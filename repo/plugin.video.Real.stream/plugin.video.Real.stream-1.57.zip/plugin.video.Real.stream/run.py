import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import resolveurl
import cookielib , base64
import requests
import plugintools
import codecs
import tyriom

if 64 - 64: i11iIiiIii
OO0o = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
Oo0Ooo = OO0o . getAddonInfo ( 'version' )
O0O0OO0O0O0 = int ( sys . argv [ 1 ] )
iiiii = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
ooo0OO = iiiii . getAddonInfo ( 'profile' )
II1 = iiiii . getAddonInfo ( 'path' )
#Imagenes
O00ooooo00 = xbmc . translatePath ( os . path . join ( II1 , 'fanart.jpg' ) )
I1IiiI = xbmc . translatePath ( os . path . join ( II1 , 'icon.png' ) )
IIi1IiiiI1Ii = xbmc . translatePath ( os . path . join ( II1 , 'extended_info.png' ) )
I11i11Ii = xbmc . translatePath ( os . path . join ( II1 , 'buscar.png' ) )
oO00oOo = xbmc . translatePath ( os . path . join ( II1 , 'pair.png' ) )
OOOo0 = xbmc . translatePath ( os . path . join ( II1 , 'theMovieDB.png' ) )
Oooo000o = xbmc . translatePath ( os . path . join ( II1 , 'estrenos.png' ) )
IiIi11iIIi1Ii = xbmc . translatePath ( os . path . join ( II1 , 'encines.png' ) )
Oo0O = xbmc . translatePath ( os . path . join ( II1 , 'recomendadas.png' ) )
IiI = xbmc . translatePath ( os . path . join ( II1 , 'accion.png' ) )
ooOo = xbmc . translatePath ( os . path . join ( II1 , 'animacion.png' ) )
Oo = xbmc . translatePath ( os . path . join ( II1 , 'aventuras.png' ) )
o0O = xbmc . translatePath ( os . path . join ( II1 , 'belico.png' ) )
IiiIII111iI = xbmc . translatePath ( os . path . join ( II1 , 'ciencia-ficcion.png' ) )
IiII = xbmc . translatePath ( os . path . join ( II1 , 'comedia.png' ) )
iI1Ii11111iIi = xbmc . translatePath ( os . path . join ( II1 , 'crimen.png' ) )
i1i1II = xbmc . translatePath ( os . path . join ( II1 , 'drama.png' ) )
O0oo0OO0 = xbmc . translatePath ( os . path . join ( II1 , 'familiar.png' ) )
I1i1iiI1 = xbmc . translatePath ( os . path . join ( II1 , 'fantasia.png' ) )
iiIIIII1i1iI = xbmc . translatePath ( os . path . join ( II1 , 'historia.png' ) )
o0oO0 = xbmc . translatePath ( os . path . join ( II1 , 'marvel.png' ) )
oo00 = xbmc . translatePath ( os . path . join ( II1 , 'misterio.png' ) )
o00 = xbmc . translatePath ( os . path . join ( II1 , 'musical.png' ) )
Oo0oO0ooo = xbmc . translatePath ( os . path . join ( II1 , 'romance.png' ) )
o0oOoO00o = xbmc . translatePath ( os . path . join ( II1 , 'spain.png' ) )
i1 = xbmc . translatePath ( os . path . join ( II1 , 'suspense.png' ) )
oOOoo00O0O = xbmc . translatePath ( os . path . join ( II1 , 'terror.png' ) )
i1111 = xbmc . translatePath ( os . path . join ( II1 , 'thriller.png' ) )
i11 = xbmc . translatePath ( os . path . join ( II1 , 'western.png' ) )
I11 = xbmc . translatePath ( os . path . join ( II1 , 'sagas_cine.png' ) )
Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( II1 , '4k.png' ) )
oOo0oooo00o = xbmc . translatePath ( os . path . join ( II1 , 'torrent.png' ) )
if 65 - 65: O0o * i1iIIII * I1
if 54 - 54: oO % IiiIIiiI11 / oooOOOOO * IiiIII111ii / i1iIIi1
ii11iIi1I = xbmc . translatePath ( os . path . join ( II1 , 'peliculas.png' ) )
iI111I11I1I1 = xbmc . translatePath ( os . path . join ( II1 , 'ajustes.png' ) )
OOooO0OOoo = xbmc . translatePath ( os . path . join ( II1 , 'videoteca.png' ) )
iIii1 = xbmc . translatePath ( os . path . join ( II1 , 'favorites.png' ) )
oOOoO0 = xbmc . translatePath ( os . path . join ( II1 , 'resolver.png' ) )
O0OoO000O0OO = xbmc . translatePath ( os . path . join ( II1 , 'test.png' ) )
iiI1IiI = xbmc . translatePath ( os . path . join ( II1 , 'video-tutoriales.png' ) )
II = xbmc . translatePath ( os . path . join ( II1 , 'buscar-serie.png' ) )
ooOoOoo0O = xbmc . translatePath ( os . path . join ( II1 , 'series-todas.png' ) )
OooO0 = xbmc . translatePath ( os . path . join ( II1 , 'emision.png' ) )
II11iiii1Ii = xbmc . translatePath ( os . path . join ( II1 , 'mejores.png' ) )
OO0oOoo = xbmc . translatePath ( os . path . join ( II1 , 'favoritos.png' ) )
O0o0Oo = xbmc . translatePath ( os . path . join ( II1 , 'BuscadorPeliculas.png' ) )
Oo00OOOOO = xbmc . translatePath ( os . path . join ( II1 , 'BuscadorSeries.png' ) )
O0O = xbmc . translatePath ( os . path . join ( II1 , 'Novedades_series.png' ) )
O00o0OO = xbmc . translatePath ( os . path . join ( II1 , 'Novedades_Episodios.png' ) )
if 44 - 44: O0oIi1ii1 / Oo0o0 + OO0oo0oOO + I1iii - i1iiI11I
iiii = OO0o . getSetting ( 'mostrar_cat' )
oO0o0O0OOOoo0 = OO0o . getSetting ( 'videos' )
IiIiiI = OO0o . getSetting ( 'activar' )
I1I = OO0o . getSetting ( 'favcopy' )
oOO00oOO = OO0o . getSetting ( 'anticopia' )
OoOo = OO0o . getSetting ( 'notificar' )
iI = OO0o . getSetting ( 'mostrar_bus' )
o00O = OO0o . getSetting ( 'restante' )
OOO0OOO00oo = OO0o . getSetting ( 'aviso' )
Iii111II = OO0o . getSetting ( 'RealStream_Settings' )
iiii11I = OO0o . getSetting ( 'Resolver_Settings' )
o00O = OO0o . getSetting ( 'restante' )
Ooo0OO0oOO = OO0o . getSetting ( 'fav' )
ii11i1 = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
IIIii1II1II = 'bienvenida'
i1I1iI = 'YmllbnZlbmlkYQ==' . decode ( 'base64' )
oo0OooOOo0 = 'todas=[\'"](.*?)[\'"]\s*estrenos=[\'"](.*?)[\'"]\s*novedades=[\'"](.*?)[\'"]\s*accion=[\'"](.*?)[\'"]\s*animacion=[\'"](.*?)[\'"]\s*aventuras=[\'"](.*?)[\'"]\s*belico=[\'"](.*?)[\'"]\s*cifi=[\'"](.*?)[\'"]\s*comedia=[\'"](.*?)[\'"]\s*crimen=[\'"](.*?)[\'"]\s*drama=[\'"](.*?)[\'"]\s*familiar=[\'"](.*?)[\'"]\s*fantasia=[\'"](.*?)[\'"]\s*historia=[\'"](.*?)[\'"]\s*misterio=[\'"](.*?)[\'"]\s*musical=[\'"](.*?)[\'"]\s*romance=[\'"](.*?)[\'"]\s*thriller=[\'"](.*?)[\'"]\s*suspense=[\'"](.*?)[\'"]\s*terror=[\'"](.*?)[\'"]\s*western=[\'"](.*?)[\'"]\s*spain=[\'"](.*?)[\'"]\s*superheroes=[\'"](.*?)[\'"]\s*sagas=[\'"](.*?)[\'"]\s*videotutoriales=[\'"](.*?)[\'"]\s*'
if 92 - 92: oOo00oOO0O . oO0O0ooO0Oo * oOOoo0Oo
if 78 - 78: OOO00OoOO00
I1IIiI1 = OO0o . getSetting ( 'Forceupdate' )
if I1IIiI1 == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3


"""


 :::====  :::===== :::====  :::           :::===  :::==== :::====  :::===== :::====  :::=======       :::====  ::: ===      :::= === :::===== :::==== :::====  :::      :::==== :::===== :::====  :::=======       :::====  :::====  :::====  :::====       ===
 :::  === :::      :::  === :::           :::     :::==== :::  === :::      :::  === ::: === ===      :::  === ::: ===      :::===== :::      :::==== :::  === :::      :::==== :::      :::  === ::: === ===      ::   === :::  === ::   === :::  ===      ===
 =======  ======   ======== ===            =====    ===   =======  ======   ======== === === ===      =======   =====       ======== ======     ===   ======== ===        ===   ======   ======== === === ===         ====  ===  ===    ====  ===  ===      ===
 === ===  ===      ===  === ===               ===   ===   === ===  ===      ===  === ===     ===      ===  ===   ===        === ==== ===        ===   ===  === ===        ===   ===      ===  === ===     ===       ===     ===  ===  ===     ===  ===         
 ===  === ======== ===  === ========      ======    ===   ===  === ======== ===  === ===     ===      =======    ===        ===  === ========   ===   ===  === ===        ===   ======== ===  === ===     ===      ========  ======  ========  ======       ===
                                                                                                                                                                                                                                                               

O08m3wLRPeyHauPPZih4j5ba7Sba1praRnYjQqovl32kl8Udhx+L8pkncbARg7+iI6xs3Nlj5Pcl5kprwuaUDs4hVQS042IPFdaEs47AZqlx42kaI84C5RAYraiEDaQGruN20hw3WuTERZoaWio6zi0PsOC2uVc+7kqzrzcOhp632xFhRn4TQGuHRe+JRJcYqqjszo+c9s3KOje00Q1NTa2avF7i/VPhnbpN4Z8GisCWCxovAMPQbIwc+C0esUUK1zahuIAnqRtXV3922U1DDtJLXuCZiYpm/rrFx6LvHevMDPEV3fIfyUhSHnFyD4LDkAWwyqFcv0c8BJf3mKenxX58BKUU8ZtuClABulI/Ysdr+yB93MVFC5xOQElTvpURdkZpJrLbaR9QQ1NA8d0wUcBaxfC0YLxdyIAsTV0sfYyfzSehP5wpHGv86dlc4mMBcflRZ8MwKxnbZ+jS0/q0BL6vLUtaxR+Qq2SnYIjHsbJnsePKE2Tp4+c9qV2vM83I/aAW3P+bD+jlx/kRNdSfsGN/PW6HwozyDWpxxYw5Y/t3P+CvgwtpTBlI9qSQjV8+oaQvRb+6PdsTXtbAuAMgufUocZymkxnoqoU/zOfmahVprI+4jQhuF//l0WBTPMB3zT1bQjlU015wC2JbJOpqm83Omakoxb4VwXWAaG4ZABGVE2B76t3zupAWQL7roA8r0+TpYU9Qy8295hfq6oxdaE2isEVn71N1y1LG9R/Xr2ML76TTdfz8fdGEMv6Q/BWqvoWjE8uErtMPZowYmUVzGlt0Sq2N7qtrjdaimp9lVjOED0orcnZ73+g1nQBb1ht5BZLuhSBbz/YA4Z70r6oXiqxw9Soznsyos42CdTdeLrbheLur+dga6XtY+qT19EICGtIgA9IpJ5/TGGd2qGDeIcp7iTDIUyEQdGZlAfLzAZ8JXDdLrCKvkUTYJHCsKXF91eh2zRqexTFZ9oUUViCtCtMfKvC9s+S8QndDHuB3maSU2XP3Z5LwUpm8wtn6LPRmDn6BNijEzOzm2l9PskT8kz7Pai1Lj/ktNFVAL+x3wGQmmmzS1M5BtZkztvhIcA5kqatj0/j1lWghBP1rN3CIFQ6njL+kSGrS48/RF4Go7yMFXrpaA3+SLnbACHkDzjgbRbAtqTNyUIffRKeuIE5IzuynM9wbnBOr81MgdLokQlLyH3REr5wI3467kZuJNbmEziNstTW0TALpnPjgS3XBejpn5B9F1BGOdYbhxKgF06T1gw2lc07eKdb1WYU6ji/9HJ/nc7QxWD8zvkl7rcDvjnMECo1EUuc4+uJ+17wB+WWcDknlW+x1Z4c968fUjZ1Zq1HEtLbb7odDGIVC9W6ltx/busMmho4WgcqGMorNafaxwckojzOlbW48/0lSHW7AZXDlSMOntkcnt772z6KdoL1+YdrauRSSBnI6/Qljrxu/NUU5IBR82oS+KfCQVHpT0FlU3S3Wpe22PVJpoJVDsYsHqRv8Yw6slGvQQwbXbDUmLIHHyZRlVkvkJSH/bswc7opXEJBeWW7uH3cki7WF3i1+0OoGrjVZFCJ98y/G4kWe3Va2GOYp8QLAPDL83jQ2mNFSAlIWsp5K8e5agXK61O5tZs9K1tnesxGIkxB9pZeklHu13D/1R8Z1fN+oz/h29Md89yRkikGrD4egmgwnLDp8fE+lO6APgNH9f3pu2Ye2I0JJDo2uyqJIBrFpX8nvwlmjQpkIdeSdrdbV57TljsxEOUk1zRp32JOG6CWqJlGppbhUtEkKM+51tTx5861L5FlsH0X8Xfggo7rZSv2DRoxATK3n0khNYigpxa3mxqOmwuVvWTUUMltVSa++73mkOlUsCrk54XhGAvZ+HTgDWqqcQdnnOekVEeMb3Q3MH8BJ37doum6+ImNOc/N1r/bn3jZhYaisP3Q3N/1igU2fg4wgJPwR6NQ1yDDqbepRQ+dt/Ae6uIjxY+I5R7I8i6nT8TYiu83PTm9YAXexW64SwsEY6d1gkaXuaVfD77AliVPU1pbHkbUNHjI8XtwvAecsezxYavQZv66SS75d9cewywkiGq/cjya6jIqiWu5llqPQLkJ5Ig3n1BtBHudQimnwPu0NUf0xZcM3ID5NAKxRE+sMJS/mSPdAE+CiZjoXl0+Sx54a06xNxNDQAghJTgzjR2kWDxc91Uo8r5MduCuHJXJmKRXvIZHd88TtUVAGTO5iQBgQd0LwQs5eqILsZULyE/ZYLjbZfAYbzPZtr26M16kk712KpQidLfR5TGIxbZnROi+d3HnkQc7fDy6U1gO4E8RSmqVt3izDfbuvAFwkqs3rddVl8eUaTkem7ibFb+nCtVtEPhFMRVvWT1QKnaq3gGWgrtwzZY6K3brsbqBmFcgTIVTgT69I6IhJDclq/gOBCr4NMr1jflIFLm8ysgOBHlrtwFQsB3c2VJKKaWeeob3tiZOkLGU0xKz4OEtchhDziRvf8+NB1CyidKh3h2NNQgC5qir/czL/yFe2xnx1X2r5gXsAGqBuhkRbXQkR2KaYX9yT+vCDJa+0yTXd5CV86Q33xdTO/L9PTI56cMtuS/BbT4cXNI0aE2XTxBj44mRHmdGLhc652mCeND29m0mysgFhZrli1uUtEvBr2D7BlSQkbPyUhp1Njl7qNQ//UwwRborN8dtNOTgmqcmQbH/ME/ZYLjbZfAYbzPZtr26M16kk712KpQidLfR5TGIxbZnROi+d3HnkQc7fDy6U1gO4pDYRhGWoXDT4Ly8CkI9fCxawlMrdO5x49J+CeA5qdwvCtVtEPhFMRVvWT1QKnaq3gGWgrtwzZY6K3brsbqBmFcgTIVTgT69I6IhJDclq/gOBCr4NMr1jflIFLm8ysgOBHlrtwFQsB3c2VJKKaWeeofbBpfDw5q2D8m2FvUgM2JVJL9PnHcuii7P34/iaNqVQELI3kgWHh+N2ubjO3hqPDBXDU8wMe6IvnTJNeGLncT7jZEeBJWpDWRi6e/S/DNLglUIuCgOBseNy24MFgHT1vaYBVHHxt/mec1mPlYitqd8kWwXdKZzaKM+kWKlLk6Qr4gy1Arhe/TSEHfK1OwdohH2WSPwEmn2bZDtIT7b4FwmJTsYybIp3zO2/+AgjgZTYIbASzT78qnUeghj4pKHUhdlpyulWVVvwSTEkePuG81Q=/xLsXBROAESuuYyNw8XGjEiLsYw6HRauW4WZz1y8N/tIZr1ZjFIOQeiV/HiyFa/JrYLDBvEm7V8q8UoYW/+rvETos94LA7IstthtBC1tG2EJk5wGKA2BQGIByqI0RH9MjMiUDhqzsTaf5RjoVeTtMqsaYwfpjXHW5P4CTvBSQOH+0IXe92Wsexgt0oc+Jpz9APrVSzF5K45ro3atK7L+ELKagyqluyX+NxZ2i1RojGYjz5dUT+K9KNDMAmHDHr6jgZ2Fdb1I3ES3f93sX/qfrIQQvowV18H2pw4BWJ32NcIi1hPXMN4MJW1rmXPoLnOayAYhH0xW11jEP1rIwlC0TaIpF5eLqA23zAt+lQ9jRjhGVpfyzk5wwm6mdAJWvWHF5x3pv9UODh1LP7V83EE0xTGgpVmpPIOo3rrsFWvjz9Cfcqw/0SPW+FrSjKeamGYRHC1gt1y4ODdAtNyJFJU3SO0nV64ISG2LVNbpQ31WvhXDIsCTaoqmx4mkHib1h+DaCh/FyPqwYu/MNTzjySuxJc/2zmWR64CgngYvR4LBFUiC75keYFUabAiQRXSbXl506EMCL5E612myuP2b8XxRsqaxo/o+KxVZNiGi0wOsQAVEoXHMFHDBGAu2bL+JX4YJgQ4lro30Ni2k36gocw+Tef+8cSXxr9PlEoyfb0htaDGEvvjeXNo4oLlhOwmebZmYPqodPrcDymVahDGE5xd5I+AmlXIDysZ2MSrf4o/aS65zyXfCAgAjy8YnOCIq19MIGqobLrGkGhS3PhUMiZKmbGNraurRfcGWg1r4LESYowPsdzI8L4fFhvGUz5uqd6wNNFdi9950qrWZsGSvNiEZMbyOeN4G4xaQ1axTWFl+uXPPMEzjIgdk32Wrsk41zx55bpAba+sHfC4MWuxd6DJklCTra11pBFEW7AQDuE8YwLtV/30PnL/z72oLyxMpzax4f2H+p1Ks/i6i2gfNvQSoEV3RWyZcLRDvkKMAGRUX633PHKqx539R0433qBJ/lSNVY4OG6IllmbWfOnPnF/+Dt4nnv/3BqObFhuI4dYbZUsX2ev8BFHAkGYpUGaC8Y97FiXXcu1zfW4tcq7l3oCGpq0Ot7a8QLUmg6jRqtOjBo4/N3/p0rF+I5yP3CmCCQ8WWLW+Z0Dl91Bz6IpcdL8BKb1ggKASq/0iB64aPm5DqDVtp2EthoR+qyC152op4sN3zpsY0R+zjy57x9/my2nea/C+eWCCnpjw29+ZfGXYnszazirqkPzdPJvx2BJDD38zMgB9S+YH7TKPHrbpXERY6gAwuyQdW3GGAKTS07r9VxZZW5CSxNzmeuHgVXcQKTrT+5cPTezd77+omGanXB0wCkP8+OV3QABTus1WKMWOpFvgk/40QxnIxoiauuY4lZ3cXLTFbHU9Dfomhtm5DpD2+1FENmAyaScnyGTo0/V3tCiKHSlJL7bOWWci63FRuHfxmFq8r8BofUyGSpSfMJnOwwg/Ymv3yqdbkm0glrAhrbhkF/3pco70Ej8nEOtqLFe5a8FJjL8tUZvTrUiSQORlkdwYtpcMKQ/OkbN+XZctBYO4sP12/6OVF6cSBdSZFggeiYsUQ3jLSTu1cmPEP0+sc8orcn3pSR+q3T77sNlEhOkRue6hzy2AKIAJNiYGFWIfGq+kWqZjMT6idzuekB7ooofVO0upZ32Bl5DQ/RbhL4PXeDNfCh2/lqJ2wXvm1riEHTUnBvuYe2w4ai1uPxKC1OAbbS8k338SAnuOQnFsIh4PiZDtB0IG5+uuRbs5u/5fItjlREUdCMv25eflTblbG3y5hT3oj8TP4gYLtRQm8P5Q3Ckia+onIqk+ivgeUf2kPDduMVOrD1mGHAyVTDCYeeJepsRBYSK0hG+6FKp/OLrlX4/lSIQplmvGjCBCV6auoTUqypcp+FgvOhdJ4NC6RhmWpnw1v6hUVEgV15fUljEsxtX26qCHrpTa8KCR3XxTtox7CVwmsffS65UPK+j+Dewz/xGpgg04Ix7SDNlF7KkhgY4FFrKA4y5GK5hWzNuQ/cwxlpCpCDecH+o+VkTgWfVJb2Zc/JNomKb1MpM6AtLat0EtZqL9MJcg/ylmLoa6XcbuxsZif1ADLJwYbt29FkIDSPCOPaa2aL/eCtju0Z526KIcdnRGgGH1OEaPFqFxNWLZdqtJyGgcgUlxrD/aXIlTTpY/mgVpnn6P6jzJrlwN1fKc4XCp7/axzBuPEiIzYyzQ4rYjFB5WBQ5BRjmocV2//iPk2Wb9smlN8IpU9P4kJxTuYa1uz0FISaWeiXC4ZXGy4U0gPyRIrvdm0KPKtCSMCvf72ocWXe97u37n2Y0dx6UX75dsnL5ogMB8ucauvJTH66bkHY8wL+drdpiIQznjTTa93PL/4qVcRphc+Ze8OOYknHI1WihUi/v9GypxxX+oBB4t13j8SG85pe8K1lJx1eVmxaIDYUmCGyU4cnCSFwP8lgNsBS3CAeAX8zBj1wfyaFIbblFkTIWsmtJZ1QSxqn0Qf4WTjd6OAWPmfWnwFaToyqgmCG5EqyICJzDYpj5Y2l+oJWYE7OjwcZ2RRmsDDOF2GN6mURq0FqRX8FLBA/ZchmE1fgt037Im3V2EPnbbm/L0j1qu962FB2wC5nqdWw0LO1Ti+ybI3/lwpSRmD+r+7TxRUj39vvnRuhN1PXKilsBaqvsf3nVUSfEUxbgaUDX4UntNIFYR4h4Yq4EJlYPrKO7a3vCV6iMcNkV2pucnStjl9r2mSwGuYuJqXBhLChNCFWbYS+HC9GGnwOpvH79clropzNyZJJRGTreY5g24C5J4LaD40wS0C7MODHeXQpBvgGE6eoaK0gngGqnSQDOVvoC1x5oqlErMhMCBOVmcV+0hQVbEd647AF2f8EWEWu8zrcJT82FjbItMz+7wQ0RUOEqqXvIPcl90O8t9P23QKBdS2Ty6yUoqVxa0kiYCwohoiIAB8Qp6fRh/7sijGsjl+BCGv9048/bPJK0isfVVWR31mBhaDexoqtLPlO54qjsk4YaCr3lHLC5ytIilaA0sG6uGbxAAWr0pMlFghQd4848qHvNN0s8zRjCQgjx17Keqa9dSDuKBhP75+J3DnLPNLMUrUAEdE805mTMujWyAqUBk8vS8eJPLlJU1Ptz3ElHLuWJmP4T9ybNlhRM1s=





 +-+ +-+   +-+ +-+ +-+ +-+ +-+   +-+ +-+ +-+ +-+   +-+ +-+ +-+ +-+
 |B| |y|   |N| |E| |T| |A| |I|   |T| |E| |A| |M|   |2| |0| |2| |0|
 +-+ +-+   +-+ +-+ +-+ +-+ +-+   +-+ +-+ +-+ +-+   +-+ +-+ +-+ +-+

"""