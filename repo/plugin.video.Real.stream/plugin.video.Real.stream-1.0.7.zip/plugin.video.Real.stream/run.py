# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 1.0.4
#
############################################
# Dependencias 
# Script ExtendedInfo
# Script Urlresolver de TVAddons
# Script ResolveURL Por Jsergio.
#
############################################
#
# Agregar sinopsis a Peliculas y series.
# Supresion de Licencia
#
#
############################################
if 64 - 64: i11iIiiIii
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import urlresolver
import cookielib , base64
import requests
import plugintools
import config
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
IiII1IiiIiI1 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
o0OoOoOO00 = int ( sys . argv [ 1 ] )
I11i = 'gruponetai/'
O0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
Oo = O0O . getAddonInfo ( 'profile' )
I1ii11iIi11i = O0O . getAddonInfo ( 'path' )
I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
if 73 - 73: OOooOOo / ii11ii1ii
def O00ooOO ( ) :
 if 47 - 47: oO0ooO % iI1Ii11111iIi + ii1II11I1ii1I + oO0o0ooO0 - iiIIIII1i1iI
 o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 oo00 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 o00 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 Oo0oO0ooo = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 o0oOoO00o = i1 ( o00 )
 oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
 for i11 in oOOoo00O0O :
  try :
   if 41 - 41: O00o0o0000o0o . oOo0oooo00o * I1i1i1ii - IIIII
   if 26 - 26: O00OoOoo00 . iiiI11 / oooOOOOO * iI1Ii11111iIi / iiiI11
   o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 80 - 80: ii1II11I1ii1I . iiIIIII1i1iI
   if 34 - 34: O00o0o0000o0o % OoooooooOO / i1IIi . IIIII + O0
   if o0oO0 == i11 :
    if 42 - 42: O00o0o0000o0o / i1IIi + i11iIiiIii - I1i1i1ii
    if 78 - 78: oO0ooO
    Iii1I111 ( )
    if 60 - 60: iiIIIII1i1iI * ii1II11I1ii1I % ii1II11I1ii1I % oOo0oooo00o * II111iiii + i1IIi
   else :
    if 64 - 64: iiIIIII1i1iI - O0 / II111iiii / ii1II11I1ii1I / iIii1I11I1II1
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Estamos de mantenimiento. Regresaremos pronto![/COLOR] [COLOR gold]>El addon esta desactivado.[/COLOR]" )
    if 24 - 24: O0 % ii1II11I1ii1I + i1IIi + iiiI11 + oO0o0ooO0
    if 70 - 70: ii11ii1ii % ii11ii1ii . O00OoOoo00 % oO0ooO * ii1II11I1ii1I % iiIIIII1i1iI
  except :
   pass
   if 23 - 23: i11iIiiIii + OOooOOo
if I1IiI == 'true' :
 if 68 - 68: iI1Ii11111iIi . iiIIIII1i1iI . i11iIiiIii
 II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.png' ) )
 iI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 iI11iiiI1II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 O0oooo0Oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 Ii11iii11I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 oOo00Oo00O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.png' ) )
 iI11i1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.png' ) )
 o0o0OOO0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'estrenos.png' ) )
 ooOOOo0oo0O0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.png' ) )
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.png' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.png' ) )
 IIIIIooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.png' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 OOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.png' ) )
 OOO00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.png' ) )
 iiiiiIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.png' ) )
 O000OO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.png' ) )
 I11iii1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.png' ) )
 I1IIiiIiii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.png' ) )
 O000oo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'marvel.png' ) )
 OOOOi11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.png' ) )
 IIIii1II1II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.png' ) )
 i1I1iI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.png' ) )
 oo0OooOOo0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.png' ) )
 o0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.png' ) )
 O00oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.png' ) )
 I11i1I1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.png' ) )
 oO0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.png' ) )
 oOOoo0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.png' ) )
 o00OO00OoO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.png' ) )
 OOOO0OOoO0O0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.png' ) )
 O0Oo000ooO00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.jpg' ) )
 oO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.jpg' ) )
 Ii1iIiII1ii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
 ooOooo000oOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 Oo0oOOo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 Oo0OoO00oOO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.png' ) )
 OOO00O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 OOoOO0oo0ooO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 O0o0O00Oo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
else :
 if 87 - 87: oooOOOOO * ii11ii1ii % i11iIiiIii % iI1Ii11111iIi - O00o0o0000o0o
 if 68 - 68: iiiI11 % i1IIi . O00OoOoo00 . oO0o0ooO0
 ooOooo000oOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 OOO00O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
 II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.jpg' ) )
 iI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 iI11iiiI1II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 O0oooo0Oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 Ii11iii11I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 oOo00Oo00O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.jpg' ) )
 iI11i1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.jpg' ) )
 o0o0OOO0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'encines.jpg' ) )
 ooOOOo0oo0O0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.jpg' ) )
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.jpg' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.jpg' ) )
 IIIIIooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.jpg' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.jpg' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.jpg' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 OOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.jpg' ) )
 OOO00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.jpg' ) )
 iiiiiIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.jpg' ) )
 O000OO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.jpg' ) )
 I11iii1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.jpg' ) )
 I1IIiiIiii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.jpg' ) )
 O000oo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'superheroes.jpg' ) )
 OOOOi11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.jpg' ) )
 IIIii1II1II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.jpg' ) )
 i1I1iI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.jpg' ) )
 oo0OooOOo0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.jpg' ) )
 o0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.jpg' ) )
 O00oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.jpg' ) )
 I11i1I1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.jpg' ) )
 oO0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.jpg' ) )
 oOOoo0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.jpg' ) )
 o00OO00OoO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.jpg' ) )
 OOOO0OOoO0O0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.jpg' ) )
 O0Oo000ooO00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.jpg' ) )
 oO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.jpg' ) )
 Oo0oOOo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 Oo0OoO00oOO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.jpg' ) )
 Ii1iIiII1ii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favoritos.png' ) )
 OOoOO0oo0ooO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 O0o0O00Oo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
 if 92 - 92: IIIII . iiiI11
 if 31 - 31: iiiI11 . iI1Ii11111iIi / O0
 if 89 - 89: iI1Ii11111iIi
OO0oOoOO0oOO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'peliculas.png' ) )
oO0OOoo0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series.png' ) )
O0ii1ii1ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ajustes.png' ) )
oooooOoo0ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'videoteca.png' ) )
I1I1IiI1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
III1iII1I1ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'resolver.png' ) )
oOOo0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'test.png' ) )
oo00O00oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'video-tutoriales.png' ) )
iIiIIIi = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'proxy.png' ) )
if 93 - 93: IIIII
i1IIIiiII1 = IiII1IiiIiI1 . getSetting ( 'mostrar_cat' )
OOOOoOoo0O0O0 = IiII1IiiIiI1 . getSetting ( 'videos' )
OOOo00oo0oO = IiII1IiiIiI1 . getSetting ( 'activar' )
IIiIi1iI = IiII1IiiIiI1 . getSetting ( 'favcopy' )
i1IiiiI1iI = IiII1IiiIiI1 . getSetting ( 'anticopia' )
o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
i1iIi = IiII1IiiIiI1 . getSetting ( 'notificar' )
ooOOoooooo = IiII1IiiIiI1 . getSetting ( 'mostrar_bus' )
II1I = IiII1IiiIiI1 . getSetting ( 'restante' )
O0i1II1Iiii1I11 = IiII1IiiIiI1 . getSetting ( 'selecton' )
IIII = IiII1IiiIiI1 . getSetting ( 'aviso' )
iiIiI = IiII1IiiIiI1 . getSetting ( 'RealStream_Settings' )
o00oooO0Oo = IiII1IiiIiI1 . getSetting ( 'Resolver_Settings' )
II1I = IiII1IiiIiI1 . getSetting ( 'restante' )
o0O0OOO0Ooo = IiII1IiiIiI1 . getSetting ( 'fav' )
iiIiII1 = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
OOO00O0O = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
iii = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
oOooOOOoOo = 'bienvenida'
i1Iii1i1I = 'bienvenida'
copyright = IiII1IiiIiI1 . getSetting ( 'copyright' )
OOoO00 = 'cGx1Z2luLnZpZGVvLg==' . decode ( 'base64' ) + copyright
IiI111111IIII = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
i1Ii = IiII1IiiIiI1 . getSetting ( 'Forceupdate' )
if i1Ii == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
ii111iI1iIi1 = 'LnR4dA==' . decode ( 'base64' )
if 78 - 78: oO0ooO . O00o0o0000o0o + oO0ooO / oOo0oooo00o / oO0ooO
oO0O00OoOO0 = 'aHR0cDovL2JpdC5seS8yU1FOSnlP' . decode ( 'base64' )
OoO = iii + oOooOOOoOo + ii111iI1iIi1
O00 = 'http://www.youtube.com'
I1iI1 = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
iiiIi1 = '.xsl.pt'
i1I1ii11i1Iii = 'L21hc3Rlci8=' . decode ( 'base64' )
I1IiiiiI = I1iI1 + iiiIi1
o0OIiII = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*texto3=[\'"](.*?)[\'"]\s*'
ii1iII1II = 'tvg-logo=[\'"](.*?)[\'"]'
if 48 - 48: II111iiii * I1i1i1ii . oOo0oooo00o + iiIIIII1i1iI
OoO0o = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.*)'
oO0o0Ooooo = '(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)'
OOo0oO00ooO00 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
oOO0O00oO0Ooo = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
oO0Oo0O0o = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
OO = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
I1iI1ii1II = '#(.+?),(.+)\s*(.+)'
O0O0OOOOoo = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
if 74 - 74: oO0o0ooO0 + II111iiii / oO0ooO
oOo0O0Oo00oO = 'source src=[\'"](.*?)[\'"]\s*title=[\'"](.*?)[\'"]'
I111I1Iiii1i = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
oOOoo00O00o = '[\'"](.*?)[\'"]'
O0O00Oo = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
oooooo0O000o = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( 'base64' )
OoOooO0O0O0ooOOO = oooooo0O000o + I11i
i1111 = '[\'"](.*?)[\'"]'
oOOo0O00o = 'UmVhbHN0cmVhbQ==' . decode ( 'base64' )
iIiIi11 = 'video=[\'"](.*?)[\'"]'
oo00 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
o00 = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( 'base64' ) + oo00
OOO = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
iiiiI = '0110R0N' . replace ( '0110R0N' , 'R0N' )
oooOo0OOOoo0 = 'aHR0cDovL2JpdC5seS8yWEIx' . decode ( 'base64' ) + iiiiI
OOoO = '0110pEJ' . replace ( '0110pEJ' , 'pEJ' )
OO0O000 = 'aHR0cDovL2JpdC5seS8yd1Nh' . decode ( 'base64' ) + OOoO
iiIiI1i1 = 'ABBAOb5' . replace ( 'ABBAOb5' , 'Ob5' )
oO0O00oOOoooO = 'aHR0cDovL2JpdC5seS8yRVhV' . decode ( 'base64' ) + iiIiI1i1
IiIi11iI = '0110jaw' . replace ( '0110jaw' , 'jaw' )
Oo0O00O000 = 'aHR0cDovL2JpdC5seS8yd01M' . decode ( 'base64' ) + IiIi11iI
i11I1IiII1i1i = '01109DI' . replace ( '01109DI' , '9DI' )
oo = 'aHR0cDovL2JpdC5seS8ySXgz' . decode ( 'base64' ) + i11I1IiII1i1i
I1111i = '01103hs' . replace ( '01103hs' , '3hs' )
iIIii = 'aHR0cDovL2JpdC5seS8zMW1U' . decode ( 'base64' ) + I1111i
o00O0O = '01107DW' . replace ( '01107DW' , '7DW' )
ii1iii1i = 'aHR0cDovL2JpdC5seS8yV1ln' . decode ( 'base64' ) + o00O0O
Iii1I1111ii = '0110mLl' . replace ( '0110mLl' , 'mLl' )
ooOoO00 = 'aHR0cDovL2JpdC5seS8yS0cw' . decode ( 'base64' ) + Iii1I1111ii
Ii1IIiI1i = '01102Hj' . replace ( '01102Hj' , '2Hj' )
o0O00Oo0 = 'aHR0cDovL2JpdC5seS8yWEJo' . decode ( 'base64' ) + Ii1IIiI1i
IiII111i1i11 = '0110fXg' . replace ( '0110fXg' , 'fXg' )
i111iIi1i1II1 = 'aHR0cDovL2JpdC5seS8ySTVy' . decode ( 'base64' ) + IiII111i1i11
oooO = '0110NMH' . replace ( '0110NMH' , 'NMH' )
i1I1i111Ii = 'aHR0cDovL2JpdC5seS8yd0t6' . decode ( 'base64' ) + oooO
ooo = '0110bwQ' . replace ( '0110bwQ' , 'bwQ' )
i1i1iI1iiiI = 'aHR0cDovL2JpdC5seS8yd01V' . decode ( 'base64' ) + ooo
Ooo0oOooo0 = '0110xzG' . replace ( '0110xzG' , 'xzG' )
oOOOoo00 = 'aHR0cDovL2JpdC5seS8yWHhz' . decode ( 'base64' ) + Ooo0oOooo0
iiIiIIIiiI = '0110x64' . replace ( '0110x64' , 'x64' )
iiI1IIIi = 'aHR0cDovL2JpdC5seS8yRVlF' . decode ( 'base64' ) + iiIiIIIiiI
II11IiIi11 = '0110vUE' . replace ( '0110vUE' , 'vUE' )
IIOOO0O00O0OOOO = 'aHR0cDovL2JpdC5seS8yWmhW' . decode ( 'base64' ) + II11IiIi11
I1iiii1I = '01107ZL' . replace ( '01107ZL' , '7ZL' )
OOo0 = 'aHR0cDovL2JpdC5seS8yWm4w' . decode ( 'base64' ) + I1iiii1I
oO00ooooO0o = '01106cf' . replace ( '01106cf' , '6cf' )
oo0o = 'aHR0cDovL2JpdC5seS8yRVlk' . decode ( 'base64' ) + oO00ooooO0o
o0oO0oooOoo = '0110Jtp' . replace ( '0110Jtp' , 'Jtp' )
I1III1111iIi = 'aHR0cDovL2JpdC5seS8yV3Nq' . decode ( 'base64' ) + o0oO0oooOoo
I1i111I = '0110a5b' . replace ( '0110a5b' , 'a5b' )
Ooo = 'aHR0cDovL2JpdC5seS8yV3dj' . decode ( 'base64' ) + I1i111I
Oo0oo0O0o00O = '0110Q7u' . replace ( '0110Q7u' , 'Q7u' )
I1i11 = 'aHR0cDovL2JpdC5seS8yV3NL' . decode ( 'base64' ) + Oo0oo0O0o00O
IiIi1I1 = '0110rsq' . replace ( '0110rsq' , 'rsq' )
IiIIi1 = 'aHR0cDovL2JpdC5seS8ySzhE' . decode ( 'base64' ) + IiIi1I1
IIIIiii1IIii = '0110DDR' . replace ( '0110DDR' , 'DDR' )
II1i11I = 'aHR0cDovL2JpdC5seS8ySzd5' . decode ( 'base64' ) + IIIIiii1IIii
ii1I1IIii11 = '0110feQ' . replace ( '0110feQ' , 'feQ' )
O0o0oO = 'aHR0cDovL2JpdC5seS8yS0cz' . decode ( 'base64' ) + ii1I1IIii11
IIIIiIiIi1 = '0110MHY' . replace ( '0110MHY' , 'MHY' )
I11iiiiI1i = 'aHR0cDovL2JpdC5seS8ySXVo' . decode ( 'base64' ) + IIIIiIiIi1
iI1i11 = '0110xdb' . replace ( '0110xdb' , 'xdb' )
OoOOoooOO0O = 'aHR0cDovL2JpdC5seS8yWEJu' . decode ( 'base64' ) + iI1i11
ooo00Ooo = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( 'base64' )
OOoO00 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
Oo0o0O00 = '0110lxu' . replace ( '0110lxu' , 'lxu' )
ii1 = 'aHR0cDovL2JpdC5seS8yV1Bj' . decode ( 'base64' ) + Oo0o0O00
I1i11OO = '0110pzp' . replace ( '0110pzp' , 'pzp' )
o0O0oo0OO0O = 'aHR0cDovL2JpdC5seS8yVHpB' . decode ( 'base64' ) + I1i11OO
OO0 = '01105yt' . replace ( '01105yt' , '5yt' )
o0Oooo = 'aHR0cDovL2JpdC5seS8yTVpp' . decode ( 'base64' ) + OO0
if 36 - 36: OoooooooOO . oO0ooO
if 56 - 56: ii11ii1ii . oO0o0ooO0 . OOooOOo
ii111I = '1001DTs' . replace ( '1001DTs' , 'DTs' )
iiI = 'aHR0cDovL2JpdC5seS8ySzhP' . decode ( 'base64' ) + ii111I
iIiiiII = '1001Hky' . replace ( '1001Hky' , 'Hky' )
i1iI1 = 'aHR0cDovL2JpdC5seS8yTGVL' . decode ( 'base64' ) + iIiiiII
i11ii1ii11i = '1001VFU' . replace ( '1001VFU' , 'VFU' )
ooO0OoOO = 'aHR0cDovL2JpdC5seS8zMERx' . decode ( 'base64' ) + i11ii1ii11i
O0O0Oo00 = '3545OMZ' . replace ( '3545OMZ' , 'OMZ' )
oOoO00o = 'aHR0cDovL2JpdC5seS8yazhk' . decode ( 'base64' ) + O0O0Oo00
if 100 - 100: ii1II11I1ii1I + O00o0o0000o0o * ii1II11I1ii1I
def oOOo0OOOo00O ( ) :
 if 76 - 76: i11iIiiIii + ii1II11I1ii1I / oO0o0ooO0 - oO0ooO - I1i1i1ii + oO0o0ooO0
 if 51 - 51: iIii1I11I1II1 . oooOOOOO + iIii1I11I1II1
 try :
  if 95 - 95: OOooOOo
  o0oOoO00o = i1 ( oooOo0OOOoo0 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for iII1ii1 in oOOoo00O0O :
   try :
    if 12 - 12: O00o0o0000o0o - oooOOOOO . OoooooooOO / oO0o0ooO0 . i1IIi * oO0ooO
    OO0O000 = iII1ii1
    if 19 - 19: i11iIiiIii + OoooooooOO - ii11ii1ii - oOo0oooo00o
    Iii1iiIi1II = xbmc . Keyboard ( '' , 'Busqueda por titulo' )
    Iii1iiIi1II . doModal ( )
    if ( Iii1iiIi1II . isConfirmed ( ) ) :
     if 60 - 60: OOooOOo - iiIIIII1i1iI * oOo0oooo00o % II111iiii
     oooIIiIiI1I = urllib . quote_plus ( Iii1iiIi1II . getText ( ) ) . replace ( '+' , ' ' )
     OooOoOo = i1 ( OO0O000 )
     oOOoo00O0O = re . compile ( OoO0o ) . findall ( OooOoOo )
     if 14 - 14: ii1II11I1ii1I * O00o0o0000o0o + IIIII + O0 + i11iIiiIii
     for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II in oOOoo00O0O :
      if re . search ( oooIIiIiI1I , OooiiIi1i ( Oo0 . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , description , II )
       if 77 - 77: oO0o0ooO0 + oO0ooO / iiIIIII1i1iI + O0 * ii1II11I1ii1I
   except :
    pass
 except :
  pass
  if 28 - 28: oooOOOOO + i11iIiiIii / oOo0oooo00o % iI1Ii11111iIi % ii11ii1ii - O0
  if 54 - 54: i1IIi + II111iiii
  if 83 - 83: oO0o0ooO0 - OOooOOo + O00o0o0000o0o
def iIi1Ii1i1iI ( ) :
 if 16 - 16: O00o0o0000o0o / ii11ii1ii / OoooooooOO * OOooOOo + i1IIi % O00o0o0000o0o
 IIII = IiII1IiiIiI1 . getSetting ( 'aviso' )
 if IIII == 'true' :
  o0oOoO00o = i1 ( OoO )
  oOOoo00O0O = re . compile ( o0OIiII ) . findall ( o0oOoO00o )
  for ooo0o00 , ooO , o0o00 in oOOoo00O0O :
   try :
    if 14 - 14: ii1II11I1ii1I . O00o0o0000o0o . oOo0oooo00o + OoooooooOO - O00o0o0000o0o + O00OoOoo00
    if 9 - 9: I1i1i1ii
    oooooOOO000Oo = ooo0o00
    Ooo00OoOOO = ooO
    Oo0OO0000oooo = o0o00
    if 7 - 7: iiIIIII1i1iI - oO0ooO - O0 % iiIIIII1i1iI - II111iiii
    if 31 - 31: IIIII / ii11ii1ii - IIIII - O00o0o0000o0o
    I1iiIIIi11 = "[B]" + oooooOOO000Oo + "[/B]"
    Ii1I11ii1i = "" + Ooo00OoOOO + ""
    O0iIiIIIIIii = "" + Oo0OO0000oooo + ""
    if 58 - 58: ii1II11I1ii1I / O00OoOoo00 . iI1Ii11111iIi / OoooooooOO + iiiI11
    xbmcgui . Dialog ( ) . ok ( "Real Stream" , I1iiIIIi11 , Ii1I11ii1i , O0iIiIIIIIii )
    if 86 - 86: oOo0oooo00o * OOooOOo + oOo0oooo00o + II111iiii
   except :
    pass
    if 8 - 8: iiiI11 - IIIII / oooOOOOO
    if 96 - 96: iI1Ii11111iIi
 IIiiI = i1 ( ooo00Ooo )
 oOOoo00O0O = re . compile ( oOOoo00O00o ) . findall ( IIiiI )
 for III1i11 in oOOoo00O0O :
  try :
   if 25 - 25: oO0ooO
   import xbmc
   import xbmcaddon
   if 24 - 24: O00OoOoo00 * i11iIiiIii * O00o0o0000o0o
   __addon__ = xbmcaddon . Addon ( )
   __addonname__ = __addon__ . getAddonInfo ( 'name' )
   __icon__ = __addon__ . getAddonInfo ( 'icon' )
   if 85 - 85: ii1II11I1ii1I . iI1Ii11111iIi / oooOOOOO . O0 % iiiI11
   iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
   OO0ooo0oOO = III1i11
   if 97 - 97: OOooOOo / IIIII
   I1iiIIIi11 = "[COLOR orange]Version instalada: [COLOR gold] " + iIiiiI1IiI1I1 + " [/COLOR][/COLOR]"
   Oooo0 = 4000
   if 59 - 59: OoooooooOO
   xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , I1iiIIIi11 , Oooo0 , __icon__ ) )
   if 47 - 47: oooOOOOO - OOooOOo / II111iiii
   if iIiiiI1IiI1I1 < OO0ooo0oOO :
    xbmcgui . Dialog ( ) . ok ( "[B][COLOR fuchsia]Realstream:[/COLOR][/B]" , "[COLOR gold]Actualmente tiene instalada la version:  [/COLOR][COLOR lime][B]" + iIiiiI1IiI1I1 + "[/B][/COLOR]" , "[COLOR orange]Ya esta disponible la nueva version  [B][/COLOR][COLOR lime]" + III1i11 + "[/B][/COLOR][COLOR orange] Puede actualizarla desde el repositorio Realstream.[/COLOR]" )
    if 12 - 12: O00o0o0000o0o
  except :
   pass
 if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
  if 83 - 83: IIIII . O0 / ii11ii1ii / O00o0o0000o0o - II111iiii
  if 100 - 100: oO0ooO
def OooiiIi1i ( s ) :
 if 46 - 46: iI1Ii11111iIi / iIii1I11I1II1 % IIIII . iIii1I11I1II1 * IIIII
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 38 - 38: oO0o0ooO0 - IIIII / O0 . iiiI11
def i1iiIiI1Ii1i ( file ) :
 if 22 - 22: O00OoOoo00 / i11iIiiIii
 try :
  oOOoo = open ( file , 'r' )
  o0oOoO00o = oOOoo . read ( )
  oOOoo . close ( )
  return o0oOoO00o
 except :
  pass
  if 14 - 14: ii1II11I1ii1I * iiIIIII1i1iI
def i1 ( url ) :
 if 81 - 81: I1i1i1ii * ii1II11I1ii1I + iiiI11 + ii11ii1ii - OoooooooOO
 try :
  i1i1I111iIi1 = urllib2 . Request ( url )
  i1i1I111iIi1 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  oo00O00oO000o = urllib2 . urlopen ( i1i1I111iIi1 )
  OOo00OoO = oo00O00oO000o . read ( )
  oo00O00oO000o . close ( )
  return OOo00OoO
 except urllib2 . URLError , iIi1 :
  print 'We failed to open "%s".' % url
  if hasattr ( iIi1 , 'code' ) :
   print 'We failed with error code - %s.' % iIi1 . code
  if hasattr ( iIi1 , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , iIi1 . reason
   if 21 - 21: oOo0oooo00o
def OoO00 ( url ) :
 i1i1I111iIi1 = urllib2 . Request ( url )
 i1i1I111iIi1 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 i1i1I111iIi1 . add_header ( 'Referer' , '%s' % url )
 i1i1I111iIi1 . add_header ( 'Connection' , 'keep-alive' )
 oo00O00oO000o = urllib2 . urlopen ( i1i1I111iIi1 )
 OOo00OoO = oo00O00oO000o . read ( )
 oo00O00oO000o . close ( )
 return OOo00OoO
 if 85 - 85: ii11ii1ii * ii11ii1ii * OOooOOo . OoooooooOO . I1i1i1ii * oooOOOOO
 if 65 - 65: O00o0o0000o0o * iiiI11
def ooo0o000O ( ) :
 if 100 - 100: iiIIIII1i1iI . oooOOOOO * oO0o0ooO0 / iIii1I11I1II1 * i1IIi % oooOOOOO
 OOO00O0O = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 if 17 - 17: oOo0oooo00o . O00OoOoo00 - II111iiii + O0 / iIii1I11I1II1 / i11iIiiIii
 if OOOo00oo0oO == 'true' :
  if 39 - 39: O00OoOoo00 * ii11ii1ii + iIii1I11I1II1 - O00OoOoo00 + O00o0o0000o0o
  o0iiiI1I1iIIIi1 ( '[COLOR %s]Buscar Pelicula[/COLOR]' % OOO00O0O , 'search' , 111 , OOoOO0oo0ooO , II )
  o0iiiI1I1iIIIi1 ( '[COLOR %s]Buscar Serie[/COLOR]' % OOO00O0O , 'search' , 145 , O0o0O00Oo0o0 , II )
  o0iiiI1I1iIIIi1 ( '[COLOR %s]Peliculas[/COLOR] ' % OOO00O0O , 'movieDB' , 116 , OO0oOoOO0oOO0 , II )
  o0iiiI1I1iIIIi1 ( '[COLOR %s]Series[/COLOR] ' % OOO00O0O , 'movieDB' , 117 , oO0OOoo0OO , II )
  if 17 - 17: iIii1I11I1II1 . OoooooooOO / oOo0oooo00o % II111iiii % i1IIi / i11iIiiIii
  if 58 - 58: ii11ii1ii . II111iiii + iiIIIII1i1iI - i11iIiiIii / II111iiii / O0
 if iiIiI == 'true' :
  o0iiiI1I1iIIIi1 ( '[COLOR %s]Ajustes[/COLOR]' % OOO00O0O , 'Settings' , 119 , O0ii1ii1ii , II )
  if 85 - 85: iI1Ii11111iIi + O00o0o0000o0o
  if 10 - 10: O00OoOoo00 / oO0ooO + iI1Ii11111iIi / i1IIi
  if i1IIIiiII1 == 'true' :
   i1iII1II11I ( )
   if 54 - 54: O00OoOoo00 + O0 + oOo0oooo00o * iiiI11 - O00o0o0000o0o % iiIIIII1i1iI
  if o00oooO0Oo == 'true' :
   I111 ( )
   iI1I1i11iIIii ( )
   if 46 - 46: iiIIIII1i1iI % oO0ooO - iIii1I11I1II1 + I1i1i1ii - iiiI11 * oO0o0ooO0
  if i1IiiiI1iI == 'false' :
   if 11 - 11: OOooOOo - oO0ooO
   I1iiIIIi11 = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   Ii1I11ii1i = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Script.ResolveURL para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   O0iIiIIIIIii = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 39 - 39: i11iIiiIii - iIii1I11I1II1 / iiIIIII1i1iI
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , I1iiIIIi11 , Ii1I11ii1i , O0iIiIIIIIii )
   if 70 - 70: O00OoOoo00
def i11i1iiI1i ( ) :
 o0iiiI1I1iIIIi1 ( '[COLOR orange]Buscador por id[/COLOR]' , O00 , 127 , oOo00Oo00O , II )
 if 87 - 87: oooOOOOO
def IIIii ( ) :
 OOO00O0O = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]The movie DB[/COLOR]' % OOO00O0O , 'movieDB' , 99 , oOo00Oo00O , II )
 if 83 - 83: O00OoOoo00 % ii1II11I1ii1I % OOooOOo . iIii1I11I1II1 - O00OoOoo00
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Video tutoriales[/COLOR]' % OOO00O0O , O00 , 125 , oo00O00oO , II )
 if 88 - 88: OoooooooOO
 if 84 - 84: iI1Ii11111iIi / oOo0oooo00o * IIIII / iiIIIII1i1iI - i11iIiiIii . ii11ii1ii
def Iii1I111 ( ) :
 if 60 - 60: oO0o0ooO0 * OOooOOo
 ooo0o000O ( )
 IIIii ( )
 if 17 - 17: O00o0o0000o0o % ii11ii1ii / oO0o0ooO0 . O00OoOoo00 * O00o0o0000o0o - II111iiii
def i1i1IIii1i1 ( ) :
 if 65 - 65: OOooOOo + iI1Ii11111iIi / O00o0o0000o0o
 Iii1I111 ( )
 if 83 - 83: ii1II11I1ii1I . IIIII - ii11ii1ii
def Ooo0O ( ) :
 if xbmc . getCondVisibility ( 'System.HasAddon(script.favourites)' ) :
  try :
   xbmc . executebuiltin ( "RunScript(script.favourites)" )
  except :
   pass
def o0oo0000OO ( ) :
 IiII1IiiIiI1 . openSettings ( )
 if 69 - 69: oooOOOOO - oO0ooO / i11iIiiIii + oO0o0ooO0 % OoooooooOO
 if 73 - 73: I1i1i1ii - iiiI11
def O00oooo00o0O ( ) :
 urlresolver . display_settings ( )
 if 9 - 9: OOooOOo % OOooOOo % II111iiii
def I111 ( ) :
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % OOO00O0O , 'resolve' , 120 , III1iII1I1ii , II )
 if 30 - 30: O00OoOoo00 + iiiI11 - O00OoOoo00 . O00OoOoo00 - II111iiii + O0
def oOO0 ( ) :
 if 46 - 46: I1i1i1ii % iI1Ii11111iIi
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 64 - 64: i11iIiiIii - II111iiii
def iI1I1i11iIIii ( ) :
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % OOO00O0O , 'resolve' , 140 , III1iII1I1ii , II )
 if 77 - 77: iI1Ii11111iIi % I1i1i1ii
def i1iII1II11I ( ) :
 if 9 - 9: oO0ooO - ii11ii1ii * OoooooooOO . ii11ii1ii
 OOO00O0O = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Buscador[/COLOR]' % OOO00O0O , 'search' , 111 , O0oooo0Oo00 , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Estrenos[/COLOR]' % OOO00O0O , O00 , 3 , o0o0OOO0o0 , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Todas[/COLOR]' % OOO00O0O , O00 , 26 , ooOOOo0oo0O0 , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]4K[/COLOR]' % OOO00O0O , O00 , 141 , o00OO00OoO , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Novedades[/COLOR]' % OOO00O0O , O00 , 2 , iI11i1I1 , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Accion[/COLOR]' % OOO00O0O , O00 , 5 , o0 , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Animacion[/COLOR]' % OOO00O0O , O00 , 6 , I11II1i , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Artes Marciales[/COLOR]' % OOO00O0O , O00 , 29 , ooOooo000oOO , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Aventuras[/COLOR]' % OOO00O0O , O00 , 7 , IIIIIooooooO0oo , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Belico[/COLOR]' % OOO00O0O , O00 , 8 , IIiiiiiiIi1I1 , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Ciencia Ficcion[/COLOR]' % OOO00O0O , O00 , 9 , I1IIIii , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Cine Clasico[/COLOR]' % OOO00O0O , O00 , 30 , oOoOooOo0o0 , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Comedia[/COLOR]' % OOO00O0O , O00 , 10 , OOOO , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Crimen[/COLOR]' % OOO00O0O , O00 , 11 , OOO00 , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Drama[/COLOR]' % OOO00O0O , O00 , 12 , iiiiiIIii , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Familiar[/COLOR]' % OOO00O0O , O00 , 13 , O000OO0 , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Fantasia[/COLOR]' % OOO00O0O , O00 , 14 , I11iii1Ii , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Historia[/COLOR]' % OOO00O0O , O00 , 15 , I1IIiiIiii , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Misterio[/COLOR]' % OOO00O0O , O00 , 16 , OOOOi11i1 , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Musical[/COLOR]' % OOO00O0O , O00 , 17 , IIIii1II1II , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Romance[/COLOR]' % OOO00O0O , O00 , 18 , i1I1iI , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Thriller[/COLOR]' % OOO00O0O , O00 , 19 , I11i1I1I , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Suspense[/COLOR]' % OOO00O0O , O00 , 20 , o0O , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Terror[/COLOR]' % OOO00O0O , O00 , 21 , O00oO , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Western[/COLOR]' % OOO00O0O , O00 , 22 , oO0Oo , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Spain[/COLOR]' % OOO00O0O , O00 , 23 , oo0OooOOo0 , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Super heroes[/COLOR]' % OOO00O0O , O00 , 24 , O000oo0O , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Sagas[/COLOR]' % OOO00O0O , O00 , 25 , oOOoo0Oo , II )
 if 2 - 2: OoooooooOO % O00o0o0000o0o
def oOoOOo0oo0 ( ) :
 if 60 - 60: oooOOOOO * iiiI11 + ii11ii1ii
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Buscar Serie[/COLOR]' % OOO00O0O , 'search' , 145 , O0Oo000ooO00 , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]En emision[/COLOR]' % OOO00O0O , O00 , 150 , Oo0oOOo , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Mejor valoradas[/COLOR]' % OOO00O0O , O00 , 151 , Oo0OoO00oOO0o , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Series Retro[/COLOR]' % OOO00O0O , O00 , 152 , OOO00O , II )
 o0iiiI1I1iIIIi1 ( '[COLOR %s]Todas[/COLOR]' % OOO00O0O , O00 , 142 , oO0 , II )
 if 19 - 19: oO0ooO * oOo0oooo00o / oOo0oooo00o . OoooooooOO - O00o0o0000o0o + i11iIiiIii
def oo0OOo0O ( ) :
 if 39 - 39: OoooooooOO + iiIIIII1i1iI % O00o0o0000o0o / O00o0o0000o0o
 if 27 - 27: IIIII . oOo0oooo00o . iIii1I11I1II1 . iIii1I11I1II1
 try :
  if 20 - 20: ii1II11I1ii1I / i1IIi
  oO = i1 ( iiI )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( oO )
  for iII1ii1 in oOOoo00O0O :
   if 21 - 21: i11iIiiIii / iiiI11 % O00o0o0000o0o * O0 . oOo0oooo00o - iIii1I11I1II1
   try :
    if 26 - 26: II111iiii * iI1Ii11111iIi
    ii = iII1ii1
    Iii1iiIi1II = xbmc . Keyboard ( '' , 'Buscar' )
    Iii1iiIi1II . doModal ( )
    if ( Iii1iiIi1II . isConfirmed ( ) ) :
     if 81 - 81: O0 % I1i1i1ii
     oooIIiIiI1I = urllib . quote_plus ( Iii1iiIi1II . getText ( ) ) . replace ( '+' , ' ' )
     IIiiI = i1 ( ii )
     oOOoo00O0O = re . compile ( OOo0oO00ooO00 ) . findall ( IIiiI )
     for IiIII1i1i , Oo0 , II , oo0O0o00o0O , II11I in oOOoo00O0O :
      if re . search ( oooIIiIiI1I , OooiiIi1i ( Oo0 . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       oo0oOO00oO ( Oo0 , oo0O0o00o0O , 143 , IiIII1i1i , II , II11I )
   except :
    pass
 except :
  pass
  if 36 - 36: O00o0o0000o0o
def O0o ( ) :
 if 42 - 42: II111iiii
 try :
  if 32 - 32: I1i1i1ii % oO0o0ooO0 - O00o0o0000o0o * ii1II11I1ii1I + oOo0oooo00o
  oO = i1 ( oOoO00o )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( oO )
  for iII1ii1 in oOOoo00O0O :
   if 10 - 10: OOooOOo / ii11ii1ii % oO0o0ooO0 * oooOOOOO
   try :
    if 6 - 6: IIIII . O00OoOoo00 * iI1Ii11111iIi . i1IIi
    ii = iII1ii1
    if 98 - 98: i1IIi
   except :
    pass
    if 65 - 65: iI1Ii11111iIi / oO0ooO % O00OoOoo00
  IIiiI = i1 ( ii )
  oOOoo00O0O = re . compile ( OOo0oO00ooO00 ) . findall ( IIiiI )
  for IiIII1i1i , Oo0 , II , oo0O0o00o0O , II11I in oOOoo00O0O :
   try :
    if 45 - 45: iI1Ii11111iIi
    oo0oOO00oO ( Oo0 , oo0O0o00o0O , 143 , IiIII1i1i , II , II11I )
    if 66 - 66: oO0ooO
   except :
    pass
 except :
  pass
  if 56 - 56: O0
  if 61 - 61: ii1II11I1ii1I / O00o0o0000o0o / ii11ii1ii * O0
def iIII1i1i ( ) :
 if 35 - 35: II111iiii * oOo0oooo00o - OoooooooOO . oOo0oooo00o . oOo0oooo00o
 try :
  if 11 - 11: iiiI11 / iI1Ii11111iIi + oOo0oooo00o % iIii1I11I1II1
  oO = i1 ( ooO0OoOO )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( oO )
  for iII1ii1 in oOOoo00O0O :
   if 42 - 42: oO0o0ooO0 * iI1Ii11111iIi % oooOOOOO - iI1Ii11111iIi . i11iIiiIii - iiiI11
   try :
    if 84 - 84: iiiI11 - oO0o0ooO0 / oOo0oooo00o
    ii = iII1ii1
    if 13 - 13: O00OoOoo00 - ii11ii1ii - oooOOOOO
   except :
    pass
    if 92 - 92: oooOOOOO / iI1Ii11111iIi * oO0ooO . oOo0oooo00o % II111iiii
  IIiiI = i1 ( ii )
  oOOoo00O0O = re . compile ( OOo0oO00ooO00 ) . findall ( IIiiI )
  for IiIII1i1i , Oo0 , II , oo0O0o00o0O , II11I in oOOoo00O0O :
   try :
    if 71 - 71: iiiI11 % i1IIi - II111iiii - O00o0o0000o0o + O00o0o0000o0o * oooOOOOO
    oo0oOO00oO ( Oo0 , oo0O0o00o0O , 143 , IiIII1i1i , II , II11I )
    if 51 - 51: iIii1I11I1II1 / iI1Ii11111iIi + O00o0o0000o0o - oOo0oooo00o + IIIII
   except :
    pass
 except :
  pass
  if 29 - 29: ii1II11I1ii1I % iIii1I11I1II1 . OoooooooOO % OoooooooOO % II111iiii / IIIII
def oo0o0000Oo0 ( ) :
 if 80 - 80: iiiI11 - ii11ii1ii
 try :
  if 96 - 96: oO0o0ooO0 / II111iiii . I1i1i1ii - IIIII * oOo0oooo00o * iiIIIII1i1iI
  oO = i1 ( i1iI1 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( oO )
  for iII1ii1 in oOOoo00O0O :
   if 76 - 76: I1i1i1ii - II111iiii * O00o0o0000o0o / OoooooooOO
   try :
    if 18 - 18: oO0ooO + iIii1I11I1II1 - II111iiii - OOooOOo
    ii = iII1ii1
    if 71 - 71: OoooooooOO
   except :
    pass
    if 33 - 33: iiiI11
  IIiiI = i1 ( ii )
  oOOoo00O0O = re . compile ( OOo0oO00ooO00 ) . findall ( IIiiI )
  for IiIII1i1i , Oo0 , II , oo0O0o00o0O , II11I in oOOoo00O0O :
   try :
    if 62 - 62: oO0o0ooO0 + I1i1i1ii + i1IIi / OoooooooOO
    oo0oOO00oO ( Oo0 , oo0O0o00o0O , 143 , IiIII1i1i , II , II11I )
    if 7 - 7: ii1II11I1ii1I + i1IIi . OOooOOo / ii11ii1ii
   except :
    pass
 except :
  pass
  if 22 - 22: oooOOOOO - oooOOOOO % O00o0o0000o0o . iiiI11 + iiIIIII1i1iI
def Oo00OOo00O ( ) :
 if 81 - 81: O00OoOoo00 . ii1II11I1ii1I / iiiI11
 try :
  if 17 - 17: i11iIiiIii - O00o0o0000o0o . O00OoOoo00 % iIii1I11I1II1 + oOo0oooo00o - oooOOOOO
  oO = i1 ( iiI )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( oO )
  for iII1ii1 in oOOoo00O0O :
   if 78 - 78: oOo0oooo00o * iI1Ii11111iIi . O0 / O0
   try :
    if 80 - 80: i1IIi - ii11ii1ii / oO0ooO - i11iIiiIii
    ii = iII1ii1
    if 68 - 68: iiIIIII1i1iI - oO0o0ooO0 % O0 % iiiI11
   except :
    pass
    if 11 - 11: O0 / oO0ooO % O00o0o0000o0o + ii1II11I1ii1I + iIii1I11I1II1
  IIiiI = i1 ( ii )
  oOOoo00O0O = re . compile ( OOo0oO00ooO00 ) . findall ( IIiiI )
  for IiIII1i1i , Oo0 , II , oo0O0o00o0O , II11I in oOOoo00O0O :
   try :
    if 40 - 40: oooOOOOO - O00o0o0000o0o . I1i1i1ii * ii11ii1ii % iiiI11
    oo0oOO00oO ( Oo0 , oo0O0o00o0O , 143 , IiIII1i1i , II , II11I )
    if 56 - 56: i11iIiiIii . ii1II11I1ii1I - OOooOOo * oOo0oooo00o
   except :
    pass
 except :
  pass
  if 91 - 91: iiIIIII1i1iI + OoooooooOO - i1IIi
def o000 ( name , url ) :
 if 94 - 94: ii1II11I1ii1I + O0 / oOo0oooo00o . OOooOOo + O00o0o0000o0o . iIii1I11I1II1
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 62 - 62: iI1Ii11111iIi / OOooOOo - oO0o0ooO0 - OOooOOo + i11iIiiIii + i1IIi
 OooOoOo = i1 ( url )
 oOOoo00O0O = re . compile ( oO0Oo0O0o ) . findall ( OooOoOo )
 for IiIII1i1i , name , II , url in oOOoo00O0O :
  try :
   if 23 - 23: IIIII + oOo0oooo00o . iI1Ii11111iIi * OOooOOo + oO0o0ooO0
   if 18 - 18: O00OoOoo00 * ii1II11I1ii1I . O00OoOoo00 / O0
   iiIiII1 = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % iiIiII1 + name + '[/COLOR]'
   iiIII1II ( name , url , 144 , IiIII1i1i , II )
   if 100 - 100: ii11ii1ii % I1i1i1ii / oOo0oooo00o
   if 30 - 30: ii11ii1ii - O00o0o0000o0o - IIIII
  except :
   pass
   if 81 - 81: ii1II11I1ii1I . OoooooooOO + O00o0o0000o0o * oooOOOOO
   if 74 - 74: i1IIi + O0 + ii11ii1ii
   if 5 - 5: ii11ii1ii * iI1Ii11111iIi
def iiIII1II ( name , url , mode , iconimage , fanart ) :
 if 46 - 46: oooOOOOO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 33 - 33: IIIII - II111iiii * OoooooooOO - ii11ii1ii - O00o0o0000o0o
 O0OO0O = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage="
 IiiiIiiI = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 IiiiIiiI . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IiiiIiiI . setProperty ( 'fanart_image' , fanart )
 IiiiIiiI . setProperty ( 'IsPlayable' , 'true' )
 o00O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0OO0O , listitem = IiiiIiiI )
 return o00O
 if 48 - 48: IIIII . i11iIiiIii
 if 5 - 5: iiIIIII1i1iI . oO0o0ooO0 . II111iiii . OoooooooOO
def Oo0OooO0 ( name , url ) :
 if 87 - 87: iiIIIII1i1iI % I1i1i1ii
 if 83 - 83: II111iiii - oOo0oooo00o
 o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 oo00 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 o00 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 Oo0oO0ooo = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 o0oOoO00o = i1 ( o00 )
 oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
 for i11 in oOOoo00O0O :
  if 35 - 35: i1IIi - iIii1I11I1II1 + i1IIi
  try :
   if 86 - 86: iIii1I11I1II1 + iI1Ii11111iIi . i11iIiiIii - I1i1i1ii
   if 51 - 51: iI1Ii11111iIi
   o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 14 - 14: O00OoOoo00 % iiIIIII1i1iI % ii11ii1ii - i11iIiiIii
   if 53 - 53: I1i1i1ii % ii11ii1ii
   if o0oO0 == i11 :
    if 59 - 59: O00o0o0000o0o % iIii1I11I1II1 . i1IIi + II111iiii * O00OoOoo00
    if 41 - 41: I1i1i1ii % oO0o0ooO0
    if 'https://team.com' in url :
     if 12 - 12: O00o0o0000o0o
     url = url . replace ( 'https://team.com' , 'https://verystream.com' )
     if 69 - 69: OoooooooOO + O00o0o0000o0o
    if 'https://mybox.com' in url :
     if 26 - 26: ii11ii1ii + O00o0o0000o0o / oO0ooO % iI1Ii11111iIi % oO0o0ooO0 + II111iiii
     url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
     if 31 - 31: oOo0oooo00o % O00o0o0000o0o * oOo0oooo00o
     if 45 - 45: i1IIi . OOooOOo + O00o0o0000o0o - OoooooooOO % oooOOOOO
    if 'https://vidcloud.co/' in url :
     if 1 - 1: iIii1I11I1II1
     url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
     if 93 - 93: i1IIi . i11iIiiIii . ii11ii1ii
    if 'https://gounlimited.to' in url :
     if 99 - 99: oOo0oooo00o - iiiI11 - iiIIIII1i1iI % oO0ooO
     url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
     if 21 - 21: II111iiii % oO0o0ooO0 . i1IIi - OoooooooOO
    if 'https://drive.com' in url :
     if 4 - 4: OoooooooOO . oooOOOOO
     url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
     if 78 - 78: oO0o0ooO0 + oOo0oooo00o - O0
     if 10 - 10: iiiI11 % OOooOOo
    import resolveurl
    if 97 - 97: OoooooooOO - iiiI11
    oooo00 = urlresolver . HostedMediaFile ( url )
    if 96 - 96: oO0o0ooO0 % oooOOOOO % I1i1i1ii - oooOOOOO % iI1Ii11111iIi + oO0o0ooO0
    if not oooo00 :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
     return False
     if 3 - 3: O0
    try :
     Ooo0Oo0oo0 = xbmcgui . DialogProgress ( )
     Ooo0Oo0oo0 . create ( 'Realstream:' , 'Iniciando ...' )
     Ooo0Oo0oo0 . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
     xbmc . sleep ( 1000 )
     oOO0o000Oo00o = oooo00 . resolve ( )
     if not oOO0o000Oo00o or not isinstance ( oOO0o000Oo00o , basestring ) :
      try : iii11II1I = oOO0o000Oo00o . msg
      except : iii11II1I = url
      raise Exception ( iii11II1I )
      if 5 - 5: iI1Ii11111iIi - O00OoOoo00 * O00OoOoo00
    except Exception as iIi1 :
     try : iii11II1I = str ( iIi1 )
     except : iii11II1I = url
     Ooo0Oo0oo0 . update ( 45 , 'RESOLVEURL:' , 'Reiniciando ... ' )
     xbmc . sleep ( 1000 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Episodio no disponible.  ,3000)" )
     Ooo0Oo0oo0 . close ( )
     if 50 - 50: II111iiii * oO0o0ooO0 / I1i1i1ii . ii1II11I1ii1I + ii11ii1ii - O00o0o0000o0o
    Ooo0Oo0oo0 . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    Ooo0Oo0oo0 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
    xbmc . sleep ( 500 )
    Ooo0Oo0oo0 . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
    xbmc . sleep ( 500 )
    Ooo0Oo0oo0 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de este capitulo!' )
    Ooo0Oo0oo0 . close ( )
    i1iIi = IiII1IiiIiI1 . getSetting ( 'notificar' )
    II1iiIiIiI = xbmcgui . ListItem ( path = oOO0o000Oo00o )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1iiIiIiI )
    if 24 - 24: ii11ii1ii - i1IIi + oOo0oooo00o
    if 38 - 38: OoooooooOO / oO0o0ooO0 . O0 / i1IIi / ii11ii1ii + iIii1I11I1II1
   else :
    if 96 - 96: IIIII
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold]>El addon esta desactivado.[/COLOR]" )
    if 18 - 18: IIIII * oOo0oooo00o - I1i1i1ii
    if 31 - 31: ii11ii1ii - O0 % iI1Ii11111iIi % iiIIIII1i1iI
  except :
   pass
   if 45 - 45: oO0o0ooO0 + II111iiii * i11iIiiIii
   if 13 - 13: OoooooooOO * iiIIIII1i1iI - I1i1i1ii / O00o0o0000o0o + oOo0oooo00o + O00OoOoo00
   if 39 - 39: iIii1I11I1II1 - OoooooooOO
   if 81 - 81: oO0o0ooO0 - O0 * OoooooooOO
   if 23 - 23: II111iiii / iiIIIII1i1iI
   if 28 - 28: ii11ii1ii * oooOOOOO - oO0ooO
def iI11iiii1I ( ) :
 if 3 - 3: O0 % OoooooooOO / O00o0o0000o0o
 if 89 - 89: II111iiii / iiIIIII1i1iI
 IIo0OoO00 = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 IIo0OoO00 . doModal ( )
 if not IIo0OoO00 . isConfirmed ( ) :
  return None ;
 Oo0 = IIo0OoO00 . getText ( ) . strip ( )
 if 18 - 18: iiIIIII1i1iI - ii1II11I1ii1I - OOooOOo - OOooOOo
 if 54 - 54: ii11ii1ii + OOooOOo / IIIII . OOooOOo * iI1Ii11111iIi
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 1 - 1: iI1Ii11111iIi * oO0ooO . i1IIi / ii11ii1ii . oO0o0ooO0 + ii11ii1ii
  IIiIi1 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + Oo0 + '&language=es-ES' ) )
  if 91 - 91: II111iiii % IIIII % O00OoOoo00 + II111iiii / iiIIIII1i1iI
  if 62 - 62: OoooooooOO - i11iIiiIii
  return 'android'
  if 5 - 5: iIii1I11I1II1 / oOo0oooo00o / i1IIi % OoooooooOO
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 50 - 50: I1i1i1ii / iI1Ii11111iIi * I1i1i1ii
  IIiIi1 = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + Oo0 + '&language=es-ES' )
  if 34 - 34: O0 * O0 % OoooooooOO + IIIII * iIii1I11I1II1 % I1i1i1ii
  if 25 - 25: oOo0oooo00o + iI1Ii11111iIi . ii1II11I1ii1I % iI1Ii11111iIi * O00o0o0000o0o
  return 'windows'
  if 32 - 32: i11iIiiIii - iiiI11
  if 53 - 53: OoooooooOO - O00OoOoo00
def oOo ( ) :
 if 17 - 17: I1i1i1ii . i11iIiiIii
 try :
  if 5 - 5: oO0o0ooO0 + O0 + O0 . iiiI11 - oooOOOOO
  o0oOoO00o = i1 ( oooOo0OOOoo0 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for iII1ii1 in oOOoo00O0O :
   if 63 - 63: iiIIIII1i1iI
   try :
    if 71 - 71: i1IIi . I1i1i1ii * IIIII % OoooooooOO + O00o0o0000o0o
    all = iII1ii1
    if 36 - 36: O00OoOoo00
   except :
    pass
    if 49 - 49: O00o0o0000o0o / OoooooooOO / OOooOOo
  OooOoOo = i1 ( all )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( OooOoOo )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    if 74 - 74: iiiI11 % oO0o0ooO0
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 7 - 7: II111iiii
   except :
    pass
 except :
  pass
  if 27 - 27: iiIIIII1i1iI . OoooooooOO + i11iIiiIii
def O0OO ( ) :
 if 39 - 39: oO0o0ooO0 + OOooOOo - iIii1I11I1II1 - ii1II11I1ii1I
 try :
  if 7 - 7: O00OoOoo00 . iI1Ii11111iIi / oO0o0ooO0 . O00o0o0000o0o * oOo0oooo00o - II111iiii
  iI11i1I1 = i1 ( OO0O000 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( iI11i1I1 )
  for iII1ii1 in oOOoo00O0O :
   if 37 - 37: iiiI11 . iI1Ii11111iIi / O0 * IIIII
   try :
    if 7 - 7: oO0ooO * oOo0oooo00o + II111iiii % i11iIiiIii
    ii = iII1ii1
    if 8 - 8: oooOOOOO * O0
   except :
    pass
    if 73 - 73: ii1II11I1ii1I / iiIIIII1i1iI / oOo0oooo00o / oO0ooO
  IIiiI = i1 ( ii )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( IIiiI )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    if 11 - 11: iI1Ii11111iIi + O00OoOoo00 - OoooooooOO / oO0ooO
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 34 - 34: oooOOOOO
   except :
    pass
 except :
  pass
  if 45 - 45: oooOOOOO / ii11ii1ii / I1i1i1ii
def IIi11i1II ( ) :
 if 73 - 73: ii1II11I1ii1I - OOooOOo * i1IIi / i11iIiiIii * O00o0o0000o0o % II111iiii
 try :
  if 56 - 56: OoooooooOO * ii11ii1ii . ii11ii1ii . oO0o0ooO0
  o0o0OOO0o0 = i1 ( oO0O00oOOoooO )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0o0OOO0o0 )
  for iII1ii1 in oOOoo00O0O :
   if 24 - 24: ii11ii1ii . oOo0oooo00o * I1i1i1ii % IIIII / O00o0o0000o0o
   try :
    Oo0Ooo0O0 = iII1ii1
   except :
    pass
    if 42 - 42: i1IIi * iiIIIII1i1iI - I1i1i1ii . OOooOOo + ii1II11I1ii1I . iIii1I11I1II1
  o0oOoO00o = i1 ( Oo0Ooo0O0 )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( o0oOoO00o )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    if 51 - 51: oOo0oooo00o . ii11ii1ii
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 45 - 45: i1IIi - ii11ii1ii / O0 . oO0o0ooO0
   except :
    pass
 except :
  pass
  if 5 - 5: ii1II11I1ii1I . iIii1I11I1II1 % iIii1I11I1II1
def ooO0oo0o0 ( ) :
 if 9 - 9: OOooOOo + oO0o0ooO0 / OOooOOo . iiIIIII1i1iI * oooOOOOO
 try :
  if 45 - 45: i11iIiiIii
  o0oOoO00o = i1 ( db2 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for iII1ii1 in oOOoo00O0O :
   if 82 - 82: I1i1i1ii + O00OoOoo00
   try :
    if 12 - 12: iiiI11
    Oo0oOooOoOo = iII1ii1
    if 49 - 49: O00o0o0000o0o . oO0o0ooO0 . i11iIiiIii - II111iiii / I1i1i1ii
   except :
    pass
    if 62 - 62: O00o0o0000o0o
    if 1 - 1: O00OoOoo00 / O00OoOoo00 - i11iIiiIii
  o0oOoO00o = i1 ( Oo0oOooOoOo )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( o0oOoO00o )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 87 - 87: ii11ii1ii / O0 * O00OoOoo00 / ii1II11I1ii1I
   except :
    pass
 except :
  pass
  if 19 - 19: iiiI11 + i1IIi . OOooOOo - ii11ii1ii
def iIi1I1 ( ) :
 if 63 - 63: IIIII * oO0o0ooO0 . OoooooooOO / O00o0o0000o0o * ii11ii1ii . oooOOOOO
 try :
  if 62 - 62: i1IIi / oooOOOOO . OOooOOo * ii1II11I1ii1I
  i11i1Ii1 = i1 ( o0O0oo0OO0O )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( i11i1Ii1 )
  for iII1ii1 in oOOoo00O0O :
   if 98 - 98: iiiI11
   try :
    if 92 - 92: iiiI11 - iIii1I11I1II1
    I11III111i = iII1ii1
    if 78 - 78: OoooooooOO
   except :
    pass
    if 77 - 77: oO0o0ooO0 / i1IIi / ii11ii1ii % O00o0o0000o0o
    if 48 - 48: oOo0oooo00o - O00OoOoo00 + iIii1I11I1II1 + OoooooooOO
  o0oOoO00o = i1 ( I11III111i )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( o0oOoO00o )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    if 4 - 4: II111iiii . oOo0oooo00o + I1i1i1ii * iiiI11 . oooOOOOO
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 87 - 87: iI1Ii11111iIi / oO0ooO / i11iIiiIii
   except :
    pass
 except :
  pass
  if 74 - 74: iiIIIII1i1iI / oO0o0ooO0 % ii1II11I1ii1I
def OO0o0OO0 ( ) :
 if 56 - 56: i11iIiiIii - ii11ii1ii / IIIII / iI1Ii11111iIi
 try :
  if 43 - 43: ii1II11I1ii1I . IIIII . oOo0oooo00o + iIii1I11I1II1
  o0oOoO00o = i1 ( Oo0O00O000 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for iII1ii1 in oOOoo00O0O :
   if 78 - 78: iIii1I11I1II1 % iI1Ii11111iIi + oO0o0ooO0 / i1IIi % II111iiii + O00o0o0000o0o
   try :
    if 91 - 91: iIii1I11I1II1 % oO0ooO . ii1II11I1ii1I + I1i1i1ii + ii1II11I1ii1I
    o00OOo = iII1ii1
    if 87 - 87: oO0ooO % OOooOOo
   except :
    pass
    if 77 - 77: iIii1I11I1II1 - i1IIi . iiIIIII1i1iI
    if 26 - 26: ii1II11I1ii1I * O00OoOoo00 . i1IIi
  o0oOoO00o = i1 ( o00OOo )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( o0oOoO00o )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 59 - 59: O0 + i1IIi - ii1II11I1ii1I
   except :
    pass
 except :
  pass
  if 62 - 62: i11iIiiIii % O00o0o0000o0o . O00OoOoo00 . O00o0o0000o0o
def ooOo0O0O0oOO0 ( ) :
 if 10 - 10: ii11ii1ii + O0
 try :
  if 43 - 43: iIii1I11I1II1 / II111iiii % ii1II11I1ii1I - O00o0o0000o0o
  o0oOoO00o = i1 ( oo )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for iII1ii1 in oOOoo00O0O :
   if 62 - 62: oOo0oooo00o
   try :
    if 63 - 63: O00o0o0000o0o + oooOOOOO * iiIIIII1i1iI / ii1II11I1ii1I / ii11ii1ii * iIii1I11I1II1
    OOoO00ooO = iII1ii1
    if 12 - 12: oooOOOOO % OOooOOo + iiIIIII1i1iI - i1IIi . I1i1i1ii / OOooOOo
   except :
    pass
    if 51 - 51: O00o0o0000o0o . OOooOOo
  o0oOoO00o = i1 ( OOoO00ooO )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( o0oOoO00o )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 73 - 73: OoooooooOO . OOooOOo / iiiI11 % I1i1i1ii
   except :
    pass
 except :
  pass
  if 65 - 65: O00OoOoo00 - OOooOOo - I1i1i1ii
def Ii1iIi111I1i ( ) :
 if 4 - 4: IIIII - ii11ii1ii - O00OoOoo00 - oOo0oooo00o % i11iIiiIii / oO0ooO
 try :
  if 50 - 50: oooOOOOO + i1IIi
  o0oOoO00o = i1 ( iIIii )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for iII1ii1 in oOOoo00O0O :
   if 31 - 31: I1i1i1ii
   try :
    if 78 - 78: i11iIiiIii + ii1II11I1ii1I + iiiI11 / ii1II11I1ii1I % iIii1I11I1II1 % O00OoOoo00
    Oo0O0Oo00O = iII1ii1
    if 9 - 9: ii1II11I1ii1I . OOooOOo - oO0o0ooO0
   except :
    pass
    if 32 - 32: OoooooooOO / OOooOOo / iIii1I11I1II1 + II111iiii . iiIIIII1i1iI . ii1II11I1ii1I
    if 21 - 21: iIii1I11I1II1 / II111iiii % i1IIi
  o0oOoO00o = i1 ( Oo0O0Oo00O )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( o0oOoO00o )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 8 - 8: oO0ooO + iI1Ii11111iIi . iIii1I11I1II1 % O0
   except :
    pass
 except :
  pass
  if 43 - 43: oO0o0ooO0 - IIIII
def O000O ( ) :
 if 98 - 98: iIii1I11I1II1 + iiiI11 % iI1Ii11111iIi + oOo0oooo00o % iI1Ii11111iIi
 try :
  if 24 - 24: iiIIIII1i1iI * iiiI11
  o0oOoO00o = i1 ( ii1iii1i )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for iII1ii1 in oOOoo00O0O :
   if 40 - 40: I1i1i1ii - iI1Ii11111iIi * iI1Ii11111iIi . iI1Ii11111iIi + OoooooooOO
   try :
    if 77 - 77: iIii1I11I1II1 . I1i1i1ii % iiIIIII1i1iI / I1i1i1ii
    oOO0OO = iII1ii1
    if 82 - 82: oO0ooO % ii1II11I1ii1I % O00o0o0000o0o / O0
   except :
    pass
    if 94 - 94: oO0o0ooO0 + oO0o0ooO0 + OoooooooOO % oooOOOOO
    if 7 - 7: IIIII
  o0oOoO00o = i1 ( oOO0OO )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( o0oOoO00o )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 78 - 78: O00o0o0000o0o + IIIII . O00OoOoo00
   except :
    pass
 except :
  pass
  if 91 - 91: iIii1I11I1II1 . ii1II11I1ii1I . oO0o0ooO0 + OoooooooOO
def o0o0O0Oo ( ) :
 if 1 - 1: iIii1I11I1II1 + ii11ii1ii / O0 - IIIII % O00OoOoo00 + O00OoOoo00
 try :
  if 24 - 24: OOooOOo + ii11ii1ii + O00o0o0000o0o - OoooooooOO + ii11ii1ii
  o0oOoO00o = i1 ( ooOoO00 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for iII1ii1 in oOOoo00O0O :
   if 93 - 93: oooOOOOO . iIii1I11I1II1 % i11iIiiIii . iI1Ii11111iIi % oooOOOOO + O0
   try :
    if 65 - 65: I1i1i1ii + oO0ooO - OoooooooOO
    OOoOO0o = iII1ii1
    if 51 - 51: ii11ii1ii - oO0o0ooO0 * oOo0oooo00o
   except :
    pass
    if 12 - 12: iIii1I11I1II1 % oooOOOOO % oooOOOOO
    if 78 - 78: O00OoOoo00 . iI1Ii11111iIi . oOo0oooo00o
  o0oOoO00o = i1 ( OOoOO0o )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( o0oOoO00o )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 97 - 97: iiIIIII1i1iI
   except :
    pass
 except :
  pass
  if 80 - 80: OOooOOo . I1i1i1ii
def I1I11ii ( ) :
 if 93 - 93: oO0o0ooO0 % iI1Ii11111iIi . O0 / IIIII * iiIIIII1i1iI
 try :
  if 29 - 29: ii1II11I1ii1I
  o0oOoO00o = i1 ( o0Oooo )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for iII1ii1 in oOOoo00O0O :
   if 86 - 86: II111iiii . O00OoOoo00
   try :
    if 2 - 2: OoooooooOO
    o0o0O00 = iII1ii1
    if 35 - 35: iIii1I11I1II1
   except :
    pass
    if 94 - 94: iI1Ii11111iIi
    if 100 - 100: oO0ooO / i1IIi - OOooOOo % I1i1i1ii - iIii1I11I1II1
  o0oOoO00o = i1 ( o0o0O00 )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( o0oOoO00o )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 17 - 17: oOo0oooo00o / ii1II11I1ii1I % ii11ii1ii
   except :
    pass
 except :
  pass
  if 71 - 71: O00OoOoo00 . iiiI11 . oO0ooO
  if 68 - 68: i11iIiiIii % iiIIIII1i1iI * oO0ooO * O00OoOoo00 * II111iiii + O0
def o00OoO0oO00 ( ) :
 if 2 - 2: iIii1I11I1II1
 try :
  if 45 - 45: OoooooooOO / i11iIiiIii
  o0oOoO00o = i1 ( o0O00Oo0 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for iII1ii1 in oOOoo00O0O :
   if 10 - 10: IIIII - iiIIIII1i1iI * iIii1I11I1II1 % iIii1I11I1II1 * O00OoOoo00 - oO0o0ooO0
   try :
    if 97 - 97: II111iiii % iiiI11 + iiiI11 - oO0ooO / I1i1i1ii * OOooOOo
    iIii1iII1Ii = iII1ii1
    if 50 - 50: I1i1i1ii
   except :
    pass
    if 22 - 22: oOo0oooo00o * O0 . II111iiii - oO0ooO
    if 90 - 90: iiIIIII1i1iI
  o0oOoO00o = i1 ( iIii1iII1Ii )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( o0oOoO00o )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 94 - 94: oOo0oooo00o / oO0o0ooO0 * iiiI11 - iI1Ii11111iIi
   except :
    pass
 except :
  pass
  if 44 - 44: I1i1i1ii % i11iIiiIii - IIIII * oO0o0ooO0 + ii11ii1ii * O00o0o0000o0o
  if 41 - 41: O0 * oooOOOOO - iI1Ii11111iIi . I1i1i1ii
def oOIIIiI1ii1IIi ( ) :
 if 55 - 55: IIIII - oO0ooO
 try :
  if 100 - 100: O0
  o0oOoO00o = i1 ( i111iIi1i1II1 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for iII1ii1 in oOOoo00O0O :
   if 79 - 79: iIii1I11I1II1
   try :
    if 81 - 81: O00o0o0000o0o + iIii1I11I1II1 * iiiI11 - iIii1I11I1II1 . O00o0o0000o0o
    I1 = iII1ii1
    if 14 - 14: OOooOOo . I1i1i1ii
   except :
    pass
    if 46 - 46: IIIII - iIii1I11I1II1
    if 50 - 50: IIIII / IIIII + O00o0o0000o0o * oooOOOOO / oO0o0ooO0
  o0oOoO00o = i1 ( I1 )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( o0oOoO00o )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 14 - 14: I1i1i1ii % OOooOOo - iIii1I11I1II1 . O00o0o0000o0o + oO0ooO - iiiI11
   except :
    pass
    if 5 - 5: IIIII
 except :
  pass
  if 62 - 62: iI1Ii11111iIi . OoooooooOO . O00o0o0000o0o . oO0ooO * IIIII
  if 78 - 78: iiIIIII1i1iI / oO0ooO - iiIIIII1i1iI * OoooooooOO . iI1Ii11111iIi
def OOoooOoO0Oo ( ) :
 if 78 - 78: OoooooooOO / O00o0o0000o0o % iI1Ii11111iIi * OoooooooOO
 try :
  if 68 - 68: iiIIIII1i1iI
  o0oOoO00o = i1 ( i1I1i111Ii )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for iII1ii1 in oOOoo00O0O :
   if 29 - 29: IIIII + i11iIiiIii % oOo0oooo00o
   try :
    if 93 - 93: iI1Ii11111iIi % iIii1I11I1II1
    Ooo0o0oo0 = iII1ii1
    if 87 - 87: iI1Ii11111iIi / O00OoOoo00 + iIii1I11I1II1
   except :
    pass
    if 93 - 93: iIii1I11I1II1 + iiIIIII1i1iI % oooOOOOO
    if 21 - 21: O00o0o0000o0o
  o0oOoO00o = i1 ( Ooo0o0oo0 )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( o0oOoO00o )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 6 - 6: O00OoOoo00
   except :
    pass
    if 46 - 46: O00OoOoo00 + iiIIIII1i1iI
 except :
  pass
  if 79 - 79: OoooooooOO - O00OoOoo00 * O00OoOoo00 . iI1Ii11111iIi
def Oo00ooO0OoOo ( ) :
 if 99 - 99: iI1Ii11111iIi
 try :
  if 77 - 77: ii1II11I1ii1I
  o0oOoO00o = i1 ( i1i1iI1iiiI )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for iII1ii1 in oOOoo00O0O :
   if 48 - 48: iI1Ii11111iIi % oO0o0ooO0 / oOo0oooo00o . iIii1I11I1II1 * II111iiii
   try :
    if 65 - 65: iI1Ii11111iIi
    I1iI11I1III1 = iII1ii1
    if 8 - 8: i11iIiiIii / II111iiii + ii1II11I1ii1I * I1i1i1ii % O00OoOoo00 . oOo0oooo00o
   except :
    pass
    if 6 - 6: O00OoOoo00 % ii11ii1ii . ii11ii1ii - oO0o0ooO0 / oOo0oooo00o . i1IIi
  o0oOoO00o = i1 ( I1iI11I1III1 )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( o0oOoO00o )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 99 - 99: iI1Ii11111iIi . iiiI11
   except :
    pass
 except :
  pass
  if 59 - 59: oOo0oooo00o / ii11ii1ii / O00o0o0000o0o / O0 / iI1Ii11111iIi + ii1II11I1ii1I
  if 13 - 13: ii1II11I1ii1I % iiIIIII1i1iI / iiiI11 % iiiI11 % O0
def o0Ii1 ( ) :
 if 50 - 50: iiIIIII1i1iI - oooOOOOO / iIii1I11I1II1 - oO0ooO + II111iiii - O0
 try :
  if 88 - 88: iiIIIII1i1iI * oO0ooO
  o0oOoO00o = i1 ( oOOOoo00 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for iII1ii1 in oOOoo00O0O :
   if 35 - 35: oO0o0ooO0 / IIIII % OOooOOo + iIii1I11I1II1
   try :
    if 79 - 79: iI1Ii11111iIi / oooOOOOO
    oOo00o = iII1ii1
    if 98 - 98: O00o0o0000o0o % i1IIi . OOooOOo . II111iiii . oO0o0ooO0 / i11iIiiIii
   except :
    pass
    if 32 - 32: ii1II11I1ii1I + OOooOOo . iiiI11
    if 41 - 41: iI1Ii11111iIi . i11iIiiIii / oOo0oooo00o
  o0oOoO00o = i1 ( oOo00o )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( o0oOoO00o )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 98 - 98: iI1Ii11111iIi % II111iiii
   except :
    pass
 except :
  pass
  if 95 - 95: iIii1I11I1II1 - iiiI11 - O00o0o0000o0o + iiiI11 % oO0o0ooO0 . OOooOOo
  if 41 - 41: O0 + iiIIIII1i1iI . i1IIi - II111iiii * ii1II11I1ii1I . oO0ooO
def oooO00Oo ( ) :
 if 86 - 86: II111iiii + oooOOOOO + O00OoOoo00
 try :
  if 9 - 9: oooOOOOO + II111iiii % oooOOOOO % O00OoOoo00 + iIii1I11I1II1
  o0oOoO00o = i1 ( iiI1IIIi )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for iII1ii1 in oOOoo00O0O :
   if 59 - 59: i1IIi
   try :
    if 48 - 48: O0 * I1i1i1ii * oO0ooO . oO0ooO * oOo0oooo00o - I1i1i1ii
    iIi11i = iII1ii1
    if 56 - 56: i11iIiiIii . oooOOOOO / IIIII
   except :
    pass
  o0oOoO00o = i1 ( iIi11i )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( o0oOoO00o )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 48 - 48: oO0ooO * O00o0o0000o0o + iIii1I11I1II1 / II111iiii
   except :
    pass
 except :
  pass
  if 100 - 100: oOo0oooo00o
def OOO0oOO0ooo0 ( ) :
 if 14 - 14: II111iiii
 try :
  if 42 - 42: II111iiii + iiiI11 - I1i1i1ii - O0 / ii1II11I1ii1I % O00OoOoo00
  o0oOoO00o = i1 ( IIOOO0O00O0OOOO )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for iII1ii1 in oOOoo00O0O :
   if 83 - 83: O00o0o0000o0o / O0 % IIIII - ii1II11I1ii1I . ii11ii1ii
   try :
    if 49 - 49: iIii1I11I1II1 * i1IIi . OoooooooOO
    OOOO0oOo00O = iII1ii1
    if 32 - 32: O00OoOoo00 % I1i1i1ii - OOooOOo
   except :
    pass
    if 71 - 71: IIIII
    if 23 - 23: i1IIi . iIii1I11I1II1 . O00o0o0000o0o . O0 % I1i1i1ii % i11iIiiIii
  o0oOoO00o = i1 ( OOOO0oOo00O )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( o0oOoO00o )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 11 - 11: O0 - II111iiii . O00o0o0000o0o . I1i1i1ii % iiiI11
   except :
    pass
 except :
  pass
  if 21 - 21: ii11ii1ii / IIIII . iiiI11 * OoooooooOO + oOo0oooo00o - i1IIi
  if 58 - 58: oO0o0ooO0
def ii1I ( ) :
 if 98 - 98: i1IIi
 try :
  if 51 - 51: oO0o0ooO0 + oooOOOOO + ii11ii1ii / i1IIi + i1IIi
  o0oOoO00o = i1 ( OOo0 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for iII1ii1 in oOOoo00O0O :
   if 12 - 12: iIii1I11I1II1 . I1i1i1ii . oO0o0ooO0 % OOooOOo . II111iiii . iiIIIII1i1iI
   try :
    if 32 - 32: oO0o0ooO0 + O00OoOoo00 / O0 / iI1Ii11111iIi * OoooooooOO % oooOOOOO
    iIiiIIi = iII1ii1
    if 93 - 93: oooOOOOO . oO0o0ooO0 + iIii1I11I1II1 * oOo0oooo00o * oOo0oooo00o / oO0o0ooO0
   except :
    pass
    if 28 - 28: oO0ooO - iiIIIII1i1iI + iI1Ii11111iIi + I1i1i1ii / iIii1I11I1II1
    if 26 - 26: iIii1I11I1II1 - O0 . O0
  o0oOoO00o = i1 ( iIiiIIi )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( o0oOoO00o )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 68 - 68: O00o0o0000o0o + iiIIIII1i1iI . O0 . I1i1i1ii % i1IIi % O00o0o0000o0o
   except :
    pass
 except :
  pass
  if 50 - 50: O00OoOoo00 + ii1II11I1ii1I
def o0OoOOo ( ) :
 if 56 - 56: oOo0oooo00o / iIii1I11I1II1 + iI1Ii11111iIi % O00o0o0000o0o . O00o0o0000o0o - oO0o0ooO0
 try :
  if 48 - 48: ii11ii1ii - oooOOOOO + ii11ii1ii - OOooOOo * i11iIiiIii . IIIII
  o0oOoO00o = i1 ( oo0o )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for iII1ii1 in oOOoo00O0O :
   if 35 - 35: O00OoOoo00 . O0 + ii11ii1ii + O00o0o0000o0o + i1IIi
   try :
    if 65 - 65: O0 * OOooOOo / OOooOOo . iI1Ii11111iIi
    Oo0O0OOO0o0O = iII1ii1
    if 51 - 51: iiIIIII1i1iI + oO0ooO + IIIII + IIIII % ii1II11I1ii1I
   except :
    pass
    if 29 - 29: oooOOOOO
    if 41 - 41: O0 % IIIII
  o0oOoO00o = i1 ( Oo0O0OOO0o0O )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( o0oOoO00o )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 10 - 10: IIIII . i1IIi + I1i1i1ii
   except :
    pass
 except :
  pass
  if 66 - 66: oO0ooO % ii1II11I1ii1I
  if 21 - 21: iI1Ii11111iIi - OoooooooOO % i11iIiiIii
def Oo00O0OO ( ) :
 if 77 - 77: iiIIIII1i1iI - ii11ii1ii - iIii1I11I1II1
 try :
  if 16 - 16: oO0ooO / IIIII / i1IIi . IIIII + iiIIIII1i1iI
  o0oOoO00o = i1 ( I1III1111iIi )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for iII1ii1 in oOOoo00O0O :
   if 26 - 26: iIii1I11I1II1 + i1IIi / iI1Ii11111iIi % oO0o0ooO0
   try :
    if 44 - 44: OoooooooOO . II111iiii . O00o0o0000o0o % OoooooooOO
    Oo0oO00 = iII1ii1
    if 41 - 41: O0 - oOo0oooo00o * iIii1I11I1II1
   except :
    pass
    if 12 - 12: ii1II11I1ii1I * iiiI11 % II111iiii * i1IIi * iIii1I11I1II1
    if 81 - 81: ii11ii1ii - oOo0oooo00o
  o0oOoO00o = i1 ( Oo0oO00 )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( o0oOoO00o )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 24 - 24: OoooooooOO . oO0ooO * II111iiii
   except :
    pass
 except :
  pass
  if 59 - 59: iiiI11 + oO0ooO / O00o0o0000o0o
  if 97 - 97: ii11ii1ii * IIIII % oooOOOOO . IIIII - iiiI11 - O00o0o0000o0o
def oo0O0o00 ( ) :
 if 39 - 39: oooOOOOO + O0 / i1IIi % O00OoOoo00 / iiIIIII1i1iI * O00OoOoo00
 try :
  if 77 - 77: O00OoOoo00 . iiiI11 % iI1Ii11111iIi
  o0oOoO00o = i1 ( Ooo )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for iII1ii1 in oOOoo00O0O :
   if 42 - 42: O00OoOoo00 % IIIII % ii1II11I1ii1I % iiIIIII1i1iI + oOo0oooo00o % iI1Ii11111iIi
   try :
    if 3 - 3: iiIIIII1i1iI
    OOOiI1 = iII1ii1
    if 84 - 84: O00o0o0000o0o * OOooOOo % oOo0oooo00o + O00o0o0000o0o / IIIII
   except :
    pass
    if 80 - 80: OoooooooOO + O00OoOoo00
    if 95 - 95: iiiI11 / iiIIIII1i1iI * iiiI11 - OoooooooOO * OoooooooOO % oO0ooO
  o0oOoO00o = i1 ( OOOiI1 )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( o0oOoO00o )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 43 - 43: ii11ii1ii . iiiI11
   except :
    pass
 except :
  pass
  if 12 - 12: iiiI11 + O00o0o0000o0o + oOo0oooo00o . O00OoOoo00 / I1i1i1ii
  if 29 - 29: O00OoOoo00 . oooOOOOO - II111iiii
def ooooO0 ( ) :
 if 37 - 37: i11iIiiIii + OOooOOo . O00o0o0000o0o % oOo0oooo00o % oOo0oooo00o
 try :
  if 26 - 26: O0
  o0oOoO00o = i1 ( I1i11 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for iII1ii1 in oOOoo00O0O :
   if 34 - 34: oooOOOOO * iiiI11
   try :
    if 97 - 97: i11iIiiIii % iiIIIII1i1iI / ii11ii1ii / ii11ii1ii
    OoO00ooO = iII1ii1
    if 15 - 15: i11iIiiIii
   except :
    pass
    if 13 - 13: oOo0oooo00o * II111iiii * iiIIIII1i1iI * II111iiii % O00OoOoo00 / OOooOOo
    if 100 - 100: O00OoOoo00 . I1i1i1ii - iIii1I11I1II1 . i11iIiiIii / II111iiii
  o0oOoO00o = i1 ( OoO00ooO )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( o0oOoO00o )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 71 - 71: iiiI11 * ii11ii1ii . oOo0oooo00o
   except :
    pass
 except :
  pass
  if 49 - 49: O00OoOoo00 * O0 . O00OoOoo00
  if 19 - 19: II111iiii - O00OoOoo00
def OOOOo000o00OO ( ) :
 if 96 - 96: O0 . O00o0o0000o0o % oooOOOOO + i11iIiiIii - O00o0o0000o0o * oooOOOOO
 try :
  if 33 - 33: oooOOOOO % i1IIi - iiIIIII1i1iI . O0 / O0
  o0oOoO00o = i1 ( IiIIi1 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for iII1ii1 in oOOoo00O0O :
   if 96 - 96: OoooooooOO + O00OoOoo00 * O0
   try :
    if 86 - 86: I1i1i1ii
    IiII1i1iI = iII1ii1
    if 84 - 84: O00OoOoo00 + oO0o0ooO0 + I1i1i1ii + IIIII
   except :
    pass
    if 62 - 62: i11iIiiIii + iI1Ii11111iIi + i1IIi
  o0oOoO00o = i1 ( IiII1i1iI )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( o0oOoO00o )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 69 - 69: iI1Ii11111iIi
   except :
    pass
 except :
  pass
  if 63 - 63: oO0ooO / iI1Ii11111iIi * iIii1I11I1II1 . iiiI11
  if 85 - 85: i11iIiiIii / i11iIiiIii . oO0ooO . O0
def OooOo ( ) :
 if 67 - 67: ii11ii1ii / O0
 try :
  if 88 - 88: iI1Ii11111iIi - O00o0o0000o0o
  o0oOoO00o = i1 ( II1i11I )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for iII1ii1 in oOOoo00O0O :
   if 63 - 63: O00OoOoo00 * OoooooooOO
   try :
    if 19 - 19: O00OoOoo00 - ii1II11I1ii1I . iIii1I11I1II1 . iI1Ii11111iIi / O00o0o0000o0o
    OOO0O00Oo = iII1ii1
    if 13 - 13: iIii1I11I1II1
   except :
    pass
    if 2 - 2: i1IIi * iiIIIII1i1iI - iiIIIII1i1iI + OoooooooOO % iI1Ii11111iIi / iI1Ii11111iIi
    if 3 - 3: OoooooooOO
  o0oOoO00o = i1 ( OOO0O00Oo )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( o0oOoO00o )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 71 - 71: O00OoOoo00 + i1IIi - IIIII - i11iIiiIii . oOo0oooo00o - oooOOOOO
   except :
    pass
 except :
  pass
  if 85 - 85: oO0o0ooO0 - iI1Ii11111iIi / oO0o0ooO0 + O00o0o0000o0o - IIIII
def IIii1III ( ) :
 if 94 - 94: i11iIiiIii % OoooooooOO / OOooOOo
 try :
  if 24 - 24: OOooOOo * iiIIIII1i1iI
  o0oOoO00o = i1 ( O0o0oO )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for iII1ii1 in oOOoo00O0O :
   if 85 - 85: II111iiii . oooOOOOO % O00o0o0000o0o % oOo0oooo00o
   try :
    if 80 - 80: iiIIIII1i1iI * oOo0oooo00o / iIii1I11I1II1 % iiIIIII1i1iI / iIii1I11I1II1
    Iiii1 = iII1ii1
    if 36 - 36: IIIII
   except :
    pass
  o0oOoO00o = i1 ( Iiii1 )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( o0oOoO00o )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 90 - 90: O0
   except :
    pass
 except :
  pass
  if 44 - 44: i1IIi . OOooOOo / i11iIiiIii + O00OoOoo00
def iI111II1ii ( ) :
 if 62 - 62: IIIII * iIii1I11I1II1 . O00OoOoo00 - OoooooooOO * II111iiii
 try :
  if 45 - 45: O0 % OOooOOo - IIIII . oO0ooO
  o0oOoO00o = i1 ( I11iiiiI1i )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for iII1ii1 in oOOoo00O0O :
   if 42 - 42: IIIII / ii1II11I1ii1I + ii11ii1ii . ii11ii1ii % O00o0o0000o0o
   try :
    if 16 - 16: i1IIi + oO0ooO % iI1Ii11111iIi + I1i1i1ii * ii11ii1ii
    i1o0oo0 = iII1ii1
    if 67 - 67: O0 * oOo0oooo00o - ii1II11I1ii1I - II111iiii
   except :
    pass
  o0oOoO00o = i1 ( i1o0oo0 )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( o0oOoO00o )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 41 - 41: OOooOOo - iiiI11 % II111iiii . iiiI11 - oOo0oooo00o
   except :
    pass
 except :
  pass
  if 45 - 45: I1i1i1ii - O00o0o0000o0o
def OOoooO00o0o ( ) :
 if 10 - 10: I1i1i1ii - i11iIiiIii . oO0o0ooO0 % i1IIi
 try :
  if 78 - 78: iIii1I11I1II1 * ii11ii1ii . ii11ii1ii - O00o0o0000o0o . iIii1I11I1II1
  o0oOoO00o = i1 ( ii1 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for iII1ii1 in oOOoo00O0O :
   if 30 - 30: oooOOOOO + oooOOOOO % O00OoOoo00 - ii1II11I1ii1I - oO0o0ooO0
   try :
    if 36 - 36: oOo0oooo00o % O00o0o0000o0o
    OoO0 = iII1ii1
    if 37 - 37: oOo0oooo00o
   except :
    pass
  o0oOoO00o = i1 ( OoO0 )
  oOOoo00O0O = re . compile ( OoO0o ) . findall ( o0oOoO00o )
  for oOoO0 , Oo0 , oo0O0o00o0O , id , I11i1II , II11I , II in oOOoo00O0O :
   try :
    I1i11111i1i11 ( Oo0 , oo0O0o00o0O , oOoO0 , id , I11i1II , II11I , II )
    if 83 - 83: O0
   except :
    pass
 except :
  pass
  if 89 - 89: ii11ii1ii + oO0o0ooO0 - ii1II11I1ii1I
def iII1I11 ( ) :
 if 15 - 15: oOo0oooo00o
 try :
  if 13 - 13: iIii1I11I1II1 * iI1Ii11111iIi / iiiI11 % oooOOOOO + iiIIIII1i1iI
  o0oOoO00o = i1 ( OoOOoooOO0O )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for iII1ii1 in oOOoo00O0O :
   if 41 - 41: oO0o0ooO0
   try :
    if 5 - 5: ii11ii1ii
    o0oOo00 = iII1ii1
    if 22 - 22: iIii1I11I1II1 + O00OoOoo00 + oO0o0ooO0 + iiiI11 - I1i1i1ii
   except :
    pass
  o0oOoO00o = i1 ( o0oOo00 )
  oOOoo00O0O = re . compile ( I1iI1ii1II ) . findall ( o0oOoO00o )
  for oOoO0 , Oo0 , oo0O0o00o0O in oOOoo00O0O :
   try :
    I1IIII1i1 ( oOoO0 , Oo0 , oo0O0o00o0O )
    if 67 - 67: ii11ii1ii / oooOOOOO - O00OoOoo00
   except :
    pass
    if 74 - 74: oOo0oooo00o * I1i1i1ii - oO0o0ooO0 % iIii1I11I1II1
 except :
  pass
  if 56 - 56: oO0o0ooO0 - O0
  if 58 - 58: O00OoOoo00 + iIii1I11I1II1
  if 94 - 94: I1i1i1ii . i1IIi
def I1IIII1i1 ( thumb , name , url ) :
 if 71 - 71: IIIII + oO0ooO - O00OoOoo00 . oO0ooO . O00OoOoo00 + OOooOOo
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( ii1iII1II ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   o0iiiI1I1iIIIi1 ( name , url , '' , iI , II )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 26 - 26: O0
  if 'tvg-logo' in thumb :
   thumb = re . compile ( ii1iII1II ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 17 - 17: II111iiii
   iiIiii ( name , url , 4 , IiIII1i1i , II )
   if 39 - 39: OOooOOo + ii11ii1ii
  else :
   if 83 - 83: i1IIi
   iiIiii ( name , url , 4 , IiIII1i1i , II )
   if 76 - 76: I1i1i1ii + iIii1I11I1II1 + iI1Ii11111iIi . oO0ooO
def i1i1 ( name , url , thumb , id , trailer ) :
 if 68 - 68: I1i1i1ii - OOooOOo
 if 41 - 41: iiIIIII1i1iI
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 21 - 21: oooOOOOO + ii1II11I1ii1I % iiiI11 + i11iIiiIii + IIIII + II111iiii
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( ii1iII1II ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   o0iiiI1I1iIIIi1 ( name , url , '' , iI , II )
 else :
  iiIiII1 = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
  if 98 - 98: iiiI11
  name = '[COLOR %s]' % iiIiII1 + name + '[/COLOR]'
  if 49 - 49: ii11ii1ii * iiIIIII1i1iI + ii1II11I1ii1I - i11iIiiIii
  if 'tvg-logo' in thumb :
   thumb = re . compile ( ii1iII1II ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   O0i1II1Iiii1I11 = IiII1IiiIiI1 . getSetting ( 'selecton' )
   if O0i1II1Iiii1I11 == 'true' :
    if 74 - 74: ii11ii1ii / iIii1I11I1II1 . II111iiii - oO0ooO
    O0Oo0 ( name , url , 1 , thumb , thumb , id , trailer )
    if 46 - 46: OOooOOo * iI1Ii11111iIi
   else :
    if 60 - 60: O00o0o0000o0o
    O0Oo0 ( name , url , 130 , thumb , thumb , id , trailer )
    if 65 - 65: iI1Ii11111iIi
  else :
   if 91 - 91: O00OoOoo00 + I1i1i1ii % I1i1i1ii - O0 - i11iIiiIii
   if O0i1II1Iiii1I11 == 'true' :
    if 84 - 84: ii11ii1ii % IIIII % OoooooooOO + O00o0o0000o0o % i11iIiiIii
    O0Oo0 ( name , url , 1 , thumb , thumb , id , trailer )
    if 47 - 47: i1IIi + II111iiii . ii11ii1ii * iiIIIII1i1iI . oOo0oooo00o / i1IIi
   else :
    if 50 - 50: iiiI11 / i1IIi % OoooooooOO
    O0Oo0 ( name , url , 130 , thumb , thumb , id , trailer )
    if 83 - 83: oO0o0ooO0 * oO0o0ooO0 + O00o0o0000o0o
    if 57 - 57: O0 - O0 . oO0o0ooO0 / ii1II11I1ii1I / I1i1i1ii
def I1i11111i1i11 ( name , url , thumb , id , trailer , description , fanart ) :
 if 20 - 20: O00o0o0000o0o * II111iiii - iI1Ii11111iIi - iiIIIII1i1iI * iiiI11
 if 6 - 6: oooOOOOO + O00o0o0000o0o / ii11ii1ii + O00OoOoo00 % II111iiii / oO0ooO
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 iiIiII1 = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
 fanart = fanart . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 name = '[COLOR %s]' % iiIiII1 + name + '[/COLOR]'
 if 45 - 45: OoooooooOO
 if 'tvg-logo' in thumb :
  thumb = re . compile ( ii1iII1II ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  O0i1II1Iiii1I11 = IiII1IiiIiI1 . getSetting ( 'selecton' )
  if O0i1II1Iiii1I11 == 'true' :
   if 9 - 9: oOo0oooo00o . oO0ooO * i1IIi . OoooooooOO
   II1 ( name , url , 1 , thumb , fanart , id , trailer , description )
   if 60 - 60: II111iiii + i1IIi . O0 + OOooOOo
  else :
   if 80 - 80: iiIIIII1i1iI % iiIIIII1i1iI % O0 - i11iIiiIii . IIIII / O0
   II1 ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 13 - 13: OOooOOo + O0 - oO0o0ooO0 % ii11ii1ii / I1i1i1ii . i1IIi
 else :
  if 60 - 60: ii11ii1ii . O00OoOoo00 % OOooOOo - iiiI11
  if O0i1II1Iiii1I11 == 'true' :
   if 79 - 79: OoooooooOO / oO0o0ooO0 . O0
   II1 ( name , url , 1 , thumb , fanart , id , trailer , description )
   if 79 - 79: iiIIIII1i1iI - II111iiii
  else :
   if 43 - 43: i1IIi + O0 % oO0ooO / I1i1i1ii * OOooOOo
   II1 ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 89 - 89: OOooOOo . ii11ii1ii + oO0o0ooO0 . O0 % ii1II11I1ii1I
def Ooo00O0 ( name , trailer ) :
 if 70 - 70: OOooOOo - oooOOOOO - oO0ooO - iI1Ii11111iIi . i11iIiiIii % i1IIi
 if i1iIi == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Realstream, Reproduciendo Trailer de: [COLOR green]" + name + "[/COLOR] ,5000)" )
  if 1 - 1: iiIIIII1i1iI / i1IIi
  oo0O0o00o0O = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  O0oo0 = oo0O0o00o0O
  iii1iiii11I = xbmcgui . ListItem ( name , trailer , path = O0oo0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iii1iiii11I )
 else :
  oo0O0o00o0O = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  O0oo0 = oo0O0o00o0O
  iii1iiii11I = xbmcgui . ListItem ( name , trailer , path = O0oo0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iii1iiii11I )
  if 56 - 56: IIIII . iiiI11
  if 3 - 3: I1i1i1ii + iiiI11 . i1IIi / O00o0o0000o0o % iiiI11
def O0oo00oOOO0o ( trailer ) :
 if 5 - 5: ii1II11I1ii1I / OOooOOo % I1i1i1ii . O00OoOoo00
 if 'https://www.youtube.com' in trailer :
  if 86 - 86: i1IIi * iI1Ii11111iIi . O0 - I1i1i1ii - ii1II11I1ii1I - iI1Ii11111iIi
  try :
   if 47 - 47: O00o0o0000o0o + oOo0oooo00o
   import resolveurl
   if 50 - 50: iiiI11 + oO0o0ooO0
   oooo00 = urlresolver . HostedMediaFile ( oo0O0o00o0O )
   Ooo0Oo0oo0 = xbmcgui . DialogProgress ( )
   Ooo0Oo0oo0 . create ( 'Realstream:' , 'Conectando al servidor ... ' )
   Ooo0Oo0oo0 . update ( 20 , 'Por favor, espere ...' )
   xbmc . sleep ( 500 )
   if 4 - 4: O00OoOoo00 / ii11ii1ii
   if not oooo00 :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    return False
    if 31 - 31: iiiI11 - oO0o0ooO0 + O0 . ii11ii1ii + iI1Ii11111iIi - iiIIIII1i1iI
   try :
    if 43 - 43: IIIII + ii11ii1ii / OoooooooOO
    Ooo0Oo0oo0 . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    oOO0o000Oo00o = oooo00 . resolve ( )
    if not oOO0o000Oo00o or not isinstance ( oOO0o000Oo00o , basestring ) :
     try : iii11II1I = oOO0o000Oo00o . msg
     except : iii11II1I = oOO0o000Oo00o
     raise Exception ( iii11II1I )
   except Exception as iIi1 :
    try : iii11II1I = str ( iIi1 )
    except : iii11II1I = oOO0o000Oo00o
    Ooo0Oo0oo0 . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
    Ooo0Oo0oo0 . close ( )
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    if 24 - 24: O0 + ii1II11I1ii1I * I1i1i1ii - iiiI11
   Ooo0Oo0oo0 . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
   xbmc . sleep ( 500 )
   Ooo0Oo0oo0 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   Ooo0Oo0oo0 . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
   xbmc . sleep ( 500 )
   Ooo0Oo0oo0 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   Ooo0Oo0oo0 . close ( )
   if 10 - 10: i11iIiiIii
   II1iiIiIiI = xbmcgui . ListItem ( path = oOO0o000Oo00o )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1iiIiIiI )
   if 21 - 21: OOooOOo / IIIII
  except :
   pass
   if 69 - 69: oooOOOOO % oooOOOOO
  else :
   if 76 - 76: i11iIiiIii * IIIII / oO0ooO % oO0o0ooO0 + O00o0o0000o0o
   oo0O0o00o0O = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
   O0oo0 = oo0O0o00o0O
   iii1iiii11I = xbmcgui . ListItem ( trailer , path = O0oo0 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iii1iiii11I )
   return
   if 48 - 48: iIii1I11I1II1 % i1IIi + iI1Ii11111iIi % ii1II11I1ii1I
def OO0oo00oOO ( name , url ) :
 if 38 - 38: iiiI11 . IIIII . OOooOOo * oO0ooO
 if '[Youtube]' in name :
  if 69 - 69: ii1II11I1ii1I % i11iIiiIii / I1i1i1ii
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  O0oo0 = url
  iii1iiii11I = xbmcgui . ListItem ( I11i1II , path = O0oo0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iii1iiii11I )
  if 93 - 93: oooOOOOO
  if 34 - 34: iiIIIII1i1iI - oooOOOOO * ii11ii1ii / ii1II11I1ii1I
 else :
  if 19 - 19: oO0o0ooO0
  import urlresolver
  from urlresolver import common
  if 46 - 46: iIii1I11I1II1 . i11iIiiIii - iI1Ii11111iIi % O0 / II111iiii * i1IIi
  oooo00 = urlresolver . HostedMediaFile ( url )
  if 66 - 66: O0
  if not oooo00 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 52 - 52: oO0ooO * OoooooooOO
   if 12 - 12: O0 + O00OoOoo00 * i1IIi . oO0ooO
  try :
   oOO0o000Oo00o = oooo00 . resolve ( )
   if not oOO0o000Oo00o or not isinstance ( oOO0o000Oo00o , basestring ) :
    try : iii11II1I = oOO0o000Oo00o . msg
    except : iii11II1I = url
    raise Exception ( iii11II1I )
  except Exception as iIi1 :
   try : iii11II1I = str ( iIi1 )
   except : iii11II1I = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 71 - 71: iiiI11 - ii1II11I1ii1I - O00o0o0000o0o
  i1iIi = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if i1iIi == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  II1iiIiIiI = xbmcgui . ListItem ( path = oOO0o000Oo00o )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1iiIiIiI )
  if 28 - 28: iIii1I11I1II1
  if 7 - 7: ii1II11I1ii1I % O00OoOoo00 * iI1Ii11111iIi
 return
 if 58 - 58: O00OoOoo00 / oOo0oooo00o + II111iiii % IIIII - OoooooooOO
def II1iII1i1i ( name , url ) :
 if 63 - 63: O00o0o0000o0o * oOo0oooo00o
 import resolveurl
 if 22 - 22: oO0o0ooO0 * O0 * iIii1I11I1II1
 oooo00 = urlresolver . HostedMediaFile ( url )
 dp = xbmcgui . DialogProgress ( )
 dp . create ( 'Realstream:' , 'Conectando al servidor ... ' )
 dp . update ( 20 , 'Por favor, espere ...' )
 xbmc . sleep ( 500 )
 if 77 - 77: II111iiii + ii1II11I1ii1I
 if not oooo00 :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  return False
  if 47 - 47: O00o0o0000o0o
 try :
  if 75 - 75: O00OoOoo00 % i11iIiiIii + iIii1I11I1II1
  dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
  xbmc . sleep ( 500 )
  oOO0o000Oo00o = oooo00 . resolve ( )
  if not oOO0o000Oo00o or not isinstance ( oOO0o000Oo00o , basestring ) :
   try : iii11II1I = oOO0o000Oo00o . msg
   except : iii11II1I = oOO0o000Oo00o
   raise Exception ( iii11II1I )
 except Exception as iIi1 :
  try : iii11II1I = str ( iIi1 )
  except : iii11II1I = oOO0o000Oo00o
  dp . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
  dp . close ( )
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  if 92 - 92: iI1Ii11111iIi % O0
 dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
 xbmc . sleep ( 500 )
 dp . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
 xbmc . sleep ( 500 )
 dp . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
 xbmc . sleep ( 500 )
 dp . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
 dp . close ( )
 i1iIi = IiII1IiiIiI1 . getSetting ( 'notificar' )
 if 55 - 55: iIii1I11I1II1 * IIIII
 if 85 - 85: iIii1I11I1II1 . II111iiii
 if '[Realstream]' or '[Mybox]' in name :
  restante = IiII1IiiIiI1 . getSetting ( 'restante' )
 elif restante == 'true' :
  dialog = xbmcgui . Dialog ( )
  ok = dialog . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
 II1iiIiIiI = xbmcgui . ListItem ( path = oOO0o000Oo00o )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1iiIiIiI )
 if 54 - 54: I1i1i1ii . OoooooooOO % ii11ii1ii
def II1iII1i1i ( name , url ) :
 if 22 - 22: O00o0o0000o0o
 if 22 - 22: IIIII * oOo0oooo00o - ii11ii1ii * O0 / i11iIiiIii
 if 'https://www.rapidvideo.com/v/' in url :
  if 78 - 78: ii11ii1ii * O0 / oooOOOOO + OoooooooOO + O00o0o0000o0o
  o0oOoO00o = i1 ( url )
  oOOoo00O0O = re . compile ( 'rapidvideo' ) . findall ( o0oOoO00o )
  for url in oOOoo00O0O :
   if 23 - 23: IIIII % OoooooooOO / iIii1I11I1II1 + oO0o0ooO0 / i1IIi / ii1II11I1ii1I
   if 94 - 94: i1IIi
   try :
    i1iIi = IiII1IiiIiI1 . getSetting ( 'notificar' )
    if i1iIi == 'true' :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    II1iiIiIiI = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1iiIiIiI )
    if 36 - 36: OOooOOo + ii11ii1ii
   except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 46 - 46: IIIII
   if 65 - 65: i1IIi . oO0o0ooO0 / oooOOOOO
 else :
  if 11 - 11: O00OoOoo00 * oooOOOOO / oooOOOOO - O00o0o0000o0o
  import urlresolver
  from urlresolver import common
  if 68 - 68: OOooOOo % O00OoOoo00 - O00OoOoo00 / OOooOOo + oO0o0ooO0 - ii11ii1ii
  oooo00 = urlresolver . HostedMediaFile ( url )
  if 65 - 65: oooOOOOO - i1IIi
  if not oooo00 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 62 - 62: oOo0oooo00o / iiIIIII1i1iI % ii11ii1ii . OoooooooOO / i11iIiiIii / iiiI11
   if 60 - 60: OOooOOo % iiIIIII1i1iI / ii1II11I1ii1I % iiIIIII1i1iI * i11iIiiIii / IIIII
  try :
   oOO0o000Oo00o = oooo00 . resolve ( )
   if not oOO0o000Oo00o or not isinstance ( oOO0o000Oo00o , basestring ) :
    try : iii11II1I = oOO0o000Oo00o . msg
    except : iii11II1I = url
    raise Exception ( iii11II1I )
  except Exception as iIi1 :
   try : iii11II1I = str ( iIi1 )
   except : iii11II1I = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 34 - 34: iiiI11 - O00o0o0000o0o
  i1iIi = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if i1iIi == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  II1iiIiIiI = xbmcgui . ListItem ( path = oOO0o000Oo00o )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1iiIiIiI )
  if 25 - 25: iiIIIII1i1iI % OOooOOo + i11iIiiIii + O0 * OoooooooOO
 return
 if 64 - 64: i1IIi
 if 10 - 10: iiiI11 % O0 / OOooOOo % oOo0oooo00o
 if 25 - 25: II111iiii / oO0ooO
def oo0OoOO0000 ( name , url ) :
 if 2 - 2: I1i1i1ii * oO0o0ooO0 * OoooooooOO
 oOO0o000Oo00o = url
 i1iIi = IiII1IiiIiI1 . getSetting ( 'notificar' )
 if i1iIi == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  II1iiIiIiI = xbmcgui . ListItem ( path = oOO0o000Oo00o )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1iiIiIiI )
 else :
  II1iiIiIiI = xbmcgui . ListItem ( path = oOO0o000Oo00o )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1iiIiIiI )
 return
 if 73 - 73: iI1Ii11111iIi + ii11ii1ii
def oOoi1I111II ( name , url ) :
 if 65 - 65: i11iIiiIii + ii11ii1ii * OoooooooOO - oO0ooO
 if 26 - 26: ii1II11I1ii1I % O00o0o0000o0o + O00o0o0000o0o % oOo0oooo00o * i11iIiiIii / IIIII
 if '[Youtube]' in name :
  if 64 - 64: iiIIIII1i1iI % iI1Ii11111iIi / II111iiii % oooOOOOO - IIIII
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 2 - 2: iiiI11 - oO0o0ooO0 + ii1II11I1ii1I * oO0ooO / IIIII
  try :
   i1iIi = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if i1iIi == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    II1iiIiIiI = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1iiIiIiI )
    if 26 - 26: O00o0o0000o0o * ii11ii1ii
    if 31 - 31: oOo0oooo00o * iiIIIII1i1iI . I1i1i1ii
    if 35 - 35: oOo0oooo00o
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 94 - 94: oooOOOOO / i11iIiiIii % O0
  if 70 - 70: oOo0oooo00o - ii11ii1ii / OoooooooOO % OoooooooOO
 else :
  if 95 - 95: OoooooooOO % OoooooooOO . I1i1i1ii
  import xbmcgui
  import urlresolver
  from urlresolver import common
  if 26 - 26: iiIIIII1i1iI + O00OoOoo00 - II111iiii . II111iiii + oO0o0ooO0 + iI1Ii11111iIi
  oooo00 = urlresolver . HostedMediaFile ( url )
  if 68 - 68: O0
  if not oooo00 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 76 - 76: oO0o0ooO0
  import resolveurl as urlresolver
  if 99 - 99: ii1II11I1ii1I
  oooo00 = urlresolver . HostedMediaFile ( url )
  if 1 - 1: I1i1i1ii * iI1Ii11111iIi * oO0ooO + ii11ii1ii
  if 90 - 90: iiiI11 % ii11ii1ii - ii11ii1ii . iIii1I11I1II1 / O00o0o0000o0o + oOo0oooo00o
  if not oooo00 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 89 - 89: iiIIIII1i1iI
  try :
   oOO0o000Oo00o = oooo00 . resolve ( )
   if not oOO0o000Oo00o or not isinstance ( oOO0o000Oo00o , basestring ) :
    try : iii11II1I = oOO0o000Oo00o . msg
    except : iii11II1I = url
    raise Exception ( iii11II1I )
  except Exception as iIi1 :
   try : iii11II1I = str ( iIi1 )
   except : iii11II1I = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 87 - 87: IIIII % ii11ii1ii
   if 62 - 62: oO0ooO + oooOOOOO / IIIII * i11iIiiIii
   if 37 - 37: IIIII
  i1iIi = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if i1iIi == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 33 - 33: oO0ooO - O0 - oO0ooO
   if '[Realstream]' in name :
    if 94 - 94: O00OoOoo00 * oOo0oooo00o * OoooooooOO / ii1II11I1ii1I . O00OoOoo00 - ii1II11I1ii1I
    II1I = IiII1IiiIiI1 . getSetting ( 'restante' )
    if II1I == 'true' :
     I1I1i = xbmcgui . Dialog ( )
     o00O = I1I1i . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 45 - 45: O00o0o0000o0o
   II1iiIiIiI = xbmcgui . ListItem ( path = oOO0o000Oo00o )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1iiIiIiI )
   if 25 - 25: O00o0o0000o0o % O0
   if 44 - 44: iiiI11 . I1i1i1ii * II111iiii / O00OoOoo00 + iIii1I11I1II1
   if 14 - 14: O0 % O00OoOoo00 % I1i1i1ii * iiIIIII1i1iI
 return
 if 65 - 65: oOo0oooo00o % iiIIIII1i1iI + oO0o0ooO0
 if 86 - 86: iIii1I11I1II1 / O0 . iiiI11 % iIii1I11I1II1 % ii11ii1ii
 if 86 - 86: i11iIiiIii - ii1II11I1ii1I . oooOOOOO * ii11ii1ii / I1i1i1ii % ii1II11I1ii1I
def oOOo00 ( name , url ) :
 if 50 - 50: iIii1I11I1II1 - IIIII - oOo0oooo00o
 if 60 - 60: iIii1I11I1II1 * oooOOOOO
 if '[Youtube]' in name :
  if 71 - 71: iI1Ii11111iIi % ii11ii1ii % oooOOOOO
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 34 - 34: oOo0oooo00o / oOo0oooo00o % O00OoOoo00 . iI1Ii11111iIi / ii11ii1ii
  try :
   i1iIi = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if i1iIi == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    II1iiIiIiI = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1iiIiIiI )
    if 99 - 99: oooOOOOO * OOooOOo - oooOOOOO % I1i1i1ii
    if 40 - 40: O00o0o0000o0o / O00OoOoo00 / iIii1I11I1II1 + I1i1i1ii
    if 59 - 59: oOo0oooo00o * OoooooooOO + O00o0o0000o0o . iIii1I11I1II1 / i1IIi
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 75 - 75: oOo0oooo00o . O00o0o0000o0o - iIii1I11I1II1 * oO0ooO * IIIII
 else :
  if 93 - 93: oooOOOOO
  import resolveurl
  if 18 - 18: oooOOOOO
  oooo00 = urlresolver . HostedMediaFile ( url )
  if 66 - 66: iiIIIII1i1iI * i11iIiiIii + iI1Ii11111iIi / O00o0o0000o0o
  if 96 - 96: O00o0o0000o0o + O00o0o0000o0o % O00OoOoo00 % O00o0o0000o0o
  if not oooo00 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 28 - 28: iIii1I11I1II1 + iI1Ii11111iIi . ii1II11I1ii1I % i11iIiiIii
  try :
   oOO0o000Oo00o = oooo00 . resolve ( )
   if not oOO0o000Oo00o or not isinstance ( oOO0o000Oo00o , basestring ) :
    try : iii11II1I = oOO0o000Oo00o . msg
    except : iii11II1I = url
    raise Exception ( iii11II1I )
  except Exception as iIi1 :
   try : iii11II1I = str ( iIi1 )
   except : iii11II1I = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 58 - 58: oOo0oooo00o / OoooooooOO % iiIIIII1i1iI + oO0ooO
   if 58 - 58: O0
   if 91 - 91: IIIII / oO0o0ooO0 . IIIII - ii1II11I1ii1I + oO0o0ooO0
  i1iIi = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if i1iIi == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 72 - 72: I1i1i1ii . O00OoOoo00 * oO0o0ooO0 / oO0o0ooO0 / IIIII
   if '[Realstream]' in name :
    if 13 - 13: i1IIi
    II1I = IiII1IiiIiI1 . getSetting ( 'restante' )
    if II1I == 'true' :
     I1I1i = xbmcgui . Dialog ( )
     o00O = I1I1i . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 17 - 17: i11iIiiIii * ii1II11I1ii1I * ii1II11I1ii1I + oO0ooO
   II1iiIiIiI = xbmcgui . ListItem ( path = oOO0o000Oo00o )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1iiIiIiI )
   if 95 - 95: OOooOOo
   if 95 - 95: O00o0o0000o0o % oO0o0ooO0 + ii1II11I1ii1I % oooOOOOO
   if 36 - 36: O0 / i1IIi % II111iiii / IIIII
 return
 if 96 - 96: ii11ii1ii / iiIIIII1i1iI . II111iiii . ii11ii1ii
def ooIi111iII ( name , url ) :
 if 83 - 83: OoooooooOO + oO0ooO * iiIIIII1i1iI . O0
 if 13 - 13: ii1II11I1ii1I
 if '[Youtube]' in name :
  if 7 - 7: OOooOOo + O00OoOoo00 / i11iIiiIii / ii11ii1ii
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 97 - 97: iiiI11 . oOo0oooo00o / OOooOOo
  try :
   i1iIi = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if i1iIi == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    II1iiIiIiI = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1iiIiIiI )
    if 83 - 83: oOo0oooo00o - oO0o0ooO0 * iiIIIII1i1iI
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 90 - 90: ii11ii1ii * OOooOOo
 else :
  if 75 - 75: oO0o0ooO0 - iI1Ii11111iIi * i11iIiiIii . OoooooooOO - ii11ii1ii . oOo0oooo00o
  if 'https://team.com' in url :
   if 6 - 6: oOo0oooo00o * iiIIIII1i1iI / OoooooooOO % I1i1i1ii * ii1II11I1ii1I
   url = url . replace ( 'https://team.com' , 'https://verystream.com' )
   if 28 - 28: O00OoOoo00 * OOooOOo % O00OoOoo00
  if 'https://mybox.com' in url :
   if 95 - 95: O0 / oOo0oooo00o . iiiI11
   url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
   if 17 - 17: oOo0oooo00o
  if 'https://drive.com' in url :
   if 56 - 56: oooOOOOO * ii1II11I1ii1I + oOo0oooo00o
   url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
   if 48 - 48: O00OoOoo00 * oO0ooO % iiiI11 - oOo0oooo00o
  if 'https://vid.co' in url :
   if 72 - 72: i1IIi % oooOOOOO % O00OoOoo00 % iiIIIII1i1iI - iiIIIII1i1iI
   url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
   if 97 - 97: ii1II11I1ii1I * O0 / ii1II11I1ii1I * oO0ooO * ii11ii1ii
  if 'https://limited.to' in url :
   if 38 - 38: iiiI11
   url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
   if 25 - 25: iIii1I11I1II1 % II111iiii / oOo0oooo00o / oO0o0ooO0
  import resolveurl
  if 22 - 22: iiIIIII1i1iI * IIIII
  oooo00 = urlresolver . HostedMediaFile ( url )
  if 4 - 4: iI1Ii11111iIi - iiIIIII1i1iI + OOooOOo
  if 36 - 36: O00OoOoo00
  if not oooo00 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no encontrado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 19 - 19: iI1Ii11111iIi . ii1II11I1ii1I . OoooooooOO
  try :
   oOO0o000Oo00o = oooo00 . resolve ( )
   if not oOO0o000Oo00o or not isinstance ( oOO0o000Oo00o , basestring ) :
    try : iii11II1I = oOO0o000Oo00o . msg
    except : iii11II1I = url
    raise Exception ( iii11II1I )
  except Exception as iIi1 :
   try : iii11II1I = str ( iIi1 )
   except : iii11II1I = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace borrado, o no encontrado. Prueba a reiniciar el router o poner una VPN.[/COLOR]  ,5000)" )
   return False
   if 13 - 13: O00o0o0000o0o . ii11ii1ii / II111iiii
   if 43 - 43: iIii1I11I1II1 % oO0ooO
   if 84 - 84: ii11ii1ii
   i1iIi = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if i1iIi == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
    if 44 - 44: OoooooooOO * i11iIiiIii / ii11ii1ii
    if '[Realstream]' or '[Mybox]' in name :
     II1I = IiII1IiiIiI1 . getSetting ( 'restante' )
    elif II1I == 'true' :
     I1I1i = xbmcgui . Dialog ( )
     o00O = I1I1i . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 75 - 75: OoooooooOO . O00o0o0000o0o + oO0ooO / I1i1i1ii - OOooOOo % I1i1i1ii
  II1iiIiIiI = xbmcgui . ListItem ( path = oOO0o000Oo00o )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1iiIiIiI )
  if 89 - 89: IIIII * iIii1I11I1II1 + i11iIiiIii . OoooooooOO
 return
 if 51 - 51: O00o0o0000o0o / oooOOOOO + oO0ooO % iI1Ii11111iIi / I1i1i1ii
def ii111i1i ( name , url ) :
 if 71 - 71: ii1II11I1ii1I % oooOOOOO / iiIIIII1i1iI - iIii1I11I1II1 / i11iIiiIii
 if 100 - 100: iiIIIII1i1iI + O0 . OOooOOo + i1IIi - iI1Ii11111iIi + ii1II11I1ii1I
 if '[Youtube]' in name :
  if 65 - 65: II111iiii / ii11ii1ii
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 42 - 42: i11iIiiIii . O0
  try :
   i1iIi = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if i1iIi == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    II1iiIiIiI = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1iiIiIiI )
    if 75 - 75: iiiI11 + iIii1I11I1II1
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 19 - 19: OOooOOo + i11iIiiIii . O00OoOoo00 - oOo0oooo00o / I1i1i1ii + ii1II11I1ii1I
 else :
  if 38 - 38: ii11ii1ii / iIii1I11I1II1 * iIii1I11I1II1 % oO0o0ooO0
  o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
  oo00 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  o00 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  Oo0oO0ooo = IiII1IiiIiI1 . getSetting ( 'key_ext' )
  o0oOoO00o = i1 ( o00 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for i11 in oOOoo00O0O :
   if 92 - 92: oOo0oooo00o / O0 * OOooOOo - oOo0oooo00o
   try :
    if 99 - 99: i11iIiiIii % OoooooooOO
    if 56 - 56: O00OoOoo00 * iiiI11
    o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
    if 98 - 98: oOo0oooo00o + O0 * iiiI11 + i11iIiiIii - O00o0o0000o0o - iIii1I11I1II1
    if 5 - 5: O00o0o0000o0o % ii11ii1ii % O00OoOoo00 % oooOOOOO
    if o0oO0 == i11 :
     if 17 - 17: I1i1i1ii + II111iiii + OoooooooOO / O00o0o0000o0o / O00OoOoo00
     if 80 - 80: ii1II11I1ii1I % i1IIi / oOo0oooo00o
     if 'https://team.com' in url :
      if 56 - 56: i1IIi . i11iIiiIii
      url = url . replace ( 'https://team.com' , 'https://verystream.com' )
      if 15 - 15: II111iiii * iiIIIII1i1iI % IIIII / i11iIiiIii - iiIIIII1i1iI + ii11ii1ii
     if 'https://mybox.com' in url :
      if 9 - 9: oOo0oooo00o - iiIIIII1i1iI + O0 / IIIII % i1IIi
      url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
      if 97 - 97: ii1II11I1ii1I * oooOOOOO
      if 78 - 78: oOo0oooo00o . O00o0o0000o0o + iiIIIII1i1iI * IIIII - i1IIi
     if 'https://vidcloud.co/' in url :
      if 27 - 27: I1i1i1ii % i1IIi . ii11ii1ii % iiiI11
      url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
      if 10 - 10: O00OoOoo00 / OoooooooOO
     if 'https://gounlimited.to' in url :
      if 50 - 50: i11iIiiIii - OoooooooOO . iiIIIII1i1iI + O0 . i1IIi
      url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
      if 91 - 91: ii1II11I1ii1I . IIIII % ii11ii1ii - IIIII . iiIIIII1i1iI % i11iIiiIii
     if 'https://drive.com' in url :
      if 25 - 25: iIii1I11I1II1
      url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
      if 63 - 63: oooOOOOO
      if 96 - 96: oOo0oooo00o
     import resolveurl
     if 34 - 34: iI1Ii11111iIi / oO0ooO - OOooOOo . O0 . O00o0o0000o0o
     oooo00 = urlresolver . HostedMediaFile ( url )
     if 63 - 63: IIIII
     if not oooo00 :
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
      return False
      if 11 - 11: IIIII - iIii1I11I1II1
     try :
      Ooo0Oo0oo0 = xbmcgui . DialogProgress ( )
      Ooo0Oo0oo0 . create ( 'Realstream:' , 'Iniciando ...' )
      Ooo0Oo0oo0 . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
      xbmc . sleep ( 1000 )
      if 92 - 92: oO0ooO
      oOO0o000Oo00o = oooo00 . resolve ( )
      if not oOO0o000Oo00o or not isinstance ( oOO0o000Oo00o , basestring ) :
       if 15 - 15: O00OoOoo00 / O00OoOoo00 + iIii1I11I1II1 % OoooooooOO
       try : iii11II1I = oOO0o000Oo00o . msg
       except : iii11II1I = url
       raise Exception ( iii11II1I )
       if 12 - 12: oooOOOOO
     except Exception as iIi1 :
      try : iii11II1I = str ( iIi1 )
      except : iii11II1I = url
      Ooo0Oo0oo0 . update ( 45 , 'RESOLVEURL:' , 'Reiniciando ... ' )
      xbmc . sleep ( 1000 )
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no disponible.  ,3000)" )
      Ooo0Oo0oo0 . close ( )
      if 36 - 36: iiiI11 . O00OoOoo00 * OoooooooOO - ii1II11I1ii1I
     Ooo0Oo0oo0 . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
     xbmc . sleep ( 500 )
     Ooo0Oo0oo0 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
     xbmc . sleep ( 1000 )
     Ooo0Oo0oo0 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
     Ooo0Oo0oo0 . close ( )
     i1iIi = IiII1IiiIiI1 . getSetting ( 'notificar' )
     II1iiIiIiI = xbmcgui . ListItem ( path = oOO0o000Oo00o )
     xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1iiIiIiI )
     if 60 - 60: O00o0o0000o0o . IIIII / iIii1I11I1II1 + O00o0o0000o0o * iiiI11
     if 82 - 82: i11iIiiIii . iIii1I11I1II1 * OOooOOo - oOo0oooo00o + I1i1i1ii
    else :
     if 48 - 48: oO0o0ooO0
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold]>El addon esta desactivado.[/COLOR]" )
     return False
     if 96 - 96: oooOOOOO . OoooooooOO
   except :
    pass
    if 39 - 39: O00o0o0000o0o + oO0ooO
 return
 if 80 - 80: O00o0o0000o0o % oO0ooO / iI1Ii11111iIi
def OOOOO000oo0 ( ) :
 if 2 - 2: iiiI11 * OOooOOo . O00OoOoo00 * IIIII
 i11i1ii11Ii1 = [ ]
 Ii11iIiiI = sys . argv [ 2 ]
 if len ( Ii11iIiiI ) >= 2 :
  o000i11ii1 = sys . argv [ 2 ]
  Ii111I11 = o000i11ii1 . replace ( '?' , '' )
  if ( o000i11ii1 [ len ( o000i11ii1 ) - 1 ] == '/' ) :
   o000i11ii1 = o000i11ii1 [ 0 : len ( o000i11ii1 ) - 2 ]
  Oo0O0oo = Ii111I11 . split ( '&' )
  i11i1ii11Ii1 = { }
  for o0O0 in range ( len ( Oo0O0oo ) ) :
   oO0o0 = { }
   oO0o0 = Oo0O0oo [ o0O0 ] . split ( '=' )
   if ( len ( oO0o0 ) ) == 2 :
    i11i1ii11Ii1 [ oO0o0 [ 0 ] ] = oO0o0 [ 1 ]
 return i11i1ii11Ii1
 if 65 - 65: O0 . iiIIIII1i1iI
 if 85 - 85: II111iiii
def o0oOOoo0O ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  import urlresolver
  xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
  if 57 - 57: OOooOOo . i11iIiiIii * II111iiii + OoooooooOO + I1i1i1ii
def OoO0o0oOOO ( ) :
 I1I1i = xbmcgui . Dialog ( )
 list = (
 oO0I1I1i1I1I1I1 ,
 iI11IiIiiII1
 )
 if 15 - 15: oooOOOOO - O0 % OOooOOo . OoooooooOO * ii11ii1ii / O0
 IIi1I = I1I1i . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=%s]Accede a themoviedb.com[/COLOR]' % OOO00O0O ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 15 - 15: oO0o0ooO0
 if IIi1I :
  if 4 - 4: O00OoOoo00 + iIii1I11I1II1 * IIIII + ii11ii1ii * ii1II11I1ii1I % II111iiii
  if IIi1I < 0 :
   return
  OO0o0o0oo = list [ IIi1I - 2 ]
  return OO0o0o0oo ( )
 else :
  OO0o0o0oo = list [ IIi1I ]
  return OO0o0o0oo ( )
 return
 if 40 - 40: ii11ii1ii
def iI1Ii11 ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 93 - 93: OOooOOo / oooOOOOO / oOo0oooo00o + II111iiii + i11iIiiIii
iiiII1III = iI1Ii11 ( )
if 6 - 6: O00o0o0000o0o * iiIIIII1i1iI / O0 . II111iiii + O00OoOoo00 % ii1II11I1ii1I
def oO0I1I1i1I1I1I1 ( ) :
 if iiiII1III == 'android' :
  IIiIi1 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  IIiIi1 = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 67 - 67: O0 % iiiI11
  if 35 - 35: OOooOOo . iI1Ii11111iIi + OoooooooOO % ii11ii1ii % O00o0o0000o0o
def iI11IiIiiII1 ( ) :
 if 39 - 39: I1i1i1ii
 main ( )
 if 60 - 60: O00o0o0000o0o
 if 62 - 62: iiiI11 * oOo0oooo00o
 if 74 - 74: iI1Ii11111iIi . iIii1I11I1II1
def oOOoO0oO0oo0O ( ) :
 I1I1i = xbmcgui . Dialog ( )
 oO00Oo = (
 oO00OOOOOO0o ,
 iIII
 )
 if 85 - 85: II111iiii + iiiI11 - oooOOOOO * iIii1I11I1II1 % iiIIIII1i1iI
 IIi1I = I1I1i . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 62 - 62: I1i1i1ii + O0 * oO0ooO
 if IIi1I :
  if 59 - 59: II111iiii
  if IIi1I < 0 :
   return
  OO0o0o0oo = oO00Oo [ IIi1I - 2 ]
  return OO0o0o0oo ( )
 else :
  OO0o0o0oo = oO00Oo [ IIi1I ]
  return OO0o0o0oo ( )
 return
 if 43 - 43: ii11ii1ii + OoooooooOO
def iI1Ii11 ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 47 - 47: oooOOOOO
iiiII1III = iI1Ii11 ( )
if 92 - 92: oOo0oooo00o % i11iIiiIii % ii11ii1ii
def oO00OOOOOO0o ( ) :
 if iiiII1III == 'android' :
  IIiIi1 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  IIiIi1 = webbrowser . open ( 'https://olpair.com/' )
  if 23 - 23: II111iiii * IIIII
  if 80 - 80: iiiI11 / i11iIiiIii + OoooooooOO
def iIII ( ) :
 if 38 - 38: oO0o0ooO0 % oooOOOOO + i1IIi * OoooooooOO * iiIIIII1i1iI
 main ( )
 if 83 - 83: iIii1I11I1II1 - oooOOOOO - iiiI11 / oO0ooO - O0
 if 81 - 81: I1i1i1ii - iiIIIII1i1iI * oO0o0ooO0 / iiiI11
def iIIi11i ( name , url , id , trailer ) :
 I1I1i = xbmcgui . Dialog ( )
 oO00Oo = (
 III ,
 iiIi111Ii1II ,
 oOoo0oO ,
 OoO0o0oOOO ,
 IIii1i
 )
 if 69 - 69: iiiI11 / OoooooooOO % i11iIiiIii
 IIi1I = I1I1i . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % OOO00O0O ,

 '[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % OOO00O0O ,

 '[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % OOO00O0O ,

 '[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % OOO00O0O ,

 '[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % OOO00O0O ] )
 if 18 - 18: i11iIiiIii - oooOOOOO * iiIIIII1i1iI + ii1II11I1ii1I
 if IIi1I :
  if 16 - 16: OoooooooOO * i11iIiiIii . OoooooooOO - iIii1I11I1II1 * i1IIi
  if IIi1I < 0 :
   return
  OO0o0o0oo = oO00Oo [ IIi1I - 5 ]
  return OO0o0o0oo ( )
 else :
  OO0o0o0oo = oO00Oo [ IIi1I ]
  return OO0o0o0oo ( )
 return
 if 33 - 33: iiiI11 % II111iiii
 if 49 - 49: oO0o0ooO0 + oOo0oooo00o / ii1II11I1ii1I + OoooooooOO + O00o0o0000o0o / O00OoOoo00
 if 29 - 29: I1i1i1ii - I1i1i1ii / oooOOOOO
def III ( ) :
 if 49 - 49: oOo0oooo00o + iiIIIII1i1iI % oO0ooO - ii11ii1ii - O0 - OoooooooOO
 ii111i1i ( Oo0 , oo0O0o00o0O )
 if 4 - 4: II111iiii - iiIIIII1i1iI % ii11ii1ii * i11iIiiIii
def iiIi111Ii1II ( ) :
 if 18 - 18: ii11ii1ii % O0
 Ooo00O0 ( Oo0 , I11i1II )
 if 66 - 66: iIii1I11I1II1 % i11iIiiIii / OOooOOo
def oOoo0oO ( ) :
 if 47 - 47: oO0o0ooO0 * iiIIIII1i1iI + iIii1I11I1II1 - iiIIIII1i1iI / O00OoOoo00
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  oO0ooo0O0Ooo = id
  if 33 - 33: II111iiii - O00OoOoo00 - oooOOOOO
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % oO0ooo0O0Ooo )
  if 92 - 92: oO0ooO * O00OoOoo00
 if i1iIi == 'true' :
  if 92 - 92: iiIIIII1i1iI
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + Oo0 + "[/COLOR] ,5000)" )
  if 7 - 7: IIIII
def oOOoOO0O00o ( ) :
 if 38 - 38: i11iIiiIii . iIii1I11I1II1 . O00o0o0000o0o / oO0ooO
 OoO0o0oOOO ( )
 if 18 - 18: ii11ii1ii * iiiI11
def IIii1i ( ) :
 if 99 - 99: II111iiii * iIii1I11I1II1 % O0 * iiIIIII1i1iI / II111iiii % OoooooooOO
 Iii1I111 ( )
def o0iiiI1I1iIIIi1 ( name , url , mode , iconimage , fanart ) :
 if 14 - 14: O00OoOoo00 . O00OoOoo00 % oooOOOOO
 O0OO0O = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 o00O = True
 IiiiIiiI = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 IiiiIiiI . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IiiiIiiI . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  O0OO0O = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  o00O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0OO0O , listitem = IiiiIiiI , isFolder = True )
  return o00O
 o00O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0OO0O , listitem = IiiiIiiI , isFolder = True )
 return o00O
 if 42 - 42: ii1II11I1ii1I . O00o0o0000o0o - oooOOOOO
def oo0oOO00oO ( name , url , mode , iconimage , fanart , description ) :
 if 33 - 33: II111iiii / O0 / O00OoOoo00 - oOo0oooo00o - i1IIi
 O0OO0O = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 o00O = True
 IiiiIiiI = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 IiiiIiiI . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 IiiiIiiI . setProperty ( 'fanart_image' , fanart )
 o00O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0OO0O , listitem = IiiiIiiI , isFolder = True )
 return o00O
 if 8 - 8: i11iIiiIii . IIIII / iIii1I11I1II1 / oO0o0ooO0 / O00OoOoo00 - I1i1i1ii
def O0Oo0 ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 32 - 32: ii1II11I1ii1I . i1IIi * ii11ii1ii
 IiI111111IIII = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 98 - 98: I1i1i1ii - II111iiii / OOooOOo . iiIIIII1i1iI * O00OoOoo00 . oOo0oooo00o
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 IiII = [ ]
 if 27 - 27: oO0ooO . ii1II11I1ii1I . O0 - O0 / oOo0oooo00o - oO0ooO
 IiII . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 O0OO0O = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 IiiiIiiI = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 IiiiIiiI . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IiiiIiiI . setProperty ( 'fanart_image' , fanart )
 IiiiIiiI . setProperty ( 'IsPlayable' , 'true' )
 if 30 - 30: ii1II11I1ii1I - oO0ooO + O00o0o0000o0o
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  IiII . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 65 - 65: O0 / II111iiii . iIii1I11I1II1 . iiIIIII1i1iI / ii11ii1ii % iIii1I11I1II1
  IiiiIiiI . addContextMenuItems ( IiII , replaceItems = True )
 o00O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0OO0O , listitem = IiiiIiiI )
 return o00O
 if 74 - 74: i1IIi / OOooOOo % oO0o0ooO0 / O0 % oOo0oooo00o - iI1Ii11111iIi
 if 31 - 31: OOooOOo / OoooooooOO . iIii1I11I1II1 * iI1Ii11111iIi . OoooooooOO + II111iiii
def II1 ( name , url , mode , iconimage , fanart , id , trailer , description ) :
 if 8 - 8: oO0o0ooO0 * oO0o0ooO0 * i1IIi + IIIII . oO0o0ooO0
 IiI111111IIII = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 100 - 100: OoooooooOO - O0 . oOo0oooo00o / oOo0oooo00o + II111iiii * iI1Ii11111iIi
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 IiII = [ ]
 if 37 - 37: ii11ii1ii
 IiII . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 O0OO0O = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 IiiiIiiI = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 IiiiIiiI . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 IiiiIiiI . setProperty ( 'fanart_image' , fanart )
 IiiiIiiI . setProperty ( 'IsPlayable' , 'true' )
 if 72 - 72: O00OoOoo00 % oO0o0ooO0 * O00o0o0000o0o . i11iIiiIii % O00OoOoo00 * O00o0o0000o0o
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  IiII . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 15 - 15: oOo0oooo00o / ii11ii1ii * oOo0oooo00o
  IiiiIiiI . addContextMenuItems ( IiII , replaceItems = True )
 o00O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0OO0O , listitem = IiiiIiiI )
 return o00O
 if 20 - 20: oooOOOOO - O00o0o0000o0o * oO0ooO * ii1II11I1ii1I * O00o0o0000o0o / O00OoOoo00
def iiIiii ( name , url , mode , iconimage , fanart ) :
 if 40 - 40: OOooOOo * ii1II11I1ii1I . OOooOOo
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 62 - 62: oooOOOOO + II111iiii % oooOOOOO
 O0OO0O = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 IiiiIiiI = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 IiiiIiiI . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IiiiIiiI . setProperty ( 'fanart_image' , fanart )
 IiiiIiiI . setProperty ( 'IsPlayable' , 'true' )
 o00O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0OO0O , listitem = IiiiIiiI )
 return o00O
 if 50 - 50: OoooooooOO + iiIIIII1i1iI * OOooOOo - I1i1i1ii / i11iIiiIii
def iiiIIiiIi ( name , url , mode ) :
 if 86 - 86: OoooooooOO % II111iiii . OoooooooOO * oO0o0ooO0
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 9 - 9: ii11ii1ii + IIIII
 O0OO0O = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 IiiiIiiI = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = IiIII1i1i )
 IiiiIiiI . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IiiiIiiI . setProperty ( 'fanart_image' , II )
 IiiiIiiI . setProperty ( 'IsPlayable' , 'true' )
 o00O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0OO0O , listitem = IiiiIiiI )
 return o00O
 if 64 - 64: O0 * OOooOOo / OOooOOo
def OO0oo ( name , url , mode , iconimage ) :
 O0OO0O = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 o00O = True
 IiiiIiiI = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 o00O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0OO0O , listitem = IiiiIiiI , isFolder = True )
 return o00O
 if 56 - 56: oO0o0ooO0 . iiIIIII1i1iI
def oOoOo00OOOOo ( ) :
 if 56 - 56: I1i1i1ii + OOooOOo - ii1II11I1ii1I / ii1II11I1ii1I . II111iiii - I1i1i1ii
 if 40 - 40: IIIII . iI1Ii11111iIi * O0
 if 6 - 6: OOooOOo - II111iiii . OOooOOo + oOo0oooo00o . O00o0o0000o0o
 Iii1iiIi1II = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 Iii1iiIi1II . doModal ( )
 if ( Iii1iiIi1II . isConfirmed ( ) ) :
  if 74 - 74: i1IIi
  oooIIiIiI1I = urllib . quote_plus ( Iii1iiIi1II . getText ( ) ) . replace ( '+' , ' ' )
  if 15 - 15: i1IIi + O00OoOoo00 % OOooOOo / i11iIiiIii * iI1Ii11111iIi
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 69 - 69: i11iIiiIii
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % oooIIiIiI1I )
    if 61 - 61: O0
    if i1iIi == 'true' :
     if 21 - 21: oO0ooO % iIii1I11I1II1 . oO0ooO
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + Oo0 + "[/COLOR] ,10000)" )
     if 99 - 99: ii1II11I1ii1I * O00o0o0000o0o % iiIIIII1i1iI * iiIIIII1i1iI + OoooooooOO
   except :
    if 82 - 82: oOo0oooo00o / iI1Ii11111iIi - O00o0o0000o0o / oooOOOOO
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 50 - 50: O00o0o0000o0o + oO0ooO . i11iIiiIii + oO0o0ooO0 + i11iIiiIii
o000i11ii1 = OOOOO000oo0 ( )
oo0O0o00o0O = None
Oo0 = None
IIi11I1i1I1I = None
IiIII1i1i = None
id = None
I11i1II = None
if 35 - 35: O0 + ii11ii1ii - OOooOOo % I1i1i1ii % II111iiii
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 77 - 77: iiiI11 + iiIIIII1i1iI
try :
 oo0O0o00o0O = urllib . unquote_plus ( o000i11ii1 [ "url" ] )
except :
 pass
try :
 Oo0 = urllib . unquote_plus ( o000i11ii1 [ "name" ] )
except :
 pass
try :
 IIi11I1i1I1I = int ( o000i11ii1 [ "mode" ] )
except :
 pass
try :
 IiIII1i1i = urllib . unquote_plus ( o000i11ii1 [ "iconimage" ] )
except :
 pass
try :
 id = int ( o000i11ii1 [ "id" ] )
except :
 pass
try :
 I11i1II = urllib . unquote_plus ( o000i11ii1 [ "trailer" ] )
except :
 pass
 if 38 - 38: oO0o0ooO0 - I1i1i1ii * ii1II11I1ii1I
 if 13 - 13: OOooOOo * iiIIIII1i1iI
print "Mode: " + str ( IIi11I1i1I1I )
print "URL: " + str ( oo0O0o00o0O )
print "Name: " + str ( Oo0 )
print "iconimage: " + str ( IiIII1i1i )
print "id: " + str ( id )
print "trailer: " + str ( I11i1II )
if 41 - 41: O00OoOoo00
if IIi11I1i1I1I == None or oo0O0o00o0O == None or len ( oo0O0o00o0O ) < 1 :
 if OOoO00 == IiI111111IIII :
  if 16 - 16: iIii1I11I1II1
  if 94 - 94: oooOOOOO % oOo0oooo00o % i1IIi
  iIi1Ii1i1iI ( )
  if 90 - 90: I1i1i1ii * oO0ooO
  o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
  oo00 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  o00 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  Oo0oO0ooo = IiII1IiiIiI1 . getSetting ( 'key_ext' )
  o0oOoO00o = i1 ( o00 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for i11 in oOOoo00O0O :
   try :
    if 7 - 7: IIIII . I1i1i1ii . IIIII - iiiI11
    if 33 - 33: oooOOOOO + OoooooooOO - oO0ooO / i1IIi / OoooooooOO
    o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
    if 82 - 82: oO0o0ooO0 / O00o0o0000o0o - IIIII / ii11ii1ii * oO0ooO
    if 55 - 55: OoooooooOO
    if o0oO0 == i11 :
     if 73 - 73: iI1Ii11111iIi - oO0o0ooO0 % ii11ii1ii + oO0o0ooO0 - O0 . oO0ooO
     Iii1I111 ( )
     if 38 - 38: O0
    else :
     if 79 - 79: i1IIi . iiIIIII1i1iI
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Estamos de Mantenimiento, Disculpen las molestias. Volveremos pronto! [/COLOR] [COLOR gold]>El addon esta desactivado temporalmente.[/COLOR]" )
     if 34 - 34: iiiI11 * II111iiii
     if 71 - 71: O00OoOoo00
   except :
    pass
    if 97 - 97: oO0o0ooO0
 else :
  xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red][B]Error, de inicio. ¿Tienes Instalado Realstream?[/B][/COLOR]" )
  if 86 - 86: ii11ii1ii - O00o0o0000o0o . iI1Ii11111iIi . II111iiii * OOooOOo . II111iiii
  if 34 - 34: ii1II11I1ii1I . iiiI11 % O00OoOoo00 - O0 / iiiI11
  if 91 - 91: i11iIiiIii % iiiI11 * iiIIIII1i1iI - oO0o0ooO0 . iiiI11
elif IIi11I1i1I1I == 1 :
 iIIi11i ( Oo0 , oo0O0o00o0O , id , I11i1II )
elif IIi11I1i1I1I == 2 :
 O0OO ( )
elif IIi11I1i1I1I == 3 :
 IIi11i1II ( )
elif IIi11I1i1I1I == 4 :
 OO0oo00oOO ( Oo0 , oo0O0o00o0O )
elif IIi11I1i1I1I == 5 :
 OO0o0OO0 ( )
elif IIi11I1i1I1I == 6 :
 ooOo0O0O0oOO0 ( )
elif IIi11I1i1I1I == 7 :
 Ii1iIi111I1i ( )
elif IIi11I1i1I1I == 8 :
 O000O ( )
elif IIi11I1i1I1I == 9 :
 o0o0O0Oo ( )
elif IIi11I1i1I1I == 10 :
 o00OoO0oO00 ( )
elif IIi11I1i1I1I == 11 :
 oOIIIiI1ii1IIi ( )
elif IIi11I1i1I1I == 12 :
 OOoooOoO0Oo ( )
elif IIi11I1i1I1I == 13 :
 Oo00ooO0OoOo ( )
elif IIi11I1i1I1I == 14 :
 o0Ii1 ( )
elif IIi11I1i1I1I == 15 :
 oooO00Oo ( )
elif IIi11I1i1I1I == 16 :
 OOO0oOO0ooo0 ( )
elif IIi11I1i1I1I == 17 :
 ii1I ( )
elif IIi11I1i1I1I == 18 :
 o0OoOOo ( )
elif IIi11I1i1I1I == 19 :
 Oo00O0OO ( )
elif IIi11I1i1I1I == 20 :
 oo0O0o00 ( )
elif IIi11I1i1I1I == 21 :
 ooooO0 ( )
elif IIi11I1i1I1I == 22 :
 OOOOo000o00OO ( )
elif IIi11I1i1I1I == 23 :
 OooOo ( )
elif IIi11I1i1I1I == 24 :
 IIii1III ( )
elif IIi11I1i1I1I == 25 :
 iI111II1ii ( )
elif IIi11I1i1I1I == 26 :
 oOo ( )
elif IIi11I1i1I1I == 28 :
 Oo0OooO0 ( Oo0 , oo0O0o00o0O )
elif IIi11I1i1I1I == 29 :
 iIi1I1 ( )
elif IIi11I1i1I1I == 30 :
 I1I11ii ( )
elif IIi11I1i1I1I == 31 :
 prueba ( )
elif IIi11I1i1I1I == 98 :
 busqueda_global ( )
elif IIi11I1i1I1I == 97 :
 oOOoO0oO0oo0O ( )
elif IIi11I1i1I1I == 99 :
 iI11iiii1I ( )
elif IIi11I1i1I1I == 100 :
 menu_player ( Oo0 , oo0O0o00o0O )
elif IIi11I1i1I1I == 111 :
 oOOo0OOOo00O ( )
elif IIi11I1i1I1I == 115 :
 Ooo00O0 ( oo0O0o00o0O )
elif IIi11I1i1I1I == 116 :
 i1iII1II11I ( )
elif IIi11I1i1I1I == 117 :
 oOoOOo0oo0 ( )
elif IIi11I1i1I1I == 119 :
 o0oo0000OO ( )
elif IIi11I1i1I1I == 120 :
 O00oooo00o0O ( )
elif IIi11I1i1I1I == 121 :
 Ooo0O ( )
elif IIi11I1i1I1I == 125 :
 iII1I11 ( )
elif IIi11I1i1I1I == 112 :
 list_proxy ( )
elif IIi11I1i1I1I == 127 :
 oOoOo00OOOOo ( )
elif IIi11I1i1I1I == 128 :
 TESTLINKS ( )
elif IIi11I1i1I1I == 130 :
 ii111i1i ( Oo0 , oo0O0o00o0O )
elif IIi11I1i1I1I == 140 :
 oOO0 ( )
elif IIi11I1i1I1I == 141 :
 OOoooO00o0o ( )
elif IIi11I1i1I1I == 142 :
 Oo00OOo00O ( )
elif IIi11I1i1I1I == 143 :
 o000 ( Oo0 , oo0O0o00o0O )
elif IIi11I1i1I1I == 144 :
 Oo0OooO0 ( Oo0 , oo0O0o00o0O )
elif IIi11I1i1I1I == 145 :
 oo0OOo0O ( )
elif IIi11I1i1I1I == 150 :
 iIII1i1i ( )
elif IIi11I1i1I1I == 151 :
 oo0o0000Oo0 ( )
elif IIi11I1i1I1I == 152 :
 O0o ( )
 if 28 - 28: i11iIiiIii
xbmcplugin . endOfDirectory ( o0OoOoOO00 ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
