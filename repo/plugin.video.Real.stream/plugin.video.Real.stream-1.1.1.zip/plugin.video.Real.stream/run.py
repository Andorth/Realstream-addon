# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 1.0.8
#
############################################
# Dependencias 
# Script ExtendedInfo
# Script Urlresolver de TVAddons
# Script ResolveURL Por Jsergio.
#
############################################
#
# Agregar sinopsis a Peliculas y series.
# Supresion de Licencia
#
#
############################################
if 64 - 64: i11iIiiIii
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import urlresolver
import cookielib , base64
import requests
import plugintools
import config
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
IiII1IiiIiI1 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
o0OoOoOO00 = int ( sys . argv [ 1 ] )
I11i = 'gruponetai/'
O0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
Oo = O0O . getAddonInfo ( 'profile' )
I1ii11iIi11i = O0O . getAddonInfo ( 'path' )
I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
if 73 - 73: OOooOOo / ii11ii1ii
if 94 - 94: OoOO + OoOO0ooOOoo0O + o0000oOoOoO0o * o00O0oo
if I1IiI == 'true' :
 if 97 - 97: oO0o0ooO0 - IIII / O0oO - o0oO0
 oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.png' ) )
 o00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 Oo0oO0ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.png' ) )
 i1111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.png' ) )
 i11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'estrenos.png' ) )
 I11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.png' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.png' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.png' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.png' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.png' ) )
 oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.png' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.png' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.png' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.png' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.png' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.png' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.png' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'marvel.png' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.png' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.png' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.png' ) )
 II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.png' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.png' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.png' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.png' ) )
 OO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.png' ) )
 Ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.png' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.png' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.png' ) )
 O0OO00o0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.jpg' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.jpg' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
else :
 if 95 - 95: iiiIi1i1I % II11iII % OoOo
 if 18 - 18: iii11I111
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
 oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.jpg' ) )
 o00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 Oo0oO0ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.jpg' ) )
 i1111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.jpg' ) )
 i11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'encines.jpg' ) )
 I11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.jpg' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.jpg' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.jpg' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.jpg' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.jpg' ) )
 oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.jpg' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.jpg' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.jpg' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.jpg' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.jpg' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.jpg' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.jpg' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'superheroes.jpg' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.jpg' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.jpg' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.jpg' ) )
 II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.jpg' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.jpg' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.jpg' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.jpg' ) )
 OO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.jpg' ) )
 Ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.jpg' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.jpg' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.jpg' ) )
 O0OO00o0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.jpg' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.jpg' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.jpg' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favoritos.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
 if 63 - 63: OoOO * oO0o0ooO0 - iiiIi1i1I * O0
 if 17 - 17: o00O0oo % II111iiii
 if 13 - 13: OoOo % OoOO0ooOOoo0O - i11iIiiIii . OOooOOo + II111iiii
II111ii1II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'peliculas.png' ) )
OoOo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series.png' ) )
o0OOoo0OO0OOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ajustes.png' ) )
iI1iI1I1i1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'videoteca.png' ) )
iIi11Ii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
Ii11iII1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'resolver.png' ) )
Oo0O0O0ooO0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'test.png' ) )
IIIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'video-tutoriales.png' ) )
O0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'proxy.png' ) )
if 71 - 71: IIII + iii11I111 % i11iIiiIii + o00O0oo - II11iII
oO0OOoO0 = IiII1IiiIiI1 . getSetting ( 'mostrar_cat' )
I111Ii111 = IiII1IiiIiI1 . getSetting ( 'videos' )
i111IiI1I = IiII1IiiIiI1 . getSetting ( 'activar' )
O0iII = IiII1IiiIiI1 . getSetting ( 'favcopy' )
o0ooOooo000oOO = IiII1IiiIiI1 . getSetting ( 'anticopia' )
Oo0oOOo = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
OOO00O = IiII1IiiIiI1 . getSetting ( 'mostrar_bus' )
OOoOO0oo0ooO = IiII1IiiIiI1 . getSetting ( 'restante' )
O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'selecton' )
O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'aviso' )
i1Oo00 = IiII1IiiIiI1 . getSetting ( 'RealStream_Settings' )
i1i = IiII1IiiIiI1 . getSetting ( 'Resolver_Settings' )
OOoOO0oo0ooO = IiII1IiiIiI1 . getSetting ( 'restante' )
iiI111I1iIiI = IiII1IiiIiI1 . getSetting ( 'fav' )
IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
oooooOoo0ooo = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
I1I1IiI1 = 'bienvenida'
III1iII1I1ii = 'bienvenida'
copyright = IiII1IiiIiI1 . getSetting ( 'copyright' )
oOOo0 = 'cGx1Z2luLnZpZGVvLg==' . decode ( 'base64' ) + copyright
oo00O00oO = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
iIiIIIi = IiII1IiiIiI1 . getSetting ( 'Forceupdate' )
if iIiIIIi == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
ooo00OOOooO = 'LnR4dA==' . decode ( 'base64' )
if 67 - 67: O0oO * oO0o0ooO0 * o00O0oo + IIII / i1IIi
I1I111 = 'aHR0cDovL2JpdC5seS8yU1FOSnlP' . decode ( 'base64' )
Oo00oo0oO = oooooOoo0ooo + I1I1IiI1 + ooo00OOOooO
IIiIi1iI = 'http://www.youtube.com'
i1IiiiI1iI = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
i1iIi = 'http://bit.ly/2ImelUx'
ooOOoooooo = '.xsl.pt'
II1I = 'L21hc3Rlci8=' . decode ( 'base64' )
O0i1II1Iiii1I11 = i1IiiiI1iI + ooOOoooooo
IIIIiiIiI = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*'
o00oooO0Oo = 'tvg-logo=[\'"](.*?)[\'"]'
if 78 - 78: o0oO0 % OoOo + o00O0oo
OOooOoooOoOo = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.*)'
o0OOOO00O0Oo = '(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)'
ii = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
oOooOOOoOo = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
i1Iii1i1I = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
OOoO00 = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
IiI111111IIII = '#(.+?),(.+)\s*(.+)'
i1Ii = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
if 14 - 14: iiiIi1i1I
I1iI1iIi111i = 'source src=[\'"](.*?)[\'"]\s*title=[\'"](.*?)[\'"]'
iiIi1IIi1I = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
o0OoOO000ooO0 = '[\'"](.*?)[\'"]'
o0o0o0oO0oOO = r'066">\s*(.+)</f'
ii1Ii11I = '[\'"](.*?)[\'"]'
o00o0 = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
iiOOooooO0Oo = '[\'"](.*?)[\'"]'
OO = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( 'base64' )
iIiIIi1 = OO + I11i
I1IIII1i = '[\'"](.*?)[\'"]'
I1I11i = 'UmVhbHN0cmVhbQ==' . decode ( 'base64' )
Ii1I1I1i1Ii = 'video=[\'"](.*?)[\'"]'
i1Oo0oO00o = '0110nhu' . replace ( '0110nhu' , 'nhu' )
i11I1II1I11i = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( 'base64' ) + i1Oo0oO00o
OooOoOO0 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
iI1i11iII111 = '0110R0N' . replace ( '0110R0N' , 'R0N' )
Iii1IIII11I = 'aHR0cDovL2JpdC5seS8yWEIx' . decode ( 'base64' ) + iI1i11iII111
OOOoo0OO = '0110pEJ' . replace ( '0110pEJ' , 'pEJ' )
oO0o0 = 'aHR0cDovL2JpdC5seS8yd1Nh' . decode ( 'base64' ) + OOOoo0OO
iI1Ii11iIiI1 = 'ABBAOb5' . replace ( 'ABBAOb5' , 'Ob5' )
OO0Oooo0oOO0O = 'aHR0cDovL2JpdC5seS8yRVhV' . decode ( 'base64' ) + iI1Ii11iIiI1
o00O0 = '0110jaw' . replace ( '0110jaw' , 'jaw' )
oOO0O00Oo0O0o = 'aHR0cDovL2JpdC5seS8yd01M' . decode ( 'base64' ) + o00O0
ii1 = '01109DI' . replace ( '01109DI' , '9DI' )
I1iIIiiIIi1i = 'aHR0cDovL2JpdC5seS8ySXgz' . decode ( 'base64' ) + ii1
O0O0ooOOO = '01103hs' . replace ( '01103hs' , '3hs' )
oOOo0O00o = 'aHR0cDovL2JpdC5seS8zMW1U' . decode ( 'base64' ) + O0O0ooOOO
iIiIi11 = '01107DW' . replace ( '01107DW' , '7DW' )
OOO = 'aHR0cDovL2JpdC5seS8yV1ln' . decode ( 'base64' ) + iIiIi11
iiiiI = '0110mLl' . replace ( '0110mLl' , 'mLl' )
oooOo0OOOoo0 = 'aHR0cDovL2JpdC5seS8yS0cw' . decode ( 'base64' ) + iiiiI
OOoO = '01102Hj' . replace ( '01102Hj' , '2Hj' )
OO0O000 = 'aHR0cDovL2JpdC5seS8yWEJo' . decode ( 'base64' ) + OOoO
iiIiI1i1 = '0110fXg' . replace ( '0110fXg' , 'fXg' )
oO0O00oOOoooO = 'aHR0cDovL2JpdC5seS8ySTVy' . decode ( 'base64' ) + iiIiI1i1
IiIi11iI = '0110NMH' . replace ( '0110NMH' , 'NMH' )
Oo0O00O000 = 'aHR0cDovL2JpdC5seS8yd0t6' . decode ( 'base64' ) + IiIi11iI
i11I1IiII1i1i = '0110bwQ' . replace ( '0110bwQ' , 'bwQ' )
oo = 'aHR0cDovL2JpdC5seS8yd01V' . decode ( 'base64' ) + i11I1IiII1i1i
I1111i = '0110xzG' . replace ( '0110xzG' , 'xzG' )
iIIii = 'aHR0cDovL2JpdC5seS8yWHhz' . decode ( 'base64' ) + I1111i
o00O0O = '0110x64' . replace ( '0110x64' , 'x64' )
ii1iii1i = 'aHR0cDovL2JpdC5seS8yRVlF' . decode ( 'base64' ) + o00O0O
Iii1I1111ii = '0110vUE' . replace ( '0110vUE' , 'vUE' )
ooOoO00 = 'aHR0cDovL2JpdC5seS8yWmhW' . decode ( 'base64' ) + Iii1I1111ii
Ii1IIiI1i = '01107ZL' . replace ( '01107ZL' , '7ZL' )
o0O00Oo0 = 'aHR0cDovL2JpdC5seS8yWm4w' . decode ( 'base64' ) + Ii1IIiI1i
IiII111i1i11 = '01106cf' . replace ( '01106cf' , '6cf' )
i111iIi1i1II1 = 'aHR0cDovL2JpdC5seS8yRVlk' . decode ( 'base64' ) + IiII111i1i11
oooO = '0110Jtp' . replace ( '0110Jtp' , 'Jtp' )
i1I1i111Ii = 'aHR0cDovL2JpdC5seS8yV3Nq' . decode ( 'base64' ) + oooO
ooo = '0110a5b' . replace ( '0110a5b' , 'a5b' )
i1i1iI1iiiI = 'aHR0cDovL2JpdC5seS8yV3dj' . decode ( 'base64' ) + ooo
Ooo0oOooo0 = '0110Q7u' . replace ( '0110Q7u' , 'Q7u' )
oOOOoo00 = 'aHR0cDovL2JpdC5seS8yV3NL' . decode ( 'base64' ) + Ooo0oOooo0
iiIiIIIiiI = '0110rsq' . replace ( '0110rsq' , 'rsq' )
iiI1IIIi = 'aHR0cDovL2JpdC5seS8ySzhE' . decode ( 'base64' ) + iiIiIIIiiI
II11IiIi11 = '0110DDR' . replace ( '0110DDR' , 'DDR' )
IIOOO0O00O0OOOO = 'aHR0cDovL2JpdC5seS8ySzd5' . decode ( 'base64' ) + II11IiIi11
I1iiii1I = '0110feQ' . replace ( '0110feQ' , 'feQ' )
OOo0 = 'aHR0cDovL2JpdC5seS8yS0cz' . decode ( 'base64' ) + I1iiii1I
oO00ooooO0o = '0110MHY' . replace ( '0110MHY' , 'MHY' )
oo0o = 'aHR0cDovL2JpdC5seS8ySXVo' . decode ( 'base64' ) + oO00ooooO0o
o0oO0oooOoo = '0110xdb' . replace ( '0110xdb' , 'xdb' )
I1III1111iIi = 'aHR0cDovL2JpdC5seS8yWEJu' . decode ( 'base64' ) + o0oO0oooOoo
I1i111I = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( 'base64' )
OooOo0oo0O0o00O = 'aHR0cHM6Ly9uZXRhaS5ldS92aXNpdGFzL2luZGV4LnBocA==' . decode ( 'base64' )
oOOo0 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
I1i11 = '0110lxu' . replace ( '0110lxu' , 'lxu' )
IiIi1I1 = 'aHR0cDovL2JpdC5seS8yV1Bj' . decode ( 'base64' ) + I1i11
IiIIi1 = '0110pzp' . replace ( '0110pzp' , 'pzp' )
IIIIiii1IIii = 'aHR0cDovL2JpdC5seS8yVHpB' . decode ( 'base64' ) + IiIIi1
II1i11I = '01105yt' . replace ( '01105yt' , '5yt' )
ii1I1IIii11 = 'aHR0cDovL2JpdC5seS8yTVpp' . decode ( 'base64' ) + II1i11I
if 67 - 67: iiiIi1i1I + O0oO / o0000oOoOoO0o . oO0o0ooO0 + IIII
if 62 - 62: i11iIiiIii + i11iIiiIii - o0000oOoOoO0o
I1 = '1001DTs' . replace ( '1001DTs' , 'DTs' )
OooooO0oOOOO = 'aHR0cDovL2JpdC5seS8ySzhP' . decode ( 'base64' ) + I1
o0O00oOOoo = '1001Hky' . replace ( '1001Hky' , 'Hky' )
i1I1iIi = 'aHR0cDovL2JpdC5seS8yTGVL' . decode ( 'base64' ) + o0O00oOOoo
IIii11Ii1i1I = '1001VFU' . replace ( '1001VFU' , 'VFU' )
Oooo0O = 'aHR0cDovL2JpdC5seS8zMERx' . decode ( 'base64' ) + IIii11Ii1i1I
oo00O0oO0O0 = '3545OMZ' . replace ( '3545OMZ' , 'OMZ' )
ooo0OO0O0Oo = 'aHR0cDovL2JpdC5seS8yazhk' . decode ( 'base64' ) + oo00O0oO0O0
if 62 - 62: O0 % O0oO . O0oO - iIii1I11I1II1 / i11iIiiIii
def iiiII ( ) :
 if 41 - 41: ii11ii1ii
 if 10 - 10: ii11ii1ii / ii11ii1ii / OoOo . OoOo
 try :
  if 98 - 98: ii11ii1ii / OOooOOo . O0 + OoOO
  if 43 - 43: II111iiii . oO0o0ooO0 / o00O0oo
  i1iI1 = i11ii1ii11i ( Iii1IIII11I )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   try :
    if 80 - 80: oO0o0ooO0 + IIII / O0oO
    oO0o0 = O0O0Oo00
    if 79 - 79: iii11I111
    i11I1I1I = xbmc . Keyboard ( '' , 'Busqueda por titulo' )
    i11I1I1I . doModal ( )
    if ( i11I1I1I . isConfirmed ( ) ) :
     if 64 - 64: o0oO0
     oo00O00Oo = urllib . quote_plus ( i11I1I1I . getText ( ) ) . replace ( '+' , ' ' )
     IIIII1II = i11ii1ii11i ( oO0o0 )
     ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( IIIII1II )
     for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
      if re . search ( oo00O00Oo , Iii1iiIi1II ( IiI . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
       if 14 - 14: OOooOOo
    IIiIiI1I ( '[COLOR %s]Buscar Pelicula[/COLOR]' % O0ii1ii1ii , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
   except : IIiIiI1I ( '[COLOR %s]Buscar Pelicula[/COLOR]' % O0ii1ii1ii , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
   if 100 - 100: iIii1I11I1II1 + OoOO0ooOOoo0O / ii11ii1ii . i11iIiiIii
   if 14 - 14: o0000oOoOoO0o * IIII + iiiIi1i1I + O0 + i11iIiiIii
 except :
  pass
  if 77 - 77: o0000oOoOoO0o / OoooooooOO
  if 46 - 46: o0000oOoOoO0o % iIii1I11I1II1 . iiiIi1i1I % iiiIi1i1I + i11iIiiIii
  if 72 - 72: iIii1I11I1II1 * o0oO0 % iii11I111 / OoOO
def I11i1II ( ) :
 if 72 - 72: iIii1I11I1II1 . i1IIi / ii11ii1ii . II111iiii
 O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'aviso' )
 if O00O0oOO00O00 == 'true' :
  i1iI1 = i11ii1ii11i ( Oo00oo0oO )
  ooO0OoOO = re . compile ( IIIIiiIiI ) . findall ( i1iI1 )
  for ooo000o000 , O0o in ooO0OoOO :
   try :
    if 72 - 72: IIII % o00O0oo + OoOO / oO0o0ooO0 + II11iII
    if 10 - 10: OoOo / iii11I111 + i11iIiiIii / o0oO0
    OOOoOoO = ooo000o000
    iIIIII1ii1I = O0o
    if 13 - 13: i11iIiiIii + i1IIi * iIii1I11I1II1 % OoooooooOO - II111iiii * IIII
    if 26 - 26: OoooooooOO * OOooOOo + IIII
    from datetime import datetime
    if 24 - 24: i11iIiiIii % iIii1I11I1II1 + IIII / i11iIiiIii
    OOooO0oo0o00o = datetime . now ( )
    ooOO0OoO = OOooO0oo0o00o . strftime ( '%d/%m/%Y' )
    if 69 - 69: iIii1I11I1II1 . o00O0oo % iii11I111 + iIii1I11I1II1 / O0 / o00O0oo
    O00OoOO0oo0 = i11ii1ii11i ( OooOo0oo0O0o00O )
    ooO0OoOO = re . compile ( o0o0o0oO0oOO ) . findall ( O00OoOO0oo0 )
    for oOO in ooO0OoOO :
     if 53 - 53: OoOo * II11iII . ii11ii1ii - o0oO0 % o0oO0 * i11iIiiIii
     iiOOO0oOOoo = "[B]" + OOOoOoO + "[/B]"
     oOOO00o000o = "" + iIIIII1ii1I + ""
     iIi11i1 = "[COLOR white]Hoy: " + ooOO0OoO + ", Es usted el visitante numero: [B][COLOR gold]" + oOO + "[/B][/COLOR]"
     if 71 - 71: iii11I111
     xbmcgui . Dialog ( ) . ok ( "Real Stream" , iiOOO0oOOoo , oOOO00o000o , iIi11i1 )
     if 53 - 53: OoooooooOO % o0oO0 . II11iII / i11iIiiIii % iiiIi1i1I
   except :
    pass
    if 28 - 28: O0oO
    if 58 - 58: OoOO0ooOOoo0O
  IIIII1II = i11ii1ii11i ( I1i111I )
  ooO0OoOO = re . compile ( o0OoOO000ooO0 ) . findall ( IIIII1II )
  for iIiiI1iI in ooO0OoOO :
   try :
    if 5 - 5: OoOO0ooOOoo0O / OoooooooOO + II11iII * OoOo - OoOO % OOooOOo
    import xbmc
    import xbmcaddon
    if 42 - 42: O0 / o0000oOoOoO0o + OoooooooOO * iii11I111 % iii11I111
    __addon__ = xbmcaddon . Addon ( )
    __addonname__ = __addon__ . getAddonInfo ( 'name' )
    __icon__ = __addon__ . getAddonInfo ( 'icon' )
    if 7 - 7: iiiIi1i1I / o00O0oo / i11iIiiIii
    iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
    IIIIIo0ooOoO000oO = iIiiI1iI
    if 85 - 85: o0000oOoOoO0o . OoOO0ooOOoo0O / iii11I111 . O0 % OoOo
    iiOOO0oOOoo = "[COLOR orange]Version instalada: [COLOR gold] " + iIiiiI1IiI1I1 + " [/COLOR][/COLOR] Disponible: " + iIiiI1iI + ""
    OO0ooo0oOO = 4000
    if 97 - 97: OOooOOo / iiiIi1i1I
    xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , iiOOO0oOOoo , OO0ooo0oOO , __icon__ ) )
    if 71 - 71: II111iiii / i1IIi . o00O0oo % OoooooooOO . OoOO0ooOOoo0O
   except :
    pass
    if 41 - 41: i1IIi * II111iiii / OoooooooOO . IIII
 if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
 return
 if 83 - 83: iiiIi1i1I . O0 / ii11ii1ii / IIII - II111iiii
def Iii1iiIi1II ( s ) :
 if 100 - 100: OoOO
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 46 - 46: OoOO0ooOOoo0O / iIii1I11I1II1 % iiiIi1i1I . iIii1I11I1II1 * iiiIi1i1I
def IIi1ii1Ii ( file ) :
 if 91 - 91: i11iIiiIii / OoooooooOO + iiiIi1i1I - i11iIiiIii + IIII
 try :
  ii1i = open ( file , 'r' )
  i1iI1 = ii1i . read ( )
  ii1i . close ( )
  return i1iI1
 except :
  pass
  if 62 - 62: OoOO / o00O0oo
def i11ii1ii11i ( url ) :
 if 7 - 7: OoooooooOO . II11iII
 try :
  O000OOO0OOo = urllib2 . Request ( url )
  O000OOO0OOo . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  i1i1I111iIi1 = urllib2 . urlopen ( O000OOO0OOo )
  oo00O00oO000o = i1i1I111iIi1 . read ( )
  i1i1I111iIi1 . close ( )
  return oo00O00oO000o
 except urllib2 . URLError , OOo00OoO :
  print 'We failed to open "%s".' % url
  if hasattr ( OOo00OoO , 'code' ) :
   print 'We failed with error code - %s.' % OOo00OoO . code
  if hasattr ( OOo00OoO , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , OOo00OoO . reason
   if 10 - 10: o0000oOoOoO0o / i11iIiiIii
def o00oO ( url ) :
 O000OOO0OOo = urllib2 . Request ( url )
 O000OOO0OOo . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 O000OOO0OOo . add_header ( 'Referer' , '%s' % url )
 O000OOO0OOo . add_header ( 'Connection' , 'keep-alive' )
 i1i1I111iIi1 = urllib2 . urlopen ( O000OOO0OOo )
 oo00O00oO000o = i1i1I111iIi1 . read ( )
 i1i1I111iIi1 . close ( )
 return oo00O00oO000o
 if 92 - 92: II11iII * ii11ii1ii * ii11ii1ii * OOooOOo . iIii1I11I1II1
 if 16 - 16: iii11I111 % OoooooooOO - IIII * o0oO0 * o00O0oo / OoooooooOO
def I11o0oO00oO0o0o0 ( ) :
 if 17 - 17: O0oO . II11iII - II111iiii + O0 / iIii1I11I1II1 / i11iIiiIii
 O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 if 39 - 39: II11iII * ii11ii1ii + iIii1I11I1II1 - II11iII + IIII
 if i111IiI1I == 'true' :
  if 69 - 69: O0
  IIiIiI1I ( '[COLOR %s]Buscar Pelicula[/COLOR]' % O0ii1ii1ii , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
  IIiIiI1I ( '[COLOR %s]Buscar Serie[/COLOR]' % O0ii1ii1ii , 'search' , 145 , I1IIIii , oo00 )
  IIiIiI1I ( '[COLOR %s]Peliculas[/COLOR] ' % O0ii1ii1ii , 'movieDB' , 116 , II111ii1II1i , oo00 )
  IIiIiI1I ( '[COLOR %s]Series[/COLOR] ' % O0ii1ii1ii , 'movieDB' , 117 , OoOo00o , oo00 )
  if 85 - 85: iii11I111 / O0
  if 18 - 18: o0000oOoOoO0o % O0 * o00O0oo
 if i1Oo00 == 'true' :
  IIiIiI1I ( '[COLOR %s]Ajustes[/COLOR]' % O0ii1ii1ii , 'Settings' , 119 , o0OOoo0OO0OOO , oo00 )
  if 62 - 62: OoOo . II11iII . OoooooooOO
  if 11 - 11: IIII / O0oO
  if oO0OOoO0 == 'true' :
   oooO0 ( )
   if 16 - 16: II111iiii + oO0o0ooO0 - OoooooooOO
  if i1i == 'true' :
   ii1iI ( )
   IIi ( )
   if 89 - 89: II111iiii + i1IIi + II111iiii
  if o0ooOooo000oOO == 'false' :
   if 7 - 7: O0 % o0000oOoOoO0o + o00O0oo * iiiIi1i1I - iiiIi1i1I
   iiOOO0oOOoo = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   oOOO00o000o = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Script.ResolveURL para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   iIi11i1 = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 42 - 42: OoOO0ooOOoo0O * OoOO0ooOOoo0O * OoOo . O0oO
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , iiOOO0oOOoo , oOOO00o000o , iIi11i1 )
   if 51 - 51: IIII % iIii1I11I1II1 - OoooooooOO % iii11I111 * iIii1I11I1II1 % OoOO
def oO0o00oOOooO0 ( ) :
 IIiIiI1I ( '[COLOR orange]Buscador por id[/COLOR]' , IIiIi1iI , 127 , oOOoo00O0O , oo00 )
 if 79 - 79: OoOO - iIii1I11I1II1 + o0oO0 - OoOo
def OoO ( ) :
 O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 IIiIiI1I ( '[COLOR %s]The movie DB[/COLOR]' % O0ii1ii1ii , 'movieDB' , 99 , oOOoo00O0O , oo00 )
 if 35 - 35: OoOO0ooOOoo0O + i11iIiiIii - II111iiii
 IIiIiI1I ( '[COLOR %s]Video tutoriales[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 125 , IIIIii , oo00 )
 if 15 - 15: i11iIiiIii % OOooOOo * O0oO / OoOo
 if 90 - 90: iiiIi1i1I
def i1i1i1I ( ) :
 if 83 - 83: oO0o0ooO0 + OoooooooOO
 I11o0oO00oO0o0o0 ( )
 OoO ( )
 if 22 - 22: o0oO0 % iiiIi1i1I * OoooooooOO - o0000oOoOoO0o / iIii1I11I1II1
def OoOO00 ( ) :
 if 28 - 28: oO0o0ooO0 - i11iIiiIii . o00O0oo + II11iII / o00O0oo
 i1i1i1I ( )
 if 35 - 35: II11iII
def OOoO0 ( ) :
 if xbmc . getCondVisibility ( 'System.HasAddon(script.favourites)' ) :
  try :
   xbmc . executebuiltin ( "RunScript(script.favourites)" )
  except :
   pass
def OoOo00o0OO ( ) :
 IiII1IiiIiI1 . openSettings ( )
 if 1 - 1: OOooOOo % iii11I111
 if 65 - 65: OOooOOo + OoOO0ooOOoo0O / IIII
def oOOoOooo0O0o ( ) :
 urlresolver . display_settings ( )
 if 72 - 72: iIii1I11I1II1 / II11iII % iiiIi1i1I % IIII - O0oO % IIII
def ii1iI ( ) :
 IIiIiI1I ( '[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % O0ii1ii1ii , 'resolve' , 120 , Ii11iII1 , oo00 )
 if 100 - 100: ii11ii1ii + i11iIiiIii
def O0oOOO000oooo0 ( ) :
 if 77 - 77: OOooOOo % O0
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 36 - 36: o0oO0 / II111iiii / II11iII / II11iII + o00O0oo
def IIi ( ) :
 IIiIiI1I ( '[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % O0ii1ii1ii , 'resolve' , 140 , Ii11iII1 , oo00 )
 if 95 - 95: II11iII
def oooO0 ( ) :
 if 51 - 51: II111iiii + II11iII . i1IIi . o00O0oo + OoOO0ooOOoo0O * OOooOOo
 O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 IIiIiI1I ( '[COLOR %s]Buscador[/COLOR]' % O0ii1ii1ii , 'search' , 111 , o0oOoO00o , oo00 )
 IIiIiI1I ( '[COLOR %s]Estrenos[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 3 , i11 , oo00 )
 IIiIiI1I ( '[COLOR %s]Todas[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 26 , I11 , oo00 )
 IIiIiI1I ( '[COLOR %s]4K[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 141 , O0o0Oo , oo00 )
 IIiIiI1I ( '[COLOR %s]Novedades[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 2 , i1111 , oo00 )
 IIiIiI1I ( '[COLOR %s]Accion[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 5 , Oo0o0000o0o0 , oo00 )
 IIiIiI1I ( '[COLOR %s]Animacion[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 6 , oOo0oooo00o , oo00 )
 IIiIiI1I ( '[COLOR %s]Artes Marciales[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 29 , o0 , oo00 )
 IIiIiI1I ( '[COLOR %s]Aventuras[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 7 , oO0o0o0ooO0oO , oo00 )
 IIiIiI1I ( '[COLOR %s]Belico[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 8 , oo0o0O00 , oo00 )
 IIiIiI1I ( '[COLOR %s]Ciencia Ficcion[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 9 , oO , oo00 )
 IIiIiI1I ( '[COLOR %s]Cine Clasico[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 30 , i1iiIIiiI111 , oo00 )
 IIiIiI1I ( '[COLOR %s]Comedia[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 10 , oooOOOOO , oo00 )
 IIiIiI1I ( '[COLOR %s]Crimen[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 11 , i1iiIII111ii , oo00 )
 IIiIiI1I ( '[COLOR %s]Drama[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 12 , i1iIIi1 , oo00 )
 IIiIiI1I ( '[COLOR %s]Familiar[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 13 , ii11iIi1I , oo00 )
 IIiIiI1I ( '[COLOR %s]Fantasia[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 14 , iI111I11I1I1 , oo00 )
 IIiIiI1I ( '[COLOR %s]Historia[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 15 , OOooO0OOoo , oo00 )
 IIiIiI1I ( '[COLOR %s]Misterio[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 16 , oOOoO0 , oo00 )
 IIiIiI1I ( '[COLOR %s]Musical[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 17 , O0OoO000O0OO , oo00 )
 IIiIiI1I ( '[COLOR %s]Romance[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 18 , iiI1IiI , oo00 )
 IIiIiI1I ( '[COLOR %s]Thriller[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 19 , II11iiii1Ii , oo00 )
 IIiIiI1I ( '[COLOR %s]Suspense[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 20 , ooOoOoo0O , oo00 )
 IIiIiI1I ( '[COLOR %s]Terror[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 21 , OooO0 , oo00 )
 IIiIiI1I ( '[COLOR %s]Western[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 22 , OO0o , oo00 )
 IIiIiI1I ( '[COLOR %s]Spain[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 23 , II , oo00 )
 IIiIiI1I ( '[COLOR %s]Super heroes[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 24 , iIii1 , oo00 )
 IIiIiI1I ( '[COLOR %s]Sagas[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 25 , Ooo , oo00 )
 if 72 - 72: oO0o0ooO0 + oO0o0ooO0 / II111iiii . OoooooooOO % o0oO0
def III ( ) :
 if 41 - 41: i11iIiiIii + ii11ii1ii / OOooOOo . OoooooooOO % oO0o0ooO0 % i1IIi
 IIiIiI1I ( '[COLOR %s]Buscar Serie[/COLOR]' % O0ii1ii1ii , 'search' , 145 , O0OO00o0OO , oo00 )
 IIiIiI1I ( '[COLOR %s]En emision[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 150 , I11II1i , oo00 )
 IIiIiI1I ( '[COLOR %s]Mejor valoradas[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 151 , IIIII , oo00 )
 IIiIiI1I ( '[COLOR %s]Series Retro[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 152 , ooooooO0oo , oo00 )
 IIiIiI1I ( '[COLOR %s]Todas[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 142 , I11i1 , oo00 )
 if 70 - 70: ii11ii1ii . OoooooooOO - iiiIi1i1I
def iII11I1Ii1 ( ) :
 if 92 - 92: O0oO / O0oO . o00O0oo
 if 17 - 17: i11iIiiIii - II111iiii * o0000oOoOoO0o
 try :
  if 5 - 5: IIII - IIII . ii11ii1ii + OoOO0ooOOoo0O - IIII . oO0o0ooO0
  IiIi1i1ii = i11ii1ii11i ( OooooO0oOOOO )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( IiIi1i1ii )
  for O0O0Oo00 in ooO0OoOO :
   if 11 - 11: II111iiii / o0000oOoOoO0o
   try :
    if 21 - 21: i11iIiiIii / i1IIi + OOooOOo * IIII . OoOo
    OoOoo0oO = O0O0Oo00
    i11I1I1I = xbmc . Keyboard ( '' , 'Buscar' )
    i11I1I1I . doModal ( )
    if ( i11I1I1I . isConfirmed ( ) ) :
     iioo0o0OoOOO = xbmcgui . DialogProgress ( )
     iioo0o0OoOOO . create ( 'Realstream:' , 'Buscando ...' )
     iioo0o0OoOOO . update ( 10 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     iioo0o0OoOOO . update ( 15 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     iioo0o0OoOOO . update ( 20 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     iioo0o0OoOOO . update ( 25 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     iioo0o0OoOOO . update ( 35 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     iioo0o0OoOOO . update ( 45 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     iioo0o0OoOOO . update ( 55 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     iioo0o0OoOOO . update ( 65 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     iioo0o0OoOOO . update ( 80 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     iioo0o0OoOOO . update ( 90 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     iioo0o0OoOOO . update ( 100 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 100 )
     iioo0o0OoOOO . close ( )
     oo00O00Oo = urllib . quote_plus ( i11I1I1I . getText ( ) ) . replace ( '+' , ' ' )
     IIIII1II = i11ii1ii11i ( OoOoo0oO )
     ooO0OoOO = re . compile ( ii ) . findall ( IIIII1II )
     for ooO0oO00O0o , IiI , oo00 , iI1ii1i , IiIiII1 in ooO0OoOO :
      if re . search ( oo00O00Oo , Iii1iiIi1II ( IiI . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       IIiIiI1I ( '[COLOR %s]Buscar Serie[/COLOR]' % O0ii1ii1ii , 'search' , 145 , O0OO00o0OO , oo00 )
       ooOO00oOOo000 ( IiI , iI1ii1i , 143 , ooO0oO00O0o , oo00 , IiIiII1 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Resultados para: [COLOR orange]" + oo00O00Oo + "[/COLOR] ,3000)" )
       if 14 - 14: OoOO . II111iiii . O0oO / o0oO0 % o00O0oo - iii11I111
       if 67 - 67: O0oO - IIII . i1IIi
   except : IIiIiI1I ( '[COLOR %s]Buscar Serie[/COLOR]' % O0ii1ii1ii , 'search' , 145 , O0OO00o0OO , oo00 )
   if 35 - 35: iiiIi1i1I + iii11I111 - oO0o0ooO0 . iiiIi1i1I . II11iII
 except :
  pass
def oo0ooOO ( ) :
 if 24 - 24: OoOO % OoOO * iIii1I11I1II1
 try :
  if 50 - 50: OoOO . i11iIiiIii - oO0o0ooO0 . oO0o0ooO0
  IiIi1i1ii = i11ii1ii11i ( ooo0OO0O0Oo )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( IiIi1i1ii )
  for O0O0Oo00 in ooO0OoOO :
   if 31 - 31: IIII / ii11ii1ii * i1IIi . OoOO0ooOOoo0O
   try :
    if 57 - 57: IIII + iIii1I11I1II1 % i1IIi % OOooOOo
    OoOoo0oO = O0O0Oo00
    if 83 - 83: o0000oOoOoO0o / i11iIiiIii % iIii1I11I1II1 . O0oO % oO0o0ooO0 . OoooooooOO
   except :
    pass
    if 94 - 94: o0oO0 + iIii1I11I1II1 % OoOO
  IIIII1II = i11ii1ii11i ( OoOoo0oO )
  ooO0OoOO = re . compile ( ii ) . findall ( IIIII1II )
  for ooO0oO00O0o , IiI , oo00 , iI1ii1i , IiIiII1 in ooO0OoOO :
   try :
    if 93 - 93: o0oO0 - IIII + iIii1I11I1II1 * o0000oOoOoO0o + OoOo . iiiIi1i1I
    ooOO00oOOo000 ( IiI , iI1ii1i , 143 , ooO0oO00O0o , oo00 , IiIiII1 )
    if 49 - 49: OoooooooOO * O0oO - ii11ii1ii . oO0o0ooO0
   except :
    pass
 except :
  pass
  if 89 - 89: iii11I111 + o0oO0 * iii11I111 / iii11I111
  if 46 - 46: OoOO
def O0000 ( ) :
 if 64 - 64: II111iiii - OOooOOo
 try :
  if 68 - 68: iii11I111 - IIII - iIii1I11I1II1 / OoOO0ooOOoo0O + IIII - OoOO
  IiIi1i1ii = i11ii1ii11i ( Oooo0O )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( IiIi1i1ii )
  for O0O0Oo00 in ooO0OoOO :
   if 75 - 75: iiiIi1i1I / o0000oOoOoO0o % iIii1I11I1II1 . OoooooooOO % OoooooooOO % II111iiii
   try :
    if 26 - 26: II111iiii % i11iIiiIii % iIii1I11I1II1 % O0oO * O0oO * o00O0oo
    OoOoo0oO = O0O0Oo00
    if 24 - 24: II111iiii % OoOo - iii11I111 + OOooOOo * o00O0oo
   except :
    pass
    if 2 - 2: o0oO0 - II11iII
  IIIII1II = i11ii1ii11i ( OoOoo0oO )
  ooO0OoOO = re . compile ( ii ) . findall ( IIIII1II )
  for ooO0oO00O0o , IiI , oo00 , iI1ii1i , IiIiII1 in ooO0OoOO :
   try :
    if 83 - 83: oO0o0ooO0 % o0000oOoOoO0o % o0oO0 - II111iiii * IIII / OoooooooOO
    ooOO00oOOo000 ( IiI , iI1ii1i , 143 , ooO0oO00O0o , oo00 , IiIiII1 )
    if 18 - 18: OoOO + iIii1I11I1II1 - II111iiii - OOooOOo
   except :
    pass
 except :
  pass
  if 71 - 71: OoooooooOO
def iIIIII1iiiiII ( ) :
 if 54 - 54: i1IIi
 try :
  if 22 - 22: i1IIi + o0oO0
  IiIi1i1ii = i11ii1ii11i ( i1I1iIi )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( IiIi1i1ii )
  for O0O0Oo00 in ooO0OoOO :
   if 54 - 54: iii11I111 % IIII . OoOo + oO0o0ooO0 - IIII * OOooOOo
   try :
    if 92 - 92: o0000oOoOoO0o + OoOo / ii11ii1ii % OoOO % II11iII . OoooooooOO
    OoOoo0oO = O0O0Oo00
    if 52 - 52: iii11I111 / i11iIiiIii - IIII . II11iII % iIii1I11I1II1 + o0000oOoOoO0o
   except :
    pass
    if 71 - 71: oO0o0ooO0 % O0oO * OoOO0ooOOoo0O . O0 / o0oO0 . o00O0oo
  IIIII1II = i11ii1ii11i ( OoOoo0oO )
  ooO0OoOO = re . compile ( ii ) . findall ( IIIII1II )
  for ooO0oO00O0o , IiI , oo00 , iI1ii1i , IiIiII1 in ooO0OoOO :
   try :
    if 58 - 58: ii11ii1ii / oO0o0ooO0
    ooOO00oOOo000 ( IiI , iI1ii1i , 143 , ooO0oO00O0o , oo00 , IiIiII1 )
    if 44 - 44: IIII
   except :
    pass
 except :
  pass
  if 54 - 54: o0oO0 - O0oO - OoOo . iIii1I11I1II1
def o0O ( ) :
 if 40 - 40: o0000oOoOoO0o + ii11ii1ii . o0000oOoOoO0o % iii11I111
 try :
  if 15 - 15: o0oO0 * ii11ii1ii % o00O0oo * iIii1I11I1II1 - i11iIiiIii
  IiIi1i1ii = i11ii1ii11i ( OooooO0oOOOO )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( IiIi1i1ii )
  for O0O0Oo00 in ooO0OoOO :
   if 60 - 60: OOooOOo * OoOo % OoOO + oO0o0ooO0
   try :
    if 52 - 52: i1IIi
    OoOoo0oO = O0O0Oo00
    if 84 - 84: o0oO0 / II11iII
   except :
    pass
    if 86 - 86: OoOO0ooOOoo0O * II111iiii - O0 . OoOO0ooOOoo0O % iIii1I11I1II1 / IIII
  IIIII1II = i11ii1ii11i ( OoOoo0oO )
  ooO0OoOO = re . compile ( ii ) . findall ( IIIII1II )
  for ooO0oO00O0o , IiI , oo00 , iI1ii1i , IiIiII1 in ooO0OoOO :
   try :
    if 11 - 11: OOooOOo * oO0o0ooO0 + o00O0oo / o00O0oo
    ooOO00oOOo000 ( IiI , iI1ii1i , 143 , ooO0oO00O0o , oo00 , IiIiII1 )
    if 37 - 37: i11iIiiIii + i1IIi
   except :
    pass
 except :
  pass
  if 23 - 23: iiiIi1i1I + O0oO . OoOO0ooOOoo0O * OOooOOo + o00O0oo
def I1iIi1iiiIiI ( name , url ) :
 if 41 - 41: o00O0oo * iii11I111 - o0oO0 + ii11ii1ii
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 23 - 23: II111iiii % o0000oOoOoO0o + o0000oOoOoO0o + iiiIi1i1I - iiiIi1i1I
 oOo0O00O = i11ii1ii11i ( url )
 ooO0OoOO = re . compile ( i1Iii1i1I ) . findall ( oOo0O00O )
 for ooO0oO00O0o , name , oo00 , url in ooO0OoOO :
  try :
   if 36 - 36: O0 + ii11ii1ii
   if 5 - 5: ii11ii1ii * OoOO0ooOOoo0O
   IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % IIIi1I1IIii1II + name + '[/COLOR]'
   ii1I11iIiIII1 ( name , url , 144 , ooO0oO00O0o , oo00 )
   if 52 - 52: o0000oOoOoO0o * II11iII + OoOO0ooOOoo0O
   if 49 - 49: iIii1I11I1II1 - O0 . i1IIi - OoooooooOO
  except :
   pass
   if 37 - 37: i1IIi . O0oO % OoOO0ooOOoo0O + OoooooooOO / iiiIi1i1I
   if 3 - 3: o00O0oo
   if 17 - 17: o00O0oo . II111iiii . iii11I111 / o00O0oo
def ii1I11iIiIII1 ( name , url , mode , iconimage , fanart ) :
 if 57 - 57: O0oO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 67 - 67: OoOO . iii11I111
 oO00oOo0OOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage="
 ii1ooO = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 ii1ooO . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 ii1ooO . setProperty ( 'fanart_image' , fanart )
 ii1ooO . setProperty ( 'IsPlayable' , 'true' )
 oOoOoO000OO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO00oOo0OOO , listitem = ii1ooO )
 return oOoOoO000OO
 if 38 - 38: o0000oOoOoO0o
 if 23 - 23: ii11ii1ii % O0oO - IIII % iIii1I11I1II1 . OoOO0ooOOoo0O
def I1Ii1 ( name , url ) :
 if 79 - 79: i11iIiiIii . IIII - ii11ii1ii / OoooooooOO
 if 66 - 66: OoOO * ii11ii1ii
 try :
  if 28 - 28: OoOO % OoOO0ooOOoo0O % o00O0oo + OOooOOo / OOooOOo
  if 71 - 71: IIII * OoOO % OoooooooOO % OoOO / OOooOOo
  Oo0oOOo = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
  if 56 - 56: OoooooooOO % i11iIiiIii * iIii1I11I1II1 . OoOO * O0
  if 23 - 23: i11iIiiIii
  if Oo0oOOo == key :
   if 39 - 39: o0000oOoOoO0o - o00O0oo % iiiIi1i1I * OoOO - IIII / iiiIi1i1I
   if 29 - 29: o00O0oo
   if 'https://team.com' in url :
    if 52 - 52: i11iIiiIii / i1IIi
    url = url . replace ( 'https://team.com' , 'https://verystream.com' )
    if 1 - 1: iii11I111
   if 'https://mybox.com' in url :
    if 78 - 78: o00O0oo + O0oO - O0
    url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
    if 10 - 10: OoOo % OOooOOo
    if 97 - 97: OoooooooOO - OoOo
   if 'https://vidcloud.co/' in url :
    if 58 - 58: iIii1I11I1II1 + O0
    url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
    if 30 - 30: iii11I111 % iiiIi1i1I * IIII - o00O0oo * o0oO0 % iii11I111
   if 'https://gounlimited.to' in url :
    if 46 - 46: i11iIiiIii - O0 . oO0o0ooO0
    url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
    if 100 - 100: OOooOOo / o0000oOoOoO0o * iiiIi1i1I . O0 / IIII
   if 'https://drive.com' in url :
    if 83 - 83: OoOo
    url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
    if 48 - 48: II111iiii * IIII * OoOo
    if 50 - 50: II11iII % i1IIi
   import resolveurl
   if 21 - 21: OoooooooOO - iIii1I11I1II1
   OO0OoOOO0 = urlresolver . HostedMediaFile ( url )
   if 90 - 90: iii11I111 + II111iiii * o00O0oo / o0oO0 . o0000oOoOoO0o + o0000oOoOoO0o
   if not OO0OoOOO0 :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
    return False
    if 40 - 40: iii11I111 / OoOO0ooOOoo0O % i11iIiiIii % o00O0oo / OOooOOo
   try :
    iioo0o0OoOOO = xbmcgui . DialogProgress ( )
    iioo0o0OoOOO . create ( 'Realstream:' , 'Iniciando ...' )
    iioo0o0OoOOO . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
    xbmc . sleep ( 1000 )
    ooOOOOo0 = OO0OoOOO0 . resolve ( )
    if not ooOOOOo0 or not isinstance ( ooOOOOo0 , basestring ) :
     try : IiiIi = ooOOOOo0 . msg
     except : IiiIi = url
     raise Exception ( IiiIi )
     if 10 - 10: OoOO / ii11ii1ii
   except Exception as OOo00OoO :
    try : IiiIi = str ( OOo00OoO )
    except : IiiIi = url
    iioo0o0OoOOO . update ( 45 , 'RESOLVEURL:' , 'Reiniciando ... ' )
    xbmc . sleep ( 1000 )
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Episodio no disponible.  ,3000)" )
    iioo0o0OoOOO . close ( )
    if 15 - 15: iiiIi1i1I . OoOO0ooOOoo0O / iiiIi1i1I * O0oO - OOooOOo % o00O0oo
   iioo0o0OoOOO . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
   xbmc . sleep ( 500 )
   iioo0o0OoOOO . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   iioo0o0OoOOO . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
   xbmc . sleep ( 500 )
   iioo0o0OoOOO . update ( 100 , 'RESOLVEURL:' , 'Disfrute de este capitulo!' )
   iioo0o0OoOOO . close ( )
   Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
   oo0OOOOOO0 = xbmcgui . ListItem ( path = ooOOOOo0 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0OOOOOO0 )
   if 26 - 26: iIii1I11I1II1
   if 87 - 87: o00O0oo / OoooooooOO - ii11ii1ii % OoOO0ooOOoo0O % II11iII % ii11ii1ii
   if 29 - 29: OoooooooOO . OOooOOo % o00O0oo - iiiIi1i1I
 except :
  pass
  if 8 - 8: i1IIi
  if 32 - 32: oO0o0ooO0 / II111iiii
  if 45 - 45: o00O0oo + OoOO * i11iIiiIii / IIII % O0oO * O0
  if 17 - 17: O0
  if 88 - 88: ii11ii1ii . O0 % OoooooooOO / IIII
  if 89 - 89: II111iiii / oO0o0ooO0
def IIo0OoO00 ( ) :
 if 18 - 18: oO0o0ooO0 - o0000oOoOoO0o - OOooOOo - OOooOOo
 if 54 - 54: ii11ii1ii + OOooOOo / iiiIi1i1I . OOooOOo * OoOO0ooOOoo0O
 IIiIiiiIIIIi1 = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 IIiIiiiIIIIi1 . doModal ( )
 if not IIiIiiiIIIIi1 . isConfirmed ( ) :
  return None ;
 IiI = IIiIiiiIIIIi1 . getText ( ) . strip ( )
 if 39 - 39: OoOO / o0oO0 / OoOo
 if 81 - 81: O0oO / OoOO % OoooooooOO * oO0o0ooO0 / oO0o0ooO0
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 28 - 28: i11iIiiIii / o0000oOoOoO0o . iIii1I11I1II1 / II111iiii
  OoOOII1i11i1iIi11 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + IiI + '&language=es-ES' ) )
  if 83 - 83: o0oO0
  if 25 - 25: O0oO + OoOO0ooOOoo0O . o0000oOoOoO0o % OoOO0ooOOoo0O * IIII
  return 'android'
  if 32 - 32: i11iIiiIii - OoOo
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 53 - 53: OoooooooOO - II11iII
  OoOOII1i11i1iIi11 = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + IiI + '&language=es-ES' )
  if 87 - 87: oO0o0ooO0 . OOooOOo
  if 17 - 17: o0oO0 . i11iIiiIii
  return 'windows'
  if 5 - 5: o00O0oo + O0 + O0 . OoOo - iii11I111
  if 63 - 63: oO0o0ooO0
def Oo0 ( ) :
 if 79 - 79: OoOO % IIII / iIii1I11I1II1 + OoOO0ooOOoo0O * OoOO
 try :
  if 30 - 30: OoooooooOO / O0oO + iiiIi1i1I / o00O0oo * O0
  i1iI1 = i11ii1ii11i ( Iii1IIII11I )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 16 - 16: ii11ii1ii / i11iIiiIii
   try :
    if 64 - 64: i11iIiiIii / o0oO0 * i1IIi
    all = O0O0Oo00
    if 73 - 73: ii11ii1ii - OoOO0ooOOoo0O - oO0o0ooO0 - OOooOOo
   except :
    pass
    if 65 - 65: o0000oOoOoO0o
  oOo0O00O = i11ii1ii11i ( all )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( oOo0O00O )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    if 7 - 7: II11iII . OoOO0ooOOoo0O / o00O0oo . IIII * O0oO - II111iiii
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 37 - 37: OoOo . OoOO0ooOOoo0O / O0 * iiiIi1i1I
   except :
    pass
 except :
  pass
  if 7 - 7: OoOO * O0oO + II111iiii % i11iIiiIii
def i1i1IiIiIi1Ii ( ) :
 if 64 - 64: IIII + OoooooooOO * OoooooooOO
 try :
  if 41 - 41: iii11I111 . ii11ii1ii + OOooOOo
  i1111 = i11ii1ii11i ( oO0o0 )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1111 )
  for O0O0Oo00 in ooO0OoOO :
   if 100 - 100: o0oO0 + OoOO
   try :
    if 73 - 73: i1IIi - OoOo % iii11I111 / OoOO
    OoOoo0oO = O0O0Oo00
    if 40 - 40: o00O0oo * iii11I111 - OOooOOo / II11iII / i11iIiiIii
   except :
    pass
    if 83 - 83: o00O0oo / OoOo - i11iIiiIii . iIii1I11I1II1 + ii11ii1ii
  IIIII1II = i11ii1ii11i ( OoOoo0oO )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( IIIII1II )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    if 59 - 59: O0 % ii11ii1ii
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 92 - 92: o0oO0 % iiiIi1i1I / o00O0oo % o00O0oo * OOooOOo
   except :
    pass
 except :
  pass
  if 74 - 74: O0 . OOooOOo % OoOO % II11iII
def oOo0OooOo ( ) :
 if 51 - 51: O0oO . ii11ii1ii
 try :
  if 45 - 45: i1IIi - ii11ii1ii / O0 . o00O0oo
  i11 = i11ii1ii11i ( OO0Oooo0oOO0O )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i11 )
  for O0O0Oo00 in ooO0OoOO :
   if 5 - 5: o0000oOoOoO0o . iIii1I11I1II1 % iIii1I11I1II1
   try :
    ooO0oo0o0 = O0O0Oo00
   except :
    pass
    if 9 - 9: OOooOOo + o00O0oo / OOooOOo . oO0o0ooO0 * iii11I111
  i1iI1 = i11ii1ii11i ( ooO0oo0o0 )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    if 45 - 45: i11iIiiIii
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 82 - 82: o0oO0 + II11iII
   except :
    pass
 except :
  pass
  if 12 - 12: OoOo
def Oo0oOooOoOo ( ) :
 if 49 - 49: IIII . o00O0oo . i11iIiiIii - II111iiii / o0oO0
 try :
  if 62 - 62: IIII
  i1iI1 = i11ii1ii11i ( db2 )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 1 - 1: II11iII / II11iII - i11iIiiIii
   try :
    if 87 - 87: ii11ii1ii / O0 * II11iII / o0000oOoOoO0o
    I1iiIII = O0O0Oo00
    if 16 - 16: oO0o0ooO0 + iii11I111 / o0000oOoOoO0o
   except :
    pass
    if 82 - 82: II11iII * i11iIiiIii % II111iiii - OoooooooOO
    if 90 - 90: ii11ii1ii . oO0o0ooO0 * i1IIi - i1IIi
  i1iI1 = i11ii1ii11i ( I1iiIII )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 16 - 16: OOooOOo * i1IIi - o0000oOoOoO0o . II11iII % O0oO / o0000oOoOoO0o
   except :
    pass
 except :
  pass
  if 14 - 14: iIii1I11I1II1 * OoOo * o00O0oo / iIii1I11I1II1 * II11iII / O0oO
def OOO000 ( ) :
 if 28 - 28: OoooooooOO . oO0o0ooO0 % o00O0oo / i1IIi / IIII
 try :
  if 36 - 36: o0000oOoOoO0o + O0oO - II11iII + iIii1I11I1II1 + OoooooooOO
  Ii = i11ii1ii11i ( IIIIiii1IIii )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( Ii )
  for O0O0Oo00 in ooO0OoOO :
   if 42 - 42: o0oO0 * OoOo . II11iII * OOooOOo + OoOO0ooOOoo0O
   try :
    if 25 - 25: O0oO . OOooOOo + oO0o0ooO0
    O00OO0o0 = O0O0Oo00
    if 52 - 52: o00O0oo % oO0o0ooO0 - i11iIiiIii
   except :
    pass
    if 30 - 30: iiiIi1i1I / OoOO + oO0o0ooO0
    if 6 - 6: iiiIi1i1I . O0oO + o0oO0 . OoOo
  i1iI1 = i11ii1ii11i ( O00OO0o0 )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    if 70 - 70: OoOO
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 46 - 46: O0oO - i1IIi
   except :
    pass
 except :
  pass
  if 46 - 46: OoOo % o0oO0
def oOOoO0OO00OOo0 ( ) :
 if 18 - 18: OOooOOo + OoOO % iIii1I11I1II1 - i1IIi . oO0o0ooO0
 try :
  if 26 - 26: o0000oOoOoO0o * II11iII . i1IIi
  i1iI1 = i11ii1ii11i ( oOO0O00Oo0O0o )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 59 - 59: O0 + i1IIi - o0000oOoOoO0o
   try :
    if 62 - 62: i11iIiiIii % IIII . II11iII . IIII
    ooOo0O0O0oOO0 = O0O0Oo00
    if 10 - 10: ii11ii1ii + O0
   except :
    pass
    if 43 - 43: iIii1I11I1II1 / II111iiii % o0000oOoOoO0o - IIII
    if 62 - 62: O0oO
  i1iI1 = i11ii1ii11i ( ooOo0O0O0oOO0 )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 63 - 63: IIII + iii11I111 * oO0o0ooO0 / o0000oOoOoO0o / ii11ii1ii * iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 57 - 57: OoOO0ooOOoo0O - oO0o0ooO0 / iii11I111 % i11iIiiIii
def I11oOOooo ( ) :
 if 80 - 80: OOooOOo - i11iIiiIii
 try :
  if 69 - 69: oO0o0ooO0 % OoooooooOO . OOooOOo
  i1iI1 = i11ii1ii11i ( I1iIIiiIIi1i )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 34 - 34: o0oO0 * OoOO0ooOOoo0O - II11iII - OOooOOo - o0oO0
   try :
    if 42 - 42: II111iiii * OOooOOo % i1IIi - o0oO0 % II11iII
    Ii1I1 = O0O0Oo00
    if 58 - 58: II11iII - O0oO % OOooOOo
   except :
    pass
    if 4 - 4: i1IIi + iii11I111 + i1IIi
  i1iI1 = i11ii1ii11i ( Ii1I1 )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 31 - 31: o0oO0
   except :
    pass
 except :
  pass
  if 78 - 78: i11iIiiIii + o0000oOoOoO0o + OoOo / o0000oOoOoO0o % iIii1I11I1II1 % II11iII
def Oo0O0Oo00O ( ) :
 if 9 - 9: o0000oOoOoO0o . OOooOOo - o00O0oo
 try :
  if 32 - 32: OoooooooOO / OOooOOo / iIii1I11I1II1 + II111iiii . oO0o0ooO0 . o0000oOoOoO0o
  i1iI1 = i11ii1ii11i ( oOOo0O00o )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 21 - 21: iIii1I11I1II1 / II111iiii % i1IIi
   try :
    if 8 - 8: OoOO + OoOO0ooOOoo0O . iIii1I11I1II1 % O0
    iI11Ii111 = O0O0Oo00
    if 54 - 54: OoOO0ooOOoo0O % iiiIi1i1I . OoOO0ooOOoo0O * IIII + OoOO0ooOOoo0O % i1IIi
   except :
    pass
    if 23 - 23: OoOo - IIII + o0oO0 - OoOO0ooOOoo0O * OoOO0ooOOoo0O . ii11ii1ii
    if 47 - 47: oO0o0ooO0 % iIii1I11I1II1
  i1iI1 = i11ii1ii11i ( iI11Ii111 )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 11 - 11: OOooOOo % o0oO0 - OoOO - oO0o0ooO0 + o0000oOoOoO0o
   except :
    pass
 except :
  pass
  if 98 - 98: iiiIi1i1I + o0oO0 - OoOO
def OOo0oOO0o0oo0 ( ) :
 if 78 - 78: IIII + iiiIi1i1I . II11iII
 try :
  if 91 - 91: iIii1I11I1II1 . o0000oOoOoO0o . o00O0oo + OoooooooOO
  i1iI1 = i11ii1ii11i ( OOO )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 69 - 69: OoOo - OOooOOo
   try :
    if 95 - 95: OOooOOo * i11iIiiIii . iii11I111
    iIIi1 = O0O0Oo00
    if 83 - 83: II11iII * O0oO / ii11ii1ii
   except :
    pass
    if 32 - 32: o0000oOoOoO0o + OoOO0ooOOoo0O - OoooooooOO
    if 39 - 39: OoooooooOO * IIII * O0 . O0oO . OoOO + iii11I111
  i1iI1 = i11ii1ii11i ( iIIi1 )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 9 - 9: OoOO0ooOOoo0O + oO0o0ooO0 % OoooooooOO + o0000oOoOoO0o
   except :
    pass
 except :
  pass
  if 56 - 56: OoooooooOO + o00O0oo - iiiIi1i1I
def III1I1 ( ) :
 if 12 - 12: iIii1I11I1II1 % iii11I111 % iii11I111
 try :
  if 78 - 78: II11iII . OoOO0ooOOoo0O . O0oO
  i1iI1 = i11ii1ii11i ( oooOo0OOOoo0 )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 97 - 97: oO0o0ooO0
   try :
    if 80 - 80: OOooOOo . o0oO0
    I1I11ii = O0O0Oo00
    if 93 - 93: o00O0oo % OoOO0ooOOoo0O . O0 / iiiIi1i1I * oO0o0ooO0
   except :
    pass
    if 29 - 29: o0000oOoOoO0o
    if 86 - 86: II111iiii . II11iII
  i1iI1 = i11ii1ii11i ( I1I11ii )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 2 - 2: OoooooooOO
   except :
    pass
 except :
  pass
  if 60 - 60: OoOO
def oO00Ooo0oO ( ) :
 if 100 - 100: OoOO / i1IIi - OOooOOo % o0oO0 - iIii1I11I1II1
 try :
  if 17 - 17: O0oO / o0000oOoOoO0o % ii11ii1ii
  i1iI1 = i11ii1ii11i ( ii1I1IIii11 )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 71 - 71: II11iII . OoOo . OoOO
   try :
    if 68 - 68: i11iIiiIii % oO0o0ooO0 * OoOO * II11iII * II111iiii + O0
    o00OoO0oO00 = O0O0Oo00
    if 2 - 2: iIii1I11I1II1
   except :
    pass
    if 45 - 45: OoooooooOO / i11iIiiIii
    if 10 - 10: iiiIi1i1I - oO0o0ooO0 * iIii1I11I1II1 % iIii1I11I1II1 * II11iII - o00O0oo
  i1iI1 = i11ii1ii11i ( o00OoO0oO00 )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 97 - 97: II111iiii % OoOo + OoOo - OoOO / o0oO0 * OOooOOo
   except :
    pass
 except :
  pass
  if 17 - 17: o0oO0
  if 39 - 39: iii11I111 . II111iiii
def iIiIi1iI11iiI ( ) :
 if 26 - 26: iIii1I11I1II1 * OoOo - IIII
 try :
  if 27 - 27: o00O0oo * OoOo - OoOO + o0oO0 * o0oO0
  i1iI1 = i11ii1ii11i ( OO0O000 )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 55 - 55: iii11I111
   try :
    if 82 - 82: OoOo - IIII + OoOO
    OO0 = O0O0Oo00
    if 9 - 9: oO0o0ooO0 % i11iIiiIii / ii11ii1ii
   except :
    pass
    if 20 - 20: oO0o0ooO0 * O0 + O0oO - OoooooooOO . O0oO
    if 60 - 60: o0000oOoOoO0o . o0000oOoOoO0o / iiiIi1i1I
  i1iI1 = i11ii1ii11i ( OO0 )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 45 - 45: O0 . i11iIiiIii % iiiIi1i1I . OoOO0ooOOoo0O % II11iII % iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 58 - 58: iIii1I11I1II1 . OoOO0ooOOoo0O - i11iIiiIii * iIii1I11I1II1 % i11iIiiIii / OOooOOo
  if 80 - 80: o00O0oo / iIii1I11I1II1 % OoOO0ooOOoo0O
def oO000o0Oo00 ( ) :
 if 77 - 77: iIii1I11I1II1 + OoOO . o00O0oo % OoOO
 try :
  if 93 - 93: O0
  i1iI1 = i11ii1ii11i ( oO0O00oOOoooO )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 85 - 85: i11iIiiIii % i11iIiiIii + O0 / IIII
   try :
    if 89 - 89: o0oO0 % i1IIi % oO0o0ooO0
    oOooO0O0OoooO = O0O0Oo00
    if 10 - 10: o0000oOoOoO0o % o0oO0 / IIII
   except :
    pass
    if 28 - 28: IIII % iii11I111
    if 48 - 48: i11iIiiIii % oO0o0ooO0
  i1iI1 = i11ii1ii11i ( oOooO0O0OoooO )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 29 - 29: iiiIi1i1I + i11iIiiIii % O0oO
   except :
    pass
    if 93 - 93: OoOO0ooOOoo0O % iIii1I11I1II1
 except :
  pass
  if 90 - 90: OOooOOo - IIII / o0oO0 / O0 / O0oO
  if 87 - 87: OoOO0ooOOoo0O / II11iII + iIii1I11I1II1
def oo0O0o ( ) :
 if 13 - 13: iIii1I11I1II1 . OoOO0ooOOoo0O * OOooOOo / oO0o0ooO0 * o0oO0
 try :
  if 64 - 64: iii11I111 / O0 * OoOO0ooOOoo0O * iii11I111
  i1iI1 = i11ii1ii11i ( Oo0O00O000 )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 60 - 60: O0oO / i1IIi % o00O0oo / o00O0oo * o00O0oo . i11iIiiIii
   try :
    if 99 - 99: OoOO0ooOOoo0O
    oO00OoOo = O0O0Oo00
    if 74 - 74: II111iiii . O0 - OOooOOo + II11iII % i11iIiiIii % OoOO0ooOOoo0O
   except :
    pass
    if 78 - 78: o0oO0 + OoOO0ooOOoo0O + II11iII - II11iII . i11iIiiIii / OoOO
    if 27 - 27: o0oO0 - O0 % O0oO * OoOo . II11iII % iIii1I11I1II1
  i1iI1 = i11ii1ii11i ( oO00OoOo )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 37 - 37: OoooooooOO + O0 - i1IIi % iii11I111
   except :
    pass
    if 24 - 24: OoOO0ooOOoo0O
 except :
  pass
  if 94 - 94: i1IIi * i1IIi % II111iiii + IIII
def iIIi11 ( ) :
 if 54 - 54: o0oO0 - OoOo
 try :
  if 81 - 81: II11iII . O0 + II111iiii * iIii1I11I1II1 * IIII / OoOO0ooOOoo0O
  i1iI1 = i11ii1ii11i ( oo )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 88 - 88: II111iiii - o0000oOoOoO0o * OOooOOo . OoOO
   try :
    if 65 - 65: II11iII . i1IIi
    OOOoO0 = O0O0Oo00
    if 85 - 85: iIii1I11I1II1 / OoooooooOO % II111iiii
   except :
    pass
    if 49 - 49: i11iIiiIii % OoOO0ooOOoo0O + OoOo . II111iiii % iiiIi1i1I * IIII
  i1iI1 = i11ii1ii11i ( OOOoO0 )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 67 - 67: i1IIi
   except :
    pass
 except :
  pass
  if 5 - 5: II111iiii . OoooooooOO
  if 57 - 57: OOooOOo
def iii1IIiI ( ) :
 if 33 - 33: O0oO
 try :
  if 98 - 98: OoOO0ooOOoo0O % II111iiii
  i1iI1 = i11ii1ii11i ( iIIii )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 95 - 95: iIii1I11I1II1 - OoOo - IIII + OoOo % o00O0oo . OOooOOo
   try :
    if 41 - 41: O0 + oO0o0ooO0 . i1IIi - II111iiii * o0000oOoOoO0o . OoOO
    oooO00Oo = O0O0Oo00
    if 86 - 86: II111iiii + iii11I111 + II11iII
   except :
    pass
    if 9 - 9: iii11I111 + II111iiii % iii11I111 % II11iII + iIii1I11I1II1
    if 59 - 59: i1IIi
  i1iI1 = i11ii1ii11i ( oooO00Oo )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 48 - 48: O0 * o0oO0 * OoOO . OoOO * O0oO - o0oO0
   except :
    pass
 except :
  pass
  if 14 - 14: o00O0oo + i11iIiiIii
  if 83 - 83: o00O0oo / i11iIiiIii + II111iiii . iiiIi1i1I * IIII + II11iII
def iiii1i1II1 ( ) :
 if 63 - 63: iIii1I11I1II1 % o00O0oo - iiiIi1i1I
 try :
  if 17 - 17: OOooOOo
  i1iI1 = i11ii1ii11i ( ii1iii1i )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 88 - 88: OoooooooOO
   try :
    if 28 - 28: ii11ii1ii * o0000oOoOoO0o / OoOo
    Oo0O = O0O0Oo00
    if 88 - 88: OOooOOo % IIII % o00O0oo . i11iIiiIii % o0000oOoOoO0o
   except :
    pass
  i1iI1 = i11ii1ii11i ( Oo0O )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 38 - 38: OoOo + OoooooooOO . i1IIi
   except :
    pass
 except :
  pass
  if 19 - 19: iiiIi1i1I - o0000oOoOoO0o - o0oO0 - OoOO0ooOOoo0O . iiiIi1i1I . OoOo
def i11I1I ( ) :
 if 71 - 71: iiiIi1i1I
 try :
  if 23 - 23: i1IIi . iIii1I11I1II1 . IIII . O0 % o0oO0 % i11iIiiIii
  i1iI1 = i11ii1ii11i ( ooOoO00 )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 11 - 11: O0 - II111iiii . IIII . o0oO0 % OoOo
   try :
    if 21 - 21: ii11ii1ii / iiiIi1i1I . OoOo * OoooooooOO + O0oO - i1IIi
    ooooo0O0 = O0O0Oo00
    if 10 - 10: O0oO - ii11ii1ii
   except :
    pass
    if 59 - 59: OoooooooOO * ii11ii1ii + i1IIi
    if 23 - 23: iii11I111
  i1iI1 = i11ii1ii11i ( ooooo0O0 )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 13 - 13: iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 77 - 77: i11iIiiIii - iIii1I11I1II1 / oO0o0ooO0 / iii11I111 / OoOO
  if 56 - 56: OoooooooOO * O0
def oo0OoOOooO ( ) :
 if 60 - 60: OoOo
 try :
  if 98 - 98: iii11I111
  i1iI1 = i11ii1ii11i ( o0O00Oo0 )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 34 - 34: iIii1I11I1II1 * O0oO * O0oO / o00O0oo
   try :
    if 28 - 28: OoOO - oO0o0ooO0 + OoOO0ooOOoo0O + o0oO0 / iIii1I11I1II1
    iiiii11I1 = O0O0Oo00
    if 16 - 16: O0 . o0oO0 % i1IIi % IIII
   except :
    pass
    if 50 - 50: II11iII + o0000oOoOoO0o
    if 96 - 96: OoOO
  i1iI1 = i11ii1ii11i ( iiiii11I1 )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 92 - 92: ii11ii1ii / i11iIiiIii + o00O0oo
   except :
    pass
 except :
  pass
  if 87 - 87: OoOO0ooOOoo0O % iIii1I11I1II1
def o0OO0OOO0O ( ) :
 if 36 - 36: i11iIiiIii / iiiIi1i1I . O0oO + II11iII . O0 + OOooOOo
 try :
  if 36 - 36: i1IIi - o00O0oo - OoOo
  i1iI1 = i11ii1ii11i ( i111iIi1i1II1 )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 7 - 7: i11iIiiIii + OOooOOo
   try :
    if 47 - 47: OoOo - IIII / iii11I111 - ii11ii1ii + iiiIi1i1I - iIii1I11I1II1
    o0OOOOO0 = O0O0Oo00
    if 79 - 79: II111iiii - iii11I111 . i1IIi + O0 % O0 * OOooOOo
   except :
    pass
    if 7 - 7: i1IIi + IIII % iiiIi1i1I / o0000oOoOoO0o + i1IIi
    if 41 - 41: o0oO0 + i11iIiiIii / II11iII % o00O0oo
  i1iI1 = i11ii1ii11i ( o0OOOOO0 )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 22 - 22: OoOO0ooOOoo0O % o0000oOoOoO0o * o0oO0 - o00O0oo + o0000oOoOoO0o - ii11ii1ii
   except :
    pass
 except :
  pass
  if 15 - 15: IIII
  if 31 - 31: iiiIi1i1I / i1IIi . OoOO
def OOOoo ( ) :
 if 25 - 25: o00O0oo + oO0o0ooO0 + OoooooooOO . II111iiii . iiiIi1i1I
 try :
  if 66 - 66: iii11I111 * OoOO0ooOOoo0O
  i1iI1 = i11ii1ii11i ( i1I1i111Ii )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 2 - 2: oO0o0ooO0 . OoOo * ii11ii1ii + O0 - O0oO * iIii1I11I1II1
   try :
    if 12 - 12: o0000oOoOoO0o * OoOo % II111iiii * i1IIi * iIii1I11I1II1
    oO0oOoo0O = O0O0Oo00
    if 26 - 26: ii11ii1ii + OOooOOo * IIII + iii11I111
   except :
    pass
    if 88 - 88: O0oO + i11iIiiIii % oO0o0ooO0 * IIII * IIII * o0oO0
    if 24 - 24: iii11I111 / iiiIi1i1I + II11iII . II11iII
  i1iI1 = i11ii1ii11i ( oO0oOoo0O )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 39 - 39: iii11I111 + O0 / i1IIi % II11iII / oO0o0ooO0 * II11iII
   except :
    pass
 except :
  pass
  if 77 - 77: II11iII . OoOo % OoOO0ooOOoo0O
  if 42 - 42: II11iII % iiiIi1i1I % o0000oOoOoO0o % oO0o0ooO0 + O0oO % OoOO0ooOOoo0O
def iI1iIIiii ( ) :
 if 52 - 52: o0oO0 % IIII * OOooOOo % O0oO + IIII / iiiIi1i1I
 try :
  if 80 - 80: OoooooooOO + II11iII
  i1iI1 = i11ii1ii11i ( i1i1iI1iiiI )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 95 - 95: OoOo / oO0o0ooO0 * OoOo - OoooooooOO * OoooooooOO % OoOO
   try :
    if 43 - 43: ii11ii1ii . OoOo
    I1I1i1i = O0O0Oo00
    if 87 - 87: OoOO0ooOOoo0O / II11iII . iii11I111 - IIII / OoOO
   except :
    pass
    if 41 - 41: II111iiii
    if 27 - 27: ii11ii1ii * OoOO0ooOOoo0O % iIii1I11I1II1 . OOooOOo
  i1iI1 = i11ii1ii11i ( I1I1i1i )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 70 - 70: O0oO % II111iiii % O0 . i1IIi / OoOo
   except :
    pass
 except :
  pass
  if 100 - 100: o00O0oo * i11iIiiIii % oO0o0ooO0 / ii11ii1ii / iii11I111 + o00O0oo
  if 59 - 59: OoOo - II11iII
def iiiii111 ( ) :
 if 93 - 93: oO0o0ooO0 * o0oO0
 try :
  if 27 - 27: OOooOOo * iii11I111
  i1iI1 = i11ii1ii11i ( oOOOoo00 )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 77 - 77: II11iII
   try :
    if 66 - 66: iIii1I11I1II1 . i11iIiiIii / O0oO / iii11I111 + OoOo
    iII11ii1ii = O0O0Oo00
    if 51 - 51: o00O0oo * o00O0oo
   except :
    pass
    if 98 - 98: OoOO - o0oO0 . II11iII % i11iIiiIii
    if 69 - 69: o00O0oo + iiiIi1i1I * O0 . IIII % OoOO0ooOOoo0O
  i1iI1 = i11ii1ii11i ( iII11ii1ii )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 96 - 96: iii11I111 . iii11I111 - O0oO / O0oO
   except :
    pass
 except :
  pass
  if 96 - 96: i11iIiiIii / OOooOOo - O0 . iii11I111
  if 39 - 39: iii11I111 / O0 * II11iII
def I1IiII1iI1 ( ) :
 if 52 - 52: OoOO0ooOOoo0O * OoOO - o0oO0
 try :
  if 82 - 82: OoOO + OOooOOo . i1IIi + IIII
  i1iI1 = i11ii1ii11i ( iiI1IIIi )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 16 - 16: o0000oOoOoO0o - OoOO / OoOo
   try :
    if 48 - 48: iIii1I11I1II1
    OoooooOo = O0O0Oo00
    if 67 - 67: II111iiii / o0000oOoOoO0o . IIII . OoooooooOO
   except :
    pass
    if 19 - 19: II11iII . o00O0oo / OoOO0ooOOoo0O
  i1iI1 = i11ii1ii11i ( OoooooOo )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 68 - 68: iii11I111 / OoooooooOO * O0oO / oO0o0ooO0
   except :
    pass
 except :
  pass
  if 88 - 88: o0000oOoOoO0o
  if 1 - 1: OoooooooOO
def I1III1I11Iii ( ) :
 if 2 - 2: i11iIiiIii
 try :
  if 98 - 98: oO0o0ooO0 / OoOO - o0oO0 - OOooOOo / OoOO0ooOOoo0O + i11iIiiIii
  i1iI1 = i11ii1ii11i ( IIOOO0O00O0OOOO )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 17 - 17: O0oO
   try :
    if 97 - 97: o00O0oo * o00O0oo / iiiIi1i1I
    i1111IIiI = O0O0Oo00
    if 49 - 49: IIII - OoOO0ooOOoo0O % o0000oOoOoO0o % OoOO
   except :
    pass
    if 32 - 32: II11iII
    if 42 - 42: OoOo + IIII + i11iIiiIii
  i1iI1 = i11ii1ii11i ( i1111IIiI )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 29 - 29: i1IIi + i1IIi
   except :
    pass
 except :
  pass
  if 91 - 91: iiiIi1i1I - iIii1I11I1II1 - II111iiii
def O00000Oo00o ( ) :
 if 20 - 20: OoOO . OOooOOo * i11iIiiIii / i11iIiiIii
 try :
  if 89 - 89: iiiIi1i1I . i11iIiiIii * O0
  i1iI1 = i11ii1ii11i ( OOo0 )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 44 - 44: i1IIi . OOooOOo / i11iIiiIii + II11iII
   try :
    if 27 - 27: IIII
    O0OO0ooO00 = O0O0Oo00
    if 83 - 83: iIii1I11I1II1
   except :
    pass
  i1iI1 = i11ii1ii11i ( O0OO0ooO00 )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 63 - 63: OoooooooOO * OoOO / O0oO - oO0o0ooO0 . iIii1I11I1II1 + iiiIi1i1I
   except :
    pass
 except :
  pass
  if 44 - 44: i1IIi % OOooOOo % o0000oOoOoO0o
def iIIi1Ii1III ( ) :
 if 86 - 86: i11iIiiIii + i11iIiiIii . OoOo % OOooOOo . iii11I111
 try :
  if 17 - 17: o0oO0
  i1iI1 = i11ii1ii11i ( oo0o )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 67 - 67: O0 * O0oO - o0000oOoOoO0o - II111iiii
   try :
    if 41 - 41: OOooOOo - OoOo % II111iiii . OoOo - O0oO
    i1I111Ii = O0O0Oo00
    if 31 - 31: OOooOOo
   except :
    pass
  i1iI1 = i11ii1ii11i ( i1I111Ii )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 73 - 73: iii11I111 . O0 / o0000oOoOoO0o - OoooooooOO % i11iIiiIii
   except :
    pass
 except :
  pass
  if 80 - 80: o0oO0 / iii11I111 % O0 . ii11ii1ii
def oOiI111I1III ( ) :
 if 36 - 36: O0oO % IIII
 try :
  if 72 - 72: OOooOOo / iiiIi1i1I - O0 + O0oO
  i1iI1 = i11ii1ii11i ( IiIi1I1 )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 83 - 83: O0
   try :
    if 89 - 89: ii11ii1ii + o00O0oo - o0000oOoOoO0o
    iII1I11 = O0O0Oo00
    if 15 - 15: O0oO
   except :
    pass
  i1iI1 = i11ii1ii11i ( iII1I11 )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 13 - 13: iIii1I11I1II1 * OoOO0ooOOoo0O / OoOo % iii11I111 + oO0o0ooO0
   except :
    pass
 except :
  pass
  if 41 - 41: o00O0oo
def i1iI1i ( ) :
 if 59 - 59: II11iII
 try :
  if 89 - 89: OoOO0ooOOoo0O % iIii1I11I1II1
  i1iI1 = i11ii1ii11i ( I1III1111iIi )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 35 - 35: o00O0oo + OoOo - OoOO0ooOOoo0O % oO0o0ooO0 % o0000oOoOoO0o % OoOO0ooOOoo0O
   try :
    if 45 - 45: OOooOOo * IIII % OoOO
    i111I11I = O0O0Oo00
    if 80 - 80: iIii1I11I1II1 - OoooooooOO - o00O0oo - o00O0oo . OoooooooOO
   except :
    pass
  i1iI1 = i11ii1ii11i ( i111I11I )
  ooO0OoOO = re . compile ( IiI111111IIII ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i in ooO0OoOO :
   try :
    I1i ( iI1 , IiI , iI1ii1i )
    if 2 - 2: O0oO / OoOO * oO0o0ooO0 % i11iIiiIii + II11iII
   except :
    pass
    if 3 - 3: II11iII + II111iiii / iIii1I11I1II1
 except :
  pass
  if 10 - 10: II111iiii . O0
  if 31 - 31: oO0o0ooO0 / i11iIiiIii / O0
  if 39 - 39: OOooOOo + ii11ii1ii
def I1i ( thumb , name , url ) :
 if 83 - 83: i1IIi
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( o00oooO0Oo ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   IIiIiI1I ( name , url , '' , o00 , oo00 )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 76 - 76: o0oO0 + iIii1I11I1II1 + OoOO0ooOOoo0O . OoOO
  if 'tvg-logo' in thumb :
   thumb = re . compile ( o00oooO0Oo ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 49 - 49: II11iII / iii11I111 / IIII
   IiIiIi1I11I ( name , url , 4 , ooO0oO00O0o , oo00 )
   if 43 - 43: i11iIiiIii + iiiIi1i1I + iii11I111 / OoOo . o00O0oo + iiiIi1i1I
  else :
   if 39 - 39: o00O0oo - i11iIiiIii - O0oO
   IiIiIi1I11I ( name , url , 4 , ooO0oO00O0o , oo00 )
   if 57 - 57: iIii1I11I1II1 + iIii1I11I1II1
def oO0o0Oo ( name , url , thumb , id , trailer ) :
 if 76 - 76: iii11I111 / OoOO0ooOOoo0O + o00O0oo
 if 2 - 2: i11iIiiIii - OoOo + OoOO % O0oO * o0oO0
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 54 - 54: O0 - iiiIi1i1I . IIII % iiiIi1i1I + iiiIi1i1I
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( o00oooO0Oo ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   IIiIiI1I ( name , url , '' , o00 , oo00 )
 else :
  IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
  if 36 - 36: IIII % i11iIiiIii
  name = '[COLOR %s]' % IIIi1I1IIii1II + name + '[/COLOR]'
  if 47 - 47: i1IIi + II111iiii . ii11ii1ii * oO0o0ooO0 . O0oO / i1IIi
  if 'tvg-logo' in thumb :
   thumb = re . compile ( o00oooO0Oo ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'selecton' )
   if O0o0O00Oo0o0 == 'true' :
    if 50 - 50: OoOo / i1IIi % OoooooooOO
    oOOOOO0Ooooo ( name , url , 1 , thumb , thumb , id , trailer )
    if 57 - 57: o0oO0 - OoooooooOO
   else :
    if 68 - 68: o0000oOoOoO0o % o00O0oo / OoOo + OoOo - OoOo . OoOO
    oOOOOO0Ooooo ( name , url , 130 , thumb , thumb , id , trailer )
    if 100 - 100: OoOO0ooOOoo0O % ii11ii1ii
  else :
   if 76 - 76: II111iiii / OoOO + OoooooooOO . o00O0oo . O0oO . iii11I111
   if O0o0O00Oo0o0 == 'true' :
    if 43 - 43: i1IIi
    oOOOOO0Ooooo ( name , url , 1 , thumb , thumb , id , trailer )
    if 17 - 17: O0 - OoOO0ooOOoo0O
   else :
    if 81 - 81: OOooOOo - iIii1I11I1II1 / OOooOOo / O0
    oOOOOO0Ooooo ( name , url , 130 , thumb , thumb , id , trailer )
    if 34 - 34: o0oO0 * o0oO0 - o00O0oo - O0 . i11iIiiIii
    if 32 - 32: iIii1I11I1II1 . OoOO * oO0o0ooO0 / IIII . II111iiii - ii11ii1ii
def OO0O00oOo ( name , url , thumb , id , trailer , description , fanart ) :
 if 10 - 10: o00O0oo / i11iIiiIii - o0oO0 + oO0o0ooO0 * OOooOOo
 if 94 - 94: OOooOOo + iIii1I11I1II1 / O0 - OoooooooOO % o00O0oo
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
 fanart = fanart . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 name = '[COLOR %s]' % IIIi1I1IIii1II + name + '[/COLOR]'
 if 64 - 64: O0oO + OoOO
 if 'tvg-logo' in thumb :
  thumb = re . compile ( o00oooO0Oo ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'selecton' )
  if O0o0O00Oo0o0 == 'true' :
   if 25 - 25: OOooOOo . iii11I111 + OOooOOo % o0oO0 * iIii1I11I1II1
   iiI1iI ( name , url , 1 , thumb , fanart , id , trailer , description )
   if 84 - 84: OoooooooOO + OoOo / OOooOOo % IIII % o00O0oo * OOooOOo
  else :
   if 58 - 58: OoOO - OoOO0ooOOoo0O . i11iIiiIii % i11iIiiIii / i1IIi / oO0o0ooO0
   iiI1iI ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 24 - 24: OOooOOo * i1IIi % iii11I111 / O0 + i11iIiiIii
 else :
  if 12 - 12: o00O0oo / o0oO0
  if O0o0O00Oo0o0 == 'true' :
   if 5 - 5: OoooooooOO
   iiI1iI ( name , url , 1 , thumb , fanart , id , trailer , description )
   if 18 - 18: OOooOOo % OoooooooOO - iiiIi1i1I . i11iIiiIii * ii11ii1ii % o0oO0
  else :
   if 12 - 12: i1IIi / IIII % iii11I111 * II11iII * O0 * iIii1I11I1II1
   iiI1iI ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 93 - 93: ii11ii1ii / o00O0oo + i1IIi * oO0o0ooO0 . OoooooooOO
def Oo000 ( name , trailer ) :
 if 97 - 97: O0 / IIII + o0000oOoOoO0o . oO0o0ooO0 % OoOO0ooOOoo0O - OoOO0ooOOoo0O
 if Oo0OoO00oOO0o == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Realstream, Reproduciendo Trailer de: [COLOR green]" + name + "[/COLOR] ,5000)" )
  if 33 - 33: O0oO % II111iiii + OoOO
  iI1ii1i = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  OoIi1I1I = iI1ii1i
  oOOoOOO0oOoo = xbmcgui . ListItem ( name , trailer , path = OoIi1I1I )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOOoOOO0oOoo )
 else :
  iI1ii1i = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  OoIi1I1I = iI1ii1i
  oOOoOOO0oOoo = xbmcgui . ListItem ( name , trailer , path = OoIi1I1I )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOOoOOO0oOoo )
  if 65 - 65: iiiIi1i1I . oO0o0ooO0 - o0oO0
  if 93 - 93: O0
def iii1 ( trailer ) :
 if 69 - 69: iii11I111 % iii11I111
 if 'https://www.youtube.com' in trailer :
  if 76 - 76: i11iIiiIii * iiiIi1i1I / OoOO % o00O0oo + IIII
  try :
   if 48 - 48: iIii1I11I1II1 % i1IIi + OoOO0ooOOoo0O % o0000oOoOoO0o
   import resolveurl
   if 79 - 79: OoOO0ooOOoo0O % OOooOOo % o0oO0 / i1IIi % OoOO
   OO0OoOOO0 = urlresolver . HostedMediaFile ( iI1ii1i )
   iioo0o0OoOOO = xbmcgui . DialogProgress ( )
   iioo0o0OoOOO . create ( 'Realstream:' , 'Conectando al servidor ... ' )
   iioo0o0OoOOO . update ( 20 , 'Por favor, espere ...' )
   xbmc . sleep ( 500 )
   if 56 - 56: iIii1I11I1II1 - i11iIiiIii * iiiIi1i1I
   if not OO0OoOOO0 :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    return False
    if 84 - 84: IIII + o0oO0 + o0000oOoOoO0o
   try :
    if 33 - 33: o0oO0
    iioo0o0OoOOO . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    ooOOOOo0 = OO0OoOOO0 . resolve ( )
    if not ooOOOOo0 or not isinstance ( ooOOOOo0 , basestring ) :
     try : IiiIi = ooOOOOo0 . msg
     except : IiiIi = ooOOOOo0
     raise Exception ( IiiIi )
   except Exception as OOo00OoO :
    try : IiiIi = str ( OOo00OoO )
    except : IiiIi = ooOOOOo0
    iioo0o0OoOOO . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
    iioo0o0OoOOO . close ( )
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    if 93 - 93: iii11I111
   iioo0o0OoOOO . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
   xbmc . sleep ( 500 )
   iioo0o0OoOOO . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   iioo0o0OoOOO . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
   xbmc . sleep ( 500 )
   iioo0o0OoOOO . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   iioo0o0OoOOO . close ( )
   if 34 - 34: oO0o0ooO0 - iii11I111 * ii11ii1ii / o0000oOoOoO0o
   oo0OOOOOO0 = xbmcgui . ListItem ( path = ooOOOOo0 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0OOOOOO0 )
   if 19 - 19: o00O0oo
  except :
   pass
   if 46 - 46: iIii1I11I1II1 . i11iIiiIii - OoOO0ooOOoo0O % O0 / II111iiii * i1IIi
  else :
   if 66 - 66: O0
   iI1ii1i = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
   OoIi1I1I = iI1ii1i
   oOOoOOO0oOoo = xbmcgui . ListItem ( trailer , path = OoIi1I1I )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOOoOOO0oOoo )
   return
   if 52 - 52: OoOO * OoooooooOO
def Ii11iiI ( name , url ) :
 if 71 - 71: OoOo - o0000oOoOoO0o - IIII
 if '[Youtube]' in name :
  if 28 - 28: iIii1I11I1II1
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  OoIi1I1I = url
  oOOoOOO0oOoo = xbmcgui . ListItem ( Oo0oooO0oO , path = OoIi1I1I )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOOoOOO0oOoo )
  if 7 - 7: o0000oOoOoO0o % II11iII * OoOO0ooOOoo0O
  if 58 - 58: II11iII / O0oO + II111iiii % iiiIi1i1I - OoooooooOO
 else :
  if 25 - 25: OoOO0ooOOoo0O % OoooooooOO * ii11ii1ii - i1IIi * II111iiii * oO0o0ooO0
  import urlresolver
  from urlresolver import common
  if 30 - 30: O0oO % OoOO0ooOOoo0O / o00O0oo * O0 * o0oO0 . OOooOOo
  OO0OoOOO0 = urlresolver . HostedMediaFile ( url )
  if 46 - 46: OoOO0ooOOoo0O - O0
  if not OO0OoOOO0 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 70 - 70: O0oO + ii11ii1ii * iIii1I11I1II1 . OOooOOo * O0oO
   if 49 - 49: o0000oOoOoO0o
  try :
   ooOOOOo0 = OO0OoOOO0 . resolve ( )
   if not ooOOOOo0 or not isinstance ( ooOOOOo0 , basestring ) :
    try : IiiIi = ooOOOOo0 . msg
    except : IiiIi = url
    raise Exception ( IiiIi )
  except Exception as OOo00OoO :
   try : IiiIi = str ( OOo00OoO )
   except : IiiIi = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 25 - 25: iiiIi1i1I . OoooooooOO * iIii1I11I1II1 . o0000oOoOoO0o / O0 + o0oO0
  Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if Oo0OoO00oOO0o == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  oo0OOOOOO0 = xbmcgui . ListItem ( path = ooOOOOo0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0OOOOOO0 )
  if 68 - 68: ii11ii1ii
  if 22 - 22: IIII
 return
 if 22 - 22: iiiIi1i1I * O0oO - ii11ii1ii * O0 / i11iIiiIii
def OOooO0Oo0o000 ( name , url ) :
 if 17 - 17: iIii1I11I1II1 + OOooOOo
 import resolveurl
 if 57 - 57: o0000oOoOoO0o / OoOo
 OO0OoOOO0 = urlresolver . HostedMediaFile ( url )
 dp = xbmcgui . DialogProgress ( )
 dp . create ( 'Realstream:' , 'Conectando al servidor ... ' )
 dp . update ( 20 , 'Por favor, espere ...' )
 xbmc . sleep ( 500 )
 if 13 - 13: OoooooooOO + OoOO
 if not OO0OoOOO0 :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  return False
  if 32 - 32: O0 + oO0o0ooO0 % ii11ii1ii
 try :
  if 7 - 7: o00O0oo / iii11I111
  dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
  xbmc . sleep ( 500 )
  ooOOOOo0 = OO0OoOOO0 . resolve ( )
  if not ooOOOOo0 or not isinstance ( ooOOOOo0 , basestring ) :
   try : IiiIi = ooOOOOo0 . msg
   except : IiiIi = ooOOOOo0
   raise Exception ( IiiIi )
 except Exception as OOo00OoO :
  try : IiiIi = str ( OOo00OoO )
  except : IiiIi = ooOOOOo0
  dp . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
  dp . close ( )
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  if 11 - 11: II11iII * iii11I111 / iii11I111 - IIII
 dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
 xbmc . sleep ( 500 )
 dp . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
 xbmc . sleep ( 500 )
 dp . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
 xbmc . sleep ( 500 )
 dp . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
 dp . close ( )
 Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
 if 68 - 68: OOooOOo % II11iII - II11iII / OOooOOo + o00O0oo - ii11ii1ii
 if 65 - 65: iii11I111 - i1IIi
 if '[Realstream]' or '[Mybox]' in name :
  restante = IiII1IiiIiI1 . getSetting ( 'restante' )
 elif restante == 'true' :
  dialog = xbmcgui . Dialog ( )
  ok = dialog . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
 oo0OOOOOO0 = xbmcgui . ListItem ( path = ooOOOOo0 )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0OOOOOO0 )
 if 62 - 62: O0oO / oO0o0ooO0 % ii11ii1ii . OoooooooOO / i11iIiiIii / OoOo
def OOooO0Oo0o000 ( name , url ) :
 if 60 - 60: OOooOOo % oO0o0ooO0 / o0000oOoOoO0o % oO0o0ooO0 * i11iIiiIii / iiiIi1i1I
 if 34 - 34: OoOo - IIII
 if 'https://www.rapidvideo.com/v/' in url :
  if 25 - 25: oO0o0ooO0 % OOooOOo + i11iIiiIii + O0 * OoooooooOO
  i1iI1 = i11ii1ii11i ( url )
  ooO0OoOO = re . compile ( 'rapidvideo' ) . findall ( i1iI1 )
  for url in ooO0OoOO :
   if 64 - 64: i1IIi
   if 10 - 10: OoOo % O0 / OOooOOo % O0oO
   try :
    Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
    if Oo0OoO00oOO0o == 'true' :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oo0OOOOOO0 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0OOOOOO0 )
    if 25 - 25: II111iiii / OoOO
   except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 64 - 64: O0 % iii11I111
   if 40 - 40: o0000oOoOoO0o + O0oO
 else :
  if 77 - 77: i11iIiiIii % II11iII + OoOo % OoooooooOO - O0oO
  import urlresolver
  from urlresolver import common
  if 26 - 26: ii11ii1ii + O0 - iIii1I11I1II1
  OO0OoOOO0 = urlresolver . HostedMediaFile ( url )
  if 47 - 47: OoooooooOO
  if not OO0OoOOO0 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 2 - 2: OoOO0ooOOoo0O % OoOo * ii11ii1ii * OoOO0ooOOoo0O
   if 65 - 65: i11iIiiIii + ii11ii1ii * OoooooooOO - OoOO
  try :
   ooOOOOo0 = OO0OoOOO0 . resolve ( )
   if not ooOOOOo0 or not isinstance ( ooOOOOo0 , basestring ) :
    try : IiiIi = ooOOOOo0 . msg
    except : IiiIi = url
    raise Exception ( IiiIi )
  except Exception as OOo00OoO :
   try : IiiIi = str ( OOo00OoO )
   except : IiiIi = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 26 - 26: o0000oOoOoO0o % IIII + IIII % O0oO * i11iIiiIii / iiiIi1i1I
  Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if Oo0OoO00oOO0o == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  oo0OOOOOO0 = xbmcgui . ListItem ( path = ooOOOOo0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0OOOOOO0 )
  if 64 - 64: oO0o0ooO0 % OoOO0ooOOoo0O / II111iiii % iii11I111 - iiiIi1i1I
 return
 if 2 - 2: OoOo - o00O0oo + o0000oOoOoO0o * OoOO / iiiIi1i1I
 if 26 - 26: IIII * ii11ii1ii
 if 31 - 31: O0oO * oO0o0ooO0 . o0oO0
def i1Ii11ii1I ( name , url ) :
 if 66 - 66: ii11ii1ii / OoooooooOO % OoOo / iiiIi1i1I + OoooooooOO
 ooOOOOo0 = url
 Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
 if Oo0OoO00oOO0o == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  oo0OOOOOO0 = xbmcgui . ListItem ( path = ooOOOOo0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0OOOOOO0 )
 else :
  oo0OOOOOO0 = xbmcgui . ListItem ( path = ooOOOOo0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0OOOOOO0 )
 return
 if 6 - 6: II111iiii % OoOo
def I1iiIiIII ( name , url ) :
 if 68 - 68: O0
 if 76 - 76: o00O0oo
 if '[Youtube]' in name :
  if 99 - 99: o0000oOoOoO0o
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 1 - 1: o0oO0 * OoOO0ooOOoo0O * OoOO + ii11ii1ii
  try :
   Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if Oo0OoO00oOO0o == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oo0OOOOOO0 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0OOOOOO0 )
    if 90 - 90: OoOo % ii11ii1ii - ii11ii1ii . iIii1I11I1II1 / IIII + O0oO
    if 89 - 89: oO0o0ooO0
    if 87 - 87: iiiIi1i1I % ii11ii1ii
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 62 - 62: OoOO + iii11I111 / iiiIi1i1I * i11iIiiIii
  if 37 - 37: iiiIi1i1I
 else :
  if 33 - 33: OoOO - O0 - OoOO
  import xbmcgui
  import urlresolver
  from urlresolver import common
  if 94 - 94: II11iII * O0oO * OoooooooOO / o0000oOoOoO0o . II11iII - o0000oOoOoO0o
  OO0OoOOO0 = urlresolver . HostedMediaFile ( url )
  if 13 - 13: IIII / II11iII - OoOO / IIII . i1IIi
  if not OO0OoOOO0 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 22 - 22: O0 - O0oO + OoOo . o0oO0 * i1IIi
  import resolveurl as urlresolver
  if 26 - 26: iIii1I11I1II1 * o0000oOoOoO0o . O0oO
  OO0OoOOO0 = urlresolver . HostedMediaFile ( url )
  if 10 - 10: OoOo * oO0o0ooO0 % ii11ii1ii - O0oO % ii11ii1ii
  if 65 - 65: iiiIi1i1I * iIii1I11I1II1 / O0 . O0oO
  if not OO0OoOOO0 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 94 - 94: ii11ii1ii . iii11I111 * i11iIiiIii - o0000oOoOoO0o . iiiIi1i1I
  try :
   ooOOOOo0 = OO0OoOOO0 . resolve ( )
   if not ooOOOOo0 or not isinstance ( ooOOOOo0 , basestring ) :
    try : IiiIi = ooOOOOo0 . msg
    except : IiiIi = url
    raise Exception ( IiiIi )
  except Exception as OOo00OoO :
   try : IiiIi = str ( OOo00OoO )
   except : IiiIi = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 98 - 98: IIII + o0oO0
   if 52 - 52: ii11ii1ii / OoOO0ooOOoo0O - OoOo . iiiIi1i1I
   if 50 - 50: iIii1I11I1II1 - iiiIi1i1I - O0oO
  Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if Oo0OoO00oOO0o == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 60 - 60: iIii1I11I1II1 * iii11I111
   if '[Realstream]' in name :
    if 71 - 71: OoOO0ooOOoo0O % ii11ii1ii % iii11I111
    OOoOO0oo0ooO = IiII1IiiIiI1 . getSetting ( 'restante' )
    if OOoOO0oo0ooO == 'true' :
     I111 = xbmcgui . Dialog ( )
     oOoOoO000OO = I111 . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 6 - 6: OoOO0ooOOoo0O / iii11I111 + iiiIi1i1I - o0000oOoOoO0o * IIII + iii11I111
   oo0OOOOOO0 = xbmcgui . ListItem ( path = ooOOOOo0 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0OOOOOO0 )
   if 76 - 76: II111iiii - OoooooooOO % II11iII
   if 40 - 40: o0oO0
   if 59 - 59: O0oO * OoooooooOO + IIII . iIii1I11I1II1 / i1IIi
 return
 if 75 - 75: O0oO . IIII - iIii1I11I1II1 * OoOO * iiiIi1i1I
 if 93 - 93: iii11I111
 if 18 - 18: iii11I111
def OOOooO00OO00O ( name , url ) :
 if 78 - 78: II111iiii - ii11ii1ii - O0 . IIII + i11iIiiIii - o00O0oo
 if 58 - 58: o0oO0 % OoooooooOO
 if '[Youtube]' in name :
  if 49 - 49: o00O0oo + O0 . o0oO0 * OoooooooOO
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 82 - 82: o00O0oo
  try :
   Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if Oo0OoO00oOO0o == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oo0OOOOOO0 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0OOOOOO0 )
    if 54 - 54: o0000oOoOoO0o + O0oO - iIii1I11I1II1 % iii11I111 % II11iII
    if 19 - 19: o00O0oo / iIii1I11I1II1 % i1IIi . OoooooooOO
    if 57 - 57: iii11I111 . ii11ii1ii - OoOO - i11iIiiIii * OoOo / o0000oOoOoO0o
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 79 - 79: o00O0oo + o0000oOoOoO0o % ii11ii1ii * o0000oOoOoO0o
 else :
  if 21 - 21: iiiIi1i1I
  import resolveurl
  if 24 - 24: iiiIi1i1I / iii11I111
  OO0OoOOO0 = urlresolver . HostedMediaFile ( url )
  if 61 - 61: iIii1I11I1II1 + oO0o0ooO0
  if 8 - 8: OoOo + OoOO
  if not OO0OoOOO0 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 9 - 9: IIII + o0000oOoOoO0o
  try :
   ooOOOOo0 = OO0OoOOO0 . resolve ( )
   if not ooOOOOo0 or not isinstance ( ooOOOOo0 , basestring ) :
    try : IiiIi = ooOOOOo0 . msg
    except : IiiIi = url
    raise Exception ( IiiIi )
  except Exception as OOo00OoO :
   try : IiiIi = str ( OOo00OoO )
   except : IiiIi = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 8 - 8: IIII * ii11ii1ii / iiiIi1i1I - OoOO - OoooooooOO
   if 100 - 100: oO0o0ooO0 . iIii1I11I1II1 . iIii1I11I1II1
   if 55 - 55: oO0o0ooO0
  Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if Oo0OoO00oOO0o == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 37 - 37: II11iII / i11iIiiIii / ii11ii1ii
   if '[Realstream]' in name :
    if 97 - 97: OoOo . O0oO / OOooOOo
    OOoOO0oo0ooO = IiII1IiiIiI1 . getSetting ( 'restante' )
    if OOoOO0oo0ooO == 'true' :
     I111 = xbmcgui . Dialog ( )
     oOoOoO000OO = I111 . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 83 - 83: O0oO - o00O0oo * oO0o0ooO0
   oo0OOOOOO0 = xbmcgui . ListItem ( path = ooOOOOo0 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0OOOOOO0 )
   if 90 - 90: ii11ii1ii * OOooOOo
   if 75 - 75: o00O0oo - OoOO0ooOOoo0O * i11iIiiIii . OoooooooOO - ii11ii1ii . O0oO
   if 6 - 6: O0oO * oO0o0ooO0 / OoooooooOO % o0oO0 * o0000oOoOoO0o
 return
 if 28 - 28: II11iII * OOooOOo % II11iII
def ooo00 ( name , url ) :
 if 17 - 17: O0oO
 if 56 - 56: iii11I111 * o0000oOoOoO0o + O0oO
 if '[Youtube]' in name :
  if 48 - 48: II11iII * OoOO % OoOo - O0oO
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 72 - 72: i1IIi % iii11I111 % II11iII % oO0o0ooO0 - oO0o0ooO0
  try :
   Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if Oo0OoO00oOO0o == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oo0OOOOOO0 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0OOOOOO0 )
    if 97 - 97: o0000oOoOoO0o * O0 / o0000oOoOoO0o * OoOO * ii11ii1ii
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 38 - 38: OoOo
 else :
  if 25 - 25: iIii1I11I1II1 % II111iiii / O0oO / o00O0oo
  if 'https://team.com' in url :
   if 22 - 22: oO0o0ooO0 * iiiIi1i1I
   url = url . replace ( 'https://team.com' , 'https://verystream.com' )
   if 4 - 4: OoOO0ooOOoo0O - oO0o0ooO0 + OOooOOo
  if 'https://mybox.com' in url :
   if 36 - 36: II11iII
   url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
   if 19 - 19: OoOO0ooOOoo0O . o0000oOoOoO0o . OoooooooOO
  if 'https://drive.com' in url :
   if 13 - 13: IIII . ii11ii1ii / II111iiii
   url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
   if 43 - 43: iIii1I11I1II1 % OoOO
  if 'https://vid.co' in url :
   if 84 - 84: ii11ii1ii
   url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
   if 44 - 44: OoooooooOO * i11iIiiIii / ii11ii1ii
  if 'https://limited.to' in url :
   if 75 - 75: OoooooooOO . IIII + OoOO / o0oO0 - OOooOOo % o0oO0
   url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
   if 89 - 89: iiiIi1i1I * iIii1I11I1II1 + i11iIiiIii . OoooooooOO
  import resolveurl
  if 51 - 51: IIII / iii11I111 + OoOO % OoOO0ooOOoo0O / o0oO0
  OO0OoOOO0 = urlresolver . HostedMediaFile ( url )
  if 25 - 25: o0000oOoOoO0o
  if 25 - 25: iii11I111 * iiiIi1i1I / O0oO / O0oO % o0000oOoOoO0o
  if not OO0OoOOO0 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no encontrado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 19 - 19: oO0o0ooO0 - iIii1I11I1II1 / iii11I111 . OoOO * O0 - O0
  try :
   ooOOOOo0 = OO0OoOOO0 . resolve ( )
   if not ooOOOOo0 or not isinstance ( ooOOOOo0 , basestring ) :
    try : IiiIi = ooOOOOo0 . msg
    except : IiiIi = url
    raise Exception ( IiiIi )
  except Exception as OOo00OoO :
   try : IiiIi = str ( OOo00OoO )
   except : IiiIi = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace borrado, o no encontrado. Prueba a reiniciar el router o poner una VPN.[/COLOR]  ,5000)" )
   return False
   if 41 - 41: i1IIi - OOooOOo
   if 48 - 48: OOooOOo - II111iiii / OoOO + OOooOOo
   if 5 - 5: O0
   Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if Oo0OoO00oOO0o == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
    if 75 - 75: OoOo + iIii1I11I1II1
    if '[Realstream]' or '[Mybox]' in name :
     OOoOO0oo0ooO = IiII1IiiIiI1 . getSetting ( 'restante' )
    elif OOoOO0oo0ooO == 'true' :
     I111 = xbmcgui . Dialog ( )
     oOoOoO000OO = I111 . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 19 - 19: OOooOOo + i11iIiiIii . II11iII - O0oO / o0oO0 + o0000oOoOoO0o
  oo0OOOOOO0 = xbmcgui . ListItem ( path = ooOOOOo0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0OOOOOO0 )
  if 38 - 38: ii11ii1ii / iIii1I11I1II1 * iIii1I11I1II1 % o00O0oo
 return
 if 92 - 92: O0oO / O0 * OOooOOo - O0oO
def oooOo00000 ( name , url ) :
 if 45 - 45: O0 * OoOo + i11iIiiIii - IIII - iIii1I11I1II1
 if 5 - 5: IIII % ii11ii1ii % II11iII % iii11I111
 if '[Youtube]' in name :
  if 17 - 17: o0oO0 + II111iiii + OoooooooOO / IIII / II11iII
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 80 - 80: o0000oOoOoO0o % i1IIi / O0oO
  try :
   Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if Oo0OoO00oOO0o == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oo0OOOOOO0 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0OOOOOO0 )
    if 56 - 56: i1IIi . i11iIiiIii
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 15 - 15: II111iiii * oO0o0ooO0 % iiiIi1i1I / i11iIiiIii - oO0o0ooO0 + ii11ii1ii
 else :
  if 9 - 9: O0oO - oO0o0ooO0 + O0 / iiiIi1i1I % i1IIi
  try :
   if 97 - 97: o0000oOoOoO0o * iii11I111
   if 78 - 78: O0oO . IIII + oO0o0ooO0 * iiiIi1i1I - i1IIi
   Oo0oOOo = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 27 - 27: o0oO0 % i1IIi . ii11ii1ii % OoOo
   if 10 - 10: II11iII / OoooooooOO
   if Oo0oOOo == key :
    if 50 - 50: i11iIiiIii - OoooooooOO . oO0o0ooO0 + O0 . i1IIi
    if 91 - 91: o0000oOoOoO0o . iiiIi1i1I % ii11ii1ii - iiiIi1i1I . oO0o0ooO0 % i11iIiiIii
    if 'https://team.com' in url :
     if 25 - 25: iIii1I11I1II1
     url = url . replace ( 'https://team.com' , 'https://verystream.com' )
     if 63 - 63: iii11I111
    if 'https://mybox.com' in url :
     if 96 - 96: O0oO
     url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
     if 34 - 34: OoOO0ooOOoo0O / OoOO - OOooOOo . O0 . IIII
     if 63 - 63: iiiIi1i1I
    if 'https://vidcloud.co/' in url :
     if 11 - 11: iiiIi1i1I - iIii1I11I1II1
     url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
     if 92 - 92: OoOO
    if 'https://gounlimited.to' in url :
     if 15 - 15: II11iII / II11iII + iIii1I11I1II1 % OoooooooOO
     url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
     if 12 - 12: iii11I111
    if 'https://drive.com' in url :
     if 36 - 36: OoOo . II11iII * OoooooooOO - o0000oOoOoO0o
     url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
     if 60 - 60: IIII . iiiIi1i1I / iIii1I11I1II1 + IIII * OoOo
     if 82 - 82: i11iIiiIii . iIii1I11I1II1 * OOooOOo - O0oO + o0oO0
    import resolveurl
    if 48 - 48: o00O0oo
    OO0OoOOO0 = urlresolver . HostedMediaFile ( url )
    if 96 - 96: iii11I111 . OoooooooOO
    if not OO0OoOOO0 :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
     return False
     if 39 - 39: IIII + OoOO
    try :
     iioo0o0OoOOO = xbmcgui . DialogProgress ( )
     iioo0o0OoOOO . create ( 'Realstream:' , 'Iniciando ...' )
     iioo0o0OoOOO . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
     xbmc . sleep ( 1000 )
     if 80 - 80: IIII % OoOO / OoOO0ooOOoo0O
     ooOOOOo0 = OO0OoOOO0 . resolve ( )
     if not ooOOOOo0 or not isinstance ( ooOOOOo0 , basestring ) :
      if 54 - 54: ii11ii1ii % OoOO - IIII - O0oO
      try : IiiIi = ooOOOOo0 . msg
      except : IiiIi = url
      raise Exception ( IiiIi )
      if 71 - 71: iii11I111 . i11iIiiIii
    except Exception as OOo00OoO :
     try : IiiIi = str ( OOo00OoO )
     except : IiiIi = url
     iioo0o0OoOOO . update ( 45 , 'RESOLVEURL:' , 'Reiniciando ... ' )
     xbmc . sleep ( 1000 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no disponible.  ,3000)" )
     iioo0o0OoOOO . close ( )
     if 56 - 56: O0 * iiiIi1i1I + iiiIi1i1I * iIii1I11I1II1 / iii11I111 * OoOo
    iioo0o0OoOOO . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    iioo0o0OoOOO . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
    xbmc . sleep ( 1000 )
    iioo0o0OoOOO . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
    iioo0o0OoOOO . close ( )
    Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
    oo0OOOOOO0 = xbmcgui . ListItem ( path = ooOOOOo0 )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0OOOOOO0 )
    if 25 - 25: iIii1I11I1II1 . O0oO * i11iIiiIii + ii11ii1ii * O0oO
    if 67 - 67: iiiIi1i1I
  except :
   pass
   if 88 - 88: ii11ii1ii
 return
 if 8 - 8: o00O0oo
def o000 ( ) :
 if 30 - 30: o0oO0 + II111iiii % OoooooooOO
 oOo000O00O0 = [ ]
 iI1iiIii1I11I = sys . argv [ 2 ]
 if len ( iI1iiIii1I11I ) >= 2 :
  Ii1IiiiI1ii = sys . argv [ 2 ]
  o0oOOoo0O = Ii1IiiiI1ii . replace ( '?' , '' )
  if ( Ii1IiiiI1ii [ len ( Ii1IiiiI1ii ) - 1 ] == '/' ) :
   Ii1IiiiI1ii = Ii1IiiiI1ii [ 0 : len ( Ii1IiiiI1ii ) - 2 ]
  OoooOo00 = o0oOOoo0O . split ( '&' )
  oOo000O00O0 = { }
  for OO0III in range ( len ( OoooOo00 ) ) :
   OoO0o = { }
   OoO0o = OoooOo00 [ OO0III ] . split ( '=' )
   if ( len ( OoO0o ) ) == 2 :
    oOo000O00O0 [ OoO0o [ 0 ] ] = OoO0o [ 1 ]
 return oOo000O00O0
 if 72 - 72: IIII % OoooooooOO % o0000oOoOoO0o * IIII % OOooOOo * o0oO0
 if 34 - 34: OoOO * o0oO0 * ii11ii1ii
def Iioo0O00ooo0o ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  import urlresolver
  xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
  if 29 - 29: OoooooooOO . II111iiii % OoOO0ooOOoo0O
def IiiIi1I11 ( ) :
 I111 = xbmcgui . Dialog ( )
 list = (
 i1I1Ii11II1i ,
 oooOoOOoOO0O
 )
 if 9 - 9: OoOo * OoooooooOO % OOooOOo / OoOO0ooOOoo0O * O0oO
 iiIiII1 = I111 . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=%s]Accede a themoviedb.com[/COLOR]' % O0ii1ii1ii ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 37 - 37: O0 + iii11I111 * IIII
 if iiIiII1 :
  if 27 - 27: O0 . II111iiii + II11iII % o0000oOoOoO0o
  if iiIiII1 < 0 :
   return
  oo0O0oOOO0o = list [ iiIiII1 - 2 ]
  return oo0O0oOOO0o ( )
 else :
  oo0O0oOOO0o = list [ iiIiII1 ]
  return oo0O0oOOO0o ( )
 return
 if 70 - 70: ii11ii1ii % o0oO0 . o00O0oo
def Ii1111iiI ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 15 - 15: iii11I111 . o0000oOoOoO0o + OoOO0ooOOoo0O . iIii1I11I1II1 % iii11I111 + O0
IIiII11 = Ii1111iiI ( )
if 58 - 58: iiiIi1i1I
def i1I1Ii11II1i ( ) :
 if IIiII11 == 'android' :
  OoOOII1i11i1iIi11 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  OoOOII1i11i1iIi11 = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 2 - 2: II11iII - oO0o0ooO0 % OoOO + o0000oOoOoO0o + o0oO0 - iIii1I11I1II1
  if 18 - 18: o00O0oo / ii11ii1ii - iiiIi1i1I
def oooOoOOoOO0O ( ) :
 if 69 - 69: oO0o0ooO0 / II11iII * iii11I111
 main ( )
 if 81 - 81: oO0o0ooO0
 if 62 - 62: o0oO0 + O0 * OoOO
 if 59 - 59: II111iiii
def iIiIi11I1iIii1i11 ( ) :
 I111 = xbmcgui . Dialog ( )
 iIiiI11II11i = (
 o00OoO0o0 ,
 o0OOOoO0ooOOOo0
 )
 if 93 - 93: ii11ii1ii
 iiIiII1 = I111 . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 75 - 75: OoOO0ooOOoo0O
 if iiIiII1 :
  if 64 - 64: II11iII / o0000oOoOoO0o / i1IIi
  if iiIiII1 < 0 :
   return
  oo0O0oOOO0o = iIiiI11II11i [ iiIiII1 - 2 ]
  return oo0O0oOOO0o ( )
 else :
  oo0O0oOOO0o = iIiiI11II11i [ iiIiII1 ]
  return oo0O0oOOO0o ( )
 return
 if 79 - 79: IIII % OoOo / oO0o0ooO0 - iIii1I11I1II1 - OoOO0ooOOoo0O
def Ii1111iiI ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 60 - 60: II111iiii
IIiII11 = Ii1111iiI ( )
if 90 - 90: OoOO0ooOOoo0O
def o00OoO0o0 ( ) :
 if IIiII11 == 'android' :
  OoOOII1i11i1iIi11 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  OoOOII1i11i1iIi11 = webbrowser . open ( 'https://olpair.com/' )
  if 37 - 37: OoOO0ooOOoo0O + O0 . O0 * ii11ii1ii % OoOo / iiiIi1i1I
  if 18 - 18: OoooooooOO
def o0OOOoO0ooOOOo0 ( ) :
 if 57 - 57: iii11I111 . OoOO0ooOOoo0O * o0000oOoOoO0o - OoooooooOO
 main ( )
 if 75 - 75: i11iIiiIii / o0000oOoOoO0o . II11iII . i1IIi . i1IIi / O0oO
 if 94 - 94: iii11I111 + OOooOOo
def oOOOoo00oO ( name , url , id , trailer ) :
 I111 = xbmcgui . Dialog ( )
 iIiiI11II11i = (
 O00O0 ,
 IIIIIIIiiiI ,
 oO0Oooo0OoO ,
 IiiIi1I11 ,
 Iii
 )
 if 33 - 33: II11iII % ii11ii1ii - oO0o0ooO0
 iiIiII1 = I111 . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % O0ii1ii1ii ,

 '[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % O0ii1ii1ii ,

 '[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % O0ii1ii1ii ,

 '[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % O0ii1ii1ii ,

 '[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % O0ii1ii1ii ] )
 if 53 - 53: II111iiii
 if iiIiII1 :
  if 61 - 61: O0 * OoOO * OOooOOo % OoooooooOO / OoOO0ooOOoo0O % iii11I111
  if iiIiII1 < 0 :
   return
  oo0O0oOOO0o = iIiiI11II11i [ iiIiII1 - 5 ]
  return oo0O0oOOO0o ( )
 else :
  oo0O0oOOO0o = iIiiI11II11i [ iiIiII1 ]
  return oo0O0oOOO0o ( )
 return
 if 43 - 43: OoooooooOO
 if 33 - 33: II111iiii - II11iII - iii11I111
 if 92 - 92: OoOO * II11iII
def O00O0 ( ) :
 if 92 - 92: oO0o0ooO0
 oooOo00000 ( IiI , iI1ii1i )
 if 7 - 7: iiiIi1i1I
def IIIIIIIiiiI ( ) :
 if 73 - 73: OoOO % o00O0oo
 Oo000 ( IiI , Oo0oooO0oO )
 if 32 - 32: IIII + iiiIi1i1I + iIii1I11I1II1 * ii11ii1ii
def oO0Oooo0OoO ( ) :
 if 62 - 62: i11iIiiIii
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  i1Iii = id
  if 91 - 91: iii11I111 * II11iII * II111iiii
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % i1Iii )
  if 79 - 79: OoOo
 if Oo0OoO00oOO0o == 'true' :
  if 8 - 8: iiiIi1i1I - II111iiii
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + IiI + "[/COLOR] ,5000)" )
  if 18 - 18: OoOO0ooOOoo0O
def I11IIiIII1i ( ) :
 if 74 - 74: II111iiii / O0
 IiiIi1I11 ( )
 if 56 - 56: O0oO - O0 / O0 * i1IIi . OoooooooOO % iIii1I11I1II1
def Iii ( ) :
 if 21 - 21: II11iII - OOooOOo % OoooooooOO + o0000oOoOoO0o
 i1i1i1I ( )
def IIiIiI1I ( name , url , mode , iconimage , fanart ) :
 if 92 - 92: iii11I111 + II11iII
 oO00oOo0OOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 oOoOoO000OO = True
 ii1ooO = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 ii1ooO . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 ii1ooO . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  oO00oOo0OOO = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  oOoOoO000OO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO00oOo0OOO , listitem = ii1ooO , isFolder = True )
  return oOoOoO000OO
 oOoOoO000OO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO00oOo0OOO , listitem = ii1ooO , isFolder = True )
 return oOoOoO000OO
 if 52 - 52: II111iiii / OOooOOo . oO0o0ooO0 * II11iII . O0oO
def ooOO00oOOo000 ( name , url , mode , iconimage , fanart , description ) :
 if 25 - 25: i11iIiiIii / OoOO0ooOOoo0O - OoOo / OoOO . o0000oOoOoO0o . o0000oOoOoO0o
 oO00oOo0OOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 oOoOoO000OO = True
 ii1ooO = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 ii1ooO . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 ii1ooO . setProperty ( 'fanart_image' , fanart )
 oOoOoO000OO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO00oOo0OOO , listitem = ii1ooO , isFolder = True )
 return oOoOoO000OO
 if 6 - 6: oO0o0ooO0 . O0oO
def oOOOOO0Ooooo ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 43 - 43: o00O0oo + o0000oOoOoO0o
 oo00O00oO = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 50 - 50: oO0o0ooO0 % i1IIi * O0
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 iiIIi11ii1Ii = [ ]
 if 60 - 60: o0000oOoOoO0o . OoOO0ooOOoo0O % OoOo / OOooOOo / O0
 iiIIi11ii1Ii . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 oO00oOo0OOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 ii1ooO = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 ii1ooO . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 ii1ooO . setProperty ( 'fanart_image' , fanart )
 ii1ooO . setProperty ( 'IsPlayable' , 'true' )
 if 19 - 19: i11iIiiIii . OOooOOo + II111iiii / IIII . o00O0oo * iii11I111
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  iiIIi11ii1Ii . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 59 - 59: iIii1I11I1II1 / o00O0oo % iii11I111
  ii1ooO . addContextMenuItems ( iiIIi11ii1Ii , replaceItems = True )
 oOoOoO000OO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO00oOo0OOO , listitem = ii1ooO )
 return oOoOoO000OO
 if 84 - 84: iIii1I11I1II1 / OOooOOo . OoOO0ooOOoo0O % O0oO
 if 99 - 99: ii11ii1ii + i11iIiiIii
def iiI1iI ( name , url , mode , iconimage , fanart , id , trailer , description ) :
 if 36 - 36: o0oO0 * OoOo * iIii1I11I1II1 - O0oO % i11iIiiIii
 oo00O00oO = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 98 - 98: iIii1I11I1II1 - i1IIi + iii11I111 % O0oO + iii11I111 / oO0o0ooO0
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 iiIIi11ii1Ii = [ ]
 if 97 - 97: II11iII % iii11I111 + II111iiii - II11iII % OoOO + iii11I111
 iiIIi11ii1Ii . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 oO00oOo0OOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 ii1ooO = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 ii1ooO . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 ii1ooO . setProperty ( 'fanart_image' , fanart )
 ii1ooO . setProperty ( 'IsPlayable' , 'true' )
 if 31 - 31: o0000oOoOoO0o
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  iiIIi11ii1Ii . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 35 - 35: OoOO0ooOOoo0O + o0oO0 * iii11I111 / OoOO0ooOOoo0O
  ii1ooO . addContextMenuItems ( iiIIi11ii1Ii , replaceItems = True )
 oOoOoO000OO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO00oOo0OOO , listitem = ii1ooO )
 return oOoOoO000OO
 if 69 - 69: iii11I111 . IIII - OOooOOo
def IiIiIi1I11I ( name , url , mode , iconimage , fanart ) :
 if 29 - 29: i11iIiiIii . o00O0oo / OOooOOo . IIII + i11iIiiIii
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 26 - 26: II11iII / o0oO0 - OoooooooOO
 oO00oOo0OOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 ii1ooO = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 ii1ooO . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 ii1ooO . setProperty ( 'fanart_image' , fanart )
 ii1ooO . setProperty ( 'IsPlayable' , 'true' )
 oOoOoO000OO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO00oOo0OOO , listitem = ii1ooO )
 return oOoOoO000OO
 if 9 - 9: OoooooooOO * o00O0oo
def iI1II1i ( name , url , mode ) :
 if 27 - 27: o00O0oo / IIII
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 33 - 33: OoooooooOO % o00O0oo . O0 / o00O0oo
 oO00oOo0OOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 ii1ooO = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = ooO0oO00O0o )
 ii1ooO . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 ii1ooO . setProperty ( 'fanart_image' , oo00 )
 ii1ooO . setProperty ( 'IsPlayable' , 'true' )
 oOoOoO000OO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO00oOo0OOO , listitem = ii1ooO )
 return oOoOoO000OO
 if 63 - 63: II11iII + iIii1I11I1II1 + OOooOOo + OoOo
def oOOoO0O ( name , url , mode , iconimage ) :
 oO00oOo0OOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 oOoOoO000OO = True
 ii1ooO = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 oOoOoO000OO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO00oOo0OOO , listitem = ii1ooO , isFolder = True )
 return oOoOoO000OO
 if 76 - 76: i1IIi / iIii1I11I1II1 - o00O0oo - II111iiii
def oo00Oo ( ) :
 if 6 - 6: OOooOOo - II111iiii . OOooOOo + O0oO . IIII
 if 74 - 74: i1IIi
 if 15 - 15: i1IIi + II11iII % OOooOOo / i11iIiiIii * OoOO0ooOOoo0O
 i11I1I1I = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 i11I1I1I . doModal ( )
 if ( i11I1I1I . isConfirmed ( ) ) :
  if 69 - 69: i11iIiiIii
  oo00O00Oo = urllib . quote_plus ( i11I1I1I . getText ( ) ) . replace ( '+' , ' ' )
  if 61 - 61: O0
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 21 - 21: OoOO % iIii1I11I1II1 . OoOO
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % oo00O00Oo )
    if 99 - 99: o0000oOoOoO0o * IIII % oO0o0ooO0 * oO0o0ooO0 + OoooooooOO
    if Oo0OoO00oOO0o == 'true' :
     if 82 - 82: O0oO / OoOO0ooOOoo0O - IIII / iii11I111
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + IiI + "[/COLOR] ,10000)" )
     if 50 - 50: IIII + OoOO . i11iIiiIii + o00O0oo + i11iIiiIii
   except :
    if 31 - 31: oO0o0ooO0 * OoOo . OoOO0ooOOoo0O * O0oO
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 28 - 28: II11iII + OOooOOo - ii11ii1ii % IIII . O0oO + OOooOOo
Ii1IiiiI1ii = o000 ( )
iI1ii1i = None
IiI = None
O0oO0 = None
ooO0oO00O0o = None
id = None
Oo0oooO0oO = None
if 65 - 65: IIII + OoOo - o0oO0
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 53 - 53: OOooOOo
try :
 iI1ii1i = urllib . unquote_plus ( Ii1IiiiI1ii [ "url" ] )
except :
 pass
try :
 IiI = urllib . unquote_plus ( Ii1IiiiI1ii [ "name" ] )
except :
 pass
try :
 O0oO0 = int ( Ii1IiiiI1ii [ "mode" ] )
except :
 pass
try :
 ooO0oO00O0o = urllib . unquote_plus ( Ii1IiiiI1ii [ "iconimage" ] )
except :
 pass
try :
 id = int ( Ii1IiiiI1ii [ "id" ] )
except :
 pass
try :
 Oo0oooO0oO = urllib . unquote_plus ( Ii1IiiiI1ii [ "trailer" ] )
except :
 pass
 if 96 - 96: OoOO - II11iII . OoooooooOO
 if 10 - 10: OoOo
print "Mode: " + str ( O0oO0 )
print "URL: " + str ( iI1ii1i )
print "Name: " + str ( IiI )
print "iconimage: " + str ( ooO0oO00O0o )
print "id: " + str ( id )
print "trailer: " + str ( Oo0oooO0oO )
if 48 - 48: iiiIi1i1I * i1IIi % OoooooooOO * o0oO0 * OoOO
if O0oO0 == None or iI1ii1i == None or len ( iI1ii1i ) < 1 :
 if 7 - 7: iiiIi1i1I . o0oO0 . iiiIi1i1I - OoOo
 i1i1i1I ( )
 I11i1II ( )
 if 33 - 33: iii11I111 + OoooooooOO - OoOO / i1IIi / OoooooooOO
elif O0oO0 == 1 :
 oOOOoo00oO ( IiI , iI1ii1i , id , Oo0oooO0oO )
elif O0oO0 == 2 :
 i1i1IiIiIi1Ii ( )
elif O0oO0 == 3 :
 oOo0OooOo ( )
elif O0oO0 == 4 :
 Ii11iiI ( IiI , iI1ii1i )
elif O0oO0 == 5 :
 oOOoO0OO00OOo0 ( )
elif O0oO0 == 6 :
 I11oOOooo ( )
elif O0oO0 == 7 :
 Oo0O0Oo00O ( )
elif O0oO0 == 8 :
 OOo0oOO0o0oo0 ( )
elif O0oO0 == 9 :
 III1I1 ( )
elif O0oO0 == 10 :
 iIiIi1iI11iiI ( )
elif O0oO0 == 11 :
 oO000o0Oo00 ( )
elif O0oO0 == 12 :
 oo0O0o ( )
elif O0oO0 == 13 :
 iIIi11 ( )
elif O0oO0 == 14 :
 iii1IIiI ( )
elif O0oO0 == 15 :
 iiii1i1II1 ( )
elif O0oO0 == 16 :
 i11I1I ( )
elif O0oO0 == 17 :
 oo0OoOOooO ( )
elif O0oO0 == 18 :
 o0OO0OOO0O ( )
elif O0oO0 == 19 :
 OOOoo ( )
elif O0oO0 == 20 :
 iI1iIIiii ( )
elif O0oO0 == 21 :
 iiiii111 ( )
elif O0oO0 == 22 :
 I1IiII1iI1 ( )
elif O0oO0 == 23 :
 I1III1I11Iii ( )
elif O0oO0 == 24 :
 O00000Oo00o ( )
elif O0oO0 == 25 :
 iIIi1Ii1III ( )
elif O0oO0 == 26 :
 Oo0 ( )
elif O0oO0 == 28 :
 I1Ii1 ( IiI , iI1ii1i )
elif O0oO0 == 29 :
 OOO000 ( )
elif O0oO0 == 30 :
 oO00Ooo0oO ( )
elif O0oO0 == 31 :
 prueba ( )
elif O0oO0 == 98 :
 busqueda_global ( )
elif O0oO0 == 97 :
 iIiIi11I1iIii1i11 ( )
elif O0oO0 == 99 :
 IIo0OoO00 ( )
elif O0oO0 == 100 :
 menu_player ( IiI , iI1ii1i )
elif O0oO0 == 111 :
 iiiII ( )
elif O0oO0 == 115 :
 Oo000 ( iI1ii1i )
elif O0oO0 == 116 :
 oooO0 ( )
elif O0oO0 == 117 :
 III ( )
elif O0oO0 == 119 :
 OoOo00o0OO ( )
elif O0oO0 == 120 :
 oOOoOooo0O0o ( )
elif O0oO0 == 121 :
 OOoO0 ( )
elif O0oO0 == 125 :
 i1iI1i ( )
elif O0oO0 == 112 :
 list_proxy ( )
elif O0oO0 == 127 :
 oo00Oo ( )
elif O0oO0 == 128 :
 TESTLINKS ( )
elif O0oO0 == 130 :
 oooOo00000 ( IiI , iI1ii1i )
elif O0oO0 == 140 :
 O0oOOO000oooo0 ( )
elif O0oO0 == 141 :
 oOiI111I1III ( )
elif O0oO0 == 142 :
 o0O ( )
elif O0oO0 == 143 :
 I1iIi1iiiIiI ( IiI , iI1ii1i )
elif O0oO0 == 144 :
 I1Ii1 ( IiI , iI1ii1i )
elif O0oO0 == 145 :
 iII11I1Ii1 ( )
elif O0oO0 == 150 :
 O0000 ( )
elif O0oO0 == 151 :
 iIIIII1iiiiII ( )
elif O0oO0 == 152 :
 oo0ooOO ( )
 if 82 - 82: o00O0oo / IIII - iiiIi1i1I / ii11ii1ii * OoOO
xbmcplugin . endOfDirectory ( o0OoOoOO00 ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
