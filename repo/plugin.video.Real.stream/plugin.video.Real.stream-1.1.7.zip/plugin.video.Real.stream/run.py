# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 1.1.5
#
############################################
# Dependencias 
# Script ExtendedInfo
# Script Urlresolver de TVAddons
# Script ResolveURL Por Jsergio.
#
############################################
#
# Agregar sinopsis a Peliculas y series.
# Supresion de Licencia
# Novedades en episodios agregados en series.
#
############################################
if 64 - 64: i11iIiiIii
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import urlresolver
import cookielib , base64
import requests
import plugintools
import config
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
IiII1IiiIiI1 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
o0OoOoOO00 = int ( sys . argv [ 1 ] )
I11i = 'gruponetai/'
O0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
Oo = O0O . getAddonInfo ( 'profile' )
I1ii11iIi11i = O0O . getAddonInfo ( 'path' )
I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
if 73 - 73: OOooOOo / ii11ii1ii
if 94 - 94: OoOO + OoOO0ooOOoo0O + o0000oOoOoO0o * o00O0oo
if I1IiI == 'true' :
 if 97 - 97: oO0o0ooO0 - IIII / O0oO - o0oO0
 oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.png' ) )
 o00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 Oo0oO0ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.png' ) )
 i1111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.png' ) )
 i11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'estrenos.png' ) )
 I11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.png' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.png' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.png' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.png' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.png' ) )
 oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.png' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.png' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.png' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.png' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.png' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.png' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.png' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'marvel.png' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.png' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.png' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.png' ) )
 II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.png' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.png' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.png' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.png' ) )
 OO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.png' ) )
 Ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.png' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.png' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.png' ) )
 O0OO00o0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.jpg' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.jpg' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_series.png' ) )
 OOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_Episodios.png' ) )
 if 87 - 87: O0ooOooooO / i1I111II1I - Oooo0Ooo000 - iI - II111iiii / O0
else :
 if 97 - 97: iI - IIII * i11iIiiIii / OoOO0ooOOoo0O % Oooo0Ooo000 - OoooooooOO
 if 59 - 59: O0 + OOooOOo + i1I111II1I % OOooOOo
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
 oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.jpg' ) )
 o00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 Oo0oO0ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.jpg' ) )
 i1111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.jpg' ) )
 i11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'encines.jpg' ) )
 I11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.jpg' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.jpg' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.jpg' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.jpg' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.jpg' ) )
 oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.jpg' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.jpg' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.jpg' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.jpg' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.jpg' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.jpg' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.jpg' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'superheroes.jpg' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.jpg' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.jpg' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.jpg' ) )
 II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.jpg' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.jpg' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.jpg' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.jpg' ) )
 OO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.jpg' ) )
 Ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.jpg' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.jpg' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.jpg' ) )
 O0OO00o0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.jpg' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.jpg' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.jpg' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favoritos.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_series.png' ) )
 OOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_Episodios.png' ) )
 if 70 - 70: O0ooOooooO * o00O0oo
 if 46 - 46: iI / OoOO
 if 52 - 52: o0000oOoOoO0o - OoooooooOO + o0oO0 + o0oO0 - o0000oOoOoO0o / Oooo0Ooo000
I1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'peliculas.png' ) )
iIi11Ii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series.png' ) )
Ii11iII1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ajustes.png' ) )
Oo0O0O0ooO0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'videoteca.png' ) )
IIIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
O0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'resolver.png' ) )
OO00Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'test.png' ) )
O0OOO0OOoO0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'video-tutoriales.png' ) )
O00Oo000ooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'proxy.png' ) )
if 100 - 100: O0 + i1I111II1I - IIII + i11iIiiIii * o0oO0
if 30 - 30: o0000oOoOoO0o . o0oO0 - OoooooooOO
if 8 - 8: i1IIi - iIii1I11I1II1 * II111iiii + i11iIiiIii / Oooo0Ooo000 % IIII
iIIIi1 = IiII1IiiIiI1 . getSetting ( 'mostrar_cat' )
iiII1i1 = IiII1IiiIiI1 . getSetting ( 'sel_tobox' )
o00oOO0o = IiII1IiiIiI1 . getSetting ( 'videos' )
OOO00O = IiII1IiiIiI1 . getSetting ( 'activar' )
OOoOO0oo0ooO = IiII1IiiIiI1 . getSetting ( 'favcopy' )
O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'anticopia' )
O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
i1i = IiII1IiiIiI1 . getSetting ( 'mostrar_bus' )
iiI111I1iIiI = IiII1IiiIiI1 . getSetting ( 'restante' )
IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'selecton' )
O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'aviso' )
oooooOoo0ooo = IiII1IiiIiI1 . getSetting ( 'RealStream_Settings' )
I1I1IiI1 = IiII1IiiIiI1 . getSetting ( 'Resolver_Settings' )
iiI111I1iIiI = IiII1IiiIiI1 . getSetting ( 'restante' )
III1iII1I1ii = IiII1IiiIiI1 . getSetting ( 'fav' )
oOOo0 = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
oo00O00oO = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
iIiIIIi = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
ooo00OOOooO = 'bienvenida'
O00OOOoOoo0O = 'bienvenida'
copyright = IiII1IiiIiI1 . getSetting ( 'copyright' )
O000OOo00oo = 'cGx1Z2luLnZpZGVvLg==' . decode ( 'base64' ) + copyright
oo0OOo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
ooOOO00Ooo = IiII1IiiIiI1 . getSetting ( 'Forceupdate' )
if ooOOO00Ooo == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
IiIIIi1iIi = 'LnR4dA==' . decode ( 'base64' )
if 68 - 68: i11iIiiIii % o00O0oo + i11iIiiIii
if 31 - 31: II111iiii . OOooOOo
if 1 - 1: ii11ii1ii / o0000oOoOoO0o % O0ooOooooO * i1I111II1I . i11iIiiIii
III1Iiii1I11 = 'aHR0cDovL2JpdC5seS8yU1FOSnlP' . decode ( 'base64' )
IIIIiiIiI = iIiIIIi + ooo00OOOooO + IiIIIi1iIi
o00oooO0Oo = 'http://www.youtube.com'
o0O0OOO0Ooo = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
iiIiI = 'http://bit.ly/2ImelUx'
I1 = '.xsl.pt'
OOO00O0O = 'L21hc3Rlci8=' . decode ( 'base64' )
iii = o0O0OOO0Ooo + I1
oOooOOOoOo = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*'
i1Iii1i1I = 'tvg-logo=[\'"](.*?)[\'"]'
if 91 - 91: o00O0oo + OOooOOo . IIII * o00O0oo + OOooOOo * ii11ii1ii
O000OOOOOo = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.*)'
Iiii1i1 = '(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)'
OO = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
oo000o = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
iiIi1IIi1I = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
o0OoOO000ooO0 = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
o0o0o0oO0oOO = '#(.+?),(.+)\s*(.+)'
ii1Ii11I = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
if 80 - 80: II111iiii
O0Oi1I1I = 'source src=[\'"](.*?)[\'"]\s*title=[\'"](.*?)[\'"]'
iiI1I = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
IiIiiIIiI = '[\'"](.*?)[\'"]'
ooOO0OOOO0oo0 = r'066">\s*(.+)</f'
I11iiI1i1 = '[\'"](.*?)[\'"]'
I1i1Iiiii = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
if 94 - 94: o0000oOoOoO0o * o0oO0 / ii11ii1ii / o0oO0
oO0 = 'src":"(.*?)"label":"(.*?)"lang":"(.*?)"'
if 75 - 75: iI + OoOO0ooOOoo0O + o0000oOoOoO0o * O0oO % oO0o0ooO0 . O0ooOooooO
oOI1Ii1I1 = '[\'"](.*?)[\'"]'
IiII111iI1ii1 = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( 'base64' )
iI11I1II = IiII111iI1ii1 + I11i
Ii1I = '[\'"](.*?)[\'"]'
IiI1i = 'UmVhbHN0cmVhbQ==' . decode ( 'base64' )
o0O = 'video=[\'"](.*?)[\'"]'
o00iI = '0110nhu' . replace ( '0110nhu' , 'nhu' )
O0O0Oooo0o = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( 'base64' ) + o00iI
oOOoo00O00o = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
O0O00Oo = '0110R0N' . replace ( '0110R0N' , 'R0N' )
oooooo0O000o = 'aHR0cDovL2JpdC5seS8yWEIx' . decode ( 'base64' ) + O0O00Oo
OoO = '0110pEJ' . replace ( '0110pEJ' , 'pEJ' )
ooO0O0O0ooOOO = 'aHR0cDovL2JpdC5seS8yd1Nh' . decode ( 'base64' ) + OoO
oOOo0O00o = 'ABBAOb5' . replace ( 'ABBAOb5' , 'Ob5' )
iIiIi11 = 'aHR0cDovL2JpdC5seS8yRVhV' . decode ( 'base64' ) + oOOo0O00o
OOO = '0110jaw' . replace ( '0110jaw' , 'jaw' )
iiiiI = 'aHR0cDovL2JpdC5seS8yd01M' . decode ( 'base64' ) + OOO
oooOo0OOOoo0 = '01109DI' . replace ( '01109DI' , '9DI' )
OOoO = 'aHR0cDovL2JpdC5seS8ySXgz' . decode ( 'base64' ) + oooOo0OOOoo0
OO0O000 = '01103hs' . replace ( '01103hs' , '3hs' )
iiIiI1i1 = 'aHR0cDovL2JpdC5seS8zMW1U' . decode ( 'base64' ) + OO0O000
oO0O00oOOoooO = '01107DW' . replace ( '01107DW' , '7DW' )
IiIi11iI = 'aHR0cDovL2JpdC5seS8yV1ln' . decode ( 'base64' ) + oO0O00oOOoooO
Oo0O00O000 = '0110mLl' . replace ( '0110mLl' , 'mLl' )
i11I1IiII1i1i = 'aHR0cDovL2JpdC5seS8yS0cw' . decode ( 'base64' ) + Oo0O00O000
oo = '01102Hj' . replace ( '01102Hj' , '2Hj' )
I1111i = 'aHR0cDovL2JpdC5seS8yWEJo' . decode ( 'base64' ) + oo
iIIii = '0110fXg' . replace ( '0110fXg' , 'fXg' )
o00O0O = 'aHR0cDovL2JpdC5seS8ySTVy' . decode ( 'base64' ) + iIIii
ii1iii1i = '0110NMH' . replace ( '0110NMH' , 'NMH' )
Iii1I1111ii = 'aHR0cDovL2JpdC5seS8yd0t6' . decode ( 'base64' ) + ii1iii1i
ooOoO00 = '0110bwQ' . replace ( '0110bwQ' , 'bwQ' )
Ii1IIiI1i = 'aHR0cDovL2JpdC5seS8yd01V' . decode ( 'base64' ) + ooOoO00
o0O00Oo0 = '0110xzG' . replace ( '0110xzG' , 'xzG' )
IiII111i1i11 = 'aHR0cDovL2JpdC5seS8yWHhz' . decode ( 'base64' ) + o0O00Oo0
i111iIi1i1II1 = '0110x64' . replace ( '0110x64' , 'x64' )
oooO = 'aHR0cDovL2JpdC5seS8yRVlF' . decode ( 'base64' ) + i111iIi1i1II1
i1I1i111Ii = '0110vUE' . replace ( '0110vUE' , 'vUE' )
ooo = 'aHR0cDovL2JpdC5seS8yWmhW' . decode ( 'base64' ) + i1I1i111Ii
i1i1iI1iiiI = '01107ZL' . replace ( '01107ZL' , '7ZL' )
Ooo0oOooo0 = 'aHR0cDovL2JpdC5seS8yWm4w' . decode ( 'base64' ) + i1i1iI1iiiI
oOOOoo00 = '01106cf' . replace ( '01106cf' , '6cf' )
iiIiIIIiiI = 'aHR0cDovL2JpdC5seS8yRVlk' . decode ( 'base64' ) + oOOOoo00
iiI1IIIi = '0110Jtp' . replace ( '0110Jtp' , 'Jtp' )
II11IiIi11 = 'aHR0cDovL2JpdC5seS8yV3Nq' . decode ( 'base64' ) + iiI1IIIi
IIOOO0O00O0OOOO = '0110a5b' . replace ( '0110a5b' , 'a5b' )
I1iiii1I = 'aHR0cDovL2JpdC5seS8yV3dj' . decode ( 'base64' ) + IIOOO0O00O0OOOO
OOo0 = '0110Q7u' . replace ( '0110Q7u' , 'Q7u' )
oO00ooooO0o = 'aHR0cDovL2JpdC5seS8yV3NL' . decode ( 'base64' ) + OOo0
oo0o = '0110rsq' . replace ( '0110rsq' , 'rsq' )
o0oO0oooOoo = 'aHR0cDovL2JpdC5seS8ySzhE' . decode ( 'base64' ) + oo0o
I1III1111iIi = '0110DDR' . replace ( '0110DDR' , 'DDR' )
I1i111I = 'aHR0cDovL2JpdC5seS8ySzd5' . decode ( 'base64' ) + I1III1111iIi
OooOo0oo0O0o00O = '0110feQ' . replace ( '0110feQ' , 'feQ' )
I1i11 = 'aHR0cDovL2JpdC5seS8yS0cz' . decode ( 'base64' ) + OooOo0oo0O0o00O
IiIi1I1 = '0110MHY' . replace ( '0110MHY' , 'MHY' )
IiIIi1 = 'aHR0cDovL2JpdC5seS8ySXVo' . decode ( 'base64' ) + IiIi1I1
IIIIiii1IIii = '0110xdb' . replace ( '0110xdb' , 'xdb' )
II1i11I = 'aHR0cDovL2JpdC5seS8yWEJu' . decode ( 'base64' ) + IIIIiii1IIii
ii1I1IIii11 = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( 'base64' )
O0o0oO = 'aHR0cHM6Ly9uZXRhaS5ldS92aXNpdGFzL2luZGV4LnBocA==' . decode ( 'base64' )
O000OOo00oo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
IIIIiIiIi1 = '0110lxu' . replace ( '0110lxu' , 'lxu' )
I11iiiiI1i = 'aHR0cDovL2JpdC5seS8yV1Bj' . decode ( 'base64' ) + IIIIiIiIi1
iI1i11 = '0110pzp' . replace ( '0110pzp' , 'pzp' )
OoOOoooOO0O = 'aHR0cDovL2JpdC5seS8yVHpB' . decode ( 'base64' ) + iI1i11
ooo00Ooo = '01105yt' . replace ( '01105yt' , '5yt' )
Oo0o0O00 = 'aHR0cDovL2JpdC5seS8yTVpp' . decode ( 'base64' ) + ooo00Ooo
if 40 - 40: OoooooooOO
if 25 - 25: i1I111II1I + o0oO0 / iI . o0000oOoOoO0o % O0 * OoOO
o0O0oo0OO0O = '1001DTs' . replace ( '1001DTs' , 'DTs' )
OO0 = 'aHR0cDovL2JpdC5seS8ySzhP' . decode ( 'base64' ) + o0O0oo0OO0O
o0Oooo = '1001Hky' . replace ( '1001Hky' , 'Hky' )
iiI = 'aHR0cDovL2JpdC5seS8yTGVL' . decode ( 'base64' ) + o0Oooo
oOIIiIi = '1001VFU' . replace ( '1001VFU' , 'VFU' )
OOoOooOoOOOoo = 'aHR0cDovL2JpdC5seS8zMERx' . decode ( 'base64' ) + oOIIiIi
Iiii1iI1i = '3545OMZ' . replace ( '3545OMZ' , 'OMZ' )
I1ii1ii11i1I = 'aHR0cDovL2JpdC5seS8yazhk' . decode ( 'base64' ) + Iiii1iI1i
o0OoOO = '4224tZO' . replace ( '4224tZO' , 'tZO' )
O0O0Oo00 = 'aHR0cDovL2JpdC5seS8zNXd4' . decode ( 'base64' ) + o0OoOO
if 80 - 80: oO0o0ooO0 + IIII / O0oO
def oOOO00O0O0OOo ( ) :
 if 77 - 77: oO0o0ooO0 + iI . ii11ii1ii % o0oO0
 if 97 - 97: II111iiii . o0000oOoOoO0o - o00O0oo
 try :
  o0OOOo = ii1iiIiIII1ii ( oooooo0O000o )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   try :
    if 21 - 21: O0 % i1I111II1I . OOooOOo / II111iiii + i1I111II1I
    ooO0O0O0ooOOO = IiIiII1
    if 53 - 53: oO0o0ooO0 - OOooOOo - oO0o0ooO0 * O0ooOooooO
    oooooo0OO = xbmc . Keyboard ( '' , 'Busqueda por titulo' )
    oooooo0OO . doModal ( )
    if ( oooooo0OO . isConfirmed ( ) ) :
     iI1I = xbmcgui . DialogProgress ( )
     iI1I . create ( 'Realstream:' , 'Buscando ...' )
     OooOoOo = range ( 0 , 76 )
     for III1I1Iii1iiI in OooOoOo :
      III1I1Iii1iiI = III1I1Iii1iiI + 1
      if 17 - 17: o0oO0 % iIii1I11I1II1 - iIii1I11I1II1
     O0o0O0 = urllib . quote_plus ( oooooo0OO . getText ( ) ) . replace ( '+' , ' ' )
     Ii1II1I11i1 = ii1iiIiIII1ii ( ooO0O0O0ooOOO )
     oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( Ii1II1I11i1 )
     for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
      if 1 - 1: O0oO % IIII + O0 + i1IIi - OoOO
      iI1I . update ( III1I1Iii1iiI , '[COLOR orange]Realstream: Buscando ...[/COLOR]' , ' [COLOR yellow] %s [/COLOR]' % Ii111 )
      xbmc . sleep ( 1 )
      if iI1I . iscanceled ( ) : break ;
      if re . search ( O0o0O0 , iIIIII1ii1I ( Ii111 . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       if 13 - 13: i11iIiiIii + i1IIi * iIii1I11I1II1 % OoooooooOO - II111iiii * IIII
       iI1I . update ( 80 , ' [COLOR orange]Busqueda finalizada[/COLOR] ' )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR gold]Generando listado ...  [/COLOR][COLOR orange] Por favor espere ![/COLOR] ,1000)" )
       iI1I . update ( 100 , '[COLOR orange]Realstream: [/COLOR]' , '[COLOR gold] Busqueda finalizada ...[/COLOR]' )
       iI1I . close ( )
       iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
       if 68 - 68: IIII
       if 82 - 82: iIii1I11I1II1 + ii11ii1ii . iIii1I11I1II1 % i1I111II1I / o0oO0 . o0oO0
     IIi ( '[COLOR %s]Buscar Pelicula[/COLOR]' % oo00O00oO , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Resultados para: [COLOR orange]" + O0o0O0 + "[/COLOR] ,2000)" )
     if 66 - 66: oO0o0ooO0 % OoOO . IIII
   except : IIi ( '[COLOR %s]Buscar Pelicula[/COLOR]' % oo00O00oO , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
   if 86 - 86: iIii1I11I1II1
 except :
  pass
  if 76 - 76: iI + iIii1I11I1II1 / O0 / o00O0oo
  if 61 - 61: IIII % IIII * o0000oOoOoO0o / o0000oOoOoO0o
  if 75 - 75: i1I111II1I . iI
  if 50 - 50: OoOO0ooOOoo0O
def O00o0OO0000oo ( ) :
 if 27 - 27: O0
 try :
  if 79 - 79: o0000oOoOoO0o - O0oO + o0000oOoOoO0o . oO0o0ooO0
  O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'aviso' )
  if 28 - 28: i1IIi - O0ooOooooO
  if O0ii1ii1ii == 'true' :
   o0OOOo = ii1iiIiIII1ii ( IIIIiiIiI )
   oO0o0oooO0oO = re . compile ( oOooOOOoOo ) . findall ( o0OOOo )
   for o00o000oo , ii11i11i1 in oO0o0oooO0oO :
    try :
     if 53 - 53: OoooooooOO % o0oO0 . i1I111II1I / i11iIiiIii % O0ooOooooO
     if 28 - 28: O0oO
     oOOOOoo = o00o000oo
     OOo0ii11I1 = ii11i11i1
     if 75 - 75: OoOO / II111iiii % O0
     if 38 - 38: OoooooooOO * iI % O0 * OoOO0ooOOoo0O
     from datetime import datetime
     if 29 - 29: o00O0oo / i1IIi . OOooOOo - OoOO0ooOOoo0O - OoOO0ooOOoo0O - o0oO0
     IiiIiI111iI = datetime . now ( )
     OOo = IiiIiI111iI . strftime ( '%d/%m/%Y' )
     if 50 - 50: iI
     o0O0O0ooo0oOO = ii1iiIiIII1ii ( O0o0oO )
     oO0o0oooO0oO = re . compile ( ooOO0OOOO0oo0 ) . findall ( o0O0O0ooo0oOO )
     for oo000 in oO0o0oooO0oO :
      if 32 - 32: i1IIi . o0oO0
      oOO = "[B]" + oOOOOoo + "[/B]"
      Oooo = "" + OOo0ii11I1 + ""
      I1i1iiiII1i = "[COLOR white]Hoy: " + OOo + ", Es usted el visitante numero: [B][COLOR gold]" + oo000 + "[/B][/COLOR]"
      if 100 - 100: OoOO
     xbmcgui . Dialog ( ) . ok ( "Real Stream" , oOO , Oooo , I1i1iiiII1i )
     if 46 - 46: OoOO0ooOOoo0O / iIii1I11I1II1 % O0ooOooooO . iIii1I11I1II1 * O0ooOooooO
    except :
     pass
     if 38 - 38: o00O0oo - O0ooOooooO / O0 . Oooo0Ooo000
     if 45 - 45: Oooo0Ooo000
     if 83 - 83: OoOO0ooOOoo0O . OoooooooOO
     if 58 - 58: i11iIiiIii + OoooooooOO % OoooooooOO / i1I111II1I / i11iIiiIii
   Ii1II1I11i1 = ii1iiIiIII1ii ( ii1I1IIii11 )
   oO0o0oooO0oO = re . compile ( IiIiiIIiI ) . findall ( Ii1II1I11i1 )
   for oOOoo in oO0o0oooO0oO :
    try :
     if 14 - 14: o0000oOoOoO0o * oO0o0ooO0
     import xbmc
     import xbmcaddon
     if 81 - 81: o0oO0 * o0000oOoOoO0o + Oooo0Ooo000 + ii11ii1ii - OoooooooOO
     __addon__ = xbmcaddon . Addon ( )
     __addonname__ = __addon__ . getAddonInfo ( 'name' )
     __icon__ = __addon__ . getAddonInfo ( 'icon' )
     if 32 - 32: o0oO0 * O0
     iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
     O00oOo00o0o = oOOoo
     if 85 - 85: O0ooOooooO + OoooooooOO * O0ooOooooO - Oooo0Ooo000 % i11iIiiIii
     oOO = "[COLOR orange]Version instalada: [COLOR gold][B] " + iIiiiI1IiI1I1 + "[/B] [/COLOR][/COLOR][COLOR white] Disponible: [B]" + oOOoo + " [/B][/COLOR]"
     OOo00OoO = 4000
     if 10 - 10: o0000oOoOoO0o / i11iIiiIii
     xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , oOO , OOo00OoO , __icon__ ) )
     if 92 - 92: O0oO . Oooo0Ooo000
     if iIiiiI1IiI1I1 < oOOoo :
      if 85 - 85: o00O0oo . Oooo0Ooo000
      if 78 - 78: iI * Oooo0Ooo000 + iIii1I11I1II1 + iIii1I11I1II1 / Oooo0Ooo000 . o0oO0
      xbmcgui . Dialog ( ) . ok ( "Real Stream" , "[COLOR white] Existe una nueva version de [/COLOR][COLOR fuchsia]Realstream[/COLOR]" , "[COLOR orange]Actualimete tiene instalada la version[/COLOR] [COLOR white][B] %s [/B][/COLOR]" % iIiiiI1IiI1I1 , " [COLOR white]Ya esta disponible la[/COLOR] [COLOR gold][B] %s [/B][/COLOR]" % oOOoo )
      if 97 - 97: iI / Oooo0Ooo000 % i1IIi % o00O0oo
      if 18 - 18: iIii1I11I1II1 % O0oO
    except :
     pass
     if 95 - 95: iI + i11iIiiIii * Oooo0Ooo000 - i1IIi * Oooo0Ooo000 - iIii1I11I1II1
   if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 75 - 75: OoooooooOO * i1I111II1I
    if 9 - 9: i1I111II1I - II111iiii + O0 / iIii1I11I1II1 / i11iIiiIii
 except :
  pass
  if 39 - 39: i1I111II1I * ii11ii1ii + iIii1I11I1II1 - i1I111II1I + IIII
  if 69 - 69: O0
def iIIIII1ii1I ( s ) :
 if 85 - 85: iI / O0
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 18 - 18: o0000oOoOoO0o % O0 * o00O0oo
def o0Iii ( file ) :
 if 19 - 19: O0oO % II111iiii / i11iIiiIii / O0ooOooooO - OoooooooOO
 try :
  iIIiii1 = open ( file , 'r' )
  o0OOOo = iIIiii1 . read ( )
  iIIiii1 . close ( )
  return o0OOOo
 except :
  pass
  if 31 - 31: IIII + o0000oOoOoO0o . OoooooooOO
def ii1iiIiIII1ii ( url ) :
 if 89 - 89: II111iiii + i1IIi + II111iiii
 try :
  IiII1II11I = urllib2 . Request ( url )
  IiII1II11I . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  O0Oo00O = urllib2 . urlopen ( IiII1II11I )
  OOo0o000oO = O0Oo00O . read ( )
  O0Oo00O . close ( )
  return OOo0o000oO
 except urllib2 . URLError , oO0o00oOOooO0 :
  print 'We failed to open "%s".' % url
  if hasattr ( oO0o00oOOooO0 , 'code' ) :
   print 'We failed with error code - %s.' % oO0o00oOOooO0 . code
  if hasattr ( oO0o00oOOooO0 , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , oO0o00oOOooO0 . reason
   if 79 - 79: OoOO - iIii1I11I1II1 + o0oO0 - Oooo0Ooo000
def OoOiIIiii ( url ) :
 IiII1II11I = urllib2 . Request ( url )
 IiII1II11I . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 IiII1II11I . add_header ( 'Referer' , '%s' % url )
 IiII1II11I . add_header ( 'Connection' , 'keep-alive' )
 O0Oo00O = urllib2 . urlopen ( IiII1II11I )
 OOo0o000oO = O0Oo00O . read ( )
 O0Oo00O . close ( )
 return OOo0o000oO
 if 61 - 61: i1I111II1I . i1IIi / Oooo0Ooo000 % i11iIiiIii * O0ooOooooO
 if 31 - 31: IIII + O0
def oO0oOOoo00000 ( ) :
 if 52 - 52: OOooOOo
 oo00O00oO = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 if 51 - 51: i1I111II1I
 if OOO00O == 'true' :
  if 88 - 88: OoooooooOO
  IIi ( '[COLOR %s]Buscar Pelicula[/COLOR]' % oo00O00oO , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
  IIi ( '[COLOR %s]Buscar Serie[/COLOR]' % oo00O00oO , 'search' , 145 , I1IIIii , oo00 )
  IIi ( '[COLOR %s]Peliculas[/COLOR] ' % oo00O00oO , 'movieDB' , 116 , I1I , oo00 )
  IIi ( '[COLOR %s]Series[/COLOR] ' % oo00O00oO , 'movieDB' , 117 , iIi11Ii1 , oo00 )
  if 84 - 84: OoOO0ooOOoo0O / O0oO * O0ooOooooO / oO0o0ooO0 - i11iIiiIii . ii11ii1ii
  if 60 - 60: o00O0oo * OOooOOo
 if oooooOoo0ooo == 'true' :
  IIi ( '[COLOR %s]Ajustes[/COLOR]' % oo00O00oO , 'Settings' , 119 , Ii11iII1 , oo00 )
  if 17 - 17: IIII % ii11ii1ii / o00O0oo . i1I111II1I * IIII - II111iiii
  if 41 - 41: o0oO0
  if iIIIi1 == 'true' :
   oOOoo0o0OOOO ( )
   if 26 - 26: O0ooOooooO % iIii1I11I1II1 + o0000oOoOoO0o
  if I1I1IiI1 == 'true' :
   OOOooo ( )
   Oo00oo0000OO ( )
   if 69 - 69: iI - OoOO / i11iIiiIii + o00O0oo % OoooooooOO
  if O0o0O00Oo0o0 == 'false' :
   if 73 - 73: o0oO0 - Oooo0Ooo000
   oOO = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   Oooo = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Script.ResolveURL para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   I1i1iiiII1i = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 68 - 68: O0ooOooooO * OoooooooOO * iIii1I11I1II1 . II111iiii
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , oOO , Oooo , I1i1iiiII1i )
   if 81 - 81: IIII / O0 + O0oO + o0oO0 / OOooOOo
def iI1I1i1I1Iii ( ) :
 IIi ( '[COLOR orange]Buscador por id[/COLOR]' , o00oooO0Oo , 127 , oOOoo00O0O , oo00 )
 if 86 - 86: i1IIi
def IIi11IIiIii1 ( ) :
 oo00O00oO = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 IIi ( '[COLOR %s]The movie DB[/COLOR]' % oo00O00oO , 'movieDB' , 99 , oOOoo00O0O , oo00 )
 if 17 - 17: o0oO0 + oO0o0ooO0 . OoOO - ii11ii1ii * i11iIiiIii
 IIi ( '[COLOR %s]Video tutoriales[/COLOR]' % oo00O00oO , o00oooO0Oo , 125 , O0OOO0OOoO0O , oo00 )
 if 20 - 20: OOooOOo . OoooooooOO % IIII
 if 63 - 63: OOooOOo % iIii1I11I1II1
 if 39 - 39: O0ooOooooO / II111iiii / o00O0oo % OOooOOo
def O0Oo00 ( ) :
 if 41 - 41: iIii1I11I1II1 % O0oO
 oO0oOOoo00000 ( )
 IIi11IIiIii1 ( )
 if 59 - 59: IIII + i11iIiiIii
def oo0OOo0O ( ) :
 if 39 - 39: OoooooooOO + oO0o0ooO0 % IIII / IIII
 O0Oo00 ( )
 if 27 - 27: O0ooOooooO . O0oO . iIii1I11I1II1 . iIii1I11I1II1
def iIi1i ( ) :
 if xbmc . getCondVisibility ( 'System.HasAddon(script.favourites)' ) :
  try :
   xbmc . executebuiltin ( "RunScript(script.favourites)" )
  except :
   pass
def i1ii ( ) :
 IiII1IiiIiI1 . openSettings ( )
 if 68 - 68: IIII * O0 . O0oO - II111iiii . iI / II111iiii
 if 47 - 47: OoooooooOO
def ii1i1i1IiII ( ) :
 urlresolver . display_settings ( )
 if 63 - 63: O0ooOooooO . OoOO / II111iiii * i1I111II1I + oO0o0ooO0 % o0oO0
def OOOooo ( ) :
 IIi ( '[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % oo00O00oO , 'resolve' , 120 , O0o0 , oo00 )
 if 12 - 12: Oooo0Ooo000 . OoOO . O0ooOooooO - OoooooooOO % ii11ii1ii
def i11i1iIiii ( ) :
 if 71 - 71: o00O0oo % iI - OOooOOo % O0oO - O0
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 67 - 67: IIII + ii11ii1ii
def Oo00oo0000OO ( ) :
 IIi ( '[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % oo00O00oO , 'resolve' , 140 , O0o0 , oo00 )
 if 84 - 84: O0 * OoooooooOO - i1I111II1I * i1I111II1I
def oOOoo0o0OOOO ( ) :
 if 8 - 8: iI / i1IIi . oO0o0ooO0
 oo00O00oO = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 IIi ( '[COLOR %s]Buscador[/COLOR]' % oo00O00oO , 'search' , 111 , o0oOoO00o , oo00 )
 IIi ( '[COLOR %s]Estrenos[/COLOR]' % oo00O00oO , o00oooO0Oo , 3 , i11 , oo00 )
 IIi ( '[COLOR %s]Todas[/COLOR]' % oo00O00oO , o00oooO0Oo , 26 , I11 , oo00 )
 IIi ( '[COLOR %s]4K[/COLOR]' % oo00O00oO , o00oooO0Oo , 141 , O0o0Oo , oo00 )
 IIi ( '[COLOR %s]Novedades[/COLOR]' % oo00O00oO , o00oooO0Oo , 2 , i1111 , oo00 )
 IIi ( '[COLOR %s]Accion[/COLOR]' % oo00O00oO , o00oooO0Oo , 5 , Oo0o0000o0o0 , oo00 )
 IIi ( '[COLOR %s]Animacion[/COLOR]' % oo00O00oO , o00oooO0Oo , 6 , oOo0oooo00o , oo00 )
 IIi ( '[COLOR %s]Artes Marciales[/COLOR]' % oo00O00oO , o00oooO0Oo , 29 , o0 , oo00 )
 IIi ( '[COLOR %s]Aventuras[/COLOR]' % oo00O00oO , o00oooO0Oo , 7 , oO0o0o0ooO0oO , oo00 )
 IIi ( '[COLOR %s]Belico[/COLOR]' % oo00O00oO , o00oooO0Oo , 8 , oo0o0O00 , oo00 )
 IIi ( '[COLOR %s]Ciencia Ficcion[/COLOR]' % oo00O00oO , o00oooO0Oo , 9 , oO , oo00 )
 IIi ( '[COLOR %s]Cine Clasico[/COLOR]' % oo00O00oO , o00oooO0Oo , 30 , i1iiIIiiI111 , oo00 )
 IIi ( '[COLOR %s]Comedia[/COLOR]' % oo00O00oO , o00oooO0Oo , 10 , oooOOOOO , oo00 )
 IIi ( '[COLOR %s]Crimen[/COLOR]' % oo00O00oO , o00oooO0Oo , 11 , i1iiIII111ii , oo00 )
 IIi ( '[COLOR %s]Drama[/COLOR]' % oo00O00oO , o00oooO0Oo , 12 , i1iIIi1 , oo00 )
 IIi ( '[COLOR %s]Familiar[/COLOR]' % oo00O00oO , o00oooO0Oo , 13 , ii11iIi1I , oo00 )
 IIi ( '[COLOR %s]Fantasia[/COLOR]' % oo00O00oO , o00oooO0Oo , 14 , iI111I11I1I1 , oo00 )
 IIi ( '[COLOR %s]Historia[/COLOR]' % oo00O00oO , o00oooO0Oo , 15 , OOooO0OOoo , oo00 )
 IIi ( '[COLOR %s]Misterio[/COLOR]' % oo00O00oO , o00oooO0Oo , 16 , oOOoO0 , oo00 )
 IIi ( '[COLOR %s]Musical[/COLOR]' % oo00O00oO , o00oooO0Oo , 17 , O0OoO000O0OO , oo00 )
 IIi ( '[COLOR %s]Romance[/COLOR]' % oo00O00oO , o00oooO0Oo , 18 , iiI1IiI , oo00 )
 IIi ( '[COLOR %s]Thriller[/COLOR]' % oo00O00oO , o00oooO0Oo , 19 , II11iiii1Ii , oo00 )
 IIi ( '[COLOR %s]Suspense[/COLOR]' % oo00O00oO , o00oooO0Oo , 20 , ooOoOoo0O , oo00 )
 IIi ( '[COLOR %s]Terror[/COLOR]' % oo00O00oO , o00oooO0Oo , 21 , OooO0 , oo00 )
 IIi ( '[COLOR %s]Western[/COLOR]' % oo00O00oO , o00oooO0Oo , 22 , OO0o , oo00 )
 IIi ( '[COLOR %s]Spain[/COLOR]' % oo00O00oO , o00oooO0Oo , 23 , II , oo00 )
 IIi ( '[COLOR %s]Super heroes[/COLOR]' % oo00O00oO , o00oooO0Oo , 24 , iIii1 , oo00 )
 IIi ( '[COLOR %s]Sagas[/COLOR]' % oo00O00oO , o00oooO0Oo , 25 , Ooo , oo00 )
 if 41 - 41: O0ooOooooO + OoOO
def oOOiiiIIiIi ( ) :
 if 68 - 68: O0 + OoOO0ooOOoo0O / oO0o0ooO0 - IIII + iIii1I11I1II1 % o0oO0
 IIi ( '[COLOR %s]Buscar Serie[/COLOR]' % oo00O00oO , 'search' , 145 , O0OO00o0OO , oo00 )
 if 23 - 23: iI % o0000oOoOoO0o / O0oO
 i11I1II ( )
 if 79 - 79: OoOO . O0ooOooooO * o0oO0 - IIII + iI
 IIi ( '[COLOR %s]En emision[/COLOR]' % oo00O00oO , o00oooO0Oo , 150 , I11II1i , oo00 )
 IIi ( '[COLOR %s]Mejor valoradas[/COLOR]' % oo00O00oO , o00oooO0Oo , 151 , IIIII , oo00 )
 IIi ( '[COLOR %s]Series Retro[/COLOR]' % oo00O00oO , o00oooO0Oo , 152 , ooooooO0oo , oo00 )
 IIi ( '[COLOR %s]Todas[/COLOR]' % oo00O00oO , o00oooO0Oo , 142 , I11i1 , oo00 )
 if 14 - 14: i11iIiiIii - O0ooOooooO * OoOO0ooOOoo0O
def i11I1II ( ) :
 if 51 - 51: o00O0oo / iIii1I11I1II1 % oO0o0ooO0 + o0000oOoOoO0o * iI + Oooo0Ooo000
 o0OoO00o0000O = 'aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtLw==' . decode ( 'base64' )
 II11I = 'Y29uZGljaW9uLnR4dA==' . decode ( 'base64' )
 OOo0o000oO = o0OoO00o0000O + II11I
 OooOOO0O00 = '[\'"](.*?)[\'"]'
 oOOiiiIIiIi = ii1iiIiIII1ii ( OOo0o000oO )
 oO0o0oooO0oO = re . compile ( OooOOO0O00 ) . findall ( oOOiiiIIiIi )
 for IIii1i1iii1 in oO0o0oooO0oO :
  try :
   if 70 - 70: i11iIiiIii % O0ooOooooO
   if IIii1i1iii1 == 'si' :
    if 11 - 11: i1I111II1I % o00O0oo % o0oO0 / II111iiii % Oooo0Ooo000 - ii11ii1ii
    IIi ( '[COLOR %s]Hay Nuevos Episodios[/COLOR]' % oo00O00oO , o00oooO0Oo , 155 , OOOO , oo00 )
    if 96 - 96: o00O0oo / II111iiii . o0oO0 - O0ooOooooO * O0oO * oO0o0ooO0
   elif IIii1i1iii1 == 'no' :
    if 76 - 76: o0oO0 - II111iiii * IIII / OoooooooOO
    IIi ( '[COLOR %s]No hay Nuevos Episodios[/COLOR]' % oo00O00oO , o00oooO0Oo , 155 , oOoOooOo0o0 , oo00 )
    if 18 - 18: OoOO + iIii1I11I1II1 - II111iiii - OOooOOo
   return
   if 71 - 71: OoooooooOO
  except :
   pass
   if 33 - 33: Oooo0Ooo000
def OOO0ooo ( ) :
 if 7 - 7: o0000oOoOoO0o + i1IIi . OOooOOo / ii11ii1ii
 if 22 - 22: iI - iI % IIII . Oooo0Ooo000 + oO0o0ooO0
 try :
  if 63 - 63: OOooOOo % Oooo0Ooo000 * o0000oOoOoO0o + Oooo0Ooo000 / ii11ii1ii % O0ooOooooO
  iiI1i1Iii111 = ii1iiIiIII1ii ( OO0 )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( iiI1i1Iii111 )
  for IiIiII1 in oO0o0oooO0oO :
   if 43 - 43: o0000oOoOoO0o
   try :
    if 71 - 71: oO0o0ooO0 % O0oO * OoOO0ooOOoo0O . O0 / o0oO0 . o00O0oo
    oOOOo = IiIiII1
    oooooo0OO = xbmc . Keyboard ( '' , 'Buscar' )
    oooooo0OO . doModal ( )
    if ( oooooo0OO . isConfirmed ( ) ) :
     iI1I = xbmcgui . DialogProgress ( )
     iI1I . create ( 'Realstream:' , 'Buscando ...' )
     OooOoOo = range ( 0 , 69 )
     for III1I1Iii1iiI in OooOoOo :
      III1I1Iii1iiI = III1I1Iii1iiI + 1
     O0o0O0 = urllib . quote_plus ( oooooo0OO . getText ( ) ) . replace ( '+' , ' ' )
     Ii1II1I11i1 = ii1iiIiIII1ii ( oOOOo )
     oO0o0oooO0oO = re . compile ( OO ) . findall ( Ii1II1I11i1 )
     for OO0O0o0o0 , Ii111 , oo00 , I111i1i1111 , I1I1i in oO0o0oooO0oO :
      iI1I . update ( III1I1Iii1iiI , '[COLOR orange]Realstream: Buscando ...[/COLOR]' , '[COLOR gold] %s [/COLOR]' % Ii111 )
      xbmc . sleep ( 5 )
      if iI1I . iscanceled ( ) : break ;
      if re . search ( O0o0O0 , iIIIII1ii1I ( Ii111 . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       if 31 - 31: o0oO0
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Generando listado ...  [COLOR orange] Por favor espere ![/COLOR] , 4000)" )
       iIIiI1I1i ( Ii111 , I111i1i1111 , 143 , OO0O0o0o0 , oo00 , I1I1i )
       iI1I . update ( 100 , '[COLOR orange]Realstream: [/COLOR]' , '[COLOR gold] Busqueda finalizada ...[/COLOR]' )
       xbmc . sleep ( 2000 )
       iI1I . close ( )
     IIi ( '[COLOR %s]Buscar Serie[/COLOR]' % oo00O00oO , 'search' , 145 , O0OO00o0OO , oo00 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Sin Resultados para: [COLOR orange]" + O0o0O0 + "[/COLOR] , 2000)" )
     if 68 - 68: O0oO % Oooo0Ooo000 + o00O0oo - i11iIiiIii . o0000oOoOoO0o - Oooo0Ooo000
     if 31 - 31: OOooOOo * oO0o0ooO0 + OoooooooOO - O0ooOooooO / OoooooooOO
   except : IIi ( '[COLOR %s]Buscar Serie[/COLOR]' % oo00O00oO , 'search' , 145 , O0OO00o0OO , oo00 )
   if 19 - 19: i1I111II1I * iI * o0000oOoOoO0o + O0 / O0
 except :
  pass
  if 73 - 73: iIii1I11I1II1 / iIii1I11I1II1 - oO0o0ooO0
def oOoOOOo ( ) :
 if 43 - 43: i1IIi
 try :
  if 23 - 23: O0ooOooooO + O0oO . OoOO0ooOOoo0O * OOooOOo + o00O0oo
  iiI1i1Iii111 = ii1iiIiIII1ii ( O0O0Oo00 )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( iiI1i1Iii111 )
  for IiIiII1 in oO0o0oooO0oO :
   if 18 - 18: i1I111II1I * o0000oOoOoO0o . i1I111II1I / O0
   try :
    if 8 - 8: o0000oOoOoO0o
    oOOOo = IiIiII1
    if 4 - 4: o00O0oo + o00O0oo * iI - OoOO0ooOOoo0O
   except :
    pass
    if 78 - 78: o0oO0 / II111iiii % OoOO0ooOOoo0O
  Ii1II1I11i1 = ii1iiIiIII1ii ( oOOOo )
  oO0o0oooO0oO = re . compile ( OO ) . findall ( Ii1II1I11i1 )
  for OO0O0o0o0 , Ii111 , oo00 , I111i1i1111 , I1I1i in oO0o0oooO0oO :
   try :
    if 52 - 52: IIII - O0ooOooooO * oO0o0ooO0
    iIIiI1I1i ( Ii111 , I111i1i1111 , 143 , OO0O0o0o0 , oo00 , I1I1i )
    if 17 - 17: OoooooooOO + IIII * O0oO * OoOO0ooOOoo0O
   except :
    pass
 except :
  pass
  if 36 - 36: O0 + ii11ii1ii
def iIIIi1i1I11i ( ) :
 if 55 - 55: ii11ii1ii - IIII
 try :
  if 84 - 84: Oooo0Ooo000 + ii11ii1ii - OoOO0ooOOoo0O * OoOO0ooOOoo0O
  iiI1i1Iii111 = ii1iiIiIII1ii ( I1ii1ii11i1I )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( iiI1i1Iii111 )
  for IiIiII1 in oO0o0oooO0oO :
   if 61 - 61: OoooooooOO . oO0o0ooO0 . OoooooooOO / ii11ii1ii
   try :
    if 72 - 72: i1IIi
    oOOOo = IiIiII1
    if 82 - 82: OoOO0ooOOoo0O + OoooooooOO / i11iIiiIii * o00O0oo . OoooooooOO
   except :
    pass
    if 63 - 63: o00O0oo
  Ii1II1I11i1 = ii1iiIiIII1ii ( oOOOo )
  oO0o0oooO0oO = re . compile ( OO ) . findall ( Ii1II1I11i1 )
  for OO0O0o0o0 , Ii111 , oo00 , I111i1i1111 , I1I1i in oO0o0oooO0oO :
   try :
    if 6 - 6: iI / o00O0oo
    iIIiI1I1i ( Ii111 , I111i1i1111 , 143 , OO0O0o0o0 , oo00 , I1I1i )
    if 57 - 57: O0oO
   except :
    pass
 except :
  pass
  if 67 - 67: OoOO . iI
  if 87 - 87: oO0o0ooO0 % o0oO0
def oo0OOOoOo ( ) :
 if 21 - 21: OoOO - O0 . oO0o0ooO0 + o0oO0 . iIii1I11I1II1 - OoOO0ooOOoo0O
 try :
  if 14 - 14: i1I111II1I % oO0o0ooO0 % ii11ii1ii - i11iIiiIii
  iiI1i1Iii111 = ii1iiIiIII1ii ( OOoOooOoOOOoo )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( iiI1i1Iii111 )
  for IiIiII1 in oO0o0oooO0oO :
   if 53 - 53: o0oO0 % ii11ii1ii
   try :
    if 59 - 59: IIII % iIii1I11I1II1 . i1IIi + II111iiii * i1I111II1I
    oOOOo = IiIiII1
    if 41 - 41: o0oO0 % o00O0oo
   except :
    pass
    if 12 - 12: IIII
  Ii1II1I11i1 = ii1iiIiIII1ii ( oOOOo )
  oO0o0oooO0oO = re . compile ( OO ) . findall ( Ii1II1I11i1 )
  for OO0O0o0o0 , Ii111 , oo00 , I111i1i1111 , I1I1i in oO0o0oooO0oO :
   try :
    if 69 - 69: OoooooooOO + IIII
    iIIiI1I1i ( Ii111 , I111i1i1111 , 143 , OO0O0o0o0 , oo00 , I1I1i )
    if 26 - 26: ii11ii1ii + IIII / OoOO % OoOO0ooOOoo0O % o00O0oo + II111iiii
   except :
    pass
 except :
  pass
  if 31 - 31: O0oO % IIII * O0oO
def IiI ( ) :
 if 34 - 34: O0oO % iI . O0 . iIii1I11I1II1
 try :
  if 93 - 93: i1IIi . i11iIiiIii . ii11ii1ii
  iiI1i1Iii111 = ii1iiIiIII1ii ( iiI )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( iiI1i1Iii111 )
  for IiIiII1 in oO0o0oooO0oO :
   if 99 - 99: O0oO - Oooo0Ooo000 - oO0o0ooO0 % OoOO
   try :
    if 21 - 21: II111iiii % o00O0oo . i1IIi - OoooooooOO
    oOOOo = IiIiII1
    if 4 - 4: OoooooooOO . iI
   except :
    pass
    if 78 - 78: o00O0oo + O0oO - O0
  Ii1II1I11i1 = ii1iiIiIII1ii ( oOOOo )
  oO0o0oooO0oO = re . compile ( OO ) . findall ( Ii1II1I11i1 )
  for OO0O0o0o0 , Ii111 , oo00 , I111i1i1111 , I1I1i in oO0o0oooO0oO :
   try :
    if 10 - 10: Oooo0Ooo000 % OOooOOo
    iIIiI1I1i ( Ii111 , I111i1i1111 , 143 , OO0O0o0o0 , oo00 , I1I1i )
    if 97 - 97: OoooooooOO - Oooo0Ooo000
   except :
    pass
 except :
  pass
  if 58 - 58: iIii1I11I1II1 + O0
def I111I11I111 ( ) :
 if 46 - 46: i11iIiiIii - O0 . oO0o0ooO0
 try :
  if 100 - 100: OOooOOo / o0000oOoOoO0o * O0ooOooooO . O0 / IIII
  iiI1i1Iii111 = ii1iiIiIII1ii ( OO0 )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( iiI1i1Iii111 )
  for IiIiII1 in oO0o0oooO0oO :
   if 83 - 83: Oooo0Ooo000
   try :
    if 48 - 48: II111iiii * IIII * Oooo0Ooo000
    oOOOo = IiIiII1
    if 50 - 50: i1I111II1I % i1IIi
   except :
    pass
    if 21 - 21: OoooooooOO - iIii1I11I1II1
  Ii1II1I11i1 = ii1iiIiIII1ii ( oOOOo )
  oO0o0oooO0oO = re . compile ( OO ) . findall ( Ii1II1I11i1 )
  for OO0O0o0o0 , Ii111 , oo00 , I111i1i1111 , I1I1i in oO0o0oooO0oO :
   try :
    if 93 - 93: oO0o0ooO0 - o0000oOoOoO0o % OoOO0ooOOoo0O . OoOO0ooOOoo0O - iI
    iIIiI1I1i ( Ii111 , I111i1i1111 , 143 , OO0O0o0o0 , oo00 , I1I1i )
    if 90 - 90: iI + II111iiii * o00O0oo / o0oO0 . o0000oOoOoO0o + o0000oOoOoO0o
   except :
    pass
 except :
  pass
  if 40 - 40: iI / OoOO0ooOOoo0O % i11iIiiIii % o00O0oo / OOooOOo
def ooOOOOo0 ( name , url ) :
 if 38 - 38: OoooooooOO / o00O0oo . O0 / i1IIi / ii11ii1ii + iIii1I11I1II1
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 96 - 96: O0ooOooooO
 i1I11iIII1i1I = ii1iiIiIII1ii ( url )
 oO0o0oooO0oO = re . compile ( iiIi1IIi1I ) . findall ( i1I11iIII1i1I )
 for OO0O0o0o0 , name , oo00 , url in oO0o0oooO0oO :
  try :
   if 63 - 63: ii11ii1ii + Oooo0Ooo000 - II111iiii
   if 2 - 2: i1I111II1I
   oOOo0 = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % oOOo0 + name + '[/COLOR]'
   oOo0O0O0 ( name , url , 144 , OO0O0o0o0 , oo00 )
   if 89 - 89: oO0o0ooO0 / OoooooooOO . O0ooOooooO
   if 34 - 34: O0ooOooooO - OoooooooOO . OOooOOo / II111iiii
  except :
   pass
   if 27 - 27: OoOO / ii11ii1ii * iI - OoOO
   if 19 - 19: O0oO
   if 67 - 67: O0 % iIii1I11I1II1 / i1I111II1I . i11iIiiIii - o0oO0 + O0
def oOo0O0O0 ( name , url , mode , iconimage , fanart ) :
 if 27 - 27: IIII
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 89 - 89: II111iiii / oO0o0ooO0
 IIo0OoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage="
 IIIIIiII1 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 IIIIIiII1 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IIIIIiII1 . setProperty ( 'fanart_image' , fanart )
 IIIIIiII1 . setProperty ( 'IsPlayable' , 'true' )
 iii11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIo0OoO00 , listitem = IIIIIiII1 )
 return iii11
 if 35 - 35: Oooo0Ooo000 . OoOO0ooOOoo0O * i11iIiiIii
 if 44 - 44: i11iIiiIii / ii11ii1ii
def Ii1IIi ( name , url ) :
 if 43 - 43: Oooo0Ooo000 % O0ooOooooO
 if 69 - 69: O0ooOooooO % OoOO
 O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 o00iI = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 O0O0Oooo0o = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 oOOoO = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 o0OOOo = ii1iiIiIII1ii ( O0O0Oooo0o )
 oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
 for iIi11ii in oO0o0oooO0oO :
  if 50 - 50: o0oO0 / OoOO0ooOOoo0O * o0oO0
  try :
   if 34 - 34: O0 * O0 % OoooooooOO + O0ooOooooO * iIii1I11I1II1 % o0oO0
   if 25 - 25: O0oO + OoOO0ooOOoo0O . o0000oOoOoO0o % OoOO0ooOOoo0O * IIII
   O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 32 - 32: i11iIiiIii - Oooo0Ooo000
   if 53 - 53: OoooooooOO - i1I111II1I
   if O00O0oOO00O00 == iIi11ii :
    if 87 - 87: oO0o0ooO0 . OOooOOo
    if 17 - 17: o0oO0 . i11iIiiIii
    if 'https://team.com' in url :
     if 5 - 5: o00O0oo + O0 + O0 . Oooo0Ooo000 - iI
     url = url . replace ( 'https://team.com' , 'https://verystream.com' )
     if 63 - 63: oO0o0ooO0
    if 'https://mybox.com' in url :
     if 71 - 71: i1IIi . o0oO0 * O0ooOooooO % OoooooooOO + IIII
     url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
     if 36 - 36: i1I111II1I
     if 49 - 49: IIII / OoooooooOO / OOooOOo
    if 'https://vidcloud.co/' in url :
     if 74 - 74: Oooo0Ooo000 % o00O0oo
     url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
     if 7 - 7: II111iiii
    if 'https://gounlimited.to' in url :
     if 27 - 27: oO0o0ooO0 . OoooooooOO + i11iIiiIii
     url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
     if 86 - 86: O0oO / o0000oOoOoO0o - o0000oOoOoO0o + o00O0oo + oO0o0ooO0
    if 'https://drive.com' in url :
     if 33 - 33: o0000oOoOoO0o . O0ooOooooO . i1I111II1I . i1IIi
     url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
     if 49 - 49: o00O0oo
     if 84 - 84: O0oO - ii11ii1ii / O0 - Oooo0Ooo000
    import resolveurl
    if 21 - 21: O0 * O0 % o00O0oo
    o00ooo = urlresolver . HostedMediaFile ( url )
    if 31 - 31: O0 * o0000oOoOoO0o % o0000oOoOoO0o / oO0o0ooO0 / O0oO / OoOO
    if not o00ooo :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
     return False
     if 11 - 11: OoOO0ooOOoo0O + i1I111II1I - OoooooooOO / OoOO
    try :
     iI1I = xbmcgui . DialogProgress ( )
     iI1I . create ( 'Realstream:' , 'Iniciando ...' )
     iI1I . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
     xbmc . sleep ( 1000 )
     iIIi1iI1I1IIi = o00ooo . resolve ( )
     if not iIIi1iI1I1IIi or not isinstance ( iIIi1iI1I1IIi , basestring ) :
      try : O0OO0 = iIIi1iI1I1IIi . msg
      except : O0OO0 = url
      raise Exception ( O0OO0 )
      if 99 - 99: iI - OOooOOo / i1I111II1I / i11iIiiIii
    except Exception as oO0o00oOOooO0 :
     try : O0OO0 = str ( oO0o00oOOooO0 )
     except : O0OO0 = url
     iI1I . update ( 45 , 'RESOLVEURL:' , 'Reiniciando ... ' )
     xbmc . sleep ( 1000 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Episodio no disponible.  ,3000)" )
     iI1I . close ( )
     if 83 - 83: o00O0oo / Oooo0Ooo000 - i11iIiiIii . iIii1I11I1II1 + ii11ii1ii
    iI1I . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    iI1I . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
    xbmc . sleep ( 500 )
    iI1I . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
    xbmc . sleep ( 500 )
    iI1I . update ( 100 , 'RESOLVEURL:' , 'Disfrute de este capitulo!' )
    iI1I . close ( )
    i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
    ooO0000o00O = xbmcgui . ListItem ( path = iIIi1iI1I1IIi )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
    if 91 - 91: O0oO / O0 - o0oO0 . OOooOOo
    if 82 - 82: i1I111II1I * IIII / oO0o0ooO0
   else :
    if 2 - 2: OOooOOo + o0000oOoOoO0o . o0000oOoOoO0o . O0 / O0oO
    i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
    if i1Oo00 == 'true' :
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Por favor compruebe los ajustes de realstream.[/COLOR]" , "[COLOR white] Desde la seccion Tutoriales puede sacarle mayor partido a su Realstream, tambien puede configurarlo a su gusto. [/COLOR]" , "[COLOR gold]El addon no esta activado o bien configurado.[/COLOR]" )
     if 40 - 40: o0000oOoOoO0o - II111iiii / ii11ii1ii
     oo00O00oO = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
     IIi ( '[COLOR %s]Video tutoriales[/COLOR]' % oo00O00oO , o00oooO0Oo , 125 , O0OOO0OOoO0O , oo00 )
  except :
   pass
   if 14 - 14: o00O0oo
   if 5 - 5: o0000oOoOoO0o . iIii1I11I1II1 % iIii1I11I1II1
   if 56 - 56: OoooooooOO - O0oO - i1IIi
   if 8 - 8: Oooo0Ooo000 / IIII . OOooOOo + o00O0oo / i11iIiiIii
   if 31 - 31: iI - iIii1I11I1II1 + O0ooOooooO . ii11ii1ii / i1I111II1I % iIii1I11I1II1
def I11i1iIiiIiIi ( ) :
 if 49 - 49: IIII . o00O0oo . i11iIiiIii - II111iiii / o0oO0
 if 62 - 62: IIII
 i1I1i = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 i1I1i . doModal ( )
 if not i1I1i . isConfirmed ( ) :
  return None ;
 Ii111 = i1I1i . getText ( ) . strip ( )
 if 87 - 87: ii11ii1ii / O0 * i1I111II1I / o0000oOoOoO0o
 if 19 - 19: Oooo0Ooo000 + i1IIi . OOooOOo - ii11ii1ii
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 16 - 16: oO0o0ooO0 + iI / o0000oOoOoO0o
  O00oOoo0OoO0 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + Ii111 + '&language=es-ES' ) )
  if 62 - 62: i1IIi / iI . OOooOOo * o0000oOoOoO0o
  if 21 - 21: o0000oOoOoO0o
  return 'android'
  if 81 - 81: O0oO / iIii1I11I1II1 - iI * Oooo0Ooo000 . OOooOOo * o00O0oo
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 95 - 95: OOooOOo
  O00oOoo0OoO0 = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + Ii111 + '&language=es-ES' )
  if 88 - 88: i1I111II1I % OoOO + Oooo0Ooo000 + Oooo0Ooo000 * II111iiii
  if 78 - 78: OoooooooOO
  return 'windows'
  if 77 - 77: o00O0oo / i1IIi / ii11ii1ii % IIII
  if 48 - 48: O0oO - i1I111II1I + iIii1I11I1II1 + OoooooooOO
def Ii ( ) :
 if 42 - 42: o0oO0 * Oooo0Ooo000 . i1I111II1I * OOooOOo + OoOO0ooOOoo0O
 try :
  if 25 - 25: O0oO . OOooOOo + oO0o0ooO0
  o0OOOo = ii1iiIiIII1ii ( oooooo0O000o )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 75 - 75: i1I111II1I - o0000oOoOoO0o % O0ooOooooO + i11iIiiIii
   try :
    if 100 - 100: O0oO + o0000oOoOoO0o - i11iIiiIii - II111iiii
    all = IiIiII1
    if 40 - 40: OoOO0ooOOoo0O % OoOO
   except :
    pass
    if 62 - 62: o0000oOoOoO0o
  i1I11iIII1i1I = ii1iiIiIII1ii ( all )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( i1I11iIII1i1I )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    if 15 - 15: O0oO + o0oO0 . IIII * OoOO . OoOO0ooOOoo0O
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 18 - 18: i1IIi % II111iiii + Oooo0Ooo000 % o0oO0
   except :
    pass
 except :
  pass
  if 72 - 72: iIii1I11I1II1
def iI1I1II1 ( ) :
 if 92 - 92: OoooooooOO - OoooooooOO * OoOO % OOooOOo
 try :
  if 77 - 77: iIii1I11I1II1 - i1IIi . oO0o0ooO0
  i1111 = ii1iiIiIII1ii ( ooO0O0O0ooOOO )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( i1111 )
  for IiIiII1 in oO0o0oooO0oO :
   if 26 - 26: o0000oOoOoO0o * i1I111II1I . i1IIi
   try :
    if 59 - 59: O0 + i1IIi - o0000oOoOoO0o
    oOOOo = IiIiII1
    if 62 - 62: i11iIiiIii % IIII . i1I111II1I . IIII
   except :
    pass
    if 84 - 84: i11iIiiIii * OoOO
  Ii1II1I11i1 = ii1iiIiIII1ii ( oOOOo )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( Ii1II1I11i1 )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    if 18 - 18: IIII - o0oO0 - OoOO0ooOOoo0O / Oooo0Ooo000 - O0
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 30 - 30: O0 + o00O0oo + II111iiii
   except :
    pass
 except :
  pass
  if 14 - 14: o0000oOoOoO0o / IIII - iIii1I11I1II1 - oO0o0ooO0 % iI
def I1iIiI1IiIIII ( ) :
 if 18 - 18: iI % i11iIiiIii . iIii1I11I1II1 - O0ooOooooO
 try :
  if 80 - 80: OOooOOo + oO0o0ooO0 - i1IIi . o0oO0 / o0000oOoOoO0o / OOooOOo
  i11 = ii1iiIiIII1ii ( iIiIi11 )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( i11 )
  for IiIiII1 in oO0o0oooO0oO :
   if 1 - 1: O0oO + i11iIiiIii - OOooOOo / IIII + Oooo0Ooo000
   try :
    OO0OO0O = IiIiII1
   except :
    pass
    if 75 - 75: O0oO / o0000oOoOoO0o / IIII / i1I111II1I % iI + II111iiii
  o0OOOo = ii1iiIiIII1ii ( OO0OO0O )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    if 4 - 4: O0ooOooooO - ii11ii1ii - i1I111II1I - O0oO % i11iIiiIii / OoOO
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 50 - 50: iI + i1IIi
   except :
    pass
 except :
  pass
  if 31 - 31: o0oO0
def OoOOo00 ( ) :
 if 53 - 53: i1I111II1I . Oooo0Ooo000 % iIii1I11I1II1 % OoOO0ooOOoo0O % O0oO
 try :
  if 53 - 53: Oooo0Ooo000
  o0OOOo = ii1iiIiIII1ii ( db2 )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 69 - 69: OoOO0ooOOoo0O . o0000oOoOoO0o . OOooOOo - o00O0oo
   try :
    if 32 - 32: OoooooooOO / OOooOOo / iIii1I11I1II1 + II111iiii . oO0o0ooO0 . o0000oOoOoO0o
    ii1ii = IiIiII1
    if 8 - 8: OoOO + OoOO0ooOOoo0O . iIii1I11I1II1 % O0
   except :
    pass
    if 43 - 43: o00O0oo - O0ooOooooO
    if 70 - 70: O0ooOooooO / IIII % iI - o0oO0
  o0OOOo = ii1iiIiIII1ii ( ii1ii )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 47 - 47: O0ooOooooO
   except :
    pass
 except :
  pass
  if 92 - 92: IIII + OoOO0ooOOoo0O % i1IIi
def I1I1I11Ii ( ) :
 if 48 - 48: OoooooooOO + oO0o0ooO0 % iIii1I11I1II1
 try :
  if 11 - 11: OOooOOo % o0oO0 - OoOO - oO0o0ooO0 + o0000oOoOoO0o
  o0O0O0 = ii1iiIiIII1ii ( OoOOoooOO0O )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0O0O0 )
  for IiIiII1 in oO0o0oooO0oO :
   if 55 - 55: O0 - Oooo0Ooo000
   try :
    if 58 - 58: OoOO0ooOOoo0O - O0ooOooooO - OoooooooOO
    o00ii111Iiii = IiIiII1
    if 54 - 54: OoooooooOO - OOooOOo % o00O0oo
   except :
    pass
    if 92 - 92: OoOO * iI
    if 35 - 35: i11iIiiIii
  o0OOOo = ii1iiIiIII1ii ( o00ii111Iiii )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    if 99 - 99: II111iiii . o0000oOoOoO0o + O0
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 71 - 71: i1I111II1I + i1IIi * ii11ii1ii % ii11ii1ii / ii11ii1ii
   except :
    pass
 except :
  pass
  if 55 - 55: OoooooooOO + Oooo0Ooo000 + OoooooooOO * iI
def ooo0oOOO0 ( ) :
 if 61 - 61: o0000oOoOoO0o / OoOO0ooOOoo0O - ii11ii1ii
 try :
  if 19 - 19: O0ooOooooO - o0000oOoOoO0o / o0000oOoOoO0o + ii11ii1ii
  o0OOOo = ii1iiIiIII1ii ( iiiiI )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 98 - 98: iIii1I11I1II1 % IIII + O0oO . iI
   try :
    if 99 - 99: O0 + O0 * O0oO + O0 * oO0o0ooO0
    oOoO0O00oo = IiIiII1
    if 93 - 93: o00O0oo % OoOO0ooOOoo0O . O0 / O0ooOooooO * oO0o0ooO0
   except :
    pass
    if 29 - 29: o0000oOoOoO0o
    if 86 - 86: II111iiii . i1I111II1I
  o0OOOo = ii1iiIiIII1ii ( oOoO0O00oo )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 2 - 2: OoooooooOO
   except :
    pass
 except :
  pass
  if 60 - 60: OoOO
def oO00Ooo0oO ( ) :
 if 100 - 100: OoOO / i1IIi - OOooOOo % o0oO0 - iIii1I11I1II1
 try :
  if 17 - 17: O0oO / o0000oOoOoO0o % ii11ii1ii
  o0OOOo = ii1iiIiIII1ii ( OOoO )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 71 - 71: i1I111II1I . Oooo0Ooo000 . OoOO
   try :
    if 68 - 68: i11iIiiIii % oO0o0ooO0 * OoOO * i1I111II1I * II111iiii + O0
    o00OoO0oO00 = IiIiII1
    if 2 - 2: iIii1I11I1II1
   except :
    pass
    if 45 - 45: OoooooooOO / i11iIiiIii
  o0OOOo = ii1iiIiIII1ii ( o00OoO0oO00 )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 10 - 10: O0ooOooooO - oO0o0ooO0 * iIii1I11I1II1 % iIii1I11I1II1 * i1I111II1I - o00O0oo
   except :
    pass
 except :
  pass
  if 97 - 97: II111iiii % Oooo0Ooo000 + Oooo0Ooo000 - OoOO / o0oO0 * OOooOOo
def iIii1iII1Ii ( ) :
 if 50 - 50: o0oO0
 try :
  if 22 - 22: O0oO * O0 . II111iiii - OoOO
  o0OOOo = ii1iiIiIII1ii ( iiIiI1i1 )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 90 - 90: oO0o0ooO0
   try :
    if 94 - 94: O0oO / o00O0oo * Oooo0Ooo000 - OoOO0ooOOoo0O
    I1Ii11II1I1 = IiIiII1
    if 41 - 41: O0 * iI - OoOO0ooOOoo0O . o0oO0
   except :
    pass
    if 65 - 65: ii11ii1ii . OoooooooOO
    if 70 - 70: ii11ii1ii - oO0o0ooO0 . iIii1I11I1II1 % O0oO / OoOO0ooOOoo0O - O0
  o0OOOo = ii1iiIiIII1ii ( I1Ii11II1I1 )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 55 - 55: O0ooOooooO - OoOO
   except :
    pass
 except :
  pass
  if 100 - 100: O0
def o00IiI1iiII1i1i ( ) :
 if 18 - 18: OOooOOo
 try :
  if 80 - 80: o00O0oo / iIii1I11I1II1 % OoOO0ooOOoo0O
  o0OOOo = ii1iiIiIII1ii ( IiIi11iI )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 80 - 80: OoOO % O0ooOooooO
   try :
    if 99 - 99: iI / iIii1I11I1II1 - o0oO0 * o00O0oo % OOooOOo
    i1II1i = IiIiII1
    if 10 - 10: o0oO0 - OoOO0ooOOoo0O . OoooooooOO . IIII . OoOO * O0ooOooooO
   except :
    pass
    if 78 - 78: oO0o0ooO0 / OoOO - oO0o0ooO0 * OoooooooOO . OoOO0ooOOoo0O
    if 96 - 96: OOooOOo % i1IIi . o0000oOoOoO0o . O0
  o0OOOo = ii1iiIiIII1ii ( i1II1i )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 37 - 37: i1IIi - IIII % OoooooooOO / IIII % iI
   except :
    pass
 except :
  pass
  if 48 - 48: i11iIiiIii % oO0o0ooO0
def i11i11 ( ) :
 if 18 - 18: iIii1I11I1II1 + O0oO * OOooOOo - IIII / OOooOOo
 try :
  if 78 - 78: O0oO . i1I111II1I
  o0OOOo = ii1iiIiIII1ii ( i11I1IiII1i1i )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 38 - 38: OoOO0ooOOoo0O + i1I111II1I
   try :
    if 15 - 15: ii11ii1ii + O0oO . iI - iIii1I11I1II1 / O0 % iIii1I11I1II1
    oO0O = IiIiII1
    if 79 - 79: OoooooooOO - i1I111II1I * i1I111II1I . OoOO0ooOOoo0O
   except :
    pass
    if 100 - 100: II111iiii * O0oO % OOooOOo / o00O0oo
    if 90 - 90: o00O0oo . iI . OoOO0ooOOoo0O . o0oO0
  o0OOOo = ii1iiIiIII1ii ( oO0O )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 4 - 4: o0oO0 + OoOO0ooOOoo0O % o00O0oo / i11iIiiIii
   except :
    pass
 except :
  pass
  if 74 - 74: II111iiii . O0 - OOooOOo + i1I111II1I % i11iIiiIii % OoOO0ooOOoo0O
def O0OOO0 ( ) :
 if 8 - 8: i11iIiiIii / II111iiii + o0000oOoOoO0o * o0oO0 % i1I111II1I . O0oO
 try :
  if 6 - 6: i1I111II1I % ii11ii1ii . ii11ii1ii - o00O0oo / O0oO . i1IIi
  o0OOOo = ii1iiIiIII1ii ( Oo0o0O00 )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 99 - 99: OoOO0ooOOoo0O . Oooo0Ooo000
   try :
    if 59 - 59: O0oO / ii11ii1ii / IIII / O0 / OoOO0ooOOoo0O + o0000oOoOoO0o
    IIiI1111i1 = IiIiII1
    if 46 - 46: i1I111II1I
   except :
    pass
    if 29 - 29: II111iiii . OoOO0ooOOoo0O % o0000oOoOoO0o * II111iiii - o0000oOoOoO0o * iIii1I11I1II1
    if 35 - 35: II111iiii - i1I111II1I . i1IIi
  o0OOOo = ii1iiIiIII1ii ( IIiI1111i1 )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 95 - 95: OOooOOo + OOooOOo - IIII - O0ooOooooO
   except :
    pass
 except :
  pass
  if 45 - 45: o0oO0 . OoooooooOO
  if 27 - 27: o0oO0 * ii11ii1ii . OoOO0ooOOoo0O
def Ii111Iiiii ( ) :
 if 13 - 13: o00O0oo / i11iIiiIii
 try :
  if 32 - 32: o0000oOoOoO0o + OOooOOo . Oooo0Ooo000
  o0OOOo = ii1iiIiIII1ii ( I1111i )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 41 - 41: OoOO0ooOOoo0O . i11iIiiIii / O0oO
   try :
    if 98 - 98: OoOO0ooOOoo0O % II111iiii
    OoO0O000 = IiIiII1
    if 14 - 14: OoOO / OoOO * O0 . oO0o0ooO0
   except :
    pass
    if 59 - 59: II111iiii * i11iIiiIii
    if 54 - 54: O0 % OoooooooOO - OOooOOo
  o0OOOo = ii1iiIiIII1ii ( OoO0O000 )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 61 - 61: ii11ii1ii * i1I111II1I . ii11ii1ii + ii11ii1ii / i1I111II1I * O0
   except :
    pass
 except :
  pass
  if 73 - 73: O0ooOooooO * O0ooOooooO / iI
  if 43 - 43: o00O0oo . i1IIi . i1I111II1I + O0 * o0oO0 * O0
def II11ii ( ) :
 if 39 - 39: O0ooOooooO . OOooOOo * OoOO0ooOOoo0O - i11iIiiIii
 try :
  if 1 - 1: O0ooOooooO * OoOO0ooOOoo0O
  o0OOOo = ii1iiIiIII1ii ( o00O0O )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 66 - 66: OoOO0ooOOoo0O + i1IIi % II111iiii . O0 * o00O0oo % o00O0oo
   try :
    if 87 - 87: IIII + o0000oOoOoO0o . O0ooOooooO - OoooooooOO
    iiiiI1IiI1I1 = IiIiII1
    if 19 - 19: o0oO0
   except :
    pass
    if 55 - 55: IIII % IIII / O0 % O0ooOooooO - o0000oOoOoO0o . ii11ii1ii
    if 49 - 49: iIii1I11I1II1 * i1IIi . OoooooooOO
  o0OOOo = ii1iiIiIII1ii ( iiiiI1IiI1I1 )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 90 - 90: o0000oOoOoO0o % o00O0oo - iIii1I11I1II1 % OoOO0ooOOoo0O
   except :
    pass
    if 8 - 8: OoOO0ooOOoo0O * ii11ii1ii / i1I111II1I % o0oO0 - OOooOOo
 except :
  pass
  if 71 - 71: O0ooOooooO
  if 23 - 23: i1IIi . iIii1I11I1II1 . IIII . O0 % o0oO0 % i11iIiiIii
def Iiiii111 ( ) :
 if 93 - 93: OoooooooOO * ii11ii1ii
 try :
  if 10 - 10: Oooo0Ooo000 * OoooooooOO + O0oO - o00O0oo / o00O0oo . i11iIiiIii
  o0OOOo = ii1iiIiIII1ii ( Iii1I1111ii )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 22 - 22: Oooo0Ooo000 / o0000oOoOoO0o
   try :
    if 98 - 98: i1IIi
    OOO0oO = IiIiII1
    if 38 - 38: iIii1I11I1II1 / iI
   except :
    pass
    if 13 - 13: iIii1I11I1II1
    if 77 - 77: i11iIiiIii - iIii1I11I1II1 / oO0o0ooO0 / iI / OoOO
  o0OOOo = ii1iiIiIII1ii ( OOO0oO )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 56 - 56: OoooooooOO * O0
   except :
    pass
    if 85 - 85: OoooooooOO % OoOO0ooOOoo0O * iIii1I11I1II1
 except :
  pass
  if 44 - 44: iIii1I11I1II1 . o00O0oo + Oooo0Ooo000 . iI
def II1i11 ( ) :
 if 28 - 28: II111iiii - oO0o0ooO0 % OoOO0ooOOoo0O + OoOO - OoOO0ooOOoo0O
 try :
  if 28 - 28: II111iiii . oO0o0ooO0 + O0 . O0 . IIII
  o0OOOo = ii1iiIiIII1ii ( Ii1IIiI1i )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 98 - 98: OoooooooOO % O0 - O0
   try :
    if 76 - 76: i1IIi % OoOO0ooOOoo0O - OOooOOo / o0000oOoOoO0o * iI
    iIiIIiI1i1Ii = IiIiII1
    if 72 - 72: IIII . IIII - o00O0oo
   except :
    pass
    if 48 - 48: ii11ii1ii - iI + ii11ii1ii - OOooOOo * i11iIiiIii . O0ooOooooO
  o0OOOo = ii1iiIiIII1ii ( iIiIIiI1i1Ii )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 35 - 35: i1I111II1I . O0 + ii11ii1ii + IIII + i1IIi
   except :
    pass
 except :
  pass
  if 65 - 65: O0 * OOooOOo / OOooOOo . OoOO0ooOOoo0O
  if 87 - 87: II111iiii * o00O0oo % ii11ii1ii * ii11ii1ii
def O0OOOOOO0 ( ) :
 if 79 - 79: II111iiii - iI . i1IIi + O0 % O0 * OOooOOo
 try :
  if 7 - 7: i1IIi + IIII % O0ooOooooO / o0000oOoOoO0o + i1IIi
  o0OOOo = ii1iiIiIII1ii ( IiII111i1i11 )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 41 - 41: o0oO0 + i11iIiiIii / i1I111II1I % o00O0oo
   try :
    if 22 - 22: OoOO0ooOOoo0O % o0000oOoOoO0o * o0oO0 - o00O0oo + o0000oOoOoO0o - ii11ii1ii
    iiIi1iiI1I = IiIiII1
    if 26 - 26: iIii1I11I1II1 + i1IIi / OoOO0ooOOoo0O % o00O0oo
   except :
    pass
    if 44 - 44: OoooooooOO . II111iiii . IIII % OoooooooOO
    if 86 - 86: i11iIiiIii + O0 * i1I111II1I - OoOO * IIII + O0
  o0OOOo = ii1iiIiIII1ii ( iiIi1iiI1I )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 95 - 95: iIii1I11I1II1 . Oooo0Ooo000 % O0ooOooooO - Oooo0Ooo000 * II111iiii
   except :
    pass
 except :
  pass
  if 89 - 89: O0ooOooooO . OOooOOo
  if 59 - 59: i1IIi % iIii1I11I1II1 + OoooooooOO
def oOOO0 ( ) :
 if 32 - 32: iI % Oooo0Ooo000 * ii11ii1ii
 try :
  if 72 - 72: iI . O0ooOooooO - Oooo0Ooo000 - o0oO0 % i1IIi
  o0OOOo = ii1iiIiIII1ii ( oooO )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 56 - 56: ii11ii1ii * O0ooOooooO
   try :
    if 13 - 13: ii11ii1ii * ii11ii1ii * II111iiii * O0ooOooooO . i1IIi / i1I111II1I
    O0Oo000OO000 = IiIiII1
    if 83 - 83: o0000oOoOoO0o % oO0o0ooO0 + O0oO % i11iIiiIii + O0
   except :
    pass
  o0OOOo = ii1iiIiIII1ii ( O0Oo000OO000 )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 65 - 65: iIii1I11I1II1 % oO0o0ooO0 + O0 / OoooooooOO
   except :
    pass
 except :
  pass
  if 52 - 52: o0oO0 % IIII * OOooOOo % O0oO + IIII / O0ooOooooO
def oo000oOO00o0oOO ( ) :
 if 27 - 27: ii11ii1ii
 try :
  if 95 - 95: O0oO
  o0OOOo = ii1iiIiIII1ii ( ooo )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 44 - 44: IIII + O0oO . i1I111II1I / II111iiii % iIii1I11I1II1 + i1I111II1I
   try :
    if 61 - 61: IIII / OoOO + II111iiii . oO0o0ooO0 / ii11ii1ii * IIII
    ii1 = IiIiII1
    if 69 - 69: O0oO % O0 / OOooOOo . Oooo0Ooo000 / iI
   except :
    pass
    if 94 - 94: O0oO - II111iiii . OOooOOo - ii11ii1ii + o00O0oo * o00O0oo
    if 27 - 27: i1I111II1I * OOooOOo . iIii1I11I1II1 - iIii1I11I1II1
  o0OOOo = ii1iiIiIII1ii ( ii1 )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 5 - 5: i1I111II1I
   except :
    pass
 except :
  pass
  if 84 - 84: II111iiii * oO0o0ooO0 * II111iiii % i1I111II1I / OOooOOo
  if 100 - 100: i1I111II1I . o0oO0 - iIii1I11I1II1 . i11iIiiIii / II111iiii
def o0oO0OO00oo0o ( ) :
 if 17 - 17: i1I111II1I / o00O0oo - o0000oOoOoO0o * o00O0oo
 try :
  if 42 - 42: o0oO0
  o0OOOo = ii1iiIiIII1ii ( Ooo0oOooo0 )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 68 - 68: IIII . ii11ii1ii % iI - OoooooooOO * O0ooOooooO . IIII
   try :
    if 46 - 46: i11iIiiIii - IIII * OOooOOo * O0oO % o00O0oo * i1IIi
    Iii1I = IiIiII1
    if 40 - 40: i1I111II1I * O0
   except :
    pass
    if 86 - 86: o0oO0
    if 29 - 29: iIii1I11I1II1 - OoOO + OOooOOo % iIii1I11I1II1 % IIII
  o0OOOo = ii1iiIiIII1ii ( Iii1I )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 84 - 84: i1I111II1I + o00O0oo + o0oO0 + O0ooOooooO
   except :
    pass
 except :
  pass
  if 62 - 62: i11iIiiIii + OoOO0ooOOoo0O + i1IIi
def oOOoO0O ( ) :
 if 15 - 15: Oooo0Ooo000
 try :
  if 85 - 85: i11iIiiIii / i11iIiiIii . OoOO . O0
  o0OOOo = ii1iiIiIII1ii ( iiIiIIIiiI )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 67 - 67: II111iiii / o0000oOoOoO0o . IIII . OoooooooOO
   try :
    if 19 - 19: i1I111II1I . o00O0oo / OoOO0ooOOoo0O
    O00oo = IiIiII1
    if 75 - 75: iIii1I11I1II1 * i11iIiiIii - OoooooooOO . OoOO0ooOOoo0O
   except :
    pass
    if 70 - 70: oO0o0ooO0 * oO0o0ooO0 + ii11ii1ii * IIII % OOooOOo + iIii1I11I1II1
    if 2 - 2: i11iIiiIii
  o0OOOo = ii1iiIiIII1ii ( O00oo )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 98 - 98: oO0o0ooO0 / OoOO - o0oO0 - OOooOOo / OoOO0ooOOoo0O + i11iIiiIii
   except :
    pass
 except :
  pass
  if 17 - 17: O0oO
  if 97 - 97: o00O0oo * o00O0oo / O0ooOooooO
def i1111IIiI ( ) :
 if 49 - 49: IIII - OoOO0ooOOoo0O % o0000oOoOoO0o % OoOO
 try :
  if 32 - 32: i1I111II1I
  o0OOOo = ii1iiIiIII1ii ( II11IiIi11 )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 42 - 42: Oooo0Ooo000 + IIII + i11iIiiIii
   try :
    if 29 - 29: i1IIi + i1IIi
    o0Ooo0000 = IiIiII1
    if 74 - 74: O0ooOooooO % II111iiii - IIII % OoooooooOO . oO0o0ooO0
   except :
    pass
    if 11 - 11: OOooOOo * i11iIiiIii / i11iIiiIii
    if 89 - 89: O0ooOooooO . i11iIiiIii * O0
  o0OOOo = ii1iiIiIII1ii ( o0Ooo0000 )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 44 - 44: i1IIi . OOooOOo / i11iIiiIii + i1I111II1I
   except :
    pass
 except :
  pass
  if 27 - 27: IIII
  if 52 - 52: Oooo0Ooo000 % OoOO0ooOOoo0O + iIii1I11I1II1 * oO0o0ooO0 . o0oO0
def OoOooOO0oOOo0O ( ) :
 if 42 - 42: O0ooOooooO / o0000oOoOoO0o + ii11ii1ii . ii11ii1ii % IIII
 try :
  if 16 - 16: i1IIi + OoOO % OoOO0ooOOoo0O + o0oO0 * ii11ii1ii
  o0OOOo = ii1iiIiIII1ii ( I1iiii1I )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 3 - 3: i11iIiiIii
   try :
    if 81 - 81: OOooOOo . OoooooooOO * o0oO0 . oO0o0ooO0 - O0 * oO0o0ooO0
    OoO0Oo00 = IiIiII1
    if 1 - 1: Oooo0Ooo000 - O0oO
   except :
    pass
    if 45 - 45: o0oO0 - IIII
    if 70 - 70: OoOO % OOooOOo / OOooOOo . O0oO % iI . II111iiii
  o0OOOo = ii1iiIiIII1ii ( OoO0Oo00 )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 10 - 10: o0oO0 - i11iIiiIii . o00O0oo % i1IIi
   except :
    pass
 except :
  pass
  if 78 - 78: iIii1I11I1II1 * ii11ii1ii . ii11ii1ii - IIII . iIii1I11I1II1
  if 30 - 30: iI + iI % i1I111II1I - o0000oOoOoO0o - o00O0oo
def i111IiiI1Ii ( ) :
 if 72 - 72: O0 . OoOO0ooOOoo0O * ii11ii1ii + o00O0oo - o0000oOoOoO0o
 try :
  if 40 - 40: OoOO + OoOO
  o0OOOo = ii1iiIiIII1ii ( oO00ooooO0o )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 94 - 94: O0ooOooooO * iIii1I11I1II1 . O0oO
   try :
    if 13 - 13: iIii1I11I1II1 * OoOO0ooOOoo0O / Oooo0Ooo000 % iI + oO0o0ooO0
    iiiI1iI1 = IiIiII1
    if 15 - 15: i1I111II1I . i1IIi * OoOO0ooOOoo0O % iIii1I11I1II1
   except :
    pass
    if 35 - 35: o00O0oo + Oooo0Ooo000 - OoOO0ooOOoo0O % oO0o0ooO0 % o0000oOoOoO0o % OoOO0ooOOoo0O
    if 45 - 45: OOooOOo * IIII % OoOO
  o0OOOo = ii1iiIiIII1ii ( iiiI1iI1 )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 24 - 24: iI - O0oO * oO0o0ooO0
   except :
    pass
 except :
  pass
  if 87 - 87: o0oO0 - o00O0oo % o00O0oo . oO0o0ooO0 / o00O0oo
  if 6 - 6: OoOO0ooOOoo0O / iIii1I11I1II1 * OoooooooOO * i11iIiiIii
def o0O0OOo0oO ( ) :
 if 42 - 42: II111iiii / O0 . iIii1I11I1II1 / O0 / OoOO / OoooooooOO
 try :
  if 62 - 62: O0 . ii11ii1ii
  o0OOOo = ii1iiIiIII1ii ( o0oO0oooOoo )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 33 - 33: ii11ii1ii / iIii1I11I1II1 % i1IIi
   try :
    if 76 - 76: o0oO0 + iIii1I11I1II1 + OoOO0ooOOoo0O . OoOO
    i1i1 = IiIiII1
    if 68 - 68: o0oO0 - OOooOOo
   except :
    pass
    if 41 - 41: oO0o0ooO0
  o0OOOo = ii1iiIiIII1ii ( i1i1 )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 21 - 21: iI + o0000oOoOoO0o % Oooo0Ooo000 + i11iIiiIii + O0ooOooooO + II111iiii
   except :
    pass
 except :
  pass
  if 98 - 98: Oooo0Ooo000
  if 49 - 49: ii11ii1ii * oO0o0ooO0 + o0000oOoOoO0o - i11iIiiIii
def OOooO ( ) :
 if 28 - 28: iI - IIII / OOooOOo
 try :
  if 27 - 27: i1IIi + OOooOOo * o00O0oo + IIII . oO0o0ooO0
  o0OOOo = ii1iiIiIII1ii ( I1i111I )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 1 - 1: IIII * i1I111II1I + O0oO
   try :
    if 77 - 77: oO0o0ooO0 % i11iIiiIii . IIII % IIII
    IIi11iI1Iii = IiIiII1
    if 29 - 29: O0 + OOooOOo - i1IIi % ii11ii1ii + Oooo0Ooo000 / O0oO
   except :
    pass
    if 21 - 21: ii11ii1ii % i1I111II1I
    if 57 - 57: IIII - IIII - o00O0oo
  o0OOOo = ii1iiIiIII1ii ( IIi11iI1Iii )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 7 - 7: O0
   except :
    pass
 except :
  pass
  if 26 - 26: o0000oOoOoO0o / OoooooooOO % iI % IIII
def oO0O0o0O ( ) :
 if 100 - 100: OoOO0ooOOoo0O % ii11ii1ii
 try :
  if 76 - 76: II111iiii / OoOO + OoooooooOO . o00O0oo . O0oO . iI
  o0OOOo = ii1iiIiIII1ii ( I1i11 )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 43 - 43: i1IIi
   try :
    if 17 - 17: O0 - OoOO0ooOOoo0O
    OOoooOoO0 = IiIiII1
    if 95 - 95: o0oO0 - o00O0oo - O0 . OOooOOo . O0ooOooooO
   except :
    pass
  o0OOOo = ii1iiIiIII1ii ( OOoooOoO0 )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 7 - 7: Oooo0Ooo000
   except :
    pass
 except :
  pass
  if 45 - 45: O0 - IIII
def oo0oOO ( ) :
 if 2 - 2: i1I111II1I % OOooOOo - Oooo0Ooo000
 try :
  if 79 - 79: OoooooooOO / o00O0oo . O0
  o0OOOo = ii1iiIiIII1ii ( IiIIi1 )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 79 - 79: oO0o0ooO0 - II111iiii
   try :
    if 43 - 43: i1IIi + O0 % OoOO / o0oO0 * OOooOOo
    OoOi1iI11Iii = IiIiII1
    if 91 - 91: IIII + iI % OOooOOo - iI - oO0o0ooO0
   except :
    pass
  o0OOOo = ii1iiIiIII1ii ( OoOi1iI11Iii )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 42 - 42: OoOO0ooOOoo0O
   except :
    pass
 except :
  pass
  if 79 - 79: i1IIi
def iIi1 ( ) :
 if 96 - 96: i1IIi % OoooooooOO
 try :
  if 99 - 99: i11iIiiIii . II111iiii . OoooooooOO
  o0OOOo = ii1iiIiIII1ii ( I11iiiiI1i )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 59 - 59: i11iIiiIii . OoooooooOO / O0oO * o00O0oo + OoooooooOO
   try :
    if 3 - 3: i11iIiiIii * ii11ii1ii % iIii1I11I1II1 % OOooOOo * O0ooOooooO / IIII
    O00oo00oOOO0o = IiIiII1
    if 5 - 5: o0000oOoOoO0o / OOooOOo % o0oO0 . i1I111II1I
   except :
    pass
  o0OOOo = ii1iiIiIII1ii ( O00oo00oOOO0o )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 86 - 86: i1IIi * OoOO0ooOOoo0O . O0 - o0oO0 - o0000oOoOoO0o - OoOO0ooOOoo0O
   except :
    pass
 except :
  pass
  if 47 - 47: IIII + O0oO
def i1Iiii ( ) :
 if 87 - 87: i1I111II1I / Oooo0Ooo000 - ii11ii1ii
 try :
  if 56 - 56: O0
  o0OOOo = ii1iiIiIII1ii ( II1i11I )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 45 - 45: OoOO0ooOOoo0O - OoOO - OoOO0ooOOoo0O
   try :
    if 41 - 41: ii11ii1ii / i1IIi / ii11ii1ii - O0ooOooooO . o0000oOoOoO0o
    Oooooooo00o00 = IiIiII1
    if 100 - 100: Oooo0Ooo000 % II111iiii . o0oO0 % OoOO + o00O0oo
   except :
    pass
  o0OOOo = ii1iiIiIII1ii ( Oooooooo00o00 )
  oO0o0oooO0oO = re . compile ( o0o0o0oO0oOO ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 in oO0o0oooO0oO :
   try :
    o0oOo0OO ( oOoooooOoO , Ii111 , I111i1i1111 )
    if 79 - 79: OoOO0ooOOoo0O % OOooOOo % o0oO0 / i1IIi % OoOO
   except :
    pass
    if 56 - 56: iIii1I11I1II1 - i11iIiiIii * O0ooOooooO
 except :
  pass
  if 84 - 84: IIII + o0oO0 + o0000oOoOoO0o
  if 33 - 33: o0oO0
  if 93 - 93: iI
def o0oOo0OO ( thumb , name , url ) :
 if 34 - 34: oO0o0ooO0 - iI * ii11ii1ii / o0000oOoOoO0o
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 if 19 - 19: o00O0oo
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( i1Iii1i1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   IIi ( name , url , '' , o00 , oo00 )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 46 - 46: iIii1I11I1II1 . i11iIiiIii - OoOO0ooOOoo0O % O0 / II111iiii * i1IIi
  if 'tvg-logo' in thumb :
   thumb = re . compile ( i1Iii1i1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 66 - 66: O0
   oOooOOo00ooO ( name , url , 4 , OO0O0o0o0 , oo00 )
   if 71 - 71: Oooo0Ooo000 - o0000oOoOoO0o - IIII
  else :
   if 28 - 28: iIii1I11I1II1
   oOooOOo00ooO ( name , url , 4 , OO0O0o0o0 , oo00 )
   if 7 - 7: o0000oOoOoO0o % i1I111II1I * OoOO0ooOOoo0O
def O0O00 ( name , url , thumb , id , trailer ) :
 if 30 - 30: OoooooooOO % i1I111II1I / OoOO0ooOOoo0O % Oooo0Ooo000
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 19 - 19: Oooo0Ooo000 + i1I111II1I / oO0o0ooO0 / II111iiii
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( i1Iii1i1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   IIi ( name , url , '' , o00 , oo00 )
 else :
  oOOo0 = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
  if 92 - 92: i1IIi % iI + iI - iIii1I11I1II1 . o0oO0
  name = '[COLOR %s]' % oOOo0 + name + '[/COLOR]'
  if 33 - 33: o0000oOoOoO0o / O0 + IIII
  if 'tvg-logo' in thumb :
   thumb = re . compile ( i1Iii1i1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'selecton' )
   if IIIi1I1IIii1II == 'true' :
    if 75 - 75: i1I111II1I % i11iIiiIii + iIii1I11I1II1
    oOoOo0o00o ( name , url , 1 , thumb , thumb , id , trailer )
    if 2 - 2: II111iiii
   else :
    if 54 - 54: o0oO0 . OoooooooOO % ii11ii1ii
    oOoOo0o00o ( name , url , 130 , thumb , thumb , id , trailer )
    if 22 - 22: IIII
  else :
   if 22 - 22: O0ooOooooO * O0oO - ii11ii1ii * O0 / i11iIiiIii
   if IIIi1I1IIii1II == 'true' :
    if 78 - 78: ii11ii1ii * O0 / iI + OoooooooOO + IIII
    oOoOo0o00o ( name , url , 1 , thumb , thumb , id , trailer )
    if 23 - 23: O0ooOooooO % OoooooooOO / iIii1I11I1II1 + o00O0oo / i1IIi / o0000oOoOoO0o
   else :
    if 94 - 94: i1IIi
    oOoOo0o00o ( name , url , 130 , thumb , thumb , id , trailer )
    if 36 - 36: OOooOOo + ii11ii1ii
    if 46 - 46: O0ooOooooO
def iiIi1iI1iIii ( name , url , thumb , id , trailer , description , fanart ) :
 if 65 - 65: i1IIi . o00O0oo / iI
 if 11 - 11: i1I111II1I * iI / iI - IIII
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 oOOo0 = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
 fanart = fanart . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 name = '[COLOR %s]' % oOOo0 + name + '[/COLOR]'
 if 68 - 68: OOooOOo % i1I111II1I - i1I111II1I / OOooOOo + o00O0oo - ii11ii1ii
 if 'tvg-logo' in thumb :
  thumb = re . compile ( i1Iii1i1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'selecton' )
  if IIIi1I1IIii1II == 'true' :
   if 65 - 65: iI - i1IIi
   O00Oo ( name , url , 1 , thumb , fanart , id , trailer , description )
   if 38 - 38: i1IIi . i11iIiiIii
  else :
   if 93 - 93: O0oO * II111iiii / o0oO0 - o0000oOoOoO0o
   O00Oo ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 98 - 98: i11iIiiIii / OOooOOo * o0000oOoOoO0o / Oooo0Ooo000
 else :
  if 67 - 67: O0oO % oO0o0ooO0
  if IIIi1I1IIii1II == 'true' :
   if 39 - 39: i11iIiiIii + i1I111II1I
   O00Oo ( name , url , 1 , thumb , fanart , id , trailer , description )
   if 7 - 7: iIii1I11I1II1 - i1IIi
  else :
   if 10 - 10: Oooo0Ooo000 % O0 / OOooOOo % O0oO
   O00Oo ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 25 - 25: II111iiii / OoOO
   if 64 - 64: O0 % iI
   if 40 - 40: o0000oOoOoO0o + O0oO
def OoO000Oo0oO ( name , trailer ) :
 if 46 - 46: O0 - OoOO0ooOOoo0O . OoooooooOO
 if i1Oo00 == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Realstream, Reproduciendo Trailer de: [COLOR green]" + name + "[/COLOR] ,5000)" )
  if 19 - 19: o0000oOoOoO0o
  I111i1i1111 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  o00OOOOOo0OOo = I111i1i1111
  i1II11I11ii1 = xbmcgui . ListItem ( name , trailer , path = o00OOOOOo0OOo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , i1II11I11ii1 )
 else :
  I111i1i1111 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  o00OOOOOo0OOo = I111i1i1111
  i1II11I11ii1 = xbmcgui . ListItem ( name , trailer , path = o00OOOOOo0OOo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , i1II11I11ii1 )
  if 64 - 64: oO0o0ooO0 % OoOO0ooOOoo0O / II111iiii % iI - O0ooOooooO
  if 2 - 2: Oooo0Ooo000 - o00O0oo + o0000oOoOoO0o * OoOO / O0ooOooooO
def iIIiI11iI1Ii1 ( name , url ) :
 if 94 - 94: iI / i11iIiiIii % O0
 if i1Oo00 == 'true' :
  if 70 - 70: O0oO - ii11ii1ii / OoooooooOO % OoooooooOO
  try :
   if 95 - 95: OoooooooOO % OoooooooOO . o0oO0
   iI1I = xbmcgui . DialogProgress ( )
   iI1I . create ( 'Realstream:' , 'Iniciando ...' )
   iI1I . update ( 30 , 'Realstream:' , 'Conectando al servidor ...' )
   xbmc . sleep ( 1000 )
   iI1I . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   iI1I . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   iI1I . close ( )
   if 26 - 26: oO0o0ooO0 + i1I111II1I - II111iiii . II111iiii + o00O0oo + OoOO0ooOOoo0O
   o00OOOOOo0OOo = url
   i1II11I11ii1 = xbmcgui . ListItem ( name , IIII1 , path = o00OOOOOo0OOo )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , i1II11I11ii1 )
   if 68 - 68: O0
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. ,3000)" )
  if 76 - 76: o00O0oo
 else :
  if 99 - 99: o0000oOoOoO0o
  try :
   if 1 - 1: o0oO0 * OoOO0ooOOoo0O * OoOO + ii11ii1ii
   iI1I = xbmcgui . DialogProgress ( )
   iI1I . create ( 'Realstream:' , 'Iniciando ...' )
   iI1I . update ( 30 , 'Realstream:' , 'Conectando al servidor ...' )
   xbmc . sleep ( 1000 )
   iI1I . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   iI1I . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   iI1I . close ( )
   if 90 - 90: Oooo0Ooo000 % ii11ii1ii - ii11ii1ii . iIii1I11I1II1 / IIII + O0oO
   o00OOOOOo0OOo = url
   i1II11I11ii1 = xbmcgui . ListItem ( name , IIII1 , path = o00OOOOOo0OOo )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , i1II11I11ii1 )
   if 89 - 89: oO0o0ooO0
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. ,3000)" )
  if 87 - 87: O0ooOooooO % ii11ii1ii
 return
 if 62 - 62: OoOO + iI / O0ooOooooO * i11iIiiIii
 if 37 - 37: O0ooOooooO
def iIIiI1111 ( trailer ) :
 if 91 - 91: OoooooooOO / o0000oOoOoO0o . i1I111II1I - iIii1I11I1II1 - o0oO0
 if 'https://www.youtube.com' in trailer :
  if 31 - 31: i1I111II1I - OoOO / IIII . i1IIi / o0oO0
  try :
   if 66 - 66: OoOO
   import resolveurl
   if 72 - 72: Oooo0Ooo000
   o00ooo = urlresolver . HostedMediaFile ( I111i1i1111 )
   iI1I = xbmcgui . DialogProgress ( )
   iI1I . create ( 'Realstream:' , 'Conectando al servidor ... ' )
   iI1I . update ( 20 , 'Por favor, espere ...' )
   xbmc . sleep ( 500 )
   if 91 - 91: II111iiii / i1I111II1I + iIii1I11I1II1 . O0oO - O0
   if not o00ooo :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    return False
    if 70 - 70: o0oO0 * oO0o0ooO0 - O0oO + ii11ii1ii % o00O0oo - i1I111II1I
   try :
    if 81 - 81: O0 . O0
    iI1I . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    iIIi1iI1I1IIi = o00ooo . resolve ( )
    if not iIIi1iI1I1IIi or not isinstance ( iIIi1iI1I1IIi , basestring ) :
     try : O0OO0 = iIIi1iI1I1IIi . msg
     except : O0OO0 = iIIi1iI1I1IIi
     raise Exception ( O0OO0 )
   except Exception as oO0o00oOOooO0 :
    try : O0OO0 = str ( oO0o00oOOooO0 )
    except : O0OO0 = iIIi1iI1I1IIi
    iI1I . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
    iI1I . close ( )
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    if 75 - 75: iIii1I11I1II1 % i1I111II1I + o00O0oo * O0 . O0ooOooooO - iI
   iI1I . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
   xbmc . sleep ( 500 )
   iI1I . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   iI1I . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
   xbmc . sleep ( 500 )
   iI1I . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   iI1I . close ( )
   if 32 - 32: o0oO0 % oO0o0ooO0 - i1IIi
   ooO0000o00O = xbmcgui . ListItem ( path = iIIi1iI1I1IIi )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
   if 40 - 40: iIii1I11I1II1 + O0ooOooooO * OoOO0ooOOoo0O + oO0o0ooO0
  except :
   pass
   if 15 - 15: O0oO % OOooOOo - iIii1I11I1II1 * iI
  else :
   if 71 - 71: OoOO0ooOOoo0O % ii11ii1ii % iI
   I111i1i1111 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
   o00OOOOOo0OOo = I111i1i1111
   i1II11I11ii1 = xbmcgui . ListItem ( trailer , path = o00OOOOOo0OOo )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , i1II11I11ii1 )
   return
   if 34 - 34: O0oO / O0oO % i1I111II1I . OoOO0ooOOoo0O / ii11ii1ii
def O0OO000OOo0o ( name , url ) :
 if 86 - 86: o0oO0 . O0ooOooooO - O0ooOooooO
 if '[Youtube]' in name :
  if 71 - 71: iIii1I11I1II1 . II111iiii % iIii1I11I1II1
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  o00OOOOOo0OOo = url
  i1II11I11ii1 = xbmcgui . ListItem ( IIII1 , path = o00OOOOOo0OOo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , i1II11I11ii1 )
  if 22 - 22: i11iIiiIii % o00O0oo % iI % iI . OoOO
  if 85 - 85: iI . O0 / IIII * iI - OoOO - i11iIiiIii
 else :
  if 25 - 25: iI % ii11ii1ii - IIII
  import urlresolver
  from urlresolver import common
  if 80 - 80: i1I111II1I % II111iiii - ii11ii1ii - iIii1I11I1II1
  o00ooo = urlresolver . HostedMediaFile ( url )
  if 9 - 9: o0000oOoOoO0o % o00O0oo . o00O0oo
  if not o00ooo :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 28 - 28: OoooooooOO % oO0o0ooO0 + o00O0oo + O0 . Oooo0Ooo000
   if 80 - 80: i11iIiiIii % o00O0oo
  try :
   iIIi1iI1I1IIi = o00ooo . resolve ( )
   if not iIIi1iI1I1IIi or not isinstance ( iIIi1iI1I1IIi , basestring ) :
    try : O0OO0 = iIIi1iI1I1IIi . msg
    except : O0OO0 = url
    raise Exception ( O0OO0 )
  except Exception as oO0o00oOOooO0 :
   try : O0OO0 = str ( oO0o00oOOooO0 )
   except : O0OO0 = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 54 - 54: o0000oOoOoO0o + O0oO - iIii1I11I1II1 % iI % i1I111II1I
  i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if i1Oo00 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  ooO0000o00O = xbmcgui . ListItem ( path = iIIi1iI1I1IIi )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
  if 19 - 19: o00O0oo / iIii1I11I1II1 % i1IIi . OoooooooOO
  if 57 - 57: iI . ii11ii1ii - OoOO - i11iIiiIii * Oooo0Ooo000 / o0000oOoOoO0o
 return
 if 79 - 79: o00O0oo + o0000oOoOoO0o % ii11ii1ii * o0000oOoOoO0o
def iiii11IiIiI ( name , url ) :
 if 8 - 8: Oooo0Ooo000 + OoOO
 import resolveurl
 if 9 - 9: IIII + o0000oOoOoO0o
 o00ooo = urlresolver . HostedMediaFile ( url )
 dp = xbmcgui . DialogProgress ( )
 dp . create ( 'Realstream:' , 'Conectando al servidor ... ' )
 dp . update ( 20 , 'Por favor, espere ...' )
 xbmc . sleep ( 500 )
 if 8 - 8: IIII * ii11ii1ii / O0ooOooooO - OoOO - OoooooooOO
 if not o00ooo :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  return False
  if 100 - 100: oO0o0ooO0 . iIii1I11I1II1 . iIii1I11I1II1
 try :
  if 55 - 55: oO0o0ooO0
  dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
  xbmc . sleep ( 500 )
  iIIi1iI1I1IIi = o00ooo . resolve ( )
  if not iIIi1iI1I1IIi or not isinstance ( iIIi1iI1I1IIi , basestring ) :
   try : O0OO0 = iIIi1iI1I1IIi . msg
   except : O0OO0 = iIIi1iI1I1IIi
   raise Exception ( O0OO0 )
 except Exception as oO0o00oOOooO0 :
  try : O0OO0 = str ( oO0o00oOOooO0 )
  except : O0OO0 = iIIi1iI1I1IIi
  dp . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
  dp . close ( )
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  if 37 - 37: i1I111II1I / i11iIiiIii / ii11ii1ii
 dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
 xbmc . sleep ( 500 )
 dp . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
 xbmc . sleep ( 500 )
 dp . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
 xbmc . sleep ( 500 )
 dp . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
 dp . close ( )
 i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
 if 97 - 97: Oooo0Ooo000 . O0oO / OOooOOo
 if 83 - 83: O0oO - o00O0oo * oO0o0ooO0
 if '[Realstream]' or '[Mybox]' in name :
  restante = IiII1IiiIiI1 . getSetting ( 'restante' )
 elif restante == 'true' :
  dialog = xbmcgui . Dialog ( )
  ok = dialog . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
 ooO0000o00O = xbmcgui . ListItem ( path = iIIi1iI1I1IIi )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
 if 90 - 90: ii11ii1ii * OOooOOo
def iiii11IiIiI ( name , url ) :
 if 75 - 75: o00O0oo - OoOO0ooOOoo0O * i11iIiiIii . OoooooooOO - ii11ii1ii . O0oO
 if 6 - 6: O0oO * oO0o0ooO0 / OoooooooOO % o0oO0 * o0000oOoOoO0o
 if 'https://www.rapidvideo.com/v/' in url :
  if 28 - 28: i1I111II1I * OOooOOo % i1I111II1I
  o0OOOo = ii1iiIiIII1ii ( url )
  oO0o0oooO0oO = re . compile ( 'rapidvideo' ) . findall ( o0OOOo )
  for url in oO0o0oooO0oO :
   if 95 - 95: O0 / O0oO . Oooo0Ooo000
   if 17 - 17: O0oO
   try :
    i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
    if i1Oo00 == 'true' :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    ooO0000o00O = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
    if 56 - 56: iI * o0000oOoOoO0o + O0oO
   except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 48 - 48: i1I111II1I * OoOO % Oooo0Ooo000 - O0oO
   if 72 - 72: i1IIi % iI % i1I111II1I % oO0o0ooO0 - oO0o0ooO0
 else :
  if 97 - 97: o0000oOoOoO0o * O0 / o0000oOoOoO0o * OoOO * ii11ii1ii
  import urlresolver
  from urlresolver import common
  if 38 - 38: Oooo0Ooo000
  o00ooo = urlresolver . HostedMediaFile ( url )
  if 25 - 25: iIii1I11I1II1 % II111iiii / O0oO / o00O0oo
  if not o00ooo :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 22 - 22: oO0o0ooO0 * O0ooOooooO
   if 4 - 4: OoOO0ooOOoo0O - oO0o0ooO0 + OOooOOo
  try :
   iIIi1iI1I1IIi = o00ooo . resolve ( )
   if not iIIi1iI1I1IIi or not isinstance ( iIIi1iI1I1IIi , basestring ) :
    try : O0OO0 = iIIi1iI1I1IIi . msg
    except : O0OO0 = url
    raise Exception ( O0OO0 )
  except Exception as oO0o00oOOooO0 :
   try : O0OO0 = str ( oO0o00oOOooO0 )
   except : O0OO0 = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 36 - 36: i1I111II1I
  i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if i1Oo00 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  ooO0000o00O = xbmcgui . ListItem ( path = iIIi1iI1I1IIi )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
  if 19 - 19: OoOO0ooOOoo0O . o0000oOoOoO0o . OoooooooOO
 return
 if 13 - 13: IIII . ii11ii1ii / II111iiii
 if 43 - 43: iIii1I11I1II1 % OoOO
 if 84 - 84: ii11ii1ii
def iiiiI11iiIIi ( name , url ) :
 if 43 - 43: O0oO % o0oO0 / o0000oOoOoO0o * Oooo0Ooo000
 iIIi1iI1I1IIi = url
 i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
 if i1Oo00 == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  ooO0000o00O = xbmcgui . ListItem ( path = iIIi1iI1I1IIi )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
 else :
  ooO0000o00O = xbmcgui . ListItem ( path = iIIi1iI1I1IIi )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
 return
 if 85 - 85: iIii1I11I1II1 . OoooooooOO . o0000oOoOoO0o
def oO00OoO0oo ( name , url ) :
 if 52 - 52: i1I111II1I % iI
 if 25 - 25: O0oO / O0oO % OoooooooOO - o00O0oo * oO0o0ooO0
 if '[Youtube]' in name :
  if 23 - 23: i11iIiiIii
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 100 - 100: oO0o0ooO0 + O0 . OOooOOo + i1IIi - OoOO0ooOOoo0O + o0000oOoOoO0o
  try :
   i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if i1Oo00 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    ooO0000o00O = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
    if 65 - 65: II111iiii / ii11ii1ii
    if 42 - 42: i11iIiiIii . O0
    if 75 - 75: Oooo0Ooo000 + iIii1I11I1II1
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 19 - 19: OOooOOo + i11iIiiIii . i1I111II1I - O0oO / o0oO0 + o0000oOoOoO0o
  if 38 - 38: ii11ii1ii / iIii1I11I1II1 * iIii1I11I1II1 % o00O0oo
 else :
  if 92 - 92: O0oO / O0 * OOooOOo - O0oO
  import xbmcgui
  import urlresolver
  from urlresolver import common
  if 99 - 99: i11iIiiIii % OoooooooOO
  o00ooo = urlresolver . HostedMediaFile ( url )
  if 56 - 56: i1I111II1I * Oooo0Ooo000
  if not o00ooo :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 98 - 98: O0oO + O0 * Oooo0Ooo000 + i11iIiiIii - IIII - iIii1I11I1II1
  import resolveurl as urlresolver
  if 5 - 5: IIII % ii11ii1ii % i1I111II1I % iI
  o00ooo = urlresolver . HostedMediaFile ( url )
  if 17 - 17: o0oO0 + II111iiii + OoooooooOO / IIII / i1I111II1I
  if 80 - 80: o0000oOoOoO0o % i1IIi / O0oO
  if not o00ooo :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 56 - 56: i1IIi . i11iIiiIii
  try :
   iIIi1iI1I1IIi = o00ooo . resolve ( )
   if not iIIi1iI1I1IIi or not isinstance ( iIIi1iI1I1IIi , basestring ) :
    try : O0OO0 = iIIi1iI1I1IIi . msg
    except : O0OO0 = url
    raise Exception ( O0OO0 )
  except Exception as oO0o00oOOooO0 :
   try : O0OO0 = str ( oO0o00oOOooO0 )
   except : O0OO0 = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 15 - 15: II111iiii * oO0o0ooO0 % O0ooOooooO / i11iIiiIii - oO0o0ooO0 + ii11ii1ii
   if 9 - 9: O0oO - oO0o0ooO0 + O0 / O0ooOooooO % i1IIi
   if 97 - 97: o0000oOoOoO0o * iI
  i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if i1Oo00 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 78 - 78: O0oO . IIII + oO0o0ooO0 * O0ooOooooO - i1IIi
   if '[Realstream]' in name :
    if 27 - 27: o0oO0 % i1IIi . ii11ii1ii % Oooo0Ooo000
    iiI111I1iIiI = IiII1IiiIiI1 . getSetting ( 'restante' )
    if iiI111I1iIiI == 'true' :
     i1iI = xbmcgui . Dialog ( )
     iii11 = i1iI . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 73 - 73: OoooooooOO . ii11ii1ii / O0 - O0
   ooO0000o00O = xbmcgui . ListItem ( path = iIIi1iI1I1IIi )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
   if 25 - 25: iIii1I11I1II1 * O0oO - oO0o0ooO0 % i11iIiiIii + o0oO0 % oO0o0ooO0
   if 5 - 5: iIii1I11I1II1 . oO0o0ooO0
   if 2 - 2: iIii1I11I1II1 * OOooOOo % i1IIi % o00O0oo + OoooooooOO + OOooOOo
 return
 if 16 - 16: IIII
 if 63 - 63: O0ooOooooO
 if 11 - 11: O0ooOooooO - iIii1I11I1II1
def ooOo0O0 ( name , url ) :
 if 83 - 83: OoooooooOO
 if 12 - 12: iI
 if '[Youtube]' in name :
  if 36 - 36: Oooo0Ooo000 . i1I111II1I * OoooooooOO - o0000oOoOoO0o
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 60 - 60: IIII . O0ooOooooO / iIii1I11I1II1 + IIII * Oooo0Ooo000
  try :
   i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if i1Oo00 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    ooO0000o00O = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
    if 82 - 82: i11iIiiIii . iIii1I11I1II1 * OOooOOo - O0oO + o0oO0
    if 48 - 48: o00O0oo
    if 96 - 96: iI . OoooooooOO
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 39 - 39: IIII + OoOO
 else :
  if 80 - 80: IIII % OoOO / OoOO0ooOOoo0O
  import resolveurl
  if 54 - 54: ii11ii1ii % OoOO - IIII - O0oO
  o00ooo = urlresolver . HostedMediaFile ( url )
  if 71 - 71: iI . i11iIiiIii
  if 56 - 56: O0 * O0ooOooooO + O0ooOooooO * iIii1I11I1II1 / iI * Oooo0Ooo000
  if not o00ooo :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 25 - 25: iIii1I11I1II1 . O0oO * i11iIiiIii + ii11ii1ii * O0oO
  try :
   iIIi1iI1I1IIi = o00ooo . resolve ( )
   if not iIIi1iI1I1IIi or not isinstance ( iIIi1iI1I1IIi , basestring ) :
    try : O0OO0 = iIIi1iI1I1IIi . msg
    except : O0OO0 = url
    raise Exception ( O0OO0 )
  except Exception as oO0o00oOOooO0 :
   try : O0OO0 = str ( oO0o00oOOooO0 )
   except : O0OO0 = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 67 - 67: O0ooOooooO
   if 88 - 88: ii11ii1ii
   if 8 - 8: o00O0oo
  i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if i1Oo00 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 82 - 82: OoooooooOO
   if 'uptostream.com' or 'uptobox.com' in url :
    if 75 - 75: II111iiii % OOooOOo + IIII % OoooooooOO / i1I111II1I
    iiI111I1iIiI = IiII1IiiIiI1 . getSetting ( 'restante' )
    if iiI111I1iIiI == 'true' :
     i1iI = xbmcgui . Dialog ( )
     iii11 = i1iI . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 4 - 4: i11iIiiIii - IIII % o00O0oo * Oooo0Ooo000 % o0000oOoOoO0o
   ooO0000o00O = xbmcgui . ListItem ( path = iIIi1iI1I1IIi )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
   if 71 - 71: iI . iI - iIii1I11I1II1
   if 22 - 22: OoooooooOO / o00O0oo % O0ooOooooO * OoOO0ooOOoo0O
   if 32 - 32: OoooooooOO % oO0o0ooO0 % iIii1I11I1II1 / O0
 return
 if 61 - 61: II111iiii . O0 - o0oO0 - o00O0oo / i11iIiiIii - II111iiii
def O0oo0oOo ( name , url ) :
 if 40 - 40: O0oO % iI
 if 71 - 71: OoOO
 if '[Youtube]' in name :
  if 75 - 75: O0ooOooooO
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 16 - 16: o00O0oo + II111iiii * OoOO0ooOOoo0O . i1I111II1I
  try :
   i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if i1Oo00 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    ooO0000o00O = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
    if 10 - 10: O0ooOooooO * o0oO0 - iI . O0oO - IIII
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 94 - 94: OOooOOo % i1I111II1I + OoOO
 else :
  if 90 - 90: i1IIi + O0 - oO0o0ooO0 . O0ooOooooO + iIii1I11I1II1
  if 'https://team.com' in url :
   if 88 - 88: o0oO0 * O0 . Oooo0Ooo000 / OoooooooOO
   url = url . replace ( 'https://team.com' , 'https://verystream.com' )
   if 29 - 29: OoooooooOO . II111iiii % OoOO0ooOOoo0O
   if 26 - 26: iIii1I11I1II1 - o00O0oo . i1I111II1I . i1I111II1I + iIii1I11I1II1 * ii11ii1ii
  if 'https://drive.com' in url :
   if 85 - 85: IIII + II111iiii - IIII * oO0o0ooO0 - i1IIi % O0ooOooooO
   url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
   if 1 - 1: OoooooooOO / O0 + OoOO0ooOOoo0O + OoOO0ooOOoo0O . Oooo0Ooo000 - OoOO0ooOOoo0O
  if 'https://vid.co' in url :
   if 9 - 9: Oooo0Ooo000 * OoooooooOO % OOooOOo / OoOO0ooOOoo0O * O0oO
   url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
   if 48 - 48: OoooooooOO . OoOO0ooOOoo0O
  if 'https://limited.to' in url :
   if 65 - 65: oO0o0ooO0 . ii11ii1ii
   url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
   if 94 - 94: OoOO0ooOOoo0O + i1I111II1I . iI
  import resolveurl
  if 69 - 69: O0 - O0
  o00ooo = urlresolver . HostedMediaFile ( url )
  if 41 - 41: i1I111II1I % o0000oOoOoO0o
  if 67 - 67: O0 % Oooo0Ooo000
  if not o00ooo :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no encontrado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 35 - 35: OOooOOo . OoOO0ooOOoo0O + OoooooooOO % ii11ii1ii % IIII
  try :
   iIIi1iI1I1IIi = o00ooo . resolve ( )
   if not iIIi1iI1I1IIi or not isinstance ( iIIi1iI1I1IIi , basestring ) :
    try : O0OO0 = iIIi1iI1I1IIi . msg
    except : O0OO0 = url
    raise Exception ( O0OO0 )
  except Exception as oO0o00oOOooO0 :
   try : O0OO0 = str ( oO0o00oOOooO0 )
   except : O0OO0 = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace borrado, o no encontrado. Prueba a reiniciar el router o poner una VPN.[/COLOR]  ,5000)" )
   return False
   if 39 - 39: o0oO0
   if 60 - 60: IIII
   if 62 - 62: Oooo0Ooo000 * O0oO
   i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if i1Oo00 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
    if 74 - 74: OoOO0ooOOoo0O . iIii1I11I1II1
    if 'uptostream.com' or 'uptobox.com' in url :
     iiI111I1iIiI = IiII1IiiIiI1 . getSetting ( 'restante' )
    elif iiI111I1iIiI == 'true' :
     i1iI = xbmcgui . Dialog ( )
     iii11 = i1iI . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 87 - 87: iI
  ooO0000o00O = xbmcgui . ListItem ( path = iIIi1iI1I1IIi )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
  if 41 - 41: OoOO0ooOOoo0O . iIii1I11I1II1 % iI + O0
 return
 if 22 - 22: o0000oOoOoO0o + ii11ii1ii . iI + o00O0oo * O0ooOooooO . i11iIiiIii
 if 90 - 90: IIII * OoOO0ooOOoo0O - ii11ii1ii + o0000oOoOoO0o
def OoOII11IiI1 ( name , url ) :
 if 86 - 86: iIii1I11I1II1 % oO0o0ooO0 - OoOO0ooOOoo0O + Oooo0Ooo000 % OoOO . o00O0oo
 if 'mybox.com' in url :
  if 4 - 4: i1IIi + OoOO0ooOOoo0O
  url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
  if 39 - 39: iIii1I11I1II1 + iI
  try :
   if 92 - 92: O0oO % i11iIiiIii % ii11ii1ii
   o0OOOo = ii1iiIiIII1ii ( url )
   oO0o0oooO0oO = re . compile ( oO0 ) . findall ( o0OOOo )
   for url , ii11Ii1IiiI1 , O00o0o in oO0o0oooO0oO :
    if 65 - 65: o00O0oo % oO0o0ooO0 . OoooooooOO * o0000oOoOoO0o * OoOO
    ii11Ii1IiiI1 = ii11Ii1IiiI1 . replace ( '","res":"1080",' , '' ) . replace ( '","res":"720",' , '' ) . replace ( '","res":"480",' , '' ) . replace ( '","res":"360",' , '' )
    url = url . replace ( '\/' , '/' )
    url = url . replace ( ',"type":"video/mp4",' , ' ' )
    name = '[COLOR white]' + ii11Ii1IiiI1 + '[/COLOR] - [COLOR gold]' + O00o0o + '[/COLOR]'
    if 10 - 10: oO0o0ooO0 - O0ooOooooO % II111iiii - Oooo0Ooo000 - i1IIi
    iIi11iI1i = [ ]
    iIi11iI1i . append ( '[COLOR orange]Real Stream: [/COLOR][COLOR gold]1. Mostrar mas info. [Reiniciar][/COLOR]' )
    iIi11iI1i . append ( '[COLOR gold]2. Mostar otras calidades disponibles [/COLOR]' )
    iIi11iI1i . append ( '[COLOR gold]3. Ver en: %s [/COLOR]' % name )
    if 46 - 46: i1IIi + II111iiii * i1IIi - o0oO0
    if 79 - 79: II111iiii - oO0o0ooO0 * o00O0oo - OoOO0ooOOoo0O . o00O0oo
    iiII1IIii1i1 = 'Seleccione una calidad e idioma:'
    i1iI = xbmcgui . Dialog ( )
    i1iiiIIi11II = i1iI . select ( iiII1IIii1i1 , iIi11iI1i )
    if 55 - 55: O0oO
    if 93 - 93: i11iIiiIii . o0000oOoOoO0o
    if 16 - 16: i1IIi . i1IIi / Oooo0Ooo000 % OoOO0ooOOoo0O / OOooOOo * o00O0oo
    if i1iiiIIi11II == 0 :
     if 30 - 30: o0000oOoOoO0o + OoooooooOO + IIII / II111iiii * ii11ii1ii
     iii11 = i1iI . ok ( "[COLOR darkpink]REALSTREAM:[/COLOR] " , "[COLOR gold]  Reiniciadas las opciones.  [/COLOR]" , "" )
     del i1iI
     return
     if 59 - 59: o0oO0 / OoOO0ooOOoo0O * OoOO * O0ooOooooO % oO0o0ooO0
    elif i1iiiIIi11II == 1 :
     if 61 - 61: ii11ii1ii - O0 - OoooooooOO
     pass
     if 4 - 4: II111iiii - oO0o0ooO0 % ii11ii1ii * i11iIiiIii
     del i1iI
     if 18 - 18: ii11ii1ii % O0
     if 66 - 66: iIii1I11I1II1 % i11iIiiIii / OOooOOo
    elif i1iiiIIi11II == 2 :
     if 47 - 47: o00O0oo * oO0o0ooO0 + iIii1I11I1II1 - oO0o0ooO0 / i1I111II1I
     iIIiI11iI1Ii1 ( name , url )
     if 86 - 86: i1I111II1I
     return
     if 43 - 43: OOooOOo / O0ooOooooO / iI + iIii1I11I1II1 + OoooooooOO
  except :
   pass
   if 33 - 33: II111iiii - i1I111II1I - iI
 elif 'uptostream.com' in url :
  if 92 - 92: OoOO * i1I111II1I
  try :
   if 92 - 92: oO0o0ooO0
   o0OOOo = ii1iiIiIII1ii ( url )
   oO0o0oooO0oO = re . compile ( oO0 ) . findall ( o0OOOo )
   for url , ii11Ii1IiiI1 , O00o0o in oO0o0oooO0oO :
    if 7 - 7: O0ooOooooO
    ii11Ii1IiiI1 = ii11Ii1IiiI1 . replace ( '","res":"1080",' , '' ) . replace ( '","res":"720",' , '' ) . replace ( '","res":"480",' , '' ) . replace ( '","res":"360",' , '' )
    url = url . replace ( '\/' , '/' )
    url = url . replace ( ',"type":"video/mp4",' , ' ' )
    name = '[COLOR white]Calidad: ' + ii11Ii1IiiI1 + '[/COLOR] [COLOR gold]Idioma: ' + O00o0o + '[/COLOR]'
    if 73 - 73: OoOO % o00O0oo
    iIi11iI1i = [ ]
    iIi11iI1i . append ( '[COLOR orange]Real Stream: [/COLOR][COLOR gold]1. Mostrar mas info. [Reiniciar][/COLOR]' )
    iIi11iI1i . append ( '[COLOR gold]2. Mostar otras calidades disponibles [/COLOR]' )
    iIi11iI1i . append ( '[COLOR gold]3. Ver en: %s [/COLOR]' % name )
    if 32 - 32: IIII + O0ooOooooO + iIii1I11I1II1 * ii11ii1ii
    if 62 - 62: i11iIiiIii
    iiII1IIii1i1 = 'Seleccione una calidad e idioma:'
    i1iI = xbmcgui . Dialog ( )
    i1iiiIIi11II = i1iI . select ( iiII1IIii1i1 , iIi11iI1i )
    if 2 - 2: OOooOOo
    if 69 - 69: OoooooooOO / ii11ii1ii * Oooo0Ooo000
    if i1iiiIIi11II == 0 :
     if 99 - 99: II111iiii * iIii1I11I1II1 % O0 * oO0o0ooO0 / II111iiii % OoooooooOO
     iii11 = i1iI . ok ( "[COLOR darkpink]REALSTREAM:[/COLOR] " , "[COLOR gold]  Reiniciadas las opciones.  [/COLOR]" , "" )
     del i1iI
     return
     if 14 - 14: i1I111II1I . i1I111II1I % iI
    elif i1iiiIIi11II == 1 :
     if 42 - 42: o0000oOoOoO0o . IIII - iI
     pass
     if 33 - 33: II111iiii / O0 / i1I111II1I - O0oO - i1IIi
     del i1iI
     if 8 - 8: i11iIiiIii . O0ooOooooO / iIii1I11I1II1 / o00O0oo / i1I111II1I - o0oO0
     if 32 - 32: o0000oOoOoO0o . i1IIi * ii11ii1ii
     if 98 - 98: o0oO0 - II111iiii / OOooOOo . oO0o0ooO0 * i1I111II1I . O0oO
     if 25 - 25: i11iIiiIii / OoOO0ooOOoo0O - Oooo0Ooo000 / OoOO . o0000oOoOoO0o . o0000oOoOoO0o
    elif i1iiiIIi11II == 2 :
     if 6 - 6: oO0o0ooO0 . O0oO
     iIIiI11iI1Ii1 ( name , url )
     if 43 - 43: o00O0oo + o0000oOoOoO0o
     return
     if 50 - 50: oO0o0ooO0 % i1IIi * O0
  except :
   pass
 else :
  if 4 - 4: iIii1I11I1II1 . i1IIi
  O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
  o00iI = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  O0O0Oooo0o = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  oOOoO = IiII1IiiIiI1 . getSetting ( 'key_ext' )
  o0OOOo = ii1iiIiIII1ii ( O0O0Oooo0o )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for iIi11ii in oO0o0oooO0oO :
   if 63 - 63: iIii1I11I1II1 + i1I111II1I % i1IIi / OOooOOo % II111iiii
   try :
    if 60 - 60: o0000oOoOoO0o . OoOO0ooOOoo0O % Oooo0Ooo000 / OOooOOo / O0
    if 19 - 19: i11iIiiIii . OOooOOo + II111iiii / IIII . o00O0oo * iI
    O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
    if 59 - 59: iIii1I11I1II1 / o00O0oo % iI
    if 84 - 84: iIii1I11I1II1 / OOooOOo . OoOO0ooOOoo0O % O0oO
    if O00O0oOO00O00 == iIi11ii :
     if 99 - 99: ii11ii1ii + i11iIiiIii
     if 36 - 36: o0oO0 * Oooo0Ooo000 * iIii1I11I1II1 - O0oO % i11iIiiIii
     if 'https://team.com' in url :
      if 98 - 98: iIii1I11I1II1 - i1IIi + iI % O0oO + iI / oO0o0ooO0
      url = url . replace ( 'https://team.com' , 'https://verystream.com' )
      if 97 - 97: i1I111II1I % iI + II111iiii - i1I111II1I % OoOO + iI
     if 'https://mybox.com' in url :
      if 31 - 31: o0000oOoOoO0o
      url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
      if 35 - 35: OoOO0ooOOoo0O + o0oO0 * iI / OoOO0ooOOoo0O
      if 69 - 69: iI . IIII - OOooOOo
     if 'https://vidcloud.co/' in url :
      if 29 - 29: i11iIiiIii . o00O0oo / OOooOOo . IIII + i11iIiiIii
      url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
      if 26 - 26: i1I111II1I / o0oO0 - OoooooooOO
     if 'https://gounlimited.to' in url :
      if 9 - 9: OoooooooOO * o00O0oo
      url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
      if 9 - 9: ii11ii1ii + O0ooOooooO
     if 'https://drive.com' in url :
      if 64 - 64: O0 * OOooOOo / OOooOOo
      url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
      if 57 - 57: o00O0oo / OoooooooOO % o00O0oo . O0 / o00O0oo
      if 63 - 63: i1I111II1I + iIii1I11I1II1 + OOooOOo + Oooo0Ooo000
     import resolveurl
     if 72 - 72: OoOO + i11iIiiIii + o00O0oo
     o00ooo = urlresolver . HostedMediaFile ( url )
     if 96 - 96: oO0o0ooO0 % i1IIi / o0000oOoOoO0o
     if not o00ooo :
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
      return False
      if 13 - 13: II111iiii - ii11ii1ii % i11iIiiIii + O0ooOooooO
     try :
      if 88 - 88: O0 . oO0o0ooO0 % OOooOOo
      iI1I = xbmcgui . DialogProgress ( )
      iI1I . create ( 'Realstream:' , 'Iniciando ...' )
      iI1I . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
      xbmc . sleep ( 1000 )
      if 10 - 10: OOooOOo + O0
      iIIi1iI1I1IIi = o00ooo . resolve ( )
      if not iIIi1iI1I1IIi or not isinstance ( iIIi1iI1I1IIi , basestring ) :
       if 75 - 75: O0 % iIii1I11I1II1 / OoOO0ooOOoo0O % IIII / i1I111II1I
       try : O0OO0 = iIIi1iI1I1IIi . msg
       except : O0OO0 = url
       raise Exception ( O0OO0 )
       if 31 - 31: i11iIiiIii * OoOO0ooOOoo0O
     except Exception as oO0o00oOOooO0 :
      try : O0OO0 = str ( oO0o00oOOooO0 )
      except : O0OO0 = url
      if 69 - 69: i11iIiiIii
      if 61 - 61: O0
      if 21 - 21: OoOO % iIii1I11I1II1 . OoOO
      for OO000OOOo0Oo in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       Oo00O0O = 1
       iI1I . update ( 45 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % OO000OOOo0Oo )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5  Puede cancelar cuando desee o esperar...,  1000)" % Oo00O0O )
       iI1I . close ( )
       if 70 - 70: OoOO
      for OO000OOOo0Oo in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       Oo00O0O = 2
       iI1I . update ( 48 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % OO000OOOo0Oo )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % Oo00O0O )
       iI1I . close ( )
      for OO000OOOo0Oo in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       Oo00O0O = 3
       iI1I . update ( 50 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % OO000OOOo0Oo )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % Oo00O0O )
       iI1I . close ( )
      for OO000OOOo0Oo in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       Oo00O0O = 4
       iI1I . update ( 53 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % OO000OOOo0Oo )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % Oo00O0O )
       iI1I . close ( )
      for OO000OOOo0Oo in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       Oo00O0O = 5
       iI1I . update ( 55 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % OO000OOOo0Oo )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % Oo00O0O )
       iI1I . close ( )
       if 43 - 43: OoOO0ooOOoo0O
      if iI1I . iscanceled ( ) :
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Cancelando !! , 2000)" )
       iI1I . close ( )
       break
       if 57 - 57: OOooOOo
       if 65 - 65: i11iIiiIii - iI * O0oO + iI / i1I111II1I + o0000oOoOoO0o
       if 35 - 35: O0 + ii11ii1ii - OOooOOo % o0oO0 % II111iiii
     iI1I . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
     xbmc . sleep ( 500 )
     iI1I . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
     xbmc . sleep ( 1000 )
     iI1I . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
     iI1I . close ( )
     i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
     ooO0000o00O = xbmcgui . ListItem ( path = iIIi1iI1I1IIi )
     xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooO0000o00O )
     if 77 - 77: Oooo0Ooo000 + oO0o0ooO0
     if 38 - 38: o00O0oo - o0oO0 * o0000oOoOoO0o
    else :
     if 13 - 13: OOooOOo * oO0o0ooO0
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold] El addon no ha podido conectar al servidor.[/COLOR]" )
     return False
     if 41 - 41: i1I111II1I
   except :
    pass
    if 16 - 16: iIii1I11I1II1
 return
 if 94 - 94: iI % O0oO % i1IIi
 if 90 - 90: o0oO0 * OoOO
 if 7 - 7: O0ooOooooO . o0oO0 . O0ooOooooO - Oooo0Ooo000
 if 33 - 33: iI + OoooooooOO - OoOO / i1IIi / OoooooooOO
def OOO0 ( ) :
 if 21 - 21: ii11ii1ii * o0000oOoOoO0o + OoooooooOO . Oooo0Ooo000 % oO0o0ooO0
 IIIIIiiI = [ ]
 i1iIii = sys . argv [ 2 ]
 if len ( i1iIii ) >= 2 :
  O0o00 = sys . argv [ 2 ]
  I1IIi1iI1iiI = O0o00 . replace ( '?' , '' )
  if ( O0o00 [ len ( O0o00 ) - 1 ] == '/' ) :
   O0o00 = O0o00 [ 0 : len ( O0o00 ) - 2 ]
  iiI11I1ii11 = I1IIi1iI1iiI . split ( '&' )
  IIIIIiiI = { }
  for OO000OOOo0Oo in range ( len ( iiI11I1ii11 ) ) :
   O0OoO0oooOO = { }
   O0OoO0oooOO = iiI11I1ii11 [ OO000OOOo0Oo ] . split ( '=' )
   if ( len ( O0OoO0oooOO ) ) == 2 :
    IIIIIiiI [ O0OoO0oooOO [ 0 ] ] = O0OoO0oooOO [ 1 ]
 return IIIIIiiI
 if 44 - 44: iI * i11iIiiIii
 if 6 - 6: o0000oOoOoO0o % IIII * o00O0oo % o0oO0 . IIII
def iI1 ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  import urlresolver
  xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
  if 99 - 99: OoOO / i1IIi . o00O0oo
def I1I1i11iiiiI ( ) :
 i1iI = xbmcgui . Dialog ( )
 list = (
 oOOooI1I1i11 ,
 oOo0Oo00O
 )
 if 28 - 28: iI . i1IIi
 o0o00O = i1iI . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=%s]Accede a themoviedb.com[/COLOR]' % oo00O00oO ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 46 - 46: OoOO0ooOOoo0O
 if o0o00O :
  if 4 - 4: O0ooOooooO + O0
  if o0o00O < 0 :
   return
  I1IiiiI = list [ o0o00O - 2 ]
  return I1IiiiI ( )
 else :
  I1IiiiI = list [ o0o00O ]
  return I1IiiiI ( )
 return
 if 6 - 6: OOooOOo - i11iIiiIii
def O00O0O0OO00oo ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 39 - 39: i1I111II1I % OoOO0ooOOoo0O * o00O0oo - OoooooooOO - ii11ii1ii
Oo0 = O00O0O0OO00oo ( )
if 96 - 96: i1IIi
def oOOooI1I1i11 ( ) :
 if Oo0 == 'android' :
  O00oOoo0OoO0 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  O00oOoo0OoO0 = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 55 - 55: oO0o0ooO0 + IIII + o0oO0
  if 82 - 82: o00O0oo . II111iiii / OoOO0ooOOoo0O / OoOO
def oOo0Oo00O ( ) :
 if 47 - 47: O0ooOooooO + O0 / II111iiii * OOooOOo - OoooooooOO . o0oO0
 main ( )
 if 28 - 28: oO0o0ooO0 . oO0o0ooO0 . iIii1I11I1II1 . IIII . o00O0oo * i11iIiiIii
 if 72 - 72: O0oO
 if 26 - 26: i1I111II1I % ii11ii1ii
def OoOOoo ( ) :
 i1iI = xbmcgui . Dialog ( )
 II1ii1 = (
 iI1Iii11i ,
 O0OOOo0o
 )
 if 73 - 73: O0 * Oooo0Ooo000 . i1IIi
 o0o00O = i1iI . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 51 - 51: OoOO - O0ooOooooO % O0 - OoOO0ooOOoo0O
 if o0o00O :
  if 53 - 53: O0ooOooooO / i1IIi / i1IIi
  if o0o00O < 0 :
   return
  I1IiiiI = II1ii1 [ o0o00O - 2 ]
  return I1IiiiI ( )
 else :
  I1IiiiI = II1ii1 [ o0o00O ]
  return I1IiiiI ( )
 return
 if 77 - 77: O0oO + i1IIi . O0oO
def O00O0O0OO00oo ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 89 - 89: o0000oOoOoO0o + IIII * oO0o0ooO0
Oo0 = O00O0O0OO00oo ( )
if 45 - 45: O0ooOooooO - o0000oOoOoO0o . o0oO0
def iI1Iii11i ( ) :
 if Oo0 == 'android' :
  O00oOoo0OoO0 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  O00oOoo0OoO0 = webbrowser . open ( 'https://olpair.com/' )
  if 41 - 41: II111iiii . OOooOOo / OoOO . iI
  if 58 - 58: i1I111II1I % i11iIiiIii * II111iiii . o00O0oo
def O0OOOo0o ( ) :
 if 94 - 94: i11iIiiIii . IIII + iIii1I11I1II1 * Oooo0Ooo000 * Oooo0Ooo000
 main ( )
 if 36 - 36: O0oO - i1I111II1I . i1I111II1I
 if 60 - 60: i11iIiiIii * ii11ii1ii % OoOO + OoOO
def ooo000o ( name , url , id , trailer ) :
 i1iI = xbmcgui . Dialog ( )
 II1ii1 = (
 OOOOOO ,
 oOO0O ,
 oooo0 ,
 I1I1i11iiiiI ,
 OOOOiiI
 )
 if 89 - 89: iI * o0oO0
 o0o00O = i1iI . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % oo00O00oO ,

 '[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % oo00O00oO ,

 '[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % oo00O00oO ,

 '[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % oo00O00oO ,

 '[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % oo00O00oO ] )
 if 93 - 93: i1IIi . o0oO0 * Oooo0Ooo000 . iI
 if o0o00O :
  if 54 - 54: O0ooOooooO . i1IIi . o00O0oo * o0000oOoOoO0o % O0ooOooooO
  if o0o00O < 0 :
   return
  I1IiiiI = II1ii1 [ o0o00O - 5 ]
  return I1IiiiI ( )
 else :
  I1IiiiI = II1ii1 [ o0o00O ]
  return I1IiiiI ( )
 return
 if 30 - 30: O0oO
 if 85 - 85: II111iiii + iI * O0oO
 if 12 - 12: o0oO0 . OOooOOo % o0000oOoOoO0o
def OOOOOO ( ) :
 if 28 - 28: o0oO0 - OOooOOo % OoOO * Oooo0Ooo000
 OoOII11IiI1 ( Ii111 , I111i1i1111 )
 if 80 - 80: IIII * i1I111II1I
def oOO0O ( ) :
 if 4 - 4: iIii1I11I1II1 . Oooo0Ooo000 + II111iiii % OoooooooOO
 OoO000Oo0oO ( Ii111 , IIII1 )
 if 82 - 82: OoooooooOO / iI * O0oO * O0 . o00O0oo
def oooo0 ( ) :
 if 21 - 21: II111iiii + ii11ii1ii
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  OOooooO = id
  if 80 - 80: OoOO0ooOOoo0O + iIii1I11I1II1 . i1I111II1I
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % OOooooO )
  if 76 - 76: OOooOOo * IIII
 if i1Oo00 == 'true' :
  if 12 - 12: iIii1I11I1II1 / O0oO % o0oO0
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + Ii111 + "[/COLOR] ,5000)" )
  if 49 - 49: OoOO + II111iiii / i1I111II1I - O0 % o0oO0
def iII1i1 ( ) :
 if 34 - 34: OoOO / OoooooooOO - oO0o0ooO0 / oO0o0ooO0 * OOooOOo
 I1I1i11iiiiI ( )
 if 61 - 61: O0oO
def OOOOiiI ( ) :
 if 81 - 81: O0oO
 O0Oo00 ( )
def IIi ( name , url , mode , iconimage , fanart ) :
 if 92 - 92: IIII - ii11ii1ii - OoooooooOO / i1I111II1I - i1IIi
 IIo0OoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 iii11 = True
 IIIIIiII1 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 IIIIIiII1 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IIIIIiII1 . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  IIo0OoO00 = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  iii11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIo0OoO00 , listitem = IIIIIiII1 , isFolder = True )
  return iii11
 iii11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIo0OoO00 , listitem = IIIIIiII1 , isFolder = True )
 return iii11
 if 81 - 81: i1IIi / Oooo0Ooo000 % i11iIiiIii . iIii1I11I1II1 * OoOO0ooOOoo0O + OoooooooOO
def iIIiI1I1i ( name , url , mode , iconimage , fanart , description ) :
 if 31 - 31: i1IIi % II111iiii
 IIo0OoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 iii11 = True
 IIIIIiII1 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 IIIIIiII1 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 IIIIIiII1 . setProperty ( 'fanart_image' , fanart )
 iii11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIo0OoO00 , listitem = IIIIIiII1 , isFolder = True )
 return iii11
 if 13 - 13: iIii1I11I1II1 - II111iiii % O0 . o0oO0 % OoOO
def Ii11iIiiI ( name , url , mode , iconimage ) :
 if 3 - 3: II111iiii / IIII
 IIo0OoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 iii11 = True
 IIIIIiII1 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 IIIIIiII1 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 IIIIIiII1 . setProperty ( 'fanart_image' , oo00 )
 iii11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIo0OoO00 , listitem = IIIIIiII1 , isFolder = True )
 return iii11
 if 48 - 48: iI . o00O0oo
 if 49 - 49: i1IIi - OoOO0ooOOoo0O . ii11ii1ii + iIii1I11I1II1 - iI / ii11ii1ii
def oOoOo0o00o ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 24 - 24: oO0o0ooO0 - O0ooOooooO / iI
 oo0OOo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 10 - 10: OoOO0ooOOoo0O * i1IIi
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 I1Ii1ii = [ ]
 if 34 - 34: OOooOOo
 I1Ii1ii . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 IIo0OoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 IIIIIiII1 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 IIIIIiII1 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IIIIIiII1 . setProperty ( 'fanart_image' , fanart )
 IIIIIiII1 . setProperty ( 'IsPlayable' , 'true' )
 if 57 - 57: IIII . o0oO0 % o0000oOoOoO0o
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  I1Ii1ii . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 32 - 32: O0oO / i1I111II1I - O0 * iIii1I11I1II1
  IIIIIiII1 . addContextMenuItems ( I1Ii1ii , replaceItems = True )
 iii11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIo0OoO00 , listitem = IIIIIiII1 )
 return iii11
 if 70 - 70: OoooooooOO % OoooooooOO % OoOO
 if 98 - 98: OoOO
def O00Oo ( name , url , mode , iconimage , fanart , id , trailer , description ) :
 if 18 - 18: O0oO + ii11ii1ii - OoOO / Oooo0Ooo000 / IIII
 oo0OOo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 53 - 53: IIII + o0000oOoOoO0o . oO0o0ooO0 / O0oO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 I1Ii1ii = [ ]
 if 52 - 52: Oooo0Ooo000 + Oooo0Ooo000
 I1Ii1ii . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 IIo0OoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 IIIIIiII1 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 IIIIIiII1 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 IIIIIiII1 . setProperty ( 'fanart_image' , fanart )
 IIIIIiII1 . setProperty ( 'IsPlayable' , 'true' )
 if 73 - 73: o0000oOoOoO0o . i11iIiiIii % OoooooooOO + iI . OoooooooOO / IIII
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  I1Ii1ii . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 54 - 54: OoOO0ooOOoo0O . OoooooooOO
  IIIIIiII1 . addContextMenuItems ( I1Ii1ii , replaceItems = True )
 iii11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIo0OoO00 , listitem = IIIIIiII1 )
 return iii11
 if 36 - 36: oO0o0ooO0 / II111iiii * i1I111II1I % o00O0oo
def oOooOOo00ooO ( name , url , mode , iconimage , fanart ) :
 if 31 - 31: II111iiii + IIII - OoooooooOO . O0oO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 28 - 28: o0oO0 . o00O0oo
 IIo0OoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 IIIIIiII1 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 IIIIIiII1 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IIIIIiII1 . setProperty ( 'fanart_image' , fanart )
 IIIIIiII1 . setProperty ( 'IsPlayable' , 'true' )
 iii11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIo0OoO00 , listitem = IIIIIiII1 )
 return iii11
 if 77 - 77: o00O0oo % II111iiii
def OOo00o0oo0 ( name , url , mode , iconimage ) :
 if 33 - 33: o0000oOoOoO0o . IIII + o0000oOoOoO0o / o00O0oo . ii11ii1ii + OoOO0ooOOoo0O
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 32 - 32: i1I111II1I - iI * O0ooOooooO * O0oO
 IIo0OoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 IIIIIiII1 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 IIIIIiII1 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IIIIIiII1 . setProperty ( 'fanart_image' , oo00 )
 IIIIIiII1 . setProperty ( 'IsPlayable' , 'true' )
 iii11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIo0OoO00 , listitem = IIIIIiII1 )
 return iii11
 if 84 - 84: o0oO0 + o00O0oo % OOooOOo + i11iIiiIii
def i1iI11Ii1i ( name , url , mode , iconimage ) :
 IIo0OoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 iii11 = True
 IIIIIiII1 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iii11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIo0OoO00 , listitem = IIIIIiII1 , isFolder = True )
 return iii11
 if 45 - 45: OOooOOo . ii11ii1ii . Oooo0Ooo000 / oO0o0ooO0
def ii1iI11 ( ) :
 if 87 - 87: oO0o0ooO0 * OoOO0ooOOoo0O + o0oO0 * i11iIiiIii % i1I111II1I . OoooooooOO
 if 74 - 74: OoOO . O0 * O0 - o0000oOoOoO0o . OoooooooOO * oO0o0ooO0
 if 2 - 2: OOooOOo * Oooo0Ooo000 % Oooo0Ooo000 - Oooo0Ooo000 - O0ooOooooO + IIII
 oooooo0OO = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 oooooo0OO . doModal ( )
 if ( oooooo0OO . isConfirmed ( ) ) :
  if 7 - 7: O0oO - OoOO . OoooooooOO / OoooooooOO - O0oO
  O0o0O0 = urllib . quote_plus ( oooooo0OO . getText ( ) ) . replace ( '+' , ' ' )
  if 84 - 84: II111iiii
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 36 - 36: IIII - OoOO0ooOOoo0O - iIii1I11I1II1
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % O0o0O0 )
    if 10 - 10: o00O0oo / o0oO0 * i1IIi % O0 + O0oO
    if i1Oo00 == 'true' :
     if 25 - 25: Oooo0Ooo000 - o0oO0 / O0 . OoooooooOO % OOooOOo . i1IIi
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + Ii111 + "[/COLOR] ,10000)" )
     if 19 - 19: II111iiii / II111iiii % o00O0oo + oO0o0ooO0 + oO0o0ooO0 + O0ooOooooO
   except :
    if 4 - 4: o0000oOoOoO0o + O0oO / O0ooOooooO + i1IIi % o0000oOoOoO0o % O0ooOooooO
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 80 - 80: o0oO0
O0o00 = OOO0 ( )
I111i1i1111 = None
Ii111 = None
ii = None
OO0O0o0o0 = None
id = None
IIII1 = None
if 66 - 66: o00O0oo . ii11ii1ii
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 38 - 38: O0oO . i1I111II1I - OoOO . OOooOOo
try :
 I111i1i1111 = urllib . unquote_plus ( O0o00 [ "url" ] )
except :
 pass
try :
 Ii111 = urllib . unquote_plus ( O0o00 [ "name" ] )
except :
 pass
try :
 ii = int ( O0o00 [ "mode" ] )
except :
 pass
try :
 OO0O0o0o0 = urllib . unquote_plus ( O0o00 [ "iconimage" ] )
except :
 pass
try :
 id = int ( O0o00 [ "id" ] )
except :
 pass
try :
 IIII1 = urllib . unquote_plus ( O0o00 [ "trailer" ] )
except :
 pass
 if 65 - 65: Oooo0Ooo000
 if 31 - 31: i11iIiiIii / OoOO0ooOOoo0O % o00O0oo
print "Mode: " + str ( ii )
print "URL: " + str ( I111i1i1111 )
print "Name: " + str ( Ii111 )
print "iconimage: " + str ( OO0O0o0o0 )
print "id: " + str ( id )
print "trailer: " + str ( IIII1 )
if 44 - 44: II111iiii * OOooOOo + IIII
if ii == None or I111i1i1111 == None or len ( I111i1i1111 ) < 1 :
 if 31 - 31: o0oO0 * o0000oOoOoO0o * o0oO0 + OoOO * o0000oOoOoO0o . Oooo0Ooo000
 O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 o00iI = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 O0O0Oooo0o = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 oOOoO = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 o0OOOo = ii1iiIiIII1ii ( O0O0Oooo0o )
 oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
 for iIi11ii in oO0o0oooO0oO :
  if 89 - 89: OoooooooOO * o0oO0 * OOooOOo . iI * o0oO0 / O0ooOooooO
  try :
   if 46 - 46: i11iIiiIii
   if 15 - 15: O0 / i1IIi / i1IIi . O0ooOooooO % OoOO0ooOOoo0O + OOooOOo
   O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 48 - 48: Oooo0Ooo000 % O0ooOooooO % o0oO0 % iIii1I11I1II1 . o0oO0
   if 14 - 14: O0ooOooooO * OoOO % O0 + O0oO + o00O0oo
   if O00O0oOO00O00 == iIi11ii :
    O0Oo00 ( )
    O00o0OO0000oo ( )
    if 23 - 23: ii11ii1ii % O0ooOooooO + o0oO0 - Oooo0Ooo000
   else :
    if 65 - 65: OoooooooOO
    oo00O00oO = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
    IIi ( '[COLOR %s]Video tutoriales[/COLOR]' % oo00O00oO , o00oooO0Oo , 125 , O0OOO0OOoO0O , oo00 )
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Por favor compruebe los ajustes de realstream.[/COLOR]" , "[COLOR white] Desde la seccion Tutoriales puede sacarle mayor partido a su Realstream, tambien puede configurarlo a su gusto. [/COLOR]" , "[COLOR gold]El addon no esta activado o bien configurado.[/COLOR]" )
    if 22 - 22: IIII + II111iiii + ii11ii1ii
    if 83 - 83: iI
  except :
   pass
   if 43 - 43: IIII
elif ii == 1 :
 ooo000o ( Ii111 , I111i1i1111 , id , IIII1 )
elif ii == 2 :
 iI1I1II1 ( )
elif ii == 3 :
 I1iIiI1IiIIII ( )
elif ii == 4 :
 O0OO000OOo0o ( Ii111 , I111i1i1111 )
elif ii == 5 :
 ooo0oOOO0 ( )
elif ii == 6 :
 oO00Ooo0oO ( )
elif ii == 7 :
 iIii1iII1Ii ( )
elif ii == 8 :
 o00IiI1iiII1i1i ( )
elif ii == 9 :
 i11i11 ( )
elif ii == 10 :
 Ii111Iiiii ( )
elif ii == 11 :
 II11ii ( )
elif ii == 12 :
 Iiiii111 ( )
elif ii == 13 :
 II1i11 ( )
elif ii == 14 :
 O0OOOOOO0 ( )
elif ii == 15 :
 oOOO0 ( )
elif ii == 16 :
 oo000oOO00o0oOO ( )
elif ii == 17 :
 o0oO0OO00oo0o ( )
elif ii == 18 :
 oOOoO0O ( )
elif ii == 19 :
 i1111IIiI ( )
elif ii == 20 :
 OoOooOO0oOOo0O ( )
elif ii == 21 :
 i111IiiI1Ii ( )
elif ii == 22 :
 o0O0OOo0oO ( )
elif ii == 23 :
 OOooO ( )
elif ii == 24 :
 oO0O0o0O ( )
elif ii == 25 :
 oo0oOO ( )
elif ii == 26 :
 Ii ( )
elif ii == 28 :
 Ii1IIi ( Ii111 , I111i1i1111 )
elif ii == 29 :
 I1I1I11Ii ( )
elif ii == 30 :
 O0OOO0 ( )
elif ii == 31 :
 prueba ( )
elif ii == 98 :
 busqueda_global ( )
elif ii == 97 :
 OoOOoo ( )
elif ii == 99 :
 I11i1iIiiIiIi ( )
elif ii == 100 :
 menu_player ( Ii111 , I111i1i1111 )
elif ii == 111 :
 oOOO00O0O0OOo ( )
elif ii == 115 :
 OoO000Oo0oO ( I111i1i1111 )
elif ii == 116 :
 oOOoo0o0OOOO ( )
elif ii == 117 :
 oOOiiiIIiIi ( )
elif ii == 119 :
 i1ii ( )
elif ii == 120 :
 ii1i1i1IiII ( )
elif ii == 121 :
 iIi1i ( )
elif ii == 125 :
 i1Iiii ( )
elif ii == 112 :
 list_proxy ( )
elif ii == 127 :
 ii1iI11 ( )
elif ii == 128 :
 TESTLINKS ( )
elif ii == 130 :
 OoOII11IiI1 ( Ii111 , I111i1i1111 )
elif ii == 140 :
 i11i1iIiii ( )
elif ii == 141 :
 iIi1 ( )
elif ii == 142 :
 I111I11I111 ( )
elif ii == 143 :
 ooOOOOo0 ( Ii111 , I111i1i1111 )
elif ii == 144 :
 Ii1IIi ( Ii111 , I111i1i1111 )
elif ii == 145 :
 OOO0ooo ( )
elif ii == 150 :
 oo0OOOoOo ( )
elif ii == 151 :
 IiI ( )
elif ii == 152 :
 iIIIi1i1I11i ( )
elif ii == 155 :
 oOoOOOo ( )
 if 84 - 84: IIII . i1I111II1I . O0ooOooooO
 if 2 - 2: ii11ii1ii - OoOO0ooOOoo0O
xbmcplugin . endOfDirectory ( o0OoOoOO00 ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
