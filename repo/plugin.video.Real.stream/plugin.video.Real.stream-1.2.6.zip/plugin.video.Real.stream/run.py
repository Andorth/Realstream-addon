# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 1.2.6
#
############################################
# Dependencias 
# Script ExtendedInfo
# Script Urlresolver de TVAddons
# Script ResolveURL Por Jsergio.
#
############################################
#
# Agregar sinopsis a Peliculas y series.
# Supresion de Licencia
# Novedades en episodios agregados en series.
#
############################################
if 64 - 64: i11iIiiIii
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import urlresolver
import cookielib , base64
import requests
import plugintools
import config
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
IiII1IiiIiI1 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
o0OoOoOO00 = int ( sys . argv [ 1 ] )
I11i = 'gruponetai/'
O0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
Oo = O0O . getAddonInfo ( 'profile' )
I1ii11iIi11i = O0O . getAddonInfo ( 'path' )
I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
if 73 - 73: OOooOOo / ii11ii1ii
if 94 - 94: OoOO + OoOO0ooOOoo0O + o0000oOoOoO0o * o00O0oo
if I1IiI == 'true' :
 if 97 - 97: oO0o0ooO0 - IIII / O0oO - o0oO0
 oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.png' ) )
 o00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 Oo0oO0ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.png' ) )
 i1111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.png' ) )
 i11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'estrenos.png' ) )
 I11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.png' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.png' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.png' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.png' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.png' ) )
 oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.png' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.png' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.png' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.png' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.png' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.png' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.png' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'marvel.png' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.png' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.png' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.png' ) )
 II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.png' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.png' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.png' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.png' ) )
 OO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.png' ) )
 Ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.png' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.png' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.png' ) )
 O0OO00o0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.png' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.png' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_series.png' ) )
 OOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_Episodios.png' ) )
 if 87 - 87: O0ooOooooO / i1I111II1I - Oooo0Ooo000 - iI - II111iiii / O0
else :
 if 97 - 97: iI - IIII * i11iIiiIii / OoOO0ooOOoo0O % Oooo0Ooo000 - OoooooooOO
 if 59 - 59: O0 + OOooOOo + i1I111II1I % OOooOOo
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
 oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.jpg' ) )
 o00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 Oo0oO0ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.jpg' ) )
 i1111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.jpg' ) )
 i11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'encines.jpg' ) )
 I11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.jpg' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.jpg' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.jpg' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.jpg' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.jpg' ) )
 oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.jpg' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.jpg' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.jpg' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.jpg' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.jpg' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.jpg' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.jpg' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'superheroes.jpg' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.jpg' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.jpg' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.jpg' ) )
 II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.jpg' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.jpg' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.jpg' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.jpg' ) )
 OO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.jpg' ) )
 Ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.jpg' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.jpg' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.jpg' ) )
 O0OO00o0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.png' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.png' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.png' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favoritos.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_series.png' ) )
 OOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_Episodios.png' ) )
 if 70 - 70: O0ooOooooO * o00O0oo
 if 46 - 46: iI / OoOO
 if 52 - 52: o0000oOoOoO0o - OoooooooOO + o0oO0 + o0oO0 - o0000oOoOoO0o / Oooo0Ooo000
I1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'peliculas.png' ) )
iIi11Ii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series.png' ) )
Ii11iII1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ajustes.png' ) )
Oo0O0O0ooO0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'videoteca.png' ) )
IIIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
O0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'resolver.png' ) )
OO00Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'test.png' ) )
O0OOO0OOoO0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'video-tutoriales.png' ) )
O00Oo000ooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'proxy.png' ) )
if 100 - 100: O0 + i1I111II1I - IIII + i11iIiiIii * o0oO0
if 30 - 30: o0000oOoOoO0o . o0oO0 - OoooooooOO
if 8 - 8: i1IIi - iIii1I11I1II1 * II111iiii + i11iIiiIii / Oooo0Ooo000 % IIII
iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
OOoOO0oo0ooO = IiII1IiiIiI1 . getSetting ( 'mostrar_cat' )
O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'sel_tobox' )
O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'videos' )
i1Oo00 = IiII1IiiIiI1 . getSetting ( 'activar' )
i1i = IiII1IiiIiI1 . getSetting ( 'favcopy' )
iiI111I1iIiI = IiII1IiiIiI1 . getSetting ( 'anticopia' )
IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
oooooOoo0ooo = IiII1IiiIiI1 . getSetting ( 'mostrar_bus' )
I1I1IiI1 = IiII1IiiIiI1 . getSetting ( 'restante' )
III1iII1I1ii = IiII1IiiIiI1 . getSetting ( 'selecton' )
oOOo0 = IiII1IiiIiI1 . getSetting ( 'aviso' )
oo00O00oO = IiII1IiiIiI1 . getSetting ( 'RealStream_Settings' )
iIiIIIi = IiII1IiiIiI1 . getSetting ( 'Resolver_Settings' )
I1I1IiI1 = IiII1IiiIiI1 . getSetting ( 'restante' )
ooo00OOOooO = IiII1IiiIiI1 . getSetting ( 'fav' )
O00OOOoOoo0O = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
O000OOo00oo = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
oo0OOo = 'bienvenida'
ooOOO00Ooo = 'bienvenida'
copyright = IiII1IiiIiI1 . getSetting ( 'copyright' )
IiIIIi1iIi = 'cGx1Z2luLnZpZGVvLg==' . decode ( 'base64' ) + copyright
ooOOoooooo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
II1I = IiII1IiiIiI1 . getSetting ( 'Forceupdate' )
if II1I == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
O0i1II1Iiii1I11 = 'LnR4dA==' . decode ( 'base64' )
IIIIiiIiI = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1NQOUpRZExS' . decode ( 'base64' )
if 91 - 91: O0ooOooooO % i1IIi % iIii1I11I1II1
if 20 - 20: IIII % o0oO0 / o0oO0 + o0oO0
III1IiiI = 'aHR0cDovL2JpdC5seS8yU1FOSnlP' . decode ( 'base64' )
iIi1 = O000OOo00oo + oo0OOo + O0i1II1Iiii1I11
IIIII11I1IiI = 'http://www.youtube.com'
i1I = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
OoOOooOOO0 = 'http://bit.ly/2ImelUx'
o0o = '.xsl.pt'
O0OOoO00OO0o = 'L21hc3Rlci8=' . decode ( 'base64' )
I1111IIIIIi = i1I + o0o
Iiii1i1 = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*'
OO = 'tvg-logo=[\'"](.*?)[\'"]'
if 77 - 77: ii11ii1ii
I1iII1iIi1I = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.*)'
oO0O00OoOO0 = '(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)'
OoO = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
O00 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
I1iI1 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
iiiIi1 = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
i1I1ii11i1Iii = '#(.+?),(.+)\s*(.+)'
I1IiiiiI = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
o0O = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
IiII = '[\'"](.*?)[\'"]'
ii1iII1II = r'066">\s*(.+)</f'
Iii1I1I11iiI1 = '[\'"](.*?)[\'"]'
I1I1i1I = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
ii1I = '[\'"](.*?)[\'"]'
O0oO0 = 'src":"(.*?)"label":"(.*?)"lang":"(.*?)"'
oO0 = 'https://pastebin.com/raw/SP9JQdLR'
O0OO0O = '[\'"](.*?)[\'"]'
OOOoOoO = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( 'base64' )
Ii1I1i = OOOoOoO + I11i
if 99 - 99: oO0o0ooO0 . O0ooOooooO + iI % oO0o0ooO0 . i11iIiiIii % O0
oOO00O = '[\'"](.*?)[\'"],[\'"](.*?)[\'"][\'"](.*?)[\'"]\s*'
OOOoo0OO = '[\'"](.*?)[\'"]'
oO0o0 = 'UmVhbHN0cmVhbQ==' . decode ( 'base64' )
iI1Ii11iIiI1 = 'video=[\'"](.*?)[\'"]'
OO0Oooo0oOO0O = '0110nhu' . replace ( '0110nhu' , 'nhu' )
o00O0 = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( 'base64' ) + OO0Oooo0oOO0O
oOO0O00Oo0O0o = '0101ahn' . replace ( '0101ahn' , 'sZn' )
ii1 = 'aHR0cDovL2JpdC5seS8yTnpB' . decode ( 'base64' ) + oOO0O00Oo0O0o
I1iIIiiIIi1i = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
O0O0ooOOO = '0110R0N' . replace ( '0110R0N' , 'R0N' )
oOOo0O00o = 'aHR0cDovL2JpdC5seS8yWEIx' . decode ( 'base64' ) + O0O0ooOOO
iIiIi11 = '0110pEJ' . replace ( '0110pEJ' , 'pEJ' )
OOO = 'aHR0cDovL2JpdC5seS8yd1Nh' . decode ( 'base64' ) + iIiIi11
iiiiI = 'ABBAOb5' . replace ( 'ABBAOb5' , 'Ob5' )
oooOo0OOOoo0 = 'aHR0cDovL2JpdC5seS8yRVhV' . decode ( 'base64' ) + iiiiI
OOoO = '0110jaw' . replace ( '0110jaw' , 'jaw' )
OO0O000 = 'aHR0cDovL2JpdC5seS8yd01M' . decode ( 'base64' ) + OOoO
iiIiI1i1 = '01109DI' . replace ( '01109DI' , '9DI' )
oO0O00oOOoooO = 'aHR0cDovL2JpdC5seS8ySXgz' . decode ( 'base64' ) + iiIiI1i1
IiIi11iI = '01103hs' . replace ( '01103hs' , '3hs' )
Oo0O00O000 = 'aHR0cDovL2JpdC5seS8zMW1U' . decode ( 'base64' ) + IiIi11iI
i11I1IiII1i1i = '01107DW' . replace ( '01107DW' , '7DW' )
oo = 'aHR0cDovL2JpdC5seS8yV1ln' . decode ( 'base64' ) + i11I1IiII1i1i
I1111i = '0110mLl' . replace ( '0110mLl' , 'mLl' )
iIIii = 'aHR0cDovL2JpdC5seS8yS0cw' . decode ( 'base64' ) + I1111i
o00O0O = '01102Hj' . replace ( '01102Hj' , '2Hj' )
ii1iii1i = 'aHR0cDovL2JpdC5seS8yWEJo' . decode ( 'base64' ) + o00O0O
Iii1I1111ii = '0110fXg' . replace ( '0110fXg' , 'fXg' )
ooOoO00 = 'aHR0cDovL2JpdC5seS8ySTVy' . decode ( 'base64' ) + Iii1I1111ii
Ii1IIiI1i = '0110NMH' . replace ( '0110NMH' , 'NMH' )
o0O00Oo0 = 'aHR0cDovL2JpdC5seS8yd0t6' . decode ( 'base64' ) + Ii1IIiI1i
IiII111i1i11 = '0110bwQ' . replace ( '0110bwQ' , 'bwQ' )
i111iIi1i1II1 = 'aHR0cDovL2JpdC5seS8yd01V' . decode ( 'base64' ) + IiII111i1i11
oooO = '0110xzG' . replace ( '0110xzG' , 'xzG' )
i1I1i111Ii = 'aHR0cDovL2JpdC5seS8yWHhz' . decode ( 'base64' ) + oooO
ooo = '0110x64' . replace ( '0110x64' , 'x64' )
i1i1iI1iiiI = 'aHR0cDovL2JpdC5seS8yRVlF' . decode ( 'base64' ) + ooo
Ooo0oOooo0 = '0110vUE' . replace ( '0110vUE' , 'vUE' )
oOOOoo00 = 'aHR0cDovL2JpdC5seS8yWmhW' . decode ( 'base64' ) + Ooo0oOooo0
iiIiIIIiiI = '01107ZL' . replace ( '01107ZL' , '7ZL' )
iiI1IIIi = 'aHR0cDovL2JpdC5seS8yWm4w' . decode ( 'base64' ) + iiIiIIIiiI
II11IiIi11 = '01106cf' . replace ( '01106cf' , '6cf' )
IIOOO0O00O0OOOO = 'aHR0cDovL2JpdC5seS8yRVlk' . decode ( 'base64' ) + II11IiIi11
I1iiii1I = '0110Jtp' . replace ( '0110Jtp' , 'Jtp' )
OOo0 = 'aHR0cDovL2JpdC5seS8yV3Nq' . decode ( 'base64' ) + I1iiii1I
oO00ooooO0o = '0110a5b' . replace ( '0110a5b' , 'a5b' )
oo0o = 'aHR0cDovL2JpdC5seS8yV3dj' . decode ( 'base64' ) + oO00ooooO0o
o0oO0oooOoo = '0110Q7u' . replace ( '0110Q7u' , 'Q7u' )
I1III1111iIi = 'aHR0cDovL2JpdC5seS8yV3NL' . decode ( 'base64' ) + o0oO0oooOoo
I1i111I = '0110rsq' . replace ( '0110rsq' , 'rsq' )
OooOo0oo0O0o00O = 'aHR0cDovL2JpdC5seS8ySzhE' . decode ( 'base64' ) + I1i111I
I1i11 = '0110DDR' . replace ( '0110DDR' , 'DDR' )
IiIi1I1 = 'aHR0cDovL2JpdC5seS8ySzd5' . decode ( 'base64' ) + I1i11
IiIIi1 = '0110feQ' . replace ( '0110feQ' , 'feQ' )
IIIIiii1IIii = 'aHR0cDovL2JpdC5seS8yS0cz' . decode ( 'base64' ) + IiIIi1
II1i11I = '0110MHY' . replace ( '0110MHY' , 'MHY' )
ii1I1IIii11 = 'aHR0cDovL2JpdC5seS8ySXVo' . decode ( 'base64' ) + II1i11I
O0o0oO = '0110xdb' . replace ( '0110xdb' , 'xdb' )
IIIIiIiIi1 = 'aHR0cDovL2JpdC5seS8yWEJu' . decode ( 'base64' ) + O0o0oO
I11iiiiI1i = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( 'base64' )
iI1i11 = 'aHR0cHM6Ly9uZXRhaS5ldS92aXNpdGFzL2luZGV4LnBocA==' . decode ( 'base64' )
IiIIIi1iIi = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
OoOOoooOO0O = '0110lxu' . replace ( '0110lxu' , 'lxu' )
ooo00Ooo = 'aHR0cDovL2JpdC5seS8yV1Bj' . decode ( 'base64' ) + OoOOoooOO0O
Oo0o0O00 = '0110pzp' . replace ( '0110pzp' , 'pzp' )
ii1I1i11 = 'aHR0cDovL2JpdC5seS8yVHpB' . decode ( 'base64' ) + Oo0o0O00
OOo0O0oo0OO0O = '01105yt' . replace ( '01105yt' , '5yt' )
OO0 = 'aHR0cDovL2JpdC5seS8yTVpp' . decode ( 'base64' ) + OOo0O0oo0OO0O
if 72 - 72: OoooooooOO
if 72 - 72: OOooOOo % i11iIiiIii . ii11ii1ii / II111iiii
iIIiIiI = '1001DTs' . replace ( '1001DTs' , 'DTs' )
iIi11 = 'aHR0cDovL2JpdC5seS8ySzhP' . decode ( 'base64' ) + iIIiIiI
OOoo = '1001Hky' . replace ( '1001Hky' , 'Hky' )
iIIiiiI = 'aHR0cDovL2JpdC5seS8yTGVL' . decode ( 'base64' ) + OOoo
oo0 = '1001VFU' . replace ( '1001VFU' , 'VFU' )
IiI111ii1ii = 'aHR0cDovL2JpdC5seS8zMERx' . decode ( 'base64' ) + oo0
O0OOo = '3545OMZ' . replace ( '3545OMZ' , 'OMZ' )
IiIII1 = 'aHR0cDovL2JpdC5seS8yazhk' . decode ( 'base64' ) + O0OOo
O0Oo000 = '4224tZO' . replace ( '4224tZO' , 'tZO' )
iiI11i1II = 'aHR0cDovL2JpdC5seS8zNXd4' . decode ( 'base64' ) + O0Oo000
if 51 - 51: o0000oOoOoO0o % ii11ii1ii % o0000oOoOoO0o * O0 - IIII % ii11ii1ii
try :
 if 65 - 65: iI
 iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
 o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
 OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
 if 68 - 68: iI % i11iIiiIii + II111iiii
 OOOO0OOO = i1i1ii ( ii1 )
 iII1ii1 = re . compile ( oOO00O ) . findall ( OOOO0OOO )
 for I1i1iiiI1 , iIIi , oO0o00oo0 in iII1ii1 :
  if re . search ( OOO00O , oO0o00oo0 ) :
   if 19 - 19: II111iiii + i1I111II1I
   if iiII1i1 == iIIi and o00oOO0o == I1i1iiiI1 and OOO00O == oO0o00oo0 :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR orange]Bienvenido![/COLOR][COLOR white] " + iIIi + "[/COLOR] ,3000)" )
    if 53 - 53: oO0o0ooO0 - OOooOOo - oO0o0ooO0 * O0ooOooooO
    login == 'true'
    if 71 - 71: O0 - iIii1I11I1II1
   else :
    if 12 - 12: IIII / o0000oOoOoO0o
    login == 'false'
    if 42 - 42: ii11ii1ii
    if 19 - 19: oO0o0ooO0 % o00O0oo * iIii1I11I1II1 + OOooOOo
except :
 pass
 if 46 - 46: ii11ii1ii
 if 1 - 1: O0ooOooooO
def O0O0Ooo ( ) :
 if 77 - 77: o0000oOoOoO0o / OoooooooOO
 if 46 - 46: o0000oOoOoO0o % iIii1I11I1II1 . O0ooOooooO % O0ooOooooO + i11iIiiIii
 try :
  Oo00o0OO0O00o = i1i1ii ( oOOo0O00o )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
  for O0Oooo in iII1ii1 :
   try :
    if 21 - 21: ii11ii1ii
    OOO = O0Oooo
    if 29 - 29: O0oO / II111iiii / iI * IIII
    I111i1i1111 = xbmc . Keyboard ( '' , 'Busqueda por titulo' )
    I111i1i1111 . doModal ( )
    if ( I111i1i1111 . isConfirmed ( ) ) :
     IIII1 = xbmcgui . DialogProgress ( )
     IIII1 . create ( 'Realstream:' , 'Buscando ...' )
     I1I1i = range ( 0 , 76 )
     for I1IIIiIiIi in I1I1i :
      I1IIIiIiIi = I1IIIiIiIi + 1
      if 27 - 27: o00O0oo + OoOO0ooOOoo0O - IIII + O0 . o0oO0
     iIi1i1iIi1iI = urllib . quote_plus ( I111i1i1111 . getText ( ) ) . replace ( '+' , ' ' )
     iiIi1iI1iIii = i1i1ii ( OOO )
     iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( iiIi1iI1iIii )
     for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
      if 98 - 98: iIii1I11I1II1 * o00O0oo * IIII + iI % i11iIiiIii % O0
      IIII1 . update ( I1IIIiIiIi , '[COLOR orange]Realstream: Buscando ...[/COLOR]' , ' [COLOR yellow] %s [/COLOR]' % o0o0oOoOO0O )
      xbmc . sleep ( 1 )
      if IIII1 . iscanceled ( ) : break ;
      if re . search ( iIi1i1iIi1iI , i1OO0oOOoo ( o0o0oOoOO0O . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       if 52 - 52: o0000oOoOoO0o % ii11ii1ii
       IIII1 . update ( 80 , ' [COLOR orange]Busqueda finalizada[/COLOR] ' )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR gold]Generando listado ...  [/COLOR][COLOR orange] Por favor espere ![/COLOR] ,1000)" )
       IIII1 . update ( 100 , '[COLOR orange]Realstream: [/COLOR]' , '[COLOR gold] Busqueda finalizada ...[/COLOR]' )
       IIII1 . close ( )
       Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
       if 31 - 31: iIii1I11I1II1 % O0oO % iI . o0oO0 - O0oO
       if 17 - 17: o0oO0
     Ii1ii1IiIII ( '[COLOR %s]Buscar Pelicula[/COLOR]' % iIIIi1 , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Resultados para: [COLOR orange]" + iIi1i1iIi1iI + "[/COLOR] ,2000)" )
     if 57 - 57: iIii1I11I1II1 / O0oO - i1IIi
   except : Ii1ii1IiIII ( '[COLOR %s]Buscar Pelicula[/COLOR]' % iIIIi1 , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
   if 51 - 51: i1I111II1I
 except :
  pass
  if 25 - 25: OoooooooOO + i1I111II1I * o00O0oo
def OoO0ooO ( ) :
 if 51 - 51: O0ooOooooO / iI * OoOO0ooOOoo0O . O0ooOooooO / o00O0oo / i11iIiiIii
 oOOo0 = IiII1IiiIiI1 . getSetting ( 'aviso' )
 if 21 - 21: oO0o0ooO0 / o00O0oo + o0oO0 + OoooooooOO
 if oOOo0 == 'true' :
  if 91 - 91: i11iIiiIii / i1IIi + O0ooOooooO + iI * i11iIiiIii
  try :
   Oo00o0OO0O00o = i1i1ii ( iIi1 )
   iII1ii1 = re . compile ( Iiii1i1 ) . findall ( Oo00o0OO0O00o )
   for OoOoOo00o0 , OO0ooo0oOO in iII1ii1 :
    try :
     if 97 - 97: OOooOOo / O0ooOooooO
     if 71 - 71: II111iiii / i1IIi . o00O0oo % OoooooooOO . OoOO0ooOOoo0O
     Iiiiii111i1ii = OoOoOo00o0
     i1i1iII1 = OO0ooo0oOO
     if 25 - 25: iIii1I11I1II1 % O0ooOooooO . iI
     if 14 - 14: oO0o0ooO0 + o00O0oo - O0ooOooooO / O0 . Oooo0Ooo000
     from datetime import datetime
     if 45 - 45: Oooo0Ooo000
     oOIIi1iiii1iI = datetime . now ( )
     iIiiii = oOIIi1iiii1iI . strftime ( '%d/%m/%Y' )
     if 89 - 89: O0ooOooooO - iI % ii11ii1ii % o0000oOoOoO0o
     IIiii11i = i1i1ii ( iI1i11 )
     iII1ii1 = re . compile ( ii1iII1II ) . findall ( IIiii11i )
     for O00oOo00o0o in iII1ii1 :
      if 85 - 85: O0ooOooooO + OoooooooOO * O0ooOooooO - Oooo0Ooo000 % i11iIiiIii
      OOo00OoO = "[B]" + Iiiiii111i1ii + "[/B]"
      iIi1i11iiI1111 = "" + i1i1iII1 + ""
      oOoooo000Oo00 = "[COLOR white]Hoy: " + iIiiii + ", Es usted el visitante numero: [B][COLOR gold]" + O00oOo00o0o + "[/B][/COLOR]"
      if 93 - 93: o00O0oo / OOooOOo / iIii1I11I1II1 % Oooo0Ooo000 % Oooo0Ooo000
      xbmcgui . Dialog ( ) . ok ( "Real Stream" , OOo00OoO , iIi1i11iiI1111 , oOoooo000Oo00 )
    except :
     pass
     if 40 - 40: i11iIiiIii * Oooo0Ooo000 - i1IIi * Oooo0Ooo000 - O0oO . i1IIi
  except :
   pass
   if 99 - 99: O0 * O0oO
  try :
   iiIi1iI1iIii = i1i1ii ( I11iiiiI1i )
   iII1ii1 = re . compile ( IiII ) . findall ( iiIi1iI1iIii )
   for Ooooooo in iII1ii1 :
    if 39 - 39: i1I111II1I * ii11ii1ii + iIii1I11I1II1 - i1I111II1I + IIII
    import xbmc
    import xbmcaddon
    if 69 - 69: O0
    __addon__ = xbmcaddon . Addon ( )
    __addonname__ = __addon__ . getAddonInfo ( 'name' )
    __icon__ = __addon__ . getAddonInfo ( 'icon' )
    if 85 - 85: iI / O0
    iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
    iI1iIIIi1i = Ooooooo
    if 89 - 89: iIii1I11I1II1
    OOo00OoO = "[COLOR orange]Version instalada: [COLOR gold][B] " + iIiiiI1IiI1I1 + "[/B] [/COLOR][/COLOR][COLOR white] Disponible: [B]" + Ooooooo + " [/B][/COLOR]"
    i11iiiiI1i = 4000
    xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , OOo00OoO , i11iiiiI1i , __icon__ ) )
    if 37 - 37: IIII / OoooooooOO - i11iIiiIii
    if iIiiiI1IiI1I1 < Ooooooo :
     if 18 - 18: O0ooOooooO . OOooOOo
     xbmcgui . Dialog ( ) . ok ( "Real Stream" , "[COLOR white] Existe una nueva version de [/COLOR][COLOR fuchsia]Realstream[/COLOR]" , "[COLOR orange]Actualimete tiene instalada la version[/COLOR] [COLOR white][B] %s [/B][/COLOR]" % iIiiiI1IiI1I1 , " [COLOR white]Ya esta disponible la[/COLOR] [COLOR gold][B] %s [/B][/COLOR]" % Ooooooo )
     if 40 - 40: O0 - OoooooooOO - i1I111II1I
     if 37 - 37: OoOO0ooOOoo0O / II111iiii / O0
  except :
   pass
   if 76 - 76: OOooOOo . iI - o00O0oo - O0ooOooooO * OoOO
   if 54 - 54: i1I111II1I + O0 + O0oO * Oooo0Ooo000 - IIII % oO0o0ooO0
   if 13 - 13: iI / O0ooOooooO * OoOO . OoOO * iI
   if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 63 - 63: Oooo0Ooo000 / O0 * ii11ii1ii + II111iiii / i1I111II1I + o0oO0
    if 63 - 63: OoOO + o00O0oo . Oooo0Ooo000 % Oooo0Ooo000
    if 57 - 57: II111iiii
def i1OO0oOOoo ( s ) :
 if 54 - 54: ii11ii1ii + oO0o0ooO0 + i11iIiiIii
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 28 - 28: oO0o0ooO0
def ooo000o0ooO0 ( file ) :
 if 10 - 10: iI . O0ooOooooO + OoOO / OoooooooOO - O0ooOooooO / O0oO
 try :
  OOooOo00oo0 = open ( file , 'r' )
  Oo00o0OO0O00o = OOooOo00oo0 . read ( )
  OOooOo00oo0 . close ( )
  return Oo00o0OO0O00o
 except :
  pass
  if 84 - 84: Oooo0Ooo000 + O0oO
def i1i1ii ( url ) :
 if 28 - 28: oO0o0ooO0 - i11iIiiIii . o00O0oo + i1I111II1I / o00O0oo
 try :
  i11iIiI11I1i = urllib2 . Request ( url )
  i11iIiI11I1i . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  i1i1IIii1i1 = urllib2 . urlopen ( i11iIiI11I1i )
  oOoO00 = i1i1IIii1i1 . read ( )
  i1i1IIii1i1 . close ( )
  return oOoO00
 except urllib2 . URLError , iI1IIIii :
  print 'We failed to open "%s".' % url
  if hasattr ( iI1IIIii , 'code' ) :
   print 'We failed with error code - %s.' % iI1IIIii . code
  if hasattr ( iI1IIIii , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , iI1IIIii . reason
   if 7 - 7: i1I111II1I - O0oO / II111iiii * o0oO0 . O0ooOooooO * O0ooOooooO
def O0O0oOOo0O ( url ) :
 i11iIiI11I1i = urllib2 . Request ( url )
 i11iIiI11I1i . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 i11iIiI11I1i . add_header ( 'Referer' , '%s' % url )
 i11iIiI11I1i . add_header ( 'Connection' , 'keep-alive' )
 i1i1IIii1i1 = urllib2 . urlopen ( i11iIiI11I1i )
 oOoO00 = i1i1IIii1i1 . read ( )
 i1i1IIii1i1 . close ( )
 return oOoO00
 if 19 - 19: o0000oOoOoO0o / Oooo0Ooo000 % o0000oOoOoO0o % O0ooOooooO * i1I111II1I
 if 19 - 19: iIii1I11I1II1
 if 26 - 26: OoooooooOO % OOooOOo % ii11ii1ii . OOooOOo % o0oO0
def i1I1I ( ) :
 if 95 - 95: i1I111II1I
 iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 if 51 - 51: II111iiii + i1I111II1I . i1IIi . o00O0oo + OoOO0ooOOoo0O * OOooOOo
 if i1Oo00 == 'true' :
  if 72 - 72: oO0o0ooO0 + oO0o0ooO0 / II111iiii . OoooooooOO % o0oO0
  Ii1ii1IiIII ( '[COLOR %s]Buscar Serie[/COLOR]' % iIIIi1 , 'search' , 145 , I1IIIii , oo00 )
  Ii1ii1IiIII ( '[COLOR %s]Series[/COLOR] ' % iIIIi1 , 'movieDB' , 117 , iIi11Ii1 , oo00 )
  if 49 - 49: oO0o0ooO0 . OoOO - ii11ii1ii * OoooooooOO . ii11ii1ii
  try :
   if 2 - 2: OoooooooOO % IIII
   iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
   o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
   OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
   if 63 - 63: OOooOOo % iIii1I11I1II1
   OOOO0OOO = i1i1ii ( ii1 )
   iII1ii1 = re . compile ( oOO00O ) . findall ( OOOO0OOO )
   for I1i1iiiI1 , iIIi , oO0o00oo0 in iII1ii1 :
    if re . search ( OOO00O , oO0o00oo0 ) :
     if 39 - 39: O0ooOooooO / II111iiii / o00O0oo % OOooOOo
     if iiII1i1 == iIIi and o00oOO0o == I1i1iiiI1 and OOO00O == oO0o00oo0 :
      if 89 - 89: Oooo0Ooo000 + OoooooooOO + Oooo0Ooo000 * i1IIi + iIii1I11I1II1 % O0oO
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR orange]Bienvenido![/COLOR][COLOR white] " + iIIi + "[/COLOR] ,3000)" )
      if 59 - 59: IIII + i11iIiiIii
      Ii1ii1IiIII ( '[COLOR %s]Buscar Pelicula[/COLOR]' % iIIIi1 , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
      Ii1ii1IiIII ( '[COLOR %s]Peliculas[/COLOR] ' % iIIIi1 , 'movieDB' , 116 , I1I , oo00 )
      if 88 - 88: i11iIiiIii - iI
  except :
   pass
   if 67 - 67: IIII . ii11ii1ii + OoOO0ooOOoo0O - OoooooooOO
 if oo00O00oO == 'true' :
  Ii1ii1IiIII ( '[COLOR %s]Ajustes[/COLOR]' % iIIIi1 , 'Settings' , 119 , Ii11iII1 , oo00 )
  if 70 - 70: IIII / II111iiii - iIii1I11I1II1 - O0ooOooooO
  if 11 - 11: iIii1I11I1II1 . OoooooooOO . II111iiii / i1IIi - O0oO
  if OOoOO0oo0ooO == 'true' :
   try :
    if 30 - 30: OoOO0ooOOoo0O
    iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
    o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
    OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
    if 21 - 21: i11iIiiIii / Oooo0Ooo000 % IIII * O0 . O0oO - iIii1I11I1II1
    OOOO0OOO = i1i1ii ( ii1 )
    iII1ii1 = re . compile ( oOO00O ) . findall ( OOOO0OOO )
    for I1i1iiiI1 , iIIi , oO0o00oo0 in iII1ii1 :
     if re . search ( OOO00O , oO0o00oo0 ) :
      if 26 - 26: II111iiii * OoOO0ooOOoo0O
      if iiII1i1 == iIIi and o00oOO0o == I1i1iiiI1 and OOO00O == oO0o00oo0 :
       if 10 - 10: II111iiii . O0ooOooooO
       I1i ( )
   except :
    pass
    if 86 - 86: ii11ii1ii / oO0o0ooO0 + O0 * O0ooOooooO
  if iIiIIIi == 'true' :
   iiI11I1i1i1iI ( )
   OoOOo000o0 ( )
   if 12 - 12: II111iiii . O0oO / IIII
  if iiI111I1iIiI == 'false' :
   if 77 - 77: iI - OOooOOo % O0oO - O0
   OOo00OoO = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   iIi1i11iiI1111 = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Script.ResolveURL para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   oOoooo000Oo00 = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 67 - 67: IIII + ii11ii1ii
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , OOo00OoO , iIi1i11iiI1111 , oOoooo000Oo00 )
   if 84 - 84: O0 * OoooooooOO - i1I111II1I * i1I111II1I
def i1ii ( ) :
 Ii1ii1IiIII ( '[COLOR orange]Buscador por id[/COLOR]' , IIIII11I1IiI , 127 , oOOoo00O0O , oo00 )
 if 65 - 65: OoOO0ooOOoo0O / OoOO % i1I111II1I
def iIiIIii ( ) :
 iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 Ii1ii1IiIII ( '[COLOR %s]The movie DB[/COLOR]' % iIIIi1 , 'movieDB' , 99 , oOOoo00O0O , oo00 )
 if 61 - 61: o0000oOoOoO0o / IIII / ii11ii1ii * O0
 Ii1ii1IiIII ( '[COLOR %s]Video tutoriales[/COLOR]' % iIIIi1 , IIIII11I1IiI , 125 , O0OOO0OOoO0O , oo00 )
 if 23 - 23: oO0o0ooO0 - IIII + O0oO
 if 12 - 12: OOooOOo / iI % o0000oOoOoO0o / i11iIiiIii % OoooooooOO
 if 15 - 15: iIii1I11I1II1 % OoooooooOO - ii11ii1ii * o0oO0 + O0oO
def i1I1II1iIIi11 ( ) :
 if 49 - 49: OoooooooOO * O0oO - ii11ii1ii . oO0o0ooO0
 i1I1I ( )
 iIiIIii ( )
 if 89 - 89: iI + o0oO0 * iI / iI
def i11i11 ( ) :
 if 72 - 72: i1IIi - II111iiii - IIII + IIII * o0000oOoOoO0o * IIII
 i1I1II1iIIi11 ( )
 if 33 - 33: ii11ii1ii
def II11i11Iii ( ) :
 if xbmc . getCondVisibility ( 'System.HasAddon(script.favourites)' ) :
  try :
   xbmc . executebuiltin ( "RunScript(script.favourites)" )
  except :
   pass
def oooo00o0o0o ( ) :
 IiII1IiiIiI1 . openSettings ( )
 if 87 - 87: O0oO * i1IIi - o0oO0 % IIII / Oooo0Ooo000
 if 39 - 39: OOooOOo * i11iIiiIii - oO0o0ooO0 / i1I111II1I % Oooo0Ooo000 % O0oO
def OO00oo0o ( ) :
 urlresolver . display_settings ( )
 if 18 - 18: OoOO + iIii1I11I1II1 - II111iiii - OOooOOo
def iiI11I1i1i1iI ( ) :
 Ii1ii1IiIII ( '[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % iIIIi1 , 'resolve' , 120 , O0o0 , oo00 )
 if 71 - 71: OoooooooOO
def iIIIII1iiiiII ( ) :
 if 54 - 54: i1IIi
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 22 - 22: i1IIi + o0oO0
def OoOOo000o0 ( ) :
 Ii1ii1IiIII ( '[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % iIIIi1 , 'resolve' , 140 , O0o0 , oo00 )
 if 54 - 54: iI % IIII . Oooo0Ooo000 + oO0o0ooO0 - IIII * OOooOOo
def I1i ( ) :
 if 92 - 92: o0000oOoOoO0o + Oooo0Ooo000 / ii11ii1ii % OoOO % i1I111II1I . OoooooooOO
 try :
  if 52 - 52: iI / i11iIiiIii - IIII . i1I111II1I % iIii1I11I1II1 + o0000oOoOoO0o
  iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
  OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 71 - 71: oO0o0ooO0 % O0oO * OoOO0ooOOoo0O . O0 / o0oO0 . o00O0oo
  OOOO0OOO = i1i1ii ( ii1 )
  iII1ii1 = re . compile ( oOO00O ) . findall ( OOOO0OOO )
  for I1i1iiiI1 , iIIi , oO0o00oo0 in iII1ii1 :
   if re . search ( OOO00O , oO0o00oo0 ) :
    if 58 - 58: ii11ii1ii / oO0o0ooO0
    if iiII1i1 == iIIi and o00oOO0o == I1i1iiiI1 and OOO00O == oO0o00oo0 :
     if 44 - 44: IIII
     Ii1ii1IiIII ( '[COLOR %s]Buscador[/COLOR]' % iIIIi1 , 'search' , 111 , o0oOoO00o , oo00 )
     Ii1ii1IiIII ( '[COLOR %s]Estrenos[/COLOR]' % iIIIi1 , IIIII11I1IiI , 3 , i11 , oo00 )
     Ii1ii1IiIII ( '[COLOR %s]Todas[/COLOR]' % iIIIi1 , IIIII11I1IiI , 26 , I11 , oo00 )
     Ii1ii1IiIII ( '[COLOR %s]4K[/COLOR]' % iIIIi1 , IIIII11I1IiI , 141 , O0o0Oo , oo00 )
     Ii1ii1IiIII ( '[COLOR %s]Novedades[/COLOR]' % iIIIi1 , IIIII11I1IiI , 2 , i1111 , oo00 )
     Ii1ii1IiIII ( '[COLOR %s]Accion[/COLOR]' % iIIIi1 , IIIII11I1IiI , 5 , Oo0o0000o0o0 , oo00 )
     Ii1ii1IiIII ( '[COLOR %s]Animacion[/COLOR]' % iIIIi1 , IIIII11I1IiI , 6 , oOo0oooo00o , oo00 )
     Ii1ii1IiIII ( '[COLOR %s]Artes Marciales[/COLOR]' % iIIIi1 , IIIII11I1IiI , 29 , o0 , oo00 )
     Ii1ii1IiIII ( '[COLOR %s]Aventuras[/COLOR]' % iIIIi1 , IIIII11I1IiI , 7 , oO0o0o0ooO0oO , oo00 )
     Ii1ii1IiIII ( '[COLOR %s]Belico[/COLOR]' % iIIIi1 , IIIII11I1IiI , 8 , oo0o0O00 , oo00 )
     Ii1ii1IiIII ( '[COLOR %s]Ciencia Ficcion[/COLOR]' % iIIIi1 , IIIII11I1IiI , 9 , oO , oo00 )
     Ii1ii1IiIII ( '[COLOR %s]Cine Clasico[/COLOR]' % iIIIi1 , IIIII11I1IiI , 30 , i1iiIIiiI111 , oo00 )
     Ii1ii1IiIII ( '[COLOR %s]Comedia[/COLOR]' % iIIIi1 , IIIII11I1IiI , 10 , oooOOOOO , oo00 )
     Ii1ii1IiIII ( '[COLOR %s]Crimen[/COLOR]' % iIIIi1 , IIIII11I1IiI , 11 , i1iiIII111ii , oo00 )
     Ii1ii1IiIII ( '[COLOR %s]Drama[/COLOR]' % iIIIi1 , IIIII11I1IiI , 12 , i1iIIi1 , oo00 )
     Ii1ii1IiIII ( '[COLOR %s]Familiar[/COLOR]' % iIIIi1 , IIIII11I1IiI , 13 , ii11iIi1I , oo00 )
     Ii1ii1IiIII ( '[COLOR %s]Fantasia[/COLOR]' % iIIIi1 , IIIII11I1IiI , 14 , iI111I11I1I1 , oo00 )
     Ii1ii1IiIII ( '[COLOR %s]Historia[/COLOR]' % iIIIi1 , IIIII11I1IiI , 15 , OOooO0OOoo , oo00 )
     Ii1ii1IiIII ( '[COLOR %s]Misterio[/COLOR]' % iIIIi1 , IIIII11I1IiI , 16 , oOOoO0 , oo00 )
     Ii1ii1IiIII ( '[COLOR %s]Musical[/COLOR]' % iIIIi1 , IIIII11I1IiI , 17 , O0OoO000O0OO , oo00 )
     Ii1ii1IiIII ( '[COLOR %s]Romance[/COLOR]' % iIIIi1 , IIIII11I1IiI , 18 , iiI1IiI , oo00 )
     Ii1ii1IiIII ( '[COLOR %s]Thriller[/COLOR]' % iIIIi1 , IIIII11I1IiI , 19 , II11iiii1Ii , oo00 )
     Ii1ii1IiIII ( '[COLOR %s]Suspense[/COLOR]' % iIIIi1 , IIIII11I1IiI , 20 , ooOoOoo0O , oo00 )
     Ii1ii1IiIII ( '[COLOR %s]Terror[/COLOR]' % iIIIi1 , IIIII11I1IiI , 21 , OooO0 , oo00 )
     Ii1ii1IiIII ( '[COLOR %s]Western[/COLOR]' % iIIIi1 , IIIII11I1IiI , 22 , OO0o , oo00 )
     Ii1ii1IiIII ( '[COLOR %s]Spain[/COLOR]' % iIIIi1 , IIIII11I1IiI , 23 , II , oo00 )
     Ii1ii1IiIII ( '[COLOR %s]Super heroes[/COLOR]' % iIIIi1 , IIIII11I1IiI , 24 , iIii1 , oo00 )
     Ii1ii1IiIII ( '[COLOR %s]Sagas[/COLOR]' % iIIIi1 , IIIII11I1IiI , 25 , Ooo , oo00 )
     if 54 - 54: o0oO0 - O0oO - Oooo0Ooo000 . iIii1I11I1II1
    else :
     if 79 - 79: o0oO0 . OoOO
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR orange]Esta seccion ya no esta disponible! Lo sentimos.[/COLOR][COLOR white] " + iIIi + "[/COLOR] ,3000)" )
     if 40 - 40: o0000oOoOoO0o + ii11ii1ii . o0000oOoOoO0o % iI
     return False
     if 15 - 15: o0oO0 * ii11ii1ii % o00O0oo * iIii1I11I1II1 - i11iIiiIii
 except :
  pass
  if 60 - 60: OOooOOo * Oooo0Ooo000 % OoOO + oO0o0ooO0
def o0oo ( ) :
 if 80 - 80: Oooo0Ooo000 * OoOO0ooOOoo0O * II111iiii - O0 . OoOO0ooOOoo0O % OOooOOo
 Ii1ii1IiIII ( '[COLOR %s]Buscar Serie[/COLOR]' % iIIIi1 , 'search' , 145 , O0OO00o0OO , oo00 )
 if 13 - 13: oO0o0ooO0 . OOooOOo * oO0o0ooO0 + OOooOOo
 OoOooo ( )
 if 74 - 74: iIii1I11I1II1 * i1I111II1I % OoOO0ooOOoo0O
 Ii1ii1IiIII ( '[COLOR %s]En emision[/COLOR]' % iIIIi1 , IIIII11I1IiI , 150 , I11II1i , oo00 )
 Ii1ii1IiIII ( '[COLOR %s]Mejor valoradas[/COLOR]' % iIIIi1 , IIIII11I1IiI , 151 , IIIII , oo00 )
 Ii1ii1IiIII ( '[COLOR %s]Series Retro[/COLOR]' % iIIIi1 , IIIII11I1IiI , 152 , ooooooO0oo , oo00 )
 Ii1ii1IiIII ( '[COLOR %s]Todas[/COLOR]' % iIIIi1 , IIIII11I1IiI , 142 , I11i1 , oo00 )
 if 36 - 36: OoooooooOO - oO0o0ooO0
def OoOooo ( ) :
 if 85 - 85: o0000oOoOoO0o . i1I111II1I / O0 . o0000oOoOoO0o . o00O0oo . OoOO
 OO0O0Oo0 = 'aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtLw==' . decode ( 'base64' )
 oOOOO00 = 'Y29uZGljaW9uLnR4dA==' . decode ( 'base64' )
 oOoO00 = OO0O0Oo0 + oOOOO00
 oOo0O00O = '[\'"](.*?)[\'"]'
 o0oo = i1i1ii ( oOoO00 )
 iII1ii1 = re . compile ( oOo0O00O ) . findall ( o0oo )
 for iiIii1I in iII1ii1 :
  try :
   if 47 - 47: iI . O0oO / o0000oOoOoO0o
   if iiIii1I == 'si' :
    if 83 - 83: o0000oOoOoO0o / IIII / IIII + o0000oOoOoO0o * Oooo0Ooo000 + o0000oOoOoO0o
    Ii1ii1IiIII ( '[COLOR %s]Hay Nuevos Episodios[/COLOR]' % iIIIi1 , IIIII11I1IiI , 155 , OOOO , oo00 )
    if 36 - 36: OoOO0ooOOoo0O + o0000oOoOoO0o - OoooooooOO . oO0o0ooO0 . OoooooooOO / ii11ii1ii
   elif iiIii1I == 'no' :
    if 72 - 72: i1IIi
    Ii1ii1IiIII ( '[COLOR %s]No hay Nuevos Episodios[/COLOR]' % iIIIi1 , IIIII11I1IiI , 155 , oOoOooOo0o0 , oo00 )
    if 82 - 82: OoOO0ooOOoo0O + OoooooooOO / i11iIiiIii * o00O0oo . OoooooooOO
   return
   if 63 - 63: o00O0oo
  except :
   pass
   if 6 - 6: iI / o00O0oo
def oOooO00o0O ( ) :
 if 80 - 80: IIII / O0oO / OoOO0ooOOoo0O + i1IIi - ii11ii1ii
 if 11 - 11: o0000oOoOoO0o * OoOO
 try :
  if 15 - 15: OoOO0ooOOoo0O
  oOoOoO000OO = i1i1ii ( iIi11 )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( oOoOoO000OO )
  for O0Oooo in iII1ii1 :
   if 38 - 38: o0000oOoOoO0o
   try :
    if 23 - 23: ii11ii1ii % O0oO - IIII % iIii1I11I1II1 . OoOO0ooOOoo0O
    I1Ii1 = O0Oooo
    I111i1i1111 = xbmc . Keyboard ( '' , 'Buscar' )
    I111i1i1111 . doModal ( )
    if ( I111i1i1111 . isConfirmed ( ) ) :
     IIII1 = xbmcgui . DialogProgress ( )
     IIII1 . create ( 'Realstream:' , 'Buscando ...' )
     I1I1i = range ( 0 , 69 )
     for I1IIIiIiIi in I1I1i :
      I1IIIiIiIi = I1IIIiIiIi + 1
     iIi1i1iIi1iI = urllib . quote_plus ( I111i1i1111 . getText ( ) ) . replace ( '+' , ' ' )
     iiIi1iI1iIii = i1i1ii ( I1Ii1 )
     iII1ii1 = re . compile ( OoO ) . findall ( iiIi1iI1iIii )
     for OoOooOo0O , o0o0oOoOO0O , oo00 , i1ii1II1ii , Ooo00OoOOO in iII1ii1 :
      IIII1 . update ( I1IIIiIiIi , '[COLOR orange]Realstream: Buscando ...[/COLOR]' , '[COLOR gold] %s [/COLOR]' % o0o0oOoOO0O )
      xbmc . sleep ( 5 )
      if IIII1 . iscanceled ( ) : break ;
      if re . search ( iIi1i1iIi1iI , i1OO0oOOoo ( o0o0oOoOO0O . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       if 37 - 37: o0oO0 % OoOO
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Generando listado ...  [COLOR orange] Por favor espere ![/COLOR] , 4000)" )
       oOooO0 ( o0o0oOoOO0O , i1ii1II1ii , 143 , OoOooOo0O , oo00 , Ooo00OoOOO )
       IIII1 . update ( 100 , '[COLOR orange]Realstream: [/COLOR]' , '[COLOR gold] Busqueda finalizada ...[/COLOR]' )
       xbmc . sleep ( 2000 )
       IIII1 . close ( )
     Ii1ii1IiIII ( '[COLOR %s]Buscar Serie[/COLOR]' % iIIIi1 , 'search' , 145 , O0OO00o0OO , oo00 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Sin Resultados para: [COLOR orange]" + iIi1i1iIi1iI + "[/COLOR] , 2000)" )
     if 74 - 74: O0oO - IIII + i1IIi . OOooOOo + IIII - O0oO
     if 17 - 17: O0 . Oooo0Ooo000 . O0 + O0 / ii11ii1ii . iI
   except : Ii1ii1IiIII ( '[COLOR %s]Buscar Serie[/COLOR]' % iIIIi1 , 'search' , 145 , O0OO00o0OO , oo00 )
   if 62 - 62: o00O0oo % O0ooOooooO * OoOO - i1IIi
 except :
  pass
  if 66 - 66: i11iIiiIii / o0000oOoOoO0o - OoooooooOO / i1IIi . i11iIiiIii
def IIIII1iii11 ( ) :
 if 35 - 35: oO0o0ooO0 / Oooo0Ooo000 / II111iiii - iIii1I11I1II1 + II111iiii . Oooo0Ooo000
 try :
  if 81 - 81: O0ooOooooO * IIII - o00O0oo * o0oO0 % OoOO0ooOOoo0O * OoOO0ooOOoo0O
  oOoOoO000OO = i1i1ii ( iiI11i1II )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( oOoOoO000OO )
  for O0Oooo in iII1ii1 :
   if 59 - 59: iIii1I11I1II1
   try :
    if 7 - 7: IIII * OOooOOo / o0000oOoOoO0o * i11iIiiIii
    I1Ii1 = O0Oooo
    if 84 - 84: IIII . O0ooOooooO
   except :
    pass
    if 8 - 8: ii11ii1ii + II111iiii * IIII * OoOO0ooOOoo0O * O0oO / i1I111II1I
  iiIi1iI1iIii = i1i1ii ( I1Ii1 )
  iII1ii1 = re . compile ( OoO ) . findall ( iiIi1iI1iIii )
  for OoOooOo0O , o0o0oOoOO0O , oo00 , i1ii1II1ii , Ooo00OoOOO in iII1ii1 :
   try :
    if 21 - 21: oO0o0ooO0 / OoooooooOO
    oOooO0 ( o0o0oOoOO0O , i1ii1II1ii , 143 , OoOooOo0O , oo00 , Ooo00OoOOO )
    if 11 - 11: IIII % o0oO0 - i11iIiiIii - oO0o0ooO0 + iI + i1I111II1I
   except :
    pass
 except :
  pass
  if 87 - 87: Oooo0Ooo000 * i1IIi / o00O0oo
def IIII1i1 ( ) :
 if 70 - 70: i11iIiiIii % o00O0oo / OOooOOo
 try :
  if 62 - 62: i1IIi - OoOO0ooOOoo0O
  oOoOoO000OO = i1i1ii ( IiIII1 )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( oOoOoO000OO )
  for O0Oooo in iII1ii1 :
   if 62 - 62: i1IIi + ii11ii1ii % i1I111II1I
   try :
    if 28 - 28: o00O0oo . i1IIi
    I1Ii1 = O0Oooo
    if 10 - 10: OoOO / ii11ii1ii
   except :
    pass
    if 15 - 15: O0ooOooooO . OoOO0ooOOoo0O / O0ooOooooO * O0oO - OOooOOo % o00O0oo
  iiIi1iI1iIii = i1i1ii ( I1Ii1 )
  iII1ii1 = re . compile ( OoO ) . findall ( iiIi1iI1iIii )
  for OoOooOo0O , o0o0oOoOO0O , oo00 , i1ii1II1ii , Ooo00OoOOO in iII1ii1 :
   try :
    if 57 - 57: O0 % OoOO0ooOOoo0O % oO0o0ooO0
    oOooO0 ( o0o0oOoOO0O , i1ii1II1ii , 143 , OoOooOo0O , oo00 , Ooo00OoOOO )
    if 45 - 45: o00O0oo + II111iiii * i11iIiiIii
   except :
    pass
 except :
  pass
  if 13 - 13: OoooooooOO * oO0o0ooO0 - o0oO0 / IIII + O0oO + i1I111II1I
  if 39 - 39: iIii1I11I1II1 - OoooooooOO
def oO0oooooo ( ) :
 if 65 - 65: i1I111II1I + ii11ii1ii
 try :
  if 59 - 59: OoooooooOO + O0oO . Oooo0Ooo000 - O0 % iIii1I11I1II1 / O0
  oOoOoO000OO = i1i1ii ( IiI111ii1ii )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( oOoOoO000OO )
  for O0Oooo in iII1ii1 :
   if 88 - 88: ii11ii1ii . O0 % OoooooooOO / IIII
   try :
    if 89 - 89: II111iiii / oO0o0ooO0
    I1Ii1 = O0Oooo
    if 14 - 14: IIII . OOooOOo * iI + II111iiii - iI + IIII
   except :
    pass
    if 18 - 18: oO0o0ooO0 - o0000oOoOoO0o - OOooOOo - OOooOOo
  iiIi1iI1iIii = i1i1ii ( I1Ii1 )
  iII1ii1 = re . compile ( OoO ) . findall ( iiIi1iI1iIii )
  for OoOooOo0O , o0o0oOoOO0O , oo00 , i1ii1II1ii , Ooo00OoOOO in iII1ii1 :
   try :
    if 54 - 54: ii11ii1ii + OOooOOo / O0ooOooooO . OOooOOo * OoOO0ooOOoo0O
    oOooO0 ( o0o0oOoOO0O , i1ii1II1ii , 143 , OoOooOo0O , oo00 , Ooo00OoOOO )
    if 1 - 1: OoOO0ooOOoo0O * OoOO . i1IIi / ii11ii1ii . o00O0oo + ii11ii1ii
   except :
    pass
 except :
  pass
  if 17 - 17: ii11ii1ii + OoOO / o0oO0 / O0ooOooooO * IIII
def II1iiIIiIii ( ) :
 if 5 - 5: iIii1I11I1II1 / O0oO / i1IIi % OoooooooOO
 try :
  if 50 - 50: o0oO0 / OoOO0ooOOoo0O * o0oO0
  oOoOoO000OO = i1i1ii ( iIIiiiI )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( oOoOoO000OO )
  for O0Oooo in iII1ii1 :
   if 34 - 34: O0 * O0 % OoooooooOO + O0ooOooooO * iIii1I11I1II1 % o0oO0
   try :
    if 25 - 25: O0oO + OoOO0ooOOoo0O . o0000oOoOoO0o % OoOO0ooOOoo0O * IIII
    I1Ii1 = O0Oooo
    if 32 - 32: i11iIiiIii - Oooo0Ooo000
   except :
    pass
    if 53 - 53: OoooooooOO - i1I111II1I
  iiIi1iI1iIii = i1i1ii ( I1Ii1 )
  iII1ii1 = re . compile ( OoO ) . findall ( iiIi1iI1iIii )
  for OoOooOo0O , o0o0oOoOO0O , oo00 , i1ii1II1ii , Ooo00OoOOO in iII1ii1 :
   try :
    if 87 - 87: oO0o0ooO0 . OOooOOo
    oOooO0 ( o0o0oOoOO0O , i1ii1II1ii , 143 , OoOooOo0O , oo00 , Ooo00OoOOO )
    if 17 - 17: o0oO0 . i11iIiiIii
   except :
    pass
 except :
  pass
  if 5 - 5: o00O0oo + O0 + O0 . Oooo0Ooo000 - iI
def o00oo0000 ( ) :
 if 44 - 44: ii11ii1ii % iIii1I11I1II1
 try :
  if 90 - 90: II111iiii + OoooooooOO % OoooooooOO
  oOoOoO000OO = i1i1ii ( iIi11 )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( oOoOoO000OO )
  for O0Oooo in iII1ii1 :
   if 35 - 35: O0ooOooooO / o00O0oo * OoooooooOO . II111iiii / ii11ii1ii
   try :
    if 1 - 1: OoooooooOO + i1I111II1I . i1IIi % O0oO
    I1Ii1 = O0Oooo
    if 66 - 66: o0000oOoOoO0o + o00O0oo + OOooOOo - oO0o0ooO0
   except :
    pass
    if 12 - 12: O0ooOooooO . i1I111II1I . OoOO0ooOOoo0O / O0
  iiIi1iI1iIii = i1i1ii ( I1Ii1 )
  iII1ii1 = re . compile ( OoO ) . findall ( iiIi1iI1iIii )
  for OoOooOo0O , o0o0oOoOO0O , oo00 , i1ii1II1ii , Ooo00OoOOO in iII1ii1 :
   try :
    if 58 - 58: o0000oOoOoO0o - II111iiii % oO0o0ooO0 + Oooo0Ooo000 . OoOO0ooOOoo0O / i1I111II1I
    oOooO0 ( o0o0oOoOO0O , i1ii1II1ii , 143 , OoOooOo0O , oo00 , Ooo00OoOOO )
    if 8 - 8: o00O0oo . OoOO * O0oO + II111iiii % i11iIiiIii
   except :
    pass
 except :
  pass
  if 8 - 8: iI * O0
def OOoOIiIIII ( name , url ) :
 if 89 - 89: OoOO / OOooOOo
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 16 - 16: ii11ii1ii + iI / ii11ii1ii / OoOO % oO0o0ooO0 % o00O0oo
 Ii1II11II1iii = i1i1ii ( url )
 iII1ii1 = re . compile ( I1iI1 ) . findall ( Ii1II11II1iii )
 for OoOooOo0O , name , oo00 , url in iII1ii1 :
  try :
   if 86 - 86: O0ooOooooO
   if 69 - 69: o00O0oo - Oooo0Ooo000
   O00OOOoOoo0O = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % O00OOOoOoo0O + name + '[/COLOR]'
   iiIIi1 ( name , url , 144 , OoOooOo0O , oo00 )
   if 10 - 10: O0oO * o0oO0 % OoooooooOO
   if 83 - 83: Oooo0Ooo000 - OOooOOo - o00O0oo % O0 . o0oO0
  except :
   pass
   if 35 - 35: i1I111II1I + i1IIi * oO0o0ooO0 - o0oO0 . ii11ii1ii
   if 31 - 31: o0000oOoOoO0o
   if 15 - 15: O0 / ii11ii1ii % o00O0oo + o0000oOoOoO0o
def iiIIi1 ( name , url , mode , iconimage , fanart ) :
 if 23 - 23: iIii1I11I1II1 + O0
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 58 - 58: ii11ii1ii
 IiiIIIiI1ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage="
 oo0OOoOoo0O0O = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 oo0OOoOoo0O0O . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 oo0OOoOoo0O0O . setProperty ( 'fanart_image' , fanart )
 oo0OOoOoo0O0O . setProperty ( 'IsPlayable' , 'true' )
 iiI11ii1111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IiiIIIiI1ii , listitem = oo0OOoOoo0O0O )
 return iiI11ii1111
 if 2 - 2: OoOO0ooOOoo0O . i1IIi . i1IIi - II111iiii - OoOO0ooOOoo0O
 if 73 - 73: IIII
def Iiii1IiIi ( name , url ) :
 if 39 - 39: IIII * i1I111II1I
 if 2 - 2: i1IIi - iI + OOooOOo . o0000oOoOoO0o * o0000oOoOoO0o / OoOO0ooOOoo0O
 IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 OO0Oooo0oOO0O = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 o00O0 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 oOOO = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 Oo00o0OO0O00o = i1i1ii ( o00O0 )
 iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
 for iIi1I1 in iII1ii1 :
  if 63 - 63: O0ooOooooO * o00O0oo . OoooooooOO / IIII * ii11ii1ii . iI
  try :
   if 62 - 62: i1IIi / iI . OOooOOo * o0000oOoOoO0o
   if 21 - 21: o0000oOoOoO0o
   IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 81 - 81: O0oO / iIii1I11I1II1 - iI * Oooo0Ooo000 . OOooOOo * o00O0oo
   if 95 - 95: OOooOOo
   if IIIi1I1IIii1II == iIi1I1 :
    if 88 - 88: i1I111II1I % OoOO + Oooo0Ooo000 + Oooo0Ooo000 * II111iiii
    if 78 - 78: OoooooooOO
    if 'https://team.com' in url :
     if 77 - 77: o00O0oo / i1IIi / ii11ii1ii % IIII
     url = url . replace ( 'https://team.com' , 'https://verystream.com' )
     if 48 - 48: O0oO - i1I111II1I + iIii1I11I1II1 + OoooooooOO
    if 'https://mybox.com' in url :
     if 4 - 4: II111iiii . O0oO + o0oO0 * Oooo0Ooo000 . iI
     url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
     if 87 - 87: OoOO0ooOOoo0O / OoOO / i11iIiiIii
     if 74 - 74: oO0o0ooO0 / o00O0oo % o0000oOoOoO0o
    if 'https://vidcloud.co/' in url :
     if 88 - 88: OoOO0ooOOoo0O - i11iIiiIii % o0000oOoOoO0o * O0oO + o00O0oo
     url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
     if 52 - 52: II111iiii . OOooOOo + OoOO0ooOOoo0O % OoOO
    if 'https://gounlimited.to' in url :
     if 62 - 62: o0000oOoOoO0o
     url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
     if 15 - 15: O0oO + o0oO0 . IIII * OoOO . OoOO0ooOOoo0O
    if 'https://drive.com' in url :
     if 18 - 18: i1IIi % II111iiii + Oooo0Ooo000 % o0oO0
     url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
     if 72 - 72: iIii1I11I1II1
     if 45 - 45: ii11ii1ii - o0000oOoOoO0o % Oooo0Ooo000
    import resolveurl
    if 38 - 38: Oooo0Ooo000 % IIII - OoooooooOO
    oOo0OOoooO = urlresolver . HostedMediaFile ( url )
    if 26 - 26: o0000oOoOoO0o * i1I111II1I . i1IIi
    if not oOo0OOoooO :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
     return False
     if 59 - 59: O0 + i1IIi - o0000oOoOoO0o
    try :
     IIII1 = xbmcgui . DialogProgress ( )
     IIII1 . create ( 'Realstream:' , 'Iniciando ...' )
     IIII1 . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
     xbmc . sleep ( 1000 )
     OooOo000o0o = oOo0OOoooO . resolve ( )
     if not OooOo000o0o or not isinstance ( OooOo000o0o , basestring ) :
      try : iI1I1iII1i = OooOo000o0o . msg
      except : iI1I1iII1i = url
      raise Exception ( iI1I1iII1i )
      if 30 - 30: O0 + o00O0oo + II111iiii
    except Exception as iI1IIIii :
     try : iI1I1iII1i = str ( iI1IIIii )
     except : iI1I1iII1i = url
     IIII1 . update ( 45 , 'RESOLVEURL:' , 'Reiniciando ... ' )
     xbmc . sleep ( 1000 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Episodio no disponible.  ,3000)" )
     IIII1 . close ( )
     if 14 - 14: o0000oOoOoO0o / IIII - iIii1I11I1II1 - oO0o0ooO0 % iI
    IIII1 . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    IIII1 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
    xbmc . sleep ( 500 )
    IIII1 . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
    xbmc . sleep ( 500 )
    IIII1 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de este capitulo!' )
    IIII1 . close ( )
    O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
    I1iIiI1IiIIII = xbmcgui . ListItem ( path = OooOo000o0o )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1iIiI1IiIIII )
    if 18 - 18: iI % i11iIiiIii . iIii1I11I1II1 - O0ooOooooO
    if 80 - 80: OOooOOo + oO0o0ooO0 - i1IIi . o0oO0 / o0000oOoOoO0o / OOooOOo
   else :
    if 1 - 1: O0oO + i11iIiiIii - OOooOOo / IIII + Oooo0Ooo000
    O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
    if O0ii1ii1ii == 'true' :
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Por favor compruebe los ajustes de realstream.[/COLOR]" , "[COLOR white] Desde la seccion Tutoriales puede sacarle mayor partido a su Realstream, tambien puede configurarlo a su gusto. [/COLOR]" , "[COLOR gold]El addon no esta activado o bien configurado.[/COLOR]" )
     if 80 - 80: oO0o0ooO0 + o0000oOoOoO0o * o0oO0 + OoOO
     iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
     Ii1ii1IiIII ( '[COLOR %s]Video tutoriales[/COLOR]' % iIIIi1 , IIIII11I1IiI , 125 , O0OOO0OOoO0O , oo00 )
  except :
   pass
   if 75 - 75: O0oO / o0000oOoOoO0o / IIII / i1I111II1I % iI + II111iiii
   if 4 - 4: O0ooOooooO - ii11ii1ii - i1I111II1I - O0oO % i11iIiiIii / OoOO
   if 50 - 50: iI + i1IIi
   if 31 - 31: o0oO0
   if 78 - 78: i11iIiiIii + o0000oOoOoO0o + Oooo0Ooo000 / o0000oOoOoO0o % iIii1I11I1II1 % i1I111II1I
def Oo0O0Oo00O ( ) :
 if 9 - 9: o0000oOoOoO0o . OOooOOo - o00O0oo
 if 32 - 32: OoooooooOO / OOooOOo / iIii1I11I1II1 + II111iiii . oO0o0ooO0 . o0000oOoOoO0o
 ii1ii = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 ii1ii . doModal ( )
 if not ii1ii . isConfirmed ( ) :
  return None ;
 o0o0oOoOO0O = ii1ii . getText ( ) . strip ( )
 if 8 - 8: OoOO + OoOO0ooOOoo0O . iIii1I11I1II1 % O0
 if 43 - 43: o00O0oo - O0ooOooooO
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 70 - 70: O0ooOooooO / IIII % iI - o0oO0
  i1II11Iii1I = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + o0o0oOoOO0O + '&language=es-ES' ) )
  if 92 - 92: IIII % i1I111II1I % OoOO0ooOOoo0O
  if 4 - 4: OoOO0ooOOoo0O + o0oO0 / oO0o0ooO0
  return 'android'
  if 13 - 13: O0ooOooooO
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 80 - 80: o0oO0 - o0000oOoOoO0o
  i1II11Iii1I = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + o0o0oOoOO0O + '&language=es-ES' )
  if 41 - 41: o0000oOoOoO0o - ii11ii1ii * OOooOOo
  if 82 - 82: OoOO % o0000oOoOoO0o % IIII / O0
  return 'windows'
  if 94 - 94: o00O0oo + o00O0oo + OoooooooOO % iI
  if 7 - 7: O0ooOooooO
def oOo000O ( ) :
 if 1 - 1: iIii1I11I1II1
 try :
  if 54 - 54: OoooooooOO - OOooOOo % o00O0oo
  Oo00o0OO0O00o = i1i1ii ( oOOo0O00o )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
  for O0Oooo in iII1ii1 :
   if 92 - 92: OoOO * iI
   try :
    if 35 - 35: i11iIiiIii
    all = O0Oooo
    if 99 - 99: II111iiii . o0000oOoOoO0o + O0
   except :
    pass
    if 71 - 71: i1I111II1I + i1IIi * ii11ii1ii % ii11ii1ii / ii11ii1ii
  Ii1II11II1iii = i1i1ii ( all )
  iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( Ii1II11II1iii )
  for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
   try :
    if 55 - 55: OoooooooOO + Oooo0Ooo000 + OoooooooOO * iI
    Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
    if 68 - 68: O0
   except :
    pass
 except :
  pass
  if 2 - 2: OoOO + O0 * OoOO - o0oO0 + oO0o0ooO0
def iIIIiII1 ( ) :
 if 24 - 24: o0000oOoOoO0o + iI + O0oO - iIii1I11I1II1
 try :
  if 49 - 49: O0oO . iI * OoOO0ooOOoo0O % i1I111II1I . O0
  iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
  OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 48 - 48: O0 * o0oO0 - O0 / o0oO0 + OoOO0ooOOoo0O
  OOOO0OOO = i1i1ii ( ii1 )
  iII1ii1 = re . compile ( oOO00O ) . findall ( OOOO0OOO )
  for I1i1iiiI1 , iIIi , oO0o00oo0 in iII1ii1 :
   if re . search ( OOO00O , oO0o00oo0 ) :
    if 52 - 52: OoOO % o0oO0 * II111iiii
    if iiII1i1 == iIIi and o00oOO0o == I1i1iiiI1 and OOO00O == oO0o00oo0 :
     if 4 - 4: O0oO % O0 - OoooooooOO + iI . oO0o0ooO0 % II111iiii
     i1111 = i1i1ii ( OOO )
     iII1ii1 = re . compile ( OOOoo0OO ) . findall ( i1111 )
     for O0Oooo in iII1ii1 :
      if 9 - 9: II111iiii * II111iiii . i11iIiiIii * iIii1I11I1II1
      try :
       if 18 - 18: OoOO . II111iiii % OoOO0ooOOoo0O % o0oO0
       I1Ii1 = O0Oooo
       if 87 - 87: iIii1I11I1II1 . OoooooooOO * OoOO0ooOOoo0O
      except :
       pass
       if 100 - 100: OoOO / i1IIi - OOooOOo % o0oO0 - iIii1I11I1II1
     iiIi1iI1iIii = i1i1ii ( I1Ii1 )
     iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( iiIi1iI1iIii )
     for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
      try :
       if 17 - 17: O0oO / o0000oOoOoO0o % ii11ii1ii
       Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
       if 71 - 71: i1I111II1I . Oooo0Ooo000 . OoOO
      except :
       pass
       if 68 - 68: i11iIiiIii % oO0o0ooO0 * OoOO * i1I111II1I * II111iiii + O0
    else :
     if 66 - 66: O0oO % o00O0oo % OoooooooOO
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Esta seccion ha sido cerrada![COLOR orange] Lo sentimos ...[/COLOR] ,5000)" )
     if 34 - 34: o0000oOoOoO0o / O0ooOooooO % O0 . OoOO . i1IIi
     return False
     if 29 - 29: O0 . Oooo0Ooo000
 except :
  pass
  if 66 - 66: oO0o0ooO0 * iIii1I11I1II1 % iIii1I11I1II1 * i1I111II1I - iI - i1I111II1I
def o0O0oO0 ( ) :
 if 77 - 77: O0 . o0oO0
 try :
  if 39 - 39: iI . II111iiii
  iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
  OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 45 - 45: oO0o0ooO0 * OoOO0ooOOoo0O / iIii1I11I1II1
  OOOO0OOO = i1i1ii ( ii1 )
  iII1ii1 = re . compile ( oOO00O ) . findall ( OOOO0OOO )
  for I1i1iiiI1 , iIIi , oO0o00oo0 in iII1ii1 :
   if re . search ( OOO00O , oO0o00oo0 ) :
    if 77 - 77: Oooo0Ooo000 - O0oO
    if iiII1i1 == iIIi and o00oOO0o == I1i1iiiI1 and OOO00O == oO0o00oo0 :
     if 11 - 11: o00O0oo
     i11 = i1i1ii ( oooOo0OOOoo0 )
     iII1ii1 = re . compile ( OOOoo0OO ) . findall ( i11 )
     for O0Oooo in iII1ii1 :
      if 26 - 26: iIii1I11I1II1 * Oooo0Ooo000 - IIII
      try :
       III1II111Ii1 = O0Oooo
      except :
       pass
       if 82 - 82: Oooo0Ooo000 - IIII + OoOO
     Oo00o0OO0O00o = i1i1ii ( III1II111Ii1 )
     iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( Oo00o0OO0O00o )
     for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
      try :
       if 64 - 64: o0000oOoOoO0o . O0 * o0oO0 + OoooooooOO - ii11ii1ii . OoooooooOO
       Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
       if 70 - 70: ii11ii1ii - oO0o0ooO0 . iIii1I11I1II1 % O0oO / OoOO0ooOOoo0O - O0
      except :
       pass
       if 55 - 55: O0ooOooooO - OoOO
    else :
     if 100 - 100: O0
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Esta seccion ha sido cerrada![COLOR orange] Lo sentimos ...[/COLOR] ,5000)" )
     if 79 - 79: iIii1I11I1II1
     return False
 except :
  pass
  if 81 - 81: IIII + iIii1I11I1II1 * Oooo0Ooo000 - iIii1I11I1II1 . IIII
def I1 ( ) :
 if 14 - 14: OOooOOo . o0oO0
 try :
  if 46 - 46: O0ooOooooO - iIii1I11I1II1
  iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
  OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 50 - 50: O0ooOooooO / O0ooOooooO + IIII * iI / o00O0oo
  OOOO0OOO = i1i1ii ( ii1 )
  iII1ii1 = re . compile ( oOO00O ) . findall ( OOOO0OOO )
  for I1i1iiiI1 , iIIi , oO0o00oo0 in iII1ii1 :
   if re . search ( OOO00O , oO0o00oo0 ) :
    if 14 - 14: o0oO0 % OOooOOo - iIii1I11I1II1 . IIII + OoOO - Oooo0Ooo000
    if iiII1i1 == iIIi and o00oOO0o == I1i1iiiI1 and OOO00O == oO0o00oo0 :
     if 5 - 5: O0ooOooooO
     Oo00o0OO0O00o = i1i1ii ( db2 )
     iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
     for O0Oooo in iII1ii1 :
      if 62 - 62: OoOO0ooOOoo0O . OoooooooOO . IIII . OoOO * O0ooOooooO
      try :
       if 78 - 78: oO0o0ooO0 / OoOO - oO0o0ooO0 * OoooooooOO . OoOO0ooOOoo0O
       OOoooOoO0Oo = O0Oooo
       if 78 - 78: OoooooooOO / IIII % OoOO0ooOOoo0O * OoooooooOO
      except :
       pass
       if 68 - 68: oO0o0ooO0
       if 29 - 29: O0ooOooooO + i11iIiiIii % O0oO
     Oo00o0OO0O00o = i1i1ii ( OOoooOoO0Oo )
     iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( Oo00o0OO0O00o )
     for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
      try :
       Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
       if 93 - 93: OoOO0ooOOoo0O % iIii1I11I1II1
      except :
       pass
    else :
     if 90 - 90: OOooOOo - IIII / o0oO0 / O0 / O0oO
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Esta seccion ha sido cerrada![COLOR orange] Lo sentimos ...[/COLOR] ,5000)" )
     if 87 - 87: OoOO0ooOOoo0O / i1I111II1I + iIii1I11I1II1
     return False
     if 93 - 93: iIii1I11I1II1 + oO0o0ooO0 % iI
 except :
  pass
  if 21 - 21: IIII
def iIiI1I1IIi11 ( ) :
 if 9 - 9: iI + O0ooOooooO - O0oO / i1IIi % o00O0oo / i1I111II1I
 try :
  if 60 - 60: o00O0oo
  IIoO00OoOo = i1i1ii ( ii1I1i11 )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( IIoO00OoOo )
  for O0Oooo in iII1ii1 :
   if 74 - 74: II111iiii . O0 - OOooOOo + i1I111II1I % i11iIiiIii % OoOO0ooOOoo0O
   try :
    if 78 - 78: o0oO0 + OoOO0ooOOoo0O + i1I111II1I - i1I111II1I . i11iIiiIii / OoOO
    I11i11i1 = O0Oooo
    if 68 - 68: ii11ii1ii . ii11ii1ii - o00O0oo / O0oO . iI / i1IIi
   except :
    pass
    if 12 - 12: o00O0oo * i1IIi * O0oO
    if 23 - 23: IIII / O0 / OOooOOo
  Oo00o0OO0O00o = i1i1ii ( I11i11i1 )
  iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( Oo00o0OO0O00o )
  for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
   try :
    if 49 - 49: O0oO . o0000oOoOoO0o % oO0o0ooO0 / o0oO0
    Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
    if 95 - 95: O0 * OoOO0ooOOoo0O * i1I111II1I . iI / iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 28 - 28: i1I111II1I + oO0o0ooO0 - iI / iIii1I11I1II1 - OOooOOo
def Ii1i1 ( ) :
 if 65 - 65: oO0o0ooO0 + o00O0oo / IIII
 try :
  if 85 - 85: iIii1I11I1II1 / OoooooooOO % II111iiii
  Oo00o0OO0O00o = i1i1ii ( OO0O000 )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
  for O0Oooo in iII1ii1 :
   if 49 - 49: i11iIiiIii % OoOO0ooOOoo0O + Oooo0Ooo000 . II111iiii % O0ooOooooO * IIII
   try :
    if 67 - 67: i1IIi
    iii = O0Oooo
    if 57 - 57: OOooOOo
   except :
    pass
    if 35 - 35: OoooooooOO - Oooo0Ooo000 / OoOO
    if 50 - 50: OoOO0ooOOoo0O
  Oo00o0OO0O00o = i1i1ii ( iii )
  iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( Oo00o0OO0O00o )
  for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
   try :
    Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
    if 33 - 33: O0oO
   except :
    pass
 except :
  pass
  if 98 - 98: OoOO0ooOOoo0O % II111iiii
def OoO0O000 ( ) :
 if 14 - 14: OoOO / OoOO * O0 . oO0o0ooO0
 try :
  if 59 - 59: II111iiii * i11iIiiIii
  Oo00o0OO0O00o = i1i1ii ( oO0O00oOOoooO )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
  for O0Oooo in iII1ii1 :
   if 54 - 54: O0 % OoooooooOO - OOooOOo
   try :
    if 61 - 61: ii11ii1ii * i1I111II1I . ii11ii1ii + ii11ii1ii / i1I111II1I * O0
    o0o00O0oOooO0 = O0Oooo
    if 99 - 99: iI
   except :
    pass
    if 76 - 76: OoOO
  Oo00o0OO0O00o = i1i1ii ( o0o00O0oOooO0 )
  iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( Oo00o0OO0O00o )
  for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
   try :
    Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
    if 92 - 92: O0oO - iIii1I11I1II1 % OoooooooOO
   except :
    pass
 except :
  pass
  if 39 - 39: O0ooOooooO . OOooOOo * OoOO0ooOOoo0O - i11iIiiIii
def i1II1II1iii1i ( ) :
 if 75 - 75: i1I111II1I - OoOO0ooOOoo0O - iIii1I11I1II1 % o0000oOoOoO0o
 try :
  if 58 - 58: O0 . i1I111II1I / OoooooooOO . OoOO / ii11ii1ii * II111iiii
  Oo00o0OO0O00o = i1i1ii ( Oo0O00O000 )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
  for O0Oooo in iII1ii1 :
   if 53 - 53: o0oO0 - O0 / o0000oOoOoO0o % O0ooOooooO * OOooOOo % IIII
   try :
    if 69 - 69: o00O0oo
    oOOO0ooo = O0Oooo
    if 19 - 19: O0ooOooooO - o0000oOoOoO0o - o0oO0 - OoOO0ooOOoo0O . O0ooOooooO . Oooo0Ooo000
   except :
    pass
    if 48 - 48: O0ooOooooO + i1I111II1I
    if 60 - 60: O0oO + O0ooOooooO . i1I111II1I / i1IIi . iIii1I11I1II1
  Oo00o0OO0O00o = i1i1ii ( oOOO0ooo )
  iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( Oo00o0OO0O00o )
  for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
   try :
    Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
    if 14 - 14: IIII
   except :
    pass
 except :
  pass
  if 79 - 79: o0oO0
def o0Oii111 ( ) :
 if 93 - 93: OoooooooOO * ii11ii1ii
 try :
  if 10 - 10: Oooo0Ooo000 * OoooooooOO + O0oO - o00O0oo / o00O0oo . i11iIiiIii
  Oo00o0OO0O00o = i1i1ii ( oo )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
  for O0Oooo in iII1ii1 :
   if 22 - 22: Oooo0Ooo000 / o0000oOoOoO0o
   try :
    if 98 - 98: i1IIi
    OOO0oO = O0Oooo
    if 38 - 38: iIii1I11I1II1 / iI
   except :
    pass
    if 13 - 13: iIii1I11I1II1
    if 77 - 77: i11iIiiIii - iIii1I11I1II1 / oO0o0ooO0 / iI / OoOO
  Oo00o0OO0O00o = i1i1ii ( OOO0oO )
  iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( Oo00o0OO0O00o )
  for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
   try :
    Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
    if 56 - 56: OoooooooOO * O0
   except :
    pass
 except :
  pass
  if 85 - 85: OoooooooOO % OoOO0ooOOoo0O * iIii1I11I1II1
def IiI ( ) :
 if 60 - 60: Oooo0Ooo000
 try :
  if 98 - 98: iI
  Oo00o0OO0O00o = i1i1ii ( iIIii )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
  for O0Oooo in iII1ii1 :
   if 34 - 34: iIii1I11I1II1 * O0oO * O0oO / o00O0oo
   try :
    if 28 - 28: OoOO - oO0o0ooO0 + OoOO0ooOOoo0O + o0oO0 / iIii1I11I1II1
    iiiii11I1 = O0Oooo
    if 16 - 16: O0 . o0oO0 % i1IIi % IIII
   except :
    pass
    if 50 - 50: i1I111II1I + o0000oOoOoO0o
    if 96 - 96: OoOO
  Oo00o0OO0O00o = i1i1ii ( iiiii11I1 )
  iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( Oo00o0OO0O00o )
  for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
   try :
    Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
    if 92 - 92: ii11ii1ii / i11iIiiIii + o00O0oo
   except :
    pass
 except :
  pass
  if 87 - 87: OoOO0ooOOoo0O % iIii1I11I1II1
def o0OO0OOO0O ( ) :
 if 36 - 36: i11iIiiIii / O0ooOooooO . O0oO + i1I111II1I . O0 + OOooOOo
 try :
  if 36 - 36: i1IIi - o00O0oo - Oooo0Ooo000
  Oo00o0OO0O00o = i1i1ii ( OO0 )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
  for O0Oooo in iII1ii1 :
   if 7 - 7: i11iIiiIii + OOooOOo
   try :
    if 47 - 47: Oooo0Ooo000 - IIII / iI - ii11ii1ii + O0ooOooooO - iIii1I11I1II1
    o0OOOOO0 = O0Oooo
    if 79 - 79: II111iiii - iI . i1IIi + O0 % O0 * OOooOOo
   except :
    pass
    if 7 - 7: i1IIi + IIII % O0ooOooooO / o0000oOoOoO0o + i1IIi
    if 41 - 41: o0oO0 + i11iIiiIii / i1I111II1I % o00O0oo
  Oo00o0OO0O00o = i1i1ii ( o0OOOOO0 )
  iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( Oo00o0OO0O00o )
  for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
   try :
    Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
    if 22 - 22: OoOO0ooOOoo0O % o0000oOoOoO0o * o0oO0 - o00O0oo + o0000oOoOoO0o - ii11ii1ii
   except :
    pass
 except :
  pass
  if 15 - 15: IIII
  if 31 - 31: O0ooOooooO / i1IIi . OoOO
def OOOoo ( ) :
 if 25 - 25: o00O0oo + oO0o0ooO0 + OoooooooOO . II111iiii . O0ooOooooO
 try :
  if 66 - 66: iI * OoOO0ooOOoo0O
  Oo00o0OO0O00o = i1i1ii ( ii1iii1i )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
  for O0Oooo in iII1ii1 :
   if 2 - 2: oO0o0ooO0 . Oooo0Ooo000 * ii11ii1ii + O0 - O0oO * iIii1I11I1II1
   try :
    if 12 - 12: o0000oOoOoO0o * Oooo0Ooo000 % II111iiii * i1IIi * iIii1I11I1II1
    oO0oOoo0O = O0Oooo
    if 26 - 26: ii11ii1ii + OOooOOo * IIII + iI
   except :
    pass
    if 88 - 88: O0oO + i11iIiiIii % oO0o0ooO0 * IIII * IIII * o0oO0
    if 24 - 24: iI / O0ooOooooO + i1I111II1I . i1I111II1I
  Oo00o0OO0O00o = i1i1ii ( oO0oOoo0O )
  iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( Oo00o0OO0O00o )
  for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
   try :
    Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
    if 39 - 39: iI + O0 / i1IIi % i1I111II1I / oO0o0ooO0 * i1I111II1I
   except :
    pass
 except :
  pass
  if 77 - 77: i1I111II1I . Oooo0Ooo000 % OoOO0ooOOoo0O
  if 42 - 42: i1I111II1I % O0ooOooooO % o0000oOoOoO0o % oO0o0ooO0 + O0oO % OoOO0ooOOoo0O
def iI1iIIiii ( ) :
 if 52 - 52: o0oO0 % IIII * OOooOOo % O0oO + IIII / O0ooOooooO
 try :
  if 80 - 80: OoooooooOO + i1I111II1I
  Oo00o0OO0O00o = i1i1ii ( ooOoO00 )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
  for O0Oooo in iII1ii1 :
   if 95 - 95: Oooo0Ooo000 / oO0o0ooO0 * Oooo0Ooo000 - OoooooooOO * OoooooooOO % OoOO
   try :
    if 43 - 43: ii11ii1ii . Oooo0Ooo000
    I1I1i1i = O0Oooo
    if 87 - 87: OoOO0ooOOoo0O / i1I111II1I . iI - IIII / OoOO
   except :
    pass
    if 41 - 41: II111iiii
    if 27 - 27: ii11ii1ii * OoOO0ooOOoo0O % iIii1I11I1II1 . OOooOOo
  Oo00o0OO0O00o = i1i1ii ( I1I1i1i )
  iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( Oo00o0OO0O00o )
  for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
   try :
    Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
    if 70 - 70: O0oO % II111iiii % O0 . i1IIi / Oooo0Ooo000
   except :
    pass
    if 100 - 100: o00O0oo * i11iIiiIii % oO0o0ooO0 / ii11ii1ii / iI + o00O0oo
 except :
  pass
  if 59 - 59: Oooo0Ooo000 - i1I111II1I
  if 14 - 14: iIii1I11I1II1 - iIii1I11I1II1
def i111i1I1ii1i ( ) :
 if 100 - 100: i1I111II1I . o0oO0 - iIii1I11I1II1 . i11iIiiIii / II111iiii
 try :
  if 71 - 71: Oooo0Ooo000 * ii11ii1ii . O0oO
  Oo00o0OO0O00o = i1i1ii ( o0O00Oo0 )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
  for O0Oooo in iII1ii1 :
   if 49 - 49: i1I111II1I * O0 . i1I111II1I
   try :
    if 19 - 19: II111iiii - i1I111II1I
    OOOOo000o00OO = O0Oooo
    if 96 - 96: O0 . IIII % iI + i11iIiiIii - IIII * iI
   except :
    pass
    if 33 - 33: iI % i1IIi - oO0o0ooO0 . O0 / O0
    if 96 - 96: OoooooooOO + i1I111II1I * O0
  Oo00o0OO0O00o = i1i1ii ( OOOOo000o00OO )
  iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( Oo00o0OO0O00o )
  for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
   try :
    Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
    if 86 - 86: o0oO0
   except :
    pass
    if 29 - 29: iIii1I11I1II1 - OoOO + OOooOOo % iIii1I11I1II1 % IIII
 except :
  pass
  if 84 - 84: i1I111II1I + o00O0oo + o0oO0 + O0ooOooooO
def ooOOo0o ( ) :
 if 50 - 50: II111iiii - Oooo0Ooo000 + iIii1I11I1II1 + iIii1I11I1II1
 try :
  if 91 - 91: II111iiii - O0 . iIii1I11I1II1 . O0 + o00O0oo - II111iiii
  Oo00o0OO0O00o = i1i1ii ( i111iIi1i1II1 )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
  for O0Oooo in iII1ii1 :
   if 26 - 26: o0000oOoOoO0o
   try :
    if 12 - 12: OoooooooOO / O0 + II111iiii * o00O0oo
    Ii11ii1I1 = O0Oooo
    if 11 - 11: iIii1I11I1II1 . OoOO0ooOOoo0O / i1I111II1I % iI
   except :
    pass
    if 61 - 61: iI - IIII + IIII
  Oo00o0OO0O00o = i1i1ii ( Ii11ii1I1 )
  iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( Oo00o0OO0O00o )
  for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
   try :
    Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
    if 40 - 40: i11iIiiIii . iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 2 - 2: i1IIi * oO0o0ooO0 - oO0o0ooO0 + OoooooooOO % OoOO0ooOOoo0O / OoOO0ooOOoo0O
  if 3 - 3: OoooooooOO
def O0OoO0o ( ) :
 if 1 - 1: iI % O0oO * o00O0oo - II111iiii
 try :
  if 49 - 49: oO0o0ooO0 - O0ooOooooO % OoOO0ooOOoo0O
  Oo00o0OO0O00o = i1i1ii ( i1I1i111Ii )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
  for O0Oooo in iII1ii1 :
   if 72 - 72: OOooOOo + i1I111II1I . OoOO0ooOOoo0O + OoOO0ooOOoo0O
   try :
    if 94 - 94: i11iIiiIii % OoooooooOO / OOooOOo
    iII1Iii11111 = O0Oooo
    if 80 - 80: oO0o0ooO0 * O0oO / iIii1I11I1II1 % oO0o0ooO0 / iIii1I11I1II1
   except :
    pass
    if 42 - 42: i1IIi / i11iIiiIii . ii11ii1ii * O0ooOooooO . i11iIiiIii * O0
    if 44 - 44: i1IIi . OOooOOo / i11iIiiIii + i1I111II1I
  Oo00o0OO0O00o = i1i1ii ( iII1Iii11111 )
  iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( Oo00o0OO0O00o )
  for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
   try :
    Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
    if 27 - 27: IIII
   except :
    pass
 except :
  pass
  if 52 - 52: Oooo0Ooo000 % OoOO0ooOOoo0O + iIii1I11I1II1 * oO0o0ooO0 . o0oO0
  if 95 - 95: iIii1I11I1II1 . i1I111II1I - OoooooooOO * OoOO / o0000oOoOoO0o
def oOo0OO0o0 ( ) :
 if 35 - 35: ii11ii1ii . ii11ii1ii % OoooooooOO - o0oO0
 try :
  if 43 - 43: OoOO % OoOO
  Oo00o0OO0O00o = i1i1ii ( i1i1iI1iiiI )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
  for O0Oooo in iII1ii1 :
   if 46 - 46: ii11ii1ii % iIii1I11I1II1 . O0ooOooooO . O0 * iI / OoooooooOO
   try :
    if 7 - 7: oO0o0ooO0 - O0 * O0oO - o0000oOoOoO0o - II111iiii
    Ii11iiI1 = O0Oooo
    if 71 - 71: o0000oOoOoO0o / IIII % IIII
   except :
    pass
  Oo00o0OO0O00o = i1i1ii ( Ii11iiI1 )
  iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( Oo00o0OO0O00o )
  for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
   try :
    Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
    if 89 - 89: OoooooooOO + i11iIiiIii / O0oO + iIii1I11I1II1 % iI
   except :
    pass
 except :
  pass
  if 29 - 29: o00O0oo
def Oo0 ( ) :
 if 60 - 60: O0oO % iI
 try :
  if 12 - 12: ii11ii1ii
  Oo00o0OO0O00o = i1i1ii ( oOOOoo00 )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
  for O0Oooo in iII1ii1 :
   if 63 - 63: IIII . II111iiii . O0oO
   try :
    if 46 - 46: iI % i1I111II1I - o0000oOoOoO0o - ii11ii1ii - o0oO0 / O0oO
    OooO0Oo0 = O0Oooo
    if 83 - 83: O0
   except :
    pass
    if 89 - 89: ii11ii1ii + o00O0oo - o0000oOoOoO0o
    if 40 - 40: OoOO + OoOO
  Oo00o0OO0O00o = i1i1ii ( OooO0Oo0 )
  iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( Oo00o0OO0O00o )
  for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
   try :
    Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
    if 94 - 94: O0ooOooooO * iIii1I11I1II1 . O0oO
   except :
    pass
 except :
  pass
  if 13 - 13: iIii1I11I1II1 * OoOO0ooOOoo0O / Oooo0Ooo000 % iI + oO0o0ooO0
  if 41 - 41: o00O0oo
def i1iI1i ( ) :
 if 59 - 59: i1I111II1I
 try :
  if 89 - 89: OoOO0ooOOoo0O % iIii1I11I1II1
  Oo00o0OO0O00o = i1i1ii ( iiI1IIIi )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
  for O0Oooo in iII1ii1 :
   if 35 - 35: o00O0oo + Oooo0Ooo000 - OoOO0ooOOoo0O % oO0o0ooO0 % o0000oOoOoO0o % OoOO0ooOOoo0O
   try :
    if 45 - 45: OOooOOo * IIII % OoOO
    i111I11I = O0Oooo
    if 80 - 80: iIii1I11I1II1 - OoooooooOO - o00O0oo - o00O0oo . OoooooooOO
   except :
    pass
    if 48 - 48: Oooo0Ooo000 . i11iIiiIii / i1IIi % i1I111II1I % O0ooOooooO + oO0o0ooO0
    if 41 - 41: i1I111II1I
  Oo00o0OO0O00o = i1i1ii ( i111I11I )
  iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( Oo00o0OO0O00o )
  for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
   try :
    Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
    if 3 - 3: i1I111II1I + II111iiii / iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 10 - 10: II111iiii . O0
def iIii ( ) :
 if 6 - 6: OoOO / ii11ii1ii / O0ooOooooO
 try :
  if 13 - 13: o00O0oo % OoOO0ooOOoo0O
  Oo00o0OO0O00o = i1i1ii ( IIOOO0O00O0OOOO )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
  for O0Oooo in iII1ii1 :
   if 76 - 76: O0 . OoOO + OoOO0ooOOoo0O
   try :
    if 41 - 41: II111iiii * iI
    o0oOoOo0 = O0Oooo
    if 38 - 38: o0000oOoOoO0o % Oooo0Ooo000 + i11iIiiIii + O0ooOooooO + iI / i11iIiiIii
   except :
    pass
    if 94 - 94: O0ooOooooO - ii11ii1ii + oO0o0ooO0
    if 59 - 59: O0oO . OOooOOo - iIii1I11I1II1 + iIii1I11I1II1
  Oo00o0OO0O00o = i1i1ii ( o0oOoOo0 )
  iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( Oo00o0OO0O00o )
  for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
   try :
    Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
    if 56 - 56: oO0o0ooO0 + iI
   except :
    pass
 except :
  pass
  if 32 - 32: II111iiii + OoOO0ooOOoo0O % iI / OoOO0ooOOoo0O + o00O0oo
  if 2 - 2: i11iIiiIii - Oooo0Ooo000 + OoOO % O0oO * o0oO0
def Ooo000O00 ( ) :
 if 36 - 36: IIII % i11iIiiIii
 try :
  if 47 - 47: i1IIi + II111iiii . ii11ii1ii * oO0o0ooO0 . O0oO / i1IIi
  Oo00o0OO0O00o = i1i1ii ( OOo0 )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
  for O0Oooo in iII1ii1 :
   if 50 - 50: Oooo0Ooo000 / i1IIi % OoooooooOO
   try :
    if 83 - 83: o00O0oo * o00O0oo + IIII
    OooooOoO = O0Oooo
    if 79 - 79: iI % IIII
   except :
    pass
    if 54 - 54: OoOO0ooOOoo0O - Oooo0Ooo000
    if 65 - 65: Oooo0Ooo000 . iI + IIII / ii11ii1ii + i1I111II1I % i1IIi
  Oo00o0OO0O00o = i1i1ii ( OooooOoO )
  iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( Oo00o0OO0O00o )
  for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
   try :
    Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
    if 28 - 28: i11iIiiIii + O0 / o00O0oo
   except :
    pass
 except :
  pass
  if 3 - 3: OoOO * i1IIi . OOooOOo . O0 - OoOO0ooOOoo0O
  if 81 - 81: OOooOOo - iIii1I11I1II1 / OOooOOo / O0
def I1I1IIiiii1ii ( ) :
 if 92 - 92: oO0o0ooO0 / IIII . o00O0oo
 try :
  if 30 - 30: o0oO0 . o00O0oo / IIII
  Oo00o0OO0O00o = i1i1ii ( oo0o )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
  for O0Oooo in iII1ii1 :
   if 2 - 2: i1I111II1I % OOooOOo - Oooo0Ooo000
   try :
    if 79 - 79: OoooooooOO / o00O0oo . O0
    oOoO0Oo0 = O0Oooo
    if 7 - 7: iI + o0oO0
   except :
    pass
    if 32 - 32: iIii1I11I1II1 % OOooOOo / i11iIiiIii + IIII - o0000oOoOoO0o . O0ooOooooO
    if 86 - 86: i1IIi / o0oO0 * OOooOOo
  Oo00o0OO0O00o = i1i1ii ( oOoO0Oo0 )
  iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( Oo00o0OO0O00o )
  for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
   try :
    Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
    if 67 - 67: o00O0oo * o00O0oo / oO0o0ooO0 * OoooooooOO + OoOO0ooOOoo0O
   except :
    pass
 except :
  pass
  if 79 - 79: i1IIi
  if 1 - 1: oO0o0ooO0 / i1IIi
def O0oo0 ( ) :
 if 37 - 37: i11iIiiIii
 try :
  if 12 - 12: o00O0oo / o0oO0
  Oo00o0OO0O00o = i1i1ii ( I1III1111iIi )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
  for O0Oooo in iII1ii1 :
   if 5 - 5: OoooooooOO
   try :
    if 18 - 18: OOooOOo % OoooooooOO - O0ooOooooO . i11iIiiIii * ii11ii1ii % o0oO0
    Ii1I1 = O0Oooo
    if 98 - 98: i1I111II1I * iIii1I11I1II1 . o0oO0 * ii11ii1ii / o00O0oo + iI
   except :
    pass
    if 25 - 25: oO0o0ooO0
    if 19 - 19: OOooOOo % o0oO0 . i1I111II1I * iI
  Oo00o0OO0O00o = i1i1ii ( Ii1I1 )
  iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( Oo00o0OO0O00o )
  for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
   try :
    Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
    if 89 - 89: OoOO0ooOOoo0O . IIII
   except :
    pass
 except :
  pass
  if 7 - 7: oO0o0ooO0 % OoOO0ooOOoo0O - OOooOOo + ii11ii1ii
  if 70 - 70: II111iiii + Oooo0Ooo000 + i11iIiiIii - i1IIi / i1I111II1I
def iI1IIiiIIIII ( ) :
 if 43 - 43: O0ooOooooO + ii11ii1ii / OoooooooOO
 try :
  if 24 - 24: O0 + o0000oOoOoO0o * o0oO0 - Oooo0Ooo000
  Oo00o0OO0O00o = i1i1ii ( OooOo0oo0O0o00O )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
  for O0Oooo in iII1ii1 :
   if 10 - 10: i11iIiiIii
   try :
    if 21 - 21: OOooOOo / O0ooOooooO
    o00000oo00 = O0Oooo
    if 41 - 41: IIII - o0000oOoOoO0o + o0oO0
   except :
    pass
    if 15 - 15: O0oO / o0000oOoOoO0o + o0oO0
  Oo00o0OO0O00o = i1i1ii ( o00000oo00 )
  iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( Oo00o0OO0O00o )
  for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
   try :
    Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
    if 76 - 76: o0oO0 + OoooooooOO / IIII % OoOO / o00O0oo
   except :
    pass
 except :
  pass
  if 38 - 38: Oooo0Ooo000 . O0ooOooooO . OOooOOo * OoOO
  if 69 - 69: o0000oOoOoO0o % i11iIiiIii / o0oO0
def ooOOO00oOOooO ( ) :
 if 46 - 46: iIii1I11I1II1 . i11iIiiIii - OoOO0ooOOoo0O % O0 / II111iiii * i1IIi
 try :
  if 66 - 66: O0
  Oo00o0OO0O00o = i1i1ii ( IiIi1I1 )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
  for O0Oooo in iII1ii1 :
   if 52 - 52: OoOO * OoooooooOO
   try :
    if 12 - 12: O0 + i1I111II1I * i1IIi . OoOO
    o0OO0oooo = O0Oooo
    if 40 - 40: Oooo0Ooo000 - OoOO0ooOOoo0O * O0oO - i1I111II1I / OoOO0ooOOoo0O
   except :
    pass
    if 71 - 71: oO0o0ooO0 / OoooooooOO % i1I111II1I / OoOO0ooOOoo0O % Oooo0Ooo000
    if 19 - 19: Oooo0Ooo000 + i1I111II1I / oO0o0ooO0 / II111iiii
  Oo00o0OO0O00o = i1i1ii ( o0OO0oooo )
  iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( Oo00o0OO0O00o )
  for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
   try :
    Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
    if 92 - 92: i1IIi % iI + iI - iIii1I11I1II1 . o0oO0
   except :
    pass
 except :
  pass
  if 33 - 33: o0000oOoOoO0o / O0 + IIII
def o0Ooo0o0Oo ( ) :
 if 55 - 55: iIii1I11I1II1 * O0ooOooooO
 try :
  if 85 - 85: iIii1I11I1II1 . II111iiii
  Oo00o0OO0O00o = i1i1ii ( IIIIiii1IIii )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
  for O0Oooo in iII1ii1 :
   if 54 - 54: o0oO0 . OoooooooOO % ii11ii1ii
   try :
    if 22 - 22: IIII
    I1I11Iiii111 = O0Oooo
    if 38 - 38: OoOO . iI
   except :
    pass
  Oo00o0OO0O00o = i1i1ii ( I1I11Iiii111 )
  iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( Oo00o0OO0O00o )
  for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
   try :
    Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
    if 34 - 34: i1IIi % i1I111II1I
   except :
    pass
 except :
  pass
  if 80 - 80: OoooooooOO / iIii1I11I1II1 + o00O0oo / i1IIi / o0000oOoOoO0o
def oOoO ( ) :
 if 32 - 32: O0 + oO0o0ooO0 % ii11ii1ii
 try :
  if 7 - 7: o00O0oo / iI
  Oo00o0OO0O00o = i1i1ii ( ii1I1IIii11 )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
  for O0Oooo in iII1ii1 :
   if 11 - 11: i1I111II1I * iI / iI - IIII
   try :
    if 68 - 68: OOooOOo % i1I111II1I - i1I111II1I / OOooOOo + o00O0oo - ii11ii1ii
    o0oO0o00O = O0Oooo
    if 6 - 6: OoooooooOO / i11iIiiIii / Oooo0Ooo000
   except :
    pass
  Oo00o0OO0O00o = i1i1ii ( o0oO0o00O )
  iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( Oo00o0OO0O00o )
  for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
   try :
    Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
    if 60 - 60: OOooOOo % oO0o0ooO0 / o0000oOoOoO0o % oO0o0ooO0 * i11iIiiIii / O0ooOooooO
   except :
    pass
 except :
  pass
  if 34 - 34: Oooo0Ooo000 - IIII
def IIIiIi1iiI ( ) :
 if 15 - 15: o00O0oo . O0ooOooooO
 try :
  if 94 - 94: O0oO . OOooOOo
  Oo00o0OO0O00o = i1i1ii ( ooo00Ooo )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
  for O0Oooo in iII1ii1 :
   if 73 - 73: i1IIi / II111iiii
   try :
    if 45 - 45: o0oO0 / iI . OoooooooOO + OoOO
    O00oO000Oo0 = O0Oooo
    if 26 - 26: ii11ii1ii + O0 - iIii1I11I1II1
   except :
    pass
  Oo00o0OO0O00o = i1i1ii ( O00oO000Oo0 )
  iII1ii1 = re . compile ( I1iII1iIi1I ) . findall ( Oo00o0OO0O00o )
  for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii , Ooo00OoOOO , oo00 in iII1ii1 :
   try :
    Oo000ooOOO ( o0o0oOoOO0O , i1ii1II1ii , o00OooO0oo , id , iII111Ii , Ooo00OoOOO , oo00 )
    if 47 - 47: OoooooooOO
   except :
    pass
 except :
  pass
  if 2 - 2: OoOO0ooOOoo0O % Oooo0Ooo000 * ii11ii1ii * OoOO0ooOOoo0O
def Oo0OOo ( ) :
 if 44 - 44: O0oO * o0000oOoOoO0o
 try :
  if 49 - 49: IIII % O0oO * i11iIiiIii / oO0o0ooO0 % IIII
  Oo00o0OO0O00o = i1i1ii ( IIIIiIiIi1 )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
  for O0Oooo in iII1ii1 :
   if 70 - 70: OoOO0ooOOoo0O / II111iiii % iI - O0ooOooooO
   try :
    if 2 - 2: Oooo0Ooo000 - o00O0oo + o0000oOoOoO0o * OoOO / O0ooOooooO
    iIIiI11iI1Ii1 = O0Oooo
    if 94 - 94: iI / i11iIiiIii % O0
   except :
    pass
  Oo00o0OO0O00o = i1i1ii ( iIIiI11iI1Ii1 )
  iII1ii1 = re . compile ( i1I1ii11i1Iii ) . findall ( Oo00o0OO0O00o )
  for o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii in iII1ii1 :
   try :
    O0oO0oo0O ( o00OooO0oo , o0o0oOoOO0O , i1ii1II1ii )
    if 82 - 82: OoooooooOO . o0oO0
   except :
    pass
    if 26 - 26: oO0o0ooO0 + i1I111II1I - II111iiii . II111iiii + o00O0oo + OoOO0ooOOoo0O
 except :
  pass
  if 68 - 68: O0
  if 76 - 76: o00O0oo
  if 99 - 99: o0000oOoOoO0o
def O0oO0oo0O ( thumb , name , url ) :
 if 1 - 1: o0oO0 * OoOO0ooOOoo0O * OoOO + ii11ii1ii
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 if 90 - 90: Oooo0Ooo000 % ii11ii1ii - ii11ii1ii . iIii1I11I1II1 / IIII + O0oO
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   Ii1ii1IiIII ( name , url , '' , o00 , oo00 )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 89 - 89: oO0o0ooO0
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 87 - 87: O0ooOooooO % ii11ii1ii
   OOo000o ( name , url , 4 , OoOooOo0O , oo00 )
   if 37 - 37: O0ooOooooO
  else :
   if 33 - 33: OoOO - O0 - OoOO
   OOo000o ( name , url , 4 , OoOooOo0O , oo00 )
   if 94 - 94: i1I111II1I * O0oO * OoooooooOO / o0000oOoOoO0o . i1I111II1I - o0000oOoOoO0o
def I1I1iiii1IiI1i ( name , url , thumb , id , trailer ) :
 if 93 - 93: i1IIi % OoOO0ooOOoo0O / iIii1I11I1II1 * o0000oOoOoO0o . O0 % IIII
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 88 - 88: oO0o0ooO0 % ii11ii1ii - O0oO % oO0o0ooO0 + i1I111II1I - O0ooOooooO
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   Ii1ii1IiIII ( name , url , '' , o00 , oo00 )
 else :
  O00OOOoOoo0O = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
  if 23 - 23: O0
  name = '[COLOR %s]' % O00OOOoOoo0O + name + '[/COLOR]'
  if 9 - 9: O0oO * ii11ii1ii . iI * i11iIiiIii - O0
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   III1iII1I1ii = IiII1IiiIiI1 . getSetting ( 'selecton' )
   if III1iII1I1ii == 'true' :
    if 54 - 54: OOooOOo * IIII + o0000oOoOoO0o % i1IIi - o0000oOoOoO0o + OoOO0ooOOoo0O
    IIIIiI11Ii1i ( name , url , 1 , thumb , thumb , id , trailer )
    if 100 - 100: O0ooOooooO + O0oO + iI + O0ooOooooO / i1IIi
   else :
    if 74 - 74: O0 % OoooooooOO * ii11ii1ii + IIII * O0ooOooooO
    IIIIiI11Ii1i ( name , url , 130 , thumb , thumb , id , trailer )
    if 100 - 100: IIII + o0oO0 * o0000oOoOoO0o + II111iiii
  else :
   if 70 - 70: ii11ii1ii * iIii1I11I1II1
   if III1iII1I1ii == 'true' :
    if 76 - 76: O0ooOooooO % OoOO0ooOOoo0O % iIii1I11I1II1 . IIII
    IIIIiI11Ii1i ( name , url , 1 , thumb , thumb , id , trailer )
    if 30 - 30: i1IIi
   else :
    if 75 - 75: O0oO . IIII - iIii1I11I1II1 * OoOO * O0ooOooooO
    IIIIiI11Ii1i ( name , url , 130 , thumb , thumb , id , trailer )
    if 93 - 93: iI
def Oo000ooOOO ( name , url , thumb , id , trailer , description , fanart ) :
 if 18 - 18: iI
 if 66 - 66: oO0o0ooO0 * i11iIiiIii + OoOO0ooOOoo0O / IIII
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . strip ( )
 O00OOOoOoo0O = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
 fanart = fanart . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 name = '[COLOR %s]' % O00OOOoOoo0O + name + '[/COLOR]'
 if 96 - 96: IIII + IIII % i1I111II1I % IIII
 if 28 - 28: iIii1I11I1II1 + OoOO0ooOOoo0O . o0000oOoOoO0o % i11iIiiIii
 if 'tvg-logo' in thumb :
  thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  if III1iII1I1ii == 'true' :
   O00oO ( name , url , 1 , thumb , fanart , id , trailer , description )
  else :
   if 65 - 65: O0 - Oooo0Ooo000 . o0oO0
   O00oO ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 19 - 19: o00O0oo . O0ooOooooO - o0000oOoOoO0o + O0oO - o0oO0
 else :
  if 13 - 13: i1I111II1I * o00O0oo / o00O0oo / iIii1I11I1II1 % iIii1I11I1II1
  if III1iII1I1ii == 'true' :
   if 21 - 21: o00O0oo
   O00oO ( name , url , 1 , thumb , fanart , id , trailer , description )
   if 86 - 86: iI
  else :
   if 51 - 51: OoOO - i11iIiiIii * OOooOOo
   O00oO ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 95 - 95: IIII % o00O0oo + o0000oOoOoO0o % iI
   if 36 - 36: O0 / i1IIi % II111iiii / O0ooOooooO
def OOoOi1IiiI ( name , trailer ) :
 if 70 - 70: O0oO . IIII * ii11ii1ii / IIII
 if O0ii1ii1ii == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Realstream, Reproduciendo Trailer de: [COLOR green]" + name + "[/COLOR] ,5000)" )
  if 83 - 83: OoooooooOO + OoOO * oO0o0ooO0 . O0
  i1ii1II1ii = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  iiIIIi1i = i1ii1II1ii
  iIi1i1i1II11I = xbmcgui . ListItem ( name , trailer , path = iiIIIi1i )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iIi1i1i1II11I )
 else :
  i1ii1II1ii = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  iiIIIi1i = i1ii1II1ii
  iIi1i1i1II11I = xbmcgui . ListItem ( name , trailer , path = iiIIIi1i )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iIi1i1i1II11I )
  if 61 - 61: Oooo0Ooo000 / OOooOOo + iI % o00O0oo - OoOO0ooOOoo0O * iIii1I11I1II1
  if 1 - 1: iIii1I11I1II1 . O0oO + O0oO . iI
def o0o00OoO0 ( name , url ) :
 if 89 - 89: i1I111II1I / OoOO * O0 / O0oO . Oooo0Ooo000
 if O0ii1ii1ii == 'true' :
  if 17 - 17: O0oO
  try :
   if 56 - 56: iI * o0000oOoOoO0o + O0oO
   IIII1 = xbmcgui . DialogProgress ( )
   IIII1 . create ( 'Realstream:' , 'Iniciando ...' )
   IIII1 . update ( 30 , 'Realstream:' , 'Conectando al servidor ...' )
   xbmc . sleep ( 1000 )
   IIII1 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   IIII1 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   IIII1 . close ( )
   if 48 - 48: i1I111II1I * OoOO % Oooo0Ooo000 - O0oO
   iiIIIi1i = url
   iIi1i1i1II11I = xbmcgui . ListItem ( name , iII111Ii , path = iiIIIi1i )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iIi1i1i1II11I )
   if 72 - 72: i1IIi % iI % i1I111II1I % oO0o0ooO0 - oO0o0ooO0
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. ,3000)" )
  if 97 - 97: o0000oOoOoO0o * O0 / o0000oOoOoO0o * OoOO * ii11ii1ii
 else :
  if 38 - 38: Oooo0Ooo000
  try :
   if 25 - 25: iIii1I11I1II1 % II111iiii / O0oO / o00O0oo
   IIII1 = xbmcgui . DialogProgress ( )
   IIII1 . create ( 'Realstream:' , 'Iniciando ...' )
   IIII1 . update ( 30 , 'Realstream:' , 'Conectando al servidor ...' )
   xbmc . sleep ( 1000 )
   IIII1 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   IIII1 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   IIII1 . close ( )
   if 22 - 22: oO0o0ooO0 * O0ooOooooO
   iiIIIi1i = url
   iIi1i1i1II11I = xbmcgui . ListItem ( name , iII111Ii , path = iiIIIi1i )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iIi1i1i1II11I )
   if 4 - 4: OoOO0ooOOoo0O - oO0o0ooO0 + OOooOOo
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. ,3000)" )
  if 36 - 36: i1I111II1I
 return
 if 19 - 19: OoOO0ooOOoo0O . o0000oOoOoO0o . OoooooooOO
 if 13 - 13: IIII . ii11ii1ii / II111iiii
def iiI1iIII1ii ( trailer ) :
 if 5 - 5: Oooo0Ooo000 % OoooooooOO . OoOO0ooOOoo0O
 if 'https://www.youtube.com' in trailer :
  if 67 - 67: o00O0oo + o0oO0
  try :
   if 72 - 72: i1I111II1I % o0000oOoOoO0o
   import resolveurl
   if 93 - 93: iIii1I11I1II1 + i11iIiiIii . o0000oOoOoO0o . i1IIi % OOooOOo % iI
   oOo0OOoooO = urlresolver . HostedMediaFile ( i1ii1II1ii )
   IIII1 = xbmcgui . DialogProgress ( )
   IIII1 . create ( 'Realstream:' , 'Conectando al servidor ... ' )
   IIII1 . update ( 20 , 'Por favor, espere ...' )
   xbmc . sleep ( 500 )
   if 74 - 74: OoOO0ooOOoo0O / i1IIi % OoooooooOO
   if not oOo0OOoooO :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    return False
    if 52 - 52: i1I111II1I % iI
   try :
    if 25 - 25: O0oO / O0oO % OoooooooOO - o00O0oo * oO0o0ooO0
    IIII1 . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    OooOo000o0o = oOo0OOoooO . resolve ( )
    if not OooOo000o0o or not isinstance ( OooOo000o0o , basestring ) :
     try : iI1I1iII1i = OooOo000o0o . msg
     except : iI1I1iII1i = OooOo000o0o
     raise Exception ( iI1I1iII1i )
   except Exception as iI1IIIii :
    try : iI1I1iII1i = str ( iI1IIIii )
    except : iI1I1iII1i = OooOo000o0o
    IIII1 . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
    IIII1 . close ( )
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    if 23 - 23: i11iIiiIii
   IIII1 . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
   xbmc . sleep ( 500 )
   IIII1 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   IIII1 . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
   xbmc . sleep ( 500 )
   IIII1 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   IIII1 . close ( )
   if 100 - 100: oO0o0ooO0 + O0 . OOooOOo + i1IIi - OoOO0ooOOoo0O + o0000oOoOoO0o
   I1iIiI1IiIIII = xbmcgui . ListItem ( path = OooOo000o0o )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1iIiI1IiIIII )
   if 65 - 65: II111iiii / ii11ii1ii
  except :
   pass
   if 42 - 42: i11iIiiIii . O0
  else :
   if 75 - 75: Oooo0Ooo000 + iIii1I11I1II1
   i1ii1II1ii = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
   iiIIIi1i = i1ii1II1ii
   iIi1i1i1II11I = xbmcgui . ListItem ( trailer , path = iiIIIi1i )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iIi1i1i1II11I )
   return
   if 19 - 19: OOooOOo + i11iIiiIii . i1I111II1I - O0oO / o0oO0 + o0000oOoOoO0o
def II1i ( name , url ) :
 if 75 - 75: o00O0oo
 if '[Youtube]' in name :
  if 92 - 92: O0oO / O0 * OOooOOo - O0oO
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  iiIIIi1i = url
  iIi1i1i1II11I = xbmcgui . ListItem ( iII111Ii , path = iiIIIi1i )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iIi1i1i1II11I )
  if 99 - 99: i11iIiiIii % OoooooooOO
  if 56 - 56: i1I111II1I * Oooo0Ooo000
 else :
  if 98 - 98: O0oO + O0 * Oooo0Ooo000 + i11iIiiIii - IIII - iIii1I11I1II1
  import urlresolver
  from urlresolver import common
  if 5 - 5: IIII % ii11ii1ii % i1I111II1I % iI
  oOo0OOoooO = urlresolver . HostedMediaFile ( url )
  if 17 - 17: o0oO0 + II111iiii + OoooooooOO / IIII / i1I111II1I
  if not oOo0OOoooO :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 80 - 80: o0000oOoOoO0o % i1IIi / O0oO
   if 56 - 56: i1IIi . i11iIiiIii
  try :
   OooOo000o0o = oOo0OOoooO . resolve ( )
   if not OooOo000o0o or not isinstance ( OooOo000o0o , basestring ) :
    try : iI1I1iII1i = OooOo000o0o . msg
    except : iI1I1iII1i = url
    raise Exception ( iI1I1iII1i )
  except Exception as iI1IIIii :
   try : iI1I1iII1i = str ( iI1IIIii )
   except : iI1I1iII1i = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 15 - 15: II111iiii * oO0o0ooO0 % O0ooOooooO / i11iIiiIii - oO0o0ooO0 + ii11ii1ii
  O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if O0ii1ii1ii == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  I1iIiI1IiIIII = xbmcgui . ListItem ( path = OooOo000o0o )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1iIiI1IiIIII )
  if 9 - 9: O0oO - oO0o0ooO0 + O0 / O0ooOooooO % i1IIi
  if 97 - 97: o0000oOoOoO0o * iI
 return
 if 78 - 78: O0oO . IIII + oO0o0ooO0 * O0ooOooooO - i1IIi
def I1ii1I1iii1 ( name , url ) :
 if 19 - 19: oO0o0ooO0 % OoooooooOO . OoooooooOO
 import resolveurl
 if 40 - 40: O0 . Oooo0Ooo000 / iIii1I11I1II1 * o0000oOoOoO0o
 oOo0OOoooO = urlresolver . HostedMediaFile ( url )
 dp = xbmcgui . DialogProgress ( )
 dp . create ( 'Realstream:' , 'Conectando al servidor ... ' )
 dp . update ( 20 , 'Por favor, espere ...' )
 xbmc . sleep ( 500 )
 if 73 - 73: ii11ii1ii - O0ooOooooO . oO0o0ooO0 % i1IIi . O0
 if not oOo0OOoooO :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  return False
  if 15 - 15: iI . iIii1I11I1II1 * OOooOOo % O0oO
 try :
  if 21 - 21: OoOO - OOooOOo . OoooooooOO
  dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
  xbmc . sleep ( 500 )
  OooOo000o0o = oOo0OOoooO . resolve ( )
  if not OooOo000o0o or not isinstance ( OooOo000o0o , basestring ) :
   try : iI1I1iII1i = OooOo000o0o . msg
   except : iI1I1iII1i = OooOo000o0o
   raise Exception ( iI1I1iII1i )
 except Exception as iI1IIIii :
  try : iI1I1iII1i = str ( iI1IIIii )
  except : iI1I1iII1i = OooOo000o0o
  dp . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
  dp . close ( )
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  if 6 - 6: iIii1I11I1II1 - iIii1I11I1II1 % o0000oOoOoO0o / iIii1I11I1II1 * Oooo0Ooo000
 dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
 xbmc . sleep ( 500 )
 dp . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
 xbmc . sleep ( 500 )
 dp . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
 xbmc . sleep ( 500 )
 dp . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
 dp . close ( )
 O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
 if 3 - 3: IIII . i1I111II1I / ii11ii1ii
 if 89 - 89: OoooooooOO . iIii1I11I1II1 . ii11ii1ii * iIii1I11I1II1 - Oooo0Ooo000
 if '[Realstream]' or '[Mybox]' in name :
  restante = IiII1IiiIiI1 . getSetting ( 'restante' )
 elif restante == 'true' :
  dialog = xbmcgui . Dialog ( )
  ok = dialog . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
 I1iIiI1IiIIII = xbmcgui . ListItem ( path = OooOo000o0o )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1iIiI1IiIIII )
 if 92 - 92: OoooooooOO - o00O0oo - OoooooooOO % OOooOOo % OOooOOo % iIii1I11I1II1
def I1ii1I1iii1 ( name , url ) :
 if 92 - 92: O0ooOooooO * O0 % Oooo0Ooo000 . iIii1I11I1II1
 if 66 - 66: O0oO + o0oO0
 if 'https://www.rapidvideo.com/v/' in url :
  if 48 - 48: o00O0oo
  Oo00o0OO0O00o = i1i1ii ( url )
  iII1ii1 = re . compile ( 'rapidvideo' ) . findall ( Oo00o0OO0O00o )
  for url in iII1ii1 :
   if 96 - 96: iI . OoooooooOO
   if 39 - 39: IIII + OoOO
   try :
    O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
    if O0ii1ii1ii == 'true' :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    I1iIiI1IiIIII = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1iIiI1IiIIII )
    if 80 - 80: IIII % OoOO / OoOO0ooOOoo0O
   except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 54 - 54: ii11ii1ii % OoOO - IIII - O0oO
   if 71 - 71: iI . i11iIiiIii
 else :
  if 56 - 56: O0 * O0ooOooooO + O0ooOooooO * iIii1I11I1II1 / iI * Oooo0Ooo000
  import urlresolver
  from urlresolver import common
  if 25 - 25: iIii1I11I1II1 . O0oO * i11iIiiIii + ii11ii1ii * O0oO
  oOo0OOoooO = urlresolver . HostedMediaFile ( url )
  if 67 - 67: O0ooOooooO
  if not oOo0OOoooO :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 88 - 88: ii11ii1ii
   if 8 - 8: o00O0oo
  try :
   OooOo000o0o = oOo0OOoooO . resolve ( )
   if not OooOo000o0o or not isinstance ( OooOo000o0o , basestring ) :
    try : iI1I1iII1i = OooOo000o0o . msg
    except : iI1I1iII1i = url
    raise Exception ( iI1I1iII1i )
  except Exception as iI1IIIii :
   try : iI1I1iII1i = str ( iI1IIIii )
   except : iI1I1iII1i = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 82 - 82: OoooooooOO
  O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if O0ii1ii1ii == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  I1iIiI1IiIIII = xbmcgui . ListItem ( path = OooOo000o0o )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1iIiI1IiIIII )
  if 75 - 75: II111iiii % OOooOOo + IIII % OoooooooOO / i1I111II1I
 return
 if 4 - 4: i11iIiiIii - IIII % o00O0oo * Oooo0Ooo000 % o0000oOoOoO0o
 if 71 - 71: iI . iI - iIii1I11I1II1
 if 22 - 22: OoooooooOO / o00O0oo % O0ooOooooO * OoOO0ooOOoo0O
def Ii1IiiiI1ii ( name , url ) :
 if 55 - 55: o00O0oo
 OooOo000o0o = url
 O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
 if O0ii1ii1ii == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  I1iIiI1IiIIII = xbmcgui . ListItem ( path = OooOo000o0o )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1iIiI1IiIIII )
 else :
  I1iIiI1IiIIII = xbmcgui . ListItem ( path = OooOo000o0o )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1iIiI1IiIIII )
 return
 if 76 - 76: oO0o0ooO0 - i11iIiiIii
def II1ii1iI ( name , url ) :
 if 29 - 29: o0oO0 / iI % O0oO
 if 10 - 10: iIii1I11I1II1 % OoooooooOO % o00O0oo
 if '[Youtube]' in name :
  if 39 - 39: II111iiii * OoOO0ooOOoo0O . O0 * O0oO
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 89 - 89: o0oO0 - iI . O0oO - Oooo0Ooo000 - OOooOOo
  try :
   O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if O0ii1ii1ii == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    I1iIiI1IiIIII = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1iIiI1IiIIII )
    if 79 - 79: i1I111II1I + i1I111II1I + o0oO0
    if 39 - 39: O0 - OoooooooOO
    if 63 - 63: iIii1I11I1II1 % o0000oOoOoO0o * iI
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 79 - 79: O0
  if 32 - 32: II111iiii . O0 + o0oO0 / OoOO0ooOOoo0O / i1I111II1I / IIII
 else :
  if 15 - 15: o00O0oo
  import xbmcgui
  import urlresolver
  from urlresolver import common
  if 4 - 4: i1I111II1I + iIii1I11I1II1 * O0ooOooooO + ii11ii1ii * o0000oOoOoO0o % II111iiii
  oOo0OOoooO = urlresolver . HostedMediaFile ( url )
  if 88 - 88: oO0o0ooO0 - i1IIi % i11iIiiIii % II111iiii * OoooooooOO
  if not oOo0OOoooO :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 40 - 40: ii11ii1ii
  import resolveurl as urlresolver
  if 47 - 47: OoOO0ooOOoo0O
  oOo0OOoooO = urlresolver . HostedMediaFile ( url )
  if 65 - 65: O0 + Oooo0Ooo000 % o0oO0 * OOooOOo / iI / OoOO0ooOOoo0O
  if 71 - 71: i11iIiiIii / OoOO0ooOOoo0O . oO0o0ooO0
  if not oOo0OOoooO :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 33 - 33: oO0o0ooO0
  try :
   OooOo000o0o = oOo0OOoooO . resolve ( )
   if not OooOo000o0o or not isinstance ( OooOo000o0o , basestring ) :
    try : iI1I1iII1i = OooOo000o0o . msg
    except : iI1I1iII1i = url
    raise Exception ( iI1I1iII1i )
  except Exception as iI1IIIii :
   try : iI1I1iII1i = str ( iI1IIIii )
   except : iI1I1iII1i = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 39 - 39: OoOO + O0 + iI * II111iiii % O0 - O0
   if 41 - 41: i1I111II1I % o0000oOoOoO0o
   if 67 - 67: O0 % Oooo0Ooo000
  O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if O0ii1ii1ii == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 35 - 35: OOooOOo . OoOO0ooOOoo0O + OoooooooOO % ii11ii1ii % IIII
   if '[Realstream]' in name :
    if 39 - 39: o0oO0
    I1I1IiI1 = IiII1IiiIiI1 . getSetting ( 'restante' )
    if I1I1IiI1 == 'true' :
     oOo0000ooO = xbmcgui . Dialog ( )
     iiI11ii1111 = oOo0000ooO . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 15 - 15: iI . o0000oOoOoO0o + OoOO0ooOOoo0O . iIii1I11I1II1 % iI + O0
   I1iIiI1IiIIII = xbmcgui . ListItem ( path = OooOo000o0o )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1iIiI1IiIIII )
   if 22 - 22: o0000oOoOoO0o + ii11ii1ii . iI + o00O0oo * O0ooOooooO . i11iIiiIii
   if 90 - 90: IIII * OoOO0ooOOoo0O - ii11ii1ii + o0000oOoOoO0o
   if 53 - 53: OoooooooOO . OoooooooOO + o0000oOoOoO0o - O0ooOooooO + IIII
 return
 if 44 - 44: Oooo0Ooo000 - i1I111II1I
 if 100 - 100: oO0o0ooO0 . OoOO - o0oO0 + O0 * OoOO
 if 59 - 59: II111iiii
def iIiIi11I1iIii1i11 ( name , url ) :
 if 42 - 42: OoOO * i11iIiiIii
 if 16 - 16: O0ooOooooO % OOooOOo - iI
 if '[Youtube]' in name :
  if 100 - 100: OoooooooOO * oO0o0ooO0
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 83 - 83: iIii1I11I1II1 - iI - Oooo0Ooo000 / OoOO - O0
  try :
   O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if O0ii1ii1ii == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    I1iIiI1IiIIII = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1iIiI1IiIIII )
    if 81 - 81: o0oO0 - oO0o0ooO0 * o00O0oo / Oooo0Ooo000
    if 21 - 21: OoOO
    if 63 - 63: O0oO . O0 * O0oO + iIii1I11I1II1
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 46 - 46: i1IIi + II111iiii * i1IIi - o0oO0
 else :
  if 79 - 79: II111iiii - oO0o0ooO0 * o00O0oo - OoOO0ooOOoo0O . o00O0oo
  import resolveurl
  if 11 - 11: O0 * OoOO0ooOOoo0O
  oOo0OOoooO = urlresolver . HostedMediaFile ( url )
  if 37 - 37: OoOO0ooOOoo0O + O0 . O0 * ii11ii1ii % Oooo0Ooo000 / O0ooOooooO
  if 18 - 18: OoooooooOO
  if not oOo0OOoooO :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 57 - 57: iI . OoOO0ooOOoo0O * o0000oOoOoO0o - OoooooooOO
  try :
   OooOo000o0o = oOo0OOoooO . resolve ( )
   if not OooOo000o0o or not isinstance ( OooOo000o0o , basestring ) :
    try : iI1I1iII1i = OooOo000o0o . msg
    except : iI1I1iII1i = url
    raise Exception ( iI1I1iII1i )
  except Exception as iI1IIIii :
   try : iI1I1iII1i = str ( iI1IIIii )
   except : iI1I1iII1i = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 75 - 75: i11iIiiIii / o0000oOoOoO0o . i1I111II1I . i1IIi . i1IIi / O0oO
   if 94 - 94: iI + OOooOOo
   if 56 - 56: OoOO0ooOOoo0O % o0000oOoOoO0o
  O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if O0ii1ii1ii == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 40 - 40: IIII / i1I111II1I
   if 'uptostream.com' or 'uptobox.com' in url :
    if 29 - 29: o0oO0 - o0oO0 / iI
    I1I1IiI1 = IiII1IiiIiI1 . getSetting ( 'restante' )
    if I1I1IiI1 == 'true' :
     oOo0000ooO = xbmcgui . Dialog ( )
     iiI11ii1111 = oOo0000ooO . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 49 - 49: O0oO + oO0o0ooO0 % OoOO - ii11ii1ii - O0 - OoooooooOO
   I1iIiI1IiIIII = xbmcgui . ListItem ( path = OooOo000o0o )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1iIiI1IiIIII )
   if 4 - 4: II111iiii - oO0o0ooO0 % ii11ii1ii * i11iIiiIii
   if 18 - 18: ii11ii1ii % O0
   if 66 - 66: iIii1I11I1II1 % i11iIiiIii / OOooOOo
 return
 if 47 - 47: o00O0oo * oO0o0ooO0 + iIii1I11I1II1 - oO0o0ooO0 / i1I111II1I
def oO0ooo0O0Ooo ( name , url ) :
 if 33 - 33: II111iiii - i1I111II1I - iI
 if 92 - 92: OoOO * i1I111II1I
 if '[Youtube]' in name :
  if 92 - 92: oO0o0ooO0
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 7 - 7: O0ooOooooO
  try :
   O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if O0ii1ii1ii == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    I1iIiI1IiIIII = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1iIiI1IiIIII )
    if 73 - 73: OoOO % o00O0oo
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 32 - 32: IIII + O0ooOooooO + iIii1I11I1II1 * ii11ii1ii
 else :
  if 62 - 62: i11iIiiIii
  if 'https://team.com' in url :
   if 2 - 2: OOooOOo
   url = url . replace ( 'https://team.com' , 'https://verystream.com' )
   if 69 - 69: OoooooooOO / ii11ii1ii * Oooo0Ooo000
   if 99 - 99: II111iiii * iIii1I11I1II1 % O0 * oO0o0ooO0 / II111iiii % OoooooooOO
  if 'https://drive.com' in url :
   if 14 - 14: i1I111II1I . i1I111II1I % iI
   url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
   if 42 - 42: o0000oOoOoO0o . IIII - iI
  if 'https://vid.co' in url :
   if 33 - 33: II111iiii / O0 / i1I111II1I - O0oO - i1IIi
   url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
   if 8 - 8: i11iIiiIii . O0ooOooooO / iIii1I11I1II1 / o00O0oo / i1I111II1I - o0oO0
  if 'https://limited.to' in url :
   if 32 - 32: o0000oOoOoO0o . i1IIi * ii11ii1ii
   url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
   if 98 - 98: o0oO0 - II111iiii / OOooOOo . oO0o0ooO0 * i1I111II1I . O0oO
  import resolveurl
  if 25 - 25: i11iIiiIii / OoOO0ooOOoo0O - Oooo0Ooo000 / OoOO . o0000oOoOoO0o . o0000oOoOoO0o
  oOo0OOoooO = urlresolver . HostedMediaFile ( url )
  if 6 - 6: oO0o0ooO0 . O0oO
  if 43 - 43: o00O0oo + o0000oOoOoO0o
  if not oOo0OOoooO :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no encontrado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 50 - 50: oO0o0ooO0 % i1IIi * O0
  try :
   OooOo000o0o = oOo0OOoooO . resolve ( )
   if not OooOo000o0o or not isinstance ( OooOo000o0o , basestring ) :
    try : iI1I1iII1i = OooOo000o0o . msg
    except : iI1I1iII1i = url
    raise Exception ( iI1I1iII1i )
  except Exception as iI1IIIii :
   try : iI1I1iII1i = str ( iI1IIIii )
   except : iI1I1iII1i = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace borrado, o no encontrado. Prueba a reiniciar el router o poner una VPN.[/COLOR]  ,5000)" )
   return False
   if 4 - 4: iIii1I11I1II1 . i1IIi
   if 63 - 63: iIii1I11I1II1 + i1I111II1I % i1IIi / OOooOOo % II111iiii
   if 60 - 60: o0000oOoOoO0o . OoOO0ooOOoo0O % Oooo0Ooo000 / OOooOOo / O0
   O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if O0ii1ii1ii == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
    if 19 - 19: i11iIiiIii . OOooOOo + II111iiii / IIII . o00O0oo * iI
    if 'uptostream.com' or 'uptobox.com' in url :
     I1I1IiI1 = IiII1IiiIiI1 . getSetting ( 'restante' )
    elif I1I1IiI1 == 'true' :
     oOo0000ooO = xbmcgui . Dialog ( )
     iiI11ii1111 = oOo0000ooO . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 59 - 59: iIii1I11I1II1 / o00O0oo % iI
  I1iIiI1IiIIII = xbmcgui . ListItem ( path = OooOo000o0o )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1iIiI1IiIIII )
  if 84 - 84: iIii1I11I1II1 / OOooOOo . OoOO0ooOOoo0O % O0oO
 return
 if 99 - 99: ii11ii1ii + i11iIiiIii
 if 36 - 36: o0oO0 * Oooo0Ooo000 * iIii1I11I1II1 - O0oO % i11iIiiIii
def OoOo00O0o ( name , url ) :
 if 96 - 96: i1I111II1I * i1I111II1I % iI + o0000oOoOoO0o
 if 'mybox.com' in url :
  if 27 - 27: ii11ii1ii * iI + i11iIiiIii / OOooOOo - oO0o0ooO0
  url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
  if 44 - 44: o0oO0 * iI / OoOO0ooOOoo0O
  try :
   if 69 - 69: iI . IIII - OOooOOo
   Oo00o0OO0O00o = i1i1ii ( url )
   iII1ii1 = re . compile ( O0oO0 ) . findall ( Oo00o0OO0O00o )
   for url , Ii , IiIi in iII1ii1 :
    if 36 - 36: IIII * o0oO0
    Ii = Ii . replace ( '","res":"1080",' , '' ) . replace ( '","res":"720",' , '' ) . replace ( '","res":"480",' , '' ) . replace ( '","res":"360",' , '' )
    url = url . replace ( '\/' , '/' )
    url = url . replace ( ',"type":"video/mp4",' , ' ' )
    name = '[COLOR white]' + Ii + '[/COLOR] - [COLOR gold]' + IiIi + '[/COLOR]'
    if 16 - 16: II111iiii
    oooOO0OO0 = [ ]
    oooOO0OO0 . append ( '[COLOR orange]Real Stream: [/COLOR][COLOR gold]1. Mostrar mas info. [Reiniciar][/COLOR]' )
    oooOO0OO0 . append ( '[COLOR gold]2. Mostar otras calidades disponibles [/COLOR]' )
    oooOO0OO0 . append ( '[COLOR gold]3. Ver en: %s [/COLOR]' % name )
    if 10 - 10: OOooOOo / o00O0oo
    if 68 - 68: IIII - OoooooooOO
    IiIII = 'Seleccione una calidad e idioma:'
    oOo0000ooO = xbmcgui . Dialog ( )
    IiIi11I = oOo0000ooO . select ( IiIII , oooOO0OO0 )
    if 43 - 43: i11iIiiIii + iI - OoOO
    if 76 - 76: i1IIi / iIii1I11I1II1 - o00O0oo - II111iiii
    if 76 - 76: i11iIiiIii + i1I111II1I % OoOO0ooOOoo0O
    if IiIi11I == 0 :
     if 6 - 6: O0ooOooooO
     iiI11ii1111 = oOo0000ooO . ok ( "[COLOR darkpink]REALSTREAM:[/COLOR] " , "[COLOR gold]  Reiniciadas las opciones.  [/COLOR]" , "" )
     del oOo0000ooO
     return
     if 65 - 65: II111iiii . OOooOOo + O0
    elif IiIi11I == 1 :
     if 75 - 75: O0 % iIii1I11I1II1 / OoOO0ooOOoo0O % IIII / i1I111II1I
     pass
     if 31 - 31: i11iIiiIii * OoOO0ooOOoo0O
     del oOo0000ooO
     if 69 - 69: i11iIiiIii
     if 61 - 61: O0
    elif IiIi11I == 2 :
     if 21 - 21: OoOO % iIii1I11I1II1 . OoOO
     o0o00OoO0 ( name , url )
     if 99 - 99: o0000oOoOoO0o * IIII % oO0o0ooO0 * oO0o0ooO0 + OoooooooOO
     return
     if 82 - 82: O0oO / OoOO0ooOOoo0O - IIII / iI
  except :
   pass
   if 50 - 50: IIII + OoOO . i11iIiiIii + o00O0oo + i11iIiiIii
 elif 'uptostream.com' in url :
  if 31 - 31: oO0o0ooO0 * Oooo0Ooo000 . OoOO0ooOOoo0O * O0oO
  try :
   if 28 - 28: i1I111II1I + OOooOOo - ii11ii1ii % IIII . O0oO + OOooOOo
   Oo00o0OO0O00o = i1i1ii ( url )
   iII1ii1 = re . compile ( O0oO0 ) . findall ( Oo00o0OO0O00o )
   for url , Ii , IiIi in iII1ii1 :
    if 72 - 72: o0oO0 / ii11ii1ii / oO0o0ooO0 * OoOO0ooOOoo0O + IIII
    Ii = Ii . replace ( '","res":"1080",' , '' ) . replace ( '","res":"720",' , '' ) . replace ( '","res":"480",' , '' ) . replace ( '","res":"360",' , '' )
    url = url . replace ( '\/' , '/' )
    url = url . replace ( ',"type":"video/mp4",' , ' ' )
    name = '[COLOR white]Calidad: ' + Ii + '[/COLOR] [COLOR gold]Idioma: ' + IiIi + '[/COLOR]'
    if 58 - 58: o0000oOoOoO0o % OOooOOo . OOooOOo * OoOO - i1I111II1I . OoooooooOO
    oooOO0OO0 = [ ]
    oooOO0OO0 . append ( '[COLOR white]Reiniciar calidades disponibles[/COLOR]' )
    oooOO0OO0 . append ( '[COLOR white]Otras calidades e idiomas[/COLOR]' )
    oooOO0OO0 . append ( '[COLOR white]Ver en: %s ' % name )
    if 10 - 10: Oooo0Ooo000
    if 48 - 48: O0ooOooooO * i1IIi % OoooooooOO * o0oO0 * OoOO
    IiIII = 'Seleccione una calidad e idioma:'
    oOo0000ooO = xbmcgui . Dialog ( )
    IiIi11I = oOo0000ooO . select ( IiIII , oooOO0OO0 )
    if 7 - 7: O0ooOooooO . o0oO0 . O0ooOooooO - Oooo0Ooo000
    if 33 - 33: iI + OoooooooOO - OoOO / i1IIi / OoooooooOO
    if IiIi11I == 0 :
     if 82 - 82: o00O0oo / IIII - O0ooOooooO / ii11ii1ii * OoOO
     iiI11ii1111 = oOo0000ooO . ok ( "[COLOR darkpink]REALSTREAM:[/COLOR] " , "[COLOR gold]  Reiniciadas las opciones.  [/COLOR]" , "" )
     del oOo0000ooO
     return
     if 55 - 55: OoooooooOO
    elif IiIi11I == 1 :
     if 73 - 73: OoOO0ooOOoo0O - o00O0oo % ii11ii1ii + o00O0oo - O0 . OoOO
     pass
     if 38 - 38: O0
     del oOo0000ooO
     if 79 - 79: i1IIi . oO0o0ooO0
     if 34 - 34: Oooo0Ooo000 * II111iiii
     if 71 - 71: i1I111II1I
     if 97 - 97: o00O0oo
    elif IiIi11I == 2 :
     if 86 - 86: ii11ii1ii - IIII . OoOO0ooOOoo0O . II111iiii * OOooOOo . II111iiii
     o0o00OoO0 ( name , url )
     if 34 - 34: o0000oOoOoO0o . Oooo0Ooo000 % i1I111II1I - O0 / Oooo0Ooo000
     return
     if 91 - 91: i11iIiiIii % Oooo0Ooo000 * oO0o0ooO0 - o00O0oo . Oooo0Ooo000
  except :
   pass
 else :
  if 28 - 28: i11iIiiIii
  IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
  OO0Oooo0oOO0O = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  o00O0 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  oOOO = IiII1IiiIiI1 . getSetting ( 'key_ext' )
  Oo00o0OO0O00o = i1i1ii ( o00O0 )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
  for iIi1I1 in iII1ii1 :
   if 51 - 51: OOooOOo + iI * O0 . o0oO0
   try :
    if 82 - 82: IIII * o00O0oo % o0oO0 . IIII
    if 43 - 43: OoOO . iI * ii11ii1ii
    IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
    if 20 - 20: i1IIi . i1IIi - O0oO
    if 89 - 89: iI - O0oO . O0 % OoooooooOO . i11iIiiIii
    if IIIi1I1IIii1II == iIi1I1 :
     if 35 - 35: II111iiii / OoOO0ooOOoo0O - O0 . II111iiii
     if 55 - 55: ii11ii1ii % i1IIi * O0oO
     if 'https://team.com' in url :
      if 95 - 95: IIII / II111iiii - o0000oOoOoO0o % Oooo0Ooo000 . O0oO
      url = url . replace ( 'https://team.com' , 'https://verystream.com' )
      if 63 - 63: iIii1I11I1II1 / iI
     if 'https://mybox.com' in url :
      if 24 - 24: ii11ii1ii / iIii1I11I1II1 % IIII * OoOO0ooOOoo0O - iIii1I11I1II1
      url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
      if 50 - 50: II111iiii
      if 39 - 39: II111iiii . OoOO0ooOOoo0O - ii11ii1ii * i1IIi . OoooooooOO
     if 'https://vidcloud.co/' in url :
      if 44 - 44: OOooOOo
      url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
      if 55 - 55: oO0o0ooO0 . Oooo0Ooo000 * Oooo0Ooo000
     if 'https://gounlimited.to' in url :
      if 82 - 82: OOooOOo % OoOO % O0oO + O0oO
      url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
      if 6 - 6: ii11ii1ii
     if 'https://drive.com' in url :
      if 73 - 73: Oooo0Ooo000 * o00O0oo + o0000oOoOoO0o - ii11ii1ii . O0oO
      url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
      if 93 - 93: i11iIiiIii
      if 80 - 80: i1IIi . OOooOOo - oO0o0ooO0 + IIII + O0ooOooooO % oO0o0ooO0
     import resolveurl
     if 13 - 13: II111iiii / OoOO0ooOOoo0O / OoOO0ooOOoo0O + iI
     oOo0OOoooO = urlresolver . HostedMediaFile ( url )
     if 49 - 49: O0 / II111iiii * OOooOOo - OoooooooOO . II111iiii % i1I111II1I
     if not oOo0OOoooO :
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
      return False
      if 13 - 13: oO0o0ooO0 . iIii1I11I1II1 . IIII . i1I111II1I
     try :
      if 58 - 58: O0oO
      IIII1 = xbmcgui . DialogProgress ( )
      IIII1 . create ( 'Realstream:' , 'Iniciando ...' )
      IIII1 . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
      xbmc . sleep ( 1000 )
      if 7 - 7: II111iiii / i1I111II1I % O0oO + OOooOOo - O0
      OooOo000o0o = oOo0OOoooO . resolve ( )
      if not OooOo000o0o or not isinstance ( OooOo000o0o , basestring ) :
       if 45 - 45: OOooOOo / O0ooOooooO + oO0o0ooO0 + i1I111II1I
       try : iI1I1iII1i = OooOo000o0o . msg
       except : iI1I1iII1i = url
       raise Exception ( iI1I1iII1i )
       if 15 - 15: OOooOOo % OoOO
     except Exception as iI1IIIii :
      try : iI1I1iII1i = str ( iI1IIIii )
      except : iI1I1iII1i = url
      if 66 - 66: oO0o0ooO0 * i11iIiiIii . Oooo0Ooo000
      if 92 - 92: oO0o0ooO0
      if 81 - 81: o0000oOoOoO0o % OOooOOo - O0ooOooooO / i11iIiiIii
      for ooo0oOOOO00Oo in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       Ii1iii1 = 1
       IIII1 . update ( 45 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % ooo0oOOOO00Oo )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5  Puede cancelar cuando desee o esperar...,  1000)" % Ii1iii1 )
       IIII1 . close ( )
       if 37 - 37: iIii1I11I1II1 % O0oO / i1I111II1I
      for ooo0oOOOO00Oo in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       Ii1iii1 = 2
       IIII1 . update ( 48 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % ooo0oOOOO00Oo )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % Ii1iii1 )
       IIII1 . close ( )
      for ooo0oOOOO00Oo in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       Ii1iii1 = 3
       IIII1 . update ( 50 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % ooo0oOOOO00Oo )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % Ii1iii1 )
       IIII1 . close ( )
      for ooo0oOOOO00Oo in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       Ii1iii1 = 4
       IIII1 . update ( 53 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % ooo0oOOOO00Oo )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % Ii1iii1 )
       IIII1 . close ( )
      for ooo0oOOOO00Oo in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       Ii1iii1 = 5
       IIII1 . update ( 55 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % ooo0oOOOO00Oo )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % Ii1iii1 )
       IIII1 . close ( )
       if 37 - 37: Oooo0Ooo000 - oO0o0ooO0 - OoOO
      if IIII1 . iscanceled ( ) :
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Cancelando !! , 2000)" )
       IIII1 . close ( )
       break
       if 42 - 42: iIii1I11I1II1 % o0oO0 - o00O0oo + iIii1I11I1II1
       if 27 - 27: O0 / OoOO
       if 99 - 99: o0oO0 - i1I111II1I * iIii1I11I1II1 . II111iiii
     IIII1 . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
     xbmc . sleep ( 500 )
     IIII1 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
     xbmc . sleep ( 1000 )
     IIII1 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
     IIII1 . close ( )
     O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
     I1iIiI1IiIIII = xbmcgui . ListItem ( path = OooOo000o0o )
     xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1iIiI1IiIIII )
     if 56 - 56: iIii1I11I1II1 % OoOO . iI % i1I111II1I . Oooo0Ooo000 * ii11ii1ii
     if 41 - 41: iIii1I11I1II1 % i1I111II1I * oO0o0ooO0 - iI
    else :
     if 5 - 5: OoOO + OoOO + II111iiii * iIii1I11I1II1 + OoooooooOO
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold] El addon no ha podido conectar al servidor.[/COLOR]" )
     return False
     if 77 - 77: O0 * o00O0oo * oO0o0ooO0 + OoOO + o00O0oo - Oooo0Ooo000
   except :
    pass
    if 10 - 10: o00O0oo + i1I111II1I
 return
 if 58 - 58: OOooOOo + OoooooooOO / O0ooOooooO . iI % o0000oOoOoO0o / o00O0oo
 if 62 - 62: II111iiii
 if 12 - 12: i1I111II1I + II111iiii
 if 92 - 92: Oooo0Ooo000 % iIii1I11I1II1 - O0ooOooooO / i11iIiiIii % iI * o0000oOoOoO0o
def ooo0O0O0oo0 ( ) :
 if 85 - 85: II111iiii + iI * O0oO
 i1ooOO00o0 = [ ]
 Ii1I1iIiiI1 = sys . argv [ 2 ]
 if len ( Ii1I1iIiiI1 ) >= 2 :
  o00i111iiIiiIiI = sys . argv [ 2 ]
  OOooooO = o00i111iiIiiIiI . replace ( '?' , '' )
  if ( o00i111iiIiiIiI [ len ( o00i111iiIiiIiI ) - 1 ] == '/' ) :
   o00i111iiIiiIiI = o00i111iiIiiIiI [ 0 : len ( o00i111iiIiiIiI ) - 2 ]
  oOoo00 = OOooooO . split ( '&' )
  i1ooOO00o0 = { }
  for ooo0oOOOO00Oo in range ( len ( oOoo00 ) ) :
   IIiIi = { }
   IIiIi = oOoo00 [ ooo0oOOOO00Oo ] . split ( '=' )
   if ( len ( IIiIi ) ) == 2 :
    i1ooOO00o0 [ IIiIi [ 0 ] ] = IIiIi [ 1 ]
 return i1ooOO00o0
 if 12 - 12: o0oO0 % O0ooOooooO + OoOO + II111iiii / o0000oOoOoO0o
 if 89 - 89: o0oO0 . OOooOOo / OoOO + Oooo0Ooo000 + II111iiii
def ooOOooO0OoO ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  import urlresolver
  xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
  if 2 - 2: O0 % Oooo0Ooo000 % o00O0oo % o0000oOoOoO0o - ii11ii1ii
def i1i11ii1 ( ) :
 oOo0000ooO = xbmcgui . Dialog ( )
 list = (
 o0iiii1ii ,
 Ii1iii11I
 )
 if 2 - 2: OoooooooOO - o0oO0 % oO0o0ooO0 / OOooOOo / o0000oOoOoO0o
 iiII = oOo0000ooO . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=%s]Accede a themoviedb.com[/COLOR]' % iIIIi1 ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 30 - 30: iI
 if iiII :
  if 57 - 57: o0000oOoOoO0o * i11iIiiIii / OoOO0ooOOoo0O
  if iiII < 0 :
   return
  iii1IiII = list [ iiII - 2 ]
  return iii1IiII ( )
 else :
  iii1IiII = list [ iiII ]
  return iii1IiII ( )
 return
 if 65 - 65: iI % O0
def IiiII1I ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 24 - 24: OOooOOo / OoooooooOO + o00O0oo / i11iIiiIii + IIII
OoOo0O00 = IiiII1I ( )
if 9 - 9: IIII
def o0iiii1ii ( ) :
 if OoOo0O00 == 'android' :
  i1II11Iii1I = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  i1II11Iii1I = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 38 - 38: O0oO . OoOO . i11iIiiIii * OoooooooOO + O0ooOooooO
  if 49 - 49: ii11ii1ii - OoOO / Oooo0Ooo000 / o0000oOoOoO0o % oO0o0ooO0
def Ii1iii11I ( ) :
 if 38 - 38: o0000oOoOoO0o . oO0o0ooO0 / o0000oOoOoO0o % II111iiii
 main ( )
 if 47 - 47: O0oO * iIii1I11I1II1 * O0ooOooooO - OoOO . O0 . iI
 if 32 - 32: o0000oOoOoO0o % OOooOOo
 if 7 - 7: ii11ii1ii . i1IIi - oO0o0ooO0
def o0OoOOoOOoo ( ) :
 oOo0000ooO = xbmcgui . Dialog ( )
 oo0O0 = (
 Ii111Ii11 ,
 Ii1
 )
 if 33 - 33: o0000oOoOoO0o . IIII + o0000oOoOoO0o / o00O0oo . ii11ii1ii + OoOO0ooOOoo0O
 iiII = oOo0000ooO . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 32 - 32: i1I111II1I - iI * O0ooOooooO * O0oO
 if iiII :
  if 84 - 84: o0oO0 + o00O0oo % OOooOOo + i11iIiiIii
  if iiII < 0 :
   return
  iii1IiII = oo0O0 [ iiII - 2 ]
  return iii1IiII ( )
 else :
  iii1IiII = oo0O0 [ iiII ]
  return iii1IiII ( )
 return
 if 37 - 37: O0oO % o00O0oo / iI
def IiiII1I ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 94 - 94: O0oO / OoOO . o0000oOoOoO0o
OoOo0O00 = IiiII1I ( )
if 1 - 1: ii11ii1ii . II111iiii
def Ii111Ii11 ( ) :
 if OoOo0O00 == 'android' :
  i1II11Iii1I = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  i1II11Iii1I = webbrowser . open ( 'https://olpair.com/' )
  if 93 - 93: II111iiii . i11iIiiIii + II111iiii % oO0o0ooO0
  if 98 - 98: Oooo0Ooo000 * oO0o0ooO0 * OoOO0ooOOoo0O + o0oO0 * O0ooOooooO
def Ii1 ( ) :
 if 4 - 4: i1I111II1I
 main ( )
 if 16 - 16: iIii1I11I1II1 * O0ooOooooO + oO0o0ooO0 . O0 . o0000oOoOoO0o
 if 99 - 99: i11iIiiIii - O0ooOooooO
def o0O0O0O00o ( name , url , id , trailer ) :
 oOo0000ooO = xbmcgui . Dialog ( )
 oo0O0 = (
 OoOooOo00o ,
 iI1IIi ,
 II11 ,
 i1i11ii1 ,
 oo0o0O
 )
 if 91 - 91: iIii1I11I1II1 % O0
 iiII = oOo0000ooO . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % iIIIi1 ,

 '[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % iIIIi1 ,

 '[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % iIIIi1 ,

 '[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % iIIIi1 ,

 '[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % iIIIi1 ] )
 if 71 - 71: OOooOOo . i1IIi
 if iiII :
  if 19 - 19: II111iiii / II111iiii % o00O0oo + oO0o0ooO0 + oO0o0ooO0 + O0ooOooooO
  if iiII < 0 :
   return
  iii1IiII = oo0O0 [ iiII - 5 ]
  return iii1IiII ( )
 else :
  iii1IiII = oo0O0 [ iiII ]
  return iii1IiII ( )
 return
 if 4 - 4: o0000oOoOoO0o + O0oO / O0ooOooooO + i1IIi % o0000oOoOoO0o % O0ooOooooO
 if 80 - 80: o0oO0
 if 26 - 26: iIii1I11I1II1 . OoooooooOO - iIii1I11I1II1
def OoOooOo00o ( ) :
 if 59 - 59: o00O0oo + O0oO . oO0o0ooO0
 OoOo00O0o ( o0o0oOoOO0O , i1ii1II1ii )
 if 87 - 87: OoOO
def iI1IIi ( ) :
 if 34 - 34: Oooo0Ooo000 . OoOO0ooOOoo0O / i11iIiiIii / O0ooOooooO
 OOoOi1IiiI ( o0o0oOoOO0O , iII111Ii )
 if 46 - 46: ii11ii1ii + II111iiii * OOooOOo + IIII
def II11 ( ) :
 if 31 - 31: o0oO0 * o0000oOoOoO0o * o0oO0 + OoOO * o0000oOoOoO0o . Oooo0Ooo000
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  Oo00oo00o00Oo = id
  if 1 - 1: i1I111II1I
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % Oo00oo00o00Oo )
  if 31 - 31: i1IIi
 if O0ii1ii1ii == 'true' :
  if 21 - 21: i1IIi
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + o0o0oOoOO0O + "[/COLOR] ,5000)" )
  if 69 - 69: OoOO0ooOOoo0O + OoOO0ooOOoo0O + IIII % IIII * O0oO % o0oO0
def ii1111IIiI1 ( ) :
 if 59 - 59: o0oO0 - ii11ii1ii
 i1i11ii1 ( )
 if 34 - 34: o0oO0 - oO0o0ooO0 * OoooooooOO . OoOO / OOooOOo
def oo0o0O ( ) :
 if 66 - 66: ii11ii1ii / i11iIiiIii % iI
 i1I1II1iIIi11 ( )
def Ii1ii1IiIII ( name , url , mode , iconimage , fanart ) :
 if 43 - 43: IIII
 IiiIIIiI1ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 iiI11ii1111 = True
 oo0OOoOoo0O0O = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 oo0OOoOoo0O0O . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 oo0OOoOoo0O0O . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  IiiIIIiI1ii = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  iiI11ii1111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IiiIIIiI1ii , listitem = oo0OOoOoo0O0O , isFolder = True )
  return iiI11ii1111
 iiI11ii1111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IiiIIIiI1ii , listitem = oo0OOoOoo0O0O , isFolder = True )
 return iiI11ii1111
 if 84 - 84: IIII . i1I111II1I . O0ooOooooO
def oOooO0 ( name , url , mode , iconimage , fanart , description ) :
 if 2 - 2: ii11ii1ii - OoOO0ooOOoo0O
 IiiIIIiI1ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 iiI11ii1111 = True
 oo0OOoOoo0O0O = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 oo0OOoOoo0O0O . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 oo0OOoOoo0O0O . setProperty ( 'fanart_image' , fanart )
 iiI11ii1111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IiiIIIiI1ii , listitem = oo0OOoOoo0O0O , isFolder = True )
 return iiI11ii1111
 if 49 - 49: o0oO0 + II111iiii / oO0o0ooO0 - OoOO0ooOOoo0O % OoOO0ooOOoo0O + OOooOOo
def o0OO0oO0Oo0 ( name , url , mode , iconimage ) :
 if 73 - 73: II111iiii . OoOO0ooOOoo0O . ii11ii1ii
 IiiIIIiI1ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 iiI11ii1111 = True
 oo0OOoOoo0O0O = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 oo0OOoOoo0O0O . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 oo0OOoOoo0O0O . setProperty ( 'fanart_image' , oo00 )
 iiI11ii1111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IiiIIIiI1ii , listitem = oo0OOoOoo0O0O , isFolder = True )
 return iiI11ii1111
 if 89 - 89: OOooOOo / O0ooOooooO / OoooooooOO - i11iIiiIii + OOooOOo
 if 64 - 64: i11iIiiIii + i1IIi % O0 . O0oO
def IIIIiI11Ii1i ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 64 - 64: iI / i1IIi % O0ooOooooO
 ooOOoooooo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 84 - 84: OoOO0ooOOoo0O - ii11ii1ii . iI . i1I111II1I - ii11ii1ii
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 o0Oo0oO00Oooo = [ ]
 if 31 - 31: i1IIi * ii11ii1ii % o0oO0 + OoOO
 o0Oo0oO00Oooo . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 IiiIIIiI1ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 oo0OOoOoo0O0O = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 oo0OOoOoo0O0O . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 oo0OOoOoo0O0O . setProperty ( 'fanart_image' , fanart )
 oo0OOoOoo0O0O . setProperty ( 'IsPlayable' , 'true' )
 if 75 - 75: IIII / Oooo0Ooo000 - II111iiii % i11iIiiIii + OoOO
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  o0Oo0oO00Oooo . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 13 - 13: iI - OOooOOo
  oo0OOoOoo0O0O . addContextMenuItems ( o0Oo0oO00Oooo , replaceItems = True )
 iiI11ii1111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IiiIIIiI1ii , listitem = oo0OOoOoo0O0O )
 return iiI11ii1111
 if 23 - 23: OOooOOo
 if 7 - 7: O0ooOooooO % o00O0oo
def O00oO ( name , url , mode , iconimage , fanart , id , trailer , description ) :
 if 64 - 64: Oooo0Ooo000 + i11iIiiIii
 ooOOoooooo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 35 - 35: OoOO0ooOOoo0O + i1IIi % IIII
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 o0Oo0oO00Oooo = [ ]
 if 68 - 68: i1I111II1I . iI
 o0Oo0oO00Oooo . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 IiiIIIiI1ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 oo0OOoOoo0O0O = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 oo0OOoOoo0O0O . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 oo0OOoOoo0O0O . setProperty ( 'fanart_image' , fanart )
 oo0OOoOoo0O0O . setProperty ( 'IsPlayable' , 'true' )
 if 64 - 64: i1IIi + ii11ii1ii * OOooOOo / IIII
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  o0Oo0oO00Oooo . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 3 - 3: ii11ii1ii / iI + iI . o00O0oo
  oo0OOoOoo0O0O . addContextMenuItems ( o0Oo0oO00Oooo , replaceItems = True )
 iiI11ii1111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IiiIIIiI1ii , listitem = oo0OOoOoo0O0O )
 return iiI11ii1111
 if 50 - 50: iIii1I11I1II1 * oO0o0ooO0
def OOo000o ( name , url , mode , iconimage , fanart ) :
 if 85 - 85: i1IIi
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 100 - 100: OoooooooOO / O0oO % OoOO + o0oO0
 IiiIIIiI1ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 oo0OOoOoo0O0O = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 oo0OOoOoo0O0O . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 oo0OOoOoo0O0O . setProperty ( 'fanart_image' , fanart )
 oo0OOoOoo0O0O . setProperty ( 'IsPlayable' , 'true' )
 iiI11ii1111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IiiIIIiI1ii , listitem = oo0OOoOoo0O0O )
 return iiI11ii1111
 if 42 - 42: ii11ii1ii / i1I111II1I . o0oO0 * OOooOOo
def oOO0O0ooOOOo ( name , url , mode , iconimage ) :
 if 91 - 91: iI - oO0o0ooO0 + oO0o0ooO0
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 14 - 14: o00O0oo * Oooo0Ooo000 % i1IIi / o00O0oo
 IiiIIIiI1ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 oo0OOoOoo0O0O = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 oo0OOoOoo0O0O . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 oo0OOoOoo0O0O . setProperty ( 'fanart_image' , oo00 )
 oo0OOoOoo0O0O . setProperty ( 'IsPlayable' , 'true' )
 iiI11ii1111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IiiIIIiI1ii , listitem = oo0OOoOoo0O0O )
 return iiI11ii1111
 if 48 - 48: ii11ii1ii
def OO00oO0o0 ( name , url , mode , iconimage ) :
 IiiIIIiI1ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 iiI11ii1111 = True
 oo0OOoOoo0O0O = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iiI11ii1111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IiiIIIiI1ii , listitem = oo0OOoOoo0O0O , isFolder = True )
 return iiI11ii1111
 if 93 - 93: i1I111II1I / i1IIi
def i111IiIi1 ( ) :
 if 16 - 16: i11iIiiIii * IIII . i1I111II1I
 if 100 - 100: OoOO . O0oO / o0oO0 . o0000oOoOoO0o - OoOO0ooOOoo0O . O0oO
 if 30 - 30: o0oO0 % O0oO + o0000oOoOoO0o
 I111i1i1111 = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 I111i1i1111 . doModal ( )
 if ( I111i1i1111 . isConfirmed ( ) ) :
  if 65 - 65: iIii1I11I1II1 . O0ooOooooO / o0oO0
  iIi1i1iIi1iI = urllib . quote_plus ( I111i1i1111 . getText ( ) ) . replace ( '+' , ' ' )
  if 12 - 12: OOooOOo + Oooo0Ooo000
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 80 - 80: oO0o0ooO0 . O0
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % iIi1i1iIi1iI )
    if 90 - 90: II111iiii / OoOO / o0oO0
    if O0ii1ii1ii == 'true' :
     if 70 - 70: o0oO0 - II111iiii . ii11ii1ii / ii11ii1ii
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + o0o0oOoOO0O + "[/COLOR] ,10000)" )
     if 30 - 30: oO0o0ooO0 . OoOO + O0oO / iIii1I11I1II1 % ii11ii1ii / oO0o0ooO0
   except :
    if 3 - 3: o00O0oo / II111iiii
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 73 - 73: OoOO * OoooooooOO - OoooooooOO + OOooOOo * ii11ii1ii
o00i111iiIiiIiI = ooo0O0O0oo0 ( )
i1ii1II1ii = None
o0o0oOoOO0O = None
oOo0 = None
OoOooOo0O = None
id = None
iII111Ii = None
if 2 - 2: OOooOOo + II111iiii / o0oO0 % ii11ii1ii - Oooo0Ooo000 + Oooo0Ooo000
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 84 - 84: o0000oOoOoO0o % i1IIi / ii11ii1ii - OOooOOo . o00O0oo . o0000oOoOoO0o
try :
 i1ii1II1ii = urllib . unquote_plus ( o00i111iiIiiIiI [ "url" ] )
except :
 pass
try :
 o0o0oOoOO0O = urllib . unquote_plus ( o00i111iiIiiIiI [ "name" ] )
except :
 pass
try :
 oOo0 = int ( o00i111iiIiiIiI [ "mode" ] )
except :
 pass
try :
 OoOooOo0O = urllib . unquote_plus ( o00i111iiIiiIiI [ "iconimage" ] )
except :
 pass
try :
 id = int ( o00i111iiIiiIiI [ "id" ] )
except :
 pass
try :
 iII111Ii = urllib . unquote_plus ( o00i111iiIiiIiI [ "trailer" ] )
except :
 pass
 if 75 - 75: O0 * i1IIi - O0oO / IIII % IIII / OoOO0ooOOoo0O
 if 5 - 5: O0 - O0ooOooooO / Oooo0Ooo000 . o0000oOoOoO0o
print "Mode: " + str ( oOo0 )
print "URL: " + str ( i1ii1II1ii )
print "Name: " + str ( o0o0oOoOO0O )
print "iconimage: " + str ( OoOooOo0O )
print "id: " + str ( id )
print "trailer: " + str ( iII111Ii )
if 7 - 7: o00O0oo - OoOO0ooOOoo0O
if 54 - 54: oO0o0ooO0 / iIii1I11I1II1 / OoooooooOO . i1IIi - OoOO0ooOOoo0O
def oO0 ( ) :
 if 57 - 57: iIii1I11I1II1 * o0oO0 * O0ooOooooO / oO0o0ooO0
 try :
  if 46 - 46: o0oO0
  oOO0 = i1i1ii ( oO0 )
  iII1ii1 = re . compile ( OOOoo0OO ) . findall ( oOO0 )
  for iiIii1I in iII1ii1 :
   if 30 - 30: II111iiii / OOooOOo - iI + OoOO0ooOOoo0O * iI / OoOO0ooOOoo0O
   if iiIii1I == 'si' :
    if 17 - 17: OoOO
    import urlresolver
    from urlresolver import common
    import random
    from random import choice
    IIIi11i = xbmc . Player ( )
    Oo0O0O0ooO0O = [ 'gtG1Y3_34ug' , '3d_ACcf0rDc' , 'AKpPeLAMY9I' , 'sVBa5hNZFHM' , '5ZCVhFmbAY0' ]
    oooOOoo0 = random . choice ( Oo0O0O0ooO0O )
    i1ii1II1ii = 'https://www.youtube.com/watch?v=%s' % oooOOoo0
    i1ii1II1ii = urlresolver . HostedMediaFile ( i1ii1II1ii ) . resolve ( )
    IIIi11i . play ( i1ii1II1ii )
    if 79 - 79: OoooooooOO - iI * o0oO0 - II111iiii % OoOO0ooOOoo0O * i1I111II1I
    iI1III == 'false'
    if 42 - 42: iI + O0ooOooooO + o0oO0 * O0oO . i1IIi
   else :
    if 72 - 72: OOooOOo + o0oO0
    iI1III == 'false'
    if 33 - 33: i1IIi / i1I111II1I - i1IIi . OOooOOo
    return False
    if 48 - 48: iI + IIII . Oooo0Ooo000 % II111iiii + oO0o0ooO0
 except :
  pass
  if 38 - 38: oO0o0ooO0
  if 28 - 28: iIii1I11I1II1 * O0oO . OOooOOo
  if 78 - 78: OoooooooOO . OoooooooOO / O0
if oOo0 == None or i1ii1II1ii == None or len ( i1ii1II1ii ) < 1 :
 if 25 - 25: II111iiii % II111iiii - o0oO0 . O0
 if 79 - 79: i1I111II1I / OoOO * OoooooooOO * OoOO0ooOOoo0O + OOooOOo
 IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 OO0Oooo0oOO0O = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 o00O0 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 oOOO = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 Oo00o0OO0O00o = i1i1ii ( o00O0 )
 iII1ii1 = re . compile ( OOOoo0OO ) . findall ( Oo00o0OO0O00o )
 for iIi1I1 in iII1ii1 :
  if 68 - 68: O0oO / iIii1I11I1II1 . ii11ii1ii + i11iIiiIii + o0000oOoOoO0o
  try :
   if 92 - 92: OoOO . o0000oOoOoO0o . o0oO0 % OoOO0ooOOoo0O
   if 58 - 58: o00O0oo % o0oO0 * o0oO0 - O0ooOooooO
   IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 9 - 9: iI - o0oO0 % II111iiii + i1I111II1I + IIII % O0
   if 65 - 65: IIII - OoOO % i11iIiiIii
   if IIIi1I1IIii1II == iIi1I1 :
    if 58 - 58: O0ooOooooO
    i1I1II1iIIi11 ( )
    OoO0ooO ( )
    if 2 - 2: II111iiii + i1IIi
    iI1III = IiII1IiiIiI1 . getSetting ( 'videos_event' )
    if iI1III == 'true' :
     xbmc . sleep ( 3000 )
     oO0 ( )
     if 68 - 68: IIII + o0oO0
   else :
    if 58 - 58: i1I111II1I * o0oO0 . i1IIi
    iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
    Ii1ii1IiIII ( '[COLOR %s]Video tutoriales[/COLOR]' % iIIIi1 , IIIII11I1IiI , 125 , O0OOO0OOoO0O , oo00 )
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Por favor compruebe los ajustes de realstream.[/COLOR]" , "[COLOR white] Desde la seccion Tutoriales puede sacarle mayor partido a su Realstream, tambien puede configurarlo a su gusto. [/COLOR]" , "[COLOR gold]El addon no esta activado o bien configurado.[/COLOR]" )
    if 19 - 19: oO0o0ooO0
  except :
   pass
   if 85 - 85: iI - OOooOOo / i1IIi / OoOO / II111iiii
elif oOo0 == 1 :
 o0O0O0O00o ( o0o0oOoOO0O , i1ii1II1ii , id , iII111Ii )
elif oOo0 == 2 :
 iIIIiII1 ( )
elif oOo0 == 3 :
 o0O0oO0 ( )
elif oOo0 == 4 :
 II1i ( o0o0oOoOO0O , i1ii1II1ii )
elif oOo0 == 5 :
 Ii1i1 ( )
elif oOo0 == 6 :
 OoO0O000 ( )
elif oOo0 == 7 :
 i1II1II1iii1i ( )
elif oOo0 == 8 :
 o0Oii111 ( )
elif oOo0 == 9 :
 IiI ( )
elif oOo0 == 10 :
 OOOoo ( )
elif oOo0 == 11 :
 iI1iIIiii ( )
elif oOo0 == 12 :
 i111i1I1ii1i ( )
elif oOo0 == 13 :
 ooOOo0o ( )
elif oOo0 == 14 :
 O0OoO0o ( )
elif oOo0 == 15 :
 oOo0OO0o0 ( )
elif oOo0 == 16 :
 Oo0 ( )
elif oOo0 == 17 :
 i1iI1i ( )
elif oOo0 == 18 :
 iIii ( )
elif oOo0 == 19 :
 Ooo000O00 ( )
elif oOo0 == 20 :
 I1I1IIiiii1ii ( )
elif oOo0 == 21 :
 O0oo0 ( )
elif oOo0 == 22 :
 iI1IIiiIIIII ( )
elif oOo0 == 23 :
 ooOOO00oOOooO ( )
elif oOo0 == 24 :
 o0Ooo0o0Oo ( )
elif oOo0 == 25 :
 oOoO ( )
elif oOo0 == 26 :
 oOo000O ( )
elif oOo0 == 28 :
 Iiii1IiIi ( o0o0oOoOO0O , i1ii1II1ii )
elif oOo0 == 29 :
 iIiI1I1IIi11 ( )
elif oOo0 == 30 :
 o0OO0OOO0O ( )
elif oOo0 == 31 :
 prueba ( )
elif oOo0 == 98 :
 busqueda_global ( )
elif oOo0 == 97 :
 o0OoOOoOOoo ( )
elif oOo0 == 99 :
 Oo0O0Oo00O ( )
elif oOo0 == 100 :
 menu_player ( o0o0oOoOO0O , i1ii1II1ii )
elif oOo0 == 111 :
 O0O0Ooo ( )
elif oOo0 == 115 :
 OOoOi1IiiI ( i1ii1II1ii )
elif oOo0 == 116 :
 I1i ( )
elif oOo0 == 117 :
 o0oo ( )
elif oOo0 == 119 :
 oooo00o0o0o ( )
elif oOo0 == 120 :
 OO00oo0o ( )
elif oOo0 == 121 :
 II11i11Iii ( )
elif oOo0 == 125 :
 Oo0OOo ( )
elif oOo0 == 112 :
 list_proxy ( )
elif oOo0 == 127 :
 i111IiIi1 ( )
elif oOo0 == 128 :
 TESTLINKS ( )
elif oOo0 == 130 :
 OoOo00O0o ( o0o0oOoOO0O , i1ii1II1ii )
elif oOo0 == 140 :
 iIIIII1iiiiII ( )
elif oOo0 == 141 :
 IIIiIi1iiI ( )
elif oOo0 == 142 :
 o00oo0000 ( )
elif oOo0 == 143 :
 OOoOIiIIII ( o0o0oOoOO0O , i1ii1II1ii )
elif oOo0 == 144 :
 Iiii1IiIi ( o0o0oOoOO0O , i1ii1II1ii )
elif oOo0 == 145 :
 oOooO00o0O ( )
elif oOo0 == 150 :
 oO0oooooo ( )
elif oOo0 == 151 :
 II1iiIIiIii ( )
elif oOo0 == 152 :
 IIII1i1 ( )
elif oOo0 == 155 :
 IIIII1iii11 ( )
 if 94 - 94: iIii1I11I1II1 + i1I111II1I
 if 44 - 44: OoOO + O0oO % OoOO + i1IIi + O0ooOooooO + O0
xbmcplugin . endOfDirectory ( o0OoOoOO00 ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
