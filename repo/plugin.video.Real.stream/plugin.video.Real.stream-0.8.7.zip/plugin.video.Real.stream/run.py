# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 0.8.1
#
############################################
# Dependencias 
# Script ExtendedInfo
# Script Urlresolver de TVAddons
# Script ResolveURL Por Jsergio.
#
############################################
#
# Corregido imcompatibilidad con Servidor Team
# Agregados nuevos iconos, ahora se puede el aspecto desde ajustes del addon.
#
############################################
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import urlresolver
import cookielib , base64
import requests
import plugintools
import config
oo000 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
ii = oo000 . getAddonInfo ( 'version' )
oOOo = int ( sys . argv [ 1 ] )
O0 = 'gruponetai/'
o0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
iI11I1II1I1I = o0O . getAddonInfo ( 'profile' )
oooo = o0O . getAddonInfo ( 'path' )
iIIii1IIi = oo000 . getSetting ( 'iconos' )
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if iIIii1IIi == 'true' :
 if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
 O0oOO0o0 = xbmc . translatePath ( os . path . join ( oooo , 'fanart.png' ) )
 i1ii1iIII = xbmc . translatePath ( os . path . join ( oooo , 'icon.png' ) )
 Oo0oO0oo0oO00 = xbmc . translatePath ( os . path . join ( oooo , 'extended_info.png' ) )
 i111I = xbmc . translatePath ( os . path . join ( oooo , 'buscar.png' ) )
 II1Ii1iI1i = xbmc . translatePath ( os . path . join ( oooo , 'pair.png' ) )
 iiI1iIiI = xbmc . translatePath ( os . path . join ( oooo , 'theMovieDB.png' ) )
 OOo = xbmc . translatePath ( os . path . join ( oooo , 'novedades.png' ) )
 Ii1IIii11 = xbmc . translatePath ( os . path . join ( oooo , 'estrenos.png' ) )
 Oooo0000 = xbmc . translatePath ( os . path . join ( oooo , 'recomendadas.png' ) )
 i11 = xbmc . translatePath ( os . path . join ( oooo , 'accion.png' ) )
 I11 = xbmc . translatePath ( os . path . join ( oooo , 'animacion.png' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( oooo , 'aventuras.png' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( oooo , 'belico.png' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( oooo , 'ciencia-ficcion.png' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( oooo , 'comedia.png' ) )
 oO = xbmc . translatePath ( os . path . join ( oooo , 'crimen.png' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( oooo , 'drama.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( oooo , 'familiar.png' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( oooo , 'fantasia.png' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( oooo , 'historia.png' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( oooo , 'marvel.png' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( oooo , 'misterio.png' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( oooo , 'musical.png' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( oooo , 'romance.png' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( oooo , 'spain.png' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( oooo , 'suspense.png' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( oooo , 'terror.png' ) )
 II = xbmc . translatePath ( os . path . join ( oooo , 'thriller.png' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( oooo , 'western.png' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( oooo , 'sagas_cine.png' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( oooo , '4k.png' ) )
 OO0o = xbmc . translatePath ( os . path . join ( oooo , 'torrent.png' ) )
 Ooo = xbmc . translatePath ( os . path . join ( oooo , 'buscar-serie.jpg' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( oooo , 'series-todas.jpg' ) )
 if 78 - 78: IIIIII11i1I - o0o0OOO0o0 % IIII % o0O0 . o0oOOo0O0Ooo % II111iiii
else :
 if 95 - 95: ooOoO0o
 if 49 - 49: IiII % o00O0oo + OoOoOO00 . I1ii11iIi11i % iII111i
 iIIii1IIi = oo000 . getSetting ( 'iconos' )
 O0oOO0o0 = xbmc . translatePath ( os . path . join ( oooo , 'fanart.jpg' ) )
 i1ii1iIII = xbmc . translatePath ( os . path . join ( oooo , 'icon.png' ) )
 Oo0oO0oo0oO00 = xbmc . translatePath ( os . path . join ( oooo , 'extended_info.png' ) )
 i111I = xbmc . translatePath ( os . path . join ( oooo , 'buscar.png' ) )
 II1Ii1iI1i = xbmc . translatePath ( os . path . join ( oooo , 'pair.png' ) )
 iiI1iIiI = xbmc . translatePath ( os . path . join ( oooo , 'theMovieDB.jpg' ) )
 OOo = xbmc . translatePath ( os . path . join ( oooo , 'novedades.jpg' ) )
 Ii1IIii11 = xbmc . translatePath ( os . path . join ( oooo , 'encines.jpg' ) )
 Oooo0000 = xbmc . translatePath ( os . path . join ( oooo , 'recomendadas.jpg' ) )
 i11 = xbmc . translatePath ( os . path . join ( oooo , 'accion.jpg' ) )
 I11 = xbmc . translatePath ( os . path . join ( oooo , 'animacion.jpg' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( oooo , 'aventuras.jpg' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( oooo , 'belico.jpg' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( oooo , 'ciencia-ficcion.jpg' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( oooo , 'comedia.jpg' ) )
 oO = xbmc . translatePath ( os . path . join ( oooo , 'crimen.jpg' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( oooo , 'drama.jpg' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( oooo , 'familiar.jpg' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( oooo , 'fantasia.jpg' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( oooo , 'historia.jpg' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( oooo , 'superheroes.jpg' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( oooo , 'misterio.jpg' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( oooo , 'musical.jpg' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( oooo , 'romance.jpg' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( oooo , 'spain.jpg' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( oooo , 'suspense.jpg' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( oooo , 'terror.jpg' ) )
 II = xbmc . translatePath ( os . path . join ( oooo , 'thriller.jpg' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( oooo , 'western.jpg' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( oooo , 'sagas_cine.jpg' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( oooo , '4k.jpg' ) )
 OO0o = xbmc . translatePath ( os . path . join ( oooo , 'torrent.jpg' ) )
 Ooo = xbmc . translatePath ( os . path . join ( oooo , 'buscar-serie.jpg' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( oooo , 'series-todas.jpg' ) )
 if 48 - 48: ooOoO0o + ooOoO0o / o0oOOo0O0Ooo / Oo0Ooo
 if 20 - 20: Ii1I
 if 77 - 77: I11i / ooOoO0o
Ooooo = xbmc . translatePath ( os . path . join ( oooo , 'peliculas.png' ) )
I1I1i = xbmc . translatePath ( os . path . join ( oooo , 'series.png' ) )
oOOOoo0O0OoO = xbmc . translatePath ( os . path . join ( oooo , 'ajustes.png' ) )
ii1i1I1i = xbmc . translatePath ( os . path . join ( oooo , 'videoteca.png' ) )
o00oOO0 = xbmc . translatePath ( os . path . join ( oooo , 'favorites.png' ) )
oOoo = xbmc . translatePath ( os . path . join ( oooo , 'resolver.png' ) )
iIii11I = xbmc . translatePath ( os . path . join ( oooo , 'test.png' ) )
OOO0OOO00oo = xbmc . translatePath ( os . path . join ( oooo , 'video-tutoriales.png' ) )
Iii111II = xbmc . translatePath ( os . path . join ( oooo , 'proxy.png' ) )
if 9 - 9: OOooOOo
i11O0oo0OO0oOOOo = oo000 . getSetting ( 'mostrar_cat' )
i1i1i11IIi = oo000 . getSetting ( 'videos' )
II1III = oo000 . getSetting ( 'activar' )
iI1iI1I1i1I = oo000 . getSetting ( 'favcopy' )
iIi11Ii1 = oo000 . getSetting ( 'anticopia' )
Ii11iII1 = oo000 . getSetting ( 'licencia_addon' )
Oo0O0O0ooO0O = oo000 . getSetting ( 'notificar' )
IIIIii = oo000 . getSetting ( 'mostrar_bus' )
O0o0 = oo000 . getSetting ( 'restante' )
OO00Oo = oo000 . getSetting ( 'selecton' )
O0OOO0OOoO0O = oo000 . getSetting ( 'aviso' )
O00Oo000ooO0 = oo000 . getSetting ( 'RealStream_Settings' )
OoO0O00IIiII = oo000 . getSetting ( 'Resolver_Settings' )
O0o0 = oo000 . getSetting ( 'restante' )
o0 = oo000 . getSetting ( 'fav' )
ooOooo000oOO = oo000 . getSetting ( 'Fontcolor' )
Oo0oOOo = oo000 . getSetting ( 'MenuColor' )
Oo0OoO00oOO0o = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
OOO00O = 'bienvenida'
OOoOO0oo0ooO = 'bienvenida'
copyright = oo000 . getSetting ( 'copyright' )
O0o0O00Oo0o0 = 'cGx1Z2luLnZpZGVvLg==' . decode ( 'base64' ) + copyright
O00O0oOO00O00 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
i1 = oo000 . getSetting ( 'Forceupdate' )
if i1 == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
Oo00 = '.txt'
if 31 - 31: IIII . I11i / I1IiiI
o000O0o = 'aHR0cDovL2JpdC5seS8yU1FOSnlP' . decode ( 'base64' )
iI1iII1 = Oo0OoO00oOO0o + OOO00O + Oo00
oO0OOoo0OO = 'http://www.youtube.com'
O0ii1ii1ii = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
oooooOoo0ooo = '.xsl.pt'
I1I1IiI1 = 'L21hc3Rlci8=' . decode ( 'base64' )
III1iII1I1ii = O0ii1ii1ii + oooooOoo0ooo
oOOo0 = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*texto3=[\'"](.*?)[\'"]\s*'
oo00O00oO = 'tvg-logo=[\'"](.*?)[\'"]'
if 23 - 23: OOooOOo + OOooOOo . I1Ii111
ii1ii11IIIiiI = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)'
O00OOOoOoo0O = '(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)'
O000OOo00oo = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
oo0OOo = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
ooOOO00Ooo = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
IiIIIi1iIi = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
ooOOoooooo = '#(.+?),(.+)\s*(.+)'
II1I = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
if 84 - 84: o0o0OOO0o0 . II111iiii . o0o0OOO0o0 * iII111i - ooOoO0o
iiO0o0oOOOoOo = 'source src=[\'"](.*?)[\'"]\s*title=[\'"](.*?)[\'"]'
II1 = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
I1iiiI1Ii1I = '[\'"](.*?)[\'"]'
O0OOO0O = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
iiiiIiI = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( 'base64' )
I1 = iiiiIiI + O0
OOO00O0O = '[\'"](.*?)[\'"]'
iii = 'UmVhbHN0cmVhbQ==' . decode ( 'base64' )
oOooOOOoOo = 'video=[\'"](.*?)[\'"]'
i1Iii1i1I = '0110nhu' . replace ( '0110nhu' , 'nhu' )
OOoO00 = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( 'base64' ) + i1Iii1i1I
IiI111111IIII = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
i1Ii = '0110R0N' . replace ( '0110R0N' , 'R0N' )
ii111iI1iIi1 = 'aHR0cDovL2JpdC5seS8yWEIx' . decode ( 'base64' ) + i1Ii
OOO = '0110pEJ' . replace ( '0110pEJ' , 'pEJ' )
oo0OOo0 = 'aHR0cDovL2JpdC5seS8yd1Nh' . decode ( 'base64' ) + OOO
I11IiI = 'ABBAOb5' . replace ( 'ABBAOb5' , 'Ob5' )
O0ooO0Oo00o = 'aHR0cDovL2JpdC5seS8yRVhV' . decode ( 'base64' ) + I11IiI
ooO0oOOooOo0 = '0110jaw' . replace ( '0110jaw' , 'jaw' )
i1I1ii11i1Iii = 'aHR0cDovL2JpdC5seS8yd01M' . decode ( 'base64' ) + ooO0oOOooOo0
I1IiiiiI = '01109DI' . replace ( '01109DI' , '9DI' )
o0OIiII = 'aHR0cDovL2JpdC5seS8ySXgz' . decode ( 'base64' ) + I1IiiiiI
ii1iII1II = '01103hs' . replace ( '01103hs' , '3hs' )
Iii1I1I11iiI1 = 'aHR0cDovL2JpdC5seS8zMW1U' . decode ( 'base64' ) + ii1iII1II
I1I1i1I = '01107DW' . replace ( '01107DW' , '7DW' )
ii1I = 'aHR0cDovL2JpdC5seS8yV1ln' . decode ( 'base64' ) + I1I1i1I
O0oO0 = '0110mLl' . replace ( '0110mLl' , 'mLl' )
oO0 = 'aHR0cDovL2JpdC5seS8yS0cw' . decode ( 'base64' ) + O0oO0
O0OO0O = '01102Hj' . replace ( '01102Hj' , '2Hj' )
OO = 'aHR0cDovL2JpdC5seS8yWEJo' . decode ( 'base64' ) + O0OO0O
OoOoO = '0110fXg' . replace ( '0110fXg' , 'fXg' )
Ii1I1i = 'aHR0cDovL2JpdC5seS8ySTVy' . decode ( 'base64' ) + OoOoO
OOI1iI1ii1II = '0110NMH' . replace ( '0110NMH' , 'NMH' )
O0O0OOOOoo = 'aHR0cDovL2JpdC5seS8yd0t6' . decode ( 'base64' ) + OOI1iI1ii1II
oOooO0 = '0110bwQ' . replace ( '0110bwQ' , 'bwQ' )
Ii1I1Ii = 'aHR0cDovL2JpdC5seS8yd01V' . decode ( 'base64' ) + oOooO0
OOoO0 = '0110xzG' . replace ( '0110xzG' , 'xzG' )
OO0Oooo0oOO0O = 'aHR0cDovL2JpdC5seS8yWHhz' . decode ( 'base64' ) + OOoO0
o00O0 = '0110x64' . replace ( '0110x64' , 'x64' )
oOO0O00Oo0O0o = 'aHR0cDovL2JpdC5seS8yRVlF' . decode ( 'base64' ) + o00O0
ii1 = '0110vUE' . replace ( '0110vUE' , 'vUE' )
I1iIIiiIIi1i = 'aHR0cDovL2JpdC5seS8yWmhW' . decode ( 'base64' ) + ii1
O0O0ooOOO = '01107ZL' . replace ( '01107ZL' , '7ZL' )
oOOo0O00o = 'aHR0cDovL2JpdC5seS8yWm4w' . decode ( 'base64' ) + O0O0ooOOO
iIiIi11 = '01106cf' . replace ( '01106cf' , '6cf' )
OOOiiiiI = 'aHR0cDovL2JpdC5seS8yRVlk' . decode ( 'base64' ) + iIiIi11
oooOo0OOOoo0 = '0110Jtp' . replace ( '0110Jtp' , 'Jtp' )
OOoO = 'aHR0cDovL2JpdC5seS8yV3Nq' . decode ( 'base64' ) + oooOo0OOOoo0
OO0O000 = '0110a5b' . replace ( '0110a5b' , 'a5b' )
iiIiI1i1 = 'aHR0cDovL2JpdC5seS8yV3dj' . decode ( 'base64' ) + OO0O000
oO0O00oOOoooO = '0110Q7u' . replace ( '0110Q7u' , 'Q7u' )
IiIi11iI = 'aHR0cDovL2JpdC5seS8yV3NL' . decode ( 'base64' ) + oO0O00oOOoooO
Oo0O00O000 = '0110rsq' . replace ( '0110rsq' , 'rsq' )
i11I1IiII1i1i = 'aHR0cDovL2JpdC5seS8ySzhE' . decode ( 'base64' ) + Oo0O00O000
oo = '0110DDR' . replace ( '0110DDR' , 'DDR' )
I1111i = 'aHR0cDovL2JpdC5seS8ySzd5' . decode ( 'base64' ) + oo
iIIii = '0110feQ' . replace ( '0110feQ' , 'feQ' )
o00O0O = 'aHR0cDovL2JpdC5seS8yS0cz' . decode ( 'base64' ) + iIIii
ii1iii1i = '0110MHY' . replace ( '0110MHY' , 'MHY' )
Iii1I1111ii = 'aHR0cDovL2JpdC5seS8ySXVo' . decode ( 'base64' ) + ii1iii1i
ooOoO00 = '0110xdb' . replace ( '0110xdb' , 'xdb' )
Ii1IIiI1i = 'aHR0cDovL2JpdC5seS8yWEJu' . decode ( 'base64' ) + ooOoO00
o0O00Oo0 = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( 'base64' )
O0o0O00Oo0o0 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
IiII111i1i11 = '0110lxu' . replace ( '0110lxu' , 'lxu' )
i111iIi1i1II1 = 'aHR0cDovL2JpdC5seS8yV1Bj' . decode ( 'base64' ) + IiII111i1i11
if 86 - 86: Oo0Ooo / I11i . o0oOOo0O0Ooo
if 19 - 19: iII111i % OoO0O00 % o0o0OOO0o0 * Ii1I % I1IiiI
ooo = '1001DTs' . replace ( '1001DTs' , 'DTs' )
i1i1iI1iiiI = 'aHR0cDovL2JpdC5seS8ySzhP' . decode ( 'base64' ) + ooo
if 51 - 51: I1ii11iIi11i % IIII . IiII / Oo0Ooo / ooOoO0o . IiII
if 42 - 42: Ii1I + OoOoOO00 - o00O0oo / o0o0OOO0o0
if 9 - 9: I1IiiI % I1IiiI - Ii1I
if 51 - 51: I1ii11iIi11i . Oo0Ooo - iII111i / I1IiiI
def OOOoO00 ( ) :
 if 40 - 40: iII111i % I1ii11iIi11i . o0O0 . I1IiiI * IIII
 if 4 - 4: o00O0oo % IiII * OOooOOo
 try :
  if 100 - 100: IIII * I1Ii111 + I1Ii111
  OoOO0o = i1II1 ( ii111iI1iIi1 )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   try :
    if 87 - 87: Ii1I
    oo0OOo0 = IiiiiI1i1Iii
    if 29 - 29: I1ii11iIi11i % I1Ii111 - I1ii11iIi11i / I1Ii111 . OoOoOO00
    i11III1111iIi = xbmc . Keyboard ( '' , 'Busqueda por titulo,actor, director, año, servidor:' )
    i11III1111iIi . doModal ( )
    if ( i11III1111iIi . isConfirmed ( ) ) :
     if 38 - 38: IIIIII11i1I + ooOoO0o / IIII % o0O0 - iII111i
     iI11 = urllib . quote_plus ( i11III1111iIi . getText ( ) ) . replace ( '+' , ' ' )
     Ii1Io0OO0o0o00o = i1II1 ( oo0OOo0 )
     i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( Ii1Io0OO0o0o00o )
     if 100 - 100: IiII / IIII / iII111i
     for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
      if re . search ( iI11 , o0OO0o0oOOO0O ( OOOooo . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
       if 2 - 2: o0O0 / IIIIII11i1I . IIIIII11i1I % IIII
   except :
    pass
 except :
  pass
  if 11 - 11: Oo0Ooo
def IiIIII1i11I ( ) :
 if 86 - 86: oO0o . I1IiiI - OoO0O00 . OOooOOo + o00O0oo
 if 57 - 57: Ii1I . OoOoOO00 . o0o0OOO0o0 * II111iiii + IIII . o0o0OOO0o0
 oo0O00Oooo0O0 = i1II1 ( o0O00Oo0 )
 i11i1 = re . compile ( I1iiiI1Ii1I ) . findall ( oo0O00Oooo0O0 )
 for I11OO in i11i1 :
  try :
   if 84 - 84: o0O0 % o00O0oo + II111iiii
   import xbmc
   import xbmcaddon
   if 28 - 28: oO0o + OOooOOo * I1Ii111 % IiII . ooOoO0o % I1IiiI
   __addon__ = xbmcaddon . Addon ( )
   __addonname__ = __addon__ . getAddonInfo ( 'name' )
   __icon__ = __addon__ . getAddonInfo ( 'icon' )
   if 16 - 16: ooOoO0o - Oo0Ooo / I1ii11iIi11i . o0oOOo0O0Ooo + Oo0Ooo
   ii = oo000 . getAddonInfo ( 'version' )
   if 19 - 19: OOooOOo - oO0o . I1IiiI
   ooOo00 = "[COLOR gold]Version instalada: " + ii + " [/COLOR]" "[COLOR lime]Ultima Version: " + I11OO + "  [/COLOR]"
   OOoo = 3000
   if 50 - 50: OOooOOo
   xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , ooOo00 , OOoo , __icon__ ) )
   if 43 - 43: o0oOOo0O0Ooo . IiII / iII111i
   if 20 - 20: I1ii11iIi11i
  except :
   pass
   if 95 - 95: IIIIII11i1I - I1ii11iIi11i
   if 34 - 34: o0O0 * I1ii11iIi11i . OoOoOO00 * o0O0 / o0O0
def IIiI1Ii ( ) :
 if 57 - 57: I1Ii111 - o0O0 - ooOoO0o + OOooOOo
 i1i1i11IIi = oo000 . getSetting ( 'videos' )
 if i1i1i11IIi == 'true' :
  if 30 - 30: o00O0oo % I11i + OoOoOO00 - ooOoO0o - o00O0oo
  try :
   oo0O00Oooo0O0 = i1II1 ( o000O0o )
   i11i1 = re . compile ( O00OOOoOoo0O ) . findall ( oo0O00Oooo0O0 )
   for III11I1 , IIi1IIIi , O00Ooo , OOOO0OOO , i1i1ii , iII1ii1 , I1i1iiiI1 , iIIi , oO0o00oo0 , ii1IIII , oO00oOooooo0 , oOo , O0OOooOoO , i1II1I1Iii1 , iiI11Iii in i11i1 :
    try :
     import urlresolver
     from urlresolver import common
     import random
     from random import choice
     O0o0O0 = xbmc . Player ( )
     ii1i1I1i = [ III11I1 , IIi1IIIi , O00Ooo , OOOO0OOO , i1i1ii , iII1ii1 , I1i1iiiI1 , iIIi , oO0o00oo0 , ii1IIII , oO00oOooooo0 , oOo , O0OOooOoO , i1II1I1Iii1 , iiI11Iii ]
     Ii1II1I11i1 = random . choice ( ii1i1I1i )
     OooO0OO = 'https://www.youtube.com/watch?v=%s' % Ii1II1I11i1
     OooO0OO = urlresolver . HostedMediaFile ( OooO0OO ) . resolve ( )
     O0o0O0 . play ( OooO0OO )
     i1i1i11IIi == 'false'
    except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR red] Trailer no encontrado! [/COLOR] ,3000)" )
    if 59 - 59: IiII % Oo0Ooo . OoOoOO00
    if 21 - 21: oO0o
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR red] no se pudo conectar al servidor de origen! [/COLOR] ,3000)" )
  if 29 - 29: ooOoO0o / o0oOOo0O0Ooo / o0O0 * I1Ii111
 OoOO0o = i1II1 ( iI1iII1 )
 i11i1 = re . compile ( oOOo0 ) . findall ( OoOO0o )
 for I111i1i1111 , IIII1 , I1I1iI1IIIiIiIi in i11i1 :
  try :
   if 27 - 27: iII111i + I11i - I1Ii111 + I1IiiI . o00O0oo
   if 46 - 46: o0o0OOO0o0
   ii1iIi1iIiI1i = I111i1i1111
   iiI1iIii1i = IIII1
   OOooO0oo0o00o = I1I1iI1IIIiIiIi
   if 100 - 100: Ii1I
   if 1 - 1: ooOoO0o + OoO0O00 - I1Ii111 + o0o0OOO0o0
   ooOo00 = "[COLOR=red][B]" + ii1iIi1iIiI1i + "[/B][/COLOR]"
   iII1iiiiIII = "[COLOR yellow]" + iiI1iIii1i + "[/COLOR]"
   OOoOO0oo00Oo = "[COLOR yellow]" + OOooO0oo0o00o + "[/COLOR]"
   if 50 - 50: o0O0 - IIII * o0o0OOO0o0 . iII111i
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , ooOo00 , iII1iiiiIII , OOoOO0oo00Oo )
   if 37 - 37: o0O0 % II111iiii % o0oOOo0O0Ooo . I1IiiI . o00O0oo
  except :
   pass
   if 51 - 51: OOooOOo - I1IiiI % IiII - o0oOOo0O0Ooo
   if 31 - 31: IIIIII11i1I / oO0o - IIIIII11i1I - I1Ii111
   if 7 - 7: IIIIII11i1I % I1IiiI . I11i + I1ii11iIi11i - ooOoO0o
 if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
  if 75 - 75: ooOoO0o
  if 71 - 71: o0O0
  if 53 - 53: OoO0O00 % o00O0oo . o0o0OOO0o0 / II111iiii % IIIIII11i1I
def o0OO0o0oOOO0O ( s ) :
 if 28 - 28: ooOoO0o
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 58 - 58: I11i
def iIiiI1iI ( file ) :
 if 5 - 5: I11i / OoO0O00 + o0o0OOO0o0 * IIII - OOooOOo % I1ii11iIi11i
 try :
  IiII1 = open ( file , 'r' )
  OoOO0o = IiII1 . read ( )
  IiII1 . close ( )
  return OoOO0o
 except :
  pass
  if 18 - 18: o0O0 * I11i . IIIIII11i1I / iII111i / II111iiii
def i1II1 ( url ) :
 if 21 - 21: IiII / iII111i + o00O0oo + OoO0O00
 try :
  OoOo = urllib2 . Request ( url )
  OoOo . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  I1iI11iIiIi1 = urllib2 . urlopen ( OoOo )
  o0O0O0ooo0oOO = I1iI11iIiIi1 . read ( )
  I1iI11iIiIi1 . close ( )
  return o0O0O0ooo0oOO
 except urllib2 . URLError , oo000ii :
  print 'We failed to open "%s".' % url
  if hasattr ( oo000ii , 'code' ) :
   print 'We failed with error code - %s.' % oo000ii . code
  if hasattr ( oo000ii , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , oo000ii . reason
   if 78 - 78: OoO0O00 . OOooOOo + o0O0 - OoOoOO00
def ii1O0 ( url ) :
 OoOo = urllib2 . Request ( url )
 OoOo . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 OoOo . add_header ( 'Referer' , '%s' % url )
 OoOo . add_header ( 'Connection' , 'keep-alive' )
 I1iI11iIiIi1 = urllib2 . urlopen ( OoOo )
 o0O0O0ooo0oOO = I1iI11iIiIi1 . read ( )
 I1iI11iIiIi1 . close ( )
 return o0O0O0ooo0oOO
 if 33 - 33: OoOoOO00
 if 36 - 36: o0oOOo0O0Ooo % II111iiii * I11i + ooOoO0o
def iii11i1IIII ( ) :
 if 26 - 26: I1IiiI . OOooOOo * IIII . I1ii11iIi11i % II111iiii
 Oo0oOOo = oo000 . getSetting ( 'MenuColor' )
 if 47 - 47: IIIIII11i1I - oO0o
 if II1III == 'true' :
  Iiii ( '[COLOR %s]Peliculas[/COLOR] ' % Oo0oOOo , 'movieDB' , 116 , Ooooo , O0oOO0o0 )
  Iiii ( '[COLOR %s]Series[/COLOR] ' % Oo0oOOo , 'movieDB' , 117 , I1I1i , O0oOO0o0 )
  if 89 - 89: IiII
  if 25 - 25: iII111i + I1IiiI
 if O00Oo000ooO0 == 'true' :
  Iiii ( '[COLOR %s]Ajustes[/COLOR]' % Oo0oOOo , 'Settings' , 119 , oOOOoo0O0OoO , O0oOO0o0 )
  if 28 - 28: OoO0O00
  if 89 - 89: IIIIII11i1I - o0O0 % oO0o % Ii1I
  if i11O0oo0OO0oOOOo == 'true' :
   IIiii11i ( )
   if 100 - 100: o0O0 % Oo0Ooo * o0oOOo0O0Ooo - IIIIII11i1I
  if OoO0O00IIiII == 'true' :
   oo00O00oO000o ( )
   OOo00OoO ( )
   if 10 - 10: Ii1I / II111iiii
  if iIi11Ii1 == 'false' :
   if 92 - 92: ooOoO0o . IIII
   ooOo00 = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   iII1iiiiIII = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Program.favoritos-realstream para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   OOoOO0oo00Oo = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 85 - 85: iII111i . IIII
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , ooOo00 , iII1iiiiIII , OOoOO0oo00Oo )
   if 78 - 78: o0O0 * IIII + Oo0Ooo + Oo0Ooo / IIII . o00O0oo
def O000 ( ) :
 Iiii ( '[COLOR orange]Buscador por id[/COLOR]' , oO0OOoo0OO , 127 , iiI1iIiI , O0oOO0o0 )
 if 79 - 79: OoO0O00 - I1ii11iIi11i
def o00O00oO00 ( ) :
 if 23 - 23: Oo0Ooo * OoOoOO00 % OoO0O00 * o0o0OOO0o0
 Oo0oOOo = oo000 . getSetting ( 'MenuColor' )
 Iiii ( '[COLOR %s]The movie DB[/COLOR]' % Oo0oOOo , 'movieDB' , 99 , iiI1iIiI , O0oOO0o0 )
 Iiii ( '[COLOR %s]Buscador por id[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 127 , iiI1iIiI , O0oOO0o0 )
 Iiii ( '[COLOR %s]Video tutoriales[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 125 , OOO0OOO00oo , O0oOO0o0 )
 if 9 - 9: o0o0OOO0o0 - o0oOOo0O0Ooo + I1IiiI / Oo0Ooo / II111iiii
 if 39 - 39: o0o0OOO0o0 * oO0o + Oo0Ooo - o0o0OOO0o0 + I1Ii111
 if 69 - 69: I1IiiI
 if 85 - 85: o0O0 / I1IiiI
 if 18 - 18: Ii1I % I1IiiI * iII111i
 if 62 - 62: IIII . o0o0OOO0o0 . OoO0O00
 Iiii ( '[COLOR %s]Autorizar OPENLOAD[/COLOR]' % Oo0oOOo , 'movieDB' , 97 , II1Ii1iI1i , O0oOO0o0 )
 if 11 - 11: I1Ii111 / ooOoO0o
 Iiii ( '[COLOR %s]listado Proxy[/COLOR]' % Oo0oOOo , 'movieDB' , 112 , Iii111II , O0oOO0o0 )
 iii11i1IIII ( )
 if 73 - 73: OoOoOO00 / II111iiii
 if 58 - 58: oO0o . o0oOOo0O0Ooo + IiII - II111iiii / o0oOOo0O0Ooo / I1IiiI
 if 85 - 85: I11i + I1Ii111
 if 10 - 10: o0o0OOO0o0 / OOooOOo + I11i / OoOoOO00
 if 27 - 27: o00O0oo
 if 67 - 67: I1ii11iIi11i
 if 55 - 55: iII111i - IIIIII11i1I * Ii1I + I11i * I11i * I1IiiI
 if 91 - 91: IIII - I1Ii111 % Oo0Ooo - OoO0O00 % o0O0
 if 98 - 98: OOooOOo . OOooOOo * IiII * o0oOOo0O0Ooo * IIII
 if 92 - 92: oO0o
 if 40 - 40: I11i / o0o0OOO0o0
def OOOoO000 ( ) :
 oOOOO = xbmcgui . Dialog ( )
 Ii = (
 Ii1ii111i1 ,
 i1i1i1I ,
 )
 if 83 - 83: IiII + OoO0O00
 I111IiiIi1 = oOOOO . select ( '[B][COLOR=yellow]Listado de Proxys Gratuitos:[/COLOR][/B]' , [
 '[COLOR=orange]                      Accede a la web[/COLOR]' ,

 '[B][COLOR=gold]                      Volver al Menu [/COLOR][/B]' , ] )
 if 88 - 88: OoO0O00
 if I111IiiIi1 :
  if 84 - 84: I11i / ooOoO0o * IIIIII11i1I / IiII - II111iiii . oO0o
  if I111IiiIi1 < 0 :
   return
  oOOo000oOoO0 = Ii [ I111IiiIi1 - 2 ]
  return oOOo000oOoO0 ( )
 else :
  oOOo000oOoO0 = Ii [ I111IiiIi1 ]
  return oOOo000oOoO0 ( )
 return
 if 86 - 86: o0oOOo0O0Ooo % II111iiii + o00O0oo % II111iiii
def Ooo0o0OOO ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 35 - 35: I1Ii111 + IIIIII11i1I
iI1IIIii = Ooo0o0OOO ( )
if 7 - 7: o0o0OOO0o0 - ooOoO0o / o0oOOo0O0Ooo * o00O0oo . IIIIII11i1I * IIIIII11i1I
def Ii1ii111i1 ( ) :
 if iI1IIIii == 'android' :
  O0O0oOOo0O = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://hidemyna.me/es/proxy-list/?country=ES&type=hs#list' ) )
  if 19 - 19: Ii1I / IIII % Ii1I % IIIIII11i1I * o0o0OOO0o0
 else :
  O0O0oOOo0O = webbrowser . open ( 'https://hidemyna.me/es/proxy-list/?country=ES&type=hs#list' )
  if 19 - 19: Oo0Ooo
  if 26 - 26: OoO0O00 % I1ii11iIi11i % oO0o . I1ii11iIi11i % o00O0oo
def i1i1i1I ( ) :
 if 34 - 34: o0o0OOO0o0 / I11i
 main ( )
 if 87 - 87: I1IiiI * Ii1I * oO0o * o0oOOo0O0Ooo
 if 6 - 6: OoOoOO00 . iII111i + I11i * ooOoO0o / I11i % IiII
 if 18 - 18: o0oOOo0O0Ooo . OoO0O00 % I11i % o00O0oo
 if 9 - 9: OOooOOo - oO0o * OoO0O00 . oO0o
 if 2 - 2: OoO0O00 % I1Ii111
def oOoOOo0oo0 ( ) :
 if 60 - 60: o0O0 * IIII + oO0o
 if xbmc . getCondVisibility ( 'System.HasAddon(plugin.program.favoritos-realstream)' ) :
  if 19 - 19: OOooOOo * ooOoO0o / ooOoO0o . OoO0O00 - I1Ii111 + II111iiii
  xbmc . executebuiltin ( 'RunAddon(plugin.program.favoritos-realstream)' )
  if 88 - 88: II111iiii - o0O0
  if iI1iI1I1i1I == 'true' :
   if 67 - 67: I1Ii111 . oO0o + I11i - OoO0O00
   xbmcgui . Dialog ( ) . ok ( "[COLOR orange]Real Stream Agradecimientos[/COLOR]" , "[COLOR gold]Netai quiere agradecer el genial trabajo de [/COLOR][COLOR lime][B]Spoyser[/B][/COLOR][COLOR gold] Autor de este genial script que originalmente se conoce como:[/COLOR]" , "[COLOR lime][B]Program.super.favorites[/B][/COLOR]" , "Usted puede descargar el script original desde el repositorio de Kodi >Addons de programas> program.super.favorites" )
   if 70 - 70: I1Ii111 / o0oOOo0O0Ooo - Oo0Ooo - IIIIII11i1I
  oo000 . setSetting ( 'Favoritos-anuncio' , 'false' )
 else :
  if 11 - 11: Oo0Ooo . OoO0O00 . o0oOOo0O0Ooo / OoOoOO00 - ooOoO0o
  xbmcgui . Dialog ( ) . ok ( "El programa Real stream Favoritos No esta instalado" , "[COLOR green]Necesario AddOn externo para agregar tus peliculas a favoritas dentro del addon.[/COLOR]" , "[COLOR yellow]Puedes agregarlo desde http://netai.eu/netai/ agregando la fuente a tu Kodi, instalar desde archivo zip.[/COLOR]" )
  if 30 - 30: I11i
def Ii111 ( ) :
 oo000 . openSettings ( )
 if 67 - 67: I1IiiI
 if 52 - 52: o0oOOo0O0Ooo . o0O0 / I11i / OoO0O00 . II111iiii
def I1i1i ( ) :
 urlresolver . display_settings ( )
 if 86 - 86: oO0o / IiII + I1IiiI * IIIIII11i1I
def oo00O00oO000o ( ) :
 Iiii ( '[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % Oo0oOOo , 'resolve' , 120 , oOoo , O0oOO0o0 )
 if 19 - 19: o0oOOo0O0Ooo * o0o0OOO0o0 + o00O0oo
def O0o ( ) :
 if 95 - 95: OOooOOo
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 60 - 60: OoO0O00 % oO0o + I1Ii111 . o0O0 * Oo0Ooo
def OOo00OoO ( ) :
 Iiii ( '[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % Oo0oOOo , 'resolve' , 140 , oOoo , O0oOO0o0 )
 if 93 - 93: OOooOOo
def IIiii11i ( ) :
 if 5 - 5: ooOoO0o / I1Ii111
 Oo0oOOo = oo000 . getSetting ( 'MenuColor' )
 Iiii ( '[COLOR %s]Buscador[/COLOR]' % Oo0oOOo , 'search' , 111 , i111I , O0oOO0o0 )
 Iiii ( '[COLOR %s]Estrenos[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 3 , Ii1IIii11 , O0oOO0o0 )
 Iiii ( '[COLOR %s]Todas[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 26 , Oooo0000 , O0oOO0o0 )
 Iiii ( '[COLOR %s]4K[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 141 , II11iiii1Ii , O0oOO0o0 )
 Iiii ( '[COLOR %s]Novedades[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 2 , OOo , O0oOO0o0 )
 Iiii ( '[COLOR %s]Accion[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 5 , i11 , O0oOO0o0 )
 Iiii ( '[COLOR %s]Animacion[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 6 , I11 , O0oOO0o0 )
 Iiii ( '[COLOR %s]Aventuras[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 7 , Oo0o0000o0o0 , O0oOO0o0 )
 Iiii ( '[COLOR %s]Belico[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 8 , oOo0oooo00o , O0oOO0o0 )
 Iiii ( '[COLOR %s]Ciencia Ficcion[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 9 , oO0o0o0ooO0oO , O0oOO0o0 )
 Iiii ( '[COLOR %s]Comedia[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 10 , oo0o0O00 , O0oOO0o0 )
 Iiii ( '[COLOR %s]Crimen[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 11 , oO , O0oOO0o0 )
 Iiii ( '[COLOR %s]Drama[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 12 , i1iiIIiiI111 , O0oOO0o0 )
 Iiii ( '[COLOR %s]Familiar[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 13 , oooOOOOO , O0oOO0o0 )
 Iiii ( '[COLOR %s]Fantasia[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 14 , i1iiIII111ii , O0oOO0o0 )
 Iiii ( '[COLOR %s]Historia[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 15 , i1iIIi1 , O0oOO0o0 )
 Iiii ( '[COLOR %s]Misterio[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 16 , iI111I11I1I1 , O0oOO0o0 )
 Iiii ( '[COLOR %s]Musical[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 17 , OOooO0OOoo , O0oOO0o0 )
 Iiii ( '[COLOR %s]Romance[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 18 , iIii1 , O0oOO0o0 )
 Iiii ( '[COLOR %s]Thriller[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 19 , II , O0oOO0o0 )
 Iiii ( '[COLOR %s]Suspense[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 20 , O0OoO000O0OO , O0oOO0o0 )
 Iiii ( '[COLOR %s]Terror[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 21 , iiI1IiI , O0oOO0o0 )
 Iiii ( '[COLOR %s]Western[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 22 , ooOoOoo0O , O0oOO0o0 )
 Iiii ( '[COLOR %s]Spain[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 23 , oOOoO0 , O0oOO0o0 )
 Iiii ( '[COLOR %s]Super heroes[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 24 , ii11iIi1I , O0oOO0o0 )
 Iiii ( '[COLOR %s]Sagas[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 25 , OooO0 , O0oOO0o0 )
 if 77 - 77: o0O0 - I1ii11iIi11i % ooOoO0o - I1IiiI
 if 67 - 67: I1Ii111 + oO0o
def OoOo000oOo0oo ( ) :
 if 65 - 65: I11i / OOooOOo % o0o0OOO0o0
 if 45 - 45: I11i
 try :
  if 66 - 66: OOooOOo
  oOO = i1II1 ( i1i1iI1iiiI )
  i11i1 = re . compile ( OOO00O0O ) . findall ( oOO )
  for IiiiiI1i1Iii in i11i1 :
   if 31 - 31: I1Ii111 / oO0o * OoOoOO00 . I11i
   try :
    if 57 - 57: I1Ii111 + Oo0Ooo % OoOoOO00 % I1ii11iIi11i
    OO0oo = IiiiiI1i1Iii
    i11III1111iIi = xbmc . Keyboard ( '' , 'Buscar' )
    i11III1111iIi . doModal ( )
    if ( i11III1111iIi . isConfirmed ( ) ) :
     if 15 - 15: Oo0Ooo % OoO0O00 - oO0o * o00O0oo + ooOoO0o
     iI11 = urllib . quote_plus ( i11III1111iIi . getText ( ) ) . replace ( '+' , ' ' )
     oo0O00Oooo0O0 = i1II1 ( OO0oo )
     i11i1 = re . compile ( O000OOo00oo ) . findall ( oo0O00Oooo0O0 )
     for i1ii1iIII , OOOooo , O0oOO0o0 , OooO0OO in i11i1 :
      if re . search ( iI11 , o0OO0o0oOOO0O ( OOOooo . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       Iiii ( OOOooo , OooO0OO , 143 , i1ii1iIII , O0oOO0o0 )
       if 11 - 11: IIIIII11i1I * o00O0oo - I11i
   except :
    pass
 except :
  pass
  if 66 - 66: I11i . II111iiii - IIIIII11i1I * Ii1I + OoO0O00 * iII111i
def oO0OO0 ( ) :
 if 92 - 92: o0O0 / I11i * OOooOOo . ooOoO0o % o0oOOo0O0Ooo
 Iiii ( '[COLOR %s]Buscar Serie[/COLOR]' % Oo0oOOo , 'search' , 145 , Ooo , O0oOO0o0 )
 Iiii ( '[COLOR %s]Todas[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 142 , O0o0Oo , O0oOO0o0 )
 if 71 - 71: IIII % OoOoOO00 - o0oOOo0O0Ooo - I1Ii111 + I1Ii111 * o0O0
 if 51 - 51: Oo0Ooo / I11i + I1Ii111 - ooOoO0o + IIIIII11i1I
def IIii1i1iii1 ( ) :
 if 70 - 70: II111iiii % IIIIII11i1I
 try :
  if 11 - 11: o0o0OOO0o0 % iII111i % o00O0oo / o0oOOo0O0Ooo % IIII - oO0o
  oOO = i1II1 ( i1i1iI1iiiI )
  i11i1 = re . compile ( OOO00O0O ) . findall ( oOO )
  for IiiiiI1i1Iii in i11i1 :
   if 96 - 96: iII111i / o0oOOo0O0Ooo . o00O0oo - IIIIII11i1I * ooOoO0o * IiII
   try :
    if 76 - 76: o00O0oo - o0oOOo0O0Ooo * I1Ii111 / OoO0O00
    OO0oo = IiiiiI1i1Iii
    if 18 - 18: OOooOOo + Oo0Ooo - o0oOOo0O0Ooo - I1ii11iIi11i
   except :
    pass
    if 71 - 71: OoO0O00
  oo0O00Oooo0O0 = i1II1 ( OO0oo )
  i11i1 = re . compile ( O000OOo00oo ) . findall ( oo0O00Oooo0O0 )
  for i1ii1iIII , OOOooo , O0oOO0o0 , OooO0OO in i11i1 :
   try :
    if 33 - 33: IIII
    Iiii ( OOOooo , OooO0OO , 143 , i1ii1iIII , O0oOO0o0 )
    if 62 - 62: iII111i + o00O0oo + OoOoOO00 / OoO0O00
   except :
    pass
 except :
  pass
  if 7 - 7: Ii1I + OoOoOO00 . I1ii11iIi11i / oO0o
def I111i1I1 ( name , url ) :
 if 62 - 62: I1Ii111 * IIII / oO0o * Ii1I
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 29 - 29: oO0o % OOooOOo % o0o0OOO0o0 . Ii1I / OoO0O00 * o0O0
 Ii1Io0OO0o0o00o = i1II1 ( url )
 i11i1 = re . compile ( ooOOO00Ooo ) . findall ( Ii1Io0OO0o0o00o )
 for o0OoO000O , name , O0oOO0o0 , url in i11i1 :
  try :
   if 94 - 94: I11i . I1IiiI / o00O0oo . iII111i - OoOoOO00
   if 26 - 26: OOooOOo - I1Ii111 . Ii1I
   ooOooo000oOO = oo000 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % ooOooo000oOO + name + '[/COLOR]'
   OO0o0o0oo0O ( name , url , 144 , o0OoO000O , O0oOO0o0 )
   if 40 - 40: Ii1I + oO0o . Ii1I % o0O0
   if 15 - 15: o00O0oo * oO0o % iII111i * Oo0Ooo - II111iiii
  except :
   pass
   if 60 - 60: I1ii11iIi11i * IIII % OOooOOo + IiII
   if 52 - 52: OoOoOO00
   if 84 - 84: o00O0oo / o0o0OOO0o0
def OO0o0o0oo0O ( name , url , mode , iconimage , fanart ) :
 if 86 - 86: I11i * o0oOOo0O0Ooo - I1IiiI . I11i % Oo0Ooo / I1Ii111
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 11 - 11: I1ii11iIi11i * IiII + iII111i / iII111i
 iiii1I1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage="
 IIIiIiI11iIi = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 IIIiIiI11iIi . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IIIiIiI11iIi . setProperty ( 'fanart_image' , fanart )
 IIIiIiI11iIi . setProperty ( 'IsPlayable' , 'true' )
 oooOO0OO0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiii1I1 , listitem = IIIiIiI11iIi )
 return oooOO0OO0O
 if 78 - 78: o00O0oo / o0oOOo0O0Ooo % I11i
def oO00OoOO ( name , url ) :
 if 18 - 18: o0O0 - I11i % OoOoOO00 + I1IiiI + II111iiii + OoOoOO00
 if 91 - 91: I11i + o0O0 . I1ii11iIi11i
 if 'https://team.com' in url :
  if 71 - 71: IIIIII11i1I % Ii1I / I1Ii111 / oO0o
  url = url . replace ( 'https://team.com' , 'https://verystream.com' )
  if 66 - 66: oO0o - Ii1I * o0o0OOO0o0 + I11i + Ii1I - Oo0Ooo
 if 'https://mybox.com' in url :
  if 17 - 17: IiII
  url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
  if 22 - 22: ooOoO0o + Oo0Ooo
 if 'https://drive.com' in url :
  if 24 - 24: I11i % OoOoOO00 + IIIIII11i1I . II111iiii . iII111i
  url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
  if 17 - 17: iII111i . o0oOOo0O0Ooo . o0O0 / iII111i
 if 'https://https://vidcloud.co/' in url :
  if 57 - 57: ooOoO0o
  url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
  if 67 - 67: OOooOOo . o0O0
 if 'https://gounlimited.to' in url :
  if 87 - 87: IiII % o00O0oo
  url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
  if 83 - 83: o0oOOo0O0Ooo - ooOoO0o
  if 35 - 35: OoOoOO00 - Oo0Ooo + OoOoOO00
  if 86 - 86: Oo0Ooo + I11i . II111iiii - o00O0oo
 import resolveurl
 if 51 - 51: I11i
 I11IIIiIi11 = urlresolver . HostedMediaFile ( url )
 if 39 - 39: o00O0oo % I1IiiI % I11i . OoOoOO00
 if 86 - 86: OOooOOo * OoO0O00
 if not I11IIIiIi11 :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
  return False
  if 71 - 71: Oo0Ooo - I1Ii111 . I1ii11iIi11i % OoO0O00 + I1Ii111
 try :
  IIi11I1 = I11IIIiIi11 . resolve ( )
  if not IIi11I1 or not isinstance ( IIi11I1 , basestring ) :
   try : iiiI111I = IIi11I1 . msg
   except : iiiI111I = url
   raise Exception ( iiiI111I )
 except Exception as oo000ii :
  try : iiiI111I = str ( oo000ii )
  except : iiiI111I = url
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado, reportalo en nuesto grupo de telegram [COLOR ligthblue] https://t.me/OficialNetai [/COLOR]  ,5000)" )
  return False
  if 75 - 75: OoO0O00 % OOooOOo / I1ii11iIi11i
  if 56 - 56: OoO0O00 % II111iiii * Oo0Ooo . OOooOOo * I1IiiI
  if 23 - 23: II111iiii
 Oo0O0O0ooO0O = oo000 . getSetting ( 'notificar' )
 if Oo0O0O0ooO0O == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
  if 39 - 39: Ii1I - iII111i % IIIIII11i1I * OOooOOo - I1Ii111 / IIIIII11i1I
  if 29 - 29: iII111i
  ooooIIIII1iii11 = xbmcgui . ListItem ( path = IIi11I1 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooooIIIII1iii11 )
  if 35 - 35: IiII / IIII / o0oOOo0O0Ooo - Oo0Ooo + o0oOOo0O0Ooo . IIII
 else :
  if 81 - 81: IIIIII11i1I * I1Ii111 - iII111i * o00O0oo % I11i * I11i
  ooooIIIII1iii11 = xbmcgui . ListItem ( path = IIi11I1 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooooIIIII1iii11 )
  if 59 - 59: Oo0Ooo
  if 7 - 7: I1Ii111 * I1ii11iIi11i / Ii1I * II111iiii
  if 84 - 84: I1Ii111 . IIIIII11i1I
def II1i111 ( ) :
 if 50 - 50: o0o0OOO0o0 % OoOoOO00
 if 21 - 21: OoO0O00 - Oo0Ooo
 OO0OoOOO0 = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 OO0OoOOO0 . doModal ( )
 if not OO0OoOOO0 . isConfirmed ( ) :
  return None ;
 OOOooo = OO0OoOOO0 . getText ( ) . strip ( )
 if 90 - 90: o0O0 + o0oOOo0O0Ooo * iII111i / o00O0oo . Ii1I + Ii1I
 if 40 - 40: o0O0 / I11i % II111iiii % iII111i / I1ii11iIi11i
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 62 - 62: OoOoOO00 - I11i
  O0O0oOOo0O = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + OOOooo + '&language=es-ES' ) )
  if 62 - 62: OoOoOO00 + oO0o % o0o0OOO0o0
  if 28 - 28: iII111i . OoOoOO00
  return 'android'
  if 10 - 10: OOooOOo / oO0o
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 15 - 15: IIIIII11i1I . I11i / IIIIII11i1I * ooOoO0o - I1ii11iIi11i % iII111i
  O0O0oOOo0O = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + OOOooo + '&language=es-ES' )
  if 57 - 57: I1IiiI % I11i % IiII
  if 45 - 45: iII111i + o0oOOo0O0Ooo * II111iiii
  return 'windows'
  if 13 - 13: OoO0O00 * IiII - o00O0oo / I1Ii111 + ooOoO0o + o0o0OOO0o0
  if 39 - 39: Oo0Ooo - OoO0O00
def oO0oooooo ( ) :
 if 65 - 65: o0o0OOO0o0 + oO0o
 try :
  if 59 - 59: OoO0O00 + ooOoO0o . IIII - I1IiiI % Oo0Ooo / I1IiiI
  OoOO0o = i1II1 ( ii111iI1iIi1 )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 88 - 88: oO0o . I1IiiI % OoO0O00 / I1Ii111
   try :
    if 89 - 89: o0oOOo0O0Ooo / IiII
    all = IiiiiI1i1Iii
    if 14 - 14: I1Ii111 . I1ii11iIi11i * o0O0 + o0oOOo0O0Ooo - o0O0 + I1Ii111
   except :
    pass
    if 18 - 18: IiII - Ii1I - I1ii11iIi11i - I1ii11iIi11i
  Ii1Io0OO0o0o00o = i1II1 ( all )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( Ii1Io0OO0o0o00o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    if 54 - 54: oO0o + I1ii11iIi11i / IIIIII11i1I . I1ii11iIi11i * I11i
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 1 - 1: I11i * OOooOOo . OoOoOO00 / oO0o . iII111i + oO0o
   except :
    pass
 except :
  pass
  if 17 - 17: oO0o + OOooOOo / o00O0oo / IIIIII11i1I * I1Ii111
def II1iiIIiIii ( ) :
 if 5 - 5: Oo0Ooo / ooOoO0o / OoOoOO00 % OoO0O00
 try :
  if 50 - 50: o00O0oo / I11i * o00O0oo
  OOo = i1II1 ( oo0OOo0 )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OOo )
  for IiiiiI1i1Iii in i11i1 :
   if 34 - 34: I1IiiI * I1IiiI % OoO0O00 + IIIIII11i1I * Oo0Ooo % o00O0oo
   try :
    if 25 - 25: ooOoO0o + I11i . Ii1I % I11i * I1Ii111
    OO0oo = IiiiiI1i1Iii
    if 32 - 32: II111iiii - IIII
   except :
    pass
    if 53 - 53: OoO0O00 - o0o0OOO0o0
  oo0O00Oooo0O0 = i1II1 ( OO0oo )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( oo0O00Oooo0O0 )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    if 87 - 87: IiII . I1ii11iIi11i
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 17 - 17: o00O0oo . II111iiii
   except :
    pass
 except :
  pass
  if 5 - 5: iII111i + I1IiiI + I1IiiI . IIII - o0O0
def o00oo0000 ( ) :
 if 44 - 44: oO0o % Oo0Ooo
 try :
  if 90 - 90: o0oOOo0O0Ooo + OoO0O00 % OoO0O00
  Ii1IIii11 = i1II1 ( O0ooO0Oo00o )
  i11i1 = re . compile ( OOO00O0O ) . findall ( Ii1IIii11 )
  for IiiiiI1i1Iii in i11i1 :
   if 35 - 35: IIIIII11i1I / iII111i * OoO0O00 . o0oOOo0O0Ooo / oO0o
   try :
    Iii11i = IiiiiI1i1Iii
   except :
    pass
    if 73 - 73: oO0o - I11i - IiII - I1ii11iIi11i
  OoOO0o = i1II1 ( Iii11i )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 65 - 65: Ii1I
   except :
    pass
 except :
  pass
  if 7 - 7: o0o0OOO0o0 . I11i / iII111i . I1Ii111 * ooOoO0o - o0oOOo0O0Ooo
def I1ii1iI1II11ii ( ) :
 if 8 - 8: o0O0 * I1IiiI
 try :
  if 73 - 73: Ii1I / IiII / ooOoO0o / OOooOOo
  OoOO0o = i1II1 ( db2 )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 11 - 11: I11i + o0o0OOO0o0 - OoO0O00 / OOooOOo
   try :
    if 34 - 34: o0O0
    i1iI1 = IiiiiI1i1Iii
    if 44 - 44: iII111i - o00O0oo / o0oOOo0O0Ooo * OOooOOo * oO0o
   except :
    pass
    if 73 - 73: Ii1I - I1ii11iIi11i * OoOoOO00 / II111iiii * I1Ii111 % o0oOOo0O0Ooo
    if 56 - 56: OoO0O00 * oO0o . oO0o . iII111i
  OoOO0o = i1II1 ( i1iI1 )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 24 - 24: oO0o . ooOoO0o * o00O0oo % IIIIII11i1I / I1Ii111
   except :
    pass
 except :
  pass
  if 58 - 58: I1ii11iIi11i - iII111i % I1IiiI . I1ii11iIi11i % OOooOOo % o0o0OOO0o0
def oOo0OooOo ( ) :
 if 51 - 51: ooOoO0o . oO0o
 try :
  if 45 - 45: OoOoOO00 - oO0o / I1IiiI . iII111i
  OoOO0o = i1II1 ( i1I1ii11i1Iii )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 5 - 5: Ii1I . Oo0Ooo % Oo0Ooo
   try :
    if 56 - 56: OoO0O00 - ooOoO0o - OoOoOO00
    I1i1I = IiiiiI1i1Iii
    if 35 - 35: II111iiii - I1ii11iIi11i
   except :
    pass
    if 99 - 99: OOooOOo * II111iiii . OoO0O00 % oO0o
    if 76 - 76: I1IiiI . IIII * IIIIII11i1I * I1Ii111 . I11i . II111iiii
  OoOO0o = i1II1 ( I1i1I )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 21 - 21: Ii1I / I11i / Oo0Ooo % I1Ii111
   except :
    pass
 except :
  pass
  if 2 - 2: II111iiii - o0oOOo0O0Ooo / IiII % I1IiiI
def oo0O0o ( ) :
 if 87 - 87: oO0o / I1IiiI * o0o0OOO0o0 / Ii1I
 try :
  if 19 - 19: IIII + OoOoOO00 . I1ii11iIi11i - oO0o
  OoOO0o = i1II1 ( o0OIiII )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 16 - 16: IiII + o0O0 / Ii1I
   try :
    if 82 - 82: o0o0OOO0o0 * II111iiii % o0oOOo0O0Ooo - OoO0O00
    OO0 = IiiiiI1i1Iii
    if 62 - 62: OoOoOO00 / o0O0 . I1ii11iIi11i * Ii1I
   except :
    pass
    if 21 - 21: Ii1I
  OoOO0o = i1II1 ( OO0 )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 81 - 81: ooOoO0o / Oo0Ooo - o0O0 * IIII . I1ii11iIi11i * iII111i
   except :
    pass
 except :
  pass
  if 95 - 95: I1ii11iIi11i
def O0OOO000o0o ( ) :
 if 19 - 19: o0oOOo0O0Ooo - OoOoOO00 - I1Ii111 / I1Ii111 + I11i
 try :
  if 51 - 51: oO0o % I11i * OoO0O00 . II111iiii
  OoOO0o = i1II1 ( Iii1I1I11iiI1 )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 77 - 77: o0oOOo0O0Ooo
   try :
    if 42 - 42: o00O0oo * IIII . o0o0OOO0o0 * I1ii11iIi11i + I11i
    i1i1II11II1 = IiiiiI1i1Iii
    if 5 - 5: oO0o - iII111i % IiII - o0oOOo0O0Ooo . I1ii11iIi11i + IIIIII11i1I
   except :
    pass
    if 47 - 47: I1IiiI - Oo0Ooo - IIIIII11i1I
    if 46 - 46: o00O0oo . I1Ii111 * OOooOOo . OoO0O00 + iII111i
  OoOO0o = i1II1 ( i1i1II11II1 )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 72 - 72: o0oOOo0O0Ooo + I1Ii111
   except :
    pass
 except :
  pass
  if 91 - 91: Oo0Ooo % OOooOOo . Ii1I + o00O0oo + Ii1I
def o00OOo ( ) :
 if 87 - 87: OOooOOo % I1ii11iIi11i
 try :
  if 77 - 77: Oo0Ooo - OoOoOO00 . IiII
  OoOO0o = i1II1 ( ii1I )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 26 - 26: Ii1I * o0o0OOO0o0 . OoOoOO00
   try :
    if 59 - 59: I1IiiI + OoOoOO00 - Ii1I
    OooOo000o0o = IiiiiI1i1Iii
    if 42 - 42: IiII % I1Ii111
   except :
    pass
    if 60 - 60: I11i / IIII - o0oOOo0O0Ooo . oO0o + I1IiiI
    if 43 - 43: Oo0Ooo / o0oOOo0O0Ooo % Ii1I - I1Ii111
  OoOO0o = i1II1 ( OooOo000o0o )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 62 - 62: ooOoO0o
   except :
    pass
 except :
  pass
  if 63 - 63: I1Ii111 + o0O0 * IiII / Ii1I / oO0o * Oo0Ooo
def OOoO00ooO ( ) :
 if 12 - 12: o0O0 % I1ii11iIi11i + IiII - OoOoOO00 . o00O0oo / I1ii11iIi11i
 try :
  if 51 - 51: I1Ii111 . I1ii11iIi11i
  OoOO0o = i1II1 ( oO0 )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 73 - 73: OoO0O00 . I1ii11iIi11i / IIII % o00O0oo
   try :
    if 65 - 65: o0o0OOO0o0 - I1ii11iIi11i - o00O0oo
    Ii1iIi111I1i = IiiiiI1i1Iii
    if 4 - 4: IIIIII11i1I - oO0o - o0o0OOO0o0 - ooOoO0o % II111iiii / OOooOOo
   except :
    pass
    if 50 - 50: o0O0 + OoOoOO00
    if 31 - 31: o00O0oo
  OoOO0o = i1II1 ( Ii1iIi111I1i )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 78 - 78: II111iiii + Ii1I + IIII / Ii1I % Oo0Ooo % o0o0OOO0o0
   except :
    pass
 except :
  pass
  if 83 - 83: Oo0Ooo % I11i % Ii1I % IIII . iII111i % I1IiiI
  if 47 - 47: Ii1I
def oo0ooooO ( ) :
 if 12 - 12: o0oOOo0O0Ooo
 try :
  if 2 - 2: OoOoOO00 - I1ii11iIi11i + ooOoO0o . o0oOOo0O0Ooo
  OoOO0o = i1II1 ( OO )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 25 - 25: IiII
   try :
    if 34 - 34: I11i . Oo0Ooo % I1IiiI
    iI11Ii111 = IiiiiI1i1Iii
    if 54 - 54: I11i % IIIIII11i1I . I11i * I1Ii111 + I11i % OoOoOO00
   except :
    pass
    if 23 - 23: IIII - I1Ii111 + o00O0oo - I11i * I11i . oO0o
    if 47 - 47: IiII % Oo0Ooo
  OoOO0o = i1II1 ( iI11Ii111 )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 11 - 11: I1ii11iIi11i % o00O0oo - OOooOOo - IiII + Ii1I
   except :
    pass
 except :
  pass
  if 98 - 98: IIIIII11i1I + o00O0oo - OOooOOo
  if 79 - 79: I1Ii111 / IIII . I11i - iII111i
def Ii1ii11IIIi ( ) :
 if 82 - 82: IiII * Oo0Ooo . Ii1I . iII111i + I1Ii111 / I1ii11iIi11i
 try :
  if 58 - 58: IIII / o0O0 + I1IiiI + o0O0 . Oo0Ooo + o0oOOo0O0Ooo
  OoOO0o = i1II1 ( Ii1I1i )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 37 - 37: ooOoO0o . oO0o % o0o0OOO0o0 * OoOoOO00
   try :
    if 71 - 71: oO0o / Ii1I + I1Ii111
    i11i11 = IiiiiI1i1Iii
    if 14 - 14: II111iiii
   except :
    pass
    if 73 - 73: o0O0 + IiII . OOooOOo
    if 46 - 46: OOooOOo - Ii1I / I11i - OoO0O00 + IiII
  OoOO0o = i1II1 ( i11i11 )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 58 - 58: Ii1I / Ii1I + o0O0 + ooOoO0o - I11i . I1Ii111
   except :
    pass
    if 15 - 15: o0O0 * I11i % o0o0OOO0o0 . I11i . ooOoO0o
 except :
  pass
  if 97 - 97: IiII
  if 80 - 80: I1ii11iIi11i . o00O0oo
def I1I11ii ( ) :
 if 93 - 93: iII111i % I11i . I1IiiI / IIIIII11i1I * IiII
 try :
  if 29 - 29: Ii1I
  OoOO0o = i1II1 ( O0O0OOOOoo )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 86 - 86: o0oOOo0O0Ooo . o0o0OOO0o0
   try :
    if 2 - 2: OoO0O00
    o0o0O00 = IiiiiI1i1Iii
    if 35 - 35: Oo0Ooo
   except :
    pass
    if 94 - 94: I11i
    if 100 - 100: OOooOOo / OoOoOO00 - I1ii11iIi11i % o00O0oo - Oo0Ooo
  OoOO0o = i1II1 ( o0o0O00 )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 17 - 17: ooOoO0o / Ii1I % oO0o
   except :
    pass
    if 71 - 71: o0o0OOO0o0 . IIII . OOooOOo
 except :
  pass
  if 68 - 68: II111iiii % IiII * OOooOOo * o0o0OOO0o0 * o0oOOo0O0Ooo + I1IiiI
def o00OoO0oO00 ( ) :
 if 2 - 2: Oo0Ooo
 try :
  if 45 - 45: OoO0O00 / II111iiii
  OoOO0o = i1II1 ( Ii1I1Ii )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 10 - 10: IIIIII11i1I - IiII * Oo0Ooo % Oo0Ooo * o0o0OOO0o0 - iII111i
   try :
    if 97 - 97: o0oOOo0O0Ooo % IIII + IIII - OOooOOo / o00O0oo * I1ii11iIi11i
    iIii1iII1Ii = IiiiiI1i1Iii
    if 50 - 50: o00O0oo
   except :
    pass
    if 22 - 22: ooOoO0o * I1IiiI . o0oOOo0O0Ooo - OOooOOo
  OoOO0o = i1II1 ( iIii1iII1Ii )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 90 - 90: IiII
   except :
    pass
 except :
  pass
  if 94 - 94: ooOoO0o / iII111i * IIII - I11i
  if 44 - 44: o00O0oo % II111iiii - IIIIII11i1I * iII111i + oO0o * I1Ii111
def IiI1iI1IiiIi1 ( ) :
 if 90 - 90: I1IiiI + ooOoO0o - OoO0O00 . ooOoO0o
 try :
  if 60 - 60: Ii1I . Ii1I / IIIIII11i1I
  OoOO0o = i1II1 ( OO0Oooo0oOO0O )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 45 - 45: I1IiiI . II111iiii % IIIIII11i1I . I11i % o0o0OOO0o0 % Oo0Ooo
   try :
    if 58 - 58: Oo0Ooo . I11i - II111iiii * Oo0Ooo % II111iiii / I1ii11iIi11i
    oO0oI1I1 = IiiiiI1i1Iii
    if 99 - 99: o0O0 / Oo0Ooo - o00O0oo * iII111i % I1ii11iIi11i
   except :
    pass
    if 13 - 13: OOooOOo
    if 70 - 70: IIII + I1IiiI . IiII * o00O0oo
  OoOO0o = i1II1 ( oO0oI1I1 )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 2 - 2: OoO0O00 . I1Ii111 . o0o0OOO0o0
   except :
    pass
 except :
  pass
  if 42 - 42: I1Ii111 % IiII / OOooOOo - IiII * II111iiii
  if 19 - 19: IiII * I1ii11iIi11i % II111iiii
def iiI1Ii1I ( ) :
 if 28 - 28: I1Ii111 % o0O0
 try :
  if 48 - 48: II111iiii % IiII
  OoOO0o = i1II1 ( oOO0O00Oo0O0o )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 29 - 29: IIIIII11i1I + II111iiii % ooOoO0o
   try :
    if 93 - 93: I11i % Oo0Ooo
    Ooo0o0oo0 = IiiiiI1i1Iii
    if 87 - 87: I11i / o0o0OOO0o0 + Oo0Ooo
   except :
    pass
  OoOO0o = i1II1 ( Ooo0o0oo0 )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 93 - 93: Oo0Ooo + IiII % o0O0
   except :
    pass
 except :
  pass
  if 21 - 21: I1Ii111
def iIiI1I1IIi11 ( ) :
 if 9 - 9: o0O0 + IIIIII11i1I - ooOoO0o / OoOoOO00 % iII111i / o0o0OOO0o0
 try :
  if 60 - 60: iII111i
  OoOO0o = i1II1 ( I1iIIiiIIi1i )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 1 - 1: I11i . II111iiii % I11i - IIIIII11i1I % OoOoOO00 + iII111i
   try :
    if 2 - 2: Oo0Ooo * IiII / I11i . ooOoO0o / o0o0OOO0o0
    o00O0OO = IiiiiI1i1Iii
    if 64 - 64: o0o0OOO0o0 . II111iiii / o0oOOo0O0Ooo + Ii1I * o00O0oo % I1IiiI
   except :
    pass
    if 89 - 89: IIII . o0o0OOO0o0 % oO0o . oO0o - OoO0O00
    if 56 - 56: ooOoO0o
  OoOO0o = i1II1 ( o00O0OO )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 21 - 21: Oo0Ooo / IIII + o0O0 - ooOoO0o / oO0o / o0oOOo0O0Ooo
   except :
    pass
 except :
  pass
  if 69 - 69: I1ii11iIi11i . I11i
  if 53 - 53: ooOoO0o
def OO000 ( ) :
 if 95 - 95: o0o0OOO0o0
 try :
  if 46 - 46: o0o0OOO0o0
  OoOO0o = i1II1 ( oOOo0O00o )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 29 - 29: o0oOOo0O0Ooo . I11i % Ii1I * o0oOOo0O0Ooo - Ii1I * Oo0Ooo
   try :
    if 35 - 35: o0oOOo0O0Ooo - o0o0OOO0o0 . OoOoOO00
    OOOoO0 = IiiiiI1i1Iii
    if 85 - 85: Oo0Ooo / OoO0O00 % o0oOOo0O0Ooo
   except :
    pass
    if 49 - 49: II111iiii % I11i + IIII . o0oOOo0O0Ooo % IIIIII11i1I * I1Ii111
    if 67 - 67: OoOoOO00
  OoOO0o = i1II1 ( OOOoO0 )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 5 - 5: o0oOOo0O0Ooo . OoO0O00
   except :
    pass
 except :
  pass
  if 57 - 57: I1ii11iIi11i
def iii1IIiI ( ) :
 if 33 - 33: ooOoO0o
 try :
  if 98 - 98: I11i % o0oOOo0O0Ooo
  OoOO0o = i1II1 ( OOOiiiiI )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 95 - 95: Oo0Ooo - IIII - I1Ii111 + IIII % iII111i . I1ii11iIi11i
   try :
    if 41 - 41: I1IiiI + IiII . OoOoOO00 - o0oOOo0O0Ooo * Ii1I . OOooOOo
    oooO00Oo = IiiiiI1i1Iii
    if 86 - 86: o0oOOo0O0Ooo + o0O0 + o0o0OOO0o0
   except :
    pass
    if 9 - 9: o0O0 + o0oOOo0O0Ooo % o0O0 % o0o0OOO0o0 + Oo0Ooo
    if 59 - 59: OoOoOO00
  OoOO0o = i1II1 ( oooO00Oo )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 48 - 48: I1IiiI * o00O0oo * OOooOOo . OOooOOo * ooOoO0o - o00O0oo
   except :
    pass
 except :
  pass
  if 14 - 14: iII111i + II111iiii
  if 83 - 83: iII111i / II111iiii + o0oOOo0O0Ooo . IIIIII11i1I * I1Ii111 + o0o0OOO0o0
def iiii1i1II1 ( ) :
 if 63 - 63: Oo0Ooo % iII111i - IIIIII11i1I
 try :
  if 17 - 17: I1ii11iIi11i
  OoOO0o = i1II1 ( OOoO )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 88 - 88: OoO0O00
   try :
    if 28 - 28: oO0o * Ii1I / IIII
    Oo0O = IiiiiI1i1Iii
    if 88 - 88: I1ii11iIi11i % I1Ii111 % iII111i . II111iiii % Ii1I
   except :
    pass
    if 38 - 38: IIII + OoO0O00 . OoOoOO00
    if 19 - 19: IIIIII11i1I - Ii1I - o00O0oo - I11i . IIIIII11i1I . IIII
  OoOO0o = i1II1 ( Oo0O )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 48 - 48: IIIIII11i1I + o0o0OOO0o0
   except :
    pass
 except :
  pass
  if 60 - 60: ooOoO0o + IIIIII11i1I . o0o0OOO0o0 / OoOoOO00 . Oo0Ooo
  if 14 - 14: I1Ii111
def o0oo0Ooooo0 ( ) :
 if 76 - 76: OoOoOO00 * OoO0O00 * I1IiiI + IIII * IIII
 try :
  if 35 - 35: Ii1I
  OoOO0o = i1II1 ( iiIiI1i1 )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 73 - 73: I1IiiI - iII111i
   try :
    if 2 - 2: o0oOOo0O0Ooo / IIII
    OoO = IiiiiI1i1Iii
    if 71 - 71: OOooOOo - OoO0O00 * oO0o
   except :
    pass
    if 38 - 38: Oo0Ooo / o0O0
    if 13 - 13: Oo0Ooo
  OoOO0o = i1II1 ( OoO )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 77 - 77: II111iiii - Oo0Ooo / IiII / o0O0 / OOooOOo
   except :
    pass
 except :
  pass
  if 56 - 56: OoO0O00 * I1IiiI
  if 85 - 85: OoO0O00 % I11i * Oo0Ooo
def IiI ( ) :
 if 60 - 60: IIII
 try :
  if 98 - 98: o0O0
  OoOO0o = i1II1 ( IiIi11iI )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 34 - 34: Oo0Ooo * ooOoO0o * ooOoO0o / iII111i
   try :
    if 28 - 28: OOooOOo - IiII + I11i + o00O0oo / Oo0Ooo
    iiiii11I1 = IiiiiI1i1Iii
    if 16 - 16: I1IiiI . o00O0oo % OoOoOO00 % I1Ii111
   except :
    pass
    if 50 - 50: o0o0OOO0o0 + Ii1I
    if 96 - 96: OOooOOo
  OoOO0o = i1II1 ( iiiii11I1 )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 92 - 92: oO0o / II111iiii + iII111i
   except :
    pass
 except :
  pass
  if 87 - 87: I11i % Oo0Ooo
  if 72 - 72: I1Ii111 . I1Ii111 - iII111i
def III1II1i ( ) :
 if 3 - 3: IIIIII11i1I
 try :
  if 35 - 35: o0o0OOO0o0 . I1IiiI + oO0o + I1Ii111 + OoOoOO00
  OoOO0o = i1II1 ( i11I1IiII1i1i )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 65 - 65: I1IiiI * I1ii11iIi11i / I1ii11iIi11i . I11i
   try :
    if 87 - 87: o0oOOo0O0Ooo * iII111i % oO0o * oO0o
    O0O = IiiiiI1i1Iii
    if 51 - 51: IiII + OOooOOo + IIIIII11i1I + IIIIII11i1I % Ii1I
   except :
    pass
    if 29 - 29: o0O0
  OoOO0o = i1II1 ( O0O )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 41 - 41: I1IiiI % IIIIII11i1I
   except :
    pass
 except :
  pass
  if 10 - 10: IIIIII11i1I . OoOoOO00 + o00O0oo
  if 66 - 66: OOooOOo % Ii1I
def iI1ii11Ii ( ) :
 if 97 - 97: IIII + IiII - OOooOOo % IiII - Ii1I
 try :
  if 37 - 37: OoO0O00
  OoOO0o = i1II1 ( I1111i )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 69 - 69: I1ii11iIi11i + IIIIII11i1I
   try :
    if 7 - 7: IIIIII11i1I + IiII
    Iiii1I = IiiiiI1i1Iii
    if 56 - 56: II111iiii - Oo0Ooo . o0oOOo0O0Ooo
   except :
    pass
    if 81 - 81: o0o0OOO0o0 / I11i * o0o0OOO0o0 . I1IiiI
    if 61 - 61: OOooOOo * I1Ii111 + IIII . Oo0Ooo % ooOoO0o . IIII
  OoOO0o = i1II1 ( Iiii1I )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 53 - 53: IIII * o0o0OOO0o0 / Oo0Ooo / I1ii11iIi11i % iII111i
   except :
    pass
 except :
  pass
  if 39 - 39: OOooOOo / OoO0O00 . OOooOOo * iII111i / I11i
def II111 ( ) :
 if 94 - 94: IIIIII11i1I % o0O0 . IiII
 try :
  if 85 - 85: I1Ii111 * OoOoOO00 % I1ii11iIi11i - o0O0
  OoOO0o = i1II1 ( o00O0O )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 37 - 37: o0o0OOO0o0 . oO0o * oO0o * o0oOOo0O0Ooo * I1IiiI
   try :
    if 83 - 83: o0o0OOO0o0 / IIII
    OOo000OO000 = IiiiiI1i1Iii
    if 83 - 83: Ii1I % IiII + ooOoO0o % II111iiii + I1IiiI
   except :
    pass
  OoOO0o = i1II1 ( OOo000OO000 )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 65 - 65: Oo0Ooo % IiII + I1IiiI / OoO0O00
   except :
    pass
 except :
  pass
  if 52 - 52: o00O0oo % I1Ii111 * I1ii11iIi11i % ooOoO0o + I1Ii111 / IIIIII11i1I
def oo000o ( ) :
 if 95 - 95: IiII - o0O0 * ooOoO0o / OOooOOo / o0oOOo0O0Ooo + I1IiiI
 try :
  if 37 - 37: ooOoO0o . IIII + I1Ii111 + ooOoO0o . o0o0OOO0o0 / o00O0oo
  OoOO0o = i1II1 ( Iii1I1111ii )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 29 - 29: o0o0OOO0o0 . o0O0 - o0oOOo0O0Ooo
   try :
    if 68 - 68: Oo0Ooo + o0oOOo0O0Ooo / IiII
    oOooo00000 = IiiiiI1i1Iii
    if 26 - 26: I1IiiI
   except :
    pass
  OoOO0o = i1II1 ( oOooo00000 )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 34 - 34: o0O0 * IIII
   except :
    pass
 except :
  pass
  if 97 - 97: II111iiii % IiII / oO0o / oO0o
def OoO00ooO ( ) :
 if 15 - 15: II111iiii
 try :
  if 13 - 13: ooOoO0o * o0oOOo0O0Ooo * IiII * o0oOOo0O0Ooo % o0o0OOO0o0 / I1ii11iIi11i
  OoOO0o = i1II1 ( i111iIi1i1II1 )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 100 - 100: o0o0OOO0o0 . o00O0oo - Oo0Ooo . II111iiii / o0oOOo0O0Ooo
   try :
    if 71 - 71: IIII * oO0o . ooOoO0o
    i1ii1iiIi1II = IiiiiI1i1Iii
    if 98 - 98: OOooOOo - o00O0oo . o0o0OOO0o0 % II111iiii
   except :
    pass
  OoOO0o = i1II1 ( i1ii1iiIi1II )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 69 - 69: iII111i + IIIIII11i1I * I1IiiI . I1Ii111 % I11i
   except :
    pass
 except :
  pass
  if 96 - 96: o0O0 . o0O0 - ooOoO0o / ooOoO0o
def OoOoiIIi11i1i1i1I ( ) :
 if 13 - 13: IIIIII11i1I + I1Ii111 / Oo0Ooo
 try :
  if 67 - 67: I11i - I11i * OOooOOo - IIIIII11i1I % IiII
  OoOO0o = i1II1 ( Ii1IIiI1i )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 44 - 44: I1ii11iIi11i . OoOoOO00 + I1Ii111
   try :
    if 16 - 16: Ii1I - OOooOOo / IIII
    i11oo = IiiiiI1i1Iii
    if 5 - 5: OOooOOo
   except :
    pass
  OoOO0o = i1II1 ( i11oo )
  i11i1 = re . compile ( ooOOoooooo ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO in i11i1 :
   try :
    IiiiIiIi ( oOoOOo0O , OOOooo , OooO0OO )
    if 19 - 19: o0o0OOO0o0 . iII111i / I11i
   except :
    pass
    if 68 - 68: o0O0 / OoO0O00 * ooOoO0o / IiII
 except :
  pass
  if 88 - 88: Ii1I
  if 1 - 1: OoO0O00
  if 48 - 48: o0O0 * I11i - o0O0 - I1Ii111 + I1Ii111
def IiiiIiIi ( thumb , name , url ) :
 if 40 - 40: II111iiii . Oo0Ooo
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( oo00O00oO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   Iiii ( name , url , '' , i1ii1iIII , O0oOO0o0 )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 2 - 2: OoOoOO00 * IiII - IiII + OoO0O00 % I11i / I11i
  if 'tvg-logo' in thumb :
   thumb = re . compile ( oo00O00oO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 3 - 3: OoO0O00
   O0OoO0o ( name , url , 4 , o0OoO000O , O0oOO0o0 )
   if 1 - 1: o0O0 % ooOoO0o * iII111i - o0oOOo0O0Ooo
  else :
   if 49 - 49: IiII - IIIIII11i1I % I11i
   O0OoO0o ( name , url , 4 , o0OoO000O , O0oOO0o0 )
   if 72 - 72: I1ii11iIi11i + o0o0OOO0o0 . I11i + I11i
   if 94 - 94: II111iiii % OoO0O00 / I1ii11iIi11i
def iI ( name , url , thumb , id , trailer ) :
 if 24 - 24: I1ii11iIi11i * IiII
 if 85 - 85: o0oOOo0O0Ooo . o0O0 % I1Ii111 % ooOoO0o
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 80 - 80: IiII * ooOoO0o / Oo0Ooo % IiII / Oo0Ooo
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( oo00O00oO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   Iiii ( name , url , '' , i1ii1iIII , O0oOO0o0 )
 else :
  ooOooo000oOO = oo000 . getSetting ( 'Fontcolor' )
  if 42 - 42: OoOoOO00 / II111iiii . oO0o * IIIIII11i1I . II111iiii * I1IiiI
  name = '[COLOR %s]' % ooOooo000oOO + name + '[/COLOR]'
  if 44 - 44: OoOoOO00 . I1ii11iIi11i / II111iiii + o0o0OOO0o0
  if 'tvg-logo' in thumb :
   thumb = re . compile ( oo00O00oO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   OO00Oo = oo000 . getSetting ( 'selecton' )
   if OO00Oo == 'true' :
    if 27 - 27: I1Ii111
    O0OO0ooO00 ( name , url , 1 , thumb , thumb , id , trailer )
    if 83 - 83: Oo0Ooo
   else :
    if 63 - 63: OoO0O00 * OOooOOo / ooOoO0o - IiII . Oo0Ooo + IIIIII11i1I
    O0OO0ooO00 ( name , url , 130 , thumb , thumb , id , trailer )
    if 44 - 44: OoOoOO00 % I1ii11iIi11i % Ii1I
  else :
   if 9 - 9: oO0o % OoO0O00 - o00O0oo
   if OO00Oo == 'true' :
    if 43 - 43: OOooOOo % OOooOOo
    O0OO0ooO00 ( name , url , 1 , thumb , thumb , id , trailer )
    if 46 - 46: oO0o % Oo0Ooo . IIIIII11i1I . I1IiiI * o0O0 / OoO0O00
   else :
    if 7 - 7: IiII - I1IiiI * ooOoO0o - Ii1I - o0oOOo0O0Ooo
    O0OO0ooO00 ( name , url , 130 , thumb , thumb , id , trailer )
    if 41 - 41: I1ii11iIi11i - IIII % o0oOOo0O0Ooo . IIII - ooOoO0o
def i1I111Ii ( name , trailer ) :
 if 31 - 31: I1ii11iIi11i
 if 73 - 73: o0O0 . I1IiiI / Ii1I - OoO0O00 % II111iiii
 OooO0OO = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
 O000iIIiIi = OooO0OO
 I111I1I = xbmcgui . ListItem ( name , trailer , path = O000iIIiIi )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I111I1I )
 return
 if 54 - 54: o0oOOo0O0Ooo + ooOoO0o % ooOoO0o % Ii1I
 if 25 - 25: IIIIII11i1I - oO0o
def Iii1IIIIIII ( name , url ) :
 import urlresolver
 from urlresolver import common
 if 27 - 27: OOooOOo + I11i * o0O0
 I11IIIiIi11 = urlresolver . HostedMediaFile ( url )
 if 83 - 83: Oo0Ooo
 if not I11IIIiIi11 :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
  if 72 - 72: ooOoO0o
  return False
  if 87 - 87: OoOoOO00
  if 48 - 48: oO0o * IiII * Oo0Ooo + II111iiii - OoO0O00
 try :
  IIi11I1 = I11IIIiIi11 . resolve ( )
  if not IIi11I1 or not isinstance ( IIi11I1 , basestring ) :
   try : iiiI111I = IIi11I1 . msg
   except : iiiI111I = url
   raise Exception ( iiiI111I )
 except Exception as oo000ii :
  try : iiiI111I = str ( oo000ii )
  except : iiiI111I = url
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,5000)" )
  if 38 - 38: I11i / Oo0Ooo % II111iiii - o0o0OOO0o0 * IIIIII11i1I / I11i
  return False
  if 13 - 13: OOooOOo * iII111i - IIII
 Oo0O0O0ooO0O = oo000 . getSetting ( 'notificar' )
 if Oo0O0O0ooO0O == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
 ooooIIIII1iii11 = xbmcgui . ListItem ( path = IIi11I1 )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooooIIIII1iii11 )
 if 79 - 79: IiII % Ii1I % I11i
def ii1IIiII111I ( name , url ) :
 if 87 - 87: o00O0oo - iII111i % iII111i . IiII / iII111i
 if 6 - 6: I11i / Oo0Ooo * OoO0O00 * II111iiii
 if 'https://www.rapidvideo.com/v/' in url :
  if 79 - 79: o0o0OOO0o0 % OOooOOo
  OoOO0o = i1II1 ( url )
  i11i1 = re . compile ( 'rapidvideo' ) . findall ( OoOO0o )
  for url in i11i1 :
   if 81 - 81: II111iiii + II111iiii * OOooOOo + o0o0OOO0o0
   if 32 - 32: I1IiiI . OoO0O00
   try :
    Oo0O0O0ooO0O = oo000 . getSetting ( 'notificar' )
    if Oo0O0O0ooO0O == 'true' :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    ooooIIIII1iii11 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooooIIIII1iii11 )
    if 15 - 15: I1ii11iIi11i . OOooOOo
   except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 17 - 17: II111iiii / oO0o . OOooOOo / I1ii11iIi11i
   if 38 - 38: OoOoOO00 . iII111i % o00O0oo + Oo0Ooo + I1IiiI
 else :
  if 47 - 47: OOooOOo + o0o0OOO0o0 / o0oOOo0O0Ooo
  import urlresolver
  from urlresolver import common
  if 97 - 97: iII111i / I1ii11iIi11i % I1IiiI + OoOoOO00 - o0O0
  I11IIIiIi11 = urlresolver . HostedMediaFile ( url )
  if 38 - 38: Ii1I % IIII + II111iiii + IIIIII11i1I + o0O0 / II111iiii
  if not I11IIIiIi11 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 94 - 94: IIIIII11i1I - oO0o + IiII
   if 59 - 59: ooOoO0o . I1ii11iIi11i - Oo0Ooo + Oo0Ooo
  try :
   IIi11I1 = I11IIIiIi11 . resolve ( )
   if not IIi11I1 or not isinstance ( IIi11I1 , basestring ) :
    try : iiiI111I = IIi11I1 . msg
    except : iiiI111I = url
    raise Exception ( iiiI111I )
  except Exception as oo000ii :
   try : iiiI111I = str ( oo000ii )
   except : iiiI111I = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 56 - 56: IiII + o0O0
  Oo0O0O0ooO0O = oo000 . getSetting ( 'notificar' )
  if Oo0O0O0ooO0O == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  ooooIIIII1iii11 = xbmcgui . ListItem ( path = IIi11I1 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooooIIIII1iii11 )
  if 32 - 32: o0oOOo0O0Ooo + I11i % o0O0 / I11i + iII111i
 return
 if 2 - 2: II111iiii - IIII + OOooOOo % ooOoO0o * o00O0oo
 if 54 - 54: I1IiiI - IIIIII11i1I . I1Ii111 % IIIIII11i1I + IIIIII11i1I
 if 36 - 36: I1Ii111 % II111iiii
def Iiii1Ii ( name , url ) :
 if 62 - 62: OoOoOO00 % I11i
 IIi11I1 = url
 Oo0O0O0ooO0O = oo000 . getSetting ( 'notificar' )
 if Oo0O0O0ooO0O == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  ooooIIIII1iii11 = xbmcgui . ListItem ( path = IIi11I1 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooooIIIII1iii11 )
 else :
  ooooIIIII1iii11 = xbmcgui . ListItem ( path = IIi11I1 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooooIIIII1iii11 )
 return
 if 37 - 37: ooOoO0o * OoOoOO00
def I1IIII ( name , url ) :
 if 57 - 57: I1IiiI - I1IiiI . iII111i / Ii1I / o00O0oo
 if 20 - 20: I1Ii111 * o0oOOo0O0Ooo - I11i - IiII * IIII
 if '[Youtube]' in name :
  if 6 - 6: o0O0 + I1Ii111 / oO0o + o0o0OOO0o0 % o0oOOo0O0Ooo / OOooOOo
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 45 - 45: OoO0O00
  try :
   Oo0O0O0ooO0O = oo000 . getSetting ( 'notificar' )
   if Oo0O0O0ooO0O == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    ooooIIIII1iii11 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooooIIIII1iii11 )
    if 9 - 9: ooOoO0o . OOooOOo * OoOoOO00 . OoO0O00
    if 32 - 32: I11i . iII111i % I1ii11iIi11i - o0oOOo0O0Ooo
    if 11 - 11: I1IiiI + I1ii11iIi11i
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 80 - 80: IiII % IiII % I1IiiI - II111iiii . IIIIII11i1I / I1IiiI
  if 13 - 13: I1ii11iIi11i + I1IiiI - iII111i % oO0o / o00O0oo . OoOoOO00
 else :
  if 60 - 60: oO0o . o0o0OOO0o0 % I1ii11iIi11i - IIII
  import xbmcgui
  import urlresolver
  from urlresolver import common
  if 79 - 79: OoO0O00 / iII111i . I1IiiI
  I11IIIiIi11 = urlresolver . HostedMediaFile ( url )
  if 79 - 79: IiII - o0oOOo0O0Ooo
  if not I11IIIiIi11 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 43 - 43: OoOoOO00 + I1IiiI % OOooOOo / o00O0oo * I1ii11iIi11i
  import resolveurl as urlresolver
  if 89 - 89: I1ii11iIi11i . oO0o + iII111i . I1IiiI % Ii1I
  I11IIIiIi11 = urlresolver . HostedMediaFile ( url )
  if 84 - 84: OoO0O00 + IIII / I1ii11iIi11i % I1Ii111 % iII111i * I1ii11iIi11i
  if 58 - 58: OOooOOo - I11i . II111iiii % II111iiii / OoOoOO00 / IiII
  if not I11IIIiIi11 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 24 - 24: I1ii11iIi11i * OoOoOO00 % o0O0 / I1IiiI + II111iiii
  try :
   IIi11I1 = I11IIIiIi11 . resolve ( )
   if not IIi11I1 or not isinstance ( IIi11I1 , basestring ) :
    try : iiiI111I = IIi11I1 . msg
    except : iiiI111I = url
    raise Exception ( iiiI111I )
  except Exception as oo000ii :
   try : iiiI111I = str ( oo000ii )
   except : iiiI111I = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 12 - 12: iII111i / o00O0oo
   if 5 - 5: OoO0O00
   if 18 - 18: I1ii11iIi11i % OoO0O00 - IIIIII11i1I . II111iiii * oO0o % o00O0oo
  Oo0O0O0ooO0O = oo000 . getSetting ( 'notificar' )
  if Oo0O0O0ooO0O == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 12 - 12: OoOoOO00 / I1Ii111 % o0O0 * o0o0OOO0o0 * I1IiiI * Oo0Ooo
   if '[Realstream]' in name :
    if 93 - 93: oO0o / iII111i + OoOoOO00 * IiII . OoO0O00
    O0o0 = oo000 . getSetting ( 'restante' )
    if O0o0 == 'true' :
     oOOOO = xbmcgui . Dialog ( )
     oooOO0OO0O = oOOOO . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 54 - 54: I1IiiI / o0o0OOO0o0 % o0O0 * OoOoOO00 * I1IiiI
   ooooIIIII1iii11 = xbmcgui . ListItem ( path = IIi11I1 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooooIIIII1iii11 )
   if 48 - 48: Ii1I . IiII % I11i - I11i
   if 33 - 33: ooOoO0o % o0oOOo0O0Ooo + OOooOOo
   if 93 - 93: OoOoOO00 . o0o0OOO0o0 / I1ii11iIi11i + o0o0OOO0o0
 return
 if 58 - 58: iII111i + I1IiiI . oO0o + I11i - OOooOOo - I11i
 if 41 - 41: oO0o / OoOoOO00 / oO0o - IIIIII11i1I . Ii1I
 if 65 - 65: I1IiiI * II111iiii . OoO0O00 / I1ii11iIi11i / IIIIII11i1I
def o00000oo00 ( name , url ) :
 if 41 - 41: I1Ii111 - Ii1I + o00O0oo
 if 15 - 15: ooOoO0o / Ii1I + o00O0oo
 if '[Youtube]' in name :
  if 76 - 76: o00O0oo + OoO0O00 / I1Ii111 % OOooOOo / iII111i
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 38 - 38: IIII . IIIIII11i1I . I1ii11iIi11i * OOooOOo
  try :
   Oo0O0O0ooO0O = oo000 . getSetting ( 'notificar' )
   if Oo0O0O0ooO0O == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    ooooIIIII1iii11 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooooIIIII1iii11 )
    if 69 - 69: Ii1I % II111iiii / o00O0oo
    if 93 - 93: o0O0
    if 34 - 34: IiII - o0O0 * oO0o / Ii1I
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 19 - 19: iII111i
 else :
  if 46 - 46: Oo0Ooo . II111iiii - I11i % I1IiiI / o0oOOo0O0Ooo * OoOoOO00
  import resolveurl
  if 66 - 66: I1IiiI
  I11IIIiIi11 = urlresolver . HostedMediaFile ( url )
  if 52 - 52: OOooOOo * OoO0O00
  if 12 - 12: I1IiiI + o0o0OOO0o0 * OoOoOO00 . OOooOOo
  if not I11IIIiIi11 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 71 - 71: IIII - Ii1I - I1Ii111
  try :
   IIi11I1 = I11IIIiIi11 . resolve ( )
   if not IIi11I1 or not isinstance ( IIi11I1 , basestring ) :
    try : iiiI111I = IIi11I1 . msg
    except : iiiI111I = url
    raise Exception ( iiiI111I )
  except Exception as oo000ii :
   try : iiiI111I = str ( oo000ii )
   except : iiiI111I = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 28 - 28: Oo0Ooo
   if 7 - 7: Ii1I % o0o0OOO0o0 * I11i
   if 58 - 58: o0o0OOO0o0 / ooOoO0o + o0oOOo0O0Ooo % IIIIII11i1I - OoO0O00
  Oo0O0O0ooO0O = oo000 . getSetting ( 'notificar' )
  if Oo0O0O0ooO0O == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 25 - 25: I11i % OoO0O00 * oO0o - OoOoOO00 * o0oOOo0O0Ooo * IiII
   if '[Realstream]' in name :
    if 30 - 30: ooOoO0o % I11i / iII111i * I1IiiI * o00O0oo . I1ii11iIi11i
    O0o0 = oo000 . getSetting ( 'restante' )
    if O0o0 == 'true' :
     oOOOO = xbmcgui . Dialog ( )
     oooOO0OO0O = oOOOO . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 46 - 46: I11i - I1IiiI
   ooooIIIII1iii11 = xbmcgui . ListItem ( path = IIi11I1 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooooIIIII1iii11 )
   if 70 - 70: ooOoO0o + oO0o * Oo0Ooo . I1ii11iIi11i * ooOoO0o
   if 49 - 49: Ii1I
   if 25 - 25: IIIIII11i1I . OoO0O00 * Oo0Ooo . Ii1I / I1IiiI + o00O0oo
 return
 if 68 - 68: oO0o
 if 22 - 22: I1Ii111
 if 22 - 22: IIIIII11i1I * ooOoO0o - oO0o * I1IiiI / II111iiii
def OOooO0Oo0o000 ( name , url ) :
 if 17 - 17: Oo0Ooo + I1ii11iIi11i
 if 57 - 57: Ii1I / IIII
 if '[Youtube]' in name :
  if 13 - 13: OoO0O00 + OOooOOo
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 32 - 32: I1IiiI + IiII % oO0o
  try :
   Oo0O0O0ooO0O = oo000 . getSetting ( 'notificar' )
   if Oo0O0O0ooO0O == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    ooooIIIII1iii11 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooooIIIII1iii11 )
    if 7 - 7: iII111i / o0O0
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 11 - 11: o0o0OOO0o0 * o0O0 / o0O0 - I1Ii111
 else :
  if 68 - 68: I1ii11iIi11i % o0o0OOO0o0 - o0o0OOO0o0 / I1ii11iIi11i + iII111i - oO0o
  if 'https://team.com' in url :
   if 65 - 65: o0O0 - OoOoOO00
   url = url . replace ( 'https://team.com' , 'https://verystream.com' )
   if 62 - 62: ooOoO0o / IiII % oO0o . OoO0O00 / II111iiii / IIII
  if 'https://mybox.com' in url :
   if 60 - 60: I1ii11iIi11i % IiII / Ii1I % IiII * II111iiii / IIIIII11i1I
   url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
   if 34 - 34: IIII - I1Ii111
  if 'https://drive.com' in url :
   if 25 - 25: IiII % I1ii11iIi11i + II111iiii + I1IiiI * OoO0O00
   url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
   if 64 - 64: OoOoOO00
  if 'https://https://vidcloud.co/' in url :
   if 10 - 10: IIII % I1IiiI / I1ii11iIi11i % ooOoO0o
   url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
   if 25 - 25: o0oOOo0O0Ooo / OOooOOo
  if 'https://gounlimited.to' in url :
   if 64 - 64: I1IiiI % o0O0
   url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
   if 40 - 40: Ii1I + ooOoO0o
  import resolveurl
  if 77 - 77: II111iiii % o0o0OOO0o0 + IIII % OoO0O00 - ooOoO0o
  I11IIIiIi11 = urlresolver . HostedMediaFile ( url )
  if 26 - 26: oO0o + I1IiiI - Oo0Ooo
  if 47 - 47: OoO0O00
  if not I11IIIiIi11 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 2 - 2: I11i % IIII * oO0o * I11i
  try :
   IIi11I1 = I11IIIiIi11 . resolve ( )
   if not IIi11I1 or not isinstance ( IIi11I1 , basestring ) :
    try : iiiI111I = IIi11I1 . msg
    except : iiiI111I = url
    raise Exception ( iiiI111I )
  except Exception as oo000ii :
   try : iiiI111I = str ( oo000ii )
   except : iiiI111I = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace borrado, reportalo en nuesto grupo de telegram [/COLOR][COLOR ligthblue] https://t.me/OficialNetai [/COLOR]  ,5000)" )
   return False
   if 65 - 65: II111iiii + oO0o * OoO0O00 - OOooOOo
   if 26 - 26: Ii1I % I1Ii111 + I1Ii111 % ooOoO0o * II111iiii / IIIIII11i1I
   if 64 - 64: IiII % I11i / o0oOOo0O0Ooo % o0O0 - IIIIII11i1I
   Oo0O0O0ooO0O = oo000 . getSetting ( 'notificar' )
   if Oo0O0O0ooO0O == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
    if 2 - 2: IIII - iII111i + Ii1I * OOooOOo / IIIIII11i1I
    if '[Realstream]' or '[Mybox]' in name :
     O0o0 = oo000 . getSetting ( 'restante' )
    elif O0o0 == 'true' :
     oOOOO = xbmcgui . Dialog ( )
     oooOO0OO0O = oOOOO . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 26 - 26: I1Ii111 * oO0o
  ooooIIIII1iii11 = xbmcgui . ListItem ( path = IIi11I1 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooooIIIII1iii11 )
  if 31 - 31: ooOoO0o * IiII . o00O0oo
 return
 if 35 - 35: ooOoO0o
 if 94 - 94: o0O0 / II111iiii % I1IiiI
 if 70 - 70: ooOoO0o - oO0o / OoO0O00 % OoO0O00
def oooo0o0OOO0 ( ) :
 if 17 - 17: o0oOOo0O0Ooo + I1ii11iIi11i
 if 59 - 59: Oo0Ooo % o00O0oo . II111iiii
 OOoO0OOOO0000O = [ ]
 iiiI11 = sys . argv [ 2 ]
 if len ( iiiI11 ) >= 2 :
  o0o00OOOO = sys . argv [ 2 ]
  i11iIi1iIIIIi = o0o00OOOO . replace ( '?' , '' )
  if ( o0o00OOOO [ len ( o0o00OOOO ) - 1 ] == '/' ) :
   o0o00OOOO = o0o00OOOO [ 0 : len ( o0o00OOOO ) - 2 ]
  I1111iiiII1Ii = i11iIi1iIIIIi . split ( '&' )
  OOoO0OOOO0000O = { }
  for oO0oOoOoo0 in range ( len ( I1111iiiII1Ii ) ) :
   o0o000o = { }
   o0o000o = I1111iiiII1Ii [ oO0oOoOoo0 ] . split ( '=' )
   if ( len ( o0o000o ) ) == 2 :
    OOoO0OOOO0000O [ o0o000o [ 0 ] ] = o0o000o [ 1 ]
 return OOoO0OOOO0000O
 if 26 - 26: Oo0Ooo * Ii1I . ooOoO0o
 if 10 - 10: IIII * IiII % oO0o - ooOoO0o % oO0o
def O0oooo000oO0 ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  import urlresolver
  xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
  if 96 - 96: I1IiiI . IIIIII11i1I - I1ii11iIi11i * oO0o
def OOoOOOo0 ( ) :
 oOOOO = xbmcgui . Dialog ( )
 list = (
 oOoO00O ,
 I11I1I1i1i
 )
 if 74 - 74: I1IiiI % OoO0O00 * oO0o + I1Ii111 * IIIIII11i1I
 I111IiiIi1 = oOOOO . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=%s]Accede a themoviedb.com[/COLOR]' % Oo0oOOo ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 100 - 100: I1Ii111 + o00O0oo * Ii1I + o0oOOo0O0Ooo
 if I111IiiIi1 :
  if 70 - 70: oO0o * Oo0Ooo
  if I111IiiIi1 < 0 :
   return
  oOOo000oOoO0 = list [ I111IiiIi1 - 2 ]
  return oOOo000oOoO0 ( )
 else :
  oOOo000oOoO0 = list [ I111IiiIi1 ]
  return oOOo000oOoO0 ( )
 return
 if 76 - 76: IIIIII11i1I % I11i % Oo0Ooo . I1Ii111
def Ooo0o0OOO ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 30 - 30: OoOoOO00
iI1IIIii = Ooo0o0OOO ( )
if 75 - 75: ooOoO0o . I1Ii111 - Oo0Ooo * OOooOOo * IIIIII11i1I
def oOoO00O ( ) :
 if iI1IIIii == 'android' :
  O0O0oOOo0O = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  O0O0oOOo0O = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 93 - 93: o0O0
  if 18 - 18: o0O0
def I11I1I1i1i ( ) :
 if 66 - 66: IiII * II111iiii + I11i / I1Ii111
 main ( )
 if 96 - 96: I1Ii111 + I1Ii111 % o0o0OOO0o0 % I1Ii111
 if 28 - 28: Oo0Ooo + I11i . Ii1I % II111iiii
 if 58 - 58: ooOoO0o / OoO0O00 % IiII + OOooOOo
def o0ooOO0OOO00o ( ) :
 oOOOO = xbmcgui . Dialog ( )
 Ii = (
 OoOoO0ooooO0 ,
 IIII1ii1
 )
 if 52 - 52: OOooOOo - I1Ii111 - o0O0 - Ii1I + OoOoOO00
 I111IiiIi1 = oOOOO . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 10 - 10: OoO0O00 / IIIIII11i1I / IiII * oO0o / Oo0Ooo
 if I111IiiIi1 :
  if 63 - 63: o0oOOo0O0Ooo
  if I111IiiIi1 < 0 :
   return
  oOOo000oOoO0 = Ii [ I111IiiIi1 - 2 ]
  return oOOo000oOoO0 ( )
 else :
  oOOo000oOoO0 = Ii [ I111IiiIi1 ]
  return oOOo000oOoO0 ( )
 return
 if 39 - 39: I1IiiI + OOooOOo / Ii1I % ooOoO0o . I1Ii111 * OoO0O00
def Ooo0o0OOO ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 38 - 38: IiII % OoO0O00 + OOooOOo * II111iiii
iI1IIIii = Ooo0o0OOO ( )
if 61 - 61: Oo0Ooo
def OoOoO0ooooO0 ( ) :
 if iI1IIIii == 'android' :
  O0O0oOOo0O = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  O0O0oOOo0O = webbrowser . open ( 'https://olpair.com/' )
  if 11 - 11: IiII . I1ii11iIi11i + o0o0OOO0o0 / OoOoOO00
  if 1 - 1: oO0o * IIII . OoO0O00
def IIII1ii1 ( ) :
 if 73 - 73: I11i % Ii1I
 main ( )
 if 71 - 71: IiII - OoO0O00 * oO0o * ooOoO0o + Ii1I * iII111i
 if 85 - 85: II111iiii . OoO0O00 - Oo0Ooo
def I1OO0o ( name , url , id , trailer ) :
 oOOOO = xbmcgui . Dialog ( )
 Ii = (
 OoO000o0 ,
 ooo00 ,
 iII11II1II ,
 OOoOOOo0 ,
 OOO00000o0
 )
 if 96 - 96: Ii1I * IiII - I1Ii111 * Ii1I * OoOoOO00
 I111IiiIi1 = oOOOO . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % Oo0oOOo ,

 '[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % Oo0oOOo ,

 '[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % Oo0oOOo ,

 '[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % Oo0oOOo ,

 '[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % Oo0oOOo ] )
 if 8 - 8: o0O0 - oO0o + Oo0Ooo + OoOoOO00 * o00O0oo - Oo0Ooo
 if I111IiiIi1 :
  if 30 - 30: ooOoO0o / iII111i
  if I111IiiIi1 < 0 :
   return
  oOOo000oOoO0 = Ii [ I111IiiIi1 - 5 ]
  return oOOo000oOoO0 ( )
 else :
  oOOo000oOoO0 = Ii [ I111IiiIi1 ]
  return oOOo000oOoO0 ( )
 return
 if 22 - 22: IiII * IIIIII11i1I
 if 4 - 4: I11i - IiII + I1ii11iIi11i
 if 36 - 36: o0o0OOO0o0
def OoO000o0 ( ) :
 if 19 - 19: I11i . Ii1I . OoO0O00
 OOooO0Oo0o000 ( OOOooo , OooO0OO )
 if 13 - 13: I1Ii111 . oO0o / o0oOOo0O0Ooo
def ooo00 ( ) :
 if 43 - 43: Oo0Ooo % OOooOOo
 i1I111Ii ( OOOooo , o0OOo0o0O0O )
 if 84 - 84: oO0o
def iII11II1II ( ) :
 if 44 - 44: OoO0O00 * II111iiii / oO0o
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  OoOoO00o00 = id
  if 51 - 51: oO0o * Oo0Ooo . OoO0O00 . o00O0oo - I1Ii111 / I1ii11iIi11i
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % OoOoO00o00 )
  if 98 - 98: o0oOOo0O0Ooo + o00O0oo + OoO0O00 / OoOoOO00 - o00O0oo
 if Oo0O0O0ooO0O == 'true' :
  if 87 - 87: IIIIII11i1I / ooOoO0o / ooOoO0o % OoO0O00 - iII111i * IiII
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + OOOooo + "[/COLOR] ,5000)" )
  if 23 - 23: II111iiii
def OOooOoO ( ) :
 if 24 - 24: Ii1I + I1ii11iIi11i - o0oOOo0O0Ooo
 OOoOOOo0 ( )
 if 29 - 29: I1ii11iIi11i + II111iiii . I1IiiI
def OOO00000o0 ( ) :
 if 75 - 75: IIII + Oo0Ooo
 o00O00oO00 ( )
def Iiii ( name , url , mode , iconimage , fanart ) :
 if 19 - 19: I1ii11iIi11i + II111iiii . o0o0OOO0o0 - ooOoO0o / o00O0oo + Ii1I
 iiii1I1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 oooOO0OO0O = True
 IIIiIiI11iIi = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 IIIiIiI11iIi . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IIIiIiI11iIi . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  iiii1I1 = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  oooOO0OO0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiii1I1 , listitem = IIIiIiI11iIi , isFolder = True )
  return oooOO0OO0O
 oooOO0OO0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiii1I1 , listitem = IIIiIiI11iIi , isFolder = True )
 return oooOO0OO0O
 if 38 - 38: oO0o / Oo0Ooo * Oo0Ooo % iII111i
def O0OO0ooO00 ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 92 - 92: ooOoO0o / I1IiiI * I1ii11iIi11i - ooOoO0o
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 oooOo00000 = [ ]
 iiii1I1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 IIIiIiI11iIi = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 IIIiIiI11iIi . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IIIiIiI11iIi . setProperty ( 'fanart_image' , fanart )
 IIIiIiI11iIi . setProperty ( 'IsPlayable' , 'true' )
 if 45 - 45: I1IiiI * IIII + II111iiii - I1Ii111 - Oo0Ooo
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  oooOo00000 . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  IIIiIiI11iIi . addContextMenuItems ( oooOo00000 , replaceItems = True )
 oooOO0OO0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiii1I1 , listitem = IIIiIiI11iIi )
 return oooOO0OO0O
 if 5 - 5: I1Ii111 % oO0o % o0o0OOO0o0 % o0O0
def O0OoO0o ( name , url , mode , iconimage , fanart ) :
 if 17 - 17: o00O0oo + o0oOOo0O0Ooo + OoO0O00 / I1Ii111 / o0o0OOO0o0
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 80 - 80: Ii1I % OoOoOO00 / ooOoO0o
 iiii1I1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 IIIiIiI11iIi = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 IIIiIiI11iIi . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IIIiIiI11iIi . setProperty ( 'fanart_image' , fanart )
 IIIiIiI11iIi . setProperty ( 'IsPlayable' , 'true' )
 oooOO0OO0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiii1I1 , listitem = IIIiIiI11iIi )
 return oooOO0OO0O
 if 56 - 56: OoOoOO00 . II111iiii
def Ii1Ii1IiIIIi1 ( name , url , mode ) :
 if 55 - 55: IiII + I1IiiI / IIIIII11i1I % o0O0 / OoO0O00
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 98 - 98: o00O0oo * Oo0Ooo % oO0o % I1Ii111
 iiii1I1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 IIIiIiI11iIi = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = o0OoO000O )
 IIIiIiI11iIi . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IIIiIiI11iIi . setProperty ( 'fanart_image' , O0oOO0o0 )
 IIIiIiI11iIi . setProperty ( 'IsPlayable' , 'true' )
 oooOO0OO0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiii1I1 , listitem = IIIiIiI11iIi )
 return oooOO0OO0O
 if 88 - 88: IIIIII11i1I - o0oOOo0O0Ooo / IIIIII11i1I - o00O0oo
def iI1iii1iI1 ( name , url , mode , iconimage ) :
 iiii1I1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 oooOO0OO0O = True
 IIIiIiI11iIi = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 oooOO0OO0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiii1I1 , listitem = IIIiIiI11iIi , isFolder = True )
 return oooOO0OO0O
 if 65 - 65: OoO0O00
def iiii11iI1 ( ) :
 if 81 - 81: II111iiii + o00O0oo % II111iiii - OoOoOO00
 if 9 - 9: IiII
 if 2 - 2: Oo0Ooo * I1ii11iIi11i % OoOoOO00 % iII111i + OoO0O00 + I1ii11iIi11i
 i11III1111iIi = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 i11III1111iIi . doModal ( )
 if ( i11III1111iIi . isConfirmed ( ) ) :
  if 16 - 16: I1Ii111
  iI11 = urllib . quote_plus ( i11III1111iIi . getText ( ) ) . replace ( '+' , ' ' )
  if 63 - 63: IIIIII11i1I
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 11 - 11: IIIIII11i1I - Oo0Ooo
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % iI11 )
    if 92 - 92: OOooOOo
    if Oo0O0O0ooO0O == 'true' :
     if 15 - 15: o0o0OOO0o0 / o0o0OOO0o0 + Oo0Ooo % OoO0O00
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + OOOooo + "[/COLOR] ,10000)" )
     if 12 - 12: o0O0
   except :
    if 36 - 36: IIII . o0o0OOO0o0 * OoO0O00 - Ii1I
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 60 - 60: I1Ii111 . IIIIII11i1I / Oo0Ooo + I1Ii111 * IIII
    if 82 - 82: II111iiii . Oo0Ooo * I1ii11iIi11i - ooOoO0o + o00O0oo
    if 48 - 48: iII111i
o0o00OOOO = oooo0o0OOO0 ( )
OooO0OO = None
OOOooo = None
o0o = None
o0OoO000O = None
id = None
o0OOo0o0O0O = None
if 39 - 39: I1Ii111 + OOooOOo
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 80 - 80: I1Ii111 % OOooOOo / I11i
try :
 OooO0OO = urllib . unquote_plus ( o0o00OOOO [ "url" ] )
except :
 pass
try :
 OOOooo = urllib . unquote_plus ( o0o00OOOO [ "name" ] )
except :
 pass
try :
 o0o = int ( o0o00OOOO [ "mode" ] )
except :
 pass
try :
 o0OoO000O = urllib . unquote_plus ( o0o00OOOO [ "iconimage" ] )
except :
 pass
try :
 id = int ( o0o00OOOO [ "id" ] )
except :
 pass
try :
 o0OOo0o0O0O = urllib . unquote_plus ( o0o00OOOO [ "trailer" ] )
except :
 pass
 if 54 - 54: oO0o % OOooOOo - I1Ii111 - ooOoO0o
 if 71 - 71: o0O0 . II111iiii
print "Mode: " + str ( o0o )
print "URL: " + str ( OooO0OO )
print "Name: " + str ( OOOooo )
print "iconimage: " + str ( o0OoO000O )
print "id: " + str ( id )
print "trailer: " + str ( o0OOo0o0O0O )
if 56 - 56: I1IiiI * IIIIII11i1I + IIIIII11i1I * Oo0Ooo / o0O0 * IIII
if o0o == None or OooO0OO == None or len ( OooO0OO ) < 1 :
 if O0o0O00Oo0o0 == O00O0oOO00O00 :
  if 25 - 25: Oo0Ooo . ooOoO0o * II111iiii + oO0o * ooOoO0o
  IiIIII1i11I ( )
  O0OOO0OOoO0O = oo000 . getSetting ( 'aviso' )
  if O0OOO0OOoO0O == 'true' :
   IIiI1Ii ( )
   if 67 - 67: IIIIII11i1I
   if 88 - 88: oO0o
  Ii11iII1 = oo000 . getSetting ( 'licencia_addon' )
  i1Iii1i1I = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  if 8 - 8: iII111i
  OOoO00 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  o000 = oo000 . getSetting ( 'key_ext' )
  OoOO0o = i1II1 ( OOoO00 )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for i11ii1 in i11i1 :
   try :
    if 4 - 4: II111iiii - I1Ii111 % iII111i * IIII % Ii1I
    if 71 - 71: o0O0 . o0O0 - Oo0Ooo
    Ii11iII1 = oo000 . getSetting ( 'licencia_addon' )
    if 22 - 22: OoO0O00 / iII111i % IIIIII11i1I * I11i
    if 32 - 32: OoO0O00 % IiII % Oo0Ooo / I1IiiI
    if Ii11iII1 == i11ii1 :
     if 61 - 61: o0oOOo0O0Ooo . I1IiiI - o00O0oo - iII111i / II111iiii - o0oOOo0O0Ooo
     xbmcgui . Dialog ( ) . ok ( "Realstream Licencia:" , "[COLOR lime]Su llave es correcta![/COLOR] [COLOR gold]Sientese y disfrute de Realstream.[/COLOR]" )
     if 98 - 98: o00O0oo - I1ii11iIi11i . II111iiii * oO0o
     o00O00oO00 ( )
     if 29 - 29: o00O0oo / o0O0 % ooOoO0o
    else :
     if 10 - 10: Oo0Ooo % OoO0O00 % iII111i
     xbmcgui . Dialog ( ) . ok ( "Realstream Licencia:" , "[COLOR red]Ha introducido una llave erronea.[/COLOR] [COLOR gold]Ponganse en contacto con nosotros en nuestro grupo de telegram.[/COLOR]" )
     if 39 - 39: o0oOOo0O0Ooo * I11i . I1IiiI * ooOoO0o
     if 89 - 89: o00O0oo - o0O0 . ooOoO0o - IIII - I1ii11iIi11i
   except :
    pass
    if 79 - 79: o0o0OOO0o0 + o0o0OOO0o0 + o00O0oo
 else :
  xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red][B]Error, de inicio. ¿Tienes Instalado Realstream?[/B][/COLOR]" )
  if 39 - 39: I1IiiI - OoO0O00
  if 63 - 63: Oo0Ooo % Ii1I * o0O0
elif o0o == 1 :
 I1OO0o ( OOOooo , OooO0OO , id , o0OOo0o0O0O )
elif o0o == 2 :
 II1iiIIiIii ( )
elif o0o == 3 :
 o00oo0000 ( )
elif o0o == 4 :
 Iii1IIIIIII ( OOOooo , OooO0OO )
elif o0o == 5 :
 oOo0OooOo ( )
elif o0o == 6 :
 oo0O0o ( )
elif o0o == 7 :
 O0OOO000o0o ( )
elif o0o == 8 :
 o00OOo ( )
elif o0o == 9 :
 OOoO00ooO ( )
elif o0o == 10 :
 oo0ooooO ( )
elif o0o == 11 :
 Ii1ii11IIIi ( )
elif o0o == 12 :
 I1I11ii ( )
elif o0o == 13 :
 o00OoO0oO00 ( )
elif o0o == 14 :
 IiI1iI1IiiIi1 ( )
elif o0o == 15 :
 iiI1Ii1I ( )
elif o0o == 16 :
 iIiI1I1IIi11 ( )
elif o0o == 17 :
 OO000 ( )
elif o0o == 18 :
 iii1IIiI ( )
elif o0o == 19 :
 iiii1i1II1 ( )
elif o0o == 20 :
 o0oo0Ooooo0 ( )
elif o0o == 21 :
 IiI ( )
elif o0o == 22 :
 III1II1i ( )
elif o0o == 23 :
 iI1ii11Ii ( )
elif o0o == 24 :
 II111 ( )
elif o0o == 25 :
 oo000o ( )
elif o0o == 26 :
 oO0oooooo ( )
elif o0o == 28 :
 oO00OoOO ( OOOooo , OooO0OO )
elif o0o == 98 :
 busqueda_global ( )
elif o0o == 97 :
 o0ooOO0OOO00o ( )
elif o0o == 99 :
 II1i111 ( )
elif o0o == 100 :
 menu_player ( OOOooo , OooO0OO )
elif o0o == 111 :
 OOOoO00 ( )
elif o0o == 115 :
 i1I111Ii ( OooO0OO )
elif o0o == 116 :
 IIiii11i ( )
elif o0o == 117 :
 oO0OO0 ( )
elif o0o == 119 :
 Ii111 ( )
elif o0o == 120 :
 I1i1i ( )
elif o0o == 121 :
 oOoOOo0oo0 ( )
elif o0o == 125 :
 OoOoiIIi11i1i1i1I ( )
elif o0o == 112 :
 OOOoO000 ( )
elif o0o == 127 :
 iiii11iI1 ( )
elif o0o == 128 :
 TESTLINKS ( )
elif o0o == 130 :
 OOooO0Oo0o000 ( OOOooo , OooO0OO )
elif o0o == 140 :
 O0o ( )
elif o0o == 141 :
 OoO00ooO ( )
elif o0o == 142 :
 IIii1i1iii1 ( )
elif o0o == 143 :
 I111i1I1 ( OOOooo , OooO0OO )
elif o0o == 144 :
 oO00OoOO ( OOOooo , OooO0OO )
elif o0o == 145 :
 OoOo000oOo0oo ( )
xbmcplugin . endOfDirectory ( oOOo ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
