# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 0.8.1
#
############################################
# Dependencias 
# Script ExtendedInfo
# Script Urlresolver de TVAddons
# Script ResolveURL Por Jsergio.
#
############################################
#
# Corregido imcompatibilidad con Servidor Team
# Agregados nuevos iconos, ahora se puede el aspecto desde ajustes del addon.
#
############################################
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import urlresolver
import cookielib , base64
import requests
import plugintools
import config
oo000 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
ii = oo000 . getAddonInfo ( 'version' )
oOOo = int ( sys . argv [ 1 ] )
O0 = 'gruponetai/'
o0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
iI11I1II1I1I = o0O . getAddonInfo ( 'profile' )
oooo = o0O . getAddonInfo ( 'path' )
iIIii1IIi = oo000 . getSetting ( 'iconos' )
if 73 - 73 : II111iiii
if 22 - 22 : I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48 : oO0o / OOooOOo / I11i / Ii1I
if iIIii1IIi == 'true' :
 if 48 - 48 : iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
 o0OO00 = xbmc . translatePath ( os . path . join ( oooo , 'fanart.png' ) )
 oo = xbmc . translatePath ( os . path . join ( oooo , 'icon.png' ) )
 i1iII1IiiIiI1 = xbmc . translatePath ( os . path . join ( oooo , 'extended_info.png' ) )
 iIiiiI1IiI1I1 = xbmc . translatePath ( os . path . join ( oooo , 'buscar.png' ) )
 o0OoOoOO00 = xbmc . translatePath ( os . path . join ( oooo , 'pair.png' ) )
 I11i = xbmc . translatePath ( os . path . join ( oooo , 'theMovieDB.png' ) )
 O0O = xbmc . translatePath ( os . path . join ( oooo , 'novedades.png' ) )
 Oo = xbmc . translatePath ( os . path . join ( oooo , 'estrenos.png' ) )
 I1ii11iIi11i = xbmc . translatePath ( os . path . join ( oooo , 'recomendadas.png' ) )
 I1IiI = xbmc . translatePath ( os . path . join ( oooo , 'accion.png' ) )
 o0OOO = xbmc . translatePath ( os . path . join ( oooo , 'animacion.png' ) )
 iIiiiI = xbmc . translatePath ( os . path . join ( oooo , 'aventuras.png' ) )
 Iii1ii1II11i = xbmc . translatePath ( os . path . join ( oooo , 'belico.png' ) )
 iI111iI = xbmc . translatePath ( os . path . join ( oooo , 'ciencia-ficcion.png' ) )
 IiII = xbmc . translatePath ( os . path . join ( oooo , 'comedia.png' ) )
 iI1Ii11111iIi = xbmc . translatePath ( os . path . join ( oooo , 'crimen.png' ) )
 i1i1II = xbmc . translatePath ( os . path . join ( oooo , 'drama.png' ) )
 O0oo0OO0 = xbmc . translatePath ( os . path . join ( oooo , 'familiar.png' ) )
 I1i1iiI1 = xbmc . translatePath ( os . path . join ( oooo , 'fantasia.png' ) )
 iiIIIII1i1iI = xbmc . translatePath ( os . path . join ( oooo , 'historia.png' ) )
 o0oO0 = xbmc . translatePath ( os . path . join ( oooo , 'marvel.png' ) )
 oo00 = xbmc . translatePath ( os . path . join ( oooo , 'misterio.png' ) )
 o00 = xbmc . translatePath ( os . path . join ( oooo , 'musical.png' ) )
 Oo0oO0ooo = xbmc . translatePath ( os . path . join ( oooo , 'romance.png' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( oooo , 'spain.png' ) )
 i1 = xbmc . translatePath ( os . path . join ( oooo , 'suspense.png' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( oooo , 'terror.png' ) )
 i1111 = xbmc . translatePath ( os . path . join ( oooo , 'thriller.png' ) )
 i11 = xbmc . translatePath ( os . path . join ( oooo , 'western.png' ) )
 I11 = xbmc . translatePath ( os . path . join ( oooo , 'sagas_cine.png' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( oooo , '4k.png' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( oooo , 'torrent.png' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( oooo , 'buscar-serie.jpg' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( oooo , 'series-todas.jpg' ) )
 oO = xbmc . translatePath ( os . path . join ( oooo , 'favorites.png' ) )
else :
 if 85 - 85 : O0O00o0OOO0 . O0o / o0 + I11ii1 / I1IiiI
 if 73 - 73 : I1Ii111 % I11i - o00O0oo
 iIIii1IIi = oo000 . getSetting ( 'iconos' )
 o0OO00 = xbmc . translatePath ( os . path . join ( oooo , 'fanart.jpg' ) )
 oo = xbmc . translatePath ( os . path . join ( oooo , 'icon.png' ) )
 i1iII1IiiIiI1 = xbmc . translatePath ( os . path . join ( oooo , 'extended_info.png' ) )
 iIiiiI1IiI1I1 = xbmc . translatePath ( os . path . join ( oooo , 'buscar.png' ) )
 o0OoOoOO00 = xbmc . translatePath ( os . path . join ( oooo , 'pair.png' ) )
 I11i = xbmc . translatePath ( os . path . join ( oooo , 'theMovieDB.jpg' ) )
 O0O = xbmc . translatePath ( os . path . join ( oooo , 'novedades.jpg' ) )
 Oo = xbmc . translatePath ( os . path . join ( oooo , 'encines.jpg' ) )
 I1ii11iIi11i = xbmc . translatePath ( os . path . join ( oooo , 'recomendadas.jpg' ) )
 I1IiI = xbmc . translatePath ( os . path . join ( oooo , 'accion.jpg' ) )
 o0OOO = xbmc . translatePath ( os . path . join ( oooo , 'animacion.jpg' ) )
 iIiiiI = xbmc . translatePath ( os . path . join ( oooo , 'aventuras.jpg' ) )
 Iii1ii1II11i = xbmc . translatePath ( os . path . join ( oooo , 'belico.jpg' ) )
 iI111iI = xbmc . translatePath ( os . path . join ( oooo , 'ciencia-ficcion.jpg' ) )
 IiII = xbmc . translatePath ( os . path . join ( oooo , 'comedia.jpg' ) )
 iI1Ii11111iIi = xbmc . translatePath ( os . path . join ( oooo , 'crimen.jpg' ) )
 i1i1II = xbmc . translatePath ( os . path . join ( oooo , 'drama.jpg' ) )
 O0oo0OO0 = xbmc . translatePath ( os . path . join ( oooo , 'familiar.jpg' ) )
 I1i1iiI1 = xbmc . translatePath ( os . path . join ( oooo , 'fantasia.jpg' ) )
 iiIIIII1i1iI = xbmc . translatePath ( os . path . join ( oooo , 'historia.jpg' ) )
 o0oO0 = xbmc . translatePath ( os . path . join ( oooo , 'superheroes.jpg' ) )
 oo00 = xbmc . translatePath ( os . path . join ( oooo , 'misterio.jpg' ) )
 o00 = xbmc . translatePath ( os . path . join ( oooo , 'musical.jpg' ) )
 Oo0oO0ooo = xbmc . translatePath ( os . path . join ( oooo , 'romance.jpg' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( oooo , 'spain.jpg' ) )
 i1 = xbmc . translatePath ( os . path . join ( oooo , 'suspense.jpg' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( oooo , 'terror.jpg' ) )
 i1111 = xbmc . translatePath ( os . path . join ( oooo , 'thriller.jpg' ) )
 i11 = xbmc . translatePath ( os . path . join ( oooo , 'western.jpg' ) )
 I11 = xbmc . translatePath ( os . path . join ( oooo , 'sagas_cine.jpg' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( oooo , '4k.jpg' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( oooo , 'torrent.jpg' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( oooo , 'buscar-serie.jpg' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( oooo , 'series-todas.jpg' ) )
 oO = xbmc . translatePath ( os . path . join ( oooo , 'favoritos.png' ) )
 if 10 - 10 : I1ii11iIi11i % iII111i
 if 48 - 48 : ooOoO0o + ooOoO0o / o0oOOo0O0Ooo / Oo0Ooo
i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( oooo , 'peliculas.png' ) )
oooOOOOO = xbmc . translatePath ( os . path . join ( oooo , 'series.png' ) )
i1iiIII111ii = xbmc . translatePath ( os . path . join ( oooo , 'ajustes.png' ) )
i1iIIi1 = xbmc . translatePath ( os . path . join ( oooo , 'videoteca.png' ) )
ii11iIi1I = xbmc . translatePath ( os . path . join ( oooo , 'favorites.png' ) )
iI111I11I1I1 = xbmc . translatePath ( os . path . join ( oooo , 'resolver.png' ) )
OOooO0OOoo = xbmc . translatePath ( os . path . join ( oooo , 'test.png' ) )
iIii1 = xbmc . translatePath ( os . path . join ( oooo , 'video-tutoriales.png' ) )
oOOoO0 = xbmc . translatePath ( os . path . join ( oooo , 'proxy.png' ) )
if 69 - 69 : IiII % o0 - Ii1I + o0 - I1IiiI % OoO0O00
O0OoO000O0OO = oo000 . getSetting ( 'mostrar_cat' )
iiI1IiI = oo000 . getSetting ( 'videos' )
II = oo000 . getSetting ( 'activar' )
ooOoOoo0O = oo000 . getSetting ( 'favcopy' )
OooO0 = oo000 . getSetting ( 'anticopia' )
II11iiii1Ii = oo000 . getSetting ( 'licencia_addon' )
OO0o = oo000 . getSetting ( 'notificar' )
Ooo = oo000 . getSetting ( 'mostrar_bus' )
O0o0Oo = oo000 . getSetting ( 'restante' )
Oo00OOOOO = oo000 . getSetting ( 'selecton' )
O0OO00o0OO = oo000 . getSetting ( 'aviso' )
I11i1 = oo000 . getSetting ( 'RealStream_Settings' )
iIi1ii1I1 = oo000 . getSetting ( 'Resolver_Settings' )
O0o0Oo = oo000 . getSetting ( 'restante' )
o0 = oo000 . getSetting ( 'fav' )
I11II1i = oo000 . getSetting ( 'Fontcolor' )
IIIII = oo000 . getSetting ( 'MenuColor' )
ooooooO0oo = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
IIiiiiiiIi1I1 = 'bienvenida'
I1IIIii = 'bienvenida'
copyright = oo000 . getSetting ( 'copyright' )
oOoOooOo0o0 = 'cGx1Z2luLnZpZGVvLg==' . decode ( 'base64' ) + copyright
OOOO = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
OOO00 = oo000 . getSetting ( 'Forceupdate' )
if OOO00 == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
iiiiiIIii = '.txt'
if 11 - 11 : O0o . iII111i
O000OO0 = 'aHR0cDovL2JpdC5seS8yU1FOSnlP' . decode ( 'base64' )
I11iii1Ii = ooooooO0oo + IIiiiiiiIi1I1 + iiiiiIIii
I1IIiiIiii = 'http://www.youtube.com'
O000oo0O = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
OOOOi11i1 = '.xsl.pt'
IIIii1II1II = 'L21hc3Rlci8=' . decode ( 'base64' )
i1I1iI = O000oo0O + OOOOi11i1
oo0OooOOo0 = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*texto3=[\'"](.*?)[\'"]\s*'
o0OO00oO = 'tvg-logo=[\'"](.*?)[\'"]'
if 54 - 54 : I1IiiI - O0o % I1Ii111
I11i1I1I = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)'
oO0Oo = '(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)'
oOOoo0Oo = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
o00OO00OoO = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
OOOO0OOoO0O0 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
O0Oo000ooO00 = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
oO0 = '#(.+?),(.+)\s*(.+)'
Ii1iIiII1ii1 = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
if 68 - 68 : II111iiii % iII111i + II111iiii
ooOooo000oOO = 'source src=[\'"](.*?)[\'"]\s*title=[\'"](.*?)[\'"]'
Oo0oOOo = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
Oo0OoO00oOO0o = '[\'"](.*?)[\'"]'
OOO00O = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
OOoOO0oo0ooO = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( 'base64' )
O0o0O00Oo0o0 = OOoOO0oo0ooO + O0
O00O0oOO00O00 = '[\'"](.*?)[\'"]'
i1Oo00 = 'UmVhbHN0cmVhbQ==' . decode ( 'base64' )
i1i = 'video=[\'"](.*?)[\'"]'
iiI111I1iIiI = '0110nhu' . replace ( '0110nhu' , 'nhu' )
IIIi1I1IIii1II = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( 'base64' ) + iiI111I1iIiI
O0ii1ii1ii = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
oooooOoo0ooo = '0110R0N' . replace ( '0110R0N' , 'R0N' )
I1I1IiI1 = 'aHR0cDovL2JpdC5seS8yWEIx' . decode ( 'base64' ) + oooooOoo0ooo
III1iII1I1ii = '0110pEJ' . replace ( '0110pEJ' , 'pEJ' )
oOOo0 = 'aHR0cDovL2JpdC5seS8yd1Nh' . decode ( 'base64' ) + III1iII1I1ii
oo00O00oO = 'ABBAOb5' . replace ( 'ABBAOb5' , 'Ob5' )
iIiIIIi = 'aHR0cDovL2JpdC5seS8yRVhV' . decode ( 'base64' ) + oo00O00oO
ooo00OOOooO = '0110jaw' . replace ( '0110jaw' , 'jaw' )
O00OOOoOoo0O = 'aHR0cDovL2JpdC5seS8yd01M' . decode ( 'base64' ) + ooo00OOOooO
O000OOo00oo = '01109DI' . replace ( '01109DI' , '9DI' )
oo0OOo = 'aHR0cDovL2JpdC5seS8ySXgz' . decode ( 'base64' ) + O000OOo00oo
ooOOO00Ooo = '01103hs' . replace ( '01103hs' , '3hs' )
IiIIIi1iIi = 'aHR0cDovL2JpdC5seS8zMW1U' . decode ( 'base64' ) + ooOOO00Ooo
ooOOoooooo = '01107DW' . replace ( '01107DW' , '7DW' )
II1I = 'aHR0cDovL2JpdC5seS8yV1ln' . decode ( 'base64' ) + ooOOoooooo
O0i1II1Iiii1I11 = '0110mLl' . replace ( '0110mLl' , 'mLl' )
IIII = 'aHR0cDovL2JpdC5seS8yS0cw' . decode ( 'base64' ) + O0i1II1Iiii1I11
iiIiI = '01102Hj' . replace ( '01102Hj' , '2Hj' )
o00oooO0Oo = 'aHR0cDovL2JpdC5seS8yWEJo' . decode ( 'base64' ) + iiIiI
o0O0OOO0Ooo = '0110fXg' . replace ( '0110fXg' , 'fXg' )
iiIiII1 = 'aHR0cDovL2JpdC5seS8ySTVy' . decode ( 'base64' ) + o0O0OOO0Ooo
OOO00O0O = '0110NMH' . replace ( '0110NMH' , 'NMH' )
iii = 'aHR0cDovL2JpdC5seS8yd0t6' . decode ( 'base64' ) + OOO00O0O
oOooOOOoOo = '0110bwQ' . replace ( '0110bwQ' , 'bwQ' )
i1Iii1i1I = 'aHR0cDovL2JpdC5seS8yd01V' . decode ( 'base64' ) + oOooOOOoOo
OOoO00 = '0110xzG' . replace ( '0110xzG' , 'xzG' )
IiI111111IIII = 'aHR0cDovL2JpdC5seS8yWHhz' . decode ( 'base64' ) + OOoO00
i1Ii = '0110x64' . replace ( '0110x64' , 'x64' )
ii111iI1iIi1 = 'aHR0cDovL2JpdC5seS8yRVlF' . decode ( 'base64' ) + i1Ii
OOO = '0110vUE' . replace ( '0110vUE' , 'vUE' )
oo0OOo0 = 'aHR0cDovL2JpdC5seS8yWmhW' . decode ( 'base64' ) + OOO
I11IiI = '01107ZL' . replace ( '01107ZL' , '7ZL' )
O0ooO0Oo00o = 'aHR0cDovL2JpdC5seS8yWm4w' . decode ( 'base64' ) + I11IiI
ooO0oOOooOo0 = '01106cf' . replace ( '01106cf' , '6cf' )
i1I1ii11i1Iii = 'aHR0cDovL2JpdC5seS8yRVlk' . decode ( 'base64' ) + ooO0oOOooOo0
I1IiiiiI = '0110Jtp' . replace ( '0110Jtp' , 'Jtp' )
o0OIiII = 'aHR0cDovL2JpdC5seS8yV3Nq' . decode ( 'base64' ) + I1IiiiiI
ii1iII1II = '0110a5b' . replace ( '0110a5b' , 'a5b' )
Iii1I1I11iiI1 = 'aHR0cDovL2JpdC5seS8yV3dj' . decode ( 'base64' ) + ii1iII1II
I1I1i1I = '0110Q7u' . replace ( '0110Q7u' , 'Q7u' )
ii1I = 'aHR0cDovL2JpdC5seS8yV3NL' . decode ( 'base64' ) + I1I1i1I
O0oO0 = '0110rsq' . replace ( '0110rsq' , 'rsq' )
oO0O0OO0O = 'aHR0cDovL2JpdC5seS8ySzhE' . decode ( 'base64' ) + O0oO0
OO = '0110DDR' . replace ( '0110DDR' , 'DDR' )
OoOoO = 'aHR0cDovL2JpdC5seS8ySzd5' . decode ( 'base64' ) + OO
Ii1I1i = '0110feQ' . replace ( '0110feQ' , 'feQ' )
OOI1iI1ii1II = 'aHR0cDovL2JpdC5seS8yS0cz' . decode ( 'base64' ) + Ii1I1i
O0O0OOOOoo = '0110MHY' . replace ( '0110MHY' , 'MHY' )
oOooO0 = 'aHR0cDovL2JpdC5seS8ySXVo' . decode ( 'base64' ) + O0O0OOOOoo
Ii1I1Ii = '0110xdb' . replace ( '0110xdb' , 'xdb' )
OOoO0 = 'aHR0cDovL2JpdC5seS8yWEJu' . decode ( 'base64' ) + Ii1I1Ii
OO0Oooo0oOO0O = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( 'base64' )
oOoOooOo0o0 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
o00O0 = '0110lxu' . replace ( '0110lxu' , 'lxu' )
oOO0O00Oo0O0o = 'aHR0cDovL2JpdC5seS8yV1Bj' . decode ( 'base64' ) + o00O0
if 26 - 26 : o00O0oo % iII111i
if 76 - 76 : O0o * O0O00o0OOO0
ii1 = '1001DTs' . replace ( '1001DTs' , 'DTs' )
I1iIIiiIIi1i = 'aHR0cDovL2JpdC5seS8ySzhP' . decode ( 'base64' ) + ii1
if 32 - 32 : o0
def O0O0ooOOO ( ) :
 if 61 - 61 : I11i - I1Ii111 - OoOoOO00
 if 25 - 25 : I1IiiI * ooOoO0o + iII111i . Ii1I . Ii1I
 try :
  if 58 - 58 : I1ii11iIi11i
  oOOo0O00o = iIiIi11 ( I1I1IiI1 )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( oOOo0O00o )
  for oooOo0OOOoo0 in OOOiiiiI :
   try :
    if 1 - 1 : o0oOOo0O0Ooo
    oOOo0 = oooOo0OOOoo0
    if 68 - 68 : O0O00o0OOO0 - I1ii11iIi11i / o0 / ooOoO0o
    OOoO = xbmc . Keyboard ( '' , 'Busqueda por titulo,actor, director, año, servidor:' )
    OOoO . doModal ( )
    if ( OOoO . isConfirmed ( ) ) :
     if 60 - 60 : ooOoO0o . OoOoOO00 + O0o / Ii1I . o0oOOo0O0Ooo
     OO0O000 = urllib . quote_plus ( OOoO . getText ( ) ) . replace ( '+' , ' ' )
     iiIiI1i1 = iIiIi11 ( oOOo0 )
     OOOiiiiI = re . compile ( I11i1I1I ) . findall ( iiIiI1i1 )
     if 15 - 15 : I11i % I1ii11iIi11i * ooOoO0o
     for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i in OOOiiiiI :
      if re . search ( OO0O000 , ooI1111i ( IiIi11iI . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       iIIii ( IiIi11iI , Oo0O00O000 , oO0O00oOOoooO , id , i11I1IiII1i1i )
       if 38 - 38 : I1Ii111 + o0oOOo0O0Ooo % I11ii1 % I11i - o00O0oo / OoO0O00
   except :
    pass
 except :
  pass
def o00O0O ( ) :
 if 1 - 1 : IiII + IiII % I11i + II111iiii
 if 56 - 56 : Ii1I
 ii1iii1i = iIiIi11 ( OO0Oooo0oOO0O )
 OOOiiiiI = re . compile ( Oo0OoO00oOO0o ) . findall ( ii1iii1i )
 for Iii1I1111ii in OOOiiiiI :
  try :
   if 100 - 100 : O0O00o0OOO0 % I1Ii111
   import xbmc
   import xbmcaddon
   if 86 - 86 : oO0o . I1IiiI - OoO0O00 . OOooOOo + o00O0oo
   __addon__ = xbmcaddon . Addon ( )
   __addonname__ = __addon__ . getAddonInfo ( 'name' )
   __icon__ = __addon__ . getAddonInfo ( 'icon' )
   if 57 - 57 : Ii1I . OoOoOO00 . O0o * II111iiii + o0 . O0o
   ii = oo000 . getAddonInfo ( 'version' )
   if 57 - 57 : o0
   ooOoO00 = "[COLOR gold]Version instalada: " + ii + " [/COLOR]" "[COLOR lime]Ultima Version: " + Iii1I1111ii + "  [/COLOR]"
   Ii1IIiI1i = 3000
   if 96 - 96 : II111iiii % I11ii1 / I11i
   xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , ooOoO00 , Ii1IIiI1i , __icon__ ) )
   if 36 - 36 : I1Ii111 + I1IiiI - o00O0oo - I1IiiI % ooOoO0o . IiII
   if 74 - 74 : II111iiii . I1ii11iIi11i
  except :
   pass
   if 36 - 36 : OoO0O00 . OOooOOo
   if 56 - 56 : oO0o . iII111i . I1ii11iIi11i
def o0O00Oo0 ( ) :
 if 17 - 17 : I1ii11iIi11i . I1IiiI + OOooOOo
 O0OO00o0OO = oo000 . getSetting ( 'aviso' )
 if O0OO00o0OO == 'true' :
  oOOo0O00o = iIiIi11 ( I11iii1Ii )
  OOOiiiiI = re . compile ( oo0OooOOo0 ) . findall ( oOOo0O00o )
  for IiII111i1i11 , i111iIi1i1II1 , oooO in OOOiiiiI :
   try :
    if 55 - 55 : I11ii1 - ooOoO0o + o0oOOo0O0Ooo + O0O00o0OOO0 % o00O0oo
    if 41 - 41 : OoOoOO00 - ooOoO0o - o00O0oo
    i1I1i111Ii = IiII111i1i11
    ooo = i111iIi1i1II1
    i1i1iI1iiiI = oooO
    if 52 - 52 : iII111i - oO0o + iII111i % Ii1I
    if 35 - 35 : Oo0Ooo
    ooOoO00 = "[COLOR=red][B]" + i1I1i111Ii + "[/B][/COLOR]"
    Ooo0oOooo0 = "[COLOR yellow]" + ooo + "[/COLOR]"
    oOOOoo00 = "[COLOR yellow]" + i1i1iI1iiiI + "[/COLOR]"
    if 70 - 70 : O0O00o0OOO0 / Oo0Ooo
    xbmcgui . Dialog ( ) . ok ( "Real Stream" , ooOoO00 , Ooo0oOooo0 , oOOOoo00 )
    if 85 - 85 : OoO0O00 % OoOoOO00 * OoO0O00 / iII111i
   except :
    pass
    if 96 - 96 : OoO0O00 + IiII
    if 44 - 44 : IiII
 if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
  if 20 - 20 : ooOoO0o + o00O0oo / I1IiiI % Oo0Ooo
  if 88 - 88 : I11i / o0oOOo0O0Ooo
  if 87 - 87 : iII111i - iII111i - O0O00o0OOO0 + IiII
def ooI1111i ( s ) :
 if 82 - 82 : IiII / Oo0Ooo . I1ii11iIi11i . I1Ii111 / Ii1I
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 42 - 42 : oO0o
def iiIiIIIiiI ( file ) :
 if 1 - 1 : O0O00o0OOO0
 try :
  iiI1IIIi = open ( file , 'r' )
  oOOo0O00o = iiI1IIIi . read ( )
  iiI1IIIi . close ( )
  return oOOo0O00o
 except :
  pass
  if 77 - 77 : Ii1I / OoO0O00
def iIiIi11 ( url ) :
 if 46 - 46 : Ii1I % Oo0Ooo . O0O00o0OOO0 % O0O00o0OOO0 + II111iiii
 try :
  II11IiIi11 = urllib2 . Request ( url )
  II11IiIi11 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  IIOOO0O00O0OOOO = urllib2 . urlopen ( II11IiIi11 )
  I1iiii1I = IIOOO0O00O0OOOO . read ( )
  IIOOO0O00O0OOOO . close ( )
  return I1iiii1I
 except urllib2 . URLError , OOo0 :
  print 'We failed to open "%s".' % url
  if hasattr ( OOo0 , 'code' ) :
   print 'We failed with error code - %s.' % OOo0 . code
  if hasattr ( OOo0 , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , OOo0 . reason
   if 77 - 77 : iII111i + OOooOOo / IiII + I1IiiI * Ii1I
def oO00ooooO0o ( url ) :
 II11IiIi11 = urllib2 . Request ( url )
 II11IiIi11 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 II11IiIi11 . add_header ( 'Referer' , '%s' % url )
 II11IiIi11 . add_header ( 'Connection' , 'keep-alive' )
 IIOOO0O00O0OOOO = urllib2 . urlopen ( II11IiIi11 )
 I1iiii1I = IIOOO0O00O0OOOO . read ( )
 IIOOO0O00O0OOOO . close ( )
 return I1iiii1I
 if 74 - 74 : oO0o - Ii1I . OoOoOO00
 if 43 - 43 : O0O00o0OOO0 / I1ii11iIi11i
def oo0o ( ) :
 if 13 - 13 : II111iiii + OoOoOO00 * Oo0Ooo % OoO0O00 - o0oOOo0O0Ooo * I1Ii111
 IIIII = oo000 . getSetting ( 'MenuColor' )
 if 26 - 26 : OoO0O00 * I1ii11iIi11i + I1Ii111
 if II == 'true' :
  o0oO0oooOoo ( '[COLOR %s]Peliculas[/COLOR] ' % IIIII , 'movieDB' , 116 , i1iiIIiiI111 , o0OO00 )
  o0oO0oooOoo ( '[COLOR %s]Series[/COLOR] ' % IIIII , 'movieDB' , 117 , oooOOOOO , o0OO00 )
  if 43 - 43 : I1IiiI
  if 39 - 39 : I1ii11iIi11i . Oo0Ooo * o00O0oo % I11ii1 . Oo0Ooo
 if I11i1 == 'true' :
  o0oO0oooOoo ( '[COLOR %s]Ajustes[/COLOR]' % IIIII , 'Settings' , 119 , i1iiIII111ii , o0OO00 )
  if 54 - 54 : I1Ii111
  if 45 - 45 : OoO0O00 - I1Ii111 + I1IiiI * o00O0oo . iII111i
  if O0OoO000O0OO == 'true' :
   I1III1111iIi ( )
   if 61 - 61 : I1Ii111 % I1Ii111 * Ii1I / Ii1I
  if iIi1ii1I1 == 'true' :
   I1i111I ( )
   OooOo0oo0O0o00O ( )
   if 4 - 4 : o00O0oo
  if OooO0 == 'false' :
   if 51 - 51 : OOooOOo - I1IiiI % IiII - o0oOOo0O0Ooo
   ooOoO00 = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   Ooo0oOooo0 = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Program.favoritos-realstream para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   oOOOoo00 = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 31 - 31 : O0O00o0OOO0 / oO0o - O0O00o0OOO0 - I1Ii111
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , ooOoO00 , Ooo0oOooo0 , oOOOoo00 )
   if 7 - 7 : O0O00o0OOO0 % I1IiiI . I11i + I1ii11iIi11i - ooOoO0o
def I1i11 ( ) :
 o0oO0oooOoo ( '[COLOR orange]Buscador por id[/COLOR]' , I1IIiiIiii , 127 , I11i , o0OO00 )
 if 27 - 27 : II111iiii % o0oOOo0O0Ooo % ooOoO0o . I1IiiI - oO0o + I11i
def IiIi1I1 ( ) :
 if 51 - 51 : O0o
 IIIII = oo000 . getSetting ( 'MenuColor' )
 o0oO0oooOoo ( '[COLOR %s]The movie DB[/COLOR]' % IIIII , 'movieDB' , 99 , I11i , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]Buscador por id[/COLOR]' % IIIII , I1IIiiIiii , 127 , I11i , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]Video tutoriales[/COLOR]' % IIIII , I1IIiiIiii , 125 , iIii1 , o0OO00 )
 if 25 - 25 : OoO0O00 + O0o * iII111i
 if 92 - 92 : I1ii11iIi11i + ooOoO0o + I1IiiI / Ii1I + o0
 if 18 - 18 : I11ii1 * I11i . O0O00o0OOO0 / iII111i / II111iiii
 if 21 - 21 : IiII / iII111i + o00O0oo + OoO0O00
 if 91 - 91 : II111iiii / OoOoOO00 + O0O00o0OOO0 + I11ii1 * II111iiii
 if 66 - 66 : Oo0Ooo % OoOoOO00 - I1IiiI + ooOoO0o * o0 . O0o
 o0oO0oooOoo ( '[COLOR %s]Autorizar OPENLOAD[/COLOR]' % IIIII , 'movieDB' , 97 , o0OoOoOO00 , o0OO00 )
 if 52 - 52 : I11ii1 + I1IiiI . O0O00o0OOO0 . iII111i . OOooOOo
 o0oO0oooOoo ( '[COLOR %s]listado Proxy[/COLOR]' % IIIII , 'movieDB' , 112 , oOOoO0 , o0OO00 )
 if 39 - 39: Ii1I11I + oo0 + iI1II - o0OOo0o0O0O
 oo0o ( )
 if 97 - 97 : I1ii11iIi11i / O0O00o0OOO0
 if 71 - 71 : o0oOOo0O0Ooo / OoOoOO00 . iII111i % OoO0O00 . I11i
 if 41 - 41 : OoOoOO00 * o0oOOo0O0Ooo / OoO0O00 . I1Ii111
 if 83 - 83 : O0O00o0OOO0 . I1IiiI / oO0o / I1Ii111 - o0oOOo0O0Ooo
 if 100 - 100 : OOooOOo
 if 46 - 46 : I11i / Oo0Ooo % O0O00o0OOO0 . Oo0Ooo * O0O00o0OOO0
 if 38 - 38 : iII111i - O0O00o0OOO0 / I1IiiI . o0
 if 45 - 45 : o0
 if 83 - 83 : I11i . OoO0O00
 if 58 - 58 : II111iiii + OoO0O00 % OoO0O00 / O0o / II111iiii
 if 62 - 62 : OOooOOo / iII111i
def o0OO0o0oOOO0O ( ) :
 iI = xbmcgui . Dialog ( )
 I1i11Ooo = (
 IiIIII1i11I ,
 OOOiII1 ,
 )
 if 21 - 21 : ooOoO0o
 OOo = iI . select ( '[B][COLOR=yellow]Listado de Proxys Gratuitos:[/COLOR][/B]' , [
 '[COLOR=orange]                      Accede a la web[/COLOR]' ,

 '[B][COLOR=gold]                      Volver al Menu [/COLOR][/B]' , ] )
 if 85 - 85 : oO0o * oO0o * I1ii11iIi11i . OoO0O00 . o00O0oo * I11ii1
 if OOo :
  if 65 - 65 : I1Ii111 * o0
  if OOo < 0 :
   return
  IIii11Ii1i1I = I1i11Ooo [ OOo - 2 ]
  return IIii11Ii1i1I ( )
 else :
  IIii11Ii1i1I = I1i11Ooo [ OOo ]
  return IIii11Ii1i1I ( )
 return
 if 100 - 100 : IiII . I11ii1 * iII111i / Oo0Ooo * OoOoOO00 % I11ii1
def Oooo0O ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 1 - 1 : I11ii1 % I11i * oO0o
oo00O0oO0O0 = Oooo0O ( )
if 30 - 30 : I1IiiI * OoO0O00
def IiIIII1i11I ( ) :
 if oo00O0oO0O0 == 'android' :
  ooo0OO0O0Oo = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://hidemyna.me/es/proxy-list/?country=ES&type=hs#list' ) )
  if 17 - 17 : Oo0Ooo . OoO0O00 / ooOoO0o % o0oOOo0O0Ooo % OoOoOO00 / II111iiii
 else :
  ooo0OO0O0Oo = webbrowser . open ( 'https://hidemyna.me/es/proxy-list/?country=ES&type=hs#list' )
  if 58 - 58 : oO0o . o0oOOo0O0Ooo + IiII - II111iiii / o0oOOo0O0Ooo / I1IiiI
  if 85 - 85 : I11i + I1Ii111
def OOOiII1 ( ) :
 if 10 - 10 : O0o / OOooOOo + I11i / OoOoOO00
 main ( )
 if 27 - 27 : o00O0oo
 if 67 - 67 : I1ii11iIi11i
def Ooo0O0oooo ( ) :
 if xbmc . getCondVisibility ( 'System.HasAddon(script.favourites)' ) :
  try :
   xbmc . executebuiltin ( "RunScript(script.favourites)" )
  except :
   pass
def iiI ( ) :
 oo000 . openSettings ( )
 if 81 - 81 : OOooOOo
 if 99 - 99 : IiII * o0oOOo0O0Ooo * o0
def oOIIiIi ( ) :
 urlresolver . display_settings ( )
 if 57 - 57 : o0oOOo0O0Ooo
def I1i111I ( ) :
 o0oO0oooOoo ( '[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % IIIII , 'resolve' , 120 , iI111I11I1I1 , o0OO00 )
 if 54 - 54 : oO0o + IiII + II111iiii
def OOoOooOoOOOoo ( ) :
 if 3 - 3 : o0oOOo0O0Ooo / I1Ii111 + O0o . I11ii1 . OOooOOo
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 83 - 83 : IiII + OoO0O00
def OooOo0oo0O0o00O ( ) :
 o0oO0oooOoo ( '[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % IIIII , 'resolve' , 140 , iI111I11I1I1 , o0OO00 )
 if 22 - 22 : o00O0oo % O0O00o0OOO0 * OoO0O00 - Ii1I / Oo0Ooo
def I1III1111iIi ( ) :
 if 86 - 86 : OoO0O00 . O0O00o0OOO0 % I11i / ooOoO0o * O0O00o0OOO0 / Ii1I
 IIIII = oo000 . getSetting ( 'MenuColor' )
 o0oO0oooOoo ( '[COLOR %s]Buscador[/COLOR]' % IIIII , 'search' , 111 , iIiiiI1IiI1I1 , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]Estrenos[/COLOR]' % IIIII , I1IIiiIiii , 3 , Oo , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]Todas[/COLOR]' % IIIII , I1IIiiIiii , 26 , I1ii11iIi11i , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]4K[/COLOR]' % IIIII , I1IIiiIiii , 141 , Oo0o0000o0o0 , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]Novedades[/COLOR]' % IIIII , I1IIiiIiii , 2 , O0O , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]Accion[/COLOR]' % IIIII , I1IIiiIiii , 5 , I1IiI , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]Animacion[/COLOR]' % IIIII , I1IIiiIiii , 6 , o0OOO , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]Aventuras[/COLOR]' % IIIII , I1IIiiIiii , 7 , iIiiiI , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]Belico[/COLOR]' % IIIII , I1IIiiIiii , 8 , Iii1ii1II11i , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]Ciencia Ficcion[/COLOR]' % IIIII , I1IIiiIiii , 9 , iI111iI , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]Comedia[/COLOR]' % IIIII , I1IIiiIiii , 10 , IiII , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]Crimen[/COLOR]' % IIIII , I1IIiiIiii , 11 , iI1Ii11111iIi , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]Drama[/COLOR]' % IIIII , I1IIiiIiii , 12 , i1i1II , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]Familiar[/COLOR]' % IIIII , I1IIiiIiii , 13 , O0oo0OO0 , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]Fantasia[/COLOR]' % IIIII , I1IIiiIiii , 14 , I1i1iiI1 , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]Historia[/COLOR]' % IIIII , I1IIiiIiii , 15 , iiIIIII1i1iI , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]Misterio[/COLOR]' % IIIII , I1IIiiIiii , 16 , oo00 , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]Musical[/COLOR]' % IIIII , I1IIiiIiii , 17 , o00 , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]Romance[/COLOR]' % IIIII , I1IIiiIiii , 18 , Oo0oO0ooo , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]Thriller[/COLOR]' % IIIII , I1IIiiIiii , 19 , i1111 , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]Suspense[/COLOR]' % IIIII , I1IIiiIiii , 20 , i1 , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]Terror[/COLOR]' % IIIII , I1IIiiIiii , 21 , oOOoo00O0O , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]Western[/COLOR]' % IIIII , I1IIiiIiii , 22 , i11 , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]Spain[/COLOR]' % IIIII , I1IIiiIiii , 23 , o0oOoO00o , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]Super heroes[/COLOR]' % IIIII , I1IIiiIiii , 24 , o0oO0 , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]Sagas[/COLOR]' % IIIII , I1IIiiIiii , 25 , I11 , o0OO00 )
 if 64 - 64 : II111iiii
 if 38 - 38 : O0o / I1ii11iIi11i - O0o . ooOoO0o
def Iiii1iI1i ( ) :
 if 68 - 68 : II111iiii + o00O0oo
 if 77 - 77 : o0
 try :
  if 65 - 65 : o0oOOo0O0Ooo . I1ii11iIi11i % IiII * OOooOOo
  I1ii1ii11i1I = iIiIi11 ( I1iIIiiIIi1i )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( I1ii1ii11i1I )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 11 - 11 : O0O00o0OOO0 - IiII + o0oOOo0O0Ooo - Oo0Ooo
   try :
    if 7 - 7 : O0o - ooOoO0o / o0oOOo0O0Ooo * o00O0oo . O0O00o0OOO0 * O0O00o0OOO0
    o0OoOO = oooOo0OOOoo0
    OOoO = xbmc . Keyboard ( '' , 'Buscar' )
    OOoO . doModal ( )
    if ( OOoO . isConfirmed ( ) ) :
     if 19 - 19 : Ii1I / o0 % Ii1I % O0O00o0OOO0 * O0o
     OO0O000 = urllib . quote_plus ( OOoO . getText ( ) ) . replace ( '+' , ' ' )
     ii1iii1i = iIiIi11 ( o0OoOO )
     OOOiiiiI = re . compile ( oOOoo0Oo ) . findall ( ii1iii1i )
     for oo , IiIi11iI , o0OO00 , Oo0O00O000 in OOOiiiiI :
      if re . search ( OO0O000 , ooI1111i ( IiIi11iI . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       o0oO0oooOoo ( IiIi11iI , Oo0O00O000 , 143 , oo , o0OO00 )
       if 19 - 19 : Oo0Ooo
   except :
    pass
 except :
  pass
  if 26 - 26 : OoO0O00 % I1ii11iIi11i % oO0o . I1ii11iIi11i % o00O0oo
def O0O0Oo00 ( ) :
 if 95 - 95 : O0o
 o0oO0oooOoo ( '[COLOR %s]Buscar Serie[/COLOR]' % IIIII , 'search' , 145 , oO0o0o0ooO0oO , o0OO00 )
 o0oO0oooOoo ( '[COLOR %s]Todas[/COLOR]' % IIIII , I1IIiiIiii , 142 , oo0o0O00 , o0OO00 )
 if 51 - 51 : o0oOOo0O0Ooo + O0o . OoOoOO00 . iII111i + I11i * I1ii11iIi11i
 if 72 - 72 : IiII + IiII / o0oOOo0O0Ooo . OoO0O00 % o00O0oo
def oOoO00o ( ) :
 if 41 - 41 : II111iiii + oO0o / I1ii11iIi11i . OoO0O00 % IiII % OoOoOO00
 try :
  if 70 - 70 : oO0o . OoO0O00 - O0O00o0OOO0
  I1ii1ii11i1I = iIiIi11 ( I1iIIiiIIi1i )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( I1ii1ii11i1I )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 30 - 30 : iII111i % I1ii11iIi11i
   try :
    if 89 - 89 : o0 + OoO0O00 + o0 * OoOoOO00 + Oo0Ooo % ooOoO0o
    o0OoOO = oooOo0OOOoo0
    if 59 - 59 : I1Ii111 + II111iiii
   except :
    pass
    if 88 - 88 : II111iiii - I11ii1
  ii1iii1i = iIiIi11 ( o0OoOO )
  OOOiiiiI = re . compile ( oOOoo0Oo ) . findall ( ii1iii1i )
  for oo , IiIi11iI , o0OO00 , Oo0O00O000 in OOOiiiiI :
   try :
    if 67 - 67 : I1Ii111 . oO0o + I11i - OoO0O00
    o0oO0oooOoo ( IiIi11iI , Oo0O00O000 , 143 , oo , o0OO00 )
    if 70 - 70 : I1Ii111 / o0oOOo0O0Ooo - Oo0Ooo - O0O00o0OOO0
   except :
    pass
 except :
  pass
  if 11 - 11 : Oo0Ooo . OoO0O00 . o0oOOo0O0Ooo / OoOoOO00 - ooOoO0o
def oO00O0 ( name , url ) :
 if 84 - 84 : I1IiiI . ooOoO0o - o0oOOo0O0Ooo . I11ii1 / o0oOOo0O0Ooo
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 47 - 47 : OoO0O00
 iiIiI1i1 = iIiIi11 ( url )
 OOOiiiiI = re . compile ( OOOO0OOoO0O0 ) . findall ( iiIiI1i1 )
 for IIi1IIIi , name , o0OO00 , url in OOOiiiiI :
  try :
   if 63 - 63 : O0O00o0OOO0 . OOooOOo / o0oOOo0O0Ooo * O0o + IiII % o00O0oo
   if 12 - 12 : o0 . OOooOOo . O0O00o0OOO0 - OoO0O00 % oO0o
   I11II1i = oo000 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % I11II1i + name + '[/COLOR]'
   O00Ooo ( name , url , 144 , IIi1IIIi , o0OO00 )
   if 71 - 71 : iII111i % I11ii1 - I1ii11iIi11i % ooOoO0o - I1IiiI
   if 67 - 67 : I1Ii111 + oO0o
  except :
   pass
   if 84 - 84 : I1IiiI * OoO0O00 - O0o * O0o
   if 8 - 8 : I11ii1 / OoOoOO00 . IiII
   if 41 - 41 : O0O00o0OOO0 + OOooOOo
def O00Ooo ( name , url , mode , iconimage , fanart ) :
 if 86 - 86 : I11i . Oo0Ooo - OOooOOo
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 56 - 56 : I1IiiI
 OOOO0OOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage="
 i1i1ii = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 i1i1ii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 i1i1ii . setProperty ( 'fanart_image' , fanart )
 i1i1ii . setProperty ( 'IsPlayable' , 'true' )
 iII1ii1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOOO0OOO , listitem = i1i1ii )
 return iII1ii1
 if 79 - 79 : OOooOOo . O0O00o0OOO0 * o00O0oo - I1Ii111 + I11ii1
def I1i1iiiI1 ( name , url ) :
 if 58 - 58 : oO0o . O0o - oO0o - o0 * o00O0oo
 if 28 - 28 : I11i * OOooOOo . ooOoO0o % ooOoO0o / ooOoO0o * o0
 if 'https://team.com' in url :
  if 64 - 64 : o0oOOo0O0Ooo - I1ii11iIi11i
  url = url . replace ( 'https://team.com' , 'https://verystream.com' )
  if 68 - 68 : I11ii1 - I1Ii111 - Oo0Ooo / I11i + I1Ii111 - OOooOOo
 if 'https://mybox.com' in url :
  if 75 - 75 : O0O00o0OOO0 / Ii1I % Oo0Ooo . OoO0O00 % OoO0O00 % o0oOOo0O0Ooo
  url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
  if 26 - 26 : o0oOOo0O0Ooo % II111iiii % Oo0Ooo % ooOoO0o * ooOoO0o * iII111i
 if 'https://drive.com' in url :
  if 24 - 24 : o0oOOo0O0Ooo % o0 - I11ii1 + I1ii11iIi11i * iII111i
  url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
  if 2 - 2 : o00O0oo - O0o
 if 'https://https://vidcloud.co/' in url :
  if 83 - 83 : IiII % Ii1I % o00O0oo - o0oOOo0O0Ooo * I1Ii111 / OoO0O00
  url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
  if 18 - 18 : OOooOOo + Oo0Ooo - o0oOOo0O0Ooo - I1ii11iIi11i
 if 'https://gounlimited.to' in url :
  if 71 - 71 : OoO0O00
  url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
  if 33 - 33 : o0
  if 62 - 62 : iII111i + o00O0oo + OoOoOO00 / OoO0O00
  if 7 - 7 : Ii1I + OoOoOO00 . I1ii11iIi11i / oO0o
 import resolveurl
 if 22 - 22 : I11ii1 - I11ii1 % I1Ii111 . o0 + IiII
 iIIi = urlresolver . HostedMediaFile ( url )
 if 81 - 81 : O0o . Ii1I / o0
 if 17 - 17 : II111iiii - I1Ii111 . O0o % Oo0Ooo + ooOoO0o - I11ii1
 if not iIIi :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
  return False
  if 78 - 78 : ooOoO0o * I11i . I1IiiI / I1IiiI
 try :
  oO0o00oo0 = iIIi . resolve ( )
  if not oO0o00oo0 or not isinstance ( oO0o00oo0 , basestring ) :
   try : ii1IIII = oO0o00oo0 . msg
   except : ii1IIII = url
   raise Exception ( ii1IIII )
 except Exception as OOo0 :
  try : ii1IIII = str ( OOo0 )
  except : ii1IIII = url
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado, reportalo en nuesto grupo de telegram [COLOR ligthblue] https://t.me/OficialNetai [/COLOR]  ,5000)" )
  return False
  if 9 - 9 : oO0o + I11i - Oo0Ooo - o00O0oo + Ii1I
  if 97 - 97 : I1Ii111
  if 92 - 92 : oO0o % iII111i * Oo0Ooo - iII111i . Ii1I
 OO0o = oo000 . getSetting ( 'notificar' )
 if OO0o == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
  if 95 - 95 : o0 % I1ii11iIi11i
  if 42 - 42 : OoO0O00 - O0O00o0OOO0 / OoO0O00 / o00O0oo
  oO00oOooooo0 = xbmcgui . ListItem ( path = oO0o00oo0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO00oOooooo0 )
  if 62 - 62 : I11i / I1ii11iIi11i - iII111i - I1ii11iIi11i + II111iiii + OoOoOO00
 else :
  if 23 - 23 : O0O00o0OOO0 + ooOoO0o . I11i * I1ii11iIi11i + iII111i
  oO00oOooooo0 = xbmcgui . ListItem ( path = oO0o00oo0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO00oOooooo0 )
  if 18 - 18 : O0o * Ii1I . O0o / I1IiiI
  if 8 - 8 : Ii1I
  if 4 - 4 : iII111i + iII111i * I11ii1 - I11i
def oOo ( ) :
 if 47 - 47 : Ii1I + O0O00o0OOO0 - IiII % OoO0O00
 if 52 - 52 : o0 / I11ii1 - ooOoO0o
 O0OOooOoO = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 O0OOooOoO . doModal ( )
 if not O0OOooOoO . isConfirmed ( ) :
  return None ;
 IiIi11iI = O0OOooOoO . getText ( ) . strip ( )
 if 5 - 5 : oO0o * I11i
 if 46 - 46 : I11ii1
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 33 - 33 : O0O00o0OOO0 - o0oOOo0O0Ooo * OoO0O00 - oO0o - I1Ii111
  ooo0OO0O0Oo = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + IiIi11iI + '&language=es-ES' ) )
  if 84 - 84 : o0 + oO0o - I11i * I11i
  if 61 - 61 : OoO0O00 . IiII . OoO0O00 / oO0o
  return 'android'
  if 72 - 72 : OoOoOO00
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 82 - 82 : I11i + OoO0O00 / II111iiii * iII111i . OoO0O00
  ooo0OO0O0Oo = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + IiIi11iI + '&language=es-ES' )
  if 63 - 63 : iII111i
  if 6 - 6 : I11ii1 / iII111i
  return 'windows'
  if 57 - 57 : ooOoO0o
  if 67 - 67 : OOooOOo . I11ii1
def i1II1I1Iii1 ( ) :
 if 23 - 23 : OoOoOO00 . Ii1I * OOooOOo
 try :
  if 15 - 15 : I11i
  oOOo0O00o = iIiIi11 ( I1I1IiI1 )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( oOOo0O00o )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 62 - 62 : o00O0oo
   try :
    if 51 - 51 : I11i
    all = oooOo0OOOoo0
    if 14 - 14 : O0o % IiII % oO0o - II111iiii
   except :
    pass
    if 53 - 53 : o00O0oo % oO0o
  iiIiI1i1 = iIiIi11 ( all )
  OOOiiiiI = re . compile ( I11i1I1I ) . findall ( iiIiI1i1 )
  for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i in OOOiiiiI :
   try :
    if 59 - 59 : I1Ii111 % Oo0Ooo . OoOoOO00 + o0oOOo0O0Ooo * O0o
    iIIii ( IiIi11iI , Oo0O00O000 , oO0O00oOOoooO , id , i11I1IiII1i1i )
    if 41 - 41 : o00O0oo % iII111i
   except :
    pass
 except :
  pass
  if 12 - 12 : I1Ii111
def iiI11Iii ( ) :
 if 37 - 37 : o00O0oo % OOooOOo
 try :
  if 79 - 79 : iII111i + I1ii11iIi11i / I1ii11iIi11i
  O0O = iIiIi11 ( oOOo0 )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( O0O )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 71 - 71 : I1Ii111 * OOooOOo % OoO0O00 % OOooOOo / I1ii11iIi11i
   try :
    if 56 - 56 : OoO0O00 % II111iiii * Oo0Ooo . OOooOOo * I1IiiI
    o0OoOO = oooOo0OOOoo0
    if 23 - 23 : II111iiii
   except :
    pass
    if 39 - 39 : Ii1I - iII111i % O0O00o0OOO0 * OOooOOo - I1Ii111 / O0O00o0OOO0
  ii1iii1i = iIiIi11 ( o0OoOO )
  OOOiiiiI = re . compile ( I11i1I1I ) . findall ( ii1iii1i )
  for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i in OOOiiiiI :
   try :
    if 29 - 29 : iII111i
    iIIii ( IiIi11iI , Oo0O00O000 , oO0O00oOOoooO , id , i11I1IiII1i1i )
    if 52 - 52 : II111iiii / OoOoOO00
   except :
    pass
 except :
  pass
  if 1 - 1 : I11ii1
def O0o0O0 ( ) :
 if 29 - 29 : I1ii11iIi11i * o0oOOo0O0Ooo * OoO0O00 - iII111i * o0oOOo0O0Ooo
 try :
  if 41 - 41 : I1IiiI
  Oo = iIiIi11 ( iIiIIIi )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( Oo )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 30 - 30 : I11ii1 % O0O00o0OOO0 * I1Ii111 - iII111i * o00O0oo % I11ii1
   try :
    Ii1II1I11i1 = oooOo0OOOoo0
   except :
    pass
    if 96 - 96 : O0O00o0OOO0 . I1IiiI / O0O00o0OOO0 % I1IiiI
  oOOo0O00o = iIiIi11 ( Ii1II1I11i1 )
  OOOiiiiI = re . compile ( I11i1I1I ) . findall ( oOOo0O00o )
  for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i in OOOiiiiI :
   try :
    iIIii ( IiIi11iI , Oo0O00O000 , oO0O00oOOoooO , id , i11I1IiII1i1i )
    if 94 - 94 : O0o + o0 / I1Ii111
   except :
    pass
 except :
  pass
  if 91 - 91 : ooOoO0o / OoOoOO00 * OoOoOO00
def oOoooooOoO ( ) :
 if 68 - 68 : o00O0oo - II111iiii - IiII + I11i
 try :
  if 99 - 99 : I11i * o0 * OoOoOO00 / I1IiiI - I11i % Ii1I
  oOOo0O00o = iIiIi11 ( db2 )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( oOOo0O00o )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 51 - 51 : OoO0O00 % I1Ii111 * I11i
   try :
    if 69 - 69 : OoOoOO00
    Ii111 = oooOo0OOOoo0
    if 71 - 71 : o0oOOo0O0Ooo * Oo0Ooo / iII111i
   except :
    pass
    if 23 - 23 : o0oOOo0O0Ooo
    if 24 - 24 : Oo0Ooo + Oo0Ooo * O0O00o0OOO0
  oOOo0O00o = iIiIi11 ( Ii111 )
  OOOiiiiI = re . compile ( I11i1I1I ) . findall ( oOOo0O00o )
  for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i in OOOiiiiI :
   try :
    iIIii ( IiIi11iI , Oo0O00O000 , oO0O00oOOoooO , id , i11I1IiII1i1i )
    if 18 - 18 : O0O00o0OOO0 * ooOoO0o - o00O0oo
   except :
    pass
 except :
  pass
  if 31 - 31 : oO0o - I1IiiI % I11i % IiII
def I111i1i1111 ( ) :
 if 87 - 87 : iII111i / OoO0O00 - oO0o % I11i % O0o % oO0o
 try :
  if 29 - 29 : OoO0O00 . I1ii11iIi11i % iII111i - O0O00o0OOO0
  oOOo0O00o = iIiIi11 ( O00OOOoOoo0O )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( oOOo0O00o )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 8 - 8 : OoOoOO00
   try :
    if 32 - 32 : IiII / o0oOOo0O0Ooo
    IIII1 = oooOo0OOOoo0
    if 73 - 73 : ooOoO0o * OoO0O00 . I1IiiI . O0o
   except :
    pass
    if 55 - 55 : oO0o
    if 77 - 77 : o0oOOo0O0Ooo
  oOOo0O00o = iIiIi11 ( IIII1 )
  OOOiiiiI = re . compile ( I11i1I1I ) . findall ( oOOo0O00o )
  for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i in OOOiiiiI :
   try :
    iIIii ( IiIi11iI , Oo0O00O000 , oO0O00oOOoooO , id , i11I1IiII1i1i )
    if 16 - 16 : I1ii11iIi11i * o0oOOo0O0Ooo / Oo0Ooo - O0O00o0OOO0
   except :
    pass
 except :
  pass
  if 3 - 3 : I1ii11iIi11i * I11ii1 + o0oOOo0O0Ooo - OOooOOo
def I1I1i ( ) :
 if 57 - 57 : I1ii11iIi11i - Ii1I + OOooOOo % oO0o
 try :
  if 26 - 26 : O0O00o0OOO0 . O0O00o0OOO0
  oOOo0O00o = iIiIi11 ( oo0OOo )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( oOOo0O00o )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 35 - 35 : o0 . I11i * II111iiii
   try :
    if 44 - 44 : II111iiii / oO0o
    I1IIIiIiIi = oooOo0OOOoo0
    if 43 - 43 : o0 % O0O00o0OOO0
   except :
    pass
    if 69 - 69 : O0O00o0OOO0 % OOooOOo
  oOOo0O00o = iIiIi11 ( I1IIIiIiIi )
  OOOiiiiI = re . compile ( I11i1I1I ) . findall ( oOOo0O00o )
  for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i in OOOiiiiI :
   try :
    iIIii ( IiIi11iI , Oo0O00O000 , oO0O00oOOoooO , id , i11I1IiII1i1i )
    if 86 - 86 : IiII / IiII
   except :
    pass
 except :
  pass
  if 28 - 28 : II111iiii / Ii1I . Oo0Ooo / o0oOOo0O0Ooo
def IIIII1 ( ) :
 if 32 - 32 : I11i * I1ii11iIi11i % I11ii1 * o00O0oo . I1IiiI
 try :
  if 48 - 48 : O0O00o0OOO0 * O0O00o0OOO0
  oOOo0O00o = iIiIi11 ( IiIIIi1iIi )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( oOOo0O00o )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 13 - 13 : o00O0oo / ooOoO0o + I11i . Ii1I % I11ii1
   try :
    if 48 - 48 : I1ii11iIi11i / II111iiii - Ii1I * IiII / OoO0O00
    iIi1Ii1i1iI = oooOo0OOOoo0
    if 5 - 5 : iII111i + I1IiiI + I1IiiI . o0 - I11ii1
   except :
    pass
    if 63 - 63 : IiII
    if 71 - 71 : OoOoOO00 . o00O0oo * O0O00o0OOO0 % OoO0O00 + I1Ii111
  oOOo0O00o = iIiIi11 ( iIi1Ii1i1iI )
  OOOiiiiI = re . compile ( I11i1I1I ) . findall ( oOOo0O00o )
  for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i in OOOiiiiI :
   try :
    iIIii ( IiIi11iI , Oo0O00O000 , oO0O00oOOoooO , id , i11I1IiII1i1i )
    if 36 - 36 : O0o
   except :
    pass
 except :
  pass
  if 49 - 49 : I1Ii111 / OoO0O00 / I1ii11iIi11i
def IIiI1 ( ) :
 if 19 - 19 : O0o
 try :
  if 78 - 78 : I1Ii111 % Ii1I
  oOOo0O00o = iIiIi11 ( II1I )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( oOOo0O00o )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 39 - 39 : iII111i + I1ii11iIi11i - Oo0Ooo - Ii1I
   try :
    if 7 - 7 : O0o . I11i / iII111i . I1Ii111 * ooOoO0o - o0oOOo0O0Ooo
    i1iI1 = oooOo0OOOoo0
    if 8 - 8 : I11ii1 * I1IiiI
   except :
    pass
    if 73 - 73 : Ii1I / IiII / ooOoO0o / OOooOOo
    if 11 - 11 : I11i + O0o - OoO0O00 / OOooOOo
  oOOo0O00o = iIiIi11 ( i1iI1 )
  OOOiiiiI = re . compile ( I11i1I1I ) . findall ( oOOo0O00o )
  for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i in OOOiiiiI :
   try :
    iIIii ( IiIi11iI , Oo0O00O000 , oO0O00oOOoooO , id , i11I1IiII1i1i )
    if 34 - 34 : I11ii1
   except :
    pass
 except :
  pass
  if 45 - 45 : I11ii1 / oO0o / o00O0oo
def ii1I1IiiI1ii1i ( ) :
 if 73 - 73 : Ii1I - I1ii11iIi11i * OoOoOO00 / II111iiii * I1Ii111 % o0oOOo0O0Ooo
 try :
  if 56 - 56 : OoO0O00 * oO0o . oO0o . iII111i
  oOOo0O00o = iIiIi11 ( IIII )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( oOOo0O00o )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 24 - 24 : oO0o . ooOoO0o * o00O0oo % O0O00o0OOO0 / I1Ii111
   try :
    if 58 - 58 : I1ii11iIi11i - iII111i % I1IiiI . I1ii11iIi11i % OOooOOo % O0o
    O0o = oooOo0OOOoo0
    if 51 - 51 : ooOoO0o . oO0o
   except :
    pass
    if 45 - 45 : OoOoOO00 - oO0o / I1IiiI . iII111i
    if 5 - 5 : Ii1I . Oo0Ooo % Oo0Ooo
  oOOo0O00o = iIiIi11 ( O0o )
  OOOiiiiI = re . compile ( I11i1I1I ) . findall ( oOOo0O00o )
  for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i in OOOiiiiI :
   try :
    iIIii ( IiIi11iI , Oo0O00O000 , oO0O00oOOoooO , id , i11I1IiII1i1i )
    if 56 - 56 : OoO0O00 - ooOoO0o - OoOoOO00
   except :
    pass
 except :
  pass
  if 8 - 8 : o0 / I1Ii111 . I1ii11iIi11i + iII111i / II111iiii
  if 31 - 31 : I11ii1 - Oo0Ooo + O0O00o0OOO0 . oO0o / O0o % Oo0Ooo
def oO0OoO00o ( ) :
 if 49 - 49 : I1Ii111 . iII111i . II111iiii - o0oOOo0O0Ooo / o00O0oo
 try :
  if 62 - 62 : I1Ii111
  oOOo0O00o = iIiIi11 ( o00oooO0Oo )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( oOOo0O00o )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 1 - 1 : O0o / O0o - II111iiii
   try :
    if 87 - 87 : oO0o / I1IiiI * O0o / Ii1I
    II1iiiiII = oooOo0OOOoo0
    if 16 - 16 : IiII + I11ii1 / Ii1I
   except :
    pass
    if 82 - 82 : O0o * II111iiii % o0oOOo0O0Ooo - OoO0O00
    if 90 - 90 : oO0o . IiII * OoOoOO00 - OoOoOO00
  oOOo0O00o = iIiIi11 ( II1iiiiII )
  OOOiiiiI = re . compile ( I11i1I1I ) . findall ( oOOo0O00o )
  for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i in OOOiiiiI :
   try :
    iIIii ( IiIi11iI , Oo0O00O000 , oO0O00oOOoooO , id , i11I1IiII1i1i )
    if 16 - 16 : I1ii11iIi11i * OoOoOO00 - Ii1I . O0o % ooOoO0o / Ii1I
   except :
    pass
 except :
  pass
  if 14 - 14 : Oo0Ooo * o0 * iII111i / Oo0Ooo * O0o / ooOoO0o
  if 77 - 77 : OOooOOo + o0 + o0 * o00O0oo / OoO0O00 . o00O0oo
def O0OoOO0oo0 ( ) :
 if 61 - 61 : O0o + Oo0Ooo + II111iiii / II111iiii % o0oOOo0O0Ooo
 try :
  if 42 - 42 : o00O0oo * o0 . O0o * I1ii11iIi11i + I11i
  oOOo0O00o = iIiIi11 ( iiIiII1 )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( oOOo0O00o )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 25 - 25 : ooOoO0o . I1ii11iIi11i + IiII
   try :
    if 75 - 75 : O0o - Ii1I % O0O00o0OOO0 + II111iiii
    oOO = oooOo0OOOoo0
    if 30 - 30 : O0O00o0OOO0 / OOooOOo + IiII
   except :
    pass
    if 6 - 6 : O0O00o0OOO0 . ooOoO0o + o00O0oo . o0
    if 70 - 70 : OOooOOo
  oOOo0O00o = iIiIi11 ( oOO )
  OOOiiiiI = re . compile ( I11i1I1I ) . findall ( oOOo0O00o )
  for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i in OOOiiiiI :
   try :
    iIIii ( IiIi11iI , Oo0O00O000 , oO0O00oOOoooO , id , i11I1IiII1i1i )
    if 46 - 46 : ooOoO0o - OoOoOO00
   except :
    pass
    if 46 - 46 : o0 % o00O0oo
 except :
  pass
  if 72 - 72 : Oo0Ooo
  if 45 - 45 : oO0o - Ii1I % o0
def O0o0OO0000ooo ( ) :
 if 45 - 45 : Oo0Ooo . IiII / I11i / O0o
 try :
  if 55 - 55 : O0o
  oOOo0O00o = iIiIi11 ( iii )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( oOOo0O00o )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 24 - 24 : OOooOOo + IiII . Ii1I / IiII
   try :
    if 56 - 56 : Oo0Ooo . II111iiii - I1Ii111 * o0oOOo0O0Ooo * o0
    iIIII1iIIii = oooOo0OOOoo0
    if 60 - 60 : I11i / o0 - o0oOOo0O0Ooo . oO0o + I1IiiI
   except :
    pass
    if 43 - 43 : Oo0Ooo / o0oOOo0O0Ooo % Ii1I - I1Ii111
    if 62 - 62 : ooOoO0o
  oOOo0O00o = iIiIi11 ( iIIII1iIIii )
  OOOiiiiI = re . compile ( I11i1I1I ) . findall ( oOOo0O00o )
  for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i in OOOiiiiI :
   try :
    iIIii ( IiIi11iI , Oo0O00O000 , oO0O00oOOoooO , id , i11I1IiII1i1i )
    if 63 - 63 : I1Ii111 + I11ii1 * IiII / Ii1I / oO0o * Oo0Ooo
   except :
    pass
    if 57 - 57 : I11i - IiII / I11ii1 % II111iiii
 except :
  pass
  if 3 - 3 : O0O00o0OOO0 . I11ii1 % I1ii11iIi11i + iII111i
def oOOO00o000o ( ) :
 if 51 - 51 : I1Ii111 . I1ii11iIi11i
 try :
  if 73 - 73 : OoO0O00 . I1ii11iIi11i / o0 % o00O0oo
  oOOo0O00o = iIiIi11 ( i1Iii1i1I )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( oOOo0O00o )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 65 - 65 : O0o - I1ii11iIi11i - o00O0oo
   try :
    if 42 - 42 : o0oOOo0O0Ooo * I1ii11iIi11i % OoOoOO00 - o00O0oo % O0o
    iIi11i1 = oooOo0OOOoo0
    if 58 - 58 : O0o - ooOoO0o % I1ii11iIi11i
   except :
    pass
    if 4 - 4 : OoOoOO00 + I11ii1 + OoOoOO00
  oOOo0O00o = iIiIi11 ( iIi11i1 )
  OOOiiiiI = re . compile ( I11i1I1I ) . findall ( oOOo0O00o )
  for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i in OOOiiiiI :
   try :
    iIIii ( IiIi11iI , Oo0O00O000 , oO0O00oOOoooO , id , i11I1IiII1i1i )
    if 31 - 31 : o00O0oo
   except :
    pass
 except :
  pass
  if 78 - 78 : II111iiii + Ii1I + o0 / Ii1I % Oo0Ooo % O0o
  if 83 - 83 : Oo0Ooo % I11i % Ii1I % o0 . iII111i % I1IiiI
def oO00oo0o00o0o ( ) :
 if 28 - 28 : Oo0Ooo + Oo0Ooo
 try :
  if 28 - 28 : IiII
  oOOo0O00o = iIiIi11 ( IiI111111IIII )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( oOOo0O00o )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 52 - 52 : I1ii11iIi11i + Oo0Ooo
   try :
    if 71 - 71 : I1IiiI / IiII
    IiIIIIIi = oooOo0OOOoo0
    if 11 - 11 : OOooOOo
   except :
    pass
    if 18 - 18 : O0O00o0OOO0 - IiII % O0O00o0OOO0 / ooOoO0o
    if 68 - 68 : o00O0oo * Oo0Ooo + o0 % I11i
  oOOo0O00o = iIiIi11 ( IiIIIIIi )
  OOOiiiiI = re . compile ( I11i1I1I ) . findall ( oOOo0O00o )
  for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i in OOOiiiiI :
   try :
    iIIii ( IiIi11iI , Oo0O00O000 , oO0O00oOOoooO , id , i11I1IiII1i1i )
    if 46 - 46 : I11i % OoOoOO00 / IiII * oO0o * I1Ii111
   except :
    pass
 except :
  pass
  if 67 - 67 : I11i * I11i . I11i + o00O0oo / IiII
  if 13 - 13 : O0O00o0OOO0
def IiIi1iIIi1 ( ) :
 if 35 - 35 : o00O0oo - o00O0oo + OoOoOO00 - I1IiiI - o0
 try :
  if 58 - 58 : I11i - O0O00o0OOO0 - OoO0O00
  oOOo0O00o = iIiIi11 ( ii111iI1iIi1 )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( oOOo0O00o )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 96 - 96 : Oo0Ooo
   try :
    if 82 - 82 : I11i + I1IiiI - O0o % IiII * II111iiii
    O0OoO0ooOO0o = oooOo0OOOoo0
    if 31 - 31 : I11ii1 + I1IiiI + I11ii1 . Oo0Ooo + oO0o / Ii1I
   except :
    pass
  oOOo0O00o = iIiIi11 ( O0OoO0ooOO0o )
  OOOiiiiI = re . compile ( I11i1I1I ) . findall ( oOOo0O00o )
  for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i in OOOiiiiI :
   try :
    iIIii ( IiIi11iI , Oo0O00O000 , oO0O00oOOoooO , id , i11I1IiII1i1i )
    if 6 - 6 : oO0o % O0o * ooOoO0o / I1ii11iIi11i + oO0o
   except :
    pass
 except :
  pass
  if 39 - 39 : I11i - oO0o / O0O00o0OOO0 * OoO0O00
def OoOo0oOooOoOO ( ) :
 if 61 - 61 : Ii1I / I11i - oO0o
 try :
  if 19 - 19 : O0O00o0OOO0 - Ii1I / Ii1I + oO0o
  oOOo0O00o = iIiIi11 ( oo0OOo0 )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( oOOo0O00o )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 98 - 98 : Oo0Ooo % I1Ii111 + ooOoO0o . I11ii1
   try :
    if 99 - 99 : I1IiiI + I1IiiI * ooOoO0o + I1IiiI * IiII
    oo00ooOoO00 = oooOo0OOOoo0
    if 93 - 93 : iII111i % I11i . I1IiiI / O0O00o0OOO0 * IiII
   except :
    pass
    if 29 - 29 : Ii1I
    if 86 - 86 : o0oOOo0O0Ooo . O0o
  oOOo0O00o = iIiIi11 ( oo00ooOoO00 )
  OOOiiiiI = re . compile ( I11i1I1I ) . findall ( oOOo0O00o )
  for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i in OOOiiiiI :
   try :
    iIIii ( IiIi11iI , Oo0O00O000 , oO0O00oOOoooO , id , i11I1IiII1i1i )
    if 2 - 2 : OoO0O00
   except :
    pass
 except :
  pass
  if 60 - 60 : OOooOOo
  if 81 - 81 : I11i % o00O0oo
def o00oOoOo0 ( ) :
 if 16 - 16 : o00O0oo * OOooOOo / IiII
 try :
  if 22 - 22 : IiII + Oo0Ooo % oO0o / ooOoO0o / o00O0oo
  oOOo0O00o = iIiIi11 ( O0ooO0Oo00o )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( oOOo0O00o )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 54 - 54 : I11i % O0o . II111iiii
   try :
    if 93 - 93 : I11ii1 % II111iiii % o0
    o0O0O0ooo0oOO = oooOo0OOOoo0
    if 40 - 40 : ooOoO0o % OoO0O00 - I1Ii111 + Ii1I / I1Ii111
   except :
    pass
    if 84 - 84 : I1IiiI
    if 11 - 11 : o0oOOo0O0Ooo / II111iiii / I1IiiI
  oOOo0O00o = iIiIi11 ( o0O0O0ooo0oOO )
  OOOiiiiI = re . compile ( I11i1I1I ) . findall ( oOOo0O00o )
  for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i in OOOiiiiI :
   try :
    iIIii ( IiIi11iI , Oo0O00O000 , oO0O00oOOoooO , id , i11I1IiII1i1i )
    if 94 - 94 : I11ii1 * ooOoO0o - O0o . Oo0Ooo
   except :
    pass
 except :
  pass
  if 66 - 66 : I11ii1 - I1Ii111 * I11i / IiII * o0oOOo0O0Ooo * OOooOOo
def oo000ii ( ) :
 if 34 - 34 : I11ii1
 try :
  if 27 - 27 : o0 + OoO0O00 - I11i
  oOOo0O00o = iIiIi11 ( i1I1ii11i1Iii )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( oOOo0O00o )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 15 - 15 : IiII / ooOoO0o * I1IiiI . o0oOOo0O0Ooo - OOooOOo
   try :
    if 90 - 90 : IiII
    OoO = oooOo0OOOoo0
    if 94 - 94 : O0O00o0OOO0 + o00O0oo % Ii1I
   except :
    pass
    if 1 - 1 : I11i % o0 - I1Ii111 + IiII + I1IiiI * Ii1I
    if 97 - 97 : I11i
  oOOo0O00o = iIiIi11 ( OoO )
  OOOiiiiI = re . compile ( I11i1I1I ) . findall ( oOOo0O00o )
  for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i in OOOiiiiI :
   try :
    iIIii ( IiIi11iI , Oo0O00O000 , oO0O00oOOoooO , id , i11I1IiII1i1i )
    if 77 - 77 : II111iiii / OoO0O00 + O0o % IiII
   except :
    pass
 except :
  pass
  if 36 - 36 : IiII
  if 74 - 74 : OoO0O00
def Iiiiii111i1ii ( ) :
 if 100 - 100 : I1IiiI
 try :
  if 79 - 79 : Oo0Ooo
  oOOo0O00o = iIiIi11 ( o0OIiII )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( oOOo0O00o )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 81 - 81 : I1Ii111 + Oo0Ooo * o0 - Oo0Ooo . I1Ii111
   try :
    if 48 - 48 : ooOoO0o . OoO0O00 . I1ii11iIi11i . I11i % iII111i / O0O00o0OOO0
    i1i1iII1 = oooOo0OOOoo0
    if 84 - 84 : iII111i % Oo0Ooo + OOooOOo . iII111i % OOooOOo
   except :
    pass
    if 93 - 93 : I1IiiI
    if 85 - 85 : II111iiii % II111iiii + I1IiiI / I1Ii111
  oOOo0O00o = iIiIi11 ( i1i1iII1 )
  OOOiiiiI = re . compile ( I11i1I1I ) . findall ( oOOo0O00o )
  for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i in OOOiiiiI :
   try :
    iIIii ( IiIi11iI , Oo0O00O000 , oO0O00oOOoooO , id , i11I1IiII1i1i )
    if 89 - 89 : o00O0oo % OoOoOO00 % IiII
   except :
    pass
 except :
  pass
  if 53 - 53 : IiII * OoO0O00 . I11i
  if 96 - 96 : I1ii11iIi11i % OoOoOO00 . Ii1I . I1IiiI
def iii11i1IIII ( ) :
 if 97 - 97 : I1Ii111 / IiII . o0oOOo0O0Ooo
 try :
  if 44 - 44 : o00O0oo % ooOoO0o . o0
  oOOo0O00o = iIiIi11 ( Iii1I1I11iiI1 )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( oOOo0O00o )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 18 - 18 : Oo0Ooo + ooOoO0o * I1ii11iIi11i - I1Ii111 / I1ii11iIi11i
   try :
    if 78 - 78 : ooOoO0o . O0o
    Ii = oooOo0OOOoo0
    if 14 - 14 : I11ii1 - Oo0Ooo / I1IiiI % O0o . I11i
   except :
    pass
    if 18 - 18 : IiII * IiII % IiII
    if 17 - 17 : I1IiiI * I11i * iII111i * o0oOOo0O0Ooo * ooOoO0o % OoOoOO00
  oOOo0O00o = iIiIi11 ( Ii )
  OOOiiiiI = re . compile ( I11i1I1I ) . findall ( oOOo0O00o )
  for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i in OOOiiiiI :
   try :
    iIIii ( IiIi11iI , Oo0O00O000 , oO0O00oOOoooO , id , i11I1IiII1i1i )
    if 33 - 33 : iII111i * iII111i . I11ii1 . II111iiii
   except :
    pass
 except :
  pass
  if 48 - 48 : Ii1I . o00O0oo + I11i % iII111i / II111iiii
  if 74 - 74 : o0oOOo0O0Ooo . I1IiiI - I1ii11iIi11i + O0o % II111iiii % I11i
def o00iiI1Ii1 ( ) :
 if 8 - 8 : II111iiii / o0oOOo0O0Ooo + Ii1I * o00O0oo % O0o . ooOoO0o
 try :
  if 6 - 6 : O0o % oO0o . oO0o - iII111i / ooOoO0o . OoOoOO00
  oOOo0O00o = iIiIi11 ( ii1I )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( oOOo0O00o )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 99 - 99 : I11i . o0
   try :
    if 59 - 59 : ooOoO0o / oO0o / I1Ii111 / I1IiiI / I11i + Ii1I
    ii1i = oooOo0OOOoo0
    if 46 - 46 : O0o
   except :
    pass
    if 29 - 29 : o0oOOo0O0Ooo . I11i % Ii1I * o0oOOo0O0Ooo - Ii1I * Oo0Ooo
    if 35 - 35 : o0oOOo0O0Ooo - O0o . OoOoOO00
  oOOo0O00o = iIiIi11 ( ii1i )
  OOOiiiiI = re . compile ( I11i1I1I ) . findall ( oOOo0O00o )
  for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i in OOOiiiiI :
   try :
    iIIii ( IiIi11iI , Oo0O00O000 , oO0O00oOOoooO , id , i11I1IiII1i1i )
    if 95 - 95 : I1ii11iIi11i + I1ii11iIi11i - I1Ii111 - O0O00o0OOO0
   except :
    pass
 except :
  pass
  if 45 - 45 : o00O0oo . OoO0O00
  if 27 - 27 : o00O0oo * oO0o . I11i
def oOOoo ( ) :
 if 13 - 13 : iII111i / II111iiii
 try :
  if 32 - 32 : Ii1I + I1ii11iIi11i . o0
  oOOo0O00o = iIiIi11 ( oO0O0OO0O )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( oOOo0O00o )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 41 - 41 : I11i . II111iiii / ooOoO0o
   try :
    if 98 - 98 : I11i % o0oOOo0O0Ooo
    iII1111III1I = oooOo0OOOoo0
    if 14 - 14 : OOooOOo / OOooOOo * I1IiiI . IiII
   except :
    pass
    if 59 - 59 : o0oOOo0O0Ooo * II111iiii
  oOOo0O00o = iIiIi11 ( iII1111III1I )
  OOOiiiiI = re . compile ( I11i1I1I ) . findall ( oOOo0O00o )
  for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i in OOOiiiiI :
   try :
    iIIii ( IiIi11iI , Oo0O00O000 , oO0O00oOOoooO , id , i11I1IiII1i1i )
    if 54 - 54 : I1IiiI % OoO0O00 - I1ii11iIi11i
   except :
    pass
 except :
  pass
  if 61 - 61 : oO0o * O0o . oO0o + oO0o / O0o * I1IiiI
  if 73 - 73 : O0O00o0OOO0 * O0O00o0OOO0 / I11ii1
def ii11i ( ) :
 if 21 - 21 : I11ii1 * I11ii1 . o00O0oo
 try :
  if 9 - 9 : OOooOOo * ooOoO0o - o00O0oo
  oOOo0O00o = iIiIi11 ( OoOoO )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( oOOo0O00o )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 14 - 14 : iII111i + II111iiii
   try :
    if 83 - 83 : iII111i / II111iiii + o0oOOo0O0Ooo . O0O00o0OOO0 * I1Ii111 + O0o
    O00oOo00o0o = oooOo0OOOoo0
    if 63 - 63 : Oo0Ooo % iII111i - O0O00o0OOO0
   except :
    pass
    if 17 - 17 : I1ii11iIi11i
    if 88 - 88 : OoO0O00
  oOOo0O00o = iIiIi11 ( O00oOo00o0o )
  OOOiiiiI = re . compile ( I11i1I1I ) . findall ( oOOo0O00o )
  for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i in OOOiiiiI :
   try :
    iIIii ( IiIi11iI , Oo0O00O000 , oO0O00oOOoooO , id , i11I1IiII1i1i )
    if 28 - 28 : oO0o * Ii1I / o0
   except :
    pass
 except :
  pass
  if 52 - 52 : I1IiiI / Ii1I % O0O00o0OOO0 * I1ii11iIi11i % I1Ii111
def O00oO0 ( ) :
 if 11 - 11 : OoOoOO00
 try :
  if 19 - 19 : O0O00o0OOO0 - Ii1I - o00O0oo - I11i . O0O00o0OOO0 . o0
  oOOo0O00o = iIiIi11 ( OOI1iI1ii1II )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( oOOo0O00o )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 48 - 48 : O0O00o0OOO0 + O0o
   try :
    if 60 - 60 : ooOoO0o + O0O00o0OOO0 . O0o / OoOoOO00 . Oo0Ooo
    O0Oo00OoOo = oooOo0OOOoo0
    if 12 - 12 : I1Ii111 . o00O0oo
   except :
    pass
  oOOo0O00o = iIiIi11 ( O0Oo00OoOo )
  OOOiiiiI = re . compile ( I11i1I1I ) . findall ( oOOo0O00o )
  for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i in OOOiiiiI :
   try :
    iIIii ( IiIi11iI , Oo0O00O000 , oO0O00oOOoooO , id , i11I1IiII1i1i )
    if 79 - 79 : o0 / oO0o / O0O00o0OOO0 . o0 * OoO0O00 + Ii1I
   except :
    pass
 except :
  pass
  if 73 - 73 : I1IiiI - iII111i
def ii1ii111 ( ) :
 if 59 - 59 : OoO0O00 * oO0o + OoOoOO00
 try :
  if 23 - 23 : I11ii1
  oOOo0O00o = iIiIi11 ( oOooO0 )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( oOOo0O00o )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 13 - 13 : Oo0Ooo
   try :
    if 77 - 77 : II111iiii - Oo0Ooo / IiII / I11ii1 / OOooOOo
    i11111I1I = oooOo0OOOoo0
    if 9 - 9 : OOooOOo
   except :
    pass
  oOOo0O00o = iIiIi11 ( i11111I1I )
  OOOiiiiI = re . compile ( I11i1I1I ) . findall ( oOOo0O00o )
  for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i in OOOiiiiI :
   try :
    iIIii ( IiIi11iI , Oo0O00O000 , oO0O00oOOoooO , id , i11I1IiII1i1i )
    if 60 - 60 : o0
   except :
    pass
 except :
  pass
  if 98 - 98 : I11ii1
def ii1Oo0000oOo ( ) :
 if 41 - 41 : o00O0oo / o0oOOo0O0Ooo . I11i
 try :
  if 63 - 63 : I1IiiI
  oOOo0O00o = iIiIi11 ( oOO0O00Oo0O0o )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( oOOo0O00o )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 6 - 6 : I1Ii111
   try :
    if 98 - 98 : OoO0O00 % I1IiiI - I1IiiI
    I11o0oO00oO0o0o0 = oooOo0OOOoo0
    if 92 - 92 : oO0o / II111iiii + iII111i
   except :
    pass
  oOOo0O00o = iIiIi11 ( I11o0oO00oO0o0o0 )
  OOOiiiiI = re . compile ( I11i1I1I ) . findall ( oOOo0O00o )
  for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i in OOOiiiiI :
   try :
    iIIii ( IiIi11iI , Oo0O00O000 , oO0O00oOOoooO , id , i11I1IiII1i1i )
    if 87 - 87 : I11i % Oo0Ooo
   except :
    pass
 except :
  pass
  if 72 - 72 : I1Ii111 . I1Ii111 - iII111i
def I1I ( ) :
 if 3 - 3 : O0O00o0OOO0
 try :
  if 35 - 35 : O0o . I1IiiI + oO0o + I1Ii111 + OoOoOO00
  oOOo0O00o = iIiIi11 ( OOoO0 )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( oOOo0O00o )
  for oooOo0OOOoo0 in OOOiiiiI :
   if 65 - 65 : I1IiiI * I1ii11iIi11i / I1ii11iIi11i . I11i
   try :
    if 87 - 87 : o0oOOo0O0Ooo * iII111i % oO0o * oO0o
    ooooo = oooOo0OOOoo0
    if 51 - 51 : IiII + OOooOOo + O0O00o0OOO0 + O0O00o0OOO0 % Ii1I
   except :
    pass
  oOOo0O00o = iIiIi11 ( ooooo )
  OOOiiiiI = re . compile ( oO0 ) . findall ( oOOo0O00o )
  for oO0O00oOOoooO , IiIi11iI , Oo0O00O000 in OOOiiiiI :
   try :
    i11IIIiI1I ( oO0O00oOOoooO , IiIi11iI , Oo0O00O000 )
    if 66 - 66 : OOooOOo % Ii1I
   except :
    pass
    if 21 - 21 : I11i - OoO0O00 % II111iiii
 except :
  pass
  if 71 - 71 : OoOoOO00 - ooOoO0o * o0 + IiII - OOooOOo % iII111i
  if 63 - 63 : Oo0Ooo + I1Ii111 . OOooOOo / I1ii11iIi11i
  if 84 - 84 : OoOoOO00
def i11IIIiI1I ( thumb , name , url ) :
 if 42 - 42 : o0oOOo0O0Ooo - OOooOOo - OoO0O00 . O0O00o0OOO0 / I11i
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( o0OO00oO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   o0oO0oooOoo ( name , url , '' , oo , o0OO00 )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 56 - 56 : II111iiii - Oo0Ooo . o0oOOo0O0Ooo
  if 'tvg-logo' in thumb :
   thumb = re . compile ( o0OO00oO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 81 - 81 : O0o / I11i * O0o . I1IiiI
   o0iiiI1I1iIIIi1 ( name , url , 4 , IIi1IIIi , o0OO00 )
   if 83 - 83 : o0oOOo0O0Ooo * OoOoOO00 * O0O00o0OOO0 . iII111i / ooOoO0o + OoOoOO00
  else :
   if 43 - 43 : OoO0O00
   o0iiiI1I1iIIIi1 ( name , url , 4 , IIi1IIIi , o0OO00 )
   if 97 - 97 : iII111i / oO0o + o0
def iIIii ( name , url , thumb , id , trailer ) :
 if 32 - 32 : I11ii1 % o0 * oO0o
 if 72 - 72 : I11ii1 . O0O00o0OOO0 - o0 - o00O0oo % OoOoOO00
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 56 - 56 : oO0o * O0O00o0OOO0
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( o0OO00oO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   o0oO0oooOoo ( name , url , '' , oo , o0OO00 )
 else :
  I11II1i = oo000 . getSetting ( 'Fontcolor' )
  if 13 - 13 : oO0o * oO0o * o0oOOo0O0Ooo * O0O00o0OOO0 . OoOoOO00 / O0o
  name = '[COLOR %s]' % I11II1i + name + '[/COLOR]'
  if 92 - 92 : o00O0oo * II111iiii + O0O00o0OOO0 * o0
  if 'tvg-logo' in thumb :
   thumb = re . compile ( o0OO00oO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   Oo00OOOOO = oo000 . getSetting ( 'selecton' )
   if Oo00OOOOO == 'true' :
    if 48 - 48 : ooOoO0o * O0O00o0OOO0 * O0O00o0OOO0
    Iii ( name , url , 1 , thumb , thumb , id , trailer )
    if 6 - 6 : o00O0oo - OOooOOo . I1ii11iIi11i - I1IiiI
   else :
    if 16 - 16 : O0O00o0OOO0 * O0O00o0OOO0 % o00O0oo % I1ii11iIi11i
    Iii ( name , url , 130 , thumb , thumb , id , trailer )
    if 48 - 48 : I1Ii111 / o00O0oo % OOooOOo / O0o / o0
  else :
   if 89 - 89 : o0 * IiII
   if Oo00OOOOO == 'true' :
    if 63 - 63 : OoO0O00 * OoO0O00 % OOooOOo + I1IiiI / o0 + Oo0Ooo
    Iii ( name , url , 1 , thumb , thumb , id , trailer )
    if 72 - 72 : I11i * Oo0Ooo % ooOoO0o
   else :
    if 20 - 20 : o0oOOo0O0Ooo % Oo0Ooo + IiII * o0oOOo0O0Ooo * OOooOOo % OOooOOo
    Iii ( name , url , 130 , thumb , thumb , id , trailer )
    if 15 - 15 : IiII / o0
    if 37 - 37 : II111iiii + I1ii11iIi11i . I1Ii111 % ooOoO0o % ooOoO0o
def I1iiiiI1iI ( name , trailer ) :
 if 59 - 59 : o0 - O0o
 Oo0O00O000 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
 iIiiiii1i = Oo0O00O000
 iiIi1IIiI = xbmcgui . ListItem ( name , trailer , path = iIiiiii1i )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iiIi1IIiI )
 return
 if 80 - 80 : Oo0Ooo
 if 23 - 23 : o0oOOo0O0Ooo
def i1oO0OO0 ( name , url ) :
 import urlresolver
 from urlresolver import common
 if 17 - 17 : O0o / iII111i - Ii1I * iII111i
 iIIi = urlresolver . HostedMediaFile ( url )
 if 42 - 42 : o00O0oo
 if not iIIi :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
  if 68 - 68 : I1Ii111 . oO0o % I11ii1 - OoO0O00 * O0O00o0OOO0 . I1Ii111
  return False
  if 46 - 46 : II111iiii - I1Ii111 * I1ii11iIi11i * ooOoO0o % iII111i * OoOoOO00
  if 5 - 5 : I1IiiI / I11ii1 . oO0o + OoO0O00
 try :
  oO0o00oo0 = iIIi . resolve ( )
  if not oO0o00oo0 or not isinstance ( oO0o00oo0 , basestring ) :
   try : ii1IIII = oO0o00oo0 . msg
   except : ii1IIII = url
   raise Exception ( ii1IIII )
 except Exception as OOo0 :
  try : ii1IIII = str ( OOo0 )
  except : ii1IIII = url
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,5000)" )
  if 97 - 97 : O0o . o00O0oo . o00O0oo / Oo0Ooo - OOooOOo + O0O00o0OOO0
  return False
  if 32 - 32 : I1Ii111 . Ii1I % O0o + iII111i + OOooOOo
 OO0o = oo000 . getSetting ( 'notificar' )
 if OO0o == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
 oO00oOooooo0 = xbmcgui . ListItem ( path = oO0o00oo0 )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO00oOooooo0 )
 if 76 - 76 : OOooOOo - II111iiii + I11i + I1Ii111 / OoO0O00
def o0O0Oo00 ( name , url ) :
 if 85 - 85 : II111iiii / II111iiii . OOooOOo . I1IiiI
 if 67 - 67 : o0oOOo0O0Ooo / Ii1I . I1Ii111 . OoO0O00
 if 'https://www.rapidvideo.com/v/' in url :
  if 19 - 19 : O0o . iII111i / I11i
  oOOo0O00o = iIiIi11 ( url )
  OOOiiiiI = re . compile ( 'rapidvideo' ) . findall ( oOOo0O00o )
  for url in OOOiiiiI :
   if 68 - 68 : I11ii1 / OoO0O00 * ooOoO0o / IiII
   if 88 - 88 : Ii1I
   try :
    OO0o = oo000 . getSetting ( 'notificar' )
    if OO0o == 'true' :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oO00oOooooo0 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO00oOooooo0 )
    if 1 - 1 : OoO0O00
   except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 48 - 48 : I11ii1 * I11i - I11ii1 - I1Ii111 + I1Ii111
   if 40 - 40 : II111iiii . Oo0Ooo
 else :
  if 2 - 2 : OoOoOO00 * IiII - IiII + OoO0O00 % I11i / I11i
  import urlresolver
  from urlresolver import common
  if 3 - 3 : OoO0O00
  iIIi = urlresolver . HostedMediaFile ( url )
  if 71 - 71 : O0o + OoOoOO00 - O0O00o0OOO0 - II111iiii . ooOoO0o - I11ii1
  if not iIIi :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 85 - 85 : iII111i - I11i / iII111i + I1Ii111 - O0O00o0OOO0
   if 49 - 49 : OOooOOo - I1IiiI / OOooOOo * I11i + o0
  try :
   oO0o00oo0 = iIIi . resolve ( )
   if not oO0o00oo0 or not isinstance ( oO0o00oo0 , basestring ) :
    try : ii1IIII = oO0o00oo0 . msg
    except : ii1IIII = url
    raise Exception ( ii1IIII )
  except Exception as OOo0 :
   try : ii1IIII = str ( OOo0 )
   except : ii1IIII = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 35 - 35 : o0oOOo0O0Ooo . I1ii11iIi11i / OoOoOO00 / I1ii11iIi11i * IiII
  OO0o = oo000 . getSetting ( 'notificar' )
  if OO0o == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  oO00oOooooo0 = xbmcgui . ListItem ( path = oO0o00oo0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO00oOooooo0 )
  if 85 - 85 : o0oOOo0O0Ooo . I11ii1 % I1Ii111 % ooOoO0o
 return
 if 80 - 80 : IiII * ooOoO0o / Oo0Ooo % IiII / Oo0Ooo
 if 42 - 42 : OoOoOO00 / II111iiii . oO0o * O0O00o0OOO0 . II111iiii * I1IiiI
 if 44 - 44 : OoOoOO00 . I1ii11iIi11i / II111iiii + O0o
def O0Oo0o000oO ( name , url ) :
 if 62 - 62 : O0O00o0OOO0 * Oo0Ooo . O0o - OoO0O00 * o0oOOo0O0Ooo
 oO0o00oo0 = url
 OO0o = oo000 . getSetting ( 'notificar' )
 if OO0o == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  oO00oOooooo0 = xbmcgui . ListItem ( path = oO0o00oo0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO00oOooooo0 )
 else :
  oO00oOooooo0 = xbmcgui . ListItem ( path = oO0o00oo0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO00oOooooo0 )
 return
 if 45 - 45 : I1IiiI % I1ii11iIi11i - O0O00o0OOO0 . OOooOOo
def oO0o00oOOooO0 ( name , url ) :
 if 9 - 9 : oO0o % OoO0O00 - o00O0oo
 if 43 - 43 : OOooOOo % OOooOOo
 if '[Youtube]' in name :
  if 46 - 46 : oO0o % Oo0Ooo . O0O00o0OOO0 . I1IiiI * I11ii1 / OoO0O00
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 7 - 7 : IiII - I1IiiI * ooOoO0o - Ii1I - o0oOOo0O0Ooo
  try :
   OO0o = oo000 . getSetting ( 'notificar' )
   if OO0o == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oO00oOooooo0 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO00oOooooo0 )
    if 41 - 41 : I1ii11iIi11i - o0 % o0oOOo0O0Ooo . o0 - ooOoO0o
    if 45 - 45 : o00O0oo - I1Ii111
    if 70 - 70 : OOooOOo % I1ii11iIi11i / I1ii11iIi11i . ooOoO0o % I11ii1 . o0oOOo0O0Ooo
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 10 - 10 : o00O0oo - II111iiii . iII111i % OoOoOO00
  if 78 - 78 : Oo0Ooo * oO0o . oO0o - I1Ii111 . Oo0Ooo
 else :
  if 30 - 30 : I11ii1 + I11ii1 % O0o - Ii1I - iII111i
  import xbmcgui
  import urlresolver
  from urlresolver import common
  if 36 - 36 : ooOoO0o % I1Ii111
  iIIi = urlresolver . HostedMediaFile ( url )
  if 72 - 72 : I1ii11iIi11i / O0O00o0OOO0 - I1IiiI + ooOoO0o
  if not iIIi :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 83 - 83 : I1IiiI
  import resolveurl as urlresolver
  if 89 - 89 : oO0o + iII111i - Ii1I
  iIIi = urlresolver . HostedMediaFile ( url )
  if 40 - 40 : OOooOOo + OOooOOo
  if 94 - 94 : O0O00o0OOO0 * Oo0Ooo . ooOoO0o
  if not iIIi :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 13 - 13 : Oo0Ooo * I11i / o0 % I11ii1 + IiII
  try :
   oO0o00oo0 = iIIi . resolve ( )
   if not oO0o00oo0 or not isinstance ( oO0o00oo0 , basestring ) :
    try : ii1IIII = oO0o00oo0 . msg
    except : ii1IIII = url
    raise Exception ( ii1IIII )
  except Exception as OOo0 :
   try : ii1IIII = str ( OOo0 )
   except : ii1IIII = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 41 - 41 : iII111i
   if 5 - 5 : oO0o
   if 100 - 100 : o00O0oo + Oo0Ooo
  OO0o = oo000 . getSetting ( 'notificar' )
  if OO0o == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 59 - 59 : O0o
   if '[Realstream]' in name :
    if 89 - 89 : I11i % Oo0Ooo
    O0o0Oo = oo000 . getSetting ( 'restante' )
    if O0o0Oo == 'true' :
     iI = xbmcgui . Dialog ( )
     iII1ii1 = iI . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 35 - 35 : iII111i + o0 - I11i % IiII % Ii1I % I11i
   oO00oOooooo0 = xbmcgui . ListItem ( path = oO0o00oo0 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO00oOooooo0 )
   if 45 - 45 : I1ii11iIi11i * I1Ii111 % OOooOOo
   if 24 - 24 : I11ii1 - ooOoO0o * IiII
   if 87 - 87 : o00O0oo - iII111i % iII111i . IiII / iII111i
 return
 if 6 - 6 : I11i / Oo0Ooo * OoO0O00 * II111iiii
 if 79 - 79 : O0o % OOooOOo
 if 81 - 81 : II111iiii + II111iiii * OOooOOo + O0o
def OOOoO000 ( name , url ) :
 if 17 - 17 : II111iiii / oO0o . OOooOOo / I1ii11iIi11i
 if 38 - 38 : OoOoOO00 . iII111i % o00O0oo + Oo0Ooo + I1IiiI
 if '[Youtube]' in name :
  if 47 - 47 : OOooOOo + O0o / o0oOOo0O0Ooo
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 97 - 97 : iII111i / I1ii11iIi11i % I1IiiI + OoOoOO00 - I11ii1
  try :
   OO0o = oo000 . getSetting ( 'notificar' )
   if OO0o == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oO00oOooooo0 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO00oOooooo0 )
    if 38 - 38 : Ii1I % o0 + II111iiii + O0O00o0OOO0 + I11ii1 / II111iiii
    if 94 - 94 : O0O00o0OOO0 - oO0o + IiII
    if 59 - 59 : ooOoO0o . I1ii11iIi11i - Oo0Ooo + Oo0Ooo
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 56 - 56 : IiII + I11ii1
 else :
  if 32 - 32 : o0oOOo0O0Ooo + I11i % I11ii1 / I11i + iII111i
  import resolveurl
  if 2 - 2 : II111iiii - o0 + OOooOOo % ooOoO0o * o00O0oo
  iIIi = urlresolver . HostedMediaFile ( url )
  if 54 - 54 : I1IiiI - O0O00o0OOO0 . I1Ii111 % O0O00o0OOO0 + O0O00o0OOO0
  if 36 - 36 : I1Ii111 % II111iiii
  if not iIIi :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 47 - 47 : OoOoOO00 + o0oOOo0O0Ooo . oO0o * IiII . ooOoO0o / OoOoOO00
  try :
   oO0o00oo0 = iIIi . resolve ( )
   if not oO0o00oo0 or not isinstance ( oO0o00oo0 , basestring ) :
    try : ii1IIII = oO0o00oo0 . msg
    except : ii1IIII = url
    raise Exception ( ii1IIII )
  except Exception as OOo0 :
   try : ii1IIII = str ( OOo0 )
   except : ii1IIII = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 50 - 50 : o0 / OoOoOO00 % OoO0O00
   if 83 - 83 : iII111i * iII111i + I1Ii111
   if 57 - 57 : I1IiiI - I1IiiI . iII111i / Ii1I / o00O0oo
  OO0o = oo000 . getSetting ( 'notificar' )
  if OO0o == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 20 - 20 : I1Ii111 * o0oOOo0O0Ooo - I11i - IiII * o0
   if '[Realstream]' in name :
    if 6 - 6 : I11ii1 + I1Ii111 / oO0o + O0o % o0oOOo0O0Ooo / OOooOOo
    O0o0Oo = oo000 . getSetting ( 'restante' )
    if O0o0Oo == 'true' :
     iI = xbmcgui . Dialog ( )
     iII1ii1 = iI . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 45 - 45 : OoO0O00
   oO00oOooooo0 = xbmcgui . ListItem ( path = oO0o00oo0 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO00oOooooo0 )
   if 9 - 9 : ooOoO0o . OOooOOo * OoOoOO00 . OoO0O00
   if 32 - 32 : I11i . iII111i % I1ii11iIi11i - o0oOOo0O0Ooo
   if 11 - 11 : I1IiiI + I1ii11iIi11i
 return
 if 80 - 80 : IiII % IiII % I1IiiI - II111iiii . O0O00o0OOO0 / I1IiiI
 if 13 - 13 : I1ii11iIi11i + I1IiiI - iII111i % oO0o / o00O0oo . OoOoOO00
 if 60 - 60 : oO0o . O0o % I1ii11iIi11i - o0
def oOOOO ( name , url ) :
 if 79 - 79 : IiII - o0oOOo0O0Ooo
 if 43 - 43 : OoOoOO00 + I1IiiI % OOooOOo / o00O0oo * I1ii11iIi11i
 if '[Youtube]' in name :
  if 89 - 89 : I1ii11iIi11i . oO0o + iII111i . I1IiiI % Ii1I
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 84 - 84 : OoO0O00 + o0 / I1ii11iIi11i % I1Ii111 % iII111i * I1ii11iIi11i
  try :
   OO0o = oo000 . getSetting ( 'notificar' )
   if OO0o == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oO00oOooooo0 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO00oOooooo0 )
    if 58 - 58 : OOooOOo - I11i . II111iiii % II111iiii / OoOoOO00 / IiII
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 24 - 24 : I1ii11iIi11i * OoOoOO00 % I11ii1 / I1IiiI + II111iiii
 else :
  if 12 - 12 : iII111i / o00O0oo
  if 'https://team.com' in url :
   if 5 - 5 : OoO0O00
   url = url . replace ( 'https://team.com' , 'https://verystream.com' )
   if 18 - 18 : I1ii11iIi11i % OoO0O00 - O0O00o0OOO0 . II111iiii * oO0o % o00O0oo
  if 'https://mybox.com' in url :
   if 12 - 12 : OoOoOO00 / I1Ii111 % I11ii1 * O0o * I1IiiI * Oo0Ooo
   url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
   if 93 - 93 : oO0o / iII111i + OoOoOO00 * IiII . OoO0O00
  if 'https://drive.com' in url :
   if 54 - 54 : I1IiiI / O0o % I11ii1 * OoOoOO00 * I1IiiI
   url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
   if 48 - 48 : Ii1I . IiII % I11i - I11i
  if 'https://https://vidcloud.co/' in url :
   if 33 - 33 : ooOoO0o % o0oOOo0O0Ooo + OOooOOo
   url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
   if 93 - 93 : OoOoOO00 . O0o / I1ii11iIi11i + O0o
  if 'https://gounlimited.to' in url :
   if 58 - 58 : iII111i + I1IiiI . oO0o + I11i - OOooOOo - I11i
   url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
   if 41 - 41 : oO0o / OoOoOO00 / oO0o - O0O00o0OOO0 . Ii1I
  import resolveurl
  if 65 - 65 : I1IiiI * II111iiii . OoO0O00 / I1ii11iIi11i / O0O00o0OOO0
  iIIi = urlresolver . HostedMediaFile ( url )
  if 69 - 69 : I11ii1 % I11ii1
  if 76 - 76 : II111iiii * O0O00o0OOO0 / OOooOOo % iII111i + I1Ii111
  if not iIIi :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 48 - 48 : Oo0Ooo % OoOoOO00 + I11i % Ii1I
  try :
   oO0o00oo0 = iIIi . resolve ( )
   if not oO0o00oo0 or not isinstance ( oO0o00oo0 , basestring ) :
    try : ii1IIII = oO0o00oo0 . msg
    except : ii1IIII = url
    raise Exception ( ii1IIII )
  except Exception as OOo0 :
   try : ii1IIII = str ( OOo0 )
   except : ii1IIII = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace borrado reportalo en nuesto grupo de telegram [/COLOR][COLOR ligthblue] https://t.me/OficialNetai [/COLOR]  ,5000)" )
   return False
   if 79 - 79 : I11i % I1ii11iIi11i % o00O0oo / OoOoOO00 % OOooOOo
   if 56 - 56 : Oo0Ooo - II111iiii * O0O00o0OOO0
   if 84 - 84 : I1Ii111 + o00O0oo + Ii1I
   OO0o = oo000 . getSetting ( 'notificar' )
   if OO0o == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
    if 33 - 33 : o00O0oo
    if '[Realstream]' or '[Mybox]' in name :
     O0o0Oo = oo000 . getSetting ( 'restante' )
    elif O0o0Oo == 'true' :
     iI = xbmcgui . Dialog ( )
     iII1ii1 = iI . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 93 - 93 : I11ii1
  oO00oOooooo0 = xbmcgui . ListItem ( path = oO0o00oo0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO00oOooooo0 )
  if 34 - 34 : IiII - I11ii1 * oO0o / Ii1I
 return
 if 19 - 19 : iII111i
 if 46 - 46 : Oo0Ooo . II111iiii - I11i % I1IiiI / o0oOOo0O0Ooo * OoOoOO00
 if 66 - 66 : I1IiiI
def IiIi1ii111i1 ( ) :
 if 71 - 71 : o0 - Ii1I - I1Ii111
 if 28 - 28 : Oo0Ooo
 i1i1i1I = [ ]
 oOoo000 = sys . argv [ 2 ]
 if len ( oOoo000 ) >= 2 :
  OooOo00o = sys . argv [ 2 ]
  IiI11i1IIiiI = OooOo00o . replace ( '?' , '' )
  if ( OooOo00o [ len ( OooOo00o ) - 1 ] == '/' ) :
   OooOo00o = OooOo00o [ 0 : len ( OooOo00o ) - 2 ]
  oOOo000oOoO0 = IiI11i1IIiiI . split ( '&' )
  i1i1i1I = { }
  for OoOo00o0OO in range ( len ( oOOo000oOoO0 ) ) :
   ii1IIIIiI11 = { }
   ii1IIIIiI11 = oOOo000oOoO0 [ OoOo00o0OO ] . split ( '=' )
   if ( len ( ii1IIIIiI11 ) ) == 2 :
    i1i1i1I [ ii1IIIIiI11 [ 0 ] ] = ii1IIIIiI11 [ 1 ]
 return i1i1i1I
 if 18 - 18 : Oo0Ooo
 if 30 - 30 : I1IiiI + I1Ii111 % oO0o . OoOoOO00
def iI1IIIii ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  import urlresolver
  xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
  if 65 - 65 : oO0o * I1IiiI / o00O0oo . o0 % oO0o
def I1i11ii11 ( ) :
 iI = xbmcgui . Dialog ( )
 list = (
 OO00O0oOO ,
 Ii1iI111
 )
 if 7 - 7 : oO0o - OoOoOO00 . iII111i / Oo0Ooo * Ii1I
 OOo = iI . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=%s]Accede a themoviedb.com[/COLOR]' % IIIII ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 100 - 100 : I11ii1 / I11ii1 - I1Ii111 % I1Ii111 * IiII / O0o
 if OOo :
  if 32 - 32 : I1ii11iIi11i + iII111i - IiII + iII111i / OoOoOO00 * IiII
  if OOo < 0 :
   return
  IIii11Ii1i1I = list [ OOo - 2 ]
  return IIii11Ii1i1I ( )
 else :
  IIii11Ii1i1I = list [ OOo ]
  return IIii11Ii1i1I ( )
 return
 if 90 - 90 : o00O0oo % IiII
def Oooo0O ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 6 - 6 : OoO0O00 / II111iiii / o0
oo00O0oO0O0 = Oooo0O ( )
if 60 - 60 : I1ii11iIi11i % IiII / Ii1I % IiII * II111iiii / O0O00o0OOO0
def OO00O0oOO ( ) :
 if oo00O0oO0O0 == 'android' :
  ooo0OO0O0Oo = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  ooo0OO0O0Oo = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 34 - 34 : o0 - I1Ii111
  if 25 - 25 : IiII % I1ii11iIi11i + II111iiii + I1IiiI * OoO0O00
def Ii1iI111 ( ) :
 if 64 - 64 : OoOoOO00
 main ( )
 if 10 - 10 : o0 % I1IiiI / I1ii11iIi11i % ooOoO0o
 if 25 - 25 : o0oOOo0O0Ooo / OOooOOo
 if 64 - 64 : I1IiiI % I11ii1
def O0oooo00o0Oo ( ) :
 iI = xbmcgui . Dialog ( )
 I1i11Ooo = (
 I1iii ,
 oO0o0O0Ooo0o
 )
 if 59 - 59 : o0 . iII111i + OoO0O00
 OOo = iI . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 44 - 44 : ooOoO0o * Ii1I
 if OOo :
  if 49 - 49 : I1Ii111 % ooOoO0o * II111iiii / IiII % I1Ii111
  if OOo < 0 :
   return
  IIii11Ii1i1I = I1i11Ooo [ OOo - 2 ]
  return IIii11Ii1i1I ( )
 else :
  IIii11Ii1i1I = I1i11Ooo [ OOo ]
  return IIii11Ii1i1I ( )
 return
 if 70 - 70 : I11i / o0oOOo0O0Ooo % I11ii1 - O0O00o0OOO0
def Oooo0O ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 2 - 2 : o0 - iII111i + Ii1I * OOooOOo / O0O00o0OOO0
oo00O0oO0O0 = Oooo0O ( )
if 26 - 26 : I1Ii111 * oO0o
def I1iii ( ) :
 if oo00O0oO0O0 == 'android' :
  ooo0OO0O0Oo = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  ooo0OO0O0Oo = webbrowser . open ( 'https://olpair.com/' )
  if 31 - 31 : ooOoO0o * IiII . o00O0oo
  if 35 - 35 : ooOoO0o
def oO0o0O0Ooo0o ( ) :
 if 94 - 94 : I11ii1 / II111iiii % I1IiiI
 main ( )
 if 70 - 70 : ooOoO0o - oO0o / OoO0O00 % OoO0O00
 if 95 - 95 : OoO0O00 % OoO0O00 . o00O0oo
def i1Ii11II ( name , url , id , trailer ) :
 iI = xbmcgui . Dialog ( )
 I1i11Ooo = (
 IioO0oOOO0Ooo ,
 i1i1I ,
 IiIIi1 ,
 I1i11ii11 ,
 iII11I1Ii1
 )
 if 70 - 70 : Oo0Ooo * O0o - I1Ii111 / oO0o % IiII
 OOo = iI . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % IIIII ,

 '[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % IIIII ,

 '[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % IIIII ,

 '[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % IIIII ,

 '[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % IIIII ] )
 if 66 - 66 : OoO0O00 + I11ii1 * O0O00o0OOO0
 if OOo :
  if 2 - 2 : O0O00o0OOO0 . OOooOOo / IiII
  if OOo < 0 :
   return
  IIii11Ii1i1I = I1i11Ooo [ OOo - 5 ]
  return IIii11Ii1i1I ( )
 else :
  IIii11Ii1i1I = I1i11Ooo [ OOo ]
  return IIii11Ii1i1I ( )
 return
 if 41 - 41 : OOooOOo . o0 * O0o * o0
 if 74 - 74 : Oo0Ooo / Ii1I
 if 58 - 58 : Oo0Ooo - I1ii11iIi11i % Ii1I % OoO0O00 * Oo0Ooo + I1Ii111
def IioO0oOOO0Ooo ( ) :
 if 25 - 25 : I1Ii111 % I1IiiI
 oOOOO ( IiIi11iI , Oo0O00O000 )
 if 44 - 44 : o0 . o00O0oo * o0oOOo0O0Ooo / O0o + Oo0Ooo
def i1i1I ( ) :
 if 14 - 14 : I1IiiI % O0o % o00O0oo * IiII
 I1iiiiI1iI ( IiIi11iI , i11I1IiII1i1i )
 if 65 - 65 : ooOoO0o % IiII + iII111i
def IiIIi1 ( ) :
 if 86 - 86 : Oo0Ooo / I1IiiI . o0 % Oo0Ooo % oO0o
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  o0o0 = id
  if 68 - 68 : IiII - oO0o / I11i - o0 . O0O00o0OOO0
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % o0o0 )
  if 50 - 50 : Oo0Ooo - O0O00o0OOO0 - ooOoO0o
 if OO0o == 'true' :
  if 60 - 60 : Oo0Ooo * I11ii1
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + IiIi11iI + "[/COLOR] ,5000)" )
  if 71 - 71 : I11i % oO0o % I11ii1
def oOo0oO ( ) :
 if 66 - 66 : Ii1I * I1Ii111 + o00O0oo * Ii1I + I1Ii111 / OoO0O00
 I1i11ii11 ( )
 if 86 - 86 : o00O0oo . O0O00o0OOO0 - O0O00o0OOO0
def iII11I1Ii1 ( ) :
 if 71 - 71 : Oo0Ooo . o0oOOo0O0Ooo % Oo0Ooo
 IiIi1I1 ( )
def o0oO0oooOoo ( name , url , mode , iconimage , fanart ) :
 if 22 - 22 : II111iiii % iII111i % I11ii1 % I11ii1 . OOooOOo
 OOOO0OOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 iII1ii1 = True
 i1i1ii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1i1ii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 i1i1ii . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  OOOO0OOO = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  iII1ii1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOOO0OOO , listitem = i1i1ii , isFolder = True )
  return iII1ii1
 iII1ii1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOOO0OOO , listitem = i1i1ii , isFolder = True )
 return iII1ii1
 if 85 - 85 : I11ii1 . I1IiiI / I1Ii111 * I11ii1 - OOooOOo - II111iiii
def Iii ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 25 - 25 : I11ii1 % oO0o - I1Ii111
 OOOO = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 80 - 80 : O0o % o0oOOo0O0Ooo - oO0o - Oo0Ooo
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 IIi1IIIIi = [ ]
 OOOO0OOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 i1i1ii = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 i1i1ii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 i1i1ii . setProperty ( 'fanart_image' , fanart )
 i1i1ii . setProperty ( 'IsPlayable' , 'true' )
 if 65 - 65 : I1IiiI - o0 . o00O0oo
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  IIi1IIIIi . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  i1i1ii . addContextMenuItems ( IIi1IIIIi , replaceItems = True )
 iII1ii1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOOO0OOO , listitem = i1i1ii )
 return iII1ii1
 if 19 - 19 : iII111i . O0O00o0OOO0 - Ii1I + ooOoO0o - o00O0oo
def o0iiiI1I1iIIIi1 ( name , url , mode , iconimage , fanart ) :
 if 13 - 13 : O0o * iII111i / iII111i / Oo0Ooo % Oo0Ooo
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 21 - 21 : iII111i
 OOOO0OOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 i1i1ii = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 i1i1ii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 i1i1ii . setProperty ( 'fanart_image' , fanart )
 i1i1ii . setProperty ( 'IsPlayable' , 'true' )
 iII1ii1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOOO0OOO , listitem = i1i1ii )
 return iII1ii1
 if 86 - 86 : I11ii1
def OOOoO ( name , url , mode ) :
 if 66 - 66 : I1Ii111 - I11ii1 - oO0o
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 54 - 54 : O0O00o0OOO0 . OoOoOO00
 OOOO0OOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 i1i1ii = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = IIi1IIIi )
 i1i1ii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 i1i1ii . setProperty ( 'fanart_image' , o0OO00 )
 i1i1ii . setProperty ( 'IsPlayable' , 'true' )
 iII1ii1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOOO0OOO , listitem = i1i1ii )
 return iII1ii1
 if 19 - 19 : I11ii1 % IiII
def I1i ( name , url , mode , iconimage ) :
 OOOO0OOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 iII1ii1 = True
 i1i1ii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iII1ii1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOOO0OOO , listitem = i1i1ii , isFolder = True )
 return iII1ii1
 if 26 - 26 : OOooOOo * o0oOOo0O0Ooo . OOooOOo
def iiiI ( ) :
 if 3 - 3 : Oo0Ooo . Ii1I . IiII . oO0o
 if 34 - 34 : OoOoOO00 * II111iiii
 if 38 - 38 : Oo0Ooo + OoO0O00 * I1ii11iIi11i % I11i % ooOoO0o - O0o
 OOoO = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 OOoO . doModal ( )
 if ( OOoO . isConfirmed ( ) ) :
  if 56 - 56 : OoO0O00 * oO0o * ooOoO0o + I11ii1
  OO0O000 = urllib . quote_plus ( OOoO . getText ( ) ) . replace ( '+' , ' ' )
  if 54 - 54 : I11i * II111iiii . OoO0O00 - Oo0Ooo
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 38 - 38 : ooOoO0o . ooOoO0o * IiII / OoO0O00 % I11ii1
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % OO0O000 )
    if 80 - 80 : OOooOOo / O0o * I1ii11iIi11i % O0o
    if OO0o == 'true' :
     if 95 - 95 : I1IiiI / ooOoO0o . o0
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + IiIi11iI + "[/COLOR] ,10000)" )
     if 17 - 17 : ooOoO0o
   except :
    if 56 - 56 : I11ii1 * Ii1I + ooOoO0o
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 48 - 48 : O0o * OOooOOo % o0 - ooOoO0o
    if 72 - 72 : OoOoOO00 % I11ii1 % O0o % IiII - IiII
    if 97 - 97 : Ii1I * I1IiiI / Ii1I * OOooOOo * oO0o
OooOo00o = IiIi1ii111i1 ( )
Oo0O00O000 = None
IiIi11iI = None
IiIi1 = None
IIi1IIIi = None
id = None
i11I1IiII1i1i = None
if 94 - 94 : II111iiii % IiII + oO0o + IiII
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 33 - 33 : O0o . oO0o / Oo0Ooo
try :
 Oo0O00O000 = urllib . unquote_plus ( OooOo00o [ "url" ] )
except :
 pass
try :
 IiIi11iI = urllib . unquote_plus ( OooOo00o [ "name" ] )
except :
 pass
try :
 IiIi1 = int ( OooOo00o [ "mode" ] )
except :
 pass
try :
 IIi1IIIi = urllib . unquote_plus ( OooOo00o [ "iconimage" ] )
except :
 pass
try :
 id = int ( OooOo00o [ "id" ] )
except :
 pass
try :
 i11I1IiII1i1i = urllib . unquote_plus ( OooOo00o [ "trailer" ] )
except :
 pass
 if 50 - 50 : Ii1I
 if 16 - 16 : I11i
print "Mode: " + str ( IiIi1 )
print "URL: " + str ( Oo0O00O000 )
print "Name: " + str ( IiIi11iI )
print "iconimage: " + str ( IIi1IIIi )
print "id: " + str ( id )
print "trailer: " + str ( i11I1IiII1i1i )
if 16 - 16 : oO0o / OOooOOo / O0O00o0OOO0 / Oo0Ooo
if IiIi1 == None or Oo0O00O000 == None or len ( Oo0O00O000 ) < 1 :
 if oOoOooOo0o0 == OOOO :
  if 44 - 44 : oO0o . oO0o + OoO0O00 * II111iiii / ooOoO0o + o0
  o00O0O ( )
  o0O00Oo0 ( )
  if 17 - 17 : I1Ii111 + o0oOOo0O0Ooo
  if 43 - 43 : ooOoO0o % o00O0oo / Ii1I * o0
  II11iiii1Ii = oo000 . getSetting ( 'licencia_addon' )
  iiI111I1iIiI = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  if 85 - 85 : Oo0Ooo . OoO0O00 . Ii1I
  IIIi1I1IIii1II = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  i111iiI1ii = oo000 . getSetting ( 'key_ext' )
  oOOo0O00o = iIiIi11 ( IIIi1I1IIii1II )
  OOOiiiiI = re . compile ( O00O0oOO00O00 ) . findall ( oOOo0O00o )
  for IIiii in OOOiiiiI :
   try :
    if 100 - 100 : OoOoOO00 - II111iiii . o0 * OOooOOo
    if 62 - 62 : I1IiiI
    II11iiii1Ii = oo000 . getSetting ( 'licencia_addon' )
    if 41 - 41 : OoOoOO00 - I1ii11iIi11i
    if 48 - 48 : I1ii11iIi11i - o0oOOo0O0Ooo / OOooOOo + I1ii11iIi11i
    if II11iiii1Ii == IIiii :
     if 5 - 5 : I1IiiI
     xbmcgui . Dialog ( ) . ok ( "Realstream Licencia:" , "[COLOR lime]Su llave es correcta![/COLOR] [COLOR gold]Sientese y disfrute de Realstream.[/COLOR]" )
     if 75 - 75 : o0 + Oo0Ooo
     IiIi1I1 ( )
     if 19 - 19 : I1ii11iIi11i + II111iiii . O0o - ooOoO0o / o00O0oo + Ii1I
    else :
     if 38 - 38 : oO0o / Oo0Ooo * Oo0Ooo % iII111i
     xbmcgui . Dialog ( ) . ok ( "Realstream Licencia:" , "[COLOR red]Ha introducido una llave erronea.[/COLOR] [COLOR gold]Ponganse en contacto con nosotros en nuestro grupo de telegram.[/COLOR]" )
     if 92 - 92 : ooOoO0o / I1IiiI * I1ii11iIi11i - ooOoO0o
     if 99 - 99 : II111iiii % OoO0O00
   except :
    pass
    if 56 - 56 : O0o * o0
 else :
  xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red][B]Error, de inicio. ¿Tienes Instalado Realstream?[/B][/COLOR]" )
  if 98 - 98 : ooOoO0o + I1IiiI * o0 + II111iiii - I1Ii111 - Oo0Ooo
  if 5 - 5 : I1Ii111 % oO0o % O0o % I11ii1
  if 17 - 17 : o00O0oo + o0oOOo0O0Ooo + OoO0O00 / I1Ii111 / O0o
elif IiIi1 == 1 :
 i1Ii11II ( IiIi11iI , Oo0O00O000 , id , i11I1IiII1i1i )
elif IiIi1 == 2 :
 iiI11Iii ( )
elif IiIi1 == 3 :
 O0o0O0 ( )
elif IiIi1 == 4 :
 i1oO0OO0 ( IiIi11iI , Oo0O00O000 )
elif IiIi1 == 5 :
 I111i1i1111 ( )
elif IiIi1 == 6 :
 I1I1i ( )
elif IiIi1 == 7 :
 IIIII1 ( )
elif IiIi1 == 8 :
 IIiI1 ( )
elif IiIi1 == 9 :
 ii1I1IiiI1ii1i ( )
elif IiIi1 == 10 :
 oO0OoO00o ( )
elif IiIi1 == 11 :
 O0OoOO0oo0 ( )
elif IiIi1 == 12 :
 O0o0OO0000ooo ( )
elif IiIi1 == 13 :
 oOOO00o000o ( )
elif IiIi1 == 14 :
 oO00oo0o00o0o ( )
elif IiIi1 == 15 :
 IiIi1iIIi1 ( )
elif IiIi1 == 16 :
 OoOo0oOooOoOO ( )
elif IiIi1 == 17 :
 o00oOoOo0 ( )
elif IiIi1 == 18 :
 oo000ii ( )
elif IiIi1 == 19 :
 Iiiiii111i1ii ( )
elif IiIi1 == 20 :
 iii11i1IIII ( )
elif IiIi1 == 21 :
 o00iiI1Ii1 ( )
elif IiIi1 == 22 :
 oOOoo ( )
elif IiIi1 == 23 :
 ii11i ( )
elif IiIi1 == 24 :
 O00oO0 ( )
elif IiIi1 == 25 :
 ii1ii111 ( )
elif IiIi1 == 26 :
 i1II1I1Iii1 ( )
elif IiIi1 == 28 :
 I1i1iiiI1 ( IiIi11iI , Oo0O00O000 )
elif IiIi1 == 98 :
 busqueda_global ( )
elif IiIi1 == 97 :
 O0oooo00o0Oo ( )
elif IiIi1 == 99 :
 oOo ( )
elif IiIi1 == 100 :
 menu_player ( IiIi11iI , Oo0O00O000 )
elif IiIi1 == 111 :
 O0O0ooOOO ( )
elif IiIi1 == 115 :
 I1iiiiI1iI ( Oo0O00O000 )
elif IiIi1 == 116 :
 I1III1111iIi ( )
elif IiIi1 == 117 :
 O0O0Oo00 ( )
elif IiIi1 == 119 :
 iiI ( )
elif IiIi1 == 120 :
 oOIIiIi ( )
elif IiIi1 == 121 :
 Ooo0O0oooo ( )
elif IiIi1 == 125 :
 I1I ( )
elif IiIi1 == 112 :
 o0OO0o0oOOO0O ( )
elif IiIi1 == 127 :
 iiiI ( )
elif IiIi1 == 128 :
 TESTLINKS ( )
elif IiIi1 == 130 :
 oOOOO ( IiIi11iI , Oo0O00O000 )
elif IiIi1 == 140 :
 OOoOooOoOOOoo ( )
elif IiIi1 == 141 :
 ii1Oo0000oOo ( )
elif IiIi1 == 142 :
 oOoO00o ( )
elif IiIi1 == 143 :
 oO00O0 ( IiIi11iI , Oo0O00O000 )
elif IiIi1 == 144 :
 I1i1iiiI1 ( IiIi11iI , Oo0O00O000 )
elif IiIi1 == 145 :
 Iiii1iI1i ( )
 if 80 - 80 : Ii1I % OoOoOO00 / ooOoO0o
xbmcplugin . endOfDirectory ( oOOo )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
