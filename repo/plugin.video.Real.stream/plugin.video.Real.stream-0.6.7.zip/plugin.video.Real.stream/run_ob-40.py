# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 0.6.7
#
############################################
#
# Incluido Script ResolveURL Por Jsergio.
#
############################################
#
# Corregido imcompatibilidad con Servidor Team
# Ahora se mostrara el nombre del servidor por color
#
############################################
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import urlresolver
import cookielib , base64
import requests
import plugintools
import config
oo000 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
ii = oo000 . getAddonInfo ( 'version' )
oOOo = int ( sys . argv [ 1 ] )
O0 = 'gruponetai/'
o0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
iI11I1II1I1I = o0O . getAddonInfo ( 'profile' )
oooo = o0O . getAddonInfo ( 'path' )
if 11 - 11: ii1I - ooO0OO000o
ii11i = xbmc . translatePath ( os . path . join ( oooo , 'fanart.jpg' ) )
oOooOoO0Oo0O = xbmc . translatePath ( os . path . join ( oooo , 'icon.png' ) )
iI1 = xbmc . translatePath ( os . path . join ( oooo , 'extended_info.png' ) )
i1I11i = xbmc . translatePath ( os . path . join ( oooo , 'buscar.png' ) )
OoOoOO00 = xbmc . translatePath ( os . path . join ( oooo , 'pair.png' ) )
I11i = xbmc . translatePath ( os . path . join ( oooo , 'theMovieDB.jpg' ) )
O0O = xbmc . translatePath ( os . path . join ( oooo , 'estrenos.png' ) )
Oo = xbmc . translatePath ( os . path . join ( oooo , 'encines.jpg' ) )
I1ii11iIi11i = xbmc . translatePath ( os . path . join ( oooo , 'recomendadas.jpg' ) )
I1IiI = xbmc . translatePath ( os . path . join ( oooo , 'accion.jpg' ) )
o0OOO = xbmc . translatePath ( os . path . join ( oooo , 'animacion.jpg' ) )
iIiiiI = xbmc . translatePath ( os . path . join ( oooo , 'aventuras.jpg' ) )
Iii1ii1II11i = xbmc . translatePath ( os . path . join ( oooo , 'belico.jpg' ) )
iI111iI = xbmc . translatePath ( os . path . join ( oooo , 'ciencia-ficcion.jpg' ) )
IiII = xbmc . translatePath ( os . path . join ( oooo , 'comedia.jpg' ) )
iI1Ii11111iIi = xbmc . translatePath ( os . path . join ( oooo , 'crimen.jpg' ) )
i1i1II = xbmc . translatePath ( os . path . join ( oooo , 'drama.jpg' ) )
O0oo0OO0 = xbmc . translatePath ( os . path . join ( oooo , 'familiar.jpg' ) )
I1i1iiI1 = xbmc . translatePath ( os . path . join ( oooo , 'fantasia.jpg' ) )
iiIIIII1i1iI = xbmc . translatePath ( os . path . join ( oooo , 'historia.jpg' ) )
o0oO0 = xbmc . translatePath ( os . path . join ( oooo , 'marvel.png' ) )
oo00 = xbmc . translatePath ( os . path . join ( oooo , 'misterio.jpg' ) )
o00 = xbmc . translatePath ( os . path . join ( oooo , 'musical.jpg' ) )
Oo0oO0ooo = xbmc . translatePath ( os . path . join ( oooo , 'romance.jpg' ) )
o0oOoO00o = xbmc . translatePath ( os . path . join ( oooo , 'spain.jpg' ) )
i1 = xbmc . translatePath ( os . path . join ( oooo , 'suspense.jpg' ) )
oOOoo00O0O = xbmc . translatePath ( os . path . join ( oooo , 'terror.jpg' ) )
i1111 = xbmc . translatePath ( os . path . join ( oooo , 'thriller.jpg' ) )
i11 = xbmc . translatePath ( os . path . join ( oooo , 'western.jpg' ) )
I11 = xbmc . translatePath ( os . path . join ( oooo , 'sagas_cine.jpg' ) )
Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( oooo , '4k.jpg' ) )
oOo0oooo00o = xbmc . translatePath ( os . path . join ( oooo , 'torrent.jpg' ) )
if 65 - 65: O0o * i1iIIII * I1
O0OoOoo00o = xbmc . translatePath ( os . path . join ( oooo , 'peliculas.png' ) )
iiiI11 = xbmc . translatePath ( os . path . join ( oooo , 'ajustes.png' ) )
OOooO = xbmc . translatePath ( os . path . join ( oooo , 'videoteca.png' ) )
OOoO00o = xbmc . translatePath ( os . path . join ( oooo , 'favorites.png' ) )
II111iiii = xbmc . translatePath ( os . path . join ( oooo , 'resolver.png' ) )
II = xbmc . translatePath ( os . path . join ( oooo , 'test.png' ) )
oOoOo00oOo = xbmc . translatePath ( os . path . join ( oooo , 'video-tutoriales.png' ) )
if 96 - 96: I111I11 . OO00OooO0OO - iiIii / OO
oO0O = oo000 . getSetting ( 'mostrar_cat' )
OOoO000O0OO = oo000 . getSetting ( 'videos' )
iiI1IiI = oo000 . getSetting ( 'activar' )
IIooOoOoo0O = oo000 . getSetting ( 'favcopy' )
OooO0 = oo000 . getSetting ( 'anticopia' )
II11iiii1Ii = oo000 . getSetting ( 'licencia_addon' )
OO0o = oo000 . getSetting ( 'notificar' )
Ooo = oo000 . getSetting ( 'mostrar_bus' )
O0o0Oo = oo000 . getSetting ( 'restante' )
Oo00OOOOO = oo000 . getSetting ( 'aviso' )
O0OO00o0OO = oo000 . getSetting ( 'RealStream_Settings' )
I11i1 = oo000 . getSetting ( 'Resolver_Settings' )
O0o0Oo = oo000 . getSetting ( 'restante' )
iIi1ii1I1 = oo000 . getSetting ( 'fav' )
o0 = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
I11II1i = 'bienvenida'
IIIII = 'bienvenida'
copyright = oo000 . getSetting ( 'copyright' )
ooooooO0oo = 'cGx1Z2luLnZpZGVvLg==' . decode ( 'base64' ) + copyright
IIiiiiiiIi1I1 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
I1IIIii = oo000 . getSetting ( 'Forceupdate' )
if I1IIIii == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
oOoOooOo0o0 = '.txt'
if 61 - 61: o00oOO0 / iiiiiIIii * o00OO0OOO0 % i1Iii % OOOooOooo00O0
Oo0OO = o0 + I11II1i + oOoOooOo0o0
oOOoOo00o = 'http://www.youtube.com'
o0OOoo0OO0OOO = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
iI1iI1I1i1I = '.xsl.pt'
iIi11Ii1 = '/master/'
Ii11iII1 = o0OOoo0OO0OOO + iI1iI1I1i1I
Oo0O0O0ooO0O = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*texto3=[\'"](.*?)[\'"]\s*'
IIIIii = 'tvg-logo=[\'"](.*?)[\'"]'
if 70 - 70: o00OO00OoO / OOO0OOo - oO000Oo000 + i111IiI1I
O0iII = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)'
o0ooOooo000oOO = '#(.+?),(.+)\s*(.+)'
Oo0oOOo = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
if 58 - 58: IiI11iII1 * OOO00O / i1Iii * IiI11iII1
oO0oo0o = 'source src=[\'"](.*?)[\'"]\s*title=[\'"](.*?)[\'"]'
II11i1I11Ii1i = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
O000O0oOO0 = '[\'"](.*?)[\'"]'
O0ooo0O0oo0 = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( 'base64' )
oo0oOo = O0ooo0O0oo0 + O0
o000O0o = '[\'"](.*?)[\'"]'
iI1iII1 = 'Realstream'
oO0OOoo0OO = 'video=[\'"](.*?)[\'"]'
O0ii1ii1ii = '0110nhu' . replace ( '0110nhu' , 'nhu' )
oooooOoo0ooo = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( 'base64' ) + O0ii1ii1ii
I1I1IiI1 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
III1iII1I1ii = '0110R0N' . replace ( '0110R0N' , 'R0N' )
oOOo0 = 'aHR0cDovL2JpdC5seS8yWEIx' . decode ( 'base64' ) + III1iII1I1ii
oo00O00oO = '0110pEJ' . replace ( '0110pEJ' , 'pEJ' )
iIiIIIi = 'aHR0cDovL2JpdC5seS8yd1Nh' . decode ( 'base64' ) + oo00O00oO
ooo00OOOooO = 'ABBAOb5' . replace ( 'ABBAOb5' , 'Ob5' )
O00OOOoOoo0O = 'aHR0cDovL2JpdC5seS8yRVhV' . decode ( 'base64' ) + ooo00OOOooO
O000OOo00oo = '0110jaw' . replace ( '0110jaw' , 'jaw' )
oo0OOo = 'aHR0cDovL2JpdC5seS8yd01M' . decode ( 'base64' ) + O000OOo00oo
ooOOO00Ooo = '01109DI' . replace ( '01109DI' , '9DI' )
IiIIIi1iIi = 'aHR0cDovL2JpdC5seS8ySXgz' . decode ( 'base64' ) + ooOOO00Ooo
ooOOoooooo = '01103hs' . replace ( '01103hs' , '3hs' )
II1I = 'aHR0cDovL2JpdC5seS8zMW1U' . decode ( 'base64' ) + ooOOoooooo
O0i1II1Iiii1I11 = '01107DW' . replace ( '01107DW' , '7DW' )
IIII = 'aHR0cDovL2JpdC5seS8yV1ln' . decode ( 'base64' ) + O0i1II1Iiii1I11
iiIiI = '0110mLl' . replace ( '0110mLl' , 'mLl' )
o00oooO0Oo = 'aHR0cDovL2JpdC5seS8yS0cw' . decode ( 'base64' ) + iiIiI
o0O0OOO0Ooo = '01102Hj' . replace ( '01102Hj' , '2Hj' )
iiIiII1 = 'aHR0cDovL2JpdC5seS8yWEJo' . decode ( 'base64' ) + o0O0OOO0Ooo
OOO00O0O = '0110fXg' . replace ( '0110fXg' , 'fXg' )
iii = 'aHR0cDovL2JpdC5seS8ySTVy' . decode ( 'base64' ) + OOO00O0O
oOooOOOoOo = '0110NMH' . replace ( '0110NMH' , 'NMH' )
i1Iii1i1I = 'aHR0cDovL2JpdC5seS8yd0t6' . decode ( 'base64' ) + oOooOOOoOo
OOoO00 = '0110bwQ' . replace ( '0110bwQ' , 'bwQ' )
IiI111111IIII = 'aHR0cDovL2JpdC5seS8yd01V' . decode ( 'base64' ) + OOoO00
i1Ii = '0110xzG' . replace ( '0110xzG' , 'xzG' )
ii111iI1iIi1 = 'aHR0cDovL2JpdC5seS8yWHhz' . decode ( 'base64' ) + i1Ii
OOO = '0110x64' . replace ( '0110x64' , 'x64' )
oo0OOo0 = 'aHR0cDovL2JpdC5seS8yRVlF' . decode ( 'base64' ) + OOO
I11IiI = '0110vUE' . replace ( '0110vUE' , 'vUE' )
O0ooO0Oo00o = 'aHR0cDovL2JpdC5seS8yWmhW' . decode ( 'base64' ) + I11IiI
ooO0oOOooOo0 = '01107ZL' . replace ( '01107ZL' , '7ZL' )
i1I1ii11i1Iii = 'aHR0cDovL2JpdC5seS8yWm4w' . decode ( 'base64' ) + ooO0oOOooOo0
I1IiiiiI = '01106cf' . replace ( '01106cf' , '6cf' )
o0OIiII = 'aHR0cDovL2JpdC5seS8yRVlk' . decode ( 'base64' ) + I1IiiiiI
ii1iII1II = '0110Jtp' . replace ( '0110Jtp' , 'Jtp' )
Iii1I1I11iiI1 = 'aHR0cDovL2JpdC5seS8yV3Nq' . decode ( 'base64' ) + ii1iII1II
I1I1i1I = '0110a5b' . replace ( '0110a5b' , 'a5b' )
ii1IO0oO0 = 'aHR0cDovL2JpdC5seS8yV3dj' . decode ( 'base64' ) + I1I1i1I
oO0 = '0110Q7u' . replace ( '0110Q7u' , 'Q7u' )
O0OO0O = 'aHR0cDovL2JpdC5seS8yV3NL' . decode ( 'base64' ) + oO0
OOOoOoO = '0110rsq' . replace ( '0110rsq' , 'rsq' )
Ii1I1i = 'aHR0cDovL2JpdC5seS8ySzhE' . decode ( 'base64' ) + OOOoOoO
OOI1iI1ii1II = '0110DDR' . replace ( '0110DDR' , 'DDR' )
O0O0OOOOoo = 'aHR0cDovL2JpdC5seS8ySzd5' . decode ( 'base64' ) + OOI1iI1ii1II
oOooO0 = '0110feQ' . replace ( '0110feQ' , 'feQ' )
Ii1I1Ii = 'aHR0cDovL2JpdC5seS8yS0cz' . decode ( 'base64' ) + oOooO0
OOoO0 = '0110MHY' . replace ( '0110MHY' , 'MHY' )
OO0Oooo0oOO0O = 'aHR0cDovL2JpdC5seS8ySXVo' . decode ( 'base64' ) + OOoO0
o00O0 = '0110xdb' . replace ( '0110xdb' , 'xdb' )
oOO0O00Oo0O0o = 'aHR0cDovL2JpdC5seS8yWEJu' . decode ( 'base64' ) + o00O0
ii1 = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( 'base64' )
ooooooO0oo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
if 35 - 35: oO000Oo000 * i1Iii / O0o - iiiiiIIii / i1iIIII - IiI11iII1
def II1I1iiIII ( ) :
 if 77 - 77: o00oOO0 - I111I11 - OOO00O
 if 49 - 49: I111I11 % ooO0OO000o . o00oOO0 + i1Iii / OO00OooO0OO
 try :
  if 72 - 72: OOO00O * iiIii . OO00OooO0OO - I111I11 + I1
  iIi1ii = oOOOoo0O0oO ( oOOo0 )
  iIII1I111III = re . compile ( o000O0o ) . findall ( iIi1ii )
  for IIo0o0O0O00oOOo in iIII1I111III :
   try :
    if 14 - 14: o00oOO0 + i1Iii
    iIiIIIi = IIo0o0O0O00oOOo
    if 52 - 52: i1iIIII - OOO00O
    o0O0o0 = xbmc . Keyboard ( '' , 'Busqueda por titulo, año, servidor:' )
    o0O0o0 . doModal ( )
    if ( o0O0o0 . isConfirmed ( ) ) :
     if 37 - 37: o00OO0OOO0 * o00OO00OoO % ii1I % OOO00O + OOO0OOo
     OOoOO0o0o0 = urllib . quote_plus ( o0O0o0 . getText ( ) ) . replace ( '+' , ' ' )
     ii1I1 = oOOOoo0O0oO ( iIiIIIi )
     iIII1I111III = re . compile ( O0iII ) . findall ( ii1I1 )
     if 93 - 93: ooO0OO000o % I1 . OOOooOooo00O0 / OO00OooO0OO - IiI11iII1 / OO00OooO0OO
     for II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 , id , oOo0OOoO0 in iIII1I111III :
      if re . search ( OOoOO0o0o0 , IIo0Oo0oO0oOO00 ( iiI11ii1I1 . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       oo00OO0000oO ( iiI11ii1I1 , Ooo0OOoOoO0 , II1IiiIi1i , id , oOo0OOoO0 )
   except :
    pass
 except :
  pass
  if 11 - 11: OOO00O / o00oOO0 - i111IiI1I * i1iIIII + i1iIIII . o00oOO0
def i1I1i111Ii ( ) :
 if 67 - 67: OO00OooO0OO . I1
 i1i1iI1iiiI = oOOOoo0O0oO ( ii1 )
 iIII1I111III = re . compile ( O000O0oOO0 ) . findall ( i1i1iI1iiiI )
 for Ooo0oOooo0 in iIII1I111III :
  try :
   if 61 - 61: o00oOO0 - OOOooOooo00O0 - I1
   import xbmc
   import xbmcaddon
   if 25 - 25: ooO0OO000o * o00OO00OoO + o00OO0OOO0 . iiiiiIIii . iiiiiIIii
   __addon__ = xbmcaddon . Addon ( )
   __addonname__ = __addon__ . getAddonInfo ( 'name' )
   __icon__ = __addon__ . getAddonInfo ( 'icon' )
   if 58 - 58: OO00OooO0OO
   ii = oo000 . getAddonInfo ( 'version' )
   if 53 - 53: I1
   o0OOOoO0 = "[COLOR lime]Version oficial: " + Ooo0oOooo0 + "  Verion instalada: " + ii + "[/COLOR]"
   o0OoOo00o0o = 5000
   if 41 - 41: OOO00O % OO - iiIii * IiI11iII1 * iiIii
   xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , o0OOOoO0 , o0OoOo00o0o , __icon__ ) )
   if 69 - 69: OOOooOooo00O0 - i1iIIII + iiiiiIIii - o00OO00OoO
   if 23 - 23: ii1I
  except :
   pass
   if 30 - 30: iiiiiIIii - I1 % I111I11 + o00OO00OoO * O0o
   if 81 - 81: i111IiI1I % I1 . O0o
def Ii1Iii1iIi ( ) :
 if 82 - 82: o00OO0OOO0 / OO00OooO0OO % O0o / I1 - OO00OooO0OO
 if 7 - 7: IiI11iII1 * OO - OOO00O + OOOooOooo00O0 * OO00OooO0OO % OO
 OOoO000O0OO = oo000 . getSetting ( 'videos' )
 if OOoO000O0OO == 'true' :
  if 15 - 15: o00oOO0 % OO00OooO0OO * o00OO00OoO
  try :
   if 81 - 81: OOO00O - O0o - I1 / IiI11iII1 - ooO0OO000o * o00OO00OoO
   import urlresolver
   from urlresolver import common
   import random
   from random import choice
   iI1i11II1i = xbmc . Player ( )
   OOooO = [ 'iHJAKUyjomI' , '_pqbkWaTGX0' , '5sSQINZQjfU' , 'hEl07wzNkaE' , 'hflGH4jKU0k' , '1qP8wVmQ1eI' ]
   o0o0OoOo0O0OO = random . choice ( OOooO )
   Ooo0OOoOoO0 = 'https://www.youtube.com/watch?v=%s' % o0o0OoOo0O0OO
   Ooo0OOoOoO0 = urlresolver . HostedMediaFile ( Ooo0OOoOoO0 ) . resolve ( )
   iI1i11II1i . play ( Ooo0OOoOoO0 )
   if 36 - 36: o00oOO0 - ooO0OO000o
   OOoO000O0OO == 'false'
   if 99 - 99: IiI11iII1 * OO + o00OO0OOO0
  except :
   pass
   if 23 - 23: I111I11
   if 94 - 94: i1iIIII + iiIii / o00oOO0 * OOOooOooo00O0
 iIi1ii = oOOOoo0O0oO ( Oo0OO )
 iIII1I111III = re . compile ( Oo0O0O0ooO0O ) . findall ( iIi1ii )
 for o0OOo0o0O0O , o0OO0o0oOOO0O , iI in iIII1I111III :
  try :
   if 2 - 2: OOO00O / oO000Oo000 . oO000Oo000 % IiI11iII1
   if 11 - 11: O0o
   IiIIII1i11I = o0OOo0o0O0O
   OOOiII1 = o0OO0o0oOOO0O
   OOo = iI
   if 22 - 22: o00oOO0 * ooO0OO000o . i111IiI1I * ii1I - OO00OooO0OO * OOO00O
   if 59 - 59: iiIii % i1iIIII . oO000Oo000 / i111IiI1I + OO00OooO0OO
   o0OOOoO0 = "[COLOR=red][B]" + IiIIII1i11I + "[/B][/COLOR]"
   o0O0oO0O00O0o = "[COLOR yellow]" + OOOiII1 + "[/COLOR]"
   II1I1Ii = "[COLOR yellow]" + OOo + "[/COLOR]"
   if 62 - 62: ooO0OO000o % o00OO00OoO . o00OO00OoO - O0o / ii1I
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , o0OOOoO0 , o0O0oO0O00O0o , II1I1Ii )
   if 31 - 31: O0o / OO / o00OO0OOO0
  except : iiIiIi ( )
  if 39 - 39: IiI11iII1
  if 91 - 91: i1iIIII - O0o + o00oOO0 / OO . o00oOO0 + ooO0OO000o
  if 26 - 26: o00OO0OOO0 - i1iIIII
  if 11 - 11: OO00OooO0OO * i1Iii
  if 81 - 81: oO000Oo000 + i111IiI1I
 if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
  if 98 - 98: OO00OooO0OO
  if 95 - 95: OOO00O / OOO00O
  if 30 - 30: o00OO0OOO0 + iiIii / iiIii % o00OO0OOO0 . o00OO0OOO0
def IIo0Oo0oO0oOO00 ( s ) :
 if 55 - 55: OOO00O - o00OO00OoO + I111I11 + oO000Oo000 % OOO0OOo
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 41 - 41: I1 - o00OO00OoO - OOO0OOo
def III11I1 ( file ) :
 if 36 - 36: i1Iii - OOO0OOo . iiIii - ii1I - OOOooOooo00O0 * iiIii
 try :
  OooOOOO = open ( file , 'r' )
  iIi1ii = OooOOOO . read ( )
  OooOOOO . close ( )
  return iIi1ii
 except :
  pass
  if 45 - 45: o00OO0OOO0 % OO00OooO0OO - ii1I
def oOOOoo0O0oO ( url ) :
 if 11 - 11: O0o * O0o * OO00OooO0OO
 try :
  iII1ii1 = urllib2 . Request ( url )
  if 12 - 12: OOOooOooo00O0 - OOO00O . i1iIIII / o00OO0OOO0 . I1 * OO
  iII1ii1 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  IiIiII1 = urllib2 . urlopen ( iII1ii1 )
  Iii1iiIi1II = IiIiII1 . read ( )
  IiIiII1 . close ( )
  return Iii1iiIi1II
 except urllib2 . URLError , OO0O00oOo :
  print 'We failed to open "%s".' % url
  if hasattr ( OO0O00oOo , 'code' ) :
   print 'We failed with error code - %s.' % OO0O00oOo . code
  if hasattr ( OO0O00oOo , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , OO0O00oOo . reason
   if 14 - 14: OO00OooO0OO
def IIiIiI1I ( url ) :
 iII1ii1 = urllib2 . Request ( url )
 iII1ii1 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 iII1ii1 . add_header ( 'Referer' , '%s' % url )
 iII1ii1 . add_header ( 'Connection' , 'keep-alive' )
 IiIiII1 = urllib2 . urlopen ( iII1ii1 )
 Iii1iiIi1II = IiIiII1 . read ( )
 IiIiII1 . close ( )
 return Iii1iiIi1II
 if 100 - 100: O0o + o00oOO0 / iiIii . ii1I
 if 14 - 14: iiiiiIIii * OOOooOooo00O0 + oO000Oo000 + ooO0OO000o + ii1I
def oOoO0 ( ) :
 if 77 - 77: O0o . oO000Oo000 % oO000Oo000 + ii1I
 if iiI1IiI == 'true' :
  Oo00o0OO0O00o ( '[COLOR orange]Menu Peliculas[/COLOR] ' , 'movieDB' , 116 , O0OoOoo00o , ii11i )
  if 82 - 82: o00OO00OoO + i1iIIII - I1 . I1
  if 6 - 6: iiiiiIIii / o00OO00OoO / I111I11
 if O0OO00o0OO == 'true' :
  Oo00o0OO0O00o ( '[COLOR orange]Ajustes[/COLOR]' , 'Settings' , 119 , iiiI11 , ii11i )
  if 27 - 27: OOOooOooo00O0 * OOO00O . IiI11iII1 % i111IiI1I * i111IiI1I . I1
  if 72 - 72: OOOooOooo00O0 % o00OO0OOO0 + OO / i1Iii + i111IiI1I
  if oO0O == 'true' :
   I1I1i ( )
   if 1 - 1: o00OO00OoO % OOOooOooo00O0 + ooO0OO000o + I1 - OO
  if I11i1 == 'true' :
   iIIIII1ii1I ( )
   Ii1i1iI ( )
   if 16 - 16: OOOooOooo00O0 / iiIii / i1iIIII * OO00OooO0OO + I1 % OOOooOooo00O0
  if OooO0 == 'false' :
   if 71 - 71: o00oOO0
   o0OOOoO0 = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   o0O0oO0O00O0o = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Program.favoritos-realstream para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   II1I1Ii = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 14 - 14: ii1I % OOOooOooo00O0
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , o0OOOoO0 , o0O0oO0O00O0o , II1I1Ii )
   if 82 - 82: O0o + iiIii . O0o % i111IiI1I / OOO0OOo . OOO0OOo
def IIi ( ) :
 Oo00o0OO0O00o ( '[COLOR orange]Buscador por id[/COLOR]' , oOOoOo00o , 127 , I11i , ii11i )
 if 66 - 66: i1Iii % OO . OOOooOooo00O0
def iiIiIi ( ) :
 Oo00o0OO0O00o ( '[COLOR orange]The movie DB[/COLOR]' , 'movieDB' , 99 , I11i , ii11i )
 Oo00o0OO0O00o ( '[COLOR orange]Buscador por id[/COLOR]' , oOOoOo00o , 127 , I11i , ii11i )
 Oo00o0OO0O00o ( '[COLOR orange]Video tutoriales[/COLOR]' , oOOoOo00o , 125 , oOoOo00oOo , ii11i )
 if 86 - 86: O0o
 if 76 - 76: OOO00O + O0o / ooO0OO000o / o00OO0OOO0
 if 61 - 61: OOOooOooo00O0 % OOOooOooo00O0 * iiiiiIIii / iiiiiIIii
 if 75 - 75: i111IiI1I . OOO00O
 if 50 - 50: o00oOO0
 if 60 - 60: OOO00O * O0o * o00OO0OOO0 * iiIii
 Oo00o0OO0O00o ( '[COLOR orange]Autorizar[/COLOR] [COLOR blue][B]OPENLOAD[/B][/COLOR]' , 'movieDB' , 97 , OoOoOO00 , ii11i )
 if 69 - 69: OOO0OOo * ooO0OO000o . ii1I / OOO0OOo . iiiiiIIii
 oOoO0 ( )
 if 63 - 63: o00OO00OoO + iiiiiIIii . I111I11 - OO00OooO0OO
 if 52 - 52: iiiiiIIii % iiIii
def Oo000ooOOO ( ) :
 if 31 - 31: O0o % o00OO00OoO % OOO00O . OOO0OOo - o00OO00OoO
 if xbmc . getCondVisibility ( 'System.HasAddon(plugin.program.favoritos-realstream)' ) :
  if 17 - 17: OOO0OOo
  xbmc . executebuiltin ( 'RunAddon(plugin.program.favoritos-realstream)' )
  if 27 - 27: ii1I % I111I11 % o00OO00OoO . ooO0OO000o - iiIii + o00oOO0
  if IIooOoOoo0O == 'true' :
   if 57 - 57: O0o / o00OO00OoO - I1
   xbmcgui . Dialog ( ) . ok ( "[COLOR orange]Real Stream Agradecimientos[/COLOR]" , "[COLOR gold]Netai quiere agradecer el genial trabajo de [/COLOR][COLOR lime][B]Spoyser[/B][/COLOR][COLOR gold] Autor de este genial script que originalmente se conoce como:[/COLOR]" , "[COLOR lime][B]Program.super.favorites[/B][/COLOR]" , "Usted puede descargar el script original desde el repositorio de Kodi >Addons de programas> program.super.favorites" )
   if 51 - 51: i111IiI1I
  oo000 . setSetting ( 'Favoritos-anuncio' , 'false' )
 else :
  if 25 - 25: i1iIIII + i111IiI1I * o00OO0OOO0
  xbmcgui . Dialog ( ) . ok ( "El programa Real stream Favoritos No esta instalado" , "[COLOR green]Necesario AddOn externo para agregar tus peliculas a favoritas dentro del addon.[/COLOR]" , "[COLOR yellow]Puedes agregarlo desde http://netai.eu/netai/ agregando la fuente a tu Kodi, instalar desde archivo zip.[/COLOR]" )
  if 92 - 92: OO00OooO0OO + o00OO00OoO + ooO0OO000o / iiiiiIIii + IiI11iII1
def I1iIi1iIiiIiI ( ) :
 oo000 . openSettings ( )
 if 47 - 47: OOO0OOo + IiI11iII1 / I1 % ii1I
def i111iI ( ) :
 urlresolver . display_settings ( )
 if 85 - 85: iiiiiIIii . o00oOO0 / OOO00O . ooO0OO000o % IiI11iII1
def iIIIII1ii1I ( ) :
 Oo00o0OO0O00o ( '[COLOR orange]Ajustes URL RESOLVER[/COLOR]' , 'resolve' , 120 , II111iiii , ii11i )
 if 90 - 90: iiIii % ooO0OO000o * O0o . oO000Oo000
def I1iii11 ( ) :
 if 74 - 74: ooO0OO000o / I1
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 78 - 78: i1iIIII . OO + OOO00O - I1
def Ii1i1iI ( ) :
 Oo00o0OO0O00o ( '[COLOR orange]Ajustes RESOLVE URL[/COLOR]' , 'resolve' , 140 , II111iiii , ii11i )
 if 31 - 31: i1iIIII . OOOooOooo00O0
def I1I1i ( ) :
 Oo00o0OO0O00o ( '[COLOR yellow]Buscador[/COLOR]' , 'search' , 111 , i1I11i , ii11i )
 Oo00o0OO0O00o ( '[COLOR orange]Todas[/COLOR]' , oOOoOo00o , 26 , I1ii11iIi11i , ii11i )
 Oo00o0OO0O00o ( '[COLOR orange]Novedades[/COLOR]' , oOOoOo00o , 2 , O0O , ii11i )
 Oo00o0OO0O00o ( '[COLOR orange]Estrenos[/COLOR]' , oOOoOo00o , 3 , Oo , ii11i )
 Oo00o0OO0O00o ( '[COLOR orange]Accion[/COLOR]' , oOOoOo00o , 5 , I1IiI , ii11i )
 Oo00o0OO0O00o ( '[COLOR orange]Animacion[/COLOR]' , oOOoOo00o , 6 , o0OOO , ii11i )
 Oo00o0OO0O00o ( '[COLOR orange]Aventuras[/COLOR]' , oOOoOo00o , 7 , iIiiiI , ii11i )
 Oo00o0OO0O00o ( '[COLOR orange]Belico[/COLOR]' , oOOoOo00o , 8 , Iii1ii1II11i , ii11i )
 Oo00o0OO0O00o ( '[COLOR orange]Ciencia Ficcion[/COLOR]' , oOOoOo00o , 9 , iI111iI , ii11i )
 Oo00o0OO0O00o ( '[COLOR orange]Comedia[/COLOR]' , oOOoOo00o , 10 , IiII , ii11i )
 Oo00o0OO0O00o ( '[COLOR orange]Crimen[/COLOR]' , oOOoOo00o , 11 , iI1Ii11111iIi , ii11i )
 Oo00o0OO0O00o ( '[COLOR orange]Drama[/COLOR]' , oOOoOo00o , 12 , i1i1II , ii11i )
 Oo00o0OO0O00o ( '[COLOR orange]Familiar[/COLOR]' , oOOoOo00o , 13 , O0oo0OO0 , ii11i )
 Oo00o0OO0O00o ( '[COLOR orange]Fantasia[/COLOR]' , oOOoOo00o , 14 , I1i1iiI1 , ii11i )
 Oo00o0OO0O00o ( '[COLOR orange]Historia[/COLOR]' , oOOoOo00o , 15 , iiIIIII1i1iI , ii11i )
 Oo00o0OO0O00o ( '[COLOR orange]Misterio[/COLOR]' , oOOoOo00o , 16 , oo00 , ii11i )
 Oo00o0OO0O00o ( '[COLOR orange]Musical[/COLOR]' , oOOoOo00o , 17 , o00 , ii11i )
 Oo00o0OO0O00o ( '[COLOR orange]Romance[/COLOR]' , oOOoOo00o , 18 , Oo0oO0ooo , ii11i )
 Oo00o0OO0O00o ( '[COLOR orange]Thriller[/COLOR]' , oOOoOo00o , 19 , i1111 , ii11i )
 Oo00o0OO0O00o ( '[COLOR orange]Suspense[/COLOR]' , oOOoOo00o , 20 , i1 , ii11i )
 Oo00o0OO0O00o ( '[COLOR orange]Terror[/COLOR]' , oOOoOo00o , 21 , oOOoo00O0O , ii11i )
 Oo00o0OO0O00o ( '[COLOR orange]Western[/COLOR]' , oOOoOo00o , 22 , i11 , ii11i )
 Oo00o0OO0O00o ( '[COLOR orange]Spain[/COLOR]' , oOOoOo00o , 23 , o0oOoO00o , ii11i )
 Oo00o0OO0O00o ( '[COLOR orange]Super heroes[/COLOR]' , oOOoOo00o , 24 , o0oO0 , ii11i )
 Oo00o0OO0O00o ( '[COLOR orange]Sagas[/COLOR]' , oOOoOo00o , 25 , I11 , ii11i )
 if 83 - 83: oO000Oo000 . ooO0OO000o / iiIii / OOOooOooo00O0 - I111I11
def oO0oO0 ( ) :
 if 14 - 14: oO000Oo000
 if 99 - 99: oO000Oo000
 IIi1ii1Ii = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 IIi1ii1Ii . doModal ( )
 if not IIi1ii1Ii . isConfirmed ( ) :
  return None ;
 iiI11ii1I1 = IIi1ii1Ii . getText ( ) . strip ( )
 if 91 - 91: ii1I / i1iIIII + oO000Oo000 - ii1I + OOOooOooo00O0
 if 18 - 18: I111I11 / i111IiI1I
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 4 - 4: I111I11 / o00OO0OOO0 + I111I11 . O0o
  II1111II = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + iiI11ii1I1 + '&language=es-ES' ) )
  if 49 - 49: iiIii - OO00OooO0OO / i111IiI1I / ooO0OO000o % iiiiiIIii * OOO0OOo
  if 100 - 100: OOOooOooo00O0 . oO000Oo000 / ooO0OO000o * I1 * OOO0OOo * iiIii
  return 'android'
  if 84 - 84: o00OO0OOO0 / OOOooOooo00O0 % ii1I * IiI11iII1 % o00OO0OOO0 - i1iIIII
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 99 - 99: OO00OooO0OO + ooO0OO000o + I1 / ii1I - I1 * O0o
  II1111II = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + iiI11ii1I1 + '&language=es-ES' )
  if 72 - 72: OO00OooO0OO * o00OO0OOO0 . OOO0OOo * i111IiI1I * iiIii * IiI11iII1
  if 40 - 40: OO00OooO0OO
  return 'windows'
  if 14 - 14: IiI11iII1
def Oo0000oOo ( ) :
 if 31 - 31: o00OO00OoO . IiI11iII1 * OOO00O + ii1I * i1Iii
 try :
  if 93 - 93: o00OO0OOO0 / O0o * I1 % i1iIIII * ooO0OO000o * o00OO00OoO
  iIi1ii = oOOOoo0O0oO ( oOOo0 )
  iIII1I111III = re . compile ( o000O0o ) . findall ( iIi1ii )
  for IIo0o0O0O00oOOo in iIII1I111III :
   if 64 - 64: I111I11 + ooO0OO000o / O0o / iiIii . OOO00O % i111IiI1I
   try :
    if 50 - 50: O0o - i111IiI1I + OOOooOooo00O0
    all = IIo0o0O0O00oOOo
    if 69 - 69: ooO0OO000o
   except :
    pass
    if 85 - 85: OOO00O / ooO0OO000o
  ii1I1 = oOOOoo0O0oO ( all )
  iIII1I111III = re . compile ( O0iII ) . findall ( ii1I1 )
  for II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 , id , oOo0OOoO0 in iIII1I111III :
   try :
    if 18 - 18: iiiiiIIii % ooO0OO000o * o00OO0OOO0
    oo00OO0000oO ( iiI11ii1I1 , Ooo0OOoOoO0 , II1IiiIi1i , id , oOo0OOoO0 )
    if 62 - 62: IiI11iII1 . i111IiI1I . i1iIIII
   except :
    pass
 except :
  pass
  if 11 - 11: OOOooOooo00O0 / o00OO00OoO
def oooO0 ( ) :
 if 16 - 16: I111I11 + i1Iii - i1iIIII
 try :
  if 3 - 3: ooO0OO000o / oO000Oo000
  O0O = oOOOoo0O0oO ( iIiIIIi )
  iIII1I111III = re . compile ( o000O0o ) . findall ( O0O )
  for IIo0o0O0O00oOOo in iIII1I111III :
   if 31 - 31: OOOooOooo00O0 + iiiiiIIii . i1iIIII
   try :
    if 89 - 89: I111I11 + I1 + I111I11
    IiII1II11I = IIo0o0O0O00oOOo
    if 54 - 54: i111IiI1I + ooO0OO000o + o00OO00OoO * IiI11iII1 - OOOooOooo00O0 % i1Iii
   except :
    pass
    if 13 - 13: OOO00O / oO000Oo000 * OO . OO * OOO00O
  i1i1iI1iiiI = oOOOoo0O0oO ( IiII1II11I )
  iIII1I111III = re . compile ( O0iII ) . findall ( i1i1iI1iiiI )
  for II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 , id , oOo0OOoO0 in iIII1I111III :
   try :
    if 63 - 63: IiI11iII1 / ooO0OO000o * iiIii + I111I11 / i111IiI1I + OOO0OOo
    oo00OO0000oO ( iiI11ii1I1 , Ooo0OOoOoO0 , II1IiiIi1i , id , oOo0OOoO0 )
    if 63 - 63: OO + o00OO0OOO0 . IiI11iII1 % IiI11iII1
   except :
    pass
 except :
  pass
  if 57 - 57: I111I11
def oOOOoo ( ) :
 if 15 - 15: ii1I % OO00OooO0OO * o00OO00OoO / IiI11iII1
 try :
  if 90 - 90: oO000Oo000
  Oo = oOOOoo0O0oO ( O00OOOoOoo0O )
  iIII1I111III = re . compile ( o000O0o ) . findall ( Oo )
  for IIo0o0O0O00oOOo in iIII1I111III :
   if 31 - 31: OOOooOooo00O0 + ooO0OO000o
   try :
    oO0oOOoo00000 = IIo0o0O0O00oOOo
   except :
    pass
    if 52 - 52: OO00OooO0OO
  iIi1ii = oOOOoo0O0oO ( oO0oOOoo00000 )
  iIII1I111III = re . compile ( O0iII ) . findall ( iIi1ii )
  for II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 , id , oOo0OOoO0 in iIII1I111III :
   try :
    oo00OO0000oO ( iiI11ii1I1 , Ooo0OOoOoO0 , II1IiiIi1i , id , oOo0OOoO0 )
    if 51 - 51: i111IiI1I
   except :
    pass
 except :
  pass
  if 88 - 88: i1iIIII
def OO00 ( ) :
 if 28 - 28: i1Iii - ii1I . o00OO0OOO0 + i111IiI1I / o00OO0OOO0
 try :
  if 35 - 35: i111IiI1I
  iIi1ii = oOOOoo0O0oO ( db2 )
  iIII1I111III = re . compile ( o000O0o ) . findall ( iIi1ii )
  for IIo0o0O0O00oOOo in iIII1I111III :
   if 75 - 75: iiIii / o00OO0OOO0 . i111IiI1I * OOOooOooo00O0 - I111I11
   try :
    if 41 - 41: OOO0OOo
    oOOoo0o0OOOO = IIo0o0O0O00oOOo
    if 26 - 26: oO000Oo000 % O0o + iiiiiIIii
   except :
    pass
    if 67 - 67: i1Iii + I111I11 - ooO0OO000o . i1Iii * I111I11 * o00OO00OoO
    if 90 - 90: OOO0OOo . i111IiI1I
  iIi1ii = oOOOoo0O0oO ( oOOoo0o0OOOO )
  iIII1I111III = re . compile ( O0iII ) . findall ( iIi1ii )
  for II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 , id , oOo0OOoO0 in iIII1I111III :
   try :
    oo00OO0000oO ( iiI11ii1I1 , Ooo0OOoOoO0 , II1IiiIi1i , id , oOo0OOoO0 )
    if 81 - 81: OOOooOooo00O0 - o00OO00OoO % OOO00O - OO / iiIii
   except :
    pass
 except :
  pass
  if 4 - 4: i1iIIII - I1 % OOO0OOo - OOOooOooo00O0 * iiiiiIIii
def Ooooo00o0OoO ( ) :
 if 75 - 75: OO00OooO0OO % I111I11
 try :
  if 30 - 30: i111IiI1I + IiI11iII1 - i111IiI1I . i111IiI1I - I111I11 + ooO0OO000o
  iIi1ii = oOOOoo0O0oO ( oo0OOo )
  iIII1I111III = re . compile ( o000O0o ) . findall ( iIi1ii )
  for IIo0o0O0O00oOOo in iIII1I111III :
   if 86 - 86: I1
   try :
    if 41 - 41: o00oOO0 * o00OO00OoO / o00oOO0 % i1Iii
    Ii = IIo0o0O0O00oOOo
    if 77 - 77: o00oOO0 % OOO0OOo
   except :
    pass
    if 9 - 9: OO - iiIii * i1iIIII . iiIii
    if 2 - 2: i1iIIII % OOOooOooo00O0
  iIi1ii = oOOOoo0O0oO ( Ii )
  iIII1I111III = re . compile ( O0iII ) . findall ( iIi1ii )
  for II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 , id , oOo0OOoO0 in iIII1I111III :
   try :
    oo00OO0000oO ( iiI11ii1I1 , Ooo0OOoOoO0 , II1IiiIi1i , id , oOo0OOoO0 )
    if 63 - 63: OO00OooO0OO % O0o
   except :
    pass
 except :
  pass
  if 39 - 39: oO000Oo000 / I111I11 / o00OO0OOO0 % OO00OooO0OO
def O0Oo00 ( ) :
 if 41 - 41: O0o % o00OO00OoO
 try :
  if 59 - 59: OOOooOooo00O0 + ii1I
  iIi1ii = oOOOoo0O0oO ( IiIIIi1iIi )
  iIII1I111III = re . compile ( o000O0o ) . findall ( iIi1ii )
  for IIo0o0O0O00oOOo in iIII1I111III :
   if 88 - 88: ii1I - OOO00O
   try :
    if 67 - 67: OOOooOooo00O0 . iiIii + o00oOO0 - i1iIIII
    OOOoO = IIo0o0O0O00oOOo
    if 14 - 14: o00OO00OoO . O0o . i1iIIII . I111I11 / iiiiiIIii
   except :
    pass
    if 21 - 21: ii1I / I1 + OO00OooO0OO * OOOooOooo00O0 . IiI11iII1
  iIi1ii = oOOOoo0O0oO ( OOOoO )
  iIII1I111III = re . compile ( O0iII ) . findall ( iIi1ii )
  for II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 , id , oOo0OOoO0 in iIII1I111III :
   try :
    oo00OO0000oO ( iiI11ii1I1 , Ooo0OOoOoO0 , II1IiiIi1i , id , oOo0OOoO0 )
    if 84 - 84: ooO0OO000o . o00OO00OoO - I111I11 . OOO00O / I111I11
   except :
    pass
 except :
  pass
  if 47 - 47: i1iIIII
def ii1i1i1IiII ( ) :
 if 63 - 63: oO000Oo000 . OO / I111I11 * i111IiI1I + i1Iii % OOO0OOo
 try :
  if 12 - 12: IiI11iII1 . OO . oO000Oo000 - i1iIIII % iiIii
  iIi1ii = oOOOoo0O0oO ( II1I )
  iIII1I111III = re . compile ( o000O0o ) . findall ( iIi1ii )
  for IIo0o0O0O00oOOo in iIII1I111III :
   if 36 - 36: OOOooOooo00O0
   try :
    if 84 - 84: IiI11iII1 . OO . I111I11 . o00OO00OoO / OOO0OOo % o00OO0OOO0
    OOO0oOoO0O = IIo0o0O0O00oOOo
    if 84 - 84: ooO0OO000o * i1iIIII - i111IiI1I * i111IiI1I
   except :
    pass
    if 8 - 8: OOO00O / I1 . i1Iii
    if 41 - 41: oO000Oo000 + OO
  iIi1ii = oOOOoo0O0oO ( OOO0oOoO0O )
  iIII1I111III = re . compile ( O0iII ) . findall ( iIi1ii )
  for II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 , id , oOo0OOoO0 in iIII1I111III :
   try :
    oo00OO0000oO ( iiI11ii1I1 , Ooo0OOoOoO0 , II1IiiIi1i , id , oOo0OOoO0 )
    if 86 - 86: o00oOO0 . O0o - OO
   except :
    pass
 except :
  pass
  if 56 - 56: ooO0OO000o
def OOo00 ( ) :
 if 37 - 37: I1
 try :
  if 46 - 46: o00oOO0 - o00OO00OoO - OOO0OOo . I1
  iIi1ii = oOOOoo0O0oO ( IIII )
  iIII1I111III = re . compile ( o000O0o ) . findall ( iIi1ii )
  for IIo0o0O0O00oOOo in iIII1I111III :
   if 35 - 35: I111I11 * o00OO00OoO - i1iIIII . o00OO00OoO . o00OO00OoO
   try :
    if 11 - 11: IiI11iII1 / o00oOO0 + o00OO00OoO % O0o
    II1II1iIIi11 = IIo0o0O0O00oOOo
    if 49 - 49: i1iIIII * o00OO00OoO - iiIii . i1Iii
   except :
    pass
    if 89 - 89: OOO00O + OOO0OOo * OOO00O / OOO00O
    if 46 - 46: OO
  iIi1ii = oOOOoo0O0oO ( II1II1iIIi11 )
  iIII1I111III = re . compile ( O0iII ) . findall ( iIi1ii )
  for II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 , id , oOo0OOoO0 in iIII1I111III :
   try :
    oo00OO0000oO ( iiI11ii1I1 , Ooo0OOoOoO0 , II1IiiIi1i , id , oOo0OOoO0 )
    if 71 - 71: o00OO00OoO / o00OO00OoO * i1Iii * i1Iii / I111I11
   except :
    pass
 except :
  pass
  if 35 - 35: OOOooOooo00O0 * iiiiiIIii * OO00OooO0OO % iiIii . o00oOO0
def O00o00O ( ) :
 if 3 - 3: OOOooOooo00O0
 try :
  if 20 - 20: I111I11 . oO000Oo000 / I111I11 % ii1I % oO000Oo000
  iIi1ii = oOOOoo0O0oO ( o00oooO0Oo )
  iIII1I111III = re . compile ( o000O0o ) . findall ( iIi1ii )
  for IIo0o0O0O00oOOo in iIII1I111III :
   if 11 - 11: i111IiI1I % o00OO0OOO0 % OOO0OOo / I111I11 % IiI11iII1 - iiIii
   try :
    if 96 - 96: o00OO0OOO0 / I111I11 . OOO0OOo - oO000Oo000 * o00OO00OoO * i1Iii
    O00oo0ooO = IIo0o0O0O00oOOo
    if 38 - 38: O0o - I111I11 - OO00OooO0OO
   except :
    pass
    if 71 - 71: i1iIIII
    if 33 - 33: IiI11iII1
  iIi1ii = oOOOoo0O0oO ( O00oo0ooO )
  iIII1I111III = re . compile ( O0iII ) . findall ( iIi1ii )
  for II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 , id , oOo0OOoO0 in iIII1I111III :
   try :
    oo00OO0000oO ( iiI11ii1I1 , Ooo0OOoOoO0 , II1IiiIi1i , id , oOo0OOoO0 )
    if 62 - 62: o00OO0OOO0 + OOO0OOo + I1 / i1iIIII
   except :
    pass
 except :
  pass
  if 7 - 7: iiiiiIIii + I1 . OO00OooO0OO / iiIii
  if 22 - 22: OOO00O - OOO00O % OOOooOooo00O0 . IiI11iII1 + i1Iii
def Oo00OOo00O ( ) :
 if 81 - 81: i111IiI1I . iiiiiIIii / IiI11iII1
 try :
  if 17 - 17: ii1I - OOOooOooo00O0 . i111IiI1I % O0o + o00OO00OoO - OOO00O
  iIi1ii = oOOOoo0O0oO ( iiIiII1 )
  iIII1I111III = re . compile ( o000O0o ) . findall ( iIi1ii )
  for IIo0o0O0O00oOOo in iIII1I111III :
   if 78 - 78: o00OO00OoO * o00oOO0 . ooO0OO000o / ooO0OO000o
   try :
    if 80 - 80: I1 - iiIii / OO - ii1I
    OO0O0o0o0 = IIo0o0O0O00oOOo
    if 31 - 31: OOO0OOo
   except :
    pass
    if 44 - 44: o00oOO0 - O0o - iiIii
    if 80 - 80: O0o * IiI11iII1 % o00OO00OoO % iiIii
  iIi1ii = oOOOoo0O0oO ( OO0O0o0o0 )
  iIII1I111III = re . compile ( O0iII ) . findall ( iIi1ii )
  for II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 , id , oOo0OOoO0 in iIII1I111III :
   try :
    oo00OO0000oO ( iiI11ii1I1 , Ooo0OOoOoO0 , II1IiiIi1i , id , oOo0OOoO0 )
    if 95 - 95: O0o - o00OO0OOO0 . IiI11iII1 - OO00OooO0OO
   except :
    pass
 except :
  pass
  if 75 - 75: OO + iiiiiIIii - I1 . i1iIIII * OOO0OOo / i111IiI1I
  if 86 - 86: o00oOO0 * I111I11 - ooO0OO000o . o00oOO0 % O0o / OOOooOooo00O0
def IiIIiIIIiIii ( ) :
 if 23 - 23: oO000Oo000 + o00OO00OoO . o00oOO0 * OO00OooO0OO + o00OO0OOO0
 try :
  if 18 - 18: i111IiI1I * iiiiiIIii . i111IiI1I / ooO0OO000o
  iIi1ii = oOOOoo0O0oO ( iii )
  iIII1I111III = re . compile ( o000O0o ) . findall ( iIi1ii )
  for IIo0o0O0O00oOOo in iIII1I111III :
   if 8 - 8: iiiiiIIii
   try :
    if 4 - 4: o00OO0OOO0 + o00OO0OOO0 * OOO00O - o00oOO0
    o00o = IIo0o0O0O00oOOo
    if 47 - 47: iiiiiIIii + oO000Oo000 - i1Iii % i1iIIII
   except :
    pass
    if 52 - 52: IiI11iII1 / OOO00O - o00OO00OoO
    if 49 - 49: o00oOO0 / iiIii . ii1I
  iIi1ii = oOOOoo0O0oO ( o00o )
  iIII1I111III = re . compile ( O0iII ) . findall ( iIi1ii )
  for II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 , id , oOo0OOoO0 in iIII1I111III :
   try :
    oo00OO0000oO ( iiI11ii1I1 , Ooo0OOoOoO0 , II1IiiIi1i , id , oOo0OOoO0 )
    if 21 - 21: o00oOO0 + ii1I + OO00OooO0OO * iiiiiIIii % oO000Oo000 % I111I11
   except :
    pass
    if 55 - 55: iiIii - OOOooOooo00O0
 except :
  pass
  if 84 - 84: IiI11iII1 + iiIii - o00oOO0 * o00oOO0
  if 61 - 61: i1iIIII . i1Iii . i1iIIII / iiIii
def o00O ( ) :
 if 48 - 48: oO000Oo000 . ii1I
 try :
  if 5 - 5: i1Iii . o00OO0OOO0 . I111I11 . i1iIIII
  iIi1ii = oOOOoo0O0oO ( i1Iii1i1I )
  iIII1I111III = re . compile ( o000O0o ) . findall ( iIi1ii )
  for IIo0o0O0O00oOOo in iIII1I111III :
   if 96 - 96: ii1I - OOOooOooo00O0 % ooO0OO000o / OO
   try :
    if 100 - 100: oO000Oo000 / OOO0OOo - i1iIIII % I111I11 - OO00OooO0OO % o00oOO0
    ooo0OO = IIo0o0O0O00oOOo
    if 15 - 15: o00oOO0
   except :
    pass
    if 62 - 62: OOO0OOo
    if 51 - 51: o00oOO0
  iIi1ii = oOOOoo0O0oO ( ooo0OO )
  iIII1I111III = re . compile ( O0iII ) . findall ( iIi1ii )
  for II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 , id , oOo0OOoO0 in iIII1I111III :
   try :
    oo00OO0000oO ( iiI11ii1I1 , Ooo0OOoOoO0 , II1IiiIi1i , id , oOo0OOoO0 )
    if 14 - 14: i111IiI1I % i1Iii % iiIii - ii1I
   except :
    pass
    if 53 - 53: OOO0OOo % iiIii
 except :
  pass
  if 59 - 59: OOOooOooo00O0 % O0o . I1 + I111I11 * i111IiI1I
def i1IiiI1iIi ( ) :
 if 66 - 66: OO * iiIii
 try :
  if 28 - 28: OO % o00oOO0 % o00OO0OOO0 + OO00OooO0OO / OO00OooO0OO
  iIi1ii = oOOOoo0O0oO ( IiI111111IIII )
  iIII1I111III = re . compile ( o000O0o ) . findall ( iIi1ii )
  for IIo0o0O0O00oOOo in iIII1I111III :
   if 71 - 71: OOOooOooo00O0 * OO % i1iIIII % OO / OO00OooO0OO
   try :
    if 56 - 56: i1iIIII % ii1I * O0o . OO * ooO0OO000o
    iIO0O00OOo = IIo0o0O0O00oOOo
    if 66 - 66: ii1I / iiiiiIIii - i1iIIII / I1 . ii1I
   except :
    pass
    if 16 - 16: iiIii % o00OO0OOO0 + o00OO00OoO - ooO0OO000o . oO000Oo000 / IiI11iII1
  iIi1ii = oOOOoo0O0oO ( iIO0O00OOo )
  iIII1I111III = re . compile ( O0iII ) . findall ( iIi1ii )
  for II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 , id , oOo0OOoO0 in iIII1I111III :
   try :
    oo00OO0000oO ( iiI11ii1I1 , Ooo0OOoOoO0 , II1IiiIi1i , id , oOo0OOoO0 )
    if 35 - 35: i1Iii / IiI11iII1 / I111I11 - O0o + I111I11 . IiI11iII1
   except :
    pass
 except :
  pass
  if 81 - 81: oO000Oo000 * OOOooOooo00O0 - o00OO0OOO0 * OOO0OOo % o00oOO0 * o00oOO0
  if 59 - 59: O0o
def I1ii1Ii1ii11i ( ) :
 if 94 - 94: i111IiI1I + IiI11iII1 / OOOooOooo00O0
 try :
  if 91 - 91: o00OO00OoO / I1 * I1
  iIi1ii = oOOOoo0O0oO ( ii111iI1iIi1 )
  iIII1I111III = re . compile ( o000O0o ) . findall ( iIi1ii )
  for IIo0o0O0O00oOOo in iIII1I111III :
   if 25 - 25: O0o . OOOooOooo00O0 * i1Iii - OOO0OOo
   try :
    if 55 - 55: o00oOO0
    o00O00ooOo0OO = IIo0o0O0O00oOOo
    if 51 - 51: i1iIIII % OOOooOooo00O0 * o00oOO0
   except :
    pass
    if 69 - 69: I1
    if 59 - 59: I111I11 - iiiiiIIii
  iIi1ii = oOOOoo0O0oO ( o00O00ooOo0OO )
  iIII1I111III = re . compile ( O0iII ) . findall ( iIi1ii )
  for II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 , id , oOo0OOoO0 in iIII1I111III :
   try :
    oo00OO0000oO ( iiI11ii1I1 , Ooo0OOoOoO0 , II1IiiIi1i , id , oOo0OOoO0 )
    if 24 - 24: iiIii - I1 + o00OO00OoO
   except :
    pass
 except :
  pass
  if 38 - 38: i1iIIII / o00OO0OOO0 . ooO0OO000o / I1 / iiIii + O0o
  if 96 - 96: oO000Oo000
def i1I11iIII1i1I ( ) :
 if 63 - 63: iiIii + IiI11iII1 - I111I11
 try :
  if 2 - 2: i111IiI1I
  iIi1ii = oOOOoo0O0oO ( oo0OOo0 )
  iIII1I111III = re . compile ( o000O0o ) . findall ( iIi1ii )
  for IIo0o0O0O00oOOo in iIII1I111III :
   if 97 - 97: i1Iii - i1iIIII
   try :
    if 79 - 79: o00oOO0 % i111IiI1I % iiIii
    Ii1 = IIo0o0O0O00oOOo
    if 34 - 34: oO000Oo000 - i1iIIII . OO00OooO0OO / I111I11
   except :
    pass
  iIi1ii = oOOOoo0O0oO ( Ii1 )
  iIII1I111III = re . compile ( O0iII ) . findall ( iIi1ii )
  for II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 , id , oOo0OOoO0 in iIII1I111III :
   try :
    oo00OO0000oO ( iiI11ii1I1 , Ooo0OOoOoO0 , II1IiiIi1i , id , oOo0OOoO0 )
    if 27 - 27: OO / iiIii * OOO00O - OO
   except :
    pass
 except :
  pass
  if 19 - 19: o00OO00OoO
def Ooooo0OoO0 ( ) :
 if 9 - 9: OOOooOooo00O0 . i111IiI1I
 try :
  if 31 - 31: i1Iii / O0o
  iIi1ii = oOOOoo0O0oO ( O0ooO0Oo00o )
  iIII1I111III = re . compile ( o000O0o ) . findall ( iIi1ii )
  for IIo0o0O0O00oOOo in iIII1I111III :
   if 84 - 84: OOOooOooo00O0
   try :
    if 87 - 87: OOO00O + iiiiiIIii
    i1iIIIIIIiII1 = IIo0o0O0O00oOOo
    if 45 - 45: OO00OooO0OO / oO000Oo000 . oO000Oo000
   except :
    pass
    if 35 - 35: IiI11iII1 . o00oOO0 * ii1I
    if 44 - 44: ii1I / iiIii
  iIi1ii = oOOOoo0O0oO ( i1iIIIIIIiII1 )
  iIII1I111III = re . compile ( O0iII ) . findall ( iIi1ii )
  for II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 , id , oOo0OOoO0 in iIII1I111III :
   try :
    oo00OO0000oO ( iiI11ii1I1 , Ooo0OOoOoO0 , II1IiiIi1i , id , oOo0OOoO0 )
    if 42 - 42: i1iIIII + iiIii % I111I11 + OO
   except :
    pass
 except :
  pass
  if 24 - 24: oO000Oo000 * I111I11 % oO000Oo000 % i111IiI1I + i1iIIII
  if 29 - 29: I111I11 - i1iIIII - ii1I . iiiiiIIii
def i11ii ( ) :
 if 50 - 50: OOO0OOo / o00oOO0 * OOO0OOo
 try :
  if 34 - 34: ooO0OO000o * ooO0OO000o % i1iIIII + oO000Oo000 * O0o % OOO0OOo
  iIi1ii = oOOOoo0O0oO ( i1I1ii11i1Iii )
  iIII1I111III = re . compile ( o000O0o ) . findall ( iIi1ii )
  for IIo0o0O0O00oOOo in iIII1I111III :
   if 25 - 25: o00OO00OoO + o00oOO0 . iiiiiIIii % o00oOO0 * OOOooOooo00O0
   try :
    if 32 - 32: ii1I - IiI11iII1
    oo00ooOoo = IIo0o0O0O00oOOo
    if 28 - 28: OOO0OOo
   except :
    pass
    if 1 - 1: OOO0OOo
    if 48 - 48: ooO0OO000o + ooO0OO000o . IiI11iII1 - OOO00O
  iIi1ii = oOOOoo0O0oO ( oo00ooOoo )
  iIII1I111III = re . compile ( O0iII ) . findall ( iIi1ii )
  for II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 , id , oOo0OOoO0 in iIII1I111III :
   try :
    oo00OO0000oO ( iiI11ii1I1 , Ooo0OOoOoO0 , II1IiiIi1i , id , oOo0OOoO0 )
    if 63 - 63: i1Iii
   except :
    pass
 except :
  pass
  if 71 - 71: I1 . OOO0OOo * oO000Oo000 % i1iIIII + OOOooOooo00O0
def iIIi1iiI1i11 ( ) :
 if 56 - 56: i1iIIII
 try :
  if 30 - 30: ii1I + i1Iii
  iIi1ii = oOOOoo0O0oO ( o0OIiII )
  iIII1I111III = re . compile ( o000O0o ) . findall ( iIi1ii )
  for IIo0o0O0O00oOOo in iIII1I111III :
   if 38 - 38: i111IiI1I . OOO0OOo
   try :
    if 24 - 24: iiiiiIIii - iiiiiIIii + o00OO0OOO0 + OO00OooO0OO - i1Iii
    I1IIiI = IIo0o0O0O00oOOo
    if 84 - 84: o00OO00OoO - iiIii / ooO0OO000o - IiI11iII1
   except :
    pass
    if 21 - 21: ooO0OO000o * ooO0OO000o % o00OO0OOO0
    if 94 - 94: o00OO00OoO + I111I11 % ii1I
  iIi1ii = oOOOoo0O0oO ( I1IIiI )
  iIII1I111III = re . compile ( O0iII ) . findall ( iIi1ii )
  for II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 , id , oOo0OOoO0 in iIII1I111III :
   try :
    oo00OO0000oO ( iiI11ii1I1 , Ooo0OOoOoO0 , II1IiiIi1i , id , oOo0OOoO0 )
    if 8 - 8: OOO00O * ooO0OO000o
   except :
    pass
 except :
  pass
  if 73 - 73: iiiiiIIii / i1Iii / o00OO00OoO / OO
  if 11 - 11: o00oOO0 + i111IiI1I - i1iIIII / OO
def iIIi1iI1I1IIi ( ) :
 if 77 - 77: OOO00O / iiIii + OOO00O % iiiiiIIii - OO00OooO0OO * OO00OooO0OO
 try :
  if 23 - 23: oO000Oo000 . I111I11 % o00OO0OOO0 - i1iIIII * iiIii . O0o
  iIi1ii = oOOOoo0O0oO ( Iii1I1I11iiI1 )
  iIII1I111III = re . compile ( o000O0o ) . findall ( iIi1ii )
  for IIo0o0O0O00oOOo in iIII1I111III :
   if 37 - 37: oO000Oo000 / iiIii . o00OO00OoO * o00OO00OoO
   try :
    if 80 - 80: OOOooOooo00O0 % o00OO0OOO0
    O0Ooo = IIo0o0O0O00oOOo
    if 78 - 78: OO % i111IiI1I * I1
   except :
    pass
    if 66 - 66: OOO0OOo . OO00OooO0OO + iiiiiIIii . O0o
    if 51 - 51: o00OO00OoO . iiIii
  iIi1ii = oOOOoo0O0oO ( O0Ooo )
  iIII1I111III = re . compile ( O0iII ) . findall ( iIi1ii )
  for II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 , id , oOo0OOoO0 in iIII1I111III :
   try :
    oo00OO0000oO ( iiI11ii1I1 , Ooo0OOoOoO0 , II1IiiIi1i , id , oOo0OOoO0 )
    if 45 - 45: I1 - iiIii / ooO0OO000o . o00OO0OOO0
   except :
    pass
 except :
  pass
  if 5 - 5: iiiiiIIii . O0o % O0o
  if 56 - 56: i1iIIII - o00OO00OoO - I1
def I1i1I ( ) :
 if 35 - 35: ii1I - OO00OooO0OO
 try :
  if 99 - 99: OO * ii1I . i1iIIII % iiIii
  iIi1ii = oOOOoo0O0oO ( ii1IO0oO0 )
  iIII1I111III = re . compile ( o000O0o ) . findall ( iIi1ii )
  for IIo0o0O0O00oOOo in iIII1I111III :
   if 76 - 76: ooO0OO000o . IiI11iII1 * oO000Oo000 * OOOooOooo00O0 . o00oOO0 . ii1I
   try :
    if 21 - 21: iiiiiIIii / o00oOO0 / O0o % OOOooOooo00O0
    Iiii1IiIi = IIo0o0O0O00oOOo
    if 39 - 39: OOOooOooo00O0 * i111IiI1I
   except :
    pass
    if 2 - 2: I1 - OOO00O + OO00OooO0OO . iiiiiIIii * iiiiiIIii / o00oOO0
    if 93 - 93: I1
  iIi1ii = oOOOoo0O0oO ( Iiii1IiIi )
  iIII1I111III = re . compile ( O0iII ) . findall ( iIi1ii )
  for II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 , id , oOo0OOoO0 in iIII1I111III :
   try :
    oo00OO0000oO ( iiI11ii1I1 , Ooo0OOoOoO0 , II1IiiIi1i , id , oOo0OOoO0 )
    if 53 - 53: i1iIIII + iiIii + i1Iii
   except :
    pass
 except :
  pass
  if 24 - 24: oO000Oo000 - i111IiI1I - oO000Oo000 * o00OO0OOO0 . i1iIIII / i111IiI1I
  if 66 - 66: iiIii
def Oooo00oOo ( ) :
 if 14 - 14: i111IiI1I % o00OO00OoO / O0o - OOO00O
 try :
  if 98 - 98: IiI11iII1
  iIi1ii = oOOOoo0O0oO ( O0OO0O )
  iIII1I111III = re . compile ( o000O0o ) . findall ( iIi1ii )
  for IIo0o0O0O00oOOo in iIII1I111III :
   if 92 - 92: IiI11iII1 - O0o
   try :
    if 32 - 32: OOO0OOo % OO * OO + i111IiI1I * I111I11 * OOO0OOo
    iIiIii1I1II = IIo0o0O0O00oOOo
    if 61 - 61: i111IiI1I + O0o + ii1I / ii1I % I111I11
   except :
    pass
    if 42 - 42: OOO0OOo * IiI11iII1 . i111IiI1I * OO00OooO0OO + o00oOO0
    if 25 - 25: o00OO00OoO . OO00OooO0OO + i1Iii
  iIi1ii = oOOOoo0O0oO ( iIiIii1I1II )
  iIII1I111III = re . compile ( O0iII ) . findall ( iIi1ii )
  for II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 , id , oOo0OOoO0 in iIII1I111III :
   try :
    oo00OO0000oO ( iiI11ii1I1 , Ooo0OOoOoO0 , II1IiiIi1i , id , oOo0OOoO0 )
    if 75 - 75: i111IiI1I - iiiiiIIii % oO000Oo000 + ii1I
   except :
    pass
 except :
  pass
  if 100 - 100: o00OO00OoO + iiiiiIIii - ii1I - I111I11
  if 40 - 40: o00oOO0 % OO
def oo0O0o00 ( ) :
 if 70 - 70: OO
 try :
  if 46 - 46: o00OO00OoO - I1
  iIi1ii = oOOOoo0O0oO ( Ii1I1i )
  iIII1I111III = re . compile ( o000O0o ) . findall ( iIi1ii )
  for IIo0o0O0O00oOOo in iIII1I111III :
   if 46 - 46: IiI11iII1 % OOO0OOo
   try :
    if 72 - 72: O0o
    iI1I1II1 = IIo0o0O0O00oOOo
    if 92 - 92: i1iIIII - i1iIIII * OO % OO00OooO0OO
   except :
    pass
    if 77 - 77: O0o - I1 . i1Iii
  iIi1ii = oOOOoo0O0oO ( iI1I1II1 )
  iIII1I111III = re . compile ( O0iII ) . findall ( iIi1ii )
  for II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 , id , oOo0OOoO0 in iIII1I111III :
   try :
    oo00OO0000oO ( iiI11ii1I1 , Ooo0OOoOoO0 , II1IiiIi1i , id , oOo0OOoO0 )
    if 26 - 26: iiiiiIIii * i111IiI1I . I1
   except :
    pass
 except :
  pass
  if 59 - 59: ooO0OO000o + I1 - iiiiiIIii
  if 62 - 62: ii1I % OOOooOooo00O0 . i111IiI1I . OOOooOooo00O0
def ooOo0O0O0oOO0 ( ) :
 if 10 - 10: iiIii + ooO0OO000o
 try :
  if 43 - 43: O0o / I111I11 % iiiiiIIii - OOOooOooo00O0
  iIi1ii = oOOOoo0O0oO ( O0O0OOOOoo )
  iIII1I111III = re . compile ( o000O0o ) . findall ( iIi1ii )
  for IIo0o0O0O00oOOo in iIII1I111III :
   if 62 - 62: o00OO00OoO
   try :
    if 63 - 63: OOOooOooo00O0 + OOO00O * i1Iii / iiiiiIIii / iiIii * O0o
    OOoO00ooO = IIo0o0O0O00oOOo
    if 12 - 12: OOO00O % OO00OooO0OO + i1Iii - I1 . OOO0OOo / OO00OooO0OO
   except :
    pass
    if 51 - 51: OOOooOooo00O0 . OO00OooO0OO
    if 73 - 73: i1iIIII . OO00OooO0OO / IiI11iII1 % OOO0OOo
  iIi1ii = oOOOoo0O0oO ( OOoO00ooO )
  iIII1I111III = re . compile ( O0iII ) . findall ( iIi1ii )
  for II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 , id , oOo0OOoO0 in iIII1I111III :
   try :
    oo00OO0000oO ( iiI11ii1I1 , Ooo0OOoOoO0 , II1IiiIi1i , id , oOo0OOoO0 )
    if 65 - 65: i111IiI1I - OO00OooO0OO - OOO0OOo
   except :
    pass
 except :
  pass
  if 42 - 42: I111I11 * OO00OooO0OO % I1 - OOO0OOo % i111IiI1I
def Ii1I1 ( ) :
 if 58 - 58: i111IiI1I - o00OO00OoO % OO00OooO0OO
 try :
  if 4 - 4: I1 + OOO00O + I1
  iIi1ii = oOOOoo0O0oO ( Ii1I1Ii )
  iIII1I111III = re . compile ( o000O0o ) . findall ( iIi1ii )
  for IIo0o0O0O00oOOo in iIII1I111III :
   if 31 - 31: OOO0OOo
   try :
    if 78 - 78: ii1I + iiiiiIIii + IiI11iII1 / iiiiiIIii % O0o % i111IiI1I
    Oo0O0Oo00O = IIo0o0O0O00oOOo
    if 9 - 9: iiiiiIIii . OO00OooO0OO - o00OO0OOO0
   except :
    pass
  iIi1ii = oOOOoo0O0oO ( Oo0O0Oo00O )
  iIII1I111III = re . compile ( O0iII ) . findall ( iIi1ii )
  for II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 , id , oOo0OOoO0 in iIII1I111III :
   try :
    oo00OO0000oO ( iiI11ii1I1 , Ooo0OOoOoO0 , II1IiiIi1i , id , oOo0OOoO0 )
    if 32 - 32: i1iIIII / OO00OooO0OO / O0o + I111I11 . i1Iii . iiiiiIIii
   except :
    pass
 except :
  pass
  if 21 - 21: O0o / I111I11 % I1
def IIiI1i ( ) :
 if 6 - 6: o00OO0OOO0 / oO000Oo000 - OOOooOooo00O0
 try :
  if 62 - 62: o00OO00OoO % OOOooOooo00O0
  iIi1ii = oOOOoo0O0oO ( OO0Oooo0oOO0O )
  iIII1I111III = re . compile ( o000O0o ) . findall ( iIi1ii )
  for IIo0o0O0O00oOOo in iIII1I111III :
   if 54 - 54: o00oOO0 % oO000Oo000 . o00oOO0 * OOOooOooo00O0 + o00oOO0 % I1
   try :
    if 23 - 23: IiI11iII1 - OOOooOooo00O0 + OOO0OOo - o00oOO0 * o00oOO0 . iiIii
    iIii11iI1II = IIo0o0O0O00oOOo
    if 42 - 42: OOO00O - OO00OooO0OO + o00OO0OOO0 % OOO0OOo
   except :
    pass
  iIi1ii = oOOOoo0O0oO ( iIii11iI1II )
  iIII1I111III = re . compile ( O0iII ) . findall ( iIi1ii )
  for II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 , id , oOo0OOoO0 in iIII1I111III :
   try :
    oo00OO0000oO ( iiI11ii1I1 , Ooo0OOoOoO0 , II1IiiIi1i , id , oOo0OOoO0 )
    if 44 - 44: I1 - ooO0OO000o - o00OO0OOO0 * o00OO0OOO0 + o00oOO0
   except :
    pass
 except :
  pass
  if 56 - 56: OOO00O / O0o . OOO0OOo % o00oOO0 + OOOooOooo00O0
def I1IiiiIIIi1i ( ) :
 if 58 - 58: IiI11iII1 / OOO00O + ooO0OO000o + OOO00O . O0o + I111I11
 try :
  if 37 - 37: o00OO00OoO . iiIii % i111IiI1I * I1
  iIi1ii = oOOOoo0O0oO ( oOO0O00Oo0O0o )
  iIII1I111III = re . compile ( o000O0o ) . findall ( iIi1ii )
  for IIo0o0O0O00oOOo in iIII1I111III :
   if 71 - 71: iiIii / iiiiiIIii + OOOooOooo00O0
   try :
    if 48 - 48: IiI11iII1 + oO000Oo000
    Iiii1II1iI = IIo0o0O0O00oOOo
    if 42 - 42: i1Iii % i1iIIII + iiiiiIIii
   except :
    pass
  iIi1ii = oOOOoo0O0oO ( Iiii1II1iI )
  iIII1I111III = re . compile ( o0ooOooo000oOO ) . findall ( iIi1ii )
  for II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 in iIII1I111III :
   try :
    ooOO0o ( II1IiiIi1i , iiI11ii1I1 , Ooo0OOoOoO0 )
    if 51 - 51: iiIii - o00OO0OOO0 * o00OO00OoO
   except :
    pass
    if 12 - 12: O0o % OOO00O % OOO00O
 except :
  pass
  if 78 - 78: i111IiI1I . o00oOO0 . o00OO00OoO
  if 97 - 97: i1Iii
def oO ( thumb , name , url , id ) :
 if 78 - 78: o00oOO0 - OO % OOO00O
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( IIIIii ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   Oo00o0OO0O00o ( name , url , '' , thumb , thumb )
  else :
   Oo00o0OO0O00o ( name , url , '' , oOooOoO0Oo0O , ii11i )
 else :
  if 'youtube.com/watch?v=' in url :
   url = 'plugin://plugin.video.youtube/play/?video_id=%s' % ( url . split ( '=' ) [ - 1 ] )
  elif 'dailymotion.com/video/' in url :
   url = url . split ( '/' ) [ - 1 ] . split ( '_' ) [ 0 ]
   url = 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=%s' % url
  else :
   url = url
  if 'tvg-logo' in thumb :
   thumb = re . compile ( IIIIii ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   o0OoOoo00O ( name , url , 1 , thumb , thumb )
  else :
   o0OoOoo00O ( name , url , 1 , oOooOoO0Oo0O , ii11i )
   if 29 - 29: iiiiiIIii
def ooOO0o ( thumb , name , url ) :
 if 86 - 86: I111I11 . i111IiI1I
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( IIIIii ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   Oo00o0OO0O00o ( name , url , '' , oOooOoO0Oo0O , ii11i )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 2 - 2: i1iIIII
  if 'tvg-logo' in thumb :
   thumb = re . compile ( IIIIii ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 60 - 60: OO
   oO00Ooo0oO ( name , url , 4 , OOOo , ii11i )
   if 74 - 74: OOO0OOo - i1iIIII . iiIii
  else :
   if 31 - 31: iiiiiIIii % o00OO00OoO + O0o + ii1I * IiI11iII1
   oO00Ooo0oO ( name , url , 4 , OOOo , ii11i )
   if 45 - 45: OOOooOooo00O0 * IiI11iII1 . OOO00O - IiI11iII1 + i111IiI1I
def oo00OO0000oO ( name , url , thumb , id , trailer ) :
 if 34 - 34: OOOooOooo00O0 . iiIii
 if 78 - 78: o00OO0OOO0 % OO00OooO0OO / i1iIIII % OOOooOooo00O0 - oO000Oo000
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 2 - 2: O0o
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( IIIIii ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   Oo00o0OO0O00o ( name , url , '' , oOooOoO0Oo0O , ii11i )
 else :
  if 45 - 45: i1iIIII / ii1I
  if '[Rapidvideo]' in name :
   if 10 - 10: oO000Oo000 - i1Iii * O0o % O0o * i111IiI1I - o00OO0OOO0
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[Rapidvideo]' , '[COLOR orange][Rapidvideo][/COLOR]' ) % name
  if '[rapidvideo]' in name :
   if 97 - 97: I111I11 % IiI11iII1 + IiI11iII1 - OO / OOO0OOo * OO00OooO0OO
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[streamgo]' , '[COLOR darkorange][streamgo][/COLOR]' ) % name
  elif '[streamago]' in name :
   if 17 - 17: OOO0OOo
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[Streamgo]' , '[COLOR orange][Streamgo][/COLOR]' ) % name
  elif '[Streamgo]' in name :
   if 39 - 39: OOO00O . I111I11
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[Openload]' , '[COLOR red][Openload][/COLOR]' ) % name
  elif '[Openload]' in name :
   if 45 - 45: i1Iii * o00oOO0 / O0o
   name = '[COLOR white]%s[/COLOR] [PAIR]' . replace ( '[Openload]' , '[COLOR red][openload Pair][/COLOR]' ) % name
  elif '[openload]' in name :
   if 77 - 77: IiI11iII1 - o00OO00OoO
   name = '[COLOR white]%s[/COLOR] [PAIR]' . replace ( '[openload]' , '[COLOR green][Vidoza][/COLOR]' ) % name
  elif '[Vidoza]' in name :
   if 11 - 11: o00OO0OOO0
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[Vidoza]' , '[COLOR green][Vidoza][/COLOR]' ) % name
  elif '[vidoza]' in name :
   if 26 - 26: O0o * IiI11iII1 - OOOooOooo00O0
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[vidoza]' , '[COLOR green][vidoza][/COLOR]' ) % name
  elif '[Streamcloud]' in name :
   if 27 - 27: o00OO0OOO0 * IiI11iII1 - OO + OOO0OOo * OOO0OOo
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[Streamcloud]' , '[COLOR blue][Streamcloud][/COLOR]' ) % name
  elif '[streamcloud]' in name :
   if 55 - 55: OOO00O
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[streamcloud]' , '[COLOR blue][streamcloud][/COLOR]' ) % name
   if 82 - 82: IiI11iII1 - OOOooOooo00O0 + OO
  elif '[streamcherry]' in name :
   if 64 - 64: iiiiiIIii . ooO0OO000o * OOO0OOo + i1iIIII - iiIii . i1iIIII
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[streamcherry]' , '[COLOR pink][streamcherry][/COLOR]' ) % name
   if 70 - 70: iiIii - i1Iii . O0o % o00OO00OoO / o00oOO0 - ooO0OO000o
  elif '[Streamcherry]' in name :
   if 55 - 55: oO000Oo000 - OO
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[Streamcherry]' , '[COLOR pink][Streamcherry][/COLOR]' ) % name
   if 100 - 100: ooO0OO000o
  elif '[Okru]' in name :
   if 79 - 79: O0o
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[Okru]' , '[COLOR aqua][Okru][/COLOR]' ) % name
  elif '[okru]' in name :
   if 81 - 81: OOOooOooo00O0 + O0o * IiI11iII1 - O0o . OOOooOooo00O0
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[okru]' , '[COLOR aqua][okru][/COLOR]' ) % name
   if 48 - 48: o00OO00OoO . i1iIIII . OO00OooO0OO . o00oOO0 % o00OO0OOO0 / oO000Oo000
  elif '[4k]' in name :
   if 11 - 11: I1 % OO % oO000Oo000
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[4k]' , '[COLOR yellow][4k][/COLOR]' ) % name
   if 99 - 99: OOO00O / O0o - OOO0OOo * o00OO0OOO0 % OO00OooO0OO
  elif '[Youtube]' in name :
   if 13 - 13: OO
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[Youtube]' , '[COLOR white][Youtube][/COLOR]' ) % name
  elif '[Realstream]' in name :
   if 70 - 70: IiI11iII1 + ooO0OO000o . i1Iii * OOO0OOo
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[Realstream]' , '[COLOR magenta][Realstream][/COLOR]' ) % name
  elif '[Team]' in name :
   if 2 - 2: i1iIIII . OOOooOooo00O0 . i111IiI1I
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[Team]' , '[COLOR magenta][Team][/COLOR]' ) % name
  elif '[Drive]' in name :
   if 42 - 42: OOOooOooo00O0 % i1Iii / OO - i1Iii * ii1I
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[Drive]' , '[COLOR magenta][Drive][/COLOR]' ) % name
   if 19 - 19: i1Iii * OO00OooO0OO % ii1I
  elif '[vidlox]' in name :
   if 24 - 24: iiiiiIIii
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[vidlox]' , '[COLOR magenta][vidlox][/COLOR]' ) % name
   if 10 - 10: iiiiiIIii % OOO0OOo / OOOooOooo00O0
  elif '[Vidlox]' in name :
   if 28 - 28: OOOooOooo00O0 % OOO00O
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[Vidlox]' , '[COLOR magenta][vidlox][/COLOR]' ) % name
   if 48 - 48: ii1I % i1Iii
  elif '[clipwatching]' in name :
   if 29 - 29: oO000Oo000 + ii1I % o00OO00OoO
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[clipwatching]' , '[COLOR pink][clipwatching][/COLOR]' ) % name
   if 93 - 93: o00oOO0 % O0o
  elif '[Clipwatching]' in name :
   if 90 - 90: OO00OooO0OO - OOOooOooo00O0 / OOO0OOo / ooO0OO000o / o00OO00OoO
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[Clipwatching]' , '[COLOR pink][Clipwatching][/COLOR]' ) % name
   if 87 - 87: o00oOO0 / i111IiI1I + O0o
  else :
   if 93 - 93: O0o + i1Iii % OOO00O
   name = '[COLOR white]%s[/COLOR]' % name
   if 21 - 21: OOOooOooo00O0
  if 'tvg-logo' in thumb :
   thumb = re . compile ( IIIIii ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 6 - 6: i111IiI1I
   o0OoOoo00O ( name , url , 1 , thumb , thumb , id , trailer )
   if 46 - 46: i111IiI1I + i1Iii
  else :
   if 79 - 79: i1iIIII - i111IiI1I * i111IiI1I . o00oOO0
   o0OoOoo00O ( name , url , 1 , thumb , thumb , id , trailer )
   if 100 - 100: I111I11 * o00OO00OoO % OO00OooO0OO / o00OO0OOO0
def OOoo0oOO00 ( name , trailer ) :
 if 46 - 46: ii1I - o00OO00OoO
 if 95 - 95: I111I11
 Ooo0OOoOoO0 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
 oo000oO = Ooo0OOoOoO0
 O0OOO0 = xbmcgui . ListItem ( name , trailer , path = oo000oO )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0OOO0 )
 return
 if 8 - 8: ii1I / I111I11 + iiiiiIIii * OOO0OOo % i111IiI1I . o00OO00OoO
 if 6 - 6: i111IiI1I % iiIii . iiIii - o00OO0OOO0 / o00OO00OoO . I1
def oO0O0oO ( name , url ) :
 import urlresolver
 from urlresolver import common
 if 27 - 27: ooO0OO000o / o00oOO0 + O0o - OOOooOooo00O0 % iiiiiIIii
 I111i1Ii1i1 = urlresolver . HostedMediaFile ( url )
 if 11 - 11: o00oOO0 % i111IiI1I
 if not I111i1Ii1i1 :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 53 - 53: OOO00O / O0o - OO + i1Iii
  return False
  if 30 - 30: i111IiI1I
  if 24 - 24: OO - i1Iii + o00OO0OOO0 / oO000Oo000 % OO00OooO0OO + O0o
 try :
  oO00o = I111i1Ii1i1 . resolve ( )
  if not oO00o or not isinstance ( oO00o , basestring ) :
   try : i11I1IiiiiiiiIi = oO00o . msg
   except : i11I1IiiiiiiiIi = url
   raise Exception ( i11I1IiiiiiiiIi )
 except Exception as OO0O00oOo :
  try : i11I1IiiiiiiiIi = str ( OO0O00oOo )
  except : i11I1IiiiiiiiIi = url
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 32 - 32: iiiiiIIii + OO00OooO0OO . IiI11iII1
  return False
  if 41 - 41: o00oOO0 . ii1I / o00OO00OoO
 OO0o = oo000 . getSetting ( 'notificar' )
 if OO0o == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
 oOo00OoO0O = xbmcgui . ListItem ( path = oO00o )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOo00OoO0O )
 if 69 - 69: O0o * OO00OooO0OO - oO000Oo000 + ooO0OO000o + ooO0OO000o
def O0oo ( name , url ) :
 if 54 - 54: ooO0OO000o % i1iIIII - OO00OooO0OO
 if 61 - 61: iiIii * i111IiI1I . iiIii + iiIii / i111IiI1I * ooO0OO000o
 if 'https://www.rapidvideo.com/v/' in url :
  if 73 - 73: oO000Oo000 * oO000Oo000 / OOO00O
  iIi1ii = oOOOoo0O0oO ( url )
  iIII1I111III = re . compile ( 'rapidvideo' ) . findall ( iIi1ii )
  for url in iIII1I111III :
   if 43 - 43: o00OO0OOO0 . I1 . i111IiI1I + ooO0OO000o * OOO0OOo * ooO0OO000o
   if 41 - 41: o00OO0OOO0 + OOO0OOo % i1iIIII . o00OO0OOO0 + oO000Oo000 . oO000Oo000
   try :
    OO0o = oo000 . getSetting ( 'notificar' )
    if OO0o == 'true' :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oOo00OoO0O = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOo00OoO0O )
    if 31 - 31: ii1I + I111I11 . oO000Oo000 * o00oOO0
   except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 66 - 66: o00oOO0 + I1 % I111I11 . ooO0OO000o * o00OO0OOO0 % o00OO0OOO0
   if 87 - 87: OOOooOooo00O0 + iiiiiIIii . oO000Oo000 - i1iIIII
 else :
  if 6 - 6: O0o * i1iIIII
  import urlresolver
  from urlresolver import common
  if 28 - 28: iiIii * iiiiiIIii / IiI11iII1
  I111i1Ii1i1 = urlresolver . HostedMediaFile ( url )
  if 52 - 52: ooO0OO000o / iiiiiIIii % oO000Oo000 * OO00OooO0OO % OOOooOooo00O0
  if not I111i1Ii1i1 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 69 - 69: o00OO0OOO0
   if 83 - 83: iiiiiIIii
  try :
   oO00o = I111i1Ii1i1 . resolve ( )
   if not oO00o or not isinstance ( oO00o , basestring ) :
    try : i11I1IiiiiiiiIi = oO00o . msg
    except : i11I1IiiiiiiiIi = url
    raise Exception ( i11I1IiiiiiiiIi )
  except Exception as OO0O00oOo :
   try : i11I1IiiiiiiiIi = str ( OO0O00oOo )
   except : i11I1IiiiiiiiIi = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 38 - 38: IiI11iII1 + i1iIIII . I1
  OO0o = oo000 . getSetting ( 'notificar' )
  if OO0o == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  oOo00OoO0O = xbmcgui . ListItem ( path = oO00o )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOo00OoO0O )
  if 19 - 19: oO000Oo000 - iiiiiIIii - OOO0OOo - o00oOO0 . oO000Oo000 . IiI11iII1
 return
 if 48 - 48: oO000Oo000 + i111IiI1I
 if 60 - 60: o00OO00OoO + oO000Oo000 . i111IiI1I / I1 . O0o
 if 14 - 14: OOOooOooo00O0
def o0oo0Ooooo0 ( name , url ) :
 if 76 - 76: I1 * i1iIIII * ooO0OO000o + IiI11iII1 * IiI11iII1
 if '[Youtube]' in name :
  if 35 - 35: iiiiiIIii
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 73 - 73: ooO0OO000o - o00OO0OOO0
  try :
   OO0o = oo000 . getSetting ( 'notificar' )
   if OO0o == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oOo00OoO0O = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOo00OoO0O )
    if 2 - 2: I111I11 / IiI11iII1
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 54 - 54: I1 . o00OO00OoO - o00OO0OOO0 + OOO00O + iiIii / iiIii
  if 22 - 22: OOO00O . O0o
 else :
  if 12 - 12: OOO0OOo
  import urlresolver
  from urlresolver import common
  if 71 - 71: OO00OooO0OO . I111I11 . OO00OooO0OO - OOO00O
  I111i1Ii1i1 = urlresolver . HostedMediaFile ( url )
  if 45 - 45: i111IiI1I / ooO0OO000o / o00oOO0 * OOOooOooo00O0
  if not I111i1Ii1i1 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 18 - 18: O0o + OOOooOooo00O0 + O0o . o00OO0OOO0 + IiI11iII1 . OOO00O
   if 7 - 7: o00OO0OOO0 + O0o * o00OO00OoO * o00OO00OoO / I111I11 - OOO0OOo
  try :
   oO00o = I111i1Ii1i1 . resolve ( )
   if not oO00o or not isinstance ( oO00o , basestring ) :
    try : i11I1IiiiiiiiIi = oO00o . msg
    except : i11I1IiiiiiiiIi = url
    raise Exception ( i11I1IiiiiiiiIi )
  except Exception as OO0O00oOo :
   try : i11I1IiiiiiiiIi = str ( OO0O00oOo )
   except : i11I1IiiiiiiiIi = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 65 - 65: i1Iii + o00oOO0 + I111I11
  OO0o = oo000 . getSetting ( 'notificar' )
  if OO0o == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  oOo00OoO0O = xbmcgui . ListItem ( path = oO00o )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOo00OoO0O )
  if 77 - 77: I111I11
 return
 if 50 - 50: ooO0OO000o . ooO0OO000o . OOO00O % iiIii
def ooo000oOO ( name , url ) :
 if 27 - 27: iiiiiIIii * ii1I * OO
 if 92 - 92: iiIii / ii1I + o00OO0OOO0
 if '[Youtube]' in name :
  if 87 - 87: o00oOO0 % O0o
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 72 - 72: OOOooOooo00O0 . OOOooOooo00O0 - o00OO0OOO0
  try :
   OO0o = oo000 . getSetting ( 'notificar' )
   if OO0o == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oOo00OoO0O = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOo00OoO0O )
    if 48 - 48: iiIii - OOO00O + iiIii - OO00OooO0OO * ii1I . oO000Oo000
    if 35 - 35: i111IiI1I . ooO0OO000o + iiIii + OOOooOooo00O0 + I1
    if 65 - 65: ooO0OO000o * OO00OooO0OO / OO00OooO0OO . o00oOO0
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 87 - 87: I111I11 * o00OO0OOO0 % iiIii * iiIii
  if 58 - 58: OOOooOooo00O0 . iiiiiIIii + OO00OooO0OO % iiIii - OO
 else :
  if 50 - 50: oO000Oo000 % I111I11 - OOO00O . I1 + ooO0OO000o % oO000Oo000
  import xbmcgui
  import urlresolver
  from urlresolver import common
  if 10 - 10: oO000Oo000 . I1 + OOO0OOo
  I111i1Ii1i1 = urlresolver . HostedMediaFile ( url )
  if 66 - 66: OO % iiiiiIIii
  if not I111i1Ii1i1 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 21 - 21: o00oOO0 - i1iIIII % ii1I
  import resolveurl as urlresolver
  if 71 - 71: I1 - o00OO00OoO * IiI11iII1 + i1Iii - OO % o00OO0OOO0
  I111i1Ii1i1 = urlresolver . HostedMediaFile ( url )
  if 63 - 63: O0o + OOOooOooo00O0 . OO / OO00OooO0OO
  if 84 - 84: I1
  if not I111i1Ii1i1 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 42 - 42: I111I11 - OO - i1iIIII . oO000Oo000 / o00oOO0
  try :
   oO00o = I111i1Ii1i1 . resolve ( )
   if not oO00o or not isinstance ( oO00o , basestring ) :
    try : i11I1IiiiiiiiIi = oO00o . msg
    except : i11I1IiiiiiiiIi = url
    raise Exception ( i11I1IiiiiiiiIi )
  except Exception as OO0O00oOo :
   try : i11I1IiiiiiiiIi = str ( OO0O00oOo )
   except : i11I1IiiiiiiiIi = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 56 - 56: ii1I - O0o . I111I11
   if 81 - 81: i111IiI1I / o00oOO0 * i111IiI1I . ooO0OO000o
   if 61 - 61: OO * OOOooOooo00O0 + IiI11iII1 . O0o % o00OO00OoO . IiI11iII1
  OO0o = oo000 . getSetting ( 'notificar' )
  if OO0o == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 53 - 53: IiI11iII1 * i111IiI1I / O0o / OO00OooO0OO % o00OO0OOO0
   if '[Realstream]' in name :
    if 39 - 39: OO / i1iIIII . OO * o00OO0OOO0 / o00oOO0
    O0o0Oo = oo000 . getSetting ( 'restante' )
    if O0o0Oo == 'true' :
     II111 = xbmcgui . Dialog ( )
     o0o0O0O000 = II111 . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 24 - 24: OOO00O / oO000Oo000 + i111IiI1I . i111IiI1I
   oOo00OoO0O = xbmcgui . ListItem ( path = oO00o )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOo00OoO0O )
   if 39 - 39: OOO00O + ooO0OO000o / I1 % i111IiI1I / i1Iii * i111IiI1I
   if 77 - 77: i111IiI1I . IiI11iII1 % o00oOO0
   if 42 - 42: i111IiI1I % oO000Oo000 % iiiiiIIii % i1Iii + o00OO00OoO % o00oOO0
 return
 if 3 - 3: i1Iii
 if 64 - 64: OO . OO00OooO0OO - i1iIIII . OOO00O - oO000Oo000
 if 77 - 77: OOO0OOo % o00oOO0 / I111I11 % oO000Oo000 % i1iIIII % OO
def I1i11II11i1iI ( name , url ) :
 if 43 - 43: iiIii . IiI11iII1
 if 12 - 12: IiI11iII1 + OOOooOooo00O0 + o00OO00OoO . i111IiI1I / OOO0OOo
 if '[Youtube]' in name :
  if 29 - 29: i111IiI1I . OOO00O - I111I11
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 68 - 68: O0o + I111I11 / i1Iii
  try :
   OO0o = oo000 . getSetting ( 'notificar' )
   if OO0o == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oOo00OoO0O = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOo00OoO0O )
    if 91 - 91: o00oOO0 % O0o . OO00OooO0OO
    if 70 - 70: o00OO00OoO % I111I11 % ooO0OO000o . I1 / IiI11iII1
    if 100 - 100: o00OO0OOO0 * ii1I % i1Iii / iiIii / OOO00O + o00OO0OOO0
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 59 - 59: IiI11iII1 - i111IiI1I
 else :
  if 14 - 14: O0o - O0o
  import resolveurl
  if 5 - 5: i111IiI1I
  I111i1Ii1i1 = urlresolver . HostedMediaFile ( url )
  if 84 - 84: I111I11 * i1Iii * I111I11 % i111IiI1I / OO00OooO0OO
  if 100 - 100: i111IiI1I . OOO0OOo - O0o . ii1I / I111I11
  if not I111i1Ii1i1 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 71 - 71: IiI11iII1 * iiIii . o00OO00OoO
  try :
   oO00o = I111i1Ii1i1 . resolve ( )
   if not oO00o or not isinstance ( oO00o , basestring ) :
    try : i11I1IiiiiiiiIi = oO00o . msg
    except : i11I1IiiiiiiiIi = url
    raise Exception ( i11I1IiiiiiiiIi )
  except Exception as OO0O00oOo :
   try : i11I1IiiiiiiiIi = str ( OO0O00oOo )
   except : i11I1IiiiiiiiIi = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 49 - 49: i111IiI1I * ooO0OO000o . i111IiI1I
   if 19 - 19: I111I11 - i111IiI1I
   if 59 - 59: iiiiiIIii * OO - OOO0OOo . OOOooOooo00O0
  OO0o = oo000 . getSetting ( 'notificar' )
  if OO0o == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 89 - 89: OOOooOooo00O0
   if '[Realstream]' in name :
    if 69 - 69: OOO00O - i1iIIII * ooO0OO000o
    O0o0Oo = oo000 . getSetting ( 'restante' )
    if O0o0Oo == 'true' :
     II111 = xbmcgui . Dialog ( )
     o0o0O0O000 = II111 . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 84 - 84: OOO00O + ii1I - OOOooOooo00O0 * OOO00O
   oOo00OoO0O = xbmcgui . ListItem ( path = oO00o )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOo00OoO0O )
   if 33 - 33: OOO00O % I1 - i1Iii . ooO0OO000o / ooO0OO000o
   if 96 - 96: i1iIIII + i111IiI1I * ooO0OO000o
   if 86 - 86: OOO0OOo
 return
 if 29 - 29: O0o - OO + OO00OooO0OO % O0o % OOOooOooo00O0
def O0OOO00 ( name , url ) :
 if 62 - 62: ii1I + o00oOO0 + I1
 if 69 - 69: o00oOO0
 if '[Youtube]' in name :
  if 63 - 63: OO / o00oOO0 * O0o . IiI11iII1
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 85 - 85: ii1I / ii1I . OO . ooO0OO000o
  try :
   OO0o = oo000 . getSetting ( 'notificar' )
   if OO0o == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oOo00OoO0O = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOo00OoO0O )
    if 67 - 67: I111I11 / iiiiiIIii . OOOooOooo00O0 . i1iIIII
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 19 - 19: i111IiI1I . o00OO0OOO0 / o00oOO0
 else :
  if 68 - 68: OOO00O / i1iIIII * o00OO00OoO / i1Iii
  if '[Team]' in name :
   if 88 - 88: iiiiiIIii
   url = url . replace ( 'https://team.com' , 'https://verystream.com' )
   if 1 - 1: i1iIIII
  if '[Realstream]' in name :
   if 48 - 48: OOO00O * o00oOO0 - OOO00O - OOOooOooo00O0 + OOOooOooo00O0
   url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
   if 40 - 40: ii1I . O0o
   if 2 - 2: I1 * i1Iii - i1Iii + i1iIIII % o00oOO0 / o00oOO0
  import resolveurl
  if 3 - 3: i1iIIII
  I111i1Ii1i1 = urlresolver . HostedMediaFile ( url )
  if 71 - 71: i111IiI1I + I1 - oO000Oo000 - ii1I . o00OO00OoO - OOO00O
  if 85 - 85: o00OO0OOO0 - o00oOO0 / o00OO0OOO0 + OOOooOooo00O0 - oO000Oo000
  if not I111i1Ii1i1 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 49 - 49: OO - ooO0OO000o / OO * o00oOO0 + IiI11iII1
  try :
   oO00o = I111i1Ii1i1 . resolve ( )
   if not oO00o or not isinstance ( oO00o , basestring ) :
    try : i11I1IiiiiiiiIi = oO00o . msg
    except : i11I1IiiiiiiiIi = url
    raise Exception ( i11I1IiiiiiiiIi )
  except Exception as OO0O00oOo :
   try : i11I1IiiiiiiiIi = str ( OO0O00oOo )
   except : i11I1IiiiiiiiIi = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 35 - 35: I111I11 . OO00OooO0OO / I1 / OO00OooO0OO * i1Iii
   if 85 - 85: I111I11 . OOO00O % OOOooOooo00O0 % o00OO00OoO
   if 80 - 80: i1Iii * o00OO00OoO / O0o % i1Iii / O0o
  OO0o = oo000 . getSetting ( 'notificar' )
  if OO0o == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 42 - 42: I1 / ii1I . iiIii * oO000Oo000 . ii1I * ooO0OO000o
   if '[Realstream]' in name :
    if 44 - 44: I1 . OO00OooO0OO / ii1I + i111IiI1I
    O0o0Oo = oo000 . getSetting ( 'restante' )
    if O0o0Oo == 'true' :
     II111 = xbmcgui . Dialog ( )
     o0o0O0O000 = II111 . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 27 - 27: OOOooOooo00O0
   oOo00OoO0O = xbmcgui . ListItem ( path = oO00o )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOo00OoO0O )
   if 52 - 52: IiI11iII1 % o00oOO0 + O0o * i1Iii . OOO0OOo
 return
def OoOooOO0oOOo0O ( ) :
 if 42 - 42: oO000Oo000 / iiiiiIIii + iiIii . iiIii % OOOooOooo00O0
 if 16 - 16: I1 + OO % o00oOO0 + OOO0OOo * iiIii
 i1o0oo0 = [ ]
 OoO0OOoO0Oo0 = sys . argv [ 2 ]
 if len ( OoO0OOoO0Oo0 ) >= 2 :
  oO00O = sys . argv [ 2 ]
  II111IiiiI1 = oO00O . replace ( '?' , '' )
  if ( oO00O [ len ( oO00O ) - 1 ] == '/' ) :
   oO00O = oO00O [ 0 : len ( oO00O ) - 2 ]
  oooOO0oo0Oo00 = II111IiiiI1 . split ( '&' )
  i1o0oo0 = { }
  for oOoO in range ( len ( oooOO0oo0Oo00 ) ) :
   iI111I1III = { }
   iI111I1III = oooOO0oo0Oo00 [ oOoO ] . split ( '=' )
   if ( len ( iI111I1III ) ) == 2 :
    i1o0oo0 [ iI111I1III [ 0 ] ] = iI111I1III [ 1 ]
 return i1o0oo0
 if 36 - 36: o00OO00OoO % OOOooOooo00O0
 if 72 - 72: OO00OooO0OO / oO000Oo000 - ooO0OO000o + o00OO00OoO
def o0iIIIIi ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  import urlresolver
  xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
  if 50 - 50: IiI11iII1 + OOO00O + oO000Oo000
def ii11iiI11I ( ) :
 II111 = xbmcgui . Dialog ( )
 list = (
 OoOooO ,
 o0oOo00
 )
 if 22 - 22: O0o + i111IiI1I + o00OO0OOO0 + IiI11iII1 - OOO0OOo
 I1IIII1i1 = II111 . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=gold]Accede a themoviedb.com[/COLOR]' ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 67 - 67: iiIii / OOO00O - i111IiI1I
 if I1IIII1i1 :
  if 74 - 74: o00OO00OoO * OOO0OOo - o00OO0OOO0 % O0o
  if I1IIII1i1 < 0 :
   return
  oOoOoO0o0 = list [ I1IIII1i1 - 2 ]
  return oOoOoO0o0 ( )
 else :
  oOoOoO0o0 = list [ I1IIII1i1 ]
  return oOoOoO0o0 ( )
 return
 if 18 - 18: OOO0OOo
def II1IIi1iII1i ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 26 - 26: ooO0OO000o
iiiIi = II1IIi1iII1i ( )
if 62 - 62: ooO0OO000o . iiIii
def OoOooO ( ) :
 if iiiIi == 'android' :
  II1111II = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  II1111II = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 33 - 33: iiIii / O0o % I1
  if 76 - 76: OOO0OOo + O0o + o00oOO0 . OO
def o0oOo00 ( ) :
 if 49 - 49: i111IiI1I / OOO00O / OOOooOooo00O0
 main ( )
 if 25 - 25: OO00OooO0OO % ooO0OO000o + I1 - OOO00O
 if 38 - 38: iiiiiIIii % IiI11iII1 + ii1I + oO000Oo000 + OOO00O / ii1I
 if 94 - 94: oO000Oo000 - iiIii + i1Iii
def O0oooOoO ( ) :
 II111 = xbmcgui . Dialog ( )
 O0Oo0 = (
 iIIIi1IiI11I1 ,
 O0Ooo000
 )
 if 36 - 36: iiIii % OOO0OOo / ii1I % IiI11iII1 + OO
 I1IIII1i1 = II111 . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 23 - 23: I111I11
 if I1IIII1i1 :
  if 93 - 93: i1Iii . o00OO00OoO / I1
  if I1IIII1i1 < 0 :
   return
  oOoOoO0o0 = O0Oo0 [ I1IIII1i1 - 2 ]
  return oOoOoO0o0 ( )
 else :
  oOoOoO0o0 = O0Oo0 [ I1IIII1i1 ]
  return oOoOoO0o0 ( )
 return
 if 50 - 50: IiI11iII1 / I1 % i1iIIII
def II1IIi1iII1i ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 83 - 83: o00OO0OOO0 * o00OO0OOO0 + OOOooOooo00O0
iiiIi = II1IIi1iII1i ( )
if 57 - 57: ooO0OO000o - ooO0OO000o . o00OO0OOO0 / iiiiiIIii / OOO0OOo
def iIIIi1IiI11I1 ( ) :
 if iiiIi == 'android' :
  II1111II = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  II1111II = webbrowser . open ( 'https://olpair.com/' )
  if 20 - 20: OOOooOooo00O0 * I111I11 - o00oOO0 - i1Iii * IiI11iII1
  if 6 - 6: OOO00O + OOOooOooo00O0 / iiIii + i111IiI1I % I111I11 / OO
def O0Ooo000 ( ) :
 if 45 - 45: i1iIIII
 main ( )
 if 9 - 9: o00OO00OoO . OO * I1 . i1iIIII
 if 32 - 32: o00oOO0 . o00OO0OOO0 % OO00OooO0OO - I111I11
def iiI111 ( name , url , id , trailer ) :
 II111 = xbmcgui . Dialog ( )
 O0Oo0 = (
 OOoooo0oo ,
 oOo0O ,
 i1i ,
 ii11iiI11I
 )
 if 60 - 60: iiIii . i111IiI1I % OO00OooO0OO - IiI11iII1
 I1IIII1i1 = II111 . select ( '[COLOR=yellow]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=yellow]Reproducir [/COLOR] [COLOR orange]' + name + '[/COLOR]' ,

 '[COLOR=yellow]Reproducir Trailer de: [/COLOR][COLOR orange]' + name + '[/COLOR]' ,

 '[COLOR=yellow]      Mas Informacion, ver trailers  [/COLOR]' ,

 '[COLOR orange]        Accede a la web MovieDB[/COLOR]' ] )
 if 79 - 79: i1iIIII / o00OO0OOO0 . ooO0OO000o
 if I1IIII1i1 :
  if 79 - 79: i1Iii - I111I11
  if I1IIII1i1 < 0 :
   return
  oOoOoO0o0 = O0Oo0 [ I1IIII1i1 - 4 ]
  return oOoOoO0o0 ( )
 else :
  oOoOoO0o0 = O0Oo0 [ I1IIII1i1 ]
  return oOoOoO0o0 ( )
 return
 if 43 - 43: I1 + ooO0OO000o % OO / OOO0OOo * OO00OooO0OO
 if 89 - 89: OO00OooO0OO . iiIii + o00OO0OOO0 . ooO0OO000o % iiiiiIIii
def OOoooo0oo ( ) :
 if 84 - 84: i1iIIII + IiI11iII1 / OO00OooO0OO % OOOooOooo00O0 % o00OO0OOO0 * OO00OooO0OO
 O0OOO00 ( iiI11ii1I1 , Ooo0OOoOoO0 )
 if 58 - 58: OO - o00oOO0 . ii1I % ii1I / I1 / i1Iii
def oOo0O ( ) :
 if 24 - 24: OO00OooO0OO * I1 % OOO00O / ooO0OO000o + ii1I
 OOoo0oOO00 ( iiI11ii1I1 , oOo0OOoO0 )
 if 12 - 12: o00OO0OOO0 / OOO0OOo
 if 5 - 5: i1iIIII
def i1i ( ) :
 if 18 - 18: OO00OooO0OO % i1iIIII - oO000Oo000 . ii1I * iiIii % OOO0OOo
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  Ii1I1O0oo00oOOO0o = id
  if 5 - 5: iiiiiIIii / OO00OooO0OO % OOO0OOo . i111IiI1I
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % Ii1I1O0oo00oOOO0o )
  if 86 - 86: I1 * o00oOO0 . ooO0OO000o - OOO0OOo - iiiiiIIii - o00oOO0
 if OO0o == 'true' :
  if 47 - 47: OOOooOooo00O0 + o00OO00OoO
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + iiI11ii1I1 + "[/COLOR] ,5000)" )
  if 50 - 50: IiI11iII1 + o00OO0OOO0
  if 4 - 4: i111IiI1I / iiIii
def I1IIiiII ( ) :
 if 59 - 59: OO - OO + oO000Oo000
 ii11iiI11I ( )
 if 32 - 32: I1 / iiIii - ooO0OO000o
 if 85 - 85: OOO0OOo - ooO0OO000o * ii1I . I1
 if 20 - 20: oO000Oo000 / OOOooOooo00O0
def Oo00o0OO0O00o ( name , url , mode , iconimage , fanart ) :
 if 28 - 28: OOO00O * o00OO00OoO % ii1I * oO000Oo000 / OOO0OOo
 iIII1iIi = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 o0o0O0O000 = True
 o000O0oo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 o000O0oo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 o000O0oo . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  iIII1iIi = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  o0o0O0O000 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iIII1iIi , listitem = o000O0oo , isFolder = True )
  return o0o0O0O000
 o0o0O0O000 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iIII1iIi , listitem = o000O0oo , isFolder = True )
 return o0o0O0O000
 if 78 - 78: OO / iiIii - O0o - ii1I * oO000Oo000
def o0OoOoo00O ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 84 - 84: OOOooOooo00O0 + OOO0OOo + iiiiiIIii
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 i1i1iIII11i = [ ]
 iIII1iIi = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 o000O0oo = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 o000O0oo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 o000O0oo . setProperty ( 'fanart_image' , fanart )
 o000O0oo . setProperty ( 'IsPlayable' , 'true' )
 if 40 - 40: O0o / o00oOO0 - ooO0OO000o * O0o
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  i1i1iIII11i . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  o000O0oo . addContextMenuItems ( i1i1iIII11i , replaceItems = True )
 o0o0O0O000 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iIII1iIi , listitem = o000O0oo )
 return o0o0O0O000
 if 56 - 56: OOOooOooo00O0
def oO00Ooo0oO ( name , url , mode , iconimage , fanart ) :
 if 49 - 49: OOO00O . I111I11
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 24 - 24: ooO0OO000o . i1iIIII - OO * i1iIIII
 iIII1iIi = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 o000O0oo = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 o000O0oo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 o000O0oo . setProperty ( 'fanart_image' , fanart )
 o000O0oo . setProperty ( 'IsPlayable' , 'true' )
 o0o0O0O000 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iIII1iIi , listitem = o000O0oo )
 return o0o0O0O000
 if 12 - 12: ooO0OO000o + i111IiI1I * I1 . OO
 if 71 - 71: IiI11iII1 - iiiiiIIii - OOOooOooo00O0
def iiI ( ) :
 if 81 - 81: i111IiI1I * o00OO0OOO0 + I111I11 % i111IiI1I
 if 46 - 46: I111I11 % oO000Oo000 - I1 / o00OO00OoO * o00oOO0
 if 92 - 92: iiIii - IiI11iII1
 o0O0o0 = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 o0O0o0 . doModal ( )
 if ( o0O0o0 . isConfirmed ( ) ) :
  if 24 - 24: i1Iii / IiI11iII1 / o00OO00OoO % o00oOO0 / o00OO0OOO0 * OOO00O
  OOoOO0o0o0 = urllib . quote_plus ( o0O0o0 . getText ( ) ) . replace ( '+' , ' ' )
  if 8 - 8: OOO0OOo
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 33 - 33: iiiiiIIii / ooO0OO000o + OOOooOooo00O0
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % OOoOO0o0o0 )
    if 75 - 75: i111IiI1I % ii1I + O0o
    if OO0o == 'true' :
     if 92 - 92: o00oOO0 % ooO0OO000o
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + iiI11ii1I1 + "[/COLOR] ,10000)" )
     if 55 - 55: O0o * oO000Oo000
   except :
    if 85 - 85: O0o . I111I11
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 54 - 54: OOO0OOo . i1iIIII % iiIii
    if 22 - 22: OOOooOooo00O0
    if 22 - 22: oO000Oo000 * o00OO00OoO - iiIii * ooO0OO000o / ii1I
oO00O = OoOooOO0oOOo0O ( )
Ooo0OOoOoO0 = None
iiI11ii1I1 = None
OOooO0Oo0o000 = None
OOOo = None
id = None
oOo0OOoO0 = None
if 17 - 17: O0o + OO00OooO0OO
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 57 - 57: iiiiiIIii / IiI11iII1
try :
 Ooo0OOoOoO0 = urllib . unquote_plus ( oO00O [ "url" ] )
except :
 pass
try :
 iiI11ii1I1 = urllib . unquote_plus ( oO00O [ "name" ] )
except :
 pass
try :
 OOooO0Oo0o000 = int ( oO00O [ "mode" ] )
except :
 pass
try :
 OOOo = urllib . unquote_plus ( oO00O [ "iconimage" ] )
except :
 pass
try :
 id = int ( oO00O [ "id" ] )
except :
 pass
try :
 oOo0OOoO0 = urllib . unquote_plus ( oO00O [ "trailer" ] )
except :
 pass
 if 13 - 13: i1iIIII + OO
 if 32 - 32: ooO0OO000o + i1Iii % iiIii
print "Mode: " + str ( OOooO0Oo0o000 )
print "URL: " + str ( Ooo0OOoOoO0 )
print "Name: " + str ( iiI11ii1I1 )
print "iconimage: " + str ( OOOo )
print "id: " + str ( id )
print "trailer: " + str ( oOo0OOoO0 )
if 7 - 7: o00OO0OOO0 / OOO00O
if OOooO0Oo0o000 == None or Ooo0OOoOoO0 == None or len ( Ooo0OOoOoO0 ) < 1 :
 if ooooooO0oo == IIiiiiiiIi1I1 :
  if 11 - 11: i111IiI1I * OOO00O / OOO00O - OOOooOooo00O0
  i1I1i111Ii ( )
  Oo00OOOOO = oo000 . getSetting ( 'aviso' )
  if Oo00OOOOO == 'true' :
   Ii1Iii1iIi ( )
   if 68 - 68: OO00OooO0OO % i111IiI1I - i111IiI1I / OO00OooO0OO + o00OO0OOO0 - iiIii
   if 65 - 65: OOO00O - I1
  II11iiii1Ii = oo000 . getSetting ( 'licencia_addon' )
  O0ii1ii1ii = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  O00Oo = oo000 . getSetting ( 'key_ext' )
  oooooOoo0ooo = 'aHR0cDovL2JpdC5seS8yUjQxbmh1' . decode ( 'base64' )
  iIi1ii = oOOOoo0O0oO ( oooooOoo0ooo )
  iIII1I111III = re . compile ( o000O0o ) . findall ( iIi1ii )
  for iiiO0ooO0O0Ooo0o in iIII1I111III :
   try :
    if 25 - 25: OOOooOooo00O0 * OOOooOooo00O0 / i1Iii % iiIii
    if 33 - 33: i111IiI1I . i1iIIII . i1Iii
    II11iiii1Ii = oo000 . getSetting ( 'licencia_addon' )
    if 15 - 15: o00OO0OOO0 . oO000Oo000
    if 94 - 94: o00OO00OoO . OO00OooO0OO
    if II11iiii1Ii == iiiO0ooO0O0Ooo0o :
     if 73 - 73: I1 / I111I11
     xbmcgui . Dialog ( ) . ok ( "Realstream Licencia:" , "[COLOR lime]Su licencia es correcta.[/COLOR] [COLOR gold]Sientese y disfrute de Realstream.[/COLOR]" )
     if 45 - 45: OOO0OOo / OOO00O . i1iIIII + OO
     iiIiIi ( )
     if 51 - 51: oO000Oo000 % ii1I % i111IiI1I + IiI11iII1 % o00OO0OOO0
    else :
     if 16 - 16: o00oOO0 / iiIii + ooO0OO000o - o00oOO0 . i1iIIII
     xbmcgui . Dialog ( ) . ok ( "Realstream Licencia:" , "[COLOR red]Su licencia ha caducado, o no ha introducido una licencia valida.[/COLOR] [COLOR gold]Ponganse en contacto con nosotros en nuestro grupo de telegram.[/COLOR]" )
     if 19 - 19: iiiiiIIii
     if 73 - 73: IiI11iII1 * iiIii * o00oOO0
   except :
    pass
    if 65 - 65: ii1I + iiIii * i1iIIII - OO
 else :
  xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red][B]Error, de inicio. ¿Tienes Instalado Realstream?[/B][/COLOR]" )
  if 26 - 26: iiiiiIIii % OOOooOooo00O0 + OOOooOooo00O0 % o00OO00OoO * ii1I / oO000Oo000
  if 64 - 64: i1Iii % o00oOO0 / I111I11 % OOO00O - oO000Oo000
elif OOooO0Oo0o000 == 1 :
 iiI111 ( iiI11ii1I1 , Ooo0OOoOoO0 , id , oOo0OOoO0 )
elif OOooO0Oo0o000 == 2 :
 oooO0 ( )
elif OOooO0Oo0o000 == 3 :
 oOOOoo ( )
elif OOooO0Oo0o000 == 4 :
 oO0O0oO ( iiI11ii1I1 , Ooo0OOoOoO0 )
elif OOooO0Oo0o000 == 5 :
 Ooooo00o0OoO ( )
elif OOooO0Oo0o000 == 6 :
 O0Oo00 ( )
elif OOooO0Oo0o000 == 7 :
 ii1i1i1IiII ( )
elif OOooO0Oo0o000 == 8 :
 OOo00 ( )
elif OOooO0Oo0o000 == 9 :
 O00o00O ( )
elif OOooO0Oo0o000 == 10 :
 Oo00OOo00O ( )
elif OOooO0Oo0o000 == 11 :
 IiIIiIIIiIii ( )
elif OOooO0Oo0o000 == 12 :
 o00O ( )
elif OOooO0Oo0o000 == 13 :
 i1IiiI1iIi ( )
elif OOooO0Oo0o000 == 14 :
 I1ii1Ii1ii11i ( )
elif OOooO0Oo0o000 == 15 :
 i1I11iIII1i1I ( )
elif OOooO0Oo0o000 == 16 :
 Ooooo0OoO0 ( )
elif OOooO0Oo0o000 == 17 :
 i11ii ( )
elif OOooO0Oo0o000 == 18 :
 iIIi1iiI1i11 ( )
elif OOooO0Oo0o000 == 19 :
 iIIi1iI1I1IIi ( )
elif OOooO0Oo0o000 == 20 :
 I1i1I ( )
elif OOooO0Oo0o000 == 21 :
 Oooo00oOo ( )
elif OOooO0Oo0o000 == 22 :
 oo0O0o00 ( )
elif OOooO0Oo0o000 == 23 :
 ooOo0O0O0oOO0 ( )
elif OOooO0Oo0o000 == 24 :
 Ii1I1 ( )
elif OOooO0Oo0o000 == 25 :
 IIiI1i ( )
elif OOooO0Oo0o000 == 26 :
 Oo0000oOo ( )
elif OOooO0Oo0o000 == 98 :
 busqueda_global ( )
elif OOooO0Oo0o000 == 97 :
 O0oooOoO ( )
elif OOooO0Oo0o000 == 99 :
 oO0oO0 ( )
elif OOooO0Oo0o000 == 100 :
 menu_player ( iiI11ii1I1 , Ooo0OOoOoO0 )
elif OOooO0Oo0o000 == 111 :
 II1I1iiIII ( )
elif OOooO0Oo0o000 == 115 :
 OOoo0oOO00 ( Ooo0OOoOoO0 )
elif OOooO0Oo0o000 == 116 :
 I1I1i ( )
elif OOooO0Oo0o000 == 119 :
 I1iIi1iIiiIiI ( )
elif OOooO0Oo0o000 == 120 :
 i111iI ( )
elif OOooO0Oo0o000 == 121 :
 Oo000ooOOO ( )
elif OOooO0Oo0o000 == 125 :
 I1IiiiIIIi1i ( )
elif OOooO0Oo0o000 == 126 :
 torrentPro ( )
elif OOooO0Oo0o000 == 127 :
 iiI ( )
elif OOooO0Oo0o000 == 128 :
 TESTLINKS ( )
elif OOooO0Oo0o000 == 140 :
 I1iii11 ( )
 if 2 - 2: IiI11iII1 - o00OO0OOO0 + iiiiiIIii * OO / oO000Oo000
xbmcplugin . endOfDirectory ( oOOo ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
