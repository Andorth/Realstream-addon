# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 1.54
#
############################################
# Dependencias 
# Script ExtendedInfo
# Script ResolveURL Por Jsergio.
############################################
#
# Agregado multi enlace de servidores.
# Agregado sistema individual de usuarios.
# Agregadas categorias de peliculas.
#
############################################
if 64 - 64: i11iIiiIii
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import resolveurl
import cookielib , base64
import requests
import plugintools
import config
import codecs
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
o0OO00 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
oo = o0OO00 . getAddonInfo ( 'version' )
i1iII1IiiIiI1 = int ( sys . argv [ 1 ] )
iIiiiI1IiI1I1 = 'gruponetai/'
o0OoOoOO00 = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
I11i = o0OoOoOO00 . getAddonInfo ( 'profile' )
O0O = o0OoOoOO00 . getAddonInfo ( 'path' )
Oo = o0OO00 . getSetting ( 'iconos' )
if 2 - 2: o0 * i1 * ii1IiI1i % OOooOOo / I11iIi1I / IiiIII111iI
if 34 - 34: iii1I1I / O00oOoOoO0o0O . O0oo0OO0 + Oo0ooO0oo0oO . I1i1iI1i - II
if Oo == 'true' :
 if 100 - 100: i11Ii11I1Ii1i . ooO - OOoO / II * OOooOOo . o0
 Ii1IIii11 = xbmc . translatePath ( os . path . join ( O0O , 'fanart.png' ) )
 Oooo0000 = xbmc . translatePath ( os . path . join ( O0O , 'icon.png' ) )
 i11 = xbmc . translatePath ( os . path . join ( O0O , 'extended_info.png' ) )
 I11 = xbmc . translatePath ( os . path . join ( O0O , 'buscar.png' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( O0O , 'pair.png' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( O0O , 'theMovieDB.png' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( O0O , 'novedades.png' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( O0O , 'estrenos.png' ) )
 oO = xbmc . translatePath ( os . path . join ( O0O , 'recomendadas.png' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( O0O , 'accion.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( O0O , 'animacion.png' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( O0O , 'aventuras.png' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( O0O , 'belico.png' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( O0O , 'ciencia-ficcion.png' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( O0O , 'clasicos.png' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( O0O , 'comedia.png' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( O0O , 'crimen.png' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( O0O , 'drama.png' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( O0O , 'familiar.png' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( O0O , 'fantasia.png' ) )
 IIooOoOoo0O = xbmc . translatePath ( os . path . join ( O0O , 'historia.png' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( O0O , 'marvel.png' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( O0O , 'misterio.png' ) )
 OO0o = xbmc . translatePath ( os . path . join ( O0O , 'musical.png' ) )
 Ooo = xbmc . translatePath ( os . path . join ( O0O , 'romance.png' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( O0O , 'spain.png' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( O0O , 'suspense.png' ) )
 O0OO00o0OO = xbmc . translatePath ( os . path . join ( O0O , 'terror.png' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( O0O , 'thriller.png' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( O0O , 'western.png' ) )
 o0I11II1i = xbmc . translatePath ( os . path . join ( O0O , 'sagas_cine.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( O0O , '4k.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( O0O , 'torrent.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( O0O , 'buscar-serie.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( O0O , 'series-todas.png' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( O0O , 'favorites.png' ) )
 OOOO = xbmc . translatePath ( os . path . join ( O0O , 'artesmarciales.png' ) )
 OOO00 = xbmc . translatePath ( os . path . join ( O0O , 'emision.png' ) )
 iiiiiIIii = xbmc . translatePath ( os . path . join ( O0O , 'mejores.png' ) )
 O000OO0 = xbmc . translatePath ( os . path . join ( O0O , 'seriesretro.png' ) )
 I11iii1Ii = xbmc . translatePath ( os . path . join ( O0O , 'BuscadorPeliculas.png' ) )
 I1IIiiIiii = xbmc . translatePath ( os . path . join ( O0O , 'BuscadorSeries.png' ) )
 O000oo0O = xbmc . translatePath ( os . path . join ( O0O , 'Novedades_series.png' ) )
 OOOOi11i1 = xbmc . translatePath ( os . path . join ( O0O , 'Novedades_Episodios.png' ) )
 if 29 - 29: iii1I1I % i1 + OOoO / IiiIII111iI + O0oo0OO0 * IiiIII111iI
else :
 if 42 - 42: I1i1iI1i + O00oOoOoO0o0O
 if 76 - 76: ooO - OOooOOo
 OOOO = xbmc . translatePath ( os . path . join ( O0O , 'artesmarciales.png' ) )
 O000OO0 = xbmc . translatePath ( os . path . join ( O0O , 'seriesretro.png' ) )
 Oo = o0OO00 . getSetting ( 'iconos' )
 Ii1IIii11 = xbmc . translatePath ( os . path . join ( O0O , 'fanart.jpg' ) )
 Oooo0000 = xbmc . translatePath ( os . path . join ( O0O , 'icon.png' ) )
 i11 = xbmc . translatePath ( os . path . join ( O0O , 'extended_info.png' ) )
 I11 = xbmc . translatePath ( os . path . join ( O0O , 'buscar.png' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( O0O , 'pair.png' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( O0O , 'theMovieDB.jpg' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( O0O , 'novedades.jpg' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( O0O , 'encines.jpg' ) )
 oO = xbmc . translatePath ( os . path . join ( O0O , 'recomendadas.jpg' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( O0O , 'accion.jpg' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( O0O , 'animacion.jpg' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( O0O , 'aventuras.jpg' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( O0O , 'belico.jpg' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( O0O , 'ciencia-ficcion.jpg' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( O0O , 'clasicos.png' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( O0O , 'comedia.jpg' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( O0O , 'crimen.jpg' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( O0O , 'drama.jpg' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( O0O , 'familiar.jpg' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( O0O , 'fantasia.jpg' ) )
 IIooOoOoo0O = xbmc . translatePath ( os . path . join ( O0O , 'historia.jpg' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( O0O , 'superheroes.jpg' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( O0O , 'misterio.jpg' ) )
 OO0o = xbmc . translatePath ( os . path . join ( O0O , 'musical.jpg' ) )
 Ooo = xbmc . translatePath ( os . path . join ( O0O , 'romance.jpg' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( O0O , 'spain.jpg' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( O0O , 'suspense.jpg' ) )
 O0OO00o0OO = xbmc . translatePath ( os . path . join ( O0O , 'terror.jpg' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( O0O , 'thriller.jpg' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( O0O , 'western.jpg' ) )
 o0I11II1i = xbmc . translatePath ( os . path . join ( O0O , 'sagas_cine.jpg' ) )
 IIIII = xbmc . translatePath ( os . path . join ( O0O , '4k.jpg' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( O0O , 'torrent.jpg' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( O0O , 'buscar-serie.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( O0O , 'series-todas.png' ) )
 OOO00 = xbmc . translatePath ( os . path . join ( O0O , 'emision.png' ) )
 iiiiiIIii = xbmc . translatePath ( os . path . join ( O0O , 'mejores.png' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( O0O , 'favoritos.png' ) )
 I11iii1Ii = xbmc . translatePath ( os . path . join ( O0O , 'BuscadorPeliculas.png' ) )
 I1IIiiIiii = xbmc . translatePath ( os . path . join ( O0O , 'BuscadorSeries.png' ) )
 O000oo0O = xbmc . translatePath ( os . path . join ( O0O , 'Novedades_series.png' ) )
 OOOOi11i1 = xbmc . translatePath ( os . path . join ( O0O , 'Novedades_Episodios.png' ) )
 if 70 - 70: OOoO
 if 61 - 61: iii1I1I . iii1I1I
 if 10 - 10: I11iIi1I * II . Oo0ooO0oo0oO + o0 - OOoO * i1IIi
oO00o0O0O0ooO = xbmc . translatePath ( os . path . join ( O0O , 'peliculas.png' ) )
oOO = xbmc . translatePath ( os . path . join ( O0O , 'series.png' ) )
Ooo0Oo0 = xbmc . translatePath ( os . path . join ( O0O , 'ajustes.png' ) )
I1II11IiII = xbmc . translatePath ( os . path . join ( O0O , 'videoteca.png' ) )
OOO0OOo = xbmc . translatePath ( os . path . join ( O0O , 'favorites.png' ) )
I1I111 = xbmc . translatePath ( os . path . join ( O0O , 'resolver.png' ) )
i11iiI111I = xbmc . translatePath ( os . path . join ( O0O , 'test.png' ) )
II11i1iIiII1 = xbmc . translatePath ( os . path . join ( O0O , 'video-tutoriales.png' ) )
iIi1iIiii111 = xbmc . translatePath ( os . path . join ( O0O , 'proxy.png' ) )
if 16 - 16: iii1I1I + OOooOOo - o0
if 85 - 85: I11iIi1I + i1IIi
if 58 - 58: o0 * O0oo0OO0 * iii1I1I / O0oo0OO0
oO0o0OOOO = o0OO00 . getSetting ( 'MenuColor' )
O0O0OoOO0 = o0OO00 . getSetting ( 'usuario' )
iiiI1I11i1 = o0OO00 . getSetting ( 'mail' )
IIi1i11111 = o0OO00 . getSetting ( 'claves' )
ooOO00O00oo = o0OO00 . getSetting ( 'mostrar_cat' )
I1ii11iI = o0OO00 . getSetting ( 'sel_tobox' )
IIi1i = o0OO00 . getSetting ( 'videos' )
I1I1iIiII1 = o0OO00 . getSetting ( 'activar' )
i11i1I1 = o0OO00 . getSetting ( 'favcopy' )
ii1I = o0OO00 . getSetting ( 'anticopia' )
Oo0ooOo0o = o0OO00 . getSetting ( 'licencia_addon' )
Ii1i1 = o0OO00 . getSetting ( 'notificar' )
iiIii = o0OO00 . getSetting ( 'mostrar_bus' )
ooo0O = o0OO00 . getSetting ( 'restante' )
oOoO0o00OO0 = o0OO00 . getSetting ( 'selecton' )
i1I1ii = o0OO00 . getSetting ( 'aviso' )
oOOo0 = o0OO00 . getSetting ( 'RealStream_Settings' )
oo00O00oO = o0OO00 . getSetting ( 'Resolver_Settings' )
ooo0O = o0OO00 . getSetting ( 'restante' )
iIiIIIi = o0OO00 . getSetting ( 'fav' )
ooo00OOOooO = o0OO00 . getSetting ( 'Fontcolor' )
oO0o0OOOO = o0OO00 . getSetting ( 'MenuColor' )
O00OOOoOoo0O = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( '\x62\x61\x73\x65\x36\x34' )
O000OOo00oo = 'bienvenida'
oo0OOo = 'bienvenida'
copyright = o0OO00 . getSetting ( 'copyright' )
ooOOO00Ooo = 'cGx1Z2luLnZpZGVvLg==' . decode ( '\x62\x61\x73\x65\x36\x34' ) + copyright
IiIIIi1iIi = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( '\x62\x61\x73\x65\x36\x34' )
ooOOoooooo = o0OO00 . getSetting ( 'Forceupdate' )
if ooOOoooooo == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
II1I = 'LnR4dA==' . decode ( '\x62\x61\x73\x65\x36\x34' )
O0i1II1Iiii1I11 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1NQOUpRZExS' . decode ( '\x62\x61\x73\x65\x36\x34' )
if 9 - 9: iii1I1I / ii1IiI1i - i1 / OoooooooOO / iIii1I11I1II1 - IiiIII111iI
if 91 - 91: II % i1IIi % iIii1I11I1II1
IIi1I11I1II = 'aHR0cDovL2JpdC5seS8yU1FOSnlP' . decode ( '\x62\x61\x73\x65\x36\x34' )
OooOoooOo = O00OOOoOoo0O + O000OOo00oo + II1I
ii11IIII11I = 'http://www.youtube.com'
OOooo = 'aHR0cDovL3kzei5zag==' . decode ( '\x62\x61\x73\x65\x36\x34' )
oOooOOOoOo = 'http://bit.ly/2ImelUx'
i1Iii1i1I = '.xsl.pt'
OOoO00 = 'L21hc3Rlci8=' . decode ( '\x62\x61\x73\x65\x36\x34' )
IiI111111IIII = OOooo + i1Iii1i1I
i1Ii = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*'
ii111iI1iIi1 = 'tvg-logo=[\'"](.*?)[\'"]'
if 78 - 78: OOooOOo . O0oo0OO0 + OOooOOo / Oo0ooO0oo0oO / OOooOOo
oO0O00OoOO0 = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.*)'
OoO = '(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)'
O00 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
I1iI1 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
iiiIi1 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
i1I1ii11i1Iii = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
I1IiiiiI = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.+)\s*'
o0O = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
IiII = '#(.+?),(.+)\s*(.+)'
ii1iII1II = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
Iii1I1I11iiI1 = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
I1I1i1I = '[\'"](.*?)[\'"]'
ii1IO0oO0 = r'066">\s*(.+)</f'
oO0 = '[\'"](.*?)[\'"]'
O0OO0O = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
OO = '[\'"](.*?)[\'"]'
OoOoO = 'src":"(.*?)"label":"(.*?)"lang":"(.*?)"'
Ii1I1i = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1NQOUpRZExS' . decode ( '\x62\x61\x73\x65\x36\x34' )
OOI1iI1ii1II = '[\'"](.*?)[\'"]'
O0O0OOOOoo = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( '\x62\x61\x73\x65\x36\x34' )
oOooO0 = O0O0OOOOoo + iIiiiI1IiI1I1
Ii1I1Ii = '(.+),(.+),(.*)\s*'
OOoO0 = '[\'"](.*?)[\'"]'
OO0Oooo0oOO0O = 'UmVhbHN0cmVhbQ==' . decode ( '\x62\x61\x73\x65\x36\x34' )
o00O0 = 'video=[\'"](.*?)[\'"]'
oOO0O00Oo0O0o = '0110nhu' . replace ( '0110nhu' , 'nhu' )
ii1 = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( '\x62\x61\x73\x65\x36\x34' ) + oOO0O00Oo0O0o
I1iIIiiIIi1i = codecs . decode ( "5573756172696F732F5564622E747874" , "\x68\x65\x78" ) . decode ( 'utf-8' )
O0O0ooOOO = 'aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtLw==' . decode ( '\x62\x61\x73\x65\x36\x34' ) + I1iIIiiIIi1i
oOOo0O00o = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( '\x62\x61\x73\x65\x36\x34' )
iIiIi11 = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( '\x62\x61\x73\x65\x36\x34' )
OOO = 'aHR0cHM6Ly9uZXRhaS5ldS92aXNpdGFzL2luZGV4LnBocA==' . decode ( '\x62\x61\x73\x65\x36\x34' )
ooOOO00Ooo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( '\x62\x61\x73\x65\x36\x34' )
if 32 - 32: i1IIi / o0 . ii1IiI1i
if 62 - 62: OoooooooOO * i1
if 58 - 58: I11iIi1I % IiiIII111iI
exec codecs . decode ( "64627365726965203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C304656526C42614D326875272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A6462747365726965203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C315672526E49355247526E272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C78333427290D0A6462657365726965203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C327442566C453355445232272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A6462727365726965203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C314E7A4D584E7752476842272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C783334272920200D0A64626E7365726965203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C30784B533164694D46424C272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C78333427292020" , "\x68\x65\x78" ) . decode ( 'utf-8' )
if 50 - 50: ooO . IiiIII111iI
if 97 - 97: O0 + I11iIi1I
if 89 - 89: IiiIII111iI + OOooOOo * Oo0ooO0oo0oO * I1i1iI1i
exec codecs . decode ( "646270656C6963756C61203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C3074705A48424B59325A47272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A64626E6F76656461646573203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C7A4A4D5230687553485A43272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A646265737472656E6F73203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C316335593046315A556442272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A64626770656C6973203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C7A64514E55703151317078272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A646266616D696C696172203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C326456656D747753326C6A272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A646273757065726865726F6573203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C3064796146703363485A52272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A50346B203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C7A4D78526E4A7A5A6B6457272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C783334272920" , "\x68\x65\x78" ) . decode ( 'utf-8' )
if 37 - 37: OoooooooOO - O0 - IiiIII111iI
def o0o0O0O00oOOo ( ) :
 if 14 - 14: I11iIi1I + O00oOoOoO0o0O
 if 52 - 52: OoooooooOO - OOoO
 try :
  o0O0o0 = II111iI111I1I ( todas )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for I1111i in I1i1i1iii :
   try :
    if 14 - 14: O0oo0OO0 / IiiIII111iI
    iII11I1IiiIi = I1111i
    if 98 - 98: i1IIi / Oo0ooO0oo0oO
    i1ii1I1111ii1 = xbmc . Keyboard ( '' , 'Busqueda por titulo' )
    i1ii1I1111ii1 . doModal ( )
    if ( i1ii1I1111ii1 . isConfirmed ( ) ) :
     iIiI1 = xbmcgui . DialogProgress ( )
     iIiI1 . create ( 'Realstream:' , 'Buscando ...' )
     oOo0OOoO0 = range ( 0 , 76 )
     for IIo0Oo0oO0oOO00 in oOo0OOoO0 :
      IIo0Oo0oO0oOO00 = IIo0Oo0oO0oOO00 + 1
      if 92 - 92: OoooooooOO * ooO
     o0000oO = urllib . quote_plus ( i1ii1I1111ii1 . getText ( ) ) . replace ( '+' , ' ' )
     I1II1 = II111iI111I1I ( iII11I1IiiIi )
     I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( I1II1 )
     for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
      if 61 - 61: I11iIi1I - O0oo0OO0 - i1IIi
      iIiI1 . update ( IIo0Oo0oO0oOO00 , '[COLOR orange]Realstream: Buscando ...[/COLOR]' , ' [COLOR yellow] %s [/COLOR]' % i1I1i111Ii )
      xbmc . sleep ( 1 )
      if iIiI1 . iscanceled ( ) : break ;
      if re . search ( o0000oO , IiI1iIiIIIii ( i1I1i111Ii . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       if 53 - 53: i1IIi
       iIiI1 . update ( 80 , ' [COLOR orange]Busqueda finalizada[/COLOR] ' )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR gold]Generando listado ...  [/COLOR][COLOR orange] Por favor espere ![/COLOR] ,1000)" )
       iIiI1 . update ( 100 , '[COLOR orange]Realstream: [/COLOR]' , '[COLOR gold] Busqueda finalizada ...[/COLOR]' )
       iIiI1 . close ( )
       o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
       if 73 - 73: Oo0ooO0oo0oO % i11iIiiIii - i1
       if 7 - 7: O0 * i11iIiiIii * I1i1iI1i + OOoO % OOooOOo - OOoO
     II1IIIIiII1i ( '[COLOR %s]Buscar Pelicula[/COLOR]' % oO0o0OOOO , 'search' , 111 , I11iii1Ii , Ii1IIii11 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Resultados para: [COLOR orange]" + o0000oO + "[/COLOR] ,2000)" )
     if 1 - 1: o0
   except : II1IIIIiII1i ( '[COLOR %s]Buscar Pelicula[/COLOR]' % oO0o0OOOO , 'search' , 111 , I11iii1Ii , Ii1IIii11 )
   if 68 - 68: II - i1 / ooO / Oo0ooO0oo0oO
 except :
  pass
  if 12 - 12: I1i1iI1i + i11iIiiIii * iIii1I11I1II1 / iii1I1I . Oo0ooO0oo0oO
def Iii1iI ( ) :
 if 29 - 29: i1 % O0oo0OO0 - i1 / O0oo0OO0 . i1IIi
 i1I1ii = o0OO00 . getSetting ( 'aviso' )
 if 31 - 31: ooO
 if i1I1ii == 'true' :
  if 88 - 88: OOooOOo - OOoO + O0oo0OO0 * i1 % iIii1I11I1II1 + ii1IiI1i
  try :
   o0O0o0 = II111iI111I1I ( OooOoooOo )
   I1i1i1iii = re . compile ( i1Ii ) . findall ( o0O0o0 )
   for oo000O0OoooO , O0o in I1i1i1iii :
    try :
     if 27 - 27: i11Ii11I1Ii1i - I1i1iI1i / iii1I1I % i11Ii11I1Ii1i + i1
     if 96 - 96: ooO
     oOoOo0O0OOOoO = oo000O0OoooO
     iI11IIIiii1II = O0o
     if 16 - 16: II + I11iIi1I
     if 66 - 66: II / O00oOoOoO0o0O * OoooooooOO + OoooooooOO % Oo0ooO0oo0oO
     from datetime import datetime
     if 49 - 49: O00oOoOoO0o0O - i11iIiiIii . ooO * I1i1iI1i % II + i1IIi
     oOO0OOOo = datetime . now ( )
     oo0o0000 = oOO0OOOo . strftime ( '%d/%m/%Y' )
     oo = o0OO00 . getAddonInfo ( 'version' )
     if 11 - 11: iIii1I11I1II1
     if 20 - 20: o0 % ii1IiI1i + iii1I1I + OOoO
     if 23 - 23: O0oo0OO0 * I1i1iI1i * ii1IiI1i . O0 - i11iIiiIii
     if 18 - 18: I1i1iI1i + i11Ii11I1Ii1i - O0
     if 53 - 53: i1IIi
     Ooo00Oo = "[B]" + oOoOo0O0OOOoO + "[/B]"
     oO00Oooo0O0o0 = "" + iI11IIIiii1II + ""
     II1iI1I11I = "[COLOR white]Hoy es: " + oo0o0000 + ", Su version instalada es:[/COLOR][COLOR gold] " + oo + "[/COLOR]"
     if 78 - 78: o0
     xbmcgui . Dialog ( ) . ok ( "Real Stream" , Ooo00Oo , oO00Oooo0O0o0 , II1iI1I11I )
    except :
     pass
     if 100 - 100: ooO + O0oo0OO0 + O0oo0OO0
  except :
   pass
   if 9 - 9: Oo0ooO0oo0oO % OoooooooOO . O00oOoOoO0o0O % Oo0ooO0oo0oO
  try :
   I1II1 = II111iI111I1I ( iIiIi11 )
   I1i1i1iii = re . compile ( I1I1i1I ) . findall ( I1II1 )
   for ii in I1i1i1iii :
    if 36 - 36: OoooooooOO . OOooOOo
    import xbmc
    import xbmcaddon
    if 56 - 56: ii1IiI1i . iii1I1I . i1
    __addon__ = xbmcaddon . Addon ( )
    __addonname__ = __addon__ . getAddonInfo ( 'name' )
    __icon__ = __addon__ . getAddonInfo ( 'icon' )
    if 39 - 39: O0 + ooO
    oo = o0OO00 . getAddonInfo ( 'version' )
    OoOooOoO = ii
    if 43 - 43: o0 . O00oOoOoO0o0O / iii1I1I
    Ooo00Oo = "[COLOR orange] Ultima version: [/COLOR][COLOR white] [B]" + ii + " [/B][/COLOR]"
    i1iI1 = 4000
    xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , Ooo00Oo , i1iI1 , __icon__ ) )
    if 33 - 33: i11Ii11I1Ii1i % iIii1I11I1II1 * i1
    if oo < ii :
     if 95 - 95: OOoO / OOoO
     xbmcgui . Dialog ( ) . ok ( "Real Stream" , "[COLOR white] Existe una nueva version de [/COLOR][COLOR fuchsia]Realstream[/COLOR]" , "[COLOR orange]Actualimete tiene instalada la version[/COLOR] [COLOR white][B] %s [/B][/COLOR]" % oo , " [COLOR white]Ya esta disponible la[/COLOR] [COLOR gold][B] %s [/B][/COLOR]" % ii )
     if 30 - 30: iii1I1I + ii1IiI1i / ii1IiI1i % iii1I1I . iii1I1I
     if 55 - 55: OOoO - Oo0ooO0oo0oO + o0 + II % I1i1iI1i
  except :
   pass
   if 41 - 41: i1IIi - Oo0ooO0oo0oO - I1i1iI1i
   if 8 - 8: OOooOOo + ooO - IiiIII111iI % ii1IiI1i % IiiIII111iI * O00oOoOoO0o0O
   if 9 - 9: ii1IiI1i - i11iIiiIii - O0oo0OO0 * I1i1iI1i + OOoO
   if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 44 - 44: o0
    if 52 - 52: iii1I1I - ii1IiI1i + iii1I1I % IiiIII111iI
    if 35 - 35: iIii1I11I1II1
def IiI1iIiIIIii ( s ) :
 if 42 - 42: ooO . i1 . i1IIi + I11iIi1I + O0oo0OO0 + i1
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 31 - 31: II . O0oo0OO0 - OOoO . OoooooooOO / OoooooooOO
def OOoOiiII1i11i ( file ) :
 if 11 - 11: i1 / o0 + IiiIII111iI * iii1I1I - iii1I1I - i1
 try :
  O0oOooooo0O = open ( file , 'r' )
  o0O0o0 = O0oOooooo0O . read ( )
  O0oOooooo0O . close ( )
  return o0O0o0
 except :
  pass
  if 42 - 42: ii1IiI1i
def II111iI111I1I ( url ) :
 if 19 - 19: O00oOoOoO0o0O % iii1I1I * iIii1I11I1II1 + i1
 try :
  iii11I = urllib2 . Request ( url )
  iii11I . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  I1Iii1 = urllib2 . urlopen ( iii11I )
  iiI11Iii = I1Iii1 . read ( )
  I1Iii1 . close ( )
  return iiI11Iii
 except urllib2 . URLError , O0o0O0 :
  print 'We failed to open "%s".' % url
  if hasattr ( O0o0O0 , 'code' ) :
   print 'We failed with error code - %s.' % O0o0O0 . code
  if hasattr ( O0o0O0 , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , O0o0O0 . reason
   if 11 - 11: o0 % OOooOOo * II + OOoO + I1i1iI1i
def II1Iiiiii ( url ) :
 iii11I = urllib2 . Request ( url )
 iii11I . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 iii11I . add_header ( 'Referer' , '%s' % url )
 iii11I . add_header ( 'Connection' , 'keep-alive' )
 I1Iii1 = urllib2 . urlopen ( iii11I )
 iiI11Iii = I1Iii1 . read ( )
 I1Iii1 . close ( )
 return iiI11Iii
 if 36 - 36: i1 - Oo0ooO0oo0oO
 if 29 - 29: OOoO * O0oo0OO0
 if 10 - 10: ooO % i11Ii11I1Ii1i * i11Ii11I1Ii1i . Oo0ooO0oo0oO / I1i1iI1i % O0oo0OO0
def IIII1 ( ) :
 if 10 - 10: ooO / OOoO + i11iIiiIii / I1i1iI1i
 oO0o0OOOO = o0OO00 . getSetting ( 'MenuColor' )
 if 74 - 74: O0oo0OO0 + O0 + i1IIi - i1IIi + o0
 if I1I1iIiII1 == 'true' :
  if 83 - 83: iii1I1I - i1 + O0oo0OO0
  if 5 - 5: I1i1iI1i
  try :
   if 46 - 46: i11Ii11I1Ii1i
   O0O0OoOO0 = o0OO00 . getSetting ( 'usuario' )
   iiiI1I11i1 = o0OO00 . getSetting ( 'mail' )
   IIi1i11111 = o0OO00 . getSetting ( 'claves' )
   if 45 - 45: OOoO
   IIi = II111iI111I1I ( O0O0ooOOO )
   I1i1i1iii = re . compile ( Ii1I1Ii ) . findall ( IIi )
   for ooO0oOo0o , OOii111IiiI1 , ii11i1iIiII1 in I1i1i1iii :
    if re . search ( IIi1i11111 , ii11i1iIiII1 ) :
     if 63 - 63: OOooOOo
     if O0O0OoOO0 == ooO0oOo0o and iiiI1I11i1 == OOii111IiiI1 and IIi1i11111 == ii11i1iIiII1 :
      xbmc . sleep ( 3000 )
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR orange]Bienvenido![/COLOR][COLOR white] " + ooO0oOo0o + "[/COLOR] ,3000)" )
      II1IIIIiII1i ( '[COLOR %s]Buscar Serie[/COLOR]' % oO0o0OOOO , 'search' , 145 , I1IIiiIiii , Ii1IIii11 )
      II1IIIIiII1i ( '[COLOR %s]Series[/COLOR] ' % oO0o0OOOO , 'movieDB' , 117 , oOO , Ii1IIii11 )
      II1IIIIiII1i ( '[COLOR %s]Buscar Pelicula[/COLOR]' % oO0o0OOOO , 'search' , 146 , I11iii1Ii , Ii1IIii11 )
      II1IIIIiII1i ( '[COLOR %s]Peliculas[/COLOR] ' % oO0o0OOOO , 'movieDB' , 116 , oO00o0O0O0ooO , Ii1IIii11 )
      if 69 - 69: iIii1I11I1II1 . iii1I1I % OOoO + iIii1I11I1II1 / O0 / iii1I1I
  except :
   pass
   if 61 - 61: O0oo0OO0 % O0oo0OO0 * IiiIII111iI / IiiIII111iI
 if oOOo0 == 'true' :
  II1IIIIiII1i ( '[COLOR %s]Ajustes[/COLOR]' % oO0o0OOOO , 'Settings' , 119 , Ooo0Oo0 , Ii1IIii11 )
  if 75 - 75: i11Ii11I1Ii1i . OOoO
  if 50 - 50: I11iIi1I
  if ooOO00O00oo == 'true' :
   try :
    if 60 - 60: OOoO * iIii1I11I1II1 * iii1I1I * ii1IiI1i
    O0O0OoOO0 = o0OO00 . getSetting ( 'usuario' )
    iiiI1I11i1 = o0OO00 . getSetting ( 'mail' )
    IIi1i11111 = o0OO00 . getSetting ( 'claves' )
    if 69 - 69: I1i1iI1i * O0 . i11iIiiIii / I1i1iI1i . IiiIII111iI
    if 63 - 63: Oo0ooO0oo0oO + IiiIII111iI . o0 - i1
    IIi = II111iI111I1I ( O0O0ooOOO )
    I1i1i1iii = re . compile ( Ii1I1Ii ) . findall ( IIi )
    for OOii111IiiI1 , ooO0oOo0o , ii11i1iIiII1 in I1i1i1iii :
     if re . search ( IIi1i11111 , ii11i1iIiII1 ) :
      if 52 - 52: IiiIII111iI % ii1IiI1i
      if O0O0OoOO0 == ooO0oOo0o and iiiI1I11i1 == OOii111IiiI1 and IIi1i11111 == ii11i1iIiII1 :
       if 64 - 64: O0 % Oo0ooO0oo0oO % O0 * OOooOOo . O00oOoOoO0o0O + i1
       O00I11ii1i1 ( )
   except :
    pass
    if 78 - 78: II
  if oo00O00oO == 'true' :
   if 28 - 28: Oo0ooO0oo0oO
   oOOOOoo ( )
   if 58 - 58: IiiIII111iI / i11Ii11I1Ii1i . I11iIi1I / OoooooooOO + ooO
  if ii1I == 'false' :
   if 86 - 86: Oo0ooO0oo0oO * i1 + Oo0ooO0oo0oO + o0
   Ooo00Oo = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   oO00Oooo0O0o0 = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.ResolveURL para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   II1iI1I11I = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, Script.resolveurl instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 8 - 8: ooO - II / OOoO
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , Ooo00Oo , oO00Oooo0O0o0 , II1iI1I11I )
   if 96 - 96: I11iIi1I
def IIiiI ( ) :
 II1IIIIiII1i ( '[COLOR orange]Buscador por id[/COLOR]' , ii11IIII11I , 127 , oOo0oooo00o , Ii1IIii11 )
 if 31 - 31: iii1I1I + I1i1iI1i + ooO / I1i1iI1i
def iiI111 ( ) :
 oO0o0OOOO = o0OO00 . getSetting ( 'MenuColor' )
 II1IIIIiII1i ( '[COLOR %s]The movie DB[/COLOR]' % oO0o0OOOO , 'movieDB' , 99 , oOo0oooo00o , Ii1IIii11 )
 if 1 - 1: Oo0ooO0oo0oO * IiiIII111iI . I11iIi1I / O0
 if 100 - 100: ooO . IiiIII111iI * ii1IiI1i % O0 * O0
 if 14 - 14: iii1I1I . OOoO + o0 / II / Oo0ooO0oo0oO
 if 74 - 74: O0 / i1IIi
 if 78 - 78: OoooooooOO . OOooOOo + OOoO - i1IIi
def ii1O0 ( ) :
 if 33 - 33: i1IIi
 IIII1 ( )
 iiI111 ( )
 if 36 - 36: o0 % i11iIiiIii * I11iIi1I + Oo0ooO0oo0oO
def iii11i1IIII ( ) :
 if 26 - 26: O0 . OOooOOo * ooO . i1 % i11iIiiIii
 ii1O0 ( )
 if 47 - 47: II - ii1IiI1i
def Iiii ( ) :
 if xbmc . getCondVisibility ( 'System.HasAddon(script.favourites)' ) :
  try :
   xbmc . executebuiltin ( "RunScript(script.favourites)" )
  except :
   pass
def oooOOoooo ( ) :
 o0OO00 . openSettings ( )
 if 89 - 89: II - OOoO % ii1IiI1i % IiiIII111iI
 if 49 - 49: ii1IiI1i - i1 / i11Ii11I1Ii1i / O0 % IiiIII111iI * I1i1iI1i
def OOo ( ) :
 resoveurl . display_settings ( )
 if 82 - 82: OOoO . II / ii1IiI1i % II * iii1I1I / II
def O0Oo00OoOo ( ) :
 II1IIIIiII1i ( '[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % oO0o0OOOO , 'resolve' , 120 , I1I111 , Ii1IIii11 )
 if 24 - 24: i11iIiiIii - ooO
def i11iiI1111 ( ) :
 if 97 - 97: ii1IiI1i * i1 . iIii1I11I1II1
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 16 - 16: OOoO % OoooooooOO - O0oo0OO0 * I1i1iI1i * iii1I1I / OoooooooOO
def oOOOOoo ( ) :
 II1IIIIiII1i ( '[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % oO0o0OOOO , 'resolve' , 140 , I1I111 , Ii1IIii11 )
 if 31 - 31: Oo0ooO0oo0oO . ooO * OOoO + i11iIiiIii * O00oOoOoO0o0O
def O00I11ii1i1 ( ) :
 if 93 - 93: iii1I1I / iIii1I11I1II1 * i1IIi % OoooooooOO * O0 * Oo0ooO0oo0oO
 try :
  if 64 - 64: o0 + O0 / iIii1I11I1II1 / ii1IiI1i . OOoO % i11Ii11I1Ii1i
  O0O0OoOO0 = o0OO00 . getSetting ( 'usuario' )
  iiiI1I11i1 = o0OO00 . getSetting ( 'mail' )
  IIi1i11111 = o0OO00 . getSetting ( 'claves' )
  if 50 - 50: iIii1I11I1II1 - i11Ii11I1Ii1i + O0oo0OO0
  IIi = II111iI111I1I ( O0O0ooOOO )
  I1i1i1iii = re . compile ( Ii1I1Ii ) . findall ( IIi )
  for ooO0oOo0o , OOii111IiiI1 , ii11i1iIiII1 in I1i1i1iii :
   if re . search ( IIi1i11111 , ii11i1iIiII1 ) :
    if 69 - 69: O0
    if O0O0OoOO0 == ooO0oOo0o and iiiI1I11i1 == OOii111IiiI1 and IIi1i11111 == ii11i1iIiII1 :
     if 85 - 85: OOoO / O0
     II1IIIIiII1i ( '[COLOR %s]Buscador[/COLOR]' % oO0o0OOOO , 'search' , 146 , I11 , Ii1IIii11 )
     II1IIIIiII1i ( '[COLOR %s]Estrenos[/COLOR]' % oO0o0OOOO , ii11IIII11I , 3 , oo0o0O00 , Ii1IIii11 )
     if 18 - 18: IiiIII111iI % O0 * iii1I1I
     if 62 - 62: ooO . i11Ii11I1Ii1i . OoooooooOO
     if 11 - 11: O0oo0OO0 / Oo0ooO0oo0oO
     II1IIIIiII1i ( '[COLOR %s]Animacion[/COLOR]' % oO0o0OOOO , ii11IIII11I , 6 , oooOOOOO , Ii1IIii11 )
     if 73 - 73: i1IIi / i11iIiiIii
     if 58 - 58: ii1IiI1i . o0 + O00oOoOoO0o0O - i11iIiiIii / o0 / O0
     if 85 - 85: I11iIi1I + O0oo0OO0
     if 10 - 10: i11Ii11I1Ii1i / OOooOOo + I11iIi1I / i1IIi
     II1IIIIiII1i ( '[COLOR %s]Grandes Peliculas[/COLOR]' % oO0o0OOOO , ii11IIII11I , 30 , iI111I11I1I1 , Ii1IIii11 )
     if 27 - 27: I1i1iI1i
     if 67 - 67: i1
     if 55 - 55: iii1I1I - II * IiiIII111iI + I11iIi1I * I11iIi1I * O0
     II1IIIIiII1i ( '[COLOR %s]Familiar[/COLOR]' % oO0o0OOOO , ii11IIII11I , 13 , O0OoO000O0OO , Ii1IIii11 )
     if 91 - 91: ooO - O0oo0OO0 % iIii1I11I1II1 - OoooooooOO % OOoO
     if 98 - 98: OOooOOo . OOooOOo * O00oOoOoO0o0O * o0 * ooO
     if 92 - 92: ii1IiI1i
     if 40 - 40: I11iIi1I / i11Ii11I1Ii1i
     if 79 - 79: OOooOOo - iIii1I11I1II1 + I1i1iI1i - ooO
     if 93 - 93: o0 . i1 - ii1IiI1i + I11iIi1I
     if 61 - 61: o0
     if 15 - 15: i11iIiiIii % i1 * Oo0ooO0oo0oO / ooO
     if 90 - 90: II
     if 31 - 31: O0oo0OO0 + O0
     II1IIIIiII1i ( '[COLOR %s]Super heroes[/COLOR]' % oO0o0OOOO , ii11IIII11I , 24 , OooO0 , Ii1IIii11 )
     II1IIIIiII1i ( '[COLOR %s]4k[/COLOR] En pruebas' % oO0o0OOOO , ii11IIII11I , 141 , IIIII , Ii1IIii11 )
     if 87 - 87: OOoO
     if 45 - 45: OOooOOo / OoooooooOO - II / I1i1iI1i % i11Ii11I1Ii1i
     if 83 - 83: i1 . iIii1I11I1II1 - i11Ii11I1Ii1i * i11iIiiIii
 except :
  pass
  if 20 - 20: i1IIi * ooO + o0 % IiiIII111iI % O00oOoOoO0o0O
  if 13 - 13: ii1IiI1i
def oOOo000oOoO0 ( ) :
 if 86 - 86: o0 % i11iIiiIii + I1i1iI1i % i11iIiiIii
 try :
  if 92 - 92: i11iIiiIii - II / OOoO / O00oOoOoO0o0O
  O0O0OoOO0 = o0OO00 . getSetting ( 'usuario' )
  iiiI1I11i1 = o0OO00 . getSetting ( 'mail' )
  IIi1i11111 = o0OO00 . getSetting ( 'claves' )
  if 43 - 43: o0 + O0oo0OO0 + II
  IIi = II111iI111I1I ( O0O0ooOOO )
  I1i1i1iii = re . compile ( Ii1I1Ii ) . findall ( IIi )
  for ooO0oOo0o , OOii111IiiI1 , ii11i1iIiII1 in I1i1i1iii :
   if re . search ( IIi1i11111 , ii11i1iIiII1 ) :
    if 40 - 40: IiiIII111iI
    if O0O0OoOO0 == ooO0oOo0o and iiiI1I11i1 == OOii111IiiI1 and IIi1i11111 == ii11i1iIiII1 :
     if 67 - 67: O00oOoOoO0o0O + o0 - O0 . O00oOoOoO0o0O * o0 * Oo0ooO0oo0oO
     II1IIIIiII1i ( '[COLOR %s]Buscar Serie[/COLOR]' % oO0o0OOOO , 'search' , 145 , IIiiiiiiIi1I1 , Ii1IIii11 )
     if 90 - 90: I1i1iI1i . i11Ii11I1Ii1i
     OO00O0oOO ( )
     if 4 - 4: OoooooooOO - i1IIi % I1i1iI1i - O0oo0OO0 * IiiIII111iI
     II1IIIIiII1i ( '[COLOR %s]En emision[/COLOR]' % oO0o0OOOO , ii11IIII11I , 150 , OOO00 , Ii1IIii11 )
     II1IIIIiII1i ( '[COLOR %s]Mejor valoradas[/COLOR]' % oO0o0OOOO , ii11IIII11I , 151 , iiiiiIIii , Ii1IIii11 )
     II1IIIIiII1i ( '[COLOR %s]Series Retro[/COLOR]' % oO0o0OOOO , ii11IIII11I , 152 , O000OO0 , Ii1IIii11 )
     II1IIIIiII1i ( '[COLOR %s]Todas[/COLOR]' % oO0o0OOOO , ii11IIII11I , 142 , I1IIIii , Ii1IIii11 )
     if 85 - 85: OoooooooOO * iIii1I11I1II1 . II / OoooooooOO % i1 % O0
     if 36 - 36: I1i1iI1i / o0 / i11Ii11I1Ii1i / i11Ii11I1Ii1i + iii1I1I
 except :
  pass
  if 95 - 95: i11Ii11I1Ii1i
  if 51 - 51: o0 + i11Ii11I1Ii1i . i1IIi . iii1I1I + I11iIi1I * i1
  if 72 - 72: O00oOoOoO0o0O + O00oOoOoO0o0O / o0 . OoooooooOO % I1i1iI1i
def OO00O0oOO ( ) :
 if 49 - 49: O00oOoOoO0o0O . OOooOOo - ii1IiI1i * OoooooooOO . ii1IiI1i
 ii1Ii1IiIIi = 'aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtLw==' . decode ( '\x62\x61\x73\x65\x36\x34' )
 o0OO0 = 'Y29uZGljaW9uLnR4dA==' . decode ( '\x62\x61\x73\x65\x36\x34' )
 iiI11Iii = ii1Ii1IiIIi + o0OO0
 oOo00Oo0o0Oo = '[\'"](.*?)[\'"]'
 oOOo000oOoO0 = II111iI111I1I ( iiI11Iii )
 I1i1i1iii = re . compile ( oOo00Oo0o0Oo ) . findall ( oOOo000oOoO0 )
 for I1 in I1i1i1iii :
  try :
   if 26 - 26: OOoO . O0oo0OO0 - O0oo0OO0 . OOooOOo
   if I1 == 'si' or I1 == 'Si' :
    if 39 - 39: OoooooooOO + O00oOoOoO0o0O % O0oo0OO0 / O0oo0OO0
    II1IIIIiII1i ( '[COLOR lime](Si)[/COLOR][COLOR %s] Nuevos Episodios[/COLOR]' % oO0o0OOOO , ii11IIII11I , 155 , OOOOi11i1 , Ii1IIii11 )
    if 27 - 27: II . Oo0ooO0oo0oO . iIii1I11I1II1 . iIii1I11I1II1
   elif I1 == 'no' or I1 == 'No' :
    if 20 - 20: IiiIII111iI / i1IIi
    II1IIIIiII1i ( '[COLOR red](No)[/COLOR][COLOR %s] Nuevos Episodios[/COLOR]' % oO0o0OOOO , ii11IIII11I , 155 , O000oo0O , Ii1IIii11 )
    if 71 - 71: I11iIi1I . i1IIi
   return
   if 94 - 94: O0oo0OO0 . ooO
  except :
   pass
   if 84 - 84: O0 . Oo0ooO0oo0oO - o0 . OOoO / o0
def iii1 ( ) :
 if 32 - 32: I1i1iI1i . i11Ii11I1Ii1i . OoooooooOO - OOooOOo + O00oOoOoO0o0O
 if 88 - 88: II
 try :
  if 19 - 19: o0 * i11Ii11I1Ii1i + I1i1iI1i
  O0ooO00oO = II111iI111I1I ( dbserie )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( O0ooO00oO )
  for I1111i in I1i1i1iii :
   if 36 - 36: O0oo0OO0
   try :
    if 84 - 84: ooO . OOooOOo . o0 . Oo0ooO0oo0oO / I1i1iI1i % iii1I1I
    OOO0oOoO0O = I1111i
    i1ii1I1111ii1 = xbmc . Keyboard ( '' , 'Buscar' )
    i1ii1I1111ii1 . doModal ( )
    if ( i1ii1I1111ii1 . isConfirmed ( ) ) :
     iIiI1 = xbmcgui . DialogProgress ( )
     iIiI1 . create ( 'Realstream:' , 'Buscando ...' )
     oOo0OOoO0 = range ( 0 , 69 )
     for IIo0Oo0oO0oOO00 in oOo0OOoO0 :
      IIo0Oo0oO0oOO00 = IIo0Oo0oO0oOO00 + 1
     o0000oO = urllib . quote_plus ( i1ii1I1111ii1 . getText ( ) ) . replace ( '+' , ' ' )
     I1II1 = II111iI111I1I ( OOO0oOoO0O )
     I1i1i1iii = re . compile ( O00 ) . findall ( I1II1 )
     for OoOo000oOo0oo , i1I1i111Ii , Ii1IIii11 , ooo , Ooo0oOooo0 in I1i1i1iii :
      iIiI1 . update ( IIo0Oo0oO0oOO00 , '[COLOR orange]Realstream: Buscando ...[/COLOR]' , '[COLOR gold] %s [/COLOR]' % i1I1i111Ii )
      xbmc . sleep ( 5 )
      if iIiI1 . iscanceled ( ) : break ;
      if re . search ( o0000oO , IiI1iIiIIIii ( i1I1i111Ii . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       if 65 - 65: I11iIi1I / OOooOOo % i11Ii11I1Ii1i
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Generando listado ...  [COLOR orange] Por favor espere ![/COLOR] , 4000)" )
       iIiIIii ( i1I1i111Ii , ooo , 143 , OoOo000oOo0oo , Ii1IIii11 , Ooo0oOooo0 )
       iIiI1 . update ( 100 , '[COLOR orange]Realstream: [/COLOR]' , '[COLOR gold] Busqueda finalizada ...[/COLOR]' )
       xbmc . sleep ( 2000 )
       iIiI1 . close ( )
     II1IIIIiII1i ( '[COLOR %s]Buscar Serie[/COLOR]' % oO0o0OOOO , 'search' , 145 , IIiiiiiiIi1I1 , Ii1IIii11 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Sin Resultados para: [COLOR orange]" + o0000oO + "[/COLOR] , 2000)" )
     if 61 - 61: IiiIII111iI / O0oo0OO0 / ii1IiI1i * O0
     if 23 - 23: O00oOoOoO0o0O - O0oo0OO0 + Oo0ooO0oo0oO
   except : II1IIIIiII1i ( '[COLOR %s]Buscar Serie[/COLOR]' % oO0o0OOOO , 'search' , 145 , IIiiiiiiIi1I1 , Ii1IIii11 )
   if 12 - 12: i1 / OOoO % IiiIII111iI / i11iIiiIii % OoooooooOO
 except :
  pass
  if 15 - 15: iIii1I11I1II1 % OoooooooOO - ii1IiI1i * I1i1iI1i + Oo0ooO0oo0oO
def i1I1II1iIIi11 ( ) :
 if 49 - 49: OoooooooOO * Oo0ooO0oo0oO - ii1IiI1i . O00oOoOoO0o0O
 try :
  if 89 - 89: OOoO + I1i1iI1i * OOoO / OOoO
  O0ooO00oO = II111iI111I1I ( dbnserie )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( O0ooO00oO )
  for I1111i in I1i1i1iii :
   if 46 - 46: OOooOOo
   try :
    if 71 - 71: Oo0ooO0oo0oO / Oo0ooO0oo0oO * O00oOoOoO0o0O * O00oOoOoO0o0O / o0
    OOO0oOoO0O = I1111i
    if 35 - 35: O0oo0OO0 * IiiIII111iI * i1 % ii1IiI1i . I11iIi1I
   except :
    pass
    if 58 - 58: Oo0ooO0oo0oO + o0 * II * i11iIiiIii - iIii1I11I1II1
  I1II1 = II111iI111I1I ( OOO0oOoO0O )
  I1i1i1iii = re . compile ( O00 ) . findall ( I1II1 )
  for OoOo000oOo0oo , i1I1i111Ii , Ii1IIii11 , ooo , Ooo0oOooo0 in I1i1i1iii :
   try :
    if 68 - 68: OoooooooOO % o0
    iIiIIii ( i1I1i111Ii , ooo , 143 , OoOo000oOo0oo , Ii1IIii11 , Ooo0oOooo0 )
    if 26 - 26: o0 % i11iIiiIii % iIii1I11I1II1 % Oo0ooO0oo0oO * Oo0ooO0oo0oO * iii1I1I
   except :
    pass
 except :
  pass
  if 24 - 24: o0 % ooO - OOoO + i1 * iii1I1I
def i11111I1I ( ) :
 if 61 - 61: o0 * O0oo0OO0 / OoooooooOO / ii1IiI1i - OOooOOo
 try :
  if 56 - 56: iii1I1I
  O0ooO00oO = II111iI111I1I ( dbrserie )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( O0ooO00oO )
  for I1111i in I1i1i1iii :
   if 26 - 26: OoooooooOO % OoooooooOO
   try :
    if 33 - 33: ooO
    OOO0oOoO0O = I1111i
    if 62 - 62: iii1I1I + I1i1iI1i + i1IIi / OoooooooOO
   except :
    pass
    if 7 - 7: IiiIII111iI + i1IIi . i1 / ii1IiI1i
  I1II1 = II111iI111I1I ( OOO0oOoO0O )
  I1i1i1iii = re . compile ( O00 ) . findall ( I1II1 )
  for OoOo000oOo0oo , i1I1i111Ii , Ii1IIii11 , ooo , Ooo0oOooo0 in I1i1i1iii :
   try :
    if 22 - 22: OOoO - OOoO % O0oo0OO0 . ooO + O00oOoOoO0o0O
    iIiIIii ( i1I1i111Ii , ooo , 143 , OoOo000oOo0oo , Ii1IIii11 , Ooo0oOooo0 )
    if 63 - 63: i1 % ooO * IiiIII111iI + ooO / ii1IiI1i % II
   except :
    pass
 except :
  pass
  if 45 - 45: i11Ii11I1Ii1i
  if 20 - 20: OoooooooOO * IiiIII111iI * O0 . O0oo0OO0
def OoO000O ( ) :
 if 94 - 94: I11iIi1I . O0 / I1i1iI1i . iii1I1I - i1IIi
 try :
  if 26 - 26: OOooOOo - O0oo0OO0 . IiiIII111iI
  O0ooO00oO = II111iI111I1I ( dbeserie )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( O0ooO00oO )
  for I1111i in I1i1i1iii :
   if 65 - 65: iii1I1I % O0 % iIii1I11I1II1 * I1i1iI1i
   try :
    if 31 - 31: I1i1iI1i
    OOO0oOoO0O = I1111i
    if 44 - 44: I11iIi1I - iIii1I11I1II1 - ii1IiI1i
   except :
    pass
    if 80 - 80: iIii1I11I1II1 * ooO % Oo0ooO0oo0oO % ii1IiI1i
  I1II1 = II111iI111I1I ( OOO0oOoO0O )
  I1i1i1iii = re . compile ( O00 ) . findall ( I1II1 )
  for OoOo000oOo0oo , i1I1i111Ii , Ii1IIii11 , ooo , Ooo0oOooo0 in I1i1i1iii :
   try :
    if 95 - 95: iIii1I11I1II1 - iii1I1I . ooO - i1
    iIiIIii ( i1I1i111Ii , ooo , 143 , OoOo000oOo0oo , Ii1IIii11 , Ooo0oOooo0 )
    if 75 - 75: OOooOOo + IiiIII111iI - i1IIi . OoooooooOO * I1i1iI1i / i11Ii11I1Ii1i
   except :
    pass
 except :
  pass
  if 86 - 86: I11iIi1I * o0 - O0 . I11iIi1I % iIii1I11I1II1 / O0oo0OO0
def IiIIiIIIiIii ( ) :
 if 23 - 23: II + Oo0ooO0oo0oO . I11iIi1I * i1 + iii1I1I
 try :
  if 18 - 18: i11Ii11I1Ii1i * IiiIII111iI . i11Ii11I1Ii1i / O0
  O0ooO00oO = II111iI111I1I ( dbtserie )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( O0ooO00oO )
  for I1111i in I1i1i1iii :
   if 8 - 8: IiiIII111iI
   try :
    if 4 - 4: iii1I1I + iii1I1I * OOoO - I11iIi1I
    OOO0oOoO0O = I1111i
    if 78 - 78: I1i1iI1i / o0 % I11iIi1I
   except :
    pass
    if 52 - 52: O0oo0OO0 - II * O00oOoOoO0o0O
  I1II1 = II111iI111I1I ( OOO0oOoO0O )
  I1i1i1iii = re . compile ( O00 ) . findall ( I1II1 )
  for OoOo000oOo0oo , i1I1i111Ii , Ii1IIii11 , ooo , Ooo0oOooo0 in I1i1i1iii :
   try :
    if 17 - 17: OoooooooOO + O0oo0OO0 * Oo0ooO0oo0oO * I11iIi1I
    iIiIIii ( i1I1i111Ii , ooo , 143 , OoOo000oOo0oo , Ii1IIii11 , Ooo0oOooo0 )
    if 36 - 36: O0 + ii1IiI1i
   except :
    pass
 except :
  pass
  if 5 - 5: ii1IiI1i * I11iIi1I
def ii1I11iIiIII1 ( ) :
 if 52 - 52: IiiIII111iI * i11Ii11I1Ii1i + I11iIi1I
 try :
  if 49 - 49: iIii1I11I1II1 - O0 . i1IIi - OoooooooOO
  O0ooO00oO = II111iI111I1I ( dbserie )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( O0ooO00oO )
  for I1111i in I1i1i1iii :
   if 37 - 37: i1IIi . Oo0ooO0oo0oO % I11iIi1I + OoooooooOO / II
   try :
    if 3 - 3: iii1I1I
    OOO0oOoO0O = I1111i
    if 17 - 17: iii1I1I . o0 . OOoO / iii1I1I
   except :
    pass
    if 57 - 57: Oo0ooO0oo0oO
  I1II1 = II111iI111I1I ( OOO0oOoO0O )
  I1i1i1iii = re . compile ( O00 ) . findall ( I1II1 )
  for OoOo000oOo0oo , i1I1i111Ii , Ii1IIii11 , ooo , Ooo0oOooo0 in I1i1i1iii :
   try :
    if 67 - 67: OOooOOo . OOoO
    iIiIIii ( i1I1i111Ii , ooo , 143 , OoOo000oOo0oo , Ii1IIii11 , Ooo0oOooo0 )
    if 87 - 87: O00oOoOoO0o0O % I1i1iI1i
   except :
    pass
 except :
  pass
  if 83 - 83: o0 - Oo0ooO0oo0oO
def iiIii1IIi ( name , url ) :
 if 10 - 10: i11iIiiIii - IiiIII111iI % iIii1I11I1II1
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 49 - 49: O00oOoOoO0o0O
 OOOOoOo00OO = II111iI111I1I ( url )
 I1i1i1iii = re . compile ( i1I1ii11i1Iii ) . findall ( OOOOoOo00OO )
 for OoOo000oOo0oo , name , Ii1IIii11 , url in I1i1i1iii :
  try :
   if 75 - 75: O0 % I11iIi1I . i11Ii11I1Ii1i / i11Ii11I1Ii1i / OOooOOo
   if 19 - 19: iii1I1I % i11iIiiIii . O0oo0OO0 - ii1IiI1i / OoooooooOO
   ooo00OOOooO = o0OO00 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % ooo00OOOooO + name + '[/COLOR]'
   oOOo00O0OOOo ( name , url , 144 , OoOo000oOo0oo , Ii1IIii11 )
   if 31 - 31: Oo0ooO0oo0oO % O0oo0OO0 * Oo0ooO0oo0oO
   if 45 - 45: i1IIi . i1 + O0oo0OO0 - OoooooooOO % OOoO
  except :
   pass
   if 1 - 1: iIii1I11I1II1
   if 93 - 93: i1IIi . i11iIiiIii . ii1IiI1i
   if 99 - 99: Oo0ooO0oo0oO - ooO - O00oOoOoO0o0O % OOooOOo
def oOOo00O0OOOo ( name , url , mode , iconimage , fanart ) :
 if 21 - 21: o0 % iii1I1I . i1IIi - OoooooooOO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 4 - 4: OoooooooOO . OOoO
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage="
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , fanart )
 II1iIi1IiIii . setProperty ( 'IsPlayable' , 'true' )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii )
 return I111I11I111
 if 46 - 46: i11iIiiIii - O0 . O00oOoOoO0o0O
 if 100 - 100: i1 / IiiIII111iI * II . O0 / O0oo0OO0
def oOO0o000Oo00o ( name , url ) :
 if 21 - 21: OoooooooOO - iIii1I11I1II1
 if 93 - 93: O00oOoOoO0o0O - IiiIII111iI % I11iIi1I . I11iIi1I - OOoO
 Oo0ooOo0o = o0OO00 . getSetting ( 'licencia_addon' )
 oOO0O00Oo0O0o = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 ii1 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( '\x62\x61\x73\x65\x36\x34' )
 O00ooOo = o0OO00 . getSetting ( 'key_ext' )
 o0O0o0 = II111iI111I1I ( ii1 )
 I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
 for oOO0o00O in I1i1i1iii :
  if 69 - 69: i1IIi
  try :
   if 59 - 59: o0 - IiiIII111iI
   if 24 - 24: ii1IiI1i - i1IIi + Oo0ooO0oo0oO
   Oo0ooOo0o = o0OO00 . getSetting ( 'licencia_addon' )
   if 38 - 38: OoooooooOO / iii1I1I . O0 / i1IIi / ii1IiI1i + iIii1I11I1II1
   if 96 - 96: II
   if Oo0ooOo0o == oOO0o00O :
    if 18 - 18: II * Oo0ooO0oo0oO - I1i1iI1i
    if 'https://mybox.com' in url :
     if 31 - 31: ii1IiI1i - O0 % I11iIi1I % O00oOoOoO0o0O
     url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
     if 45 - 45: iii1I1I + o0 * i11iIiiIii
    if 'uptostream.com' in url :
     if 13 - 13: OoooooooOO * O00oOoOoO0o0O - I1i1iI1i / O0oo0OO0 + Oo0ooO0oo0oO + i11Ii11I1Ii1i
     try :
      if 39 - 39: iIii1I11I1II1 - OoooooooOO
      o0O0o0 = II111iI111I1I ( url )
      I1i1i1iii = re . compile ( OoOoO ) . findall ( o0O0o0 )
      for url , oO0oooooo , o0OO0Oo in I1i1i1iii :
       if 3 - 3: ooO - O0 % iIii1I11I1II1 / i11Ii11I1Ii1i . IiiIII111iI
       oO0oooooo = oO0oooooo . replace ( '","res":"2160",' , ' ' ) . replace ( '","res":"1080",' , ' ' ) . replace ( '","res":"720",' , ' ' ) . replace ( '","res":"480",' , ' ' ) . replace ( '","res":"360",' , ' ' )
       url = url . replace ( '\/' , '/' )
       url = url . replace ( ',"type":"video/mp4",' , ' ' )
       o0OO0Oo = o0OO0Oo . replace ( 'spa' , 'Castellano:' ) . replace ( 'eng' , 'Ingles:' ) . replace ( 'spa1' , 'Latino:' ) . replace ( 'eng2' , 'Americano:' )
       name = '[COLOR white]' + o0OO0Oo + '[/COLOR] - [COLOR gold]' + oO0oooooo + '[/COLOR]'
       if 3 - 3: O0 % OoooooooOO / O0oo0OO0
       ooOo = [ ]
       ooOo . append ( '[COLOR orange]Real Stream: [/COLOR][COLOR gold]1. Mostrar mas info. [Reiniciar][/COLOR]' )
       ooOo . append ( '[COLOR gold]2. Mostar otras calidades disponibles [/COLOR]' )
       ooOo . append ( '[COLOR gold]3. Ver en: %s [/COLOR]' % name )
       if 84 - 84: O0oo0OO0
       if 87 - 87: OOoO + IiiIII111iI
       i1iIIIIIIiII1 = 'Seleccione una calidad e idioma:'
       iii11 = xbmcgui . Dialog ( )
       i1oO = iii11 . select ( i1iIIIIIIiII1 , ooOo )
       if 30 - 30: ii1IiI1i . OOooOOo
       if 57 - 57: Oo0ooO0oo0oO . ii1IiI1i + o0
       if i1oO == 0 :
        if 43 - 43: ooO % II
        I111I11I111 = iii11 . ok ( "[COLOR darkpink]REALSTREAM:[/COLOR] " , "[COLOR gold]  Reiniciadas las opciones.  [/COLOR]" , "" )
        del iii11
        return
        if 69 - 69: II % OOooOOo
       elif i1oO == 1 :
        if 86 - 86: O00oOoOoO0o0O / O00oOoOoO0o0O
        pass
        if 28 - 28: i11iIiiIii / IiiIII111iI . iIii1I11I1II1 / o0
        del iii11
        if 72 - 72: OoooooooOO / i1 + I1i1iI1i / I11iIi1I * I1i1iI1i
        if 34 - 34: O0 * O0 % OoooooooOO + II * iIii1I11I1II1 % I1i1iI1i
        if 25 - 25: Oo0ooO0oo0oO + I11iIi1I . IiiIII111iI % I11iIi1I * O0oo0OO0
        if 32 - 32: i11iIiiIii - ooO
       elif i1oO == 2 :
        if 53 - 53: OoooooooOO - i11Ii11I1Ii1i
        oOo ( name , url )
        if 17 - 17: I1i1iI1i . i11iIiiIii
        return
        if 5 - 5: iii1I1I + O0 + O0 . ooO - OOoO
     except :
      pass
      if 63 - 63: O00oOoOoO0o0O
      if 71 - 71: i1IIi . I1i1iI1i * II % OoooooooOO + O0oo0OO0
    if 'https://team.com' in url :
     if 36 - 36: i11Ii11I1Ii1i
     url = url . replace ( 'https://team.com' , 'https://verystream.com' )
     if 49 - 49: O0oo0OO0 / OoooooooOO / i1
     if 74 - 74: ooO % iii1I1I
     if 7 - 7: o0
    if 'https://vidcloud.co/' in url :
     if 27 - 27: O00oOoOoO0o0O . OoooooooOO + i11iIiiIii
     url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
     if 86 - 86: Oo0ooO0oo0oO / IiiIII111iI - IiiIII111iI + iii1I1I + O00oOoOoO0o0O
    if 'https://gounlimited.to' in url :
     if 33 - 33: IiiIII111iI . II . i11Ii11I1Ii1i . i1IIi
     url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
     if 49 - 49: iii1I1I
    if 'https://drive.com' in url :
     if 84 - 84: Oo0ooO0oo0oO - ii1IiI1i / O0 - ooO
     url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
     if 21 - 21: O0 * O0 % iii1I1I
     if 94 - 94: Oo0ooO0oo0oO + o0 % i11iIiiIii
     if 8 - 8: OOoO * O0
     if 73 - 73: IiiIII111iI / O00oOoOoO0o0O / Oo0ooO0oo0oO / OOooOOo
    import resolveurl
    if 11 - 11: I11iIi1I + i11Ii11I1Ii1i - OoooooooOO / OOooOOo
    iIIi1iI1I1IIi = resolveurl . HostedMediaFile ( url )
    if 77 - 77: OOoO / ii1IiI1i + OOoO % IiiIII111iI - i1 * i1
    if not iIIi1iI1I1IIi :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
     return False
     if 23 - 23: II . o0 % iii1I1I - OoooooooOO * ii1IiI1i . iIii1I11I1II1
    try :
     iIiI1 = xbmcgui . DialogProgress ( )
     iIiI1 . create ( 'Realstream:' , 'Iniciando ...' )
     iIiI1 . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
     xbmc . sleep ( 1000 )
     I1iI = iIIi1iI1I1IIi . resolve ( )
     if not I1iI or not isinstance ( I1iI , basestring ) :
      try : O0o00O0Oo0 = I1iI . msg
      except : O0o00O0Oo0 = url
      raise Exception ( O0o00O0Oo0 )
      if 58 - 58: O0
    except Exception as O0o0O0 :
     try : O0o00O0Oo0 = str ( O0o0O0 )
     except : O0o00O0Oo0 = url
     iIiI1 . update ( 45 , 'RESOLVEURL:' , 'Reiniciando ... ' )
     xbmc . sleep ( 1000 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Episodio no disponible.  ,3000)" )
     iIiI1 . close ( )
     if 78 - 78: OOooOOo % i11Ii11I1Ii1i * i1IIi
    iIiI1 . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    iIiI1 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
    xbmc . sleep ( 500 )
    iIiI1 . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
    xbmc . sleep ( 500 )
    iIiI1 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de este capitulo!' )
    iIiI1 . close ( )
    Ii1i1 = o0OO00 . getSetting ( 'notificar' )
    O0iI = xbmcgui . ListItem ( path = I1iI )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0iI )
    if 15 - 15: O0 / ii1IiI1i % iii1I1I + IiiIII111iI
    if 23 - 23: iIii1I11I1II1 + O0
   else :
    if 58 - 58: ii1IiI1i
    Ii1i1 = o0OO00 . getSetting ( 'notificar' )
    if Ii1i1 == 'true' :
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Por favor compruebe los ajustes de realstream.[/COLOR]" , "[COLOR white] Desde la seccion Tutoriales puede sacarle mayor partido a su Realstream, tambien puede configurarlo a su gusto. [/COLOR]" , "[COLOR gold]El addon no esta activado o bien configurado.[/COLOR]" )
     if 9 - 9: iIii1I11I1II1 % iii1I1I . O0oo0OO0 + OoooooooOO
     oO0o0OOOO = o0OO00 . getSetting ( 'MenuColor' )
     II1IIIIiII1i ( '[COLOR %s]Video tutoriales[/COLOR]' % oO0o0OOOO , ii11IIII11I , 125 , II11i1iIiII1 , Ii1IIii11 )
  except :
   pass
   if 62 - 62: O0 / i1 % O0 * OOooOOo % i1
   if 33 - 33: i1 . O00oOoOoO0o0O * OOooOOo * iIii1I11I1II1
   if 5 - 5: ii1IiI1i / i11Ii11I1Ii1i % O0 . ooO * i11Ii11I1Ii1i
   if 83 - 83: O0oo0OO0
def iiooO0o0oO ( ) :
 if 67 - 67: OoooooooOO
 if 29 - 29: O0 - i11iIiiIii - o0 + O0oo0OO0 * i11Ii11I1Ii1i
 try :
  if 2 - 2: i1IIi - OOoO + i1 . IiiIII111iI * IiiIII111iI / I11iIi1I
  O0ooO00oO = II111iI111I1I ( dbpelicula )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( O0ooO00oO )
  for I1111i in I1i1i1iii :
   if 93 - 93: i1IIi
   try :
    if 53 - 53: OoooooooOO + ii1IiI1i + O00oOoOoO0o0O
    OOO0oOoO0O = I1111i
    i1ii1I1111ii1 = xbmc . Keyboard ( '' , 'Buscar' )
    i1ii1I1111ii1 . doModal ( )
    if ( i1ii1I1111ii1 . isConfirmed ( ) ) :
     iIiI1 = xbmcgui . DialogProgress ( )
     iIiI1 . create ( 'Realstream:' , 'Buscando ...' )
     oOo0OOoO0 = range ( 0 , 69 )
     for IIo0Oo0oO0oOO00 in oOo0OOoO0 :
      IIo0Oo0oO0oOO00 = IIo0Oo0oO0oOO00 + 1
     o0000oO = urllib . quote_plus ( i1ii1I1111ii1 . getText ( ) ) . replace ( '+' , ' ' )
     I1II1 = II111iI111I1I ( OOO0oOoO0O )
     I1i1i1iii = re . compile ( iiiIi1 ) . findall ( I1II1 )
     for OoOo000oOo0oo , i1I1i111Ii , Ii1IIii11 , ooo , Ooo0oOooo0 in I1i1i1iii :
      iIiI1 . update ( IIo0Oo0oO0oOO00 , '[COLOR orange]Realstream: Buscando ...[/COLOR]' , '[COLOR gold] %s [/COLOR]' % i1I1i111Ii )
      xbmc . sleep ( 5 )
      if iIiI1 . iscanceled ( ) : break ;
      if re . search ( o0000oO , IiI1iIiIIIii ( i1I1i111Ii . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       if 24 - 24: II - i11Ii11I1Ii1i - II * iii1I1I . OoooooooOO / i11Ii11I1Ii1i
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Generando listado ...  [COLOR orange] Por favor espere ![/COLOR] , 4000)" )
       iIiIIii ( i1I1i111Ii , ooo , 147 , OoOo000oOo0oo , Ii1IIii11 , Ooo0oOooo0 )
       iIiI1 . update ( 100 , '[COLOR orange]Realstream: [/COLOR]' , '[COLOR gold] Busqueda finalizada ...[/COLOR]' )
       xbmc . sleep ( 2000 )
       iIiI1 . close ( )
     II1IIIIiII1i ( '[COLOR %s]Buscar Pelicula[/COLOR]' % oO0o0OOOO , 'search' , 146 , IIiiiiiiIi1I1 , Ii1IIii11 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Sin Resultados para: [COLOR orange]" + o0000oO + "[/COLOR] , 2000)" )
     if 66 - 66: ii1IiI1i
     if 97 - 97: i1IIi - OoooooooOO / ooO * i1
   except : II1IIIIiII1i ( '[COLOR %s]Buscar Pelicula[/COLOR]' % oO0o0OOOO , 'search' , 146 , IIiiiiiiIi1I1 , Ii1IIii11 )
   if 55 - 55: IiiIII111iI . II
 except :
  pass
  if 87 - 87: IiiIII111iI % iIii1I11I1II1
def O00Iii1111III111 ( ) :
 if 28 - 28: OoooooooOO . O00oOoOoO0o0O % iii1I1I / i1IIi / O0oo0OO0
 try :
  if 36 - 36: IiiIII111iI + Oo0ooO0oo0oO - i11Ii11I1Ii1i + iIii1I11I1II1 + OoooooooOO
  O0ooO00oO = II111iI111I1I ( dbpelicula )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( O0ooO00oO )
  for I1111i in I1i1i1iii :
   if 4 - 4: o0 . Oo0ooO0oo0oO + I1i1iI1i * ooO . OOoO
   try :
    if 87 - 87: I11iIi1I / OOooOOo / i11iIiiIii
    OOO0oOoO0O = I1111i
    if 74 - 74: O00oOoOoO0o0O / iii1I1I % IiiIII111iI
   except :
    pass
    if 88 - 88: I11iIi1I - i11iIiiIii % IiiIII111iI * Oo0ooO0oo0oO + iii1I1I
  I1II1 = II111iI111I1I ( OOO0oOoO0O )
  I1i1i1iii = re . compile ( iiiIi1 ) . findall ( I1II1 )
  for OoOo000oOo0oo , i1I1i111Ii , Ii1IIii11 , ooo , Ooo0oOooo0 in I1i1i1iii :
   try :
    if 52 - 52: o0 . i1 + I11iIi1I % OOooOOo
    iIiIIii ( i1I1i111Ii , ooo , 147 , OoOo000oOo0oo , Ii1IIii11 , Ooo0oOooo0 )
    if 62 - 62: IiiIII111iI
   except :
    pass
 except :
  pass
  if 15 - 15: Oo0ooO0oo0oO + I1i1iI1i . O0oo0OO0 * OOooOOo . I11iIi1I
  if 18 - 18: i1IIi % o0 + ooO % I1i1iI1i
  if 72 - 72: iIii1I11I1II1
def iI1I1II1 ( ) :
 if 92 - 92: OoooooooOO - OoooooooOO * OOooOOo % i1
 try :
  if 77 - 77: iIii1I11I1II1 - i1IIi . O00oOoOoO0o0O
  O0ooO00oO = II111iI111I1I ( dbnovedades )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( O0ooO00oO )
  for I1111i in I1i1i1iii :
   if 26 - 26: IiiIII111iI * i11Ii11I1Ii1i . i1IIi
   try :
    if 59 - 59: O0 + i1IIi - IiiIII111iI
    OOO0oOoO0O = I1111i
    if 62 - 62: i11iIiiIii % O0oo0OO0 . i11Ii11I1Ii1i . O0oo0OO0
   except :
    pass
    if 84 - 84: i11iIiiIii * OOooOOo
  I1II1 = II111iI111I1I ( OOO0oOoO0O )
  I1i1i1iii = re . compile ( iiiIi1 ) . findall ( I1II1 )
  for OoOo000oOo0oo , i1I1i111Ii , Ii1IIii11 , ooo , Ooo0oOooo0 in I1i1i1iii :
   try :
    if 18 - 18: O0oo0OO0 - I1i1iI1i - I11iIi1I / ooO - O0
    iIiIIii ( i1I1i111Ii , ooo , 147 , OoOo000oOo0oo , Ii1IIii11 , Ooo0oOooo0 )
    if 30 - 30: O0 + iii1I1I + o0
   except :
    pass
 except :
  pass
  if 14 - 14: IiiIII111iI / O0oo0OO0 - iIii1I11I1II1 - O00oOoOoO0o0O % OOoO
def I1iIiI1IiIIII ( ) :
 if 18 - 18: OOoO % i11iIiiIii . iIii1I11I1II1 - II
 try :
  if 80 - 80: i1 + O00oOoOoO0o0O - i1IIi . I1i1iI1i / IiiIII111iI / i1
  I1Iiii = II111iI111I1I ( dbfamiliar )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( I1Iiii )
  for I1111i in I1i1i1iii :
   if 34 - 34: I1i1iI1i * I11iIi1I - i11Ii11I1Ii1i - i1 - I1i1iI1i
   try :
    if 42 - 42: o0 * i1 % i1IIi - I1i1iI1i % i11Ii11I1Ii1i
    OOO0oOoO0O = I1111i
    if 36 - 36: i11iIiiIii / O00oOoOoO0o0O * iii1I1I * iii1I1I + I1i1iI1i * Oo0ooO0oo0oO
   except :
    pass
    if 32 - 32: OOooOOo
  I1II1 = II111iI111I1I ( OOO0oOoO0O )
  I1i1i1iii = re . compile ( iiiIi1 ) . findall ( I1II1 )
  for OoOo000oOo0oo , i1I1i111Ii , Ii1IIii11 , ooo , Ooo0oOooo0 in I1i1i1iii :
   try :
    if 50 - 50: OOoO + i1IIi
    iIiIIii ( i1I1i111Ii , ooo , 147 , OoOo000oOo0oo , Ii1IIii11 , Ooo0oOooo0 )
    if 31 - 31: I1i1iI1i
   except :
    pass
 except :
  pass
  if 78 - 78: i11iIiiIii + IiiIII111iI + ooO / IiiIII111iI % iIii1I11I1II1 % i11Ii11I1Ii1i
def Oo0O0Oo00O ( ) :
 if 9 - 9: IiiIII111iI . i1 - iii1I1I
 try :
  if 32 - 32: OoooooooOO / i1 / iIii1I11I1II1 + o0 . O00oOoOoO0o0O . IiiIII111iI
  O0ooO00oO = II111iI111I1I ( dbestrenos )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( O0ooO00oO )
  for I1111i in I1i1i1iii :
   if 21 - 21: iIii1I11I1II1 / o0 % i1IIi
   try :
    if 8 - 8: OOooOOo + I11iIi1I . iIii1I11I1II1 % O0
    OOO0oOoO0O = I1111i
    if 43 - 43: iii1I1I - II
   except :
    pass
    if 70 - 70: II / O0oo0OO0 % OOoO - I1i1iI1i
  I1II1 = II111iI111I1I ( OOO0oOoO0O )
  I1i1i1iii = re . compile ( iiiIi1 ) . findall ( I1II1 )
  for OoOo000oOo0oo , i1I1i111Ii , Ii1IIii11 , ooo , Ooo0oOooo0 in I1i1i1iii :
   try :
    if 47 - 47: II
    iIiIIii ( i1I1i111Ii , ooo , 147 , OoOo000oOo0oo , Ii1IIii11 , Ooo0oOooo0 )
    if 92 - 92: O0oo0OO0 + I11iIi1I % i1IIi
   except :
    pass
 except :
  pass
  if 23 - 23: ooO - O0oo0OO0 + I1i1iI1i - I11iIi1I * I11iIi1I . ii1IiI1i
def iIii11iI1II ( ) :
 if 42 - 42: OOoO - i1 + iii1I1I % I1i1iI1i
 try :
  if 44 - 44: i1IIi - O0 - iii1I1I * iii1I1I + I11iIi1I
  O0oo = II111iI111I1I ( dbsuperheroes )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( O0oo )
  for I1111i in I1i1i1iii :
   if 82 - 82: I11iIi1I + O0 - i11Ii11I1Ii1i % O00oOoOoO0o0O * i11iIiiIii
   try :
    if 15 - 15: IiiIII111iI
    OOO0oOoO0O = I1111i
    if 39 - 39: O0oo0OO0 / iii1I1I / i1 * ooO
   except :
    pass
    if 44 - 44: O0 + OOoO . iIii1I11I1II1 + ii1IiI1i / O0 - Oo0ooO0oo0oO
  I1II1 = II111iI111I1I ( OOO0oOoO0O )
  I1i1i1iii = re . compile ( iiiIi1 ) . findall ( I1II1 )
  for OoOo000oOo0oo , i1I1i111Ii , Ii1IIii11 , ooo , Ooo0oOooo0 in I1i1i1iii :
   try :
    if 83 - 83: i11Ii11I1Ii1i * Oo0ooO0oo0oO / ii1IiI1i
    iIiIIii ( i1I1i111Ii , ooo , 147 , OoOo000oOo0oo , Ii1IIii11 , Ooo0oOooo0 )
    if 32 - 32: IiiIII111iI + I11iIi1I - OoooooooOO
   except :
    pass
 except :
  pass
  if 39 - 39: OoooooooOO * O0oo0OO0 * O0 . Oo0ooO0oo0oO . OOooOOo + OOoO
def II1IIi ( ) :
 if 51 - 51: ii1IiI1i + O00oOoOoO0o0O / II - i1IIi
 try :
  if 51 - 51: ii1IiI1i - iii1I1I * Oo0ooO0oo0oO
  O0ooO00oO = II111iI111I1I ( dbgpelis )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( O0ooO00oO )
  for I1111i in I1i1i1iii :
   if 12 - 12: iIii1I11I1II1 % OOoO % OOoO
   try :
    if 78 - 78: i11Ii11I1Ii1i . I11iIi1I . Oo0ooO0oo0oO
    OOO0oOoO0O = I1111i
    if 97 - 97: O00oOoOoO0o0O
   except :
    pass
    if 80 - 80: i1 . I1i1iI1i
  I1II1 = II111iI111I1I ( OOO0oOoO0O )
  I1i1i1iii = re . compile ( iiiIi1 ) . findall ( I1II1 )
  for OoOo000oOo0oo , i1I1i111Ii , Ii1IIii11 , ooo , Ooo0oOooo0 in I1i1i1iii :
   try :
    if 47 - 47: Oo0ooO0oo0oO + OOoO + o0 % i11iIiiIii
    iIiIIii ( i1I1i111Ii , ooo , 147 , OoOo000oOo0oo , Ii1IIii11 , Ooo0oOooo0 )
    if 93 - 93: iii1I1I % I11iIi1I . O0 / II * O00oOoOoO0o0O
   except :
    pass
 except :
  pass
  if 29 - 29: IiiIII111iI
def oo0 ( ) :
 if 2 - 2: OoooooooOO
 try :
  if 60 - 60: OOooOOo
  O0ooO00oO = II111iI111I1I ( db )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( O0ooO00oO )
  for I1111i in I1i1i1iii :
   if 81 - 81: I11iIi1I % I1i1iI1i
   try :
    if 87 - 87: iIii1I11I1II1 . OoooooooOO * I11iIi1I
    OOO0oOoO0O = I1111i
    if 100 - 100: OOooOOo / i1IIi - i1 % I1i1iI1i - iIii1I11I1II1
   except :
    pass
    if 17 - 17: Oo0ooO0oo0oO / IiiIII111iI % ii1IiI1i
  I1II1 = II111iI111I1I ( OOO0oOoO0O )
  I1i1i1iii = re . compile ( iiiIi1 ) . findall ( I1II1 )
  for OoOo000oOo0oo , i1I1i111Ii , Ii1IIii11 , ooo , Ooo0oOooo0 in I1i1i1iii :
   try :
    if 71 - 71: i11Ii11I1Ii1i . ooO . OOooOOo
    iIiIIii ( i1I1i111Ii , ooo , 147 , OoOo000oOo0oo , Ii1IIii11 , Ooo0oOooo0 )
    if 68 - 68: i11iIiiIii % O00oOoOoO0o0O * OOooOOo * i11Ii11I1Ii1i * o0 + O0
   except :
    pass
 except :
  pass
  if 66 - 66: Oo0ooO0oo0oO % iii1I1I % OoooooooOO
def II11 ( ) :
 if 2 - 2: iIii1I11I1II1
 try :
  if 45 - 45: OoooooooOO / i11iIiiIii
  I11I1i1iI = II111iI111I1I ( db23 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( I11I1i1iI )
  for I1111i in I1i1i1iii :
   if 90 - 90: i11Ii11I1Ii1i * o0 % ooO + O00oOoOoO0o0O
   try :
    if 93 - 93: ooO + I1i1iI1i
    OOO0oOoO0O = I1111i
    if 33 - 33: O0
   except :
    pass
    if 78 - 78: O0 / o0 * OOooOOo
  I1II1 = II111iI111I1I ( OOO0oOoO0O )
  I1i1i1iii = re . compile ( iiiIi1 ) . findall ( I1II1 )
  for OoOo000oOo0oo , i1I1i111Ii , Ii1IIii11 , ooo , Ooo0oOooo0 in I1i1i1iii :
   try :
    if 50 - 50: OoooooooOO - iIii1I11I1II1 + i1IIi % ooO - iIii1I11I1II1 % O0
    iIiIIii ( i1I1i111Ii , ooo , 147 , OoOo000oOo0oo , Ii1IIii11 , Ooo0oOooo0 )
    if 58 - 58: i11Ii11I1Ii1i + iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 65 - 65: o0 - ooO % IiiIII111iI - I11iIi1I * II + I1i1iI1i
def O0o0O0OO0o ( ) :
 if 54 - 54: I11iIi1I . O00oOoOoO0o0O % i11iIiiIii / OoooooooOO + i11Ii11I1Ii1i % O00oOoOoO0o0O
 try :
  if 36 - 36: O00oOoOoO0o0O
  o0O0o0 = II111iI111I1I ( db4 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for I1111i in I1i1i1iii :
   if 74 - 74: OoooooooOO
   try :
    if 72 - 72: O0 + i1 - II - OOooOOo
    OOO0oOoO0O = I1111i
    if 100 - 100: O0
   except :
    pass
    if 79 - 79: iIii1I11I1II1
    if 81 - 81: O0oo0OO0 + iIii1I11I1II1 * ooO - iIii1I11I1II1 . O0oo0OO0
    if 48 - 48: Oo0ooO0oo0oO . OoooooooOO . i1 . I11iIi1I % iii1I1I / II
  I1II1 = II111iI111I1I ( OOO0oOoO0O )
  I1i1i1iii = re . compile ( iiiIi1 ) . findall ( I1II1 )
  for OoOo000oOo0oo , i1I1i111Ii , Ii1IIii11 , ooo , Ooo0oOooo0 in I1i1i1iii :
   try :
    if 11 - 11: i1IIi % OOooOOo % II
    iIiIIii ( i1I1i111Ii , ooo , 147 , OoOo000oOo0oo , Ii1IIii11 , Ooo0oOooo0 )
    if 99 - 99: OOoO / iIii1I11I1II1 - I1i1iI1i * iii1I1I % i1
   except :
    pass
 except :
  pass
  if 13 - 13: OOooOOo
def O0oo0O0 ( name , url ) :
 if 2 - 2: OoooooooOO . O0oo0OO0 . i11Ii11I1Ii1i
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 42 - 42: O0oo0OO0 % O00oOoOoO0o0O / OOooOOo - O00oOoOoO0o0O * i11iIiiIii
 OOOOoOo00OO = II111iI111I1I ( url )
 I1i1i1iii = re . compile ( I1IiiiiI ) . findall ( OOOOoOo00OO )
 for OoOo000oOo0oo , name , Ii1IIii11 , url , id in I1i1i1iii :
  try :
   if 19 - 19: O00oOoOoO0o0O * i1 % i11iIiiIii
   ooo00OOOooO = o0OO00 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % ooo00OOOooO + name + '[/COLOR]'
   iiI1Ii1I ( name , url , 130 , OoOo000oOo0oo , Ii1IIii11 , id )
   if 28 - 28: O0oo0OO0 % OOoO
   if 48 - 48: i11iIiiIii % O00oOoOoO0o0O
  except :
   pass
   if 29 - 29: II + i11iIiiIii % Oo0ooO0oo0oO
def iiI1Ii1I ( name , url , mode , iconimage , fanart , id ) :
 if 93 - 93: I11iIi1I % iIii1I11I1II1
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 90 - 90: i1 - O0oo0OO0 / I1i1iI1i / O0 / Oo0ooO0oo0oO
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + "&id=" + str ( id )
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , fanart )
 II1iIi1IiIii . setProperty ( 'IsPlayable' , 'true' )
 oOO0 = [ ]
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  oOO0 . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 15 - 15: ii1IiI1i + Oo0ooO0oo0oO . OOoO - iIii1I11I1II1 / O0 % iIii1I11I1II1
  II1iIi1IiIii . addContextMenuItems ( oOO0 , replaceItems = True )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii )
 return I111I11I111
 if 86 - 86: i1 / O00oOoOoO0o0O * I1i1iI1i
def O00o ( ) :
 if 86 - 86: iii1I1I * o0 * Oo0ooO0oo0oO
 if 74 - 74: iii1I1I / i11Ii11I1Ii1i
 oo0oO0oO = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 oo0oO0oO . doModal ( )
 if not oo0oO0oO . isConfirmed ( ) :
  return None ;
 i1I1i111Ii = oo0oO0oO . getText ( ) . strip ( )
 if 48 - 48: I11iIi1I % iii1I1I / Oo0ooO0oo0oO . iIii1I11I1II1 * o0
 if 65 - 65: I11iIi1I
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 31 - 31: Oo0ooO0oo0oO * I11iIi1I . i11Ii11I1Ii1i % I1i1iI1i + ii1IiI1i
  Ii1iiIi1I11i = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + i1I1i111Ii + '&language=es-ES' ) )
  if 89 - 89: ooO . i11Ii11I1Ii1i % ii1IiI1i . ii1IiI1i - OoooooooOO
  if 56 - 56: Oo0ooO0oo0oO
  return 'android'
  if 21 - 21: iIii1I11I1II1 / ooO + OOoO - Oo0ooO0oo0oO / ii1IiI1i / o0
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 69 - 69: i1 . I11iIi1I
  Ii1iiIi1I11i = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + i1I1i111Ii + '&language=es-ES' )
  if 53 - 53: Oo0ooO0oo0oO
  if 68 - 68: O00oOoOoO0o0O / ooO % ooO % O0
  return 'windows'
  if 90 - 90: i11Ii11I1Ii1i . OOoO / iIii1I11I1II1
  if 28 - 28: i11Ii11I1Ii1i + O00oOoOoO0o0O - OOoO / iIii1I11I1II1 - i1
def Ii1i1oOoO00 ( ) :
 if 45 - 45: I1i1iI1i . OoooooooOO
 try :
  if 27 - 27: I1i1iI1i * ii1IiI1i . I11iIi1I
  o0O0o0 = II111iI111I1I ( todas )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for I1111i in I1i1i1iii :
   if 17 - 17: o0 % II * O0oo0OO0 % i1IIi . i1 . iIii1I11I1II1
   try :
    if 27 - 27: i11iIiiIii - i1
    all = I1111i
    if 35 - 35: OoooooooOO - ooO / OOooOOo
   except :
    pass
    if 50 - 50: I11iIi1I
  OOOOoOo00OO = II111iI111I1I ( all )
  I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( OOOOoOo00OO )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
   try :
    if 33 - 33: Oo0ooO0oo0oO
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
    if 98 - 98: I11iIi1I % o0
   except :
    pass
 except :
  pass
  if 95 - 95: iIii1I11I1II1 - ooO - O0oo0OO0 + ooO % iii1I1I . i1
def IiiIIi1 ( ) :
 if 28 - 28: IiiIII111iI
 try :
  if 45 - 45: IiiIII111iI . i1 / ooO - ii1IiI1i * iIii1I11I1II1
  O0O0OoOO0 = o0OO00 . getSetting ( 'usuario' )
  iiiI1I11i1 = o0OO00 . getSetting ( 'mail' )
  IIi1i11111 = o0OO00 . getSetting ( 'claves' )
  if 86 - 86: o0 + OOoO + i11Ii11I1Ii1i
  IIi = II111iI111I1I ( O0O0ooOOO )
  I1i1i1iii = re . compile ( Ii1I1Ii ) . findall ( IIi )
  for OOii111IiiI1 , ooO0oOo0o , ii11i1iIiII1 in I1i1i1iii :
   if re . search ( IIi1i11111 , ii11i1iIiII1 ) :
    if 9 - 9: OOoO + o0 % OOoO % i11Ii11I1Ii1i + iIii1I11I1II1
    if O0O0OoOO0 == ooO0oOo0o and iiiI1I11i1 == OOii111IiiI1 and IIi1i11111 == ii11i1iIiII1 :
     if 59 - 59: i1IIi
     oO0o0o0ooO0oO = II111iI111I1I ( db )
     I1i1i1iii = re . compile ( OOoO0 ) . findall ( oO0o0o0ooO0oO )
     for I1111i in I1i1i1iii :
      if 48 - 48: O0 * I1i1iI1i * OOooOOo . OOooOOo * Oo0ooO0oo0oO - I1i1iI1i
      try :
       if 14 - 14: iii1I1I + i11iIiiIii
       OOO0oOoO0O = I1111i
       if 83 - 83: iii1I1I / i11iIiiIii + o0 . II * O0oo0OO0 + i11Ii11I1Ii1i
      except :
       pass
       if 42 - 42: i1IIi % o0 . OOoO
     I1II1 = II111iI111I1I ( OOO0oOoO0O )
     I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( I1II1 )
     for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
      try :
       if 7 - 7: iii1I1I - O00oOoOoO0o0O * O0oo0OO0 + IiiIII111iI . iii1I1I
       o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
       if 85 - 85: O0
      except :
       pass
       if 32 - 32: OoooooooOO . OOooOOo / ii1IiI1i * IiiIII111iI / IiiIII111iI * I1i1iI1i
    else :
     if 19 - 19: I1i1iI1i
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Esta seccion ha sido cerrada![COLOR orange] Lo sentimos ...[/COLOR] ,5000)" )
     if 55 - 55: O0oo0OO0 % O0oo0OO0 / O0 % II - IiiIII111iI . ii1IiI1i
     return False
     if 49 - 49: iIii1I11I1II1 * i1IIi . OoooooooOO
 except :
  pass
  if 90 - 90: IiiIII111iI % iii1I1I - iIii1I11I1II1 % I11iIi1I
def IIiI11I1I1i1i ( ) :
 if 86 - 86: i1IIi
 try :
  if 13 - 13: O0
  O0O0OoOO0 = o0OO00 . getSetting ( 'usuario' )
  iiiI1I11i1 = o0OO00 . getSetting ( 'mail' )
  IIi1i11111 = o0OO00 . getSetting ( 'claves' )
  if 70 - 70: I1i1iI1i . i11iIiiIii % I1i1iI1i . O0 - iIii1I11I1II1
  IIi = II111iI111I1I ( O0O0ooOOO )
  I1i1i1iii = re . compile ( Ii1I1Ii ) . findall ( IIi )
  for ooO0oOo0o , OOii111IiiI1 , ii11i1iIiII1 in I1i1i1iii :
   if re . search ( IIi1i11111 , ii11i1iIiII1 ) :
    if 26 - 26: O0oo0OO0
    if O0O0OoOO0 == ooO0oOo0o and iiiI1I11i1 == OOii111IiiI1 and IIi1i11111 == ii11i1iIiII1 :
     if 76 - 76: i1IIi * OoooooooOO * O0 + ooO * ooO
     oo0o0O00 = II111iI111I1I ( db1 )
     I1i1i1iii = re . compile ( OOoO0 ) . findall ( oo0o0O00 )
     for I1111i in I1i1i1iii :
      if 35 - 35: IiiIII111iI
      try :
       ooOoooo0 = I1111i
      except :
       pass
       if 54 - 54: i1IIi . Oo0ooO0oo0oO - iii1I1I + OOoO + ii1IiI1i / ii1IiI1i
     o0O0o0 = II111iI111I1I ( ooOoooo0 )
     I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( o0O0o0 )
     for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
      try :
       if 22 - 22: OOoO . iIii1I11I1II1
       o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
       if 12 - 12: I1i1iI1i
      except :
       pass
       if 71 - 71: i1 . o0 . i1 - OOoO
    else :
     if 45 - 45: i11Ii11I1Ii1i / O0 / I11iIi1I * O0oo0OO0
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Esta seccion ha sido cerrada![COLOR orange] Lo sentimos ...[/COLOR] ,5000)" )
     if 18 - 18: iIii1I11I1II1 + O0oo0OO0 + iIii1I11I1II1 . iii1I1I + ooO . OOoO
     return False
 except :
  pass
  if 7 - 7: iii1I1I + iIii1I11I1II1 * Oo0ooO0oo0oO * Oo0ooO0oo0oO / o0 - I1i1iI1i
  if 65 - 65: O00oOoOoO0o0O + I11iIi1I + o0
  if 77 - 77: o0
def Iii ( ) :
 if 7 - 7: ii1IiI1i * OoooooooOO % O0 - I1i1iI1i . I1i1iI1i
 try :
  if 80 - 80: I11iIi1I - o0
  O0O0OoOO0 = o0OO00 . getSetting ( 'usuario' )
  iiiI1I11i1 = o0OO00 . getSetting ( 'mail' )
  IIi1i11111 = o0OO00 . getSetting ( 'claves' )
  if 35 - 35: OOoO - OOooOOo . ii1IiI1i * ii1IiI1i / i11iIiiIii + iii1I1I
  IIi = II111iI111I1I ( O0O0ooOOO )
  I1i1i1iii = re . compile ( Ii1I1Ii ) . findall ( IIi )
  for OOii111IiiI1 , ooO0oOo0o , ii11i1iIiII1 in I1i1i1iii :
   if re . search ( IIi1i11111 , ii11i1iIiII1 ) :
    if 87 - 87: I11iIi1I % iIii1I11I1II1
    if O0O0OoOO0 == ooO0oOo0o and iiiI1I11i1 == OOii111IiiI1 and IIi1i11111 == ii11i1iIiII1 :
     if 72 - 72: O0oo0OO0 . O0oo0OO0 - iii1I1I
     o0O0o0 = II111iI111I1I ( db2 )
     I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
     for I1111i in I1i1i1iii :
      if 48 - 48: ii1IiI1i - OOoO + ii1IiI1i - i1 * i11iIiiIii . II
      try :
       if 35 - 35: i11Ii11I1Ii1i . O0 + ii1IiI1i + O0oo0OO0 + i1IIi
       OooOooO0O0o0 = I1111i
       if 59 - 59: ii1IiI1i + II - O0oo0OO0 . IiiIII111iI + i1 % O00oOoOoO0o0O
      except :
       pass
       if 37 - 37: II + II % IiiIII111iI
       if 29 - 29: OOoO
     o0O0o0 = II111iI111I1I ( OooOooO0O0o0 )
     I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( o0O0o0 )
     for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
      try :
       o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
       if 41 - 41: O0 % II
      except :
       pass
    else :
     if 10 - 10: II . i1IIi + I1i1iI1i
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Esta seccion ha sido cerrada![COLOR orange] Lo sentimos ...[/COLOR] ,5000)" )
     if 66 - 66: OOooOOo % IiiIII111iI
     return False
     if 21 - 21: I11iIi1I - OoooooooOO % i11iIiiIii
 except :
  pass
  if 71 - 71: i1IIi - Oo0ooO0oo0oO * ooO + O00oOoOoO0o0O - OOooOOo % iii1I1I
def Ooo0oO ( ) :
 if 32 - 32: i1IIi . II + o0 - OOooOOo - iIii1I11I1II1
 try :
  if 20 - 20: I11iIi1I % iii1I1I
  Ii = II111iI111I1I ( db26 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( Ii )
  for I1111i in I1i1i1iii :
   if 14 - 14: O0oo0OO0 % OoooooooOO
   try :
    if 86 - 86: i11iIiiIii + O0 * i11Ii11I1Ii1i - OOooOOo * O0oo0OO0 + O0
    Oo0 = I1111i
    if 94 - 94: ooO % o0 * i1IIi * iIii1I11I1II1
   except :
    pass
    if 81 - 81: ii1IiI1i - Oo0ooO0oo0oO
    if 24 - 24: OoooooooOO . OOooOOo * o0
  o0O0o0 = II111iI111I1I ( Oo0 )
  I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( o0O0o0 )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
   try :
    if 59 - 59: ooO + OOooOOo / O0oo0OO0
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
    if 97 - 97: ii1IiI1i * II % OOoO . II - ooO - O0oo0OO0
   except :
    pass
 except :
  pass
  if 79 - 79: i1 - OOoO
def I11I1ii1i ( ) :
 if 22 - 22: O00oOoOoO0o0O * I1i1iI1i * i11iIiiIii + II * I11iIi1I * OOooOOo
 try :
  if 85 - 85: II * O0oo0OO0 % ii1IiI1i - II - Oo0ooO0oo0oO
  o0O0o0 = II111iI111I1I ( db3 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for I1111i in I1i1i1iii :
   if 46 - 46: O0
   try :
    if 65 - 65: iIii1I11I1II1 % O00oOoOoO0o0O + O0 / OoooooooOO
    O0000oO0o00 = I1111i
    if 80 - 80: OoooooooOO + i11Ii11I1Ii1i
   except :
    pass
    if 95 - 95: ooO / O00oOoOoO0o0O * ooO - OoooooooOO * OoooooooOO % OOooOOo
    if 43 - 43: ii1IiI1i . ooO
  o0O0o0 = II111iI111I1I ( O0000oO0o00 )
  I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( o0O0o0 )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
    if 12 - 12: ooO + O0oo0OO0 + Oo0ooO0oo0oO . i11Ii11I1Ii1i / I1i1iI1i
   except :
    pass
 except :
  pass
  if 29 - 29: i11Ii11I1Ii1i . OOoO - o0
def ooooO0 ( ) :
 if 37 - 37: i11iIiiIii + i1 . O0oo0OO0 % Oo0ooO0oo0oO % Oo0ooO0oo0oO
 try :
  if 26 - 26: O0
  o0O0o0 = II111iI111I1I ( db4 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for I1111i in I1i1i1iii :
   if 34 - 34: OOoO * ooO
   try :
    if 97 - 97: i11iIiiIii % O00oOoOoO0o0O / ii1IiI1i / ii1IiI1i
    OoO00ooO = I1111i
    if 15 - 15: i11iIiiIii
   except :
    pass
    if 13 - 13: Oo0ooO0oo0oO * o0 * O00oOoOoO0o0O * o0 % i11Ii11I1Ii1i / i1
  o0O0o0 = II111iI111I1I ( OoO00ooO )
  I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( o0O0o0 )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
    if 100 - 100: i11Ii11I1Ii1i . I1i1iI1i - iIii1I11I1II1 . i11iIiiIii / o0
   except :
    pass
 except :
  pass
  if 71 - 71: ooO * ii1IiI1i . Oo0ooO0oo0oO
def i1ii1iiIi1II ( ) :
 if 98 - 98: OOooOOo - I1i1iI1i . i11Ii11I1Ii1i % i11iIiiIii
 try :
  if 69 - 69: iii1I1I + II * O0 . O0oo0OO0 % I11iIi1I
  o0O0o0 = II111iI111I1I ( db5 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for I1111i in I1i1i1iii :
   if 96 - 96: OOoO . OOoO - Oo0ooO0oo0oO / Oo0ooO0oo0oO
   try :
    if 96 - 96: i11iIiiIii / i1 - O0 . OOoO
    i11i = I1111i
    if 86 - 86: I1i1iI1i
   except :
    pass
    if 29 - 29: iIii1I11I1II1 - OOooOOo + i1 % iIii1I11I1II1 % O0oo0OO0
    if 84 - 84: i11Ii11I1Ii1i + iii1I1I + I1i1iI1i + II
  o0O0o0 = II111iI111I1I ( i11i )
  I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( o0O0o0 )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
    if 62 - 62: i11iIiiIii + I11iIi1I + i1IIi
   except :
    pass
 except :
  pass
  if 69 - 69: I11iIi1I
def OO0Oo ( ) :
 if 13 - 13: IiiIII111iI * i11iIiiIii / i11iIiiIii . OOooOOo . O0oo0OO0 . iii1I1I
 try :
  if 26 - 26: IiiIII111iI . iIii1I11I1II1
  o0O0o0 = II111iI111I1I ( db6 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for I1111i in I1i1i1iii :
   if 67 - 67: ii1IiI1i / O0
   try :
    if 88 - 88: I11iIi1I - O0oo0OO0
    o0oo0O0oOoooO = I1111i
    if 70 - 70: O00oOoOoO0o0O * O00oOoOoO0o0O + ii1IiI1i * O0oo0OO0 % i1 + iIii1I11I1II1
   except :
    pass
    if 2 - 2: i11iIiiIii
    if 98 - 98: O00oOoOoO0o0O / OOooOOo - I1i1iI1i - i1 / I11iIi1I + i11iIiiIii
  o0O0o0 = II111iI111I1I ( o0oo0O0oOoooO )
  I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( o0O0o0 )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
    if 17 - 17: Oo0ooO0oo0oO
   except :
    pass
 except :
  pass
  if 97 - 97: iii1I1I * iii1I1I / II
def i1111IIiI ( ) :
 if 49 - 49: O0oo0OO0 - I11iIi1I % IiiIII111iI % OOooOOo
 try :
  if 32 - 32: i11Ii11I1Ii1i
  o0O0o0 = II111iI111I1I ( db7 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for I1111i in I1i1i1iii :
   if 42 - 42: ooO + O0oo0OO0 + i11iIiiIii
   try :
    if 29 - 29: i1IIi + i1IIi
    o0Ooo0000 = I1111i
    if 74 - 74: II % o0 - O0oo0OO0 % OoooooooOO . O00oOoOoO0o0O
   except :
    pass
    if 11 - 11: i1 * i11iIiiIii / i11iIiiIii
    if 89 - 89: II . i11iIiiIii * O0
  o0O0o0 = II111iI111I1I ( o0Ooo0000 )
  I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( o0O0o0 )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
    if 44 - 44: i1IIi . i1 / i11iIiiIii + i11Ii11I1Ii1i
   except :
    pass
 except :
  pass
  if 27 - 27: O0oo0OO0
def O0OO0ooO00 ( ) :
 if 83 - 83: iIii1I11I1II1
 try :
  if 63 - 63: OoooooooOO * OOooOOo / Oo0ooO0oo0oO - O00oOoOoO0o0O . iIii1I11I1II1 + II
  o0O0o0 = II111iI111I1I ( db27 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for I1111i in I1i1i1iii :
   if 44 - 44: i1IIi % i1 % IiiIII111iI
   try :
    if 9 - 9: ii1IiI1i % OoooooooOO - I1i1iI1i
    iIII11Iiii1 = I1111i
    if 95 - 95: i1
   except :
    pass
    if 99 - 99: O0
    if 76 - 76: ooO - O00oOoOoO0o0O . O0oo0OO0 % IiiIII111iI
  o0O0o0 = II111iI111I1I ( iIII11Iiii1 )
  I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( o0O0o0 )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
    if 30 - 30: iii1I1I % Oo0ooO0oo0oO / ooO
   except :
    pass
 except :
  pass
  if 1 - 1: ooO - Oo0ooO0oo0oO
  if 45 - 45: I1i1iI1i - O0oo0OO0
def OOoooO00o0o ( ) :
 if 10 - 10: I1i1iI1i - i11iIiiIii . iii1I1I % i1IIi
 try :
  if 78 - 78: iIii1I11I1II1 * ii1IiI1i . ii1IiI1i - O0oo0OO0 . iIii1I11I1II1
  o0O0o0 = II111iI111I1I ( db8 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for I1111i in I1i1i1iii :
   if 30 - 30: OOoO + OOoO % i11Ii11I1Ii1i - IiiIII111iI - iii1I1I
   try :
    if 36 - 36: Oo0ooO0oo0oO % O0oo0OO0
    OoO0 = I1111i
    if 37 - 37: Oo0ooO0oo0oO
   except :
    pass
    if 83 - 83: O0
    if 89 - 89: ii1IiI1i + iii1I1I - IiiIII111iI
  o0O0o0 = II111iI111I1I ( OoO0 )
  I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( o0O0o0 )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
    if 40 - 40: OOooOOo + OOooOOo
   except :
    pass
 except :
  pass
  if 94 - 94: II * iIii1I11I1II1 . Oo0ooO0oo0oO
  if 13 - 13: iIii1I11I1II1 * I11iIi1I / ooO % OOoO + O00oOoOoO0o0O
def iiiI1iI1 ( ) :
 if 15 - 15: i11Ii11I1Ii1i . i1IIi * I11iIi1I % iIii1I11I1II1
 try :
  if 35 - 35: iii1I1I + ooO - I11iIi1I % O00oOoOoO0o0O % IiiIII111iI % I11iIi1I
  o0O0o0 = II111iI111I1I ( db9 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for I1111i in I1i1i1iii :
   if 45 - 45: i1 * O0oo0OO0 % OOooOOo
   try :
    if 24 - 24: OOoO - Oo0ooO0oo0oO * O00oOoOoO0o0O
    O00OoOoO = I1111i
    if 58 - 58: iii1I1I
   except :
    pass
    if 19 - 19: iIii1I11I1II1 * OoooooooOO * i11iIiiIii
    if 79 - 79: i11Ii11I1Ii1i % OOooOOo
  o0O0o0 = II111iI111I1I ( O00OoOoO )
  I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( o0O0o0 )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
    if 81 - 81: i11iIiiIii + i11iIiiIii * OOooOOo + i11Ii11I1Ii1i
   except :
    pass
    if 32 - 32: O0 . OoooooooOO
 except :
  pass
  if 15 - 15: i1 . OOooOOo
  if 17 - 17: i11iIiiIii / ii1IiI1i . OOooOOo / i1
def Ii1 ( ) :
 if 59 - 59: ii1IiI1i % O0 . I11iIi1I
 try :
  if 41 - 41: i1IIi + o0 * OOoO
  o0O0o0 = II111iI111I1I ( db10 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for I1111i in I1i1i1iii :
   if 68 - 68: I1i1iI1i - i1
   try :
    if 41 - 41: O00oOoOoO0o0O
    I11II1 = I1111i
    if 46 - 46: I11iIi1I
   except :
    pass
    if 83 - 83: i11iIiiIii * ooO
    if 49 - 49: ii1IiI1i * O00oOoOoO0o0O + IiiIII111iI - i11iIiiIii
  o0O0o0 = II111iI111I1I ( I11II1 )
  I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( o0O0o0 )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
    if 74 - 74: ii1IiI1i / iIii1I11I1II1 . o0 - OOooOOo
   except :
    pass
    if 62 - 62: O0oo0OO0 / o0 + I11iIi1I % OOoO / I11iIi1I + iii1I1I
 except :
  pass
  if 2 - 2: i11iIiiIii - ooO + OOooOOo % Oo0ooO0oo0oO * I1i1iI1i
def Ooo000O00 ( ) :
 if 36 - 36: O0oo0OO0 % i11iIiiIii
 try :
  if 47 - 47: i1IIi + o0 . ii1IiI1i * O00oOoOoO0o0O . Oo0ooO0oo0oO / i1IIi
  o0O0o0 = II111iI111I1I ( db11 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for I1111i in I1i1i1iii :
   if 50 - 50: ooO / i1IIi % OoooooooOO
   try :
    if 83 - 83: iii1I1I * iii1I1I + O0oo0OO0
    OooooOoO = I1111i
    if 79 - 79: OOoO % O0oo0OO0
   except :
    pass
    if 54 - 54: I11iIi1I - ooO
  o0O0o0 = II111iI111I1I ( OooooOoO )
  I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( o0O0o0 )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
    if 65 - 65: ooO . OOoO + O0oo0OO0 / ii1IiI1i + i11Ii11I1Ii1i % i1IIi
   except :
    pass
 except :
  pass
  if 28 - 28: i11iIiiIii + O0 / iii1I1I
  if 3 - 3: OOooOOo * i1IIi . i1 . O0 - I11iIi1I
def OOoooOoO0 ( ) :
 if 95 - 95: I1i1iI1i - iii1I1I - O0 . i1 . II
 try :
  if 7 - 7: ooO
  o0O0o0 = II111iI111I1I ( db12 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for I1111i in I1i1i1iii :
   if 45 - 45: O0 - O0oo0OO0
   try :
    if 56 - 56: O0 + I1i1iI1i
    IiI11II11 = I1111i
    if 46 - 46: iIii1I11I1II1 / iii1I1I
   except :
    pass
    if 7 - 7: iii1I1I / o0 - Oo0ooO0oo0oO + i1IIi + I1i1iI1i
    if 7 - 7: OOoO + I1i1iI1i
  o0O0o0 = II111iI111I1I ( IiI11II11 )
  I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( o0O0o0 )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
    if 32 - 32: iIii1I11I1II1 % i1 / i11iIiiIii + O0oo0OO0 - IiiIII111iI . II
   except :
    pass
 except :
  pass
  if 86 - 86: i1IIi / I1i1iI1i * i1
  if 67 - 67: iii1I1I * iii1I1I / O00oOoOoO0o0O * OoooooooOO + I11iIi1I
def oooo ( ) :
 if 63 - 63: OOoO % i1
 try :
  if 75 - 75: OOoO / ii1IiI1i
  o0O0o0 = II111iI111I1I ( db13 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for I1111i in I1i1i1iii :
   if 8 - 8: iIii1I11I1II1
   try :
    if 30 - 30: I1i1iI1i - i11iIiiIii
    i11I = I1111i
    if 56 - 56: II . ooO
   except :
    pass
  o0O0o0 = II111iI111I1I ( i11I )
  I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( o0O0o0 )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
    if 3 - 3: I1i1iI1i + ooO . i1IIi / O0oo0OO0 % ooO
   except :
    pass
 except :
  pass
  if 98 - 98: i11Ii11I1Ii1i * iIii1I11I1II1 . I1i1iI1i * ii1IiI1i / iii1I1I + OOoO
def iiI1ii111 ( ) :
 if 97 - 97: O0 / O0oo0OO0 + IiiIII111iI . O00oOoOoO0o0O % I11iIi1I - I11iIi1I
 try :
  if 33 - 33: Oo0ooO0oo0oO % o0 + OOooOOo
  o0O0o0 = II111iI111I1I ( db14 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for I1111i in I1i1i1iii :
   if 93 - 93: i1IIi . i11Ii11I1Ii1i / i1 + i11Ii11I1Ii1i
   try :
    if 58 - 58: iii1I1I + O0 . ii1IiI1i + I11iIi1I - OOooOOo - I11iIi1I
    IIiiIiII11iiiiiii = I1111i
    if 82 - 82: Oo0ooO0oo0oO / OOoO * Oo0ooO0oo0oO % i11iIiiIii * o0
   except :
    pass
    if 83 - 83: OOooOOo + O0oo0OO0 - IiiIII111iI + iIii1I11I1II1 % ii1IiI1i
    if 23 - 23: IiiIII111iI + I1i1iI1i % I11iIi1I % i1 % OoooooooOO
  o0O0o0 = II111iI111I1I ( IIiiIiII11iiiiiii )
  I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( o0O0o0 )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
    if 78 - 78: OOooOOo / ii1IiI1i - iIii1I11I1II1 - i11iIiiIii * II
   except :
    pass
 except :
  pass
  if 84 - 84: O0oo0OO0 + I1i1iI1i + IiiIII111iI
  if 33 - 33: I1i1iI1i
def ooOOO00oOOooO ( ) :
 if 46 - 46: iIii1I11I1II1 . i11iIiiIii - I11iIi1I % O0 / o0 * i1IIi
 try :
  if 66 - 66: O0
  o0O0o0 = II111iI111I1I ( db15 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for I1111i in I1i1i1iii :
   if 52 - 52: OOooOOo * OoooooooOO
   try :
    if 12 - 12: O0 + i11Ii11I1Ii1i * i1IIi . OOooOOo
    o0OO0oooo = I1111i
    if 40 - 40: ooO - I11iIi1I * Oo0ooO0oo0oO - i11Ii11I1Ii1i / I11iIi1I
   except :
    pass
    if 71 - 71: O00oOoOoO0o0O / OoooooooOO % i11Ii11I1Ii1i / I11iIi1I % ooO
    if 19 - 19: ooO + i11Ii11I1Ii1i / O00oOoOoO0o0O / o0
  o0O0o0 = II111iI111I1I ( o0OO0oooo )
  I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( o0O0o0 )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
    if 92 - 92: i1IIi % OOoO + OOoO - iIii1I11I1II1 . I1i1iI1i
   except :
    pass
 except :
  pass
  if 33 - 33: IiiIII111iI / O0 + O0oo0OO0
def o0Ooo0o0Oo ( ) :
 if 55 - 55: iIii1I11I1II1 * II
 try :
  if 85 - 85: iIii1I11I1II1 . o0
  o0O0o0 = II111iI111I1I ( db16 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for I1111i in I1i1i1iii :
   if 54 - 54: I1i1iI1i . OoooooooOO % ii1IiI1i
   try :
    if 22 - 22: O0oo0OO0
    I1I11Iiii111 = I1111i
    if 38 - 38: OOooOOo . OOoO
   except :
    pass
    if 34 - 34: i1IIi % i11Ii11I1Ii1i
    if 80 - 80: OoooooooOO / iIii1I11I1II1 + iii1I1I / i1IIi / IiiIII111iI
  o0O0o0 = II111iI111I1I ( I1I11Iiii111 )
  I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( o0O0o0 )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
    if 94 - 94: i1IIi
   except :
    pass
 except :
  pass
  if 36 - 36: i1 + ii1IiI1i
  if 46 - 46: II
def ooIiI11i1I11111 ( ) :
 if 34 - 34: i1 * I11iIi1I * O00oOoOoO0o0O + iii1I1I
 try :
  if 39 - 39: iii1I1I / i1IIi * i11Ii11I1Ii1i - i1
  o0O0o0 = II111iI111I1I ( db17 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for I1111i in I1i1i1iii :
   if 74 - 74: O0 - o0 + i1IIi . ooO . iii1I1I
   try :
    if 95 - 95: o0 / I1i1iI1i - OOoO - o0 - i11iIiiIii
    oO0O = I1111i
    if 25 - 25: O00oOoOoO0o0O % i1 + i11iIiiIii + O0 * OoooooooOO
   except :
    pass
    if 64 - 64: i1IIi
    if 10 - 10: ooO % O0 / i1 % Oo0ooO0oo0oO
  o0O0o0 = II111iI111I1I ( oO0O )
  I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( o0O0o0 )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
    if 25 - 25: o0 / OOooOOo
   except :
    pass
 except :
  pass
  if 64 - 64: O0 % OOoO
  if 40 - 40: IiiIII111iI + Oo0ooO0oo0oO
def OoO000Oo0oO ( ) :
 if 46 - 46: O0 - I11iIi1I . OoooooooOO
 try :
  if 19 - 19: IiiIII111iI
  o0O0o0 = II111iI111I1I ( db18 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for I1111i in I1i1i1iii :
   if 73 - 73: ooO * ii1IiI1i * I11iIi1I
   try :
    if 65 - 65: i11iIiiIii + ii1IiI1i * OoooooooOO - OOooOOo
    III11I11ii = I1111i
    if 82 - 82: O0oo0OO0 % o0 - O0oo0OO0 + o0
   except :
    pass
    if 61 - 61: i11iIiiIii * O00oOoOoO0o0O % ii1IiI1i * ooO - OoooooooOO - OOooOOo
    if 83 - 83: OOoO / O0oo0OO0
  o0O0o0 = II111iI111I1I ( III11I11ii )
  I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( o0O0o0 )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
    if 39 - 39: i11Ii11I1Ii1i + Oo0ooO0oo0oO
   except :
    pass
 except :
  pass
  if 9 - 9: i1 % Oo0ooO0oo0oO . ii1IiI1i * i1
  if 99 - 99: O0 . IiiIII111iI % Oo0ooO0oo0oO - ii1IiI1i / Oo0ooO0oo0oO
def iI1iii1i1III1 ( ) :
 if 17 - 17: o0 + i1
 try :
  if 59 - 59: iIii1I11I1II1 % I1i1iI1i . i11iIiiIii
  o0O0o0 = II111iI111I1I ( db19 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for I1111i in I1i1i1iii :
   if 59 - 59: IiiIII111iI . O00oOoOoO0o0O . I1i1iI1i * I11iIi1I * OOooOOo + ii1IiI1i
   try :
    if 90 - 90: ooO % ii1IiI1i - ii1IiI1i . iIii1I11I1II1 / O0oo0OO0 + Oo0ooO0oo0oO
    o0o00OOOO = I1111i
    if 42 - 42: OOoO * II
   except :
    pass
    if 2 - 2: II . OOooOOo / O00oOoOoO0o0O
    if 41 - 41: OOooOOo . ooO * i11Ii11I1Ii1i * ooO
  o0O0o0 = II111iI111I1I ( o0o00OOOO )
  I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( o0O0o0 )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
    if 74 - 74: iIii1I11I1II1 / IiiIII111iI
   except :
    pass
 except :
  pass
  if 58 - 58: iIii1I11I1II1 - i1 % IiiIII111iI % OoooooooOO * iIii1I11I1II1 + O0oo0OO0
  if 25 - 25: O0oo0OO0 % O0
def I11oO0oo ( ) :
 if 54 - 54: O0oo0OO0 . ooO * O00oOoOoO0o0O % ii1IiI1i - Oo0ooO0oo0oO
 try :
  if 74 - 74: iii1I1I - II * i1IIi
  o0O0o0 = II111iI111I1I ( db20 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for I1111i in I1i1i1iii :
   if 12 - 12: O0
   try :
    if 75 - 75: iIii1I11I1II1 % i11Ii11I1Ii1i + iii1I1I * O0 . II - OOoO
    i1IIiIIIi1 = I1111i
    if 84 - 84: O00oOoOoO0o0O + O0oo0OO0 . II
   except :
    pass
    if 71 - 71: OOoO / OOoO . I11iIi1I % II
  o0O0o0 = II111iI111I1I ( i1IIiIIIi1 )
  I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( o0O0o0 )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
    if 50 - 50: OOoO + II / Oo0ooO0oo0oO / Oo0ooO0oo0oO % O0
   except :
    pass
 except :
  pass
  if 87 - 87: ii1IiI1i + OOoO
  if 66 - 66: IiiIII111iI * O0oo0OO0 + I1i1iI1i * IiiIII111iI + O0oo0OO0 / OoooooooOO
def o0OOOoo0ooo00 ( ) :
 if 1 - 1: O0oo0OO0 - iIii1I11I1II1 * OOooOOo * ooO * O0
 try :
  if 98 - 98: OOoO . O0oo0OO0
  o0O0o0 = II111iI111I1I ( db21 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for I1111i in I1i1i1iii :
   if 60 - 60: OOooOOo - i1IIi . O0oo0OO0 + O0oo0OO0 * O0oo0OO0 + I1i1iI1i
   try :
    if 66 - 66: O0oo0OO0 * O0oo0OO0 / iIii1I11I1II1 + I11iIi1I . O0oo0OO0
    oOo00oOO = I1111i
    if 44 - 44: O0 . I1i1iI1i * II / i11iIiiIii
   except :
    pass
    if 56 - 56: I11iIi1I % iii1I1I - I1i1iI1i % iIii1I11I1II1
    if 76 - 76: OoooooooOO * OoooooooOO - II - iIii1I11I1II1 . OoooooooOO / iii1I1I
  o0O0o0 = II111iI111I1I ( oOo00oOO )
  I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( o0O0o0 )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
    if 86 - 86: OOoO
   except :
    pass
 except :
  pass
  if 51 - 51: OOooOOo - i11iIiiIii * i1
def OOOO0O0OOoo ( ) :
 if 82 - 82: o0 / II
 try :
  if 96 - 96: ii1IiI1i / O00oOoOoO0o0O . o0 . ii1IiI1i
  o0O0o0 = II111iI111I1I ( db22 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for I1111i in I1i1i1iii :
   if 91 - 91: o0 . O0oo0OO0 + IiiIII111iI
   try :
    if 8 - 8: O0oo0OO0 * ii1IiI1i / II - OOooOOo - OoooooooOO
    oOiIi = I1111i
    if 65 - 65: o0 + i1IIi * i11iIiiIii
   except :
    pass
  o0O0o0 = II111iI111I1I ( oOiIi )
  I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( o0O0o0 )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
    if 38 - 38: iIii1I11I1II1 + OoooooooOO * i1 % I11iIi1I % Oo0ooO0oo0oO - i11Ii11I1Ii1i
   except :
    pass
 except :
  pass
  if 56 - 56: OoooooooOO * ii1IiI1i * Oo0ooO0oo0oO + OOoO
def OOooOooO0o00 ( ) :
 if 71 - 71: Oo0ooO0oo0oO - OoooooooOO
 try :
  if 99 - 99: o0 - ooO + II * i11Ii11I1Ii1i / ooO
  o0O0o0 = II111iI111I1I ( db23 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for I1111i in I1i1i1iii :
   if 41 - 41: O0 . Oo0ooO0oo0oO
   try :
    if 95 - 95: O0
    O00OO0O = I1111i
    if 52 - 52: O0oo0OO0 * O00oOoOoO0o0O + Oo0ooO0oo0oO * Oo0ooO0oo0oO % i1IIi % Oo0ooO0oo0oO
   except :
    pass
  o0O0o0 = II111iI111I1I ( O00OO0O )
  I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( o0O0o0 )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
    if 96 - 96: IiiIII111iI * O00oOoOoO0o0O - O0oo0OO0 * IiiIII111iI * i1IIi
   except :
    pass
 except :
  pass
  if 8 - 8: OOoO - ii1IiI1i + iIii1I11I1II1 + i1IIi * I1i1iI1i - iIii1I11I1II1
def i1IiI1iIIIIIi ( ) :
 if 36 - 36: i11Ii11I1Ii1i
 try :
  if 19 - 19: I11iIi1I . IiiIII111iI . OoooooooOO
  o0O0o0 = II111iI111I1I ( db25 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for I1111i in I1i1i1iii :
   if 13 - 13: O0oo0OO0 . ii1IiI1i / o0
   try :
    if 43 - 43: iIii1I11I1II1 % OOooOOo
    oOO0ooi1iiIIiII1 = I1111i
    if 72 - 72: i11Ii11I1Ii1i % IiiIII111iI
   except :
    pass
  o0O0o0 = II111iI111I1I ( oOO0ooi1iiIIiII1 )
  I1i1i1iii = re . compile ( oO0O00OoOO0 ) . findall ( o0O0o0 )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 in I1i1i1iii :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , Ii1IIii11 )
    if 93 - 93: iIii1I11I1II1 + i11iIiiIii . IiiIII111iI . i1IIi % i1 % OOoO
   except :
    pass
 except :
  pass
  if 74 - 74: I11iIi1I / i1IIi % OoooooooOO
def o00o0o000Oo ( ) :
 if 100 - 100: i1IIi - i11iIiiIii . ooO * OOooOOo
 try :
  if 62 - 62: O0
  o0O0o0 = II111iI111I1I ( db24 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for I1111i in I1i1i1iii :
   if 41 - 41: i1IIi - i1
   try :
    if 48 - 48: i1 - o0 / OOooOOo + i1
    i1iii1IiiiI1i1 = I1111i
    if 37 - 37: ii1IiI1i - i1IIi - i11Ii11I1Ii1i + Oo0ooO0oo0oO . iIii1I11I1II1
   except :
    pass
  o0O0o0 = II111iI111I1I ( i1iii1IiiiI1i1 )
  I1i1i1iii = re . compile ( IiII ) . findall ( o0O0o0 )
  for oooO , i1I1i111Ii , ooo in I1i1i1iii :
   try :
    Oo00oOO00 ( oooO , i1I1i111Ii , ooo )
    if 21 - 21: OoooooooOO . o0 - i11Ii11I1Ii1i * OOoO * i11Ii11I1Ii1i
   except :
    pass
    if 45 - 45: O0 * ooO + i11iIiiIii - O0oo0OO0 - iIii1I11I1II1
 except :
  pass
  if 5 - 5: O0oo0OO0 % ii1IiI1i % i11Ii11I1Ii1i % OOoO
  if 17 - 17: I1i1iI1i + o0 + OoooooooOO / O0oo0OO0 / i11Ii11I1Ii1i
  if 80 - 80: IiiIII111iI % i1IIi / Oo0ooO0oo0oO
def Oo00oOO00 ( thumb , name , url ) :
 if 56 - 56: i1IIi . i11iIiiIii
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 if 15 - 15: o0 * O00oOoOoO0o0O % II / i11iIiiIii - O00oOoOoO0o0O + ii1IiI1i
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( ii111iI1iIi1 ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   II1IIIIiII1i ( name , url , '' , Oooo0000 , Ii1IIii11 )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 9 - 9: Oo0ooO0oo0oO - O00oOoOoO0o0O + O0 / II % i1IIi
  if 'tvg-logo' in thumb :
   thumb = re . compile ( ii111iI1iIi1 ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 97 - 97: IiiIII111iI * OOoO
   O0OOO0ooO00o ( name , url , 4 , OoOo000oOo0oo , Ii1IIii11 )
   if 24 - 24: ooO + OoooooooOO . i11Ii11I1Ii1i / I11iIi1I / Oo0ooO0oo0oO
  else :
   if 65 - 65: OoooooooOO
   O0OOO0ooO00o ( name , url , 4 , OoOo000oOo0oo , Ii1IIii11 )
   if 18 - 18: O0 - i1IIi . ooO
def o00OOo00 ( name , url , thumb , id , trailer ) :
 if 65 - 65: i1IIi
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 9 - 9: O00oOoOoO0o0O
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( ii111iI1iIi1 ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   II1IIIIiII1i ( name , url , '' , Oooo0000 , Ii1IIii11 )
 else :
  ooo00OOOooO = o0OO00 . getSetting ( 'Fontcolor' )
  if 2 - 2: iIii1I11I1II1 * i1 % i1IIi % iii1I1I + OoooooooOO + i1
  name = '[COLOR %s]' % ooo00OOOooO + name + '[/COLOR]'
  if 16 - 16: O0oo0OO0
  if 'tvg-logo' in thumb :
   thumb = re . compile ( ii111iI1iIi1 ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   oOoO0o00OO0 = o0OO00 . getSetting ( 'selecton' )
   if oOoO0o00OO0 == 'true' :
    if 63 - 63: II
    i1i1iIiI ( name , url , 1 , thumb , thumb , id , trailer )
    if 23 - 23: i11Ii11I1Ii1i + iIii1I11I1II1 % iIii1I11I1II1 / OOoO . O00oOoOoO0o0O + iIii1I11I1II1
   else :
    if 93 - 93: O00oOoOoO0o0O * IiiIII111iI / O0oo0OO0 - O0oo0OO0 . II / i1
    i1i1iIiI ( name , url , 130 , thumb , thumb , id , trailer )
    if 11 - 11: ooO - Oo0ooO0oo0oO % i11iIiiIii . iIii1I11I1II1 * i1 - ii1IiI1i
  else :
   if 73 - 73: O0 + OOoO - O0 / OoooooooOO * ii1IiI1i
   if oOoO0o00OO0 == 'true' :
    if 32 - 32: OOooOOo % i1 % II
    i1i1iIiI ( name , url , 1 , thumb , thumb , id , trailer )
    if 66 - 66: I11iIi1I + IiiIII111iI
   else :
    if 54 - 54: iii1I1I + iii1I1I + Oo0ooO0oo0oO % i1IIi % i11iIiiIii
    i1i1iIiI ( name , url , 130 , thumb , thumb , id , trailer )
    if 100 - 100: iii1I1I
def o0OOOoO0 ( name , url , thumb , id , trailer , description , fanart ) :
 if 96 - 96: i1 . i11Ii11I1Ii1i * o0 % i11Ii11I1Ii1i . ooO * i1IIi
 if 83 - 83: iIii1I11I1II1
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . strip ( )
 ooo00OOOooO = o0OO00 . getSetting ( 'Fontcolor' )
 fanart = fanart . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 name = '[COLOR %s]' % ooo00OOOooO + name + '[/COLOR]'
 if 97 - 97: i11iIiiIii + ii1IiI1i * O0oo0OO0 % II . i11Ii11I1Ii1i
 if 4 - 4: O0 . II - iIii1I11I1II1
 if 'tvg-logo' in thumb :
  thumb = re . compile ( ii111iI1iIi1 ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  if oOoO0o00OO0 == 'true' :
   I1iII11ii1 ( name , url , 1 , thumb , fanart , id , trailer , description )
  else :
   if 4 - 4: i11iIiiIii - O0oo0OO0 % iii1I1I * ooO % IiiIII111iI
   I1iII11ii1 ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 71 - 71: OOoO . OOoO - iIii1I11I1II1
 else :
  if 22 - 22: OoooooooOO / iii1I1I % II * I11iIi1I
  if oOoO0o00OO0 == 'true' :
   if 32 - 32: OoooooooOO % O00oOoOoO0o0O % iIii1I11I1II1 / O0
   I1iII11ii1 ( name , url , 1 , thumb , fanart , id , trailer , description )
   if 61 - 61: o0 . O0 - I1i1iI1i - iii1I1I / i11iIiiIii - o0
  else :
   if 98 - 98: I1i1iI1i - i1 . i11iIiiIii * ii1IiI1i
   I1iII11ii1 ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 29 - 29: I1i1iI1i / OOoO % Oo0ooO0oo0oO
   if 10 - 10: iIii1I11I1II1 % OoooooooOO % iii1I1I
def IiiI1i111I1i ( name , trailer ) :
 if 97 - 97: O0oo0OO0 % i1 * i1 % ii1IiI1i
 if Ii1i1 == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Realstream, Reproduciendo Trailer de: [COLOR green]" + name + "[/COLOR] ,5000)" )
  if 86 - 86: I1i1iI1i * i1IIi + O00oOoOoO0o0O
  ooo = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  iI1i1I11i = ooo
  iiiIii1iIi1Ii = xbmcgui . ListItem ( name , trailer , path = iI1i1I11i )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iiiIii1iIi1Ii )
 else :
  ooo = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  iI1i1I11i = ooo
  iiiIii1iIi1Ii = xbmcgui . ListItem ( name , trailer , path = iI1i1I11i )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iiiIii1iIi1Ii )
  if 13 - 13: i11Ii11I1Ii1i . i11Ii11I1Ii1i + iIii1I11I1II1 * ii1IiI1i
  if 85 - 85: O0oo0OO0 + o0 - O0oo0OO0 * O00oOoOoO0o0O - i1IIi % II
def oOo ( name , url ) :
 if 1 - 1: OoooooooOO / O0 + I11iIi1I + I11iIi1I . ooO - I11iIi1I
 if Ii1i1 == 'true' :
  if 9 - 9: ooO * OoooooooOO % i1 / I11iIi1I * Oo0ooO0oo0oO
  try :
   if 48 - 48: OoooooooOO . I11iIi1I
   iIiI1 = xbmcgui . DialogProgress ( )
   iIiI1 . create ( 'Realstream:' , 'Iniciando ...' )
   iIiI1 . update ( 30 , 'Realstream:' , 'Conectando al servidor ...' )
   xbmc . sleep ( 1000 )
   iIiI1 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   iIiI1 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   iIiI1 . close ( )
   if 65 - 65: O00oOoOoO0o0O . ii1IiI1i
   iI1i1I11i = url
   iiiIii1iIi1Ii = xbmcgui . ListItem ( name , path = iI1i1I11i )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iiiIii1iIi1Ii )
   if 94 - 94: I11iIi1I + i11Ii11I1Ii1i . OOoO
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. ,3000)" )
  if 69 - 69: O0 - O0
 else :
  if 41 - 41: i11Ii11I1Ii1i % IiiIII111iI
  try :
   if 67 - 67: O0 % ooO
   iIiI1 = xbmcgui . DialogProgress ( )
   iIiI1 . create ( 'Realstream:' , 'Iniciando ...' )
   iIiI1 . update ( 30 , 'Realstream:' , 'Conectando al servidor ...' )
   xbmc . sleep ( 1000 )
   iIiI1 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   iIiI1 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   iIiI1 . close ( )
   if 35 - 35: i1 . I11iIi1I + OoooooooOO % ii1IiI1i % O0oo0OO0
   iI1i1I11i = url
   iiiIii1iIi1Ii = xbmcgui . ListItem ( name , path = iI1i1I11i )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iiiIii1iIi1Ii )
   if 39 - 39: I1i1iI1i
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. ,3000)" )
  if 60 - 60: O0oo0OO0
 return
 if 62 - 62: ooO * Oo0ooO0oo0oO
 if 74 - 74: I11iIi1I . iIii1I11I1II1
def oOOoO0oO0oo0O ( trailer ) :
 if 55 - 55: ii1IiI1i
 if 'https://www.youtube.com' in trailer :
  if 35 - 35: iii1I1I * II . i11Ii11I1Ii1i . i11Ii11I1Ii1i - O00oOoOoO0o0O % I11iIi1I
  try :
   if 42 - 42: IiiIII111iI - iIii1I11I1II1 % OoooooooOO
   import resolveurl
   if 43 - 43: IiiIII111iI - ii1IiI1i
   iIIi1iI1I1IIi = resolveurl . HostedMediaFile ( ooo )
   iIiI1 = xbmcgui . DialogProgress ( )
   iIiI1 . create ( 'Realstream:' , 'Conectando al servidor ... ' )
   iIiI1 . update ( 20 , 'Por favor, espere ...' )
   xbmc . sleep ( 500 )
   if 85 - 85: o0 + ooO - OOoO * iIii1I11I1II1 % O00oOoOoO0o0O
   if not iIIi1iI1I1IIi :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    return False
    if 62 - 62: I1i1iI1i + O0 * OOooOOo
   try :
    if 59 - 59: o0
    iIiI1 . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    I1iI = iIIi1iI1I1IIi . resolve ( )
    if not I1iI or not isinstance ( I1iI , basestring ) :
     try : O0o00O0Oo0 = I1iI . msg
     except : O0o00O0Oo0 = I1iI
     raise Exception ( O0o00O0Oo0 )
   except Exception as O0o0O0 :
    try : O0o00O0Oo0 = str ( O0o0O0 )
    except : O0o00O0Oo0 = I1iI
    iIiI1 . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
    iIiI1 . close ( )
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    if 43 - 43: ii1IiI1i + OoooooooOO
   iIiI1 . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
   xbmc . sleep ( 500 )
   iIiI1 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   iIiI1 . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
   xbmc . sleep ( 500 )
   iIiI1 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   iIiI1 . close ( )
   if 47 - 47: OOoO
   O0iI = xbmcgui . ListItem ( path = I1iI )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0iI )
   if 92 - 92: Oo0ooO0oo0oO % i11iIiiIii % ii1IiI1i
  except :
   pass
   if 23 - 23: o0 * II
  else :
   if 80 - 80: ooO / i11iIiiIii + OoooooooOO
   ooo = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
   iI1i1I11i = ooo
   iiiIii1iIi1Ii = xbmcgui . ListItem ( trailer , path = iI1i1I11i )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iiiIii1iIi1Ii )
   return
   if 38 - 38: iii1I1I % OOoO + i1IIi * OoooooooOO * O00oOoOoO0o0O
def OoO0o0OO ( name , url ) :
 if 10 - 10: O00oOoOoO0o0O - II % o0 - ooO - i1IIi
 if '[Youtube]' in name :
  if 10 - 10: iii1I1I - Oo0ooO0oo0oO . ooO
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  iI1i1I11i = url
  iiiIii1iIi1Ii = xbmcgui . ListItem ( i1i1iI1iiiI , path = iI1i1I11i )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iiiIii1iIi1Ii )
  if 8 - 8: iIii1I11I1II1 % O00oOoOoO0o0O + ii1IiI1i
  if 24 - 24: IiiIII111iI / I1i1iI1i / I1i1iI1i % o0 - O00oOoOoO0o0O * O00oOoOoO0o0O
 else :
  if 58 - 58: I11iIi1I
  import resolveurl
  if 60 - 60: o0
  iIIi1iI1I1IIi = resolveurl . HostedMediaFile ( url )
  if 90 - 90: I11iIi1I
  if not iIIi1iI1I1IIi :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 37 - 37: I11iIi1I + O0 . O0 * ii1IiI1i % ooO / II
   if 18 - 18: OoooooooOO
  try :
   I1iI = iIIi1iI1I1IIi . resolve ( )
   if not I1iI or not isinstance ( I1iI , basestring ) :
    try : O0o00O0Oo0 = I1iI . msg
    except : O0o00O0Oo0 = url
    raise Exception ( O0o00O0Oo0 )
  except Exception as O0o0O0 :
   try : O0o00O0Oo0 = str ( O0o0O0 )
   except : O0o00O0Oo0 = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 57 - 57: OOoO . I11iIi1I * IiiIII111iI - OoooooooOO
  Ii1i1 = o0OO00 . getSetting ( 'notificar' )
  if Ii1i1 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  O0iI = xbmcgui . ListItem ( path = I1iI )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0iI )
  if 75 - 75: i11iIiiIii / IiiIII111iI . i11Ii11I1Ii1i . i1IIi . i1IIi / Oo0ooO0oo0oO
  if 94 - 94: OOoO + i1
 return
 if 56 - 56: I11iIi1I % IiiIII111iI
 if 40 - 40: O0oo0OO0 / i11Ii11I1Ii1i
def i1i11I1I1 ( name , url ) :
 if 82 - 82: OOooOOo - ii1IiI1i - O0 - OoooooooOO
 if 'mybox.com' in url :
  if 4 - 4: o0 - O00oOoOoO0o0O % ii1IiI1i * i11iIiiIii
  url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
  if 18 - 18: ii1IiI1i % O0
  try :
   if 66 - 66: iIii1I11I1II1 % i11iIiiIii / i1
   o0O0o0 = II111iI111I1I ( url )
   I1i1i1iii = re . compile ( OoOoO ) . findall ( o0O0o0 )
   for url , oO0oooooo , o0OO0Oo in I1i1i1iii :
    if 47 - 47: iii1I1I * O00oOoOoO0o0O + iIii1I11I1II1 - O00oOoOoO0o0O / i11Ii11I1Ii1i
    oO0oooooo = oO0oooooo . replace ( '","res":"2160",' , ' 2160 ' ) . replace ( '","res":"1080",' , ' 1080' ) . replace ( '","res":"720",' , ' 720' ) . replace ( '","res":"480",' , ' 480' ) . replace ( '","res":"360",' , ' 360' )
    url = url . replace ( '\/' , '/' )
    url = url . replace ( ',"type":"video/mp4",' , ' ' )
    o0OO0Oo = o0OO0Oo . replace ( 'spa' , 'Castellano:' ) . replace ( 'eng' , 'Ingles:' ) . replace ( 'spa1' , 'Latino:' ) . replace ( 'eng2' , 'Americano:' )
    name = '[COLOR white]' + o0OO0Oo + '[/COLOR] - [COLOR gold]' + oO0oooooo + '[/COLOR]'
    if 86 - 86: i11Ii11I1Ii1i
    ooOo = [ ]
    ooOo . append ( '[COLOR orange]Real Stream: [/COLOR][COLOR gold]1. Mostrar mas info. [Reiniciar][/COLOR]' )
    ooOo . append ( '[COLOR gold]2. Mostar otras calidades disponibles [/COLOR]' )
    ooOo . append ( '[COLOR gold]3. Ver en: %s [/COLOR]' % name )
    if 43 - 43: i1 / II / OOoO + iIii1I11I1II1 + OoooooooOO
    if 33 - 33: o0 - i11Ii11I1Ii1i - OOoO
    i1iIIIIIIiII1 = 'Seleccione una calidad e idioma:'
    iii11 = xbmcgui . Dialog ( )
    i1oO = iii11 . select ( i1iIIIIIIiII1 , ooOo )
    if 92 - 92: OOooOOo * i11Ii11I1Ii1i
    if 92 - 92: O00oOoOoO0o0O
    if 7 - 7: II
    if i1oO == 0 :
     if 73 - 73: OOooOOo % iii1I1I
     I111I11I111 = iii11 . ok ( "[COLOR darkpink]REALSTREAM:[/COLOR] " , "[COLOR gold]  Reiniciadas las opciones.  [/COLOR]" , "" )
     del iii11
     return
     if 32 - 32: O0oo0OO0 + II + iIii1I11I1II1 * ii1IiI1i
    elif i1oO == 1 :
     if 62 - 62: i11iIiiIii
     pass
     if 2 - 2: i1
     del iii11
     if 69 - 69: OoooooooOO / ii1IiI1i * ooO
     if 99 - 99: o0 * iIii1I11I1II1 % O0 * O00oOoOoO0o0O / o0 % OoooooooOO
    elif i1oO == 2 :
     if 14 - 14: i11Ii11I1Ii1i . i11Ii11I1Ii1i % OOoO
     oOo ( name , url )
     if 42 - 42: IiiIII111iI . O0oo0OO0 - OOoO
     return
     if 33 - 33: o0 / O0 / i11Ii11I1Ii1i - Oo0ooO0oo0oO - i1IIi
  except :
   pass
   if 8 - 8: i11iIiiIii . II / iIii1I11I1II1 / iii1I1I / i11Ii11I1Ii1i - I1i1iI1i
 elif 'uptostream.com' in url :
  if 32 - 32: IiiIII111iI . i1IIi * ii1IiI1i
  try :
   if 98 - 98: I1i1iI1i - o0 / i1 . O00oOoOoO0o0O * i11Ii11I1Ii1i . Oo0ooO0oo0oO
   o0O0o0 = II111iI111I1I ( url )
   I1i1i1iii = re . compile ( OoOoO ) . findall ( o0O0o0 )
   for url , oO0oooooo , o0OO0Oo in I1i1i1iii :
    if 25 - 25: i11iIiiIii / I11iIi1I - ooO / OOooOOo . IiiIII111iI . IiiIII111iI
    oO0oooooo = oO0oooooo . replace ( '","res":"2160",' , ' ' ) . replace ( '","res":"1080",' , ' ' ) . replace ( '","res":"720",' , ' ' ) . replace ( '","res":"480",' , ' ' ) . replace ( '","res":"360",' , ' ' )
    url = url . replace ( '\/' , '/' )
    url = url . replace ( ',"type":"video/mp4",' , ' ' )
    o0OO0Oo = o0OO0Oo . replace ( 'spa' , 'Castellano:' ) . replace ( 'eng' , 'Ingles:' ) . replace ( 'spa1' , 'Latino:' ) . replace ( 'eng2' , 'Americano:' )
    name = '[COLOR white]' + o0OO0Oo + '[/COLOR] - [COLOR gold]' + oO0oooooo + '[/COLOR]'
    if 6 - 6: O00oOoOoO0o0O . Oo0ooO0oo0oO
    ooOo = [ ]
    ooOo . append ( '[COLOR orange]Real Stream: [/COLOR][COLOR gold]1. Mostrar mas info. [Reiniciar][/COLOR]' )
    ooOo . append ( '[COLOR gold]2. Mostar otras calidades disponibles [/COLOR]' )
    ooOo . append ( '[COLOR gold]3. Ver en: %s [/COLOR]' % name )
    if 43 - 43: iii1I1I + IiiIII111iI
    if 50 - 50: O00oOoOoO0o0O % i1IIi * O0
    i1iIIIIIIiII1 = 'Seleccione una calidad e idioma:'
    iii11 = xbmcgui . Dialog ( )
    i1oO = iii11 . select ( i1iIIIIIIiII1 , ooOo )
    if 4 - 4: iIii1I11I1II1 . i1IIi
    if 63 - 63: iIii1I11I1II1 + i11Ii11I1Ii1i % i1IIi / i1 % o0
    if i1oO == 0 :
     if 60 - 60: IiiIII111iI . I11iIi1I % ooO / i1 / O0
     I111I11I111 = iii11 . ok ( "[COLOR darkpink]REALSTREAM:[/COLOR] " , "[COLOR gold]  Reiniciadas las opciones.  [/COLOR]" , "" )
     del iii11
     return
     if 19 - 19: i11iIiiIii . i1 + o0 / O0oo0OO0 . iii1I1I * OOoO
    elif i1oO == 1 :
     if 59 - 59: iIii1I11I1II1 / iii1I1I % OOoO
     pass
     if 84 - 84: iIii1I11I1II1 / i1 . I11iIi1I % Oo0ooO0oo0oO
     del iii11
     if 99 - 99: ii1IiI1i + i11iIiiIii
     if 36 - 36: I1i1iI1i * ooO * iIii1I11I1II1 - Oo0ooO0oo0oO % i11iIiiIii
     if 98 - 98: iIii1I11I1II1 - i1IIi + OOoO % Oo0ooO0oo0oO + OOoO / O00oOoOoO0o0O
     if 97 - 97: i11Ii11I1Ii1i % OOoO + o0 - i11Ii11I1Ii1i % OOooOOo + OOoO
    elif i1oO == 2 :
     if 31 - 31: IiiIII111iI
     oOo ( name , url )
     if 35 - 35: I11iIi1I + I1i1iI1i * OOoO / I11iIi1I
     return
     if 69 - 69: OOoO . O0oo0OO0 - i1
  except :
   pass
 else :
  if 29 - 29: i11iIiiIii . iii1I1I / i1 . O0oo0OO0 + i11iIiiIii
  Oo0ooOo0o = o0OO00 . getSetting ( 'licencia_addon' )
  oOO0O00Oo0O0o = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  ii1 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( '\x62\x61\x73\x65\x36\x34' )
  O00ooOo = o0OO00 . getSetting ( 'key_ext' )
  o0O0o0 = II111iI111I1I ( ii1 )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
  for oOO0o00O in I1i1i1iii :
   if 26 - 26: i11Ii11I1Ii1i / I1i1iI1i - OoooooooOO
   try :
    if 9 - 9: OoooooooOO * iii1I1I
    if 9 - 9: ii1IiI1i + II
    Oo0ooOo0o = o0OO00 . getSetting ( 'licencia_addon' )
    if 64 - 64: O0 * i1 / i1
    if 57 - 57: iii1I1I / OoooooooOO % iii1I1I . O0 / iii1I1I
    if Oo0ooOo0o == oOO0o00O :
     if 63 - 63: i11Ii11I1Ii1i + iIii1I11I1II1 + i1 + ooO
     if 72 - 72: OOooOOo + i11iIiiIii + iii1I1I
     if 'https://team.com' in url :
      if 96 - 96: O00oOoOoO0o0O % i1IIi / IiiIII111iI
      url = url . replace ( 'https://team.com' , 'https://verystream.com' )
      if 13 - 13: o0 - ii1IiI1i % i11iIiiIii + II
     if 'https://mybox.com' in url :
      if 88 - 88: O0 . O00oOoOoO0o0O % i1
      url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
      if 10 - 10: i1 + O0
      if 75 - 75: O0 % iIii1I11I1II1 / I11iIi1I % O0oo0OO0 / i11Ii11I1Ii1i
     if 'https://vidcloud.co/' in url :
      if 31 - 31: i11iIiiIii * I11iIi1I
      url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
      if 69 - 69: i11iIiiIii
     if 'https://gounlimited.to' in url :
      if 61 - 61: O0
      url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
      if 21 - 21: OOooOOo % iIii1I11I1II1 . OOooOOo
     if 'https://drive.com' in url :
      if 99 - 99: IiiIII111iI * O0oo0OO0 % O00oOoOoO0o0O * O00oOoOoO0o0O + OoooooooOO
      url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
      if 82 - 82: Oo0ooO0oo0oO / I11iIi1I - O0oo0OO0 / OOoO
      if 50 - 50: O0oo0OO0 + OOooOOo . i11iIiiIii + iii1I1I + i11iIiiIii
     import resolveurl
     if 31 - 31: O00oOoOoO0o0O * ooO . I11iIi1I * Oo0ooO0oo0oO
     iIIi1iI1I1IIi = resolveurl . HostedMediaFile ( url )
     if 28 - 28: i11Ii11I1Ii1i + i1 - ii1IiI1i % O0oo0OO0 . Oo0ooO0oo0oO + i1
     if 72 - 72: I1i1iI1i / ii1IiI1i / O00oOoOoO0o0O * I11iIi1I + O0oo0OO0
     if 58 - 58: IiiIII111iI % i1 . i1 * OOooOOo - i11Ii11I1Ii1i . OoooooooOO
     if 10 - 10: ooO
     if not iIIi1iI1I1IIi :
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
      return False
      if 48 - 48: II * i1IIi % OoooooooOO * I1i1iI1i * OOooOOo
     try :
      if 7 - 7: II . I1i1iI1i . II - ooO
      iIiI1 = xbmcgui . DialogProgress ( )
      iIiI1 . create ( 'Realstream:' , 'Iniciando ...' )
      iIiI1 . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
      xbmc . sleep ( 1000 )
      if 33 - 33: OOoO + OoooooooOO - OOooOOo / i1IIi / OoooooooOO
      I1iI = iIIi1iI1I1IIi . resolve ( )
      if not I1iI or not isinstance ( I1iI , basestring ) :
       if 82 - 82: iii1I1I / O0oo0OO0 - II / ii1IiI1i * OOooOOo
       try : O0o00O0Oo0 = I1iI . msg
       except : O0o00O0Oo0 = url
       raise Exception ( O0o00O0Oo0 )
       if 55 - 55: OoooooooOO
     except Exception as O0o0O0 :
      try : O0o00O0Oo0 = str ( O0o0O0 )
      except : O0o00O0Oo0 = url
      if 73 - 73: I11iIi1I - iii1I1I % ii1IiI1i + iii1I1I - O0 . OOooOOo
      if 38 - 38: O0
      if 79 - 79: i1IIi . O00oOoOoO0o0O
      for i1i1i11iI11II in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       II1 = 1
       iIiI1 . update ( 45 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % i1i1i11iI11II )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5  Puede cancelar cuando desee o esperar...,  1000)" % II1 )
       iIiI1 . close ( )
       if 27 - 27: i1
      for i1i1i11iI11II in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       II1 = 2
       iIiI1 . update ( 48 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % i1i1i11iI11II )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % II1 )
       iIiI1 . close ( )
      for i1i1i11iI11II in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       II1 = 3
       iIiI1 . update ( 50 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % i1i1i11iI11II )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % II1 )
       iIiI1 . close ( )
      for i1i1i11iI11II in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       II1 = 4
       iIiI1 . update ( 53 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % i1i1i11iI11II )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % II1 )
       iIiI1 . close ( )
      for i1i1i11iI11II in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       II1 = 5
       iIiI1 . update ( 55 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % i1i1i11iI11II )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % II1 )
       iIiI1 . close ( )
       if 27 - 27: iIii1I11I1II1 % Oo0ooO0oo0oO - ooO
      if iIiI1 . iscanceled ( ) :
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Cancelando !! , 2000)" )
       iIiI1 . close ( )
       break
       if 67 - 67: O0 / ooO * I1i1iI1i % OOoO . iii1I1I * O00oOoOoO0o0O
       if 9 - 9: o0 * i11iIiiIii . O0oo0OO0 - OOooOOo
       if 31 - 31: i11iIiiIii * I1i1iI1i . IiiIII111iI % O0oo0OO0 * iii1I1I % O0
     iIiI1 . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
     xbmc . sleep ( 500 )
     iIiI1 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
     xbmc . sleep ( 1000 )
     iIiI1 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
     iIiI1 . close ( )
     Ii1i1 = o0OO00 . getSetting ( 'notificar' )
     O0iI = xbmcgui . ListItem ( path = I1iI )
     xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0iI )
     if 77 - 77: OOooOOo + OOooOOo . OOoO * OoooooooOO + OOooOOo
     if 6 - 6: i1IIi - Oo0ooO0oo0oO
    else :
     if 89 - 89: OOoO - Oo0ooO0oo0oO . O0 % OoooooooOO . i11iIiiIii
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold] El addon no ha podido conectar al servidor.[/COLOR]" )
     return False
     if 35 - 35: o0 / I11iIi1I - O0 . o0
   except :
    pass
    if 55 - 55: ii1IiI1i % i1IIi * Oo0ooO0oo0oO
 return
 if 95 - 95: O0oo0OO0 / o0 - IiiIII111iI % ooO . Oo0ooO0oo0oO
def oo0o ( ) :
 if 75 - 75: II + iIii1I11I1II1
 OOoOooO0o = [ ]
 I1IiiiI = sys . argv [ 2 ]
 if len ( I1IiiiI ) >= 2 :
  iIiI1111 = sys . argv [ 2 ]
  O0OO00 = iIiI1111 . replace ( '?' , '' )
  if ( iIiI1111 [ len ( iIiI1111 ) - 1 ] == '/' ) :
   iIiI1111 = iIiI1111 [ 0 : len ( iIiI1111 ) - 2 ]
  i1111I = O0OO00 . split ( '&' )
  OOoOooO0o = { }
  for i1i1i11iI11II in range ( len ( i1111I ) ) :
   OoO00oo0 = { }
   OoO00oo0 = i1111I [ i1i1i11iI11II ] . split ( '=' )
   if ( len ( OoO00oo0 ) ) == 2 :
    OOoOooO0o [ OoO00oo0 [ 0 ] ] = OoO00oo0 [ 1 ]
 return OOoOooO0o
 if 96 - 96: i1IIi
 if 55 - 55: O00oOoOoO0o0O + O0oo0OO0 + I1i1iI1i
def OOoiII1I1i ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  pass
  if 6 - 6: O00oOoOoO0o0O / O0 / I1i1iI1i / i11Ii11I1Ii1i / O00oOoOoO0o0O . iIii1I11I1II1
def oo0O0 ( ) :
 iii11 = xbmcgui . Dialog ( )
 list = (
 Ii11I ,
 OoOOoo
 )
 if 38 - 38: O00oOoOoO0o0O + iIii1I11I1II1 * I1i1iI1i / OOooOOo + O0oo0OO0
 Iii11iI1I = iii11 . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=%s]Accede a themoviedb.com[/COLOR]' % oO0o0OOOO ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 79 - 79: i1 - II / Oo0ooO0oo0oO . ii1IiI1i
 if Iii11iI1I :
  if 100 - 100: O0
  if Iii11iI1I < 0 :
   return
  oOOO00Oo = list [ Iii11iI1I - 2 ]
  return oOOO00Oo ( )
 else :
  oOOO00Oo = list [ Iii11iI1I ]
  return oOOO00Oo ( )
 return
 if 48 - 48: o0 + o0 * i1IIi / I1i1iI1i
def iii11III1I ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 61 - 61: iii1I1I + iIii1I11I1II1 % IiiIII111iI
ooooooO0O = iii11III1I ( )
if 64 - 64: i11Ii11I1Ii1i * iIii1I11I1II1 . iii1I1I / Oo0ooO0oo0oO * iIii1I11I1II1
def Ii11I ( ) :
 if ooooooO0O == 'android' :
  Ii1iiIi1I11i = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  Ii1iiIi1I11i = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 4 - 4: OOoO % i11Ii11I1Ii1i . ooO
  if 91 - 91: iii1I1I + iIii1I11I1II1 % i11Ii11I1Ii1i
def OoOOoo ( ) :
 if 90 - 90: OOoO - Oo0ooO0oo0oO . OOooOOo + OOooOOo
 main ( )
 if 45 - 45: I11iIi1I / OoooooooOO . ooO % O0 * iii1I1I * ii1IiI1i
 if 65 - 65: IiiIII111iI + ooO - O0
 if 30 - 30: i11Ii11I1Ii1i - II - OOooOOo
def ii11 ( ) :
 iii11 = xbmcgui . Dialog ( )
 oOOooooO = (
 o000Ooo00o00O ,
 ooo0O0O0oo0
 )
 if 85 - 85: o0 + OOoO * Oo0ooO0oo0oO
 Iii11iI1I = iii11 . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 12 - 12: I1i1iI1i . i1 % IiiIII111iI
 if Iii11iI1I :
  if 28 - 28: I1i1iI1i - i1 % OOooOOo * ooO
  if Iii11iI1I < 0 :
   return
  oOOO00Oo = oOOooooO [ Iii11iI1I - 2 ]
  return oOOO00Oo ( )
 else :
  oOOO00Oo = oOOooooO [ Iii11iI1I ]
  return oOOO00Oo ( )
 return
 if 80 - 80: O0oo0OO0 * i11Ii11I1Ii1i
def iii11III1I ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 4 - 4: iIii1I11I1II1 . ooO + o0 % OoooooooOO
ooooooO0O = iii11III1I ( )
if 82 - 82: OoooooooOO / OOoO * Oo0ooO0oo0oO * O0 . iii1I1I
def o000Ooo00o00O ( ) :
 if ooooooO0O == 'android' :
  Ii1iiIi1I11i = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  Ii1iiIi1I11i = webbrowser . open ( 'https://olpair.com/' )
  if 21 - 21: o0 + ii1IiI1i
  if 59 - 59: O0oo0OO0 + i1 / o0 / I11iIi1I
def ooo0O0O0oo0 ( ) :
 if 80 - 80: I11iIi1I + iIii1I11I1II1 . i11Ii11I1Ii1i
 main ( )
 if 76 - 76: i1 * O0oo0OO0
 if 12 - 12: iIii1I11I1II1 / Oo0ooO0oo0oO % I1i1iI1i
def IIiiI11 ( name , url , id , trailer ) :
 iii11 = xbmcgui . Dialog ( )
 oOOooooO = (
 IiIII ,
 oO0oOOooO0 ,
 oo00o000O ,
 oo0O0 ,
 OooO0o
 )
 if 81 - 81: i1IIi / ooO % i11iIiiIii . iIii1I11I1II1 * I11iIi1I + OoooooooOO
 Iii11iI1I = iii11 . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % oO0o0OOOO ,

 '[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % oO0o0OOOO ,

 '[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % oO0o0OOOO ,

 '[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % oO0o0OOOO ,

 '[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % oO0o0OOOO ] )
 if 31 - 31: i1IIi % o0
 if Iii11iI1I :
  if 13 - 13: iIii1I11I1II1 - o0 % O0 . I1i1iI1i % OOooOOo
  if Iii11iI1I < 0 :
   return
  oOOO00Oo = oOOooooO [ Iii11iI1I - 5 ]
  return oOOO00Oo ( )
 else :
  oOOO00Oo = oOOooooO [ Iii11iI1I ]
  return oOOO00Oo ( )
 return
 if 2 - 2: OoooooooOO - I1i1iI1i % O00oOoOoO0o0O / i1 / IiiIII111iI
 if 3 - 3: o0 / O0oo0OO0
 if 48 - 48: OOoO . iii1I1I
def IiIII ( ) :
 if 49 - 49: i1IIi - I11iIi1I . ii1IiI1i + iIii1I11I1II1 - OOoO / ii1IiI1i
 i1i11I1I1 ( i1I1i111Ii , ooo )
 if 24 - 24: O00oOoOoO0o0O - II / OOoO
def oO0oOOooO0 ( ) :
 if 10 - 10: I11iIi1I * i1IIi
 IiiI1i111I1i ( i1I1i111Ii , i1i1iI1iiiI )
 if 15 - 15: Oo0ooO0oo0oO + i1IIi - o0 % i1
def oo00o000O ( ) :
 if 34 - 34: i1
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  o0OoOo0O00 = id
  if 9 - 9: O0oo0OO0
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % o0OoOo0O00 )
  if 38 - 38: Oo0ooO0oo0oO . OOooOOo . i11iIiiIii * OoooooooOO + II
 if Ii1i1 == 'true' :
  if 49 - 49: ii1IiI1i - OOooOOo / ooO / IiiIII111iI % O00oOoOoO0o0O
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + i1I1i111Ii + "[/COLOR] ,5000)" )
  if 38 - 38: IiiIII111iI . O00oOoOoO0o0O / IiiIII111iI % o0
def I11iI1iIii1ii ( ) :
 if 70 - 70: O0 / OoooooooOO + iii1I1I + i1IIi
 oo0O0 ( )
 if 63 - 63: II / iii1I1I * O00oOoOoO0o0O / o0 + O0oo0OO0 - O0
def OooO0o ( ) :
 if 16 - 16: o0 / I1i1iI1i . I1i1iI1i - I1i1iI1i / iii1I1I
 ii1O0 ( )
def II1IIIIiII1i ( name , url , mode , iconimage , fanart ) :
 if 28 - 28: O0oo0OO0 * OoooooooOO + OOoO % II . iIii1I11I1II1
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 I111I11I111 = True
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  oOO0oo = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii , isFolder = True )
  return I111I11I111
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii , isFolder = True )
 return I111I11I111
 if 17 - 17: i11Ii11I1Ii1i / IiiIII111iI . O0oo0OO0 + IiiIII111iI / iii1I1I . ii1IiI1i
def iIiIIii ( name , url , mode , iconimage , fanart , description ) :
 if 39 - 39: IiiIII111iI / i11Ii11I1Ii1i - II
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 I111I11I111 = True
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , fanart )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii , isFolder = True )
 return I111I11I111
 if 96 - 96: Oo0ooO0oo0oO * iii1I1I * I1i1iI1i + iii1I1I % i1 + i11iIiiIii
def i1iI11Ii1i ( name , url , mode , iconimage ) :
 if 45 - 45: i1 . ii1IiI1i . ooO / O00oOoOoO0o0O
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 I111I11I111 = True
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , Ii1IIii11 )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii , isFolder = True )
 return I111I11I111
 if 4 - 4: i11iIiiIii + O0oo0OO0
 if 26 - 26: II * ooO * O00oOoOoO0o0O * I11iIi1I
def i1i1iIiI ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 48 - 48: II % i11iIiiIii . OoooooooOO * i11Ii11I1Ii1i % OOooOOo . II
 IiIIIi1iIi = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( '\x62\x61\x73\x65\x36\x34' )
 if 6 - 6: O0 . OOoO - O00oOoOoO0o0O / i11iIiiIii
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 oOO0 = [ ]
 if 84 - 84: Oo0ooO0oo0oO / iii1I1I * IiiIII111iI * OOooOOo * O0oo0OO0 * O0
 oOO0 . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , fanart )
 II1iIi1IiIii . setProperty ( 'IsPlayable' , 'true' )
 if 83 - 83: O0 % o0 + IiiIII111iI / OoooooooOO
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  oOO0 . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 75 - 75: o0 . i1 + O0oo0OO0 - I11iIi1I - O0 . Oo0ooO0oo0oO
  II1iIi1IiIii . addContextMenuItems ( oOO0 , replaceItems = True )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii )
 return I111I11I111
 if 19 - 19: I1i1iI1i * i1IIi % O0 + Oo0ooO0oo0oO
 if 25 - 25: ooO - I1i1iI1i / O0 . OoooooooOO % i1 . i1IIi
def I1iII11ii1 ( name , url , mode , iconimage , fanart , id , trailer , description ) :
 if 19 - 19: o0 / o0 % iii1I1I + O00oOoOoO0o0O + O00oOoOoO0o0O + II
 IiIIIi1iIi = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( '\x62\x61\x73\x65\x36\x34' )
 if 4 - 4: IiiIII111iI + Oo0ooO0oo0oO / II + i1IIi % IiiIII111iI % II
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 oOO0 = [ ]
 if 80 - 80: I1i1iI1i
 oOO0 . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , fanart )
 II1iIi1IiIii . setProperty ( 'IsPlayable' , 'true' )
 if 26 - 26: iIii1I11I1II1 . OoooooooOO - iIii1I11I1II1
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  oOO0 . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 59 - 59: iii1I1I + Oo0ooO0oo0oO . O00oOoOoO0o0O
  II1iIi1IiIii . addContextMenuItems ( oOO0 , replaceItems = True )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii )
 return I111I11I111
 if 87 - 87: OOooOOo
def O0OOO0ooO00o ( name , url , mode , iconimage , fanart ) :
 if 34 - 34: ooO . I11iIi1I / i11iIiiIii / II
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 46 - 46: ii1IiI1i + o0 * i1 + O0oo0OO0
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , fanart )
 II1iIi1IiIii . setProperty ( 'IsPlayable' , 'true' )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii )
 return I111I11I111
 if 31 - 31: I1i1iI1i * IiiIII111iI * I1i1iI1i + OOooOOo * IiiIII111iI . ooO
def Oo00oo00o00Oo ( name , url , mode , iconimage ) :
 if 1 - 1: i11Ii11I1Ii1i
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 31 - 31: i1IIi
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , Ii1IIii11 )
 II1iIi1IiIii . setProperty ( 'IsPlayable' , 'true' )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii )
 return I111I11I111
 if 21 - 21: i1IIi
def OOOO00 ( name , url , mode , iconimage ) :
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 I111I11I111 = True
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii , isFolder = True )
 return I111I11I111
 if 92 - 92: Oo0ooO0oo0oO % O0 % I1i1iI1i . I1i1iI1i . i11Ii11I1Ii1i
def OOoO0Oo ( ) :
 if 61 - 61: i1 + O00oOoOoO0o0O % ooO % iIii1I11I1II1 - OoooooooOO
 if 22 - 22: O0oo0OO0 + o0 + ii1IiI1i
 if 83 - 83: OOoO
 i1ii1I1111ii1 = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 i1ii1I1111ii1 . doModal ( )
 if ( i1ii1I1111ii1 . isConfirmed ( ) ) :
  if 43 - 43: O0oo0OO0
  o0000oO = urllib . quote_plus ( i1ii1I1111ii1 . getText ( ) ) . replace ( '+' , ' ' )
  if 84 - 84: O0oo0OO0 . i11Ii11I1Ii1i . II
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 2 - 2: ii1IiI1i - I11iIi1I
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % o0000oO )
    if 49 - 49: I1i1iI1i + o0 / O00oOoOoO0o0O - I11iIi1I % I11iIi1I + i1
    if Ii1i1 == 'true' :
     if 54 - 54: OOoO % ii1IiI1i - O0oo0OO0
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + i1I1i111Ii + "[/COLOR] ,10000)" )
     if 16 - 16: iii1I1I * II / Oo0ooO0oo0oO
   except :
    if 46 - 46: o0
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 13 - 13: i11Ii11I1Ii1i + o0 % i1
    if 30 - 30: OoooooooOO - i11iIiiIii + O00oOoOoO0o0O / ii1IiI1i - i11iIiiIii
iIiI1111 = oo0o ( )
ooo = None
i1I1i111Ii = None
oo0o00o0 = None
OoOo000oOo0oo = None
id = None
i1i1iI1iiiI = None
if 84 - 84: I11iIi1I - ii1IiI1i . OOoO . i11Ii11I1Ii1i - ii1IiI1i
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 99 - 99: ooO
try :
 ooo = urllib . unquote_plus ( iIiI1111 [ "url" ] )
except :
 pass
try :
 i1I1i111Ii = urllib . unquote_plus ( iIiI1111 [ "name" ] )
except :
 pass
try :
 oo0o00o0 = int ( iIiI1111 [ "mode" ] )
except :
 pass
try :
 OoOo000oOo0oo = urllib . unquote_plus ( iIiI1111 [ "iconimage" ] )
except :
 pass
try :
 id = int ( iIiI1111 [ "id" ] )
except :
 pass
try :
 i1i1iI1iiiI = urllib . unquote_plus ( iIiI1111 [ "trailer" ] )
except :
 pass
 if 75 - 75: OOoO . O0oo0OO0 / i11Ii11I1Ii1i
 if 84 - 84: OoooooooOO . i1 / IiiIII111iI
print "Mode: " + str ( oo0o00o0 )
print "URL: " + str ( ooo )
print "Name: " + str ( i1I1i111Ii )
print "iconimage: " + str ( OoOo000oOo0oo )
print "id: " + str ( id )
print "trailer: " + str ( i1i1iI1iiiI )
if 86 - 86: ii1IiI1i % I11iIi1I
if 77 - 77: I1i1iI1i % O0oo0OO0 / O00oOoOoO0o0O
def Ii1I1i ( ) :
 if 91 - 91: OOooOOo / OOooOOo . o0 . OOoO - i1
 try :
  if 23 - 23: i1
  i1IIiI1iII = II111iI111I1I ( Ii1I1i )
  I1i1i1iii = re . compile ( OOoO0 ) . findall ( i1IIiI1iII )
  for I1 in I1i1i1iii :
   if 45 - 45: i1IIi % O0oo0OO0 % o0
   if I1 == 'si' :
    if 4 - 4: O00oOoOoO0o0O * i1 - OOoO / o0 + O0oo0OO0 / i11iIiiIii
    import resoveurl
    from resoveurl import common
    import random
    from random import choice
    oO0o0O = xbmc . Player ( )
    I1II11IiII = [ 'gtG1Y3_34ug' , '3d_ACcf0rDc' , 'AKpPeLAMY9I' , 'sVBa5hNZFHM' , '5ZCVhFmbAY0' ]
    iiI1ii1Iii11I = random . choice ( I1II11IiII )
    ooo = 'https://www.youtube.com/watch?v=%s' % iiI1ii1Iii11I
    ooo = resoveurl . HostedMediaFile ( ooo ) . resolve ( )
    oO0o0O . play ( ooo )
    if 41 - 41: iii1I1I + ii1IiI1i / i11Ii11I1Ii1i . I1i1iI1i * i1
    oOO0O0ooOOOo == 'false'
    if 91 - 91: OOoO - O00oOoOoO0o0O + O00oOoOoO0o0O
   else :
    if 14 - 14: iii1I1I * ooO % i1IIi / iii1I1I
    oOO0O0ooOOOo == 'false'
    if 48 - 48: ii1IiI1i
    return False
    if 75 - 75: iii1I1I - i11Ii11I1Ii1i * ii1IiI1i . OoooooooOO * ooO * i1
 except :
  pass
  if 30 - 30: I11iIi1I / O00oOoOoO0o0O / I1i1iI1i * IiiIII111iI * O00oOoOoO0o0O . i1
  if 93 - 93: I11iIi1I
  if 97 - 97: i11iIiiIii
if oo0o00o0 == None or ooo == None or len ( ooo ) < 1 :
 if 68 - 68: i11Ii11I1Ii1i * OOooOOo . Oo0ooO0oo0oO / I1i1iI1i . IiiIII111iI - i11iIiiIii
 if 49 - 49: ii1IiI1i / I1i1iI1i % Oo0ooO0oo0oO + O00oOoOoO0o0O - OOooOOo
 Oo0ooOo0o = o0OO00 . getSetting ( 'licencia_addon' )
 oOO0O00Oo0O0o = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 ii1 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( '\x62\x61\x73\x65\x36\x34' )
 O00ooOo = o0OO00 . getSetting ( 'key_ext' )
 o0O0o0 = II111iI111I1I ( ii1 )
 I1i1i1iii = re . compile ( OOoO0 ) . findall ( o0O0o0 )
 for oOO0o00O in I1i1i1iii :
  if 13 - 13: o0
  try :
   if 83 - 83: OoooooooOO . i1 + I1i1iI1i * O0 / O00oOoOoO0o0O
   if 8 - 8: i1IIi + o0 / I1i1iI1i + iii1I1I % I1i1iI1i - iIii1I11I1II1
   Oo0ooOo0o = o0OO00 . getSetting ( 'licencia_addon' )
   if 29 - 29: ii1IiI1i + o0
   if 95 - 95: O00oOoOoO0o0O
   if Oo0ooOo0o == oOO0o00O :
    if 48 - 48: Oo0ooO0oo0oO / iIii1I11I1II1 % o0
    ii1O0 ( )
    Iii1iI ( )
    if 39 - 39: i1IIi . iii1I1I / Oo0ooO0oo0oO / Oo0ooO0oo0oO
    oOO0O0ooOOOo = o0OO00 . getSetting ( 'videos_event' )
    if oOO0O0ooOOOo == 'true' :
     xbmc . sleep ( 3000 )
     Ii1I1i ( )
     if 100 - 100: OoooooooOO - OoooooooOO + i11Ii11I1Ii1i
   else :
    if 32 - 32: I11iIi1I * IiiIII111iI / OoooooooOO
    oO0o0OOOO = o0OO00 . getSetting ( 'MenuColor' )
    if 90 - 90: ooO
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Por favor compruebe los ajustes de realstream.[/COLOR]" , "[COLOR white] Desde la seccion Tutoriales puede sacarle mayor partido a su Realstream, tambien puede configurarlo a su gusto. [/COLOR]" , "[COLOR gold]El addon no esta activado o bien configurado.[/COLOR]" )
    if 35 - 35: o0 / I1i1iI1i
  except :
   pass
   if 79 - 79: I11iIi1I + ooO * II * I1i1iI1i
elif oo0o00o0 == 1 :
 IIiiI11 ( i1I1i111Ii , ooo , id , i1i1iI1iiiI )
elif oo0o00o0 == 2 :
 iI1I1II1 ( )
elif oo0o00o0 == 3 :
 Oo0O0Oo00O ( )
elif oo0o00o0 == 4 :
 OoO0o0OO ( i1I1i111Ii , ooo )
elif oo0o00o0 == 5 :
 I11I1ii1i ( )
elif oo0o00o0 == 6 :
 O0o0O0OO0o ( )
elif oo0o00o0 == 7 :
 i1ii1iiIi1II ( )
elif oo0o00o0 == 8 :
 OO0Oo ( )
elif oo0o00o0 == 9 :
 i1111IIiI ( )
elif oo0o00o0 == 10 :
 OOoooO00o0o ( )
elif oo0o00o0 == 11 :
 iiiI1iI1 ( )
elif oo0o00o0 == 12 :
 Ii1 ( )
elif oo0o00o0 == 13 :
 I1iIiI1IiIIII ( )
elif oo0o00o0 == 14 :
 OOoooOoO0 ( )
elif oo0o00o0 == 15 :
 oooo ( )
elif oo0o00o0 == 16 :
 iiI1ii111 ( )
elif oo0o00o0 == 17 :
 ooOOO00oOOooO ( )
elif oo0o00o0 == 18 :
 o0Ooo0o0Oo ( )
elif oo0o00o0 == 19 :
 ooIiI11i1I11111 ( )
elif oo0o00o0 == 20 :
 OoO000Oo0oO ( )
elif oo0o00o0 == 21 :
 iI1iii1i1III1 ( )
elif oo0o00o0 == 22 :
 I11oO0oo ( )
elif oo0o00o0 == 23 :
 o0OOOoo0ooo00 ( )
elif oo0o00o0 == 24 :
 iIii11iI1II ( )
elif oo0o00o0 == 25 :
 II11 ( )
elif oo0o00o0 == 26 :
 O00Iii1111III111 ( )
elif oo0o00o0 == 28 :
 oOO0o000Oo00o ( i1I1i111Ii , ooo )
elif oo0o00o0 == 29 :
 Ooo0oO ( )
elif oo0o00o0 == 30 :
 II1IIi ( )
elif oo0o00o0 == 31 :
 prueba ( )
elif oo0o00o0 == 98 :
 busqueda_global ( )
elif oo0o00o0 == 97 :
 ii11 ( )
elif oo0o00o0 == 99 :
 O00o ( )
elif oo0o00o0 == 100 :
 menu_player ( i1I1i111Ii , ooo )
elif oo0o00o0 == 111 :
 o0o0O0O00oOOo ( )
elif oo0o00o0 == 115 :
 IiiI1i111I1i ( ooo )
elif oo0o00o0 == 116 :
 O00I11ii1i1 ( )
elif oo0o00o0 == 117 :
 oOOo000oOoO0 ( )
elif oo0o00o0 == 119 :
 oooOOoooo ( )
elif oo0o00o0 == 120 :
 OOo ( )
elif oo0o00o0 == 121 :
 Iiii ( )
elif oo0o00o0 == 125 :
 o00o0o000Oo ( )
elif oo0o00o0 == 112 :
 list_proxy ( )
elif oo0o00o0 == 127 :
 OOoO0Oo ( )
elif oo0o00o0 == 128 :
 TESTLINKS ( )
elif oo0o00o0 == 130 :
 i1i11I1I1 ( i1I1i111Ii , ooo )
elif oo0o00o0 == 140 :
 i11iiI1111 ( )
elif oo0o00o0 == 141 :
 oo0 ( )
elif oo0o00o0 == 142 :
 ii1I11iIiIII1 ( )
elif oo0o00o0 == 143 :
 iiIii1IIi ( i1I1i111Ii , ooo )
elif oo0o00o0 == 144 :
 oOO0o000Oo00o ( i1I1i111Ii , ooo )
elif oo0o00o0 == 145 :
 iii1 ( )
elif oo0o00o0 == 146 :
 iiooO0o0oO ( )
elif oo0o00o0 == 147 :
 O0oo0O0 ( i1I1i111Ii , ooo )
elif oo0o00o0 == 150 :
 OoO000O ( )
elif oo0o00o0 == 151 :
 IiIIiIIIiIii ( )
elif oo0o00o0 == 152 :
 i11111I1I ( )
elif oo0o00o0 == 155 :
 i1I1II1iIIi11 ( )
 if 53 - 53: O0oo0OO0 / ii1IiI1i
xbmcplugin . endOfDirectory ( i1iII1IiiIiI1 ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
