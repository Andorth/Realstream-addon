# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 1.1.2
#
############################################
# Dependencias 
# Script ExtendedInfo
# Script Urlresolver de TVAddons
# Script ResolveURL Por Jsergio.
#
############################################
#
# Agregar sinopsis a Peliculas y series.
# Supresion de Licencia
#
#
############################################
if 64 - 64: i11iIiiIii
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import urlresolver
import cookielib , base64
import requests
import plugintools
import config
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
IiII1IiiIiI1 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
o0OoOoOO00 = int ( sys . argv [ 1 ] )
I11i = 'gruponetai/'
O0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
Oo = O0O . getAddonInfo ( 'profile' )
I1ii11iIi11i = O0O . getAddonInfo ( 'path' )
I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
if 73 - 73: OOooOOo / ii11ii1ii
if 94 - 94: OoOO + OoOO0ooOOoo0O + o0000oOoOoO0o * o00O0oo
if I1IiI == 'true' :
 if 97 - 97: oO0o0ooO0 - IIII / O0oO - o0oO0
 oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.png' ) )
 o00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 Oo0oO0ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.png' ) )
 i1111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.png' ) )
 i11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'estrenos.png' ) )
 I11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.png' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.png' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.png' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.png' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.png' ) )
 oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.png' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.png' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.png' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.png' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.png' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.png' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.png' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'marvel.png' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.png' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.png' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.png' ) )
 II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.png' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.png' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.png' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.png' ) )
 OO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.png' ) )
 Ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.png' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.png' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.png' ) )
 O0OO00o0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.jpg' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.jpg' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
else :
 if 95 - 95: iiiIi1i1I % II11iII % OoOo
 if 18 - 18: iii11I111
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
 oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.jpg' ) )
 o00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 Oo0oO0ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.jpg' ) )
 i1111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.jpg' ) )
 i11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'encines.jpg' ) )
 I11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.jpg' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.jpg' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.jpg' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.jpg' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.jpg' ) )
 oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.jpg' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.jpg' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.jpg' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.jpg' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.jpg' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.jpg' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.jpg' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'superheroes.jpg' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.jpg' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.jpg' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.jpg' ) )
 II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.jpg' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.jpg' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.jpg' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.jpg' ) )
 OO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.jpg' ) )
 Ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.jpg' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.jpg' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.jpg' ) )
 O0OO00o0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.jpg' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.jpg' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.jpg' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favoritos.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
 if 63 - 63: OoOO * oO0o0ooO0 - iiiIi1i1I * O0
 if 17 - 17: o00O0oo % II111iiii
 if 13 - 13: OoOo % OoOO0ooOOoo0O - i11iIiiIii . OOooOOo + II111iiii
II111ii1II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'peliculas.png' ) )
OoOo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series.png' ) )
o0OOoo0OO0OOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ajustes.png' ) )
iI1iI1I1i1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'videoteca.png' ) )
iIi11Ii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
Ii11iII1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'resolver.png' ) )
Oo0O0O0ooO0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'test.png' ) )
IIIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'video-tutoriales.png' ) )
O0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'proxy.png' ) )
if 71 - 71: IIII + iii11I111 % i11iIiiIii + o00O0oo - II11iII
oO0OOoO0 = IiII1IiiIiI1 . getSetting ( 'mostrar_cat' )
I111Ii111 = IiII1IiiIiI1 . getSetting ( 'videos' )
i111IiI1I = IiII1IiiIiI1 . getSetting ( 'activar' )
O0iII = IiII1IiiIiI1 . getSetting ( 'favcopy' )
o0ooOooo000oOO = IiII1IiiIiI1 . getSetting ( 'anticopia' )
Oo0oOOo = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
OOO00O = IiII1IiiIiI1 . getSetting ( 'mostrar_bus' )
OOoOO0oo0ooO = IiII1IiiIiI1 . getSetting ( 'restante' )
O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'selecton' )
O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'aviso' )
i1Oo00 = IiII1IiiIiI1 . getSetting ( 'RealStream_Settings' )
i1i = IiII1IiiIiI1 . getSetting ( 'Resolver_Settings' )
OOoOO0oo0ooO = IiII1IiiIiI1 . getSetting ( 'restante' )
iiI111I1iIiI = IiII1IiiIiI1 . getSetting ( 'fav' )
IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
oooooOoo0ooo = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
I1I1IiI1 = 'bienvenida'
III1iII1I1ii = 'bienvenida'
copyright = IiII1IiiIiI1 . getSetting ( 'copyright' )
oOOo0 = 'cGx1Z2luLnZpZGVvLg==' . decode ( 'base64' ) + copyright
oo00O00oO = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
iIiIIIi = IiII1IiiIiI1 . getSetting ( 'Forceupdate' )
if iIiIIIi == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
ooo00OOOooO = 'LnR4dA==' . decode ( 'base64' )
if 67 - 67: O0oO * oO0o0ooO0 * o00O0oo + IIII / i1IIi
I1I111 = 'aHR0cDovL2JpdC5seS8yU1FOSnlP' . decode ( 'base64' )
Oo00oo0oO = oooooOoo0ooo + I1I1IiI1 + ooo00OOOooO
IIiIi1iI = 'http://www.youtube.com'
i1IiiiI1iI = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
i1iIi = 'http://bit.ly/2ImelUx'
ooOOoooooo = '.xsl.pt'
II1I = 'L21hc3Rlci8=' . decode ( 'base64' )
O0i1II1Iiii1I11 = i1IiiiI1iI + ooOOoooooo
IIIIiiIiI = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*'
o00oooO0Oo = 'tvg-logo=[\'"](.*?)[\'"]'
if 78 - 78: o0oO0 % OoOo + o00O0oo
OOooOoooOoOo = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.*)'
o0OOOO00O0Oo = '(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)'
ii = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
oOooOOOoOo = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
i1Iii1i1I = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
OOoO00 = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
IiI111111IIII = '#(.+?),(.+)\s*(.+)'
i1Ii = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
if 14 - 14: iiiIi1i1I
I1iI1iIi111i = 'source src=[\'"](.*?)[\'"]\s*title=[\'"](.*?)[\'"]'
iiIi1IIi1I = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
o0OoOO000ooO0 = '[\'"](.*?)[\'"]'
o0o0o0oO0oOO = r'066">\s*(.+)</f'
ii1Ii11I = '[\'"](.*?)[\'"]'
o00o0 = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
iiOOooooO0Oo = '[\'"](.*?)[\'"]'
OO = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( 'base64' )
iIiIIi1 = OO + I11i
I1IIII1i = '[\'"](.*?)[\'"]'
I1I11i = 'UmVhbHN0cmVhbQ==' . decode ( 'base64' )
Ii1I1I1i1Ii = 'video=[\'"](.*?)[\'"]'
i1Oo0oO00o = '0110nhu' . replace ( '0110nhu' , 'nhu' )
i11I1II1I11i = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( 'base64' ) + i1Oo0oO00o
OooOoOO0 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
iI1i11iII111 = '0110R0N' . replace ( '0110R0N' , 'R0N' )
Iii1IIII11I = 'aHR0cDovL2JpdC5seS8yWEIx' . decode ( 'base64' ) + iI1i11iII111
OOOoo0OO = '0110pEJ' . replace ( '0110pEJ' , 'pEJ' )
oO0o0 = 'aHR0cDovL2JpdC5seS8yd1Nh' . decode ( 'base64' ) + OOOoo0OO
iI1Ii11iIiI1 = 'ABBAOb5' . replace ( 'ABBAOb5' , 'Ob5' )
OO0Oooo0oOO0O = 'aHR0cDovL2JpdC5seS8yRVhV' . decode ( 'base64' ) + iI1Ii11iIiI1
o00O0 = '0110jaw' . replace ( '0110jaw' , 'jaw' )
oOO0O00Oo0O0o = 'aHR0cDovL2JpdC5seS8yd01M' . decode ( 'base64' ) + o00O0
ii1 = '01109DI' . replace ( '01109DI' , '9DI' )
I1iIIiiIIi1i = 'aHR0cDovL2JpdC5seS8ySXgz' . decode ( 'base64' ) + ii1
O0O0ooOOO = '01103hs' . replace ( '01103hs' , '3hs' )
oOOo0O00o = 'aHR0cDovL2JpdC5seS8zMW1U' . decode ( 'base64' ) + O0O0ooOOO
iIiIi11 = '01107DW' . replace ( '01107DW' , '7DW' )
OOO = 'aHR0cDovL2JpdC5seS8yV1ln' . decode ( 'base64' ) + iIiIi11
iiiiI = '0110mLl' . replace ( '0110mLl' , 'mLl' )
oooOo0OOOoo0 = 'aHR0cDovL2JpdC5seS8yS0cw' . decode ( 'base64' ) + iiiiI
OOoO = '01102Hj' . replace ( '01102Hj' , '2Hj' )
OO0O000 = 'aHR0cDovL2JpdC5seS8yWEJo' . decode ( 'base64' ) + OOoO
iiIiI1i1 = '0110fXg' . replace ( '0110fXg' , 'fXg' )
oO0O00oOOoooO = 'aHR0cDovL2JpdC5seS8ySTVy' . decode ( 'base64' ) + iiIiI1i1
IiIi11iI = '0110NMH' . replace ( '0110NMH' , 'NMH' )
Oo0O00O000 = 'aHR0cDovL2JpdC5seS8yd0t6' . decode ( 'base64' ) + IiIi11iI
i11I1IiII1i1i = '0110bwQ' . replace ( '0110bwQ' , 'bwQ' )
oo = 'aHR0cDovL2JpdC5seS8yd01V' . decode ( 'base64' ) + i11I1IiII1i1i
I1111i = '0110xzG' . replace ( '0110xzG' , 'xzG' )
iIIii = 'aHR0cDovL2JpdC5seS8yWHhz' . decode ( 'base64' ) + I1111i
o00O0O = '0110x64' . replace ( '0110x64' , 'x64' )
ii1iii1i = 'aHR0cDovL2JpdC5seS8yRVlF' . decode ( 'base64' ) + o00O0O
Iii1I1111ii = '0110vUE' . replace ( '0110vUE' , 'vUE' )
ooOoO00 = 'aHR0cDovL2JpdC5seS8yWmhW' . decode ( 'base64' ) + Iii1I1111ii
Ii1IIiI1i = '01107ZL' . replace ( '01107ZL' , '7ZL' )
o0O00Oo0 = 'aHR0cDovL2JpdC5seS8yWm4w' . decode ( 'base64' ) + Ii1IIiI1i
IiII111i1i11 = '01106cf' . replace ( '01106cf' , '6cf' )
i111iIi1i1II1 = 'aHR0cDovL2JpdC5seS8yRVlk' . decode ( 'base64' ) + IiII111i1i11
oooO = '0110Jtp' . replace ( '0110Jtp' , 'Jtp' )
i1I1i111Ii = 'aHR0cDovL2JpdC5seS8yV3Nq' . decode ( 'base64' ) + oooO
ooo = '0110a5b' . replace ( '0110a5b' , 'a5b' )
i1i1iI1iiiI = 'aHR0cDovL2JpdC5seS8yV3dj' . decode ( 'base64' ) + ooo
Ooo0oOooo0 = '0110Q7u' . replace ( '0110Q7u' , 'Q7u' )
oOOOoo00 = 'aHR0cDovL2JpdC5seS8yV3NL' . decode ( 'base64' ) + Ooo0oOooo0
iiIiIIIiiI = '0110rsq' . replace ( '0110rsq' , 'rsq' )
iiI1IIIi = 'aHR0cDovL2JpdC5seS8ySzhE' . decode ( 'base64' ) + iiIiIIIiiI
II11IiIi11 = '0110DDR' . replace ( '0110DDR' , 'DDR' )
IIOOO0O00O0OOOO = 'aHR0cDovL2JpdC5seS8ySzd5' . decode ( 'base64' ) + II11IiIi11
I1iiii1I = '0110feQ' . replace ( '0110feQ' , 'feQ' )
OOo0 = 'aHR0cDovL2JpdC5seS8yS0cz' . decode ( 'base64' ) + I1iiii1I
oO00ooooO0o = '0110MHY' . replace ( '0110MHY' , 'MHY' )
oo0o = 'aHR0cDovL2JpdC5seS8ySXVo' . decode ( 'base64' ) + oO00ooooO0o
o0oO0oooOoo = '0110xdb' . replace ( '0110xdb' , 'xdb' )
I1III1111iIi = 'aHR0cDovL2JpdC5seS8yWEJu' . decode ( 'base64' ) + o0oO0oooOoo
I1i111I = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( 'base64' )
OooOo0oo0O0o00O = 'aHR0cHM6Ly9uZXRhaS5ldS92aXNpdGFzL2luZGV4LnBocA==' . decode ( 'base64' )
oOOo0 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
I1i11 = '0110lxu' . replace ( '0110lxu' , 'lxu' )
IiIi1I1 = 'aHR0cDovL2JpdC5seS8yV1Bj' . decode ( 'base64' ) + I1i11
IiIIi1 = '0110pzp' . replace ( '0110pzp' , 'pzp' )
IIIIiii1IIii = 'aHR0cDovL2JpdC5seS8yVHpB' . decode ( 'base64' ) + IiIIi1
II1i11I = '01105yt' . replace ( '01105yt' , '5yt' )
ii1I1IIii11 = 'aHR0cDovL2JpdC5seS8yTVpp' . decode ( 'base64' ) + II1i11I
if 67 - 67: iiiIi1i1I + O0oO / o0000oOoOoO0o . oO0o0ooO0 + IIII
if 62 - 62: i11iIiiIii + i11iIiiIii - o0000oOoOoO0o
I1 = '1001DTs' . replace ( '1001DTs' , 'DTs' )
OooooO0oOOOO = 'aHR0cDovL2JpdC5seS8ySzhP' . decode ( 'base64' ) + I1
o0O00oOOoo = '1001Hky' . replace ( '1001Hky' , 'Hky' )
i1I1iIi = 'aHR0cDovL2JpdC5seS8yTGVL' . decode ( 'base64' ) + o0O00oOOoo
IIii11Ii1i1I = '1001VFU' . replace ( '1001VFU' , 'VFU' )
Oooo0O = 'aHR0cDovL2JpdC5seS8zMERx' . decode ( 'base64' ) + IIii11Ii1i1I
oo00O0oO0O0 = '3545OMZ' . replace ( '3545OMZ' , 'OMZ' )
ooo0OO0O0Oo = 'aHR0cDovL2JpdC5seS8yazhk' . decode ( 'base64' ) + oo00O0oO0O0
if 62 - 62: O0 % O0oO . O0oO - iIii1I11I1II1 / i11iIiiIii
def iiiII ( ) :
 if 41 - 41: ii11ii1ii
 if 10 - 10: ii11ii1ii / ii11ii1ii / OoOo . OoOo
 try :
  if 98 - 98: ii11ii1ii / OOooOOo . O0 + OoOO
  if 43 - 43: II111iiii . oO0o0ooO0 / o00O0oo
  i1iI1 = i11ii1ii11i ( Iii1IIII11I )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   try :
    if 80 - 80: oO0o0ooO0 + IIII / O0oO
    oO0o0 = O0O0Oo00
    if 79 - 79: iii11I111
    i11I1I1I = xbmc . Keyboard ( '' , 'Busqueda por titulo' )
    i11I1I1I . doModal ( )
    if ( i11I1I1I . isConfirmed ( ) ) :
     if 64 - 64: o0oO0
     oo00O00Oo = urllib . quote_plus ( i11I1I1I . getText ( ) ) . replace ( '+' , ' ' )
     IIIII1II = i11ii1ii11i ( oO0o0 )
     ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( IIIII1II )
     for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
      if re . search ( oo00O00Oo , Iii1iiIi1II ( IiI . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
       if 14 - 14: OOooOOo
    IIiIiI1I ( '[COLOR %s]Buscar Pelicula[/COLOR]' % O0ii1ii1ii , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
   except : IIiIiI1I ( '[COLOR %s]Buscar Pelicula[/COLOR]' % O0ii1ii1ii , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
   if 100 - 100: iIii1I11I1II1 + OoOO0ooOOoo0O / ii11ii1ii . i11iIiiIii
   if 14 - 14: o0000oOoOoO0o * IIII + iiiIi1i1I + O0 + i11iIiiIii
 except :
  pass
  if 77 - 77: o0000oOoOoO0o / OoooooooOO
  if 46 - 46: o0000oOoOoO0o % iIii1I11I1II1 . iiiIi1i1I % iiiIi1i1I + i11iIiiIii
def Oo00o0OO0O00o ( ) :
 if 82 - 82: O0oO + OoooooooOO - i1IIi . i1IIi
 O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'aviso' )
 if O00O0oOO00O00 == 'true' :
  i1iI1 = i11ii1ii11i ( Oo00oo0oO )
  ooO0OoOO = re . compile ( IIIIiiIiI ) . findall ( i1iI1 )
  for iIi1i , I1i11111i1i11 in ooO0OoOO :
   try :
    if 77 - 77: o00O0oo + OoOO / oO0o0ooO0 + O0 * o0000oOoOoO0o
    if 28 - 28: iii11I111 + i11iIiiIii / O0oO % OoOO0ooOOoo0O % ii11ii1ii - O0
    ooo0OOO = iIi1i
    iii1Ii1Ii1 = I1i11111i1i11
    if 21 - 21: oO0o0ooO0 . OoOo . IIII / ii11ii1ii / OoOo
    if 17 - 17: IIII / IIII / O0oO
    from datetime import datetime
    if 1 - 1: i1IIi . i11iIiiIii % IIII
    OooO0oo = datetime . now ( )
    o0o0oOoOO0O = OooO0oo . strftime ( '%d/%m/%Y' )
    if 16 - 16: II11iII % iIii1I11I1II1 . o0oO0
    oooooOOO000Oo = i11ii1ii11i ( OooOo0oo0O0o00O )
    ooO0OoOO = re . compile ( o0o0o0oO0oOO ) . findall ( oooooOOO000Oo )
    for Ooo00OoOOO in ooO0OoOO :
     if 98 - 98: iIii1I11I1II1 * o00O0oo * IIII + iii11I111 % i11iIiiIii % O0
     i1OO0oOOoo = "[B]" + ooo0OOO + "[/B]"
     oOOO00o000o = "" + iii1Ii1Ii1 + ""
     iIi11i1 = "[COLOR white]Hoy: " + o0o0oOoOO0O + ", Es usted el visitante numero: [B][COLOR gold]" + Ooo00OoOOO + "[/B][/COLOR]"
     if 71 - 71: iii11I111
     xbmcgui . Dialog ( ) . ok ( "Real Stream" , i1OO0oOOoo , oOOO00o000o , iIi11i1 )
     if 53 - 53: OoooooooOO % o0oO0 . II11iII / i11iIiiIii % iiiIi1i1I
   except :
    pass
    if 28 - 28: O0oO
    if 58 - 58: OoOO0ooOOoo0O
  IIIII1II = i11ii1ii11i ( I1i111I )
  ooO0OoOO = re . compile ( o0OoOO000ooO0 ) . findall ( IIIII1II )
  for iIiiI1iI in ooO0OoOO :
   try :
    if 5 - 5: OoOO0ooOOoo0O / OoooooooOO + II11iII * OoOo - OoOO % OOooOOo
    import xbmc
    import xbmcaddon
    if 42 - 42: O0 / o0000oOoOoO0o + OoooooooOO * iii11I111 % iii11I111
    __addon__ = xbmcaddon . Addon ( )
    __addonname__ = __addon__ . getAddonInfo ( 'name' )
    __icon__ = __addon__ . getAddonInfo ( 'icon' )
    if 7 - 7: iiiIi1i1I / o00O0oo / i11iIiiIii
    iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
    IIIIIo0ooOoO000oO = iIiiI1iI
    if 85 - 85: o0000oOoOoO0o . OoOO0ooOOoo0O / iii11I111 . O0 % OoOo
    i1OO0oOOoo = "[COLOR orange]Version instalada: [COLOR gold] " + iIiiiI1IiI1I1 + " [/COLOR][/COLOR] Disponible: " + iIiiI1iI + ""
    OO0ooo0oOO = 4000
    if 97 - 97: OOooOOo / iiiIi1i1I
    xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , i1OO0oOOoo , OO0ooo0oOO , __icon__ ) )
    if 71 - 71: II111iiii / i1IIi . o00O0oo % OoooooooOO . OoOO0ooOOoo0O
   except :
    pass
    if 41 - 41: i1IIi * II111iiii / OoooooooOO . IIII
 if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
 return
 if 83 - 83: iiiIi1i1I . O0 / ii11ii1ii / IIII - II111iiii
def Iii1iiIi1II ( s ) :
 if 100 - 100: OoOO
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 46 - 46: OoOO0ooOOoo0O / iIii1I11I1II1 % iiiIi1i1I . iIii1I11I1II1 * iiiIi1i1I
def IIi1ii1Ii ( file ) :
 if 91 - 91: i11iIiiIii / OoooooooOO + iiiIi1i1I - i11iIiiIii + IIII
 try :
  ii1i = open ( file , 'r' )
  i1iI1 = ii1i . read ( )
  ii1i . close ( )
  return i1iI1
 except :
  pass
  if 62 - 62: OoOO / o00O0oo
def i11ii1ii11i ( url ) :
 if 7 - 7: OoooooooOO . II11iII
 try :
  O000OOO0OOo = urllib2 . Request ( url )
  O000OOO0OOo . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  i1i1I111iIi1 = urllib2 . urlopen ( O000OOO0OOo )
  oo00O00oO000o = i1i1I111iIi1 . read ( )
  i1i1I111iIi1 . close ( )
  return oo00O00oO000o
 except urllib2 . URLError , OOo00OoO :
  print 'We failed to open "%s".' % url
  if hasattr ( OOo00OoO , 'code' ) :
   print 'We failed with error code - %s.' % OOo00OoO . code
  if hasattr ( OOo00OoO , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , OOo00OoO . reason
   if 10 - 10: o0000oOoOoO0o / i11iIiiIii
def o00oO ( url ) :
 O000OOO0OOo = urllib2 . Request ( url )
 O000OOO0OOo . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 O000OOO0OOo . add_header ( 'Referer' , '%s' % url )
 O000OOO0OOo . add_header ( 'Connection' , 'keep-alive' )
 i1i1I111iIi1 = urllib2 . urlopen ( O000OOO0OOo )
 oo00O00oO000o = i1i1I111iIi1 . read ( )
 i1i1I111iIi1 . close ( )
 return oo00O00oO000o
 if 92 - 92: II11iII * ii11ii1ii * ii11ii1ii * OOooOOo . iIii1I11I1II1
 if 16 - 16: iii11I111 % OoooooooOO - IIII * o0oO0 * o00O0oo / OoooooooOO
def I11o0oO00oO0o0o0 ( ) :
 if 17 - 17: O0oO . II11iII - II111iiii + O0 / iIii1I11I1II1 / i11iIiiIii
 O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 if 39 - 39: II11iII * ii11ii1ii + iIii1I11I1II1 - II11iII + IIII
 if i111IiI1I == 'true' :
  if 69 - 69: O0
  IIiIiI1I ( '[COLOR %s]Buscar Pelicula[/COLOR]' % O0ii1ii1ii , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
  IIiIiI1I ( '[COLOR %s]Buscar Serie[/COLOR]' % O0ii1ii1ii , 'search' , 145 , I1IIIii , oo00 )
  IIiIiI1I ( '[COLOR %s]Peliculas[/COLOR] ' % O0ii1ii1ii , 'movieDB' , 116 , II111ii1II1i , oo00 )
  IIiIiI1I ( '[COLOR %s]Series[/COLOR] ' % O0ii1ii1ii , 'movieDB' , 117 , OoOo00o , oo00 )
  if 85 - 85: iii11I111 / O0
  if 18 - 18: o0000oOoOoO0o % O0 * o00O0oo
 if i1Oo00 == 'true' :
  IIiIiI1I ( '[COLOR %s]Ajustes[/COLOR]' % O0ii1ii1ii , 'Settings' , 119 , o0OOoo0OO0OOO , oo00 )
  if 62 - 62: OoOo . II11iII . OoooooooOO
  if 11 - 11: IIII / O0oO
  if oO0OOoO0 == 'true' :
   oooO0 ( )
   if 16 - 16: II111iiii + oO0o0ooO0 - OoooooooOO
  if i1i == 'true' :
   ii1iI ( )
   IIi ( )
   if 89 - 89: II111iiii + i1IIi + II111iiii
  if o0ooOooo000oOO == 'false' :
   if 7 - 7: O0 % o0000oOoOoO0o + o00O0oo * iiiIi1i1I - iiiIi1i1I
   i1OO0oOOoo = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   oOOO00o000o = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Script.ResolveURL para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   iIi11i1 = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 42 - 42: OoOO0ooOOoo0O * OoOO0ooOOoo0O * OoOo . O0oO
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , i1OO0oOOoo , oOOO00o000o , iIi11i1 )
   if 51 - 51: IIII % iIii1I11I1II1 - OoooooooOO % iii11I111 * iIii1I11I1II1 % OoOO
def oO0o00oOOooO0 ( ) :
 IIiIiI1I ( '[COLOR orange]Buscador por id[/COLOR]' , IIiIi1iI , 127 , oOOoo00O0O , oo00 )
 if 79 - 79: OoOO - iIii1I11I1II1 + o0oO0 - OoOo
def OoO ( ) :
 O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 IIiIiI1I ( '[COLOR %s]The movie DB[/COLOR]' % O0ii1ii1ii , 'movieDB' , 99 , oOOoo00O0O , oo00 )
 if 35 - 35: OoOO0ooOOoo0O + i11iIiiIii - II111iiii
 IIiIiI1I ( '[COLOR %s]Video tutoriales[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 125 , IIIIii , oo00 )
 if 15 - 15: i11iIiiIii % OOooOOo * O0oO / OoOo
 if 90 - 90: iiiIi1i1I
def i1i1i1I ( ) :
 if 83 - 83: oO0o0ooO0 + OoooooooOO
 I11o0oO00oO0o0o0 ( )
 OoO ( )
 if 22 - 22: o0oO0 % iiiIi1i1I * OoooooooOO - o0000oOoOoO0o / iIii1I11I1II1
def OoOO00 ( ) :
 if 28 - 28: oO0o0ooO0 - i11iIiiIii . o00O0oo + II11iII / o00O0oo
 i1i1i1I ( )
 if 35 - 35: II11iII
def OOoO0 ( ) :
 if xbmc . getCondVisibility ( 'System.HasAddon(script.favourites)' ) :
  try :
   xbmc . executebuiltin ( "RunScript(script.favourites)" )
  except :
   pass
def OoOo00o0OO ( ) :
 IiII1IiiIiI1 . openSettings ( )
 if 1 - 1: OOooOOo % iii11I111
 if 65 - 65: OOooOOo + OoOO0ooOOoo0O / IIII
def oOO ( ) :
 urlresolver . display_settings ( )
 if 85 - 85: oO0o0ooO0 - iIii1I11I1II1 / O0
def ii1iI ( ) :
 IIiIiI1I ( '[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % O0ii1ii1ii , 'resolve' , 120 , Ii11iII1 , oo00 )
 if 99 - 99: II111iiii * II11iII % iIii1I11I1II1 / o0oO0
def OOO00O0oOOo ( ) :
 if 71 - 71: O0oO / o0000oOoOoO0o / OoOo % IIII
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 51 - 51: II11iII * O0 / II111iiii . o0oO0 % IIII / OOooOOo
def IIi ( ) :
 IIiIiI1I ( '[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % O0ii1ii1ii , 'resolve' , 140 , Ii11iII1 , oo00 )
 if 9 - 9: OOooOOo % OOooOOo % II111iiii
def oooO0 ( ) :
 if 30 - 30: II11iII + OoOo - II11iII . II11iII - II111iiii + O0
 O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 IIiIiI1I ( '[COLOR %s]Buscador[/COLOR]' % O0ii1ii1ii , 'search' , 111 , o0oOoO00o , oo00 )
 IIiIiI1I ( '[COLOR %s]Estrenos[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 3 , i11 , oo00 )
 IIiIiI1I ( '[COLOR %s]Todas[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 26 , I11 , oo00 )
 IIiIiI1I ( '[COLOR %s]4K[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 141 , O0o0Oo , oo00 )
 IIiIiI1I ( '[COLOR %s]Novedades[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 2 , i1111 , oo00 )
 IIiIiI1I ( '[COLOR %s]Accion[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 5 , Oo0o0000o0o0 , oo00 )
 IIiIiI1I ( '[COLOR %s]Animacion[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 6 , oOo0oooo00o , oo00 )
 IIiIiI1I ( '[COLOR %s]Artes Marciales[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 29 , o0 , oo00 )
 IIiIiI1I ( '[COLOR %s]Aventuras[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 7 , oO0o0o0ooO0oO , oo00 )
 IIiIiI1I ( '[COLOR %s]Belico[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 8 , oo0o0O00 , oo00 )
 IIiIiI1I ( '[COLOR %s]Ciencia Ficcion[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 9 , oO , oo00 )
 IIiIiI1I ( '[COLOR %s]Cine Clasico[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 30 , i1iiIIiiI111 , oo00 )
 IIiIiI1I ( '[COLOR %s]Comedia[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 10 , oooOOOOO , oo00 )
 IIiIiI1I ( '[COLOR %s]Crimen[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 11 , i1iiIII111ii , oo00 )
 IIiIiI1I ( '[COLOR %s]Drama[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 12 , i1iIIi1 , oo00 )
 IIiIiI1I ( '[COLOR %s]Familiar[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 13 , ii11iIi1I , oo00 )
 IIiIiI1I ( '[COLOR %s]Fantasia[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 14 , iI111I11I1I1 , oo00 )
 IIiIiI1I ( '[COLOR %s]Historia[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 15 , OOooO0OOoo , oo00 )
 IIiIiI1I ( '[COLOR %s]Misterio[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 16 , oOOoO0 , oo00 )
 IIiIiI1I ( '[COLOR %s]Musical[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 17 , O0OoO000O0OO , oo00 )
 IIiIiI1I ( '[COLOR %s]Romance[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 18 , iiI1IiI , oo00 )
 IIiIiI1I ( '[COLOR %s]Thriller[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 19 , II11iiii1Ii , oo00 )
 IIiIiI1I ( '[COLOR %s]Suspense[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 20 , ooOoOoo0O , oo00 )
 IIiIiI1I ( '[COLOR %s]Terror[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 21 , OooO0 , oo00 )
 IIiIiI1I ( '[COLOR %s]Western[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 22 , OO0o , oo00 )
 IIiIiI1I ( '[COLOR %s]Spain[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 23 , II , oo00 )
 IIiIiI1I ( '[COLOR %s]Super heroes[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 24 , iIii1 , oo00 )
 IIiIiI1I ( '[COLOR %s]Sagas[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 25 , Ooo , oo00 )
 if 86 - 86: i1IIi
def IIi11IIiIii1 ( ) :
 if 17 - 17: o0oO0 + oO0o0ooO0 . OoOO - ii11ii1ii * i11iIiiIii
 IIiIiI1I ( '[COLOR %s]Buscar Serie[/COLOR]' % O0ii1ii1ii , 'search' , 145 , O0OO00o0OO , oo00 )
 IIiIiI1I ( '[COLOR %s]En emision[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 150 , I11II1i , oo00 )
 IIiIiI1I ( '[COLOR %s]Mejor valoradas[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 151 , IIIII , oo00 )
 IIiIiI1I ( '[COLOR %s]Series Retro[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 152 , ooooooO0oo , oo00 )
 IIiIiI1I ( '[COLOR %s]Todas[/COLOR]' % O0ii1ii1ii , IIiIi1iI , 142 , I11i1 , oo00 )
 if 20 - 20: OOooOOo . OoooooooOO % IIII
def oOoOOo0oo0 ( ) :
 if 60 - 60: iii11I111 * OoOo + ii11ii1ii
 if 19 - 19: OoOO * O0oO / O0oO . OoooooooOO - IIII + i11iIiiIii
 try :
  if 88 - 88: i11iIiiIii - iii11I111
  O0iIi1IiII = i11ii1ii11i ( OooooO0oOOOO )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( O0iIi1IiII )
  for O0O0Oo00 in ooO0OoOO :
   if 27 - 27: iiiIi1i1I . O0oO . iIii1I11I1II1 . iIii1I11I1II1
   try :
    if 20 - 20: o0000oOoOoO0o / i1IIi
    oOIi111 = O0O0Oo00
    i11I1I1I = xbmc . Keyboard ( '' , 'Buscar' )
    i11I1I1I . doModal ( )
    if ( i11I1I1I . isConfirmed ( ) ) :
     oO0 = xbmcgui . DialogProgress ( )
     oO0 . create ( 'Realstream:' , 'Buscando ...' )
     oO0 . update ( 10 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     oO0 . update ( 15 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     oO0 . update ( 20 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     oO0 . update ( 25 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     oO0 . update ( 35 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     oO0 . update ( 45 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     oO0 . update ( 55 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     oO0 . update ( 65 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     oO0 . update ( 80 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     oO0 . update ( 90 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     oO0 . update ( 100 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 100 )
     oO0 . close ( )
     oo00O00Oo = urllib . quote_plus ( i11I1I1I . getText ( ) ) . replace ( '+' , ' ' )
     IIIII1II = i11ii1ii11i ( oOIi111 )
     ooO0OoOO = re . compile ( ii ) . findall ( IIIII1II )
     for i1iI , IiI , oo00 , iI1ii1i , IiIiII1 in ooO0OoOO :
      if re . search ( oo00O00Oo , Iii1iiIi1II ( IiI . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       IIiIiI1I ( '[COLOR %s]Buscar Serie[/COLOR]' % O0ii1ii1ii , 'search' , 145 , O0OO00o0OO , oo00 )
       iioo0o0OoOOO ( IiI , iI1ii1i , 143 , i1iI , oo00 , IiIiII1 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Resultados para: [COLOR orange]" + oo00O00Oo + "[/COLOR] ,3000)" )
       if 88 - 88: iiiIi1i1I
       if 19 - 19: II111iiii * II11iII + o0oO0
   except : IIiIiI1I ( '[COLOR %s]Buscar Serie[/COLOR]' % O0ii1ii1ii , 'search' , 145 , O0OO00o0OO , oo00 )
   if 65 - 65: IIII . OoOo . OoOO . iiiIi1i1I - IIII
 except :
  pass
def ii111i ( ) :
 if 93 - 93: OoOO
 try :
  if 5 - 5: O0oO / IIII
  O0iIi1IiII = i11ii1ii11i ( ooo0OO0O0Oo )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( O0iIi1IiII )
  for O0O0Oo00 in ooO0OoOO :
   if 77 - 77: iii11I111 - OOooOOo % O0oO - O0
   try :
    if 67 - 67: IIII + ii11ii1ii
    oOIi111 = O0O0Oo00
    if 84 - 84: O0 * OoooooooOO - II11iII * II11iII
   except :
    pass
    if 8 - 8: iii11I111 / i1IIi . oO0o0ooO0
  IIIII1II = i11ii1ii11i ( oOIi111 )
  ooO0OoOO = re . compile ( ii ) . findall ( IIIII1II )
  for i1iI , IiI , oo00 , iI1ii1i , IiIiII1 in ooO0OoOO :
   try :
    if 41 - 41: iiiIi1i1I + OoOO
    iioo0o0OoOOO ( IiI , iI1ii1i , 143 , i1iI , oo00 , IiIiII1 )
    if 86 - 86: OoOO0ooOOoo0O . iIii1I11I1II1 - OoOO
   except :
    pass
 except :
  pass
  if 56 - 56: O0
  if 61 - 61: o0000oOoOoO0o / IIII / ii11ii1ii * O0
def iIII1i1i ( ) :
 if 35 - 35: II111iiii * O0oO - OoooooooOO . O0oO . O0oO
 try :
  if 11 - 11: OoOo / OoOO0ooOOoo0O + O0oO % iIii1I11I1II1
  O0iIi1IiII = i11ii1ii11i ( Oooo0O )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( O0iIi1IiII )
  for O0O0Oo00 in ooO0OoOO :
   if 42 - 42: o00O0oo * OoOO0ooOOoo0O % iii11I111 - OoOO0ooOOoo0O . i11iIiiIii - OoOo
   try :
    if 84 - 84: OoOo - o00O0oo / O0oO
    oOIi111 = O0O0Oo00
    if 13 - 13: II11iII - ii11ii1ii - iii11I111
   except :
    pass
    if 92 - 92: iii11I111 / OoOO0ooOOoo0O * OoOO . O0oO % II111iiii
  IIIII1II = i11ii1ii11i ( oOIi111 )
  ooO0OoOO = re . compile ( ii ) . findall ( IIIII1II )
  for i1iI , IiI , oo00 , iI1ii1i , IiIiII1 in ooO0OoOO :
   try :
    if 71 - 71: OoOo % i1IIi - II111iiii - IIII + IIII * iii11I111
    iioo0o0OoOOO ( IiI , iI1ii1i , 143 , i1iI , oo00 , IiIiII1 )
    if 51 - 51: iIii1I11I1II1 / OoOO0ooOOoo0O + IIII - O0oO + iiiIi1i1I
   except :
    pass
 except :
  pass
  if 29 - 29: o0000oOoOoO0o % iIii1I11I1II1 . OoooooooOO % OoooooooOO % II111iiii / iiiIi1i1I
def oo0o0000Oo0 ( ) :
 if 80 - 80: OoOo - ii11ii1ii
 try :
  if 96 - 96: o00O0oo / II111iiii . o0oO0 - iiiIi1i1I * O0oO * oO0o0ooO0
  O0iIi1IiII = i11ii1ii11i ( i1I1iIi )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( O0iIi1IiII )
  for O0O0Oo00 in ooO0OoOO :
   if 76 - 76: o0oO0 - II111iiii * IIII / OoooooooOO
   try :
    if 18 - 18: OoOO + iIii1I11I1II1 - II111iiii - OOooOOo
    oOIi111 = O0O0Oo00
    if 71 - 71: OoooooooOO
   except :
    pass
    if 33 - 33: OoOo
  IIIII1II = i11ii1ii11i ( oOIi111 )
  ooO0OoOO = re . compile ( ii ) . findall ( IIIII1II )
  for i1iI , IiI , oo00 , iI1ii1i , IiIiII1 in ooO0OoOO :
   try :
    if 62 - 62: o00O0oo + o0oO0 + i1IIi / OoooooooOO
    iioo0o0OoOOO ( IiI , iI1ii1i , 143 , i1iI , oo00 , IiIiII1 )
    if 7 - 7: o0000oOoOoO0o + i1IIi . OOooOOo / ii11ii1ii
   except :
    pass
 except :
  pass
  if 22 - 22: iii11I111 - iii11I111 % IIII . OoOo + oO0o0ooO0
def Oo00OOo00O ( ) :
 if 81 - 81: II11iII . o0000oOoOoO0o / OoOo
 try :
  if 17 - 17: i11iIiiIii - IIII . II11iII % iIii1I11I1II1 + O0oO - iii11I111
  O0iIi1IiII = i11ii1ii11i ( OooooO0oOOOO )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( O0iIi1IiII )
  for O0O0Oo00 in ooO0OoOO :
   if 78 - 78: O0oO * OoOO0ooOOoo0O . O0 / O0
   try :
    if 80 - 80: i1IIi - ii11ii1ii / OoOO - i11iIiiIii
    oOIi111 = O0O0Oo00
    if 68 - 68: oO0o0ooO0 - o00O0oo % O0 % OoOo
   except :
    pass
    if 11 - 11: O0 / OoOO % IIII + o0000oOoOoO0o + iIii1I11I1II1
  IIIII1II = i11ii1ii11i ( oOIi111 )
  ooO0OoOO = re . compile ( ii ) . findall ( IIIII1II )
  for i1iI , IiI , oo00 , iI1ii1i , IiIiII1 in ooO0OoOO :
   try :
    if 40 - 40: iii11I111 - IIII . o0oO0 * ii11ii1ii % OoOo
    iioo0o0OoOOO ( IiI , iI1ii1i , 143 , i1iI , oo00 , IiIiII1 )
    if 56 - 56: i11iIiiIii . o0000oOoOoO0o - OOooOOo * O0oO
   except :
    pass
 except :
  pass
  if 91 - 91: oO0o0ooO0 + OoooooooOO - i1IIi
def o000 ( name , url ) :
 if 94 - 94: o0000oOoOoO0o + O0 / O0oO . OOooOOo + IIII . iIii1I11I1II1
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 62 - 62: OoOO0ooOOoo0O / OOooOOo - o00O0oo - OOooOOo + i11iIiiIii + i1IIi
 I1i11II = i11ii1ii11i ( url )
 ooO0OoOO = re . compile ( i1Iii1i1I ) . findall ( I1i11II )
 for i1iI , name , oo00 , url in ooO0OoOO :
  try :
   if 31 - 31: oO0o0ooO0 / II11iII * o0000oOoOoO0o . II111iiii
   if 89 - 89: O0
   IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % IIIi1I1IIii1II + name + '[/COLOR]'
   IIIII1I1Ii11iI ( name , url , 144 , i1iI , oo00 )
   if 52 - 52: IIII - iiiIi1i1I * oO0o0ooO0
   if 17 - 17: OoooooooOO + IIII * O0oO * OoOO0ooOOoo0O
  except :
   pass
   if 36 - 36: O0 + ii11ii1ii
   if 5 - 5: ii11ii1ii * OoOO0ooOOoo0O
   if 46 - 46: iii11I111
def IIIII1I1Ii11iI ( name , url , mode , iconimage , fanart ) :
 if 33 - 33: iiiIi1i1I - II111iiii * OoooooooOO - ii11ii1ii - IIII
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 84 - 84: OoOo + ii11ii1ii - OoOO0ooOOoo0O * OoOO0ooOOoo0O
 OoooO0o = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage="
 IIIii1iiIi = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 IIIii1iiIi . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IIIii1iiIi . setProperty ( 'fanart_image' , fanart )
 IIIii1iiIi . setProperty ( 'IsPlayable' , 'true' )
 oooo0OOo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OoooO0o , listitem = IIIii1iiIi )
 return oooo0OOo
 if 72 - 72: O0 / iii11I111 + OoooooooOO * iiiIi1i1I
 if 61 - 61: OoooooooOO % II111iiii - OOooOOo % o00O0oo + i1IIi
def i1II ( name , url ) :
 if 15 - 15: OoOO0ooOOoo0O
 if 62 - 62: o0oO0
 Oo0oOOo = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 i1Oo0oO00o = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 i11I1II1I11i = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 ooO000O = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 i1iI1 = i11ii1ii11i ( i11I1II1I11i )
 ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
 for oOIII111iiIi1 in ooO0OoOO :
  if 29 - 29: OoooooooOO + o0oO0 % iIii1I11I1II1 - IIII . OOooOOo % ii11ii1ii
  try :
   if 16 - 16: II11iII / ii11ii1ii + IIII / o0oO0
   if 42 - 42: ii11ii1ii + II111iiii - OOooOOo / O0oO % II11iII
   Oo0oOOo = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 66 - 66: IIII + i1IIi . OOooOOo + IIII - O0oO
   if 17 - 17: O0 . OoOo . O0 + O0 / ii11ii1ii . iii11I111
   if Oo0oOOo == oOIII111iiIi1 :
    if 62 - 62: o00O0oo % iiiIi1i1I * OoOO - i1IIi
    if 66 - 66: i11iIiiIii / o0000oOoOoO0o - OoooooooOO / i1IIi . i11iIiiIii
    if 'https://team.com' in url :
     if 16 - 16: ii11ii1ii % o00O0oo + O0oO - O0 . iiiIi1i1I / OoOo
     url = url . replace ( 'https://team.com' , 'https://verystream.com' )
     if 35 - 35: oO0o0ooO0 / OoOo / II111iiii - iIii1I11I1II1 + II111iiii . OoOo
    if 'https://mybox.com' in url :
     if 81 - 81: iiiIi1i1I * IIII - o00O0oo * o0oO0 % OoOO0ooOOoo0O * OoOO0ooOOoo0O
     url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
     if 59 - 59: iIii1I11I1II1
     if 7 - 7: IIII * OOooOOo / o0000oOoOoO0o * i11iIiiIii
    if 'https://vidcloud.co/' in url :
     if 84 - 84: IIII . iiiIi1i1I
     url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
     if 8 - 8: ii11ii1ii + II111iiii * IIII * OoOO0ooOOoo0O * O0oO / II11iII
    if 'https://gounlimited.to' in url :
     if 21 - 21: oO0o0ooO0 / OoooooooOO
     url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
     if 11 - 11: IIII % o0oO0 - i11iIiiIii - oO0o0ooO0 + iii11I111 + II11iII
    if 'https://drive.com' in url :
     if 87 - 87: OoOo * i1IIi / o00O0oo
     url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
     if 6 - 6: o0000oOoOoO0o + ii11ii1ii - OoooooooOO % IIII * OoOO0ooOOoo0O
     if 69 - 69: i1IIi
    import resolveurl
    if 59 - 59: II111iiii - o0000oOoOoO0o
    iIIi1I1ii = urlresolver . HostedMediaFile ( url )
    if 14 - 14: O0 / i1IIi / ii11ii1ii + iIii1I11I1II1
    if not iIIi1I1ii :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
     return False
     if 96 - 96: iiiIi1i1I
    try :
     oO0 = xbmcgui . DialogProgress ( )
     oO0 . create ( 'Realstream:' , 'Iniciando ...' )
     oO0 . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
     xbmc . sleep ( 1000 )
     i1I11iIII1i1I = iIIi1I1ii . resolve ( )
     if not i1I11iIII1i1I or not isinstance ( i1I11iIII1i1I , basestring ) :
      try : oOO0oo = i1I11iIII1i1I . msg
      except : oOO0oo = url
      raise Exception ( oOO0oo )
      if 13 - 13: OoooooooOO * oO0o0ooO0 - o0oO0 / IIII + O0oO + II11iII
    except Exception as OOo00OoO :
     try : oOO0oo = str ( OOo00OoO )
     except : oOO0oo = url
     oO0 . update ( 45 , 'RESOLVEURL:' , 'Reiniciando ... ' )
     xbmc . sleep ( 1000 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Episodio no disponible.  ,3000)" )
     oO0 . close ( )
     if 39 - 39: iIii1I11I1II1 - OoooooooOO
    oO0 . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    oO0 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
    xbmc . sleep ( 500 )
    oO0 . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
    xbmc . sleep ( 500 )
    oO0 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de este capitulo!' )
    oO0 . close ( )
    Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
    oO0oooooo = xbmcgui . ListItem ( path = i1I11iIII1i1I )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO0oooooo )
    if 65 - 65: II11iII + ii11ii1ii
    if 59 - 59: OoooooooOO + O0oO . OoOo - O0 % iIii1I11I1II1 / O0
   else :
    if 88 - 88: ii11ii1ii . O0 % OoooooooOO / IIII
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold]>El addon esta desactivado.[/COLOR]" )
    if 89 - 89: II111iiii / oO0o0ooO0
    if 14 - 14: IIII . OOooOOo * iii11I111 + II111iiii - iii11I111 + IIII
  except :
   pass
   if 18 - 18: oO0o0ooO0 - o0000oOoOoO0o - OOooOOo - OOooOOo
   if 54 - 54: ii11ii1ii + OOooOOo / iiiIi1i1I . OOooOOo * OoOO0ooOOoo0O
   if 1 - 1: OoOO0ooOOoo0O * OoOO . i1IIi / ii11ii1ii . o00O0oo + ii11ii1ii
   if 17 - 17: ii11ii1ii + OoOO / o0oO0 / iiiIi1i1I * IIII
   if 29 - 29: OoOO % OoooooooOO * oO0o0ooO0 / II111iiii - oO0o0ooO0
   if 19 - 19: i11iIiiIii
def oo0 ( ) :
 if 73 - 73: OoOO0ooOOoo0O . OOooOOo
 if 32 - 32: OoOO0ooOOoo0O * OOooOOo % iii11I111 * o0oO0 . O0
 i11i1i1I1iI1 = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 i11i1i1I1iI1 . doModal ( )
 if not i11i1i1I1iI1 . isConfirmed ( ) :
  return None ;
 IiI = i11i1i1I1iI1 . getText ( ) . strip ( )
 if 53 - 53: IIII + OOooOOo / i11iIiiIii - o0000oOoOoO0o * oO0o0ooO0 / OoooooooOO
 if 89 - 89: iIii1I11I1II1 / OOooOOo - II111iiii / o0oO0 . i11iIiiIii . o0oO0
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 48 - 48: O0 + O0 . OoOo - iii11I111
  o00oo0000 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + IiI + '&language=es-ES' ) )
  if 44 - 44: ii11ii1ii % iIii1I11I1II1
  if 90 - 90: II111iiii + OoooooooOO % OoooooooOO
  return 'android'
  if 35 - 35: iiiIi1i1I / o00O0oo * OoooooooOO . II111iiii / ii11ii1ii
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 1 - 1: OoooooooOO + II11iII . i1IIi % O0oO
  o00oo0000 = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + IiI + '&language=es-ES' )
  if 66 - 66: o0000oOoOoO0o + o00O0oo + OOooOOo - oO0o0ooO0
  if 12 - 12: iiiIi1i1I . II11iII . OoOO0ooOOoo0O / O0
  return 'windows'
  if 58 - 58: o0000oOoOoO0o - II111iiii % oO0o0ooO0 + OoOo . OoOO0ooOOoo0O / II11iII
  if 8 - 8: o00O0oo . OoOO * O0oO + II111iiii % i11iIiiIii
def i1i1IiIiIi1Ii ( ) :
 if 64 - 64: IIII + OoooooooOO * OoooooooOO
 try :
  if 41 - 41: iii11I111 . ii11ii1ii + OOooOOo
  i1iI1 = i11ii1ii11i ( Iii1IIII11I )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 100 - 100: o0oO0 + OoOO
   try :
    if 73 - 73: i1IIi - OoOo % iii11I111 / OoOO
    all = O0O0Oo00
    if 40 - 40: o00O0oo * iii11I111 - OOooOOo / II11iII / i11iIiiIii
   except :
    pass
    if 83 - 83: o00O0oo / OoOo - i11iIiiIii . iIii1I11I1II1 + ii11ii1ii
  I1i11II = i11ii1ii11i ( all )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( I1i11II )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    if 59 - 59: O0 % ii11ii1ii
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 92 - 92: o0oO0 % iiiIi1i1I / o00O0oo % o00O0oo * OOooOOo
   except :
    pass
 except :
  pass
  if 74 - 74: O0 . OOooOOo % OoOO % II11iII
def oOo0OooOo ( ) :
 if 51 - 51: O0oO . ii11ii1ii
 try :
  if 45 - 45: i1IIi - ii11ii1ii / O0 . o00O0oo
  i1111 = i11ii1ii11i ( oO0o0 )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1111 )
  for O0O0Oo00 in ooO0OoOO :
   if 5 - 5: o0000oOoOoO0o . iIii1I11I1II1 % iIii1I11I1II1
   try :
    if 56 - 56: OoooooooOO - O0oO - i1IIi
    oOIi111 = O0O0Oo00
    if 8 - 8: OoOo / IIII . OOooOOo + o00O0oo / i11iIiiIii
   except :
    pass
    if 31 - 31: iii11I111 - iIii1I11I1II1 + iiiIi1i1I . ii11ii1ii / II11iII % iIii1I11I1II1
  IIIII1II = i11ii1ii11i ( oOIi111 )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( IIIII1II )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    if 6 - 6: II11iII * i11iIiiIii % iIii1I11I1II1 % i11iIiiIii + o0000oOoOoO0o / i1IIi
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 53 - 53: O0oO + iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 70 - 70: o00O0oo
def oo0O ( ) :
 if 6 - 6: ii11ii1ii . II11iII / II11iII - i11iIiiIii
 try :
  if 87 - 87: ii11ii1ii / O0 * II11iII / o0000oOoOoO0o
  i11 = i11ii1ii11i ( OO0Oooo0oOO0O )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i11 )
  for O0O0Oo00 in ooO0OoOO :
   if 19 - 19: OoOo + i1IIi . OOooOOo - ii11ii1ii
   try :
    iIi1I1 = O0O0Oo00
   except :
    pass
    if 63 - 63: iiiIi1i1I * o00O0oo . OoooooooOO / IIII * ii11ii1ii . iii11I111
  i1iI1 = i11ii1ii11i ( iIi1I1 )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    if 62 - 62: i1IIi / iii11I111 . OOooOOo * o0000oOoOoO0o
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 21 - 21: o0000oOoOoO0o
   except :
    pass
 except :
  pass
  if 81 - 81: O0oO / iIii1I11I1II1 - iii11I111 * OoOo . OOooOOo * o00O0oo
def o0000 ( ) :
 if 42 - 42: OoOo + OoOo * II111iiii
 try :
  if 78 - 78: OoooooooOO
  i1iI1 = i11ii1ii11i ( db2 )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 77 - 77: o00O0oo / i1IIi / ii11ii1ii % IIII
   try :
    if 48 - 48: O0oO - II11iII + iIii1I11I1II1 + OoooooooOO
    Ii = O0O0Oo00
    if 42 - 42: o0oO0 * OoOo . II11iII * OOooOOo + OoOO0ooOOoo0O
   except :
    pass
    if 25 - 25: O0oO . OOooOOo + oO0o0ooO0
    if 75 - 75: II11iII - o0000oOoOoO0o % iiiIi1i1I + i11iIiiIii
  i1iI1 = i11ii1ii11i ( Ii )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 100 - 100: O0oO + o0000oOoOoO0o - i11iIiiIii - II111iiii
   except :
    pass
 except :
  pass
  if 40 - 40: OoOO0ooOOoo0O % OoOO
def oo0O0o00 ( ) :
 if 70 - 70: OoOO
 try :
  if 46 - 46: O0oO - i1IIi
  i111iiIIII = i11ii1ii11i ( IIIIiii1IIii )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i111iiIIII )
  for O0O0Oo00 in ooO0OoOO :
   if 80 - 80: ii11ii1ii * o0oO0 + o00O0oo * IIII
   try :
    if 16 - 16: O0oO / OOooOOo + OoOO % iIii1I11I1II1 - i1IIi . oO0o0ooO0
    iIi1iIIIiIiI = O0O0Oo00
    if 62 - 62: i11iIiiIii % IIII . II11iII . IIII
   except :
    pass
    if 84 - 84: i11iIiiIii * OoOO
    if 18 - 18: IIII - o0oO0 - OoOO0ooOOoo0O / OoOo - O0
  i1iI1 = i11ii1ii11i ( iIi1iIIIiIiI )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    if 30 - 30: O0 + o00O0oo + II111iiii
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 14 - 14: o0000oOoOoO0o / IIII - iIii1I11I1II1 - oO0o0ooO0 % iii11I111
   except :
    pass
 except :
  pass
  if 49 - 49: iii11I111 * oO0o0ooO0 / o0000oOoOoO0o / ii11ii1ii * iIii1I11I1II1
def OOoO00ooO ( ) :
 if 12 - 12: iii11I111 % OOooOOo + oO0o0ooO0 - i1IIi . o0oO0 / OOooOOo
 try :
  if 51 - 51: IIII . OOooOOo
  i1iI1 = i11ii1ii11i ( oOO0O00Oo0O0o )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 73 - 73: OoooooooOO . OOooOOo / OoOo % o0oO0
   try :
    if 65 - 65: II11iII - OOooOOo - o0oO0
    Ii1iIi111I1i = O0O0Oo00
    if 4 - 4: iiiIi1i1I - ii11ii1ii - II11iII - O0oO % i11iIiiIii / OoOO
   except :
    pass
    if 50 - 50: iii11I111 + i1IIi
    if 31 - 31: o0oO0
  i1iI1 = i11ii1ii11i ( Ii1iIi111I1i )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 78 - 78: i11iIiiIii + o0000oOoOoO0o + OoOo / o0000oOoOoO0o % iIii1I11I1II1 % II11iII
   except :
    pass
 except :
  pass
  if 83 - 83: iIii1I11I1II1 % OoOO0ooOOoo0O % o0000oOoOoO0o % OoOo . o00O0oo % O0
def iIiIi1ii ( ) :
 if 28 - 28: iIii1I11I1II1 + iIii1I11I1II1
 try :
  if 28 - 28: oO0o0ooO0
  i1iI1 = i11ii1ii11i ( I1iIIiiIIi1i )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 52 - 52: OOooOOo + iIii1I11I1II1
   try :
    if 71 - 71: O0 / oO0o0ooO0
    iI1iiII11I = O0O0Oo00
    if 32 - 32: IIII % iii11I111 - OoOO0ooOOoo0O % iiiIi1i1I . OoOo
   except :
    pass
    if 47 - 47: O0oO % i1IIi + i1IIi
  i1iI1 = i11ii1ii11i ( iI1iiII11I )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 87 - 87: ii11ii1ii * IIII % II11iII % OoOO0ooOOoo0O
   except :
    pass
 except :
  pass
  if 4 - 4: OoOO0ooOOoo0O + o0oO0 / oO0o0ooO0
def i1iI1IIIII1 ( ) :
 if 39 - 39: o00O0oo % OoOO % o0oO0
 try :
  if 55 - 55: O0 - OoOo
  i1iI1 = i11ii1ii11i ( oOOo0O00o )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 58 - 58: OoOO0ooOOoo0O - iiiIi1i1I - OoooooooOO
   try :
    if 96 - 96: iIii1I11I1II1
    OOOo00 = O0O0Oo00
    if 91 - 91: iIii1I11I1II1 . o0000oOoOoO0o . o00O0oo + OoooooooOO
   except :
    pass
    if 69 - 69: OoOo - OOooOOo
    if 95 - 95: OOooOOo * i11iIiiIii . iii11I111
  i1iI1 = i11ii1ii11i ( OOOo00 )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 41 - 41: II111iiii
   except :
    pass
 except :
  pass
  if 37 - 37: O0oO . ii11ii1ii % II11iII * i1IIi
def oOOOO ( ) :
 if 48 - 48: OoOo + iiiIi1i1I
 try :
  if 16 - 16: iIii1I11I1II1 % i11iIiiIii . OoOO0ooOOoo0O % iii11I111 + oO0o0ooO0 . OoOO
  i1iI1 = i11ii1ii11i ( OOO )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 46 - 46: OoOO - o0000oOoOoO0o / OoOO0ooOOoo0O - OoooooooOO + oO0o0ooO0
   try :
    if 58 - 58: o0000oOoOoO0o / o0000oOoOoO0o + iii11I111 + O0oO - OoOO0ooOOoo0O . IIII
    I11Ii1iI11iI1 = O0O0Oo00
    if 32 - 32: OOooOOo
   except :
    pass
    if 78 - 78: OoOO0ooOOoo0O - OoOO % iii11I111
    if 80 - 80: OoOo . O0oO
  i1iI1 = i11ii1ii11i ( I11Ii1iI11iI1 )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 73 - 73: OoOO0ooOOoo0O . O0 / iiiIi1i1I * oO0o0ooO0
   except :
    pass
 except :
  pass
  if 29 - 29: o0000oOoOoO0o
def oo0iIiI ( ) :
 if 81 - 81: OoOO0ooOOoo0O % o0oO0
 try :
  if 87 - 87: iIii1I11I1II1 . OoooooooOO * OoOO0ooOOoo0O
  i1iI1 = i11ii1ii11i ( oooOo0OOOoo0 )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 100 - 100: OoOO / i1IIi - OOooOOo % o0oO0 - iIii1I11I1II1
   try :
    if 17 - 17: O0oO / o0000oOoOoO0o % ii11ii1ii
    o0o = O0O0Oo00
    if 93 - 93: iii11I111 % i11iIiiIii % OoOo
   except :
    pass
    if 64 - 64: OoOo + OOooOOo * O0 / ii11ii1ii - O0oO % O0oO
    if 59 - 59: IIII + OoooooooOO
  i1iI1 = i11ii1ii11i ( o0o )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 55 - 55: i11iIiiIii % iIii1I11I1II1 . i1IIi + OoooooooOO / i11iIiiIii
   except :
    pass
 except :
  pass
  if 10 - 10: iiiIi1i1I - oO0o0ooO0 * iIii1I11I1II1 % iIii1I11I1II1 * II11iII - o00O0oo
def OoO0O0oO00 ( ) :
 if 33 - 33: O0
 try :
  if 78 - 78: O0 / II111iiii * OoOO
  i1iI1 = i11ii1ii11i ( ii1I1IIii11 )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 50 - 50: OoooooooOO - iIii1I11I1II1 + i1IIi % OoOo - iIii1I11I1II1 % O0
   try :
    if 58 - 58: II11iII + iIii1I11I1II1
    Oo00OO0OO = O0O0Oo00
    if 85 - 85: o0000oOoOoO0o % iii11I111 . OoOO0ooOOoo0O % OoOo - ii11ii1ii
   except :
    pass
    if 69 - 69: iii11I111 - o0000oOoOoO0o . iii11I111
    if 9 - 9: oO0o0ooO0 % i11iIiiIii / ii11ii1ii
  i1iI1 = i11ii1ii11i ( Oo00OO0OO )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 20 - 20: oO0o0ooO0 * O0 + O0oO - OoooooooOO . O0oO
   except :
    pass
 except :
  pass
  if 60 - 60: o0000oOoOoO0o . o0000oOoOoO0o / iiiIi1i1I
  if 45 - 45: O0 . i11iIiiIii % iiiIi1i1I . OoOO0ooOOoo0O % II11iII % iIii1I11I1II1
def Oooo0oooo0OoO0o ( ) :
 if 50 - 50: iiiIi1i1I / iiiIi1i1I + IIII * iii11I111 / o00O0oo
 try :
  if 14 - 14: o0oO0 % OOooOOo - iIii1I11I1II1 . IIII + OoOO - OoOo
  i1iI1 = i11ii1ii11i ( OO0O000 )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 5 - 5: iiiIi1i1I
   try :
    if 62 - 62: OoOO0ooOOoo0O . OoooooooOO . IIII . OoOO * iiiIi1i1I
    OOOO = O0O0Oo00
    if 94 - 94: OoooooooOO . iii11I111 + o0oO0 - OOooOOo
   except :
    pass
    if 1 - 1: o0000oOoOoO0o . O0
    if 37 - 37: i1IIi - IIII % OoooooooOO / IIII % iii11I111
  i1iI1 = i11ii1ii11i ( OOOO )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 48 - 48: i11iIiiIii % oO0o0ooO0
   except :
    pass
 except :
  pass
  if 29 - 29: iiiIi1i1I + i11iIiiIii % O0oO
  if 93 - 93: OoOO0ooOOoo0O % iIii1I11I1II1
def Ooo0o0oo0 ( ) :
 if 87 - 87: OoOO0ooOOoo0O / II11iII + iIii1I11I1II1
 try :
  if 93 - 93: iIii1I11I1II1 + oO0o0ooO0 % iii11I111
  i1iI1 = i11ii1ii11i ( oO0O00oOOoooO )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 21 - 21: IIII
   try :
    if 6 - 6: II11iII
    i1I1II = O0O0Oo00
    if 17 - 17: O0 * OoOO0ooOOoo0O * o00O0oo * II111iiii * O0oO % i1IIi
   except :
    pass
    if 33 - 33: o00O0oo * o00O0oo . iii11I111 . i11iIiiIii
    if 48 - 48: o0000oOoOoO0o . o0oO0 + OoOO0ooOOoo0O % o00O0oo / i11iIiiIii
  i1iI1 = i11ii1ii11i ( i1I1II )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 74 - 74: II111iiii . O0 - OOooOOo + II11iII % i11iIiiIii % OoOO0ooOOoo0O
   except :
    pass
    if 78 - 78: o0oO0 + OoOO0ooOOoo0O + II11iII - II11iII . i11iIiiIii / OoOO
 except :
  pass
  if 27 - 27: o0oO0 - O0 % O0oO * OoOo . II11iII % iIii1I11I1II1
  if 37 - 37: OoooooooOO + O0 - i1IIi % iii11I111
def i1I1i1i ( ) :
 if 36 - 36: II111iiii % O0
 try :
  if 35 - 35: iIii1I11I1II1 - IIII % o0000oOoOoO0o
  i1iI1 = i11ii1ii11i ( Oo0O00O000 )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 30 - 30: OoOo % OoOo % II11iII . OoOO0ooOOoo0O
   try :
    if 9 - 9: iii11I111 / II111iiii . OoOO0ooOOoo0O % o0000oOoOoO0o * II111iiii - iii11I111
    oOOoo0 = O0O0Oo00
    if 24 - 24: OoOO - oO0o0ooO0 + o00O0oo / iiiIi1i1I % OOooOOo + iIii1I11I1II1
   except :
    pass
    if 79 - 79: OoOO0ooOOoo0O / iii11I111
    if 77 - 77: ii11ii1ii
  i1iI1 = i11ii1ii11i ( oOOoo0 )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 46 - 46: OoOo
   except :
    pass
    if 72 - 72: iiiIi1i1I * IIII
 except :
  pass
  if 67 - 67: i1IIi
def iii ( ) :
 if 57 - 57: OOooOOo
 try :
  if 35 - 35: OoooooooOO - OoOo / OoOO
  i1iI1 = i11ii1ii11i ( oo )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 50 - 50: OoOO0ooOOoo0O
   try :
    if 33 - 33: O0oO
    oOo00OoO0O = O0O0Oo00
    if 69 - 69: iIii1I11I1II1 * OOooOOo - iiiIi1i1I + O0 + O0
   except :
    pass
    if 65 - 65: OoOo / i11iIiiIii / OoOO - IIII
  i1iI1 = i11ii1ii11i ( oOo00OoO0O )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 9 - 9: OOooOOo / OoOo - ii11ii1ii * iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 86 - 86: II111iiii + iii11I111 + II11iII
  if 9 - 9: iii11I111 + II111iiii % iii11I111 % II11iII + iIii1I11I1II1
def oO00 ( ) :
 if 7 - 7: O0 % OoOo + o00O0oo + o0oO0 % OoooooooOO . ii11ii1ii
 try :
  if 56 - 56: iiiIi1i1I
  i1iI1 = i11ii1ii11i ( iIIii )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 84 - 84: OoOO0ooOOoo0O - i11iIiiIii
   try :
    if 1 - 1: iiiIi1i1I * OoOO0ooOOoo0O
    OO0ooo0 = O0O0Oo00
    if 7 - 7: o00O0oo - oO0o0ooO0 * IIII + o0000oOoOoO0o . o00O0oo
   except :
    pass
    if 85 - 85: O0
    if 32 - 32: OoooooooOO . OoOO / ii11ii1ii * o0000oOoOoO0o / o0000oOoOoO0o * o0oO0
  i1iI1 = i11ii1ii11i ( OO0ooo0 )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 19 - 19: o0oO0
   except :
    pass
 except :
  pass
  if 55 - 55: IIII % IIII / O0 % iiiIi1i1I - o0000oOoOoO0o . ii11ii1ii
  if 49 - 49: iIii1I11I1II1 * i1IIi . OoooooooOO
def OOOO0oOo00O ( ) :
 if 32 - 32: II11iII % o0oO0 - OOooOOo
 try :
  if 71 - 71: iiiIi1i1I
  i1iI1 = i11ii1ii11i ( ii1iii1i )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 23 - 23: i1IIi . iIii1I11I1II1 . IIII . O0 % o0oO0 % i11iIiiIii
   try :
    if 11 - 11: O0 - II111iiii . IIII . o0oO0 % OoOo
    IIi1 = O0O0Oo00
    if 95 - 95: OoooooooOO + O0oO - o00O0oo / o00O0oo . i1IIi . OoooooooOO
   except :
    pass
  i1iI1 = i11ii1ii11i ( IIi1 )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 29 - 29: iii11I111 - i1IIi . O0oO - o00O0oo + iii11I111 + OoooooooOO
   except :
    pass
 except :
  pass
  if 36 - 36: i1IIi / iii11I111 . iIii1I11I1II1
def i1IiiiiIi1I ( ) :
 if 56 - 56: OoooooooOO * O0
 try :
  if 85 - 85: OoooooooOO % OoOO0ooOOoo0O * iIii1I11I1II1
  i1iI1 = i11ii1ii11i ( ooOoO00 )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 44 - 44: iIii1I11I1II1 . o00O0oo + OoOo . iii11I111
   try :
    if 7 - 7: o00O0oo + iIii1I11I1II1 * O0oO * O0oO / II111iiii - o0oO0
    oOOOo0o = O0O0Oo00
    if 26 - 26: iIii1I11I1II1 - O0 . O0
   except :
    pass
    if 68 - 68: IIII + oO0o0ooO0 . O0 . o0oO0 % i1IIi % IIII
    if 50 - 50: II11iII + o0000oOoOoO0o
  i1iI1 = i11ii1ii11i ( oOOOo0o )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 96 - 96: OoOO
   except :
    pass
 except :
  pass
  if 92 - 92: ii11ii1ii / i11iIiiIii + o00O0oo
  if 87 - 87: OoOO0ooOOoo0O % iIii1I11I1II1
def o0O ( ) :
 if 69 - 69: II11iII + ii11ii1ii - iii11I111 + oO0o0ooO0
 try :
  if 36 - 36: i11iIiiIii / iiiIi1i1I . O0oO + II11iII . O0 + OOooOOo
  i1iI1 = i11ii1ii11i ( o0O00Oo0 )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 36 - 36: i1IIi - o00O0oo - OoOo
   try :
    if 7 - 7: i11iIiiIii + OOooOOo
    I1i1I1II = O0O0Oo00
    if 58 - 58: IIII . o0000oOoOoO0o + OOooOOo % ii11ii1ii - OoOO
   except :
    pass
    if 50 - 50: iiiIi1i1I % II111iiii - iii11I111 . i1IIi + O0 % iiiIi1i1I
    if 10 - 10: iiiIi1i1I . i1IIi + o0oO0
  i1iI1 = i11ii1ii11i ( I1i1I1II )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 66 - 66: OoOO % o0000oOoOoO0o
   except :
    pass
 except :
  pass
  if 21 - 21: OoOO0ooOOoo0O - OoooooooOO % i11iIiiIii
def Oo00O0OO ( ) :
 if 77 - 77: oO0o0ooO0 - ii11ii1ii - iIii1I11I1II1
 try :
  if 16 - 16: OoOO / iiiIi1i1I / i1IIi . iiiIi1i1I + oO0o0ooO0
  i1iI1 = i11ii1ii11i ( i111iIi1i1II1 )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 26 - 26: iIii1I11I1II1 + i1IIi / OoOO0ooOOoo0O % o00O0oo
   try :
    if 44 - 44: OoooooooOO . II111iiii . IIII % OoooooooOO
    Oo0oO00 = O0O0Oo00
    if 41 - 41: O0 - O0oO * iIii1I11I1II1
   except :
    pass
    if 12 - 12: o0000oOoOoO0o * OoOo % II111iiii * i1IIi * iIii1I11I1II1
    if 81 - 81: ii11ii1ii - O0oO
  i1iI1 = i11ii1ii11i ( Oo0oO00 )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 24 - 24: OoooooooOO . OoOO * II111iiii
   except :
    pass
 except :
  pass
  if 59 - 59: OoOo + OoOO / IIII
  if 97 - 97: ii11ii1ii * iiiIi1i1I % iii11I111 . iiiIi1i1I - OoOo - IIII
def oo0O0o00I1ii1i ( ) :
 if 22 - 22: oO0o0ooO0 * o0oO0 * i11iIiiIii + iiiIi1i1I * OoOO0ooOOoo0O * OoOO
 try :
  if 85 - 85: iiiIi1i1I * IIII % ii11ii1ii - iiiIi1i1I - O0oO
  i1iI1 = i11ii1ii11i ( i1I1i111Ii )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 46 - 46: O0
   try :
    if 65 - 65: iIii1I11I1II1 % oO0o0ooO0 + O0 / OoooooooOO
    O0000oO0o00 = O0O0Oo00
    if 80 - 80: OoooooooOO + II11iII
   except :
    pass
    if 95 - 95: OoOo / oO0o0ooO0 * OoOo - OoooooooOO * OoooooooOO % OoOO
    if 43 - 43: ii11ii1ii . OoOo
  i1iI1 = i11ii1ii11i ( O0000oO0o00 )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 12 - 12: OoOo + IIII + O0oO . II11iII / o0oO0
   except :
    pass
 except :
  pass
  if 29 - 29: II11iII . iii11I111 - II111iiii
  if 68 - 68: iIii1I11I1II1 + II111iiii / oO0o0ooO0
def oOooo00000 ( ) :
 if 26 - 26: O0
 try :
  if 34 - 34: iii11I111 * OoOo
  i1iI1 = i11ii1ii11i ( i1i1iI1iiiI )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 97 - 97: i11iIiiIii % oO0o0ooO0 / ii11ii1ii / ii11ii1ii
   try :
    if 97 - 97: II111iiii - OoOo - iIii1I11I1II1 * OOooOOo
    oooO0o0O0oo0o = O0O0Oo00
    if 100 - 100: II11iII . o0oO0 - iIii1I11I1II1 . i11iIiiIii / II111iiii
   except :
    pass
    if 71 - 71: OoOo * ii11ii1ii . O0oO
    if 49 - 49: II11iII * O0 . II11iII
  i1iI1 = i11ii1ii11i ( oooO0o0O0oo0o )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 19 - 19: II111iiii - II11iII
   except :
    pass
 except :
  pass
  if 59 - 59: o0000oOoOoO0o * OoOO - o0oO0 . IIII
  if 89 - 89: IIII
def o00oo0OO0 ( ) :
 if 60 - 60: iii11I111
 try :
  if 66 - 66: O0oO / iii11I111 % i1IIi - oO0o0ooO0 . O0 / O0
  i1iI1 = i11ii1ii11i ( oOOOoo00 )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 96 - 96: OoooooooOO + II11iII * O0
   try :
    if 86 - 86: o0oO0
    IiII1i1iI = O0O0Oo00
    if 84 - 84: II11iII + o00O0oo + o0oO0 + iiiIi1i1I
   except :
    pass
    if 62 - 62: i11iIiiIii + OoOO0ooOOoo0O + i1IIi
    if 69 - 69: OoOO0ooOOoo0O
  i1iI1 = i11ii1ii11i ( IiII1i1iI )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 63 - 63: OoOO / OoOO0ooOOoo0O * iIii1I11I1II1 . OoOo
   except :
    pass
 except :
  pass
  if 85 - 85: i11iIiiIii / i11iIiiIii . OoOO . O0
  if 67 - 67: II111iiii / o0000oOoOoO0o . IIII . OoooooooOO
def i1I1Ii11i ( ) :
 if 19 - 19: II11iII - o0000oOoOoO0o . iIii1I11I1II1 . OoOO0ooOOoo0O / IIII
 try :
  if 87 - 87: OoOO0ooOOoo0O - iii11I111 - IIII + ii11ii1ii % iIii1I11I1II1 / i11iIiiIii
  i1iI1 = i11ii1ii11i ( iiI1IIIi )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 12 - 12: iii11I111
   try :
    if 86 - 86: oO0o0ooO0 - OoOO
    OoOOi11 = O0O0Oo00
    if 48 - 48: i1IIi - iiiIi1i1I - i11iIiiIii . O0oO - iiiIi1i1I * O0oO
   except :
    pass
    if 60 - 60: OoOO0ooOOoo0O / o00O0oo + IIII - iiiIi1i1I
  i1iI1 = i11ii1ii11i ( OoOOi11 )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 49 - 49: OoOO - O0 / OoOO * OoOO0ooOOoo0O + OoOo
   except :
    pass
 except :
  pass
  if 35 - 35: II111iiii . OOooOOo / i1IIi / OOooOOo * oO0o0ooO0
  if 85 - 85: II111iiii . iii11I111 % IIII % O0oO
def OOo00ooOoO0o ( ) :
 if 21 - 21: i11iIiiIii
 try :
  if 89 - 89: iiiIi1i1I . i11iIiiIii * O0
  i1iI1 = i11ii1ii11i ( IIOOO0O00O0OOOO )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 44 - 44: i1IIi . OOooOOo / i11iIiiIii + II11iII
   try :
    if 27 - 27: IIII
    O0OO0ooO00 = O0O0Oo00
    if 83 - 83: iIii1I11I1II1
   except :
    pass
    if 63 - 63: OoooooooOO * OoOO / O0oO - oO0o0ooO0 . iIii1I11I1II1 + iiiIi1i1I
    if 44 - 44: i1IIi % OOooOOo % o0000oOoOoO0o
  i1iI1 = i11ii1ii11i ( O0OO0ooO00 )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 9 - 9: ii11ii1ii % OoooooooOO - o0oO0
   except :
    pass
 except :
  pass
  if 43 - 43: OoOO % OoOO
def IIiii11ii1i ( ) :
 if 7 - 7: oO0o0ooO0 - O0 * O0oO - o0000oOoOoO0o - II111iiii
 try :
  if 41 - 41: OOooOOo - OoOo % II111iiii . OoOo - O0oO
  i1iI1 = i11ii1ii11i ( OOo0 )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 45 - 45: o0oO0 - IIII
   try :
    if 70 - 70: OoOO % OOooOOo / OOooOOo . O0oO % iii11I111 . II111iiii
    I1ii1Ii1 = O0O0Oo00
    if 73 - 73: O0 . oO0o0ooO0 + i11iIiiIii + iIii1I11I1II1 - O0oO / OoOO0ooOOoo0O
   except :
    pass
  i1iI1 = i11ii1ii11i ( I1ii1Ii1 )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 99 - 99: o00O0oo * oO0o0ooO0 * o00O0oo - II111iiii + o0oO0
   except :
    pass
 except :
  pass
  if 72 - 72: o0000oOoOoO0o % OOooOOo / iiiIi1i1I - O0 + O0oO
def o0iIIIIi ( ) :
 if 50 - 50: OoOo + iii11I111 + iiiIi1i1I
 try :
  if 15 - 15: O0oO
  i1iI1 = i11ii1ii11i ( oo0o )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 13 - 13: iIii1I11I1II1 * OoOO0ooOOoo0O / OoOo % iii11I111 + oO0o0ooO0
   try :
    if 41 - 41: o00O0oo
    i1iI1i = O0O0Oo00
    if 59 - 59: II11iII
   except :
    pass
  i1iI1 = i11ii1ii11i ( i1iI1i )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 89 - 89: OoOO0ooOOoo0O % iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 35 - 35: o00O0oo + OoOo - OoOO0ooOOoo0O % oO0o0ooO0 % o0000oOoOoO0o % OoOO0ooOOoo0O
def ii1IIiII111I ( ) :
 if 87 - 87: o0oO0 - o00O0oo % o00O0oo . oO0o0ooO0 / o00O0oo
 try :
  if 6 - 6: OoOO0ooOOoo0O / iIii1I11I1II1 * OoooooooOO * i11iIiiIii
  i1iI1 = i11ii1ii11i ( IiIi1I1 )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 79 - 79: II11iII % OoOO
   try :
    if 81 - 81: i11iIiiIii + i11iIiiIii * OoOO + II11iII
    iiiiiI = O0O0Oo00
    if 17 - 17: i11iIiiIii / ii11ii1ii . OoOO / OOooOOo
   except :
    pass
  i1iI1 = i11ii1ii11i ( iiiiiI )
  ooO0OoOO = re . compile ( OOooOoooOoOo ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i , id , Oo0oooO0oO , IiIiII1 , oo00 in ooO0OoOO :
   try :
    OO0O00oOo ( IiI , iI1ii1i , iI1 , id , Oo0oooO0oO , IiIiII1 , oo00 )
    if 38 - 38: i1IIi . o00O0oo % o0oO0 + iIii1I11I1II1 + O0
   except :
    pass
 except :
  pass
  if 47 - 47: OoOO + II11iII / II111iiii
def OO0oii1I11II1 ( ) :
 if 46 - 46: OoOO0ooOOoo0O
 try :
  if 83 - 83: i11iIiiIii * OoOo
  i1iI1 = i11ii1ii11i ( I1III1111iIi )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 49 - 49: ii11ii1ii * oO0o0ooO0 + o0000oOoOoO0o - i11iIiiIii
   try :
    if 74 - 74: ii11ii1ii / iIii1I11I1II1 . II111iiii - OoOO
    O0Oo0 = O0O0Oo00
    if 46 - 46: OOooOOo * OoOO0ooOOoo0O
   except :
    pass
  i1iI1 = i11ii1ii11i ( O0Oo0 )
  ooO0OoOO = re . compile ( IiI111111IIII ) . findall ( i1iI1 )
  for iI1 , IiI , iI1ii1i in ooO0OoOO :
   try :
    oOoO00O000 ( iI1 , IiI , iI1ii1i )
    if 54 - 54: O0 - iiiIi1i1I . IIII % iiiIi1i1I + iiiIi1i1I
   except :
    pass
    if 36 - 36: IIII % i11iIiiIii
 except :
  pass
  if 47 - 47: i1IIi + II111iiii . ii11ii1ii * oO0o0ooO0 . O0oO / i1IIi
  if 50 - 50: OoOo / i1IIi % OoooooooOO
  if 83 - 83: o00O0oo * o00O0oo + IIII
def oOoO00O000 ( thumb , name , url ) :
 if 57 - 57: O0 - O0 . o00O0oo / o0000oOoOoO0o / o0oO0
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( o00oooO0Oo ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   IIiIiI1I ( name , url , '' , o00 , oo00 )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 20 - 20: IIII * II111iiii - OoOO0ooOOoo0O - oO0o0ooO0 * OoOo
  if 'tvg-logo' in thumb :
   thumb = re . compile ( o00oooO0Oo ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 6 - 6: iii11I111 + IIII / ii11ii1ii + II11iII % II111iiii / OoOO
   iiIi ( name , url , 4 , i1iI , oo00 )
   if 74 - 74: O0 + OoooooooOO / oO0o0ooO0 / OoOO0ooOOoo0O . o00O0oo % oO0o0ooO0
  else :
   if 34 - 34: i1IIi . OOooOOo
   iiIi ( name , url , 4 , i1iI , oo00 )
   if 6 - 6: OoOo % oO0o0ooO0 % o0oO0
def OooIi ( name , url , thumb , id , trailer ) :
 if 92 - 92: oO0o0ooO0 / IIII . o00O0oo
 if 30 - 30: o0oO0 . o00O0oo / IIII
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 2 - 2: II11iII % OOooOOo - OoOo
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( o00oooO0Oo ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   IIiIiI1I ( name , url , '' , o00 , oo00 )
 else :
  IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
  if 79 - 79: OoooooooOO / o00O0oo . O0
  name = '[COLOR %s]' % IIIi1I1IIii1II + name + '[/COLOR]'
  if 79 - 79: oO0o0ooO0 - II111iiii
  if 'tvg-logo' in thumb :
   thumb = re . compile ( o00oooO0Oo ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'selecton' )
   if O0o0O00Oo0o0 == 'true' :
    if 43 - 43: i1IIi + O0 % OoOO / o0oO0 * OOooOOo
    OoOi1iI11Iii ( name , url , 1 , thumb , thumb , id , trailer )
    if 91 - 91: IIII + iii11I111 % OOooOOo - iii11I111 - oO0o0ooO0
   else :
    if 42 - 42: OoOO0ooOOoo0O
    OoOi1iI11Iii ( name , url , 130 , thumb , thumb , id , trailer )
    if 79 - 79: i1IIi
  else :
   if 1 - 1: oO0o0ooO0 / i1IIi
   if O0o0O00Oo0o0 == 'true' :
    if 74 - 74: O0oO / OoooooooOO / ii11ii1ii * i11iIiiIii . II111iiii . OoooooooOO
    OoOi1iI11Iii ( name , url , 1 , thumb , thumb , id , trailer )
    if 59 - 59: i11iIiiIii . OoooooooOO / O0oO * o00O0oo + OoooooooOO
   else :
    if 3 - 3: i11iIiiIii * ii11ii1ii % iIii1I11I1II1 % OOooOOo * iiiIi1i1I / IIII
    OoOi1iI11Iii ( name , url , 130 , thumb , thumb , id , trailer )
    if 95 - 95: II11iII * O0 * OoOo . OoooooooOO % ii11ii1ii + o00O0oo
    if 98 - 98: oO0o0ooO0 . OoooooooOO
def OO0O00oOo ( name , url , thumb , id , trailer , description , fanart ) :
 if 54 - 54: O0 / II11iII % iii11I111 * i1IIi * O0
 if 48 - 48: o0000oOoOoO0o . oO0o0ooO0 % OoOO0ooOOoo0O - OoOO0ooOOoo0O
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
 fanart = fanart . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 name = '[COLOR %s]' % IIIi1I1IIii1II + name + '[/COLOR]'
 if 33 - 33: O0oO % II111iiii + OoOO
 if 'tvg-logo' in thumb :
  thumb = re . compile ( o00oooO0Oo ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'selecton' )
  if O0o0O00Oo0o0 == 'true' :
   if 93 - 93: i1IIi . II11iII / OOooOOo + II11iII
   OOooOO ( name , url , 1 , thumb , fanart , id , trailer , description )
   if 59 - 59: OoOO - OoOO + iiiIi1i1I
  else :
   if 32 - 32: i1IIi / ii11ii1ii - O0
   OOooOO ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 85 - 85: o0oO0 - O0 * i11iIiiIii . i1IIi
 else :
  if 20 - 20: iiiIi1i1I / IIII
  if O0o0O00Oo0o0 == 'true' :
   if 28 - 28: iii11I111 * O0oO % i11iIiiIii * iiiIi1i1I / o0oO0
   OOooOO ( name , url , 1 , thumb , fanart , id , trailer , description )
   if 41 - 41: IIII - o0000oOoOoO0o + o0oO0
  else :
   if 15 - 15: O0oO / o0000oOoOoO0o + o0oO0
   OOooOO ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 76 - 76: o0oO0 + OoooooooOO / IIII % OoOO / o00O0oo
def I1i ( name , trailer ) :
 if 82 - 82: OoOO + OoOO % o0000oOoOoO0o % i11iIiiIii / OoOo % OoooooooOO
 if Oo0OoO00oOO0o == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Realstream, Reproduciendo Trailer de: [COLOR green]" + name + "[/COLOR] ,5000)" )
  if 96 - 96: oO0o0ooO0 - oO0o0ooO0
  iI1ii1i = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  OOOo = iI1ii1i
  I1iiIi1 = xbmcgui . ListItem ( name , trailer , path = OOOo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1iiIi1 )
 else :
  iI1ii1i = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  OOOo = iI1ii1i
  I1iiIi1 = xbmcgui . ListItem ( name , trailer , path = OOOo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1iiIi1 )
  if 49 - 49: iii11I111 . II111iiii
  if 24 - 24: O0 . OoooooooOO - OoOO * OoooooooOO
def Ii11iiI ( trailer ) :
 if 71 - 71: OoOo - o0000oOoOoO0o - IIII
 if 'https://www.youtube.com' in trailer :
  if 28 - 28: iIii1I11I1II1
  try :
   if 7 - 7: o0000oOoOoO0o % II11iII * OoOO0ooOOoo0O
   import resolveurl
   if 58 - 58: II11iII / O0oO + II111iiii % iiiIi1i1I - OoooooooOO
   iIIi1I1ii = urlresolver . HostedMediaFile ( iI1ii1i )
   oO0 = xbmcgui . DialogProgress ( )
   oO0 . create ( 'Realstream:' , 'Conectando al servidor ... ' )
   oO0 . update ( 20 , 'Por favor, espere ...' )
   xbmc . sleep ( 500 )
   if 25 - 25: OoOO0ooOOoo0O % OoooooooOO * ii11ii1ii - i1IIi * II111iiii * oO0o0ooO0
   if not iIIi1I1ii :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    return False
    if 30 - 30: O0oO % OoOO0ooOOoo0O / o00O0oo * O0 * o0oO0 . OOooOOo
   try :
    if 46 - 46: OoOO0ooOOoo0O - O0
    oO0 . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    i1I11iIII1i1I = iIIi1I1ii . resolve ( )
    if not i1I11iIII1i1I or not isinstance ( i1I11iIII1i1I , basestring ) :
     try : oOO0oo = i1I11iIII1i1I . msg
     except : oOO0oo = i1I11iIII1i1I
     raise Exception ( oOO0oo )
   except Exception as OOo00OoO :
    try : oOO0oo = str ( OOo00OoO )
    except : oOO0oo = i1I11iIII1i1I
    oO0 . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
    oO0 . close ( )
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    if 70 - 70: O0oO + ii11ii1ii * iIii1I11I1II1 . OOooOOo * O0oO
   oO0 . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
   xbmc . sleep ( 500 )
   oO0 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   oO0 . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
   xbmc . sleep ( 500 )
   oO0 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   oO0 . close ( )
   if 49 - 49: o0000oOoOoO0o
   oO0oooooo = xbmcgui . ListItem ( path = i1I11iIII1i1I )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO0oooooo )
   if 25 - 25: iiiIi1i1I . OoooooooOO * iIii1I11I1II1 . o0000oOoOoO0o / O0 + o0oO0
  except :
   pass
   if 68 - 68: ii11ii1ii
  else :
   if 22 - 22: IIII
   iI1ii1i = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
   OOOo = iI1ii1i
   I1iiIi1 = xbmcgui . ListItem ( trailer , path = OOOo )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1iiIi1 )
   return
   if 22 - 22: iiiIi1i1I * O0oO - ii11ii1ii * O0 / i11iIiiIii
def OOooO0Oo0o000 ( name , url ) :
 if 17 - 17: iIii1I11I1II1 + OOooOOo
 if '[Youtube]' in name :
  if 57 - 57: o0000oOoOoO0o / OoOo
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  OOOo = url
  I1iiIi1 = xbmcgui . ListItem ( Oo0oooO0oO , path = OOOo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1iiIi1 )
  if 13 - 13: OoooooooOO + OoOO
  if 32 - 32: O0 + oO0o0ooO0 % ii11ii1ii
 else :
  if 7 - 7: o00O0oo / iii11I111
  import urlresolver
  from urlresolver import common
  if 11 - 11: II11iII * iii11I111 / iii11I111 - IIII
  iIIi1I1ii = urlresolver . HostedMediaFile ( url )
  if 68 - 68: OOooOOo % II11iII - II11iII / OOooOOo + o00O0oo - ii11ii1ii
  if not iIIi1I1ii :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 65 - 65: iii11I111 - i1IIi
   if 62 - 62: O0oO / oO0o0ooO0 % ii11ii1ii . OoooooooOO / i11iIiiIii / OoOo
  try :
   i1I11iIII1i1I = iIIi1I1ii . resolve ( )
   if not i1I11iIII1i1I or not isinstance ( i1I11iIII1i1I , basestring ) :
    try : oOO0oo = i1I11iIII1i1I . msg
    except : oOO0oo = url
    raise Exception ( oOO0oo )
  except Exception as OOo00OoO :
   try : oOO0oo = str ( OOo00OoO )
   except : oOO0oo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 60 - 60: OOooOOo % oO0o0ooO0 / o0000oOoOoO0o % oO0o0ooO0 * i11iIiiIii / iiiIi1i1I
  Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if Oo0OoO00oOO0o == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  oO0oooooo = xbmcgui . ListItem ( path = i1I11iIII1i1I )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO0oooooo )
  if 34 - 34: OoOo - IIII
  if 25 - 25: oO0o0ooO0 % OOooOOo + i11iIiiIii + O0 * OoooooooOO
 return
 if 64 - 64: i1IIi
def I1ii1i1iiii ( name , url ) :
 if 45 - 45: o0oO0 / iii11I111 . OoooooooOO + OoOO
 import resolveurl
 if 51 - 51: iiiIi1i1I % i11iIiiIii % II11iII + OoOo % o00O0oo
 iIIi1I1ii = urlresolver . HostedMediaFile ( url )
 dp = xbmcgui . DialogProgress ( )
 dp . create ( 'Realstream:' , 'Conectando al servidor ... ' )
 dp . update ( 20 , 'Por favor, espere ...' )
 xbmc . sleep ( 500 )
 if 16 - 16: OoOO0ooOOoo0O / ii11ii1ii + O0 - OoOO0ooOOoo0O . OoooooooOO
 if not iIIi1I1ii :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  return False
  if 19 - 19: o0000oOoOoO0o
 try :
  if 73 - 73: OoOo * ii11ii1ii * OoOO0ooOOoo0O
  dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
  xbmc . sleep ( 500 )
  i1I11iIII1i1I = iIIi1I1ii . resolve ( )
  if not i1I11iIII1i1I or not isinstance ( i1I11iIII1i1I , basestring ) :
   try : oOO0oo = i1I11iIII1i1I . msg
   except : oOO0oo = i1I11iIII1i1I
   raise Exception ( oOO0oo )
 except Exception as OOo00OoO :
  try : oOO0oo = str ( OOo00OoO )
  except : oOO0oo = i1I11iIII1i1I
  dp . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
  dp . close ( )
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  if 65 - 65: i11iIiiIii + ii11ii1ii * OoooooooOO - OoOO
 dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
 xbmc . sleep ( 500 )
 dp . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
 xbmc . sleep ( 500 )
 dp . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
 xbmc . sleep ( 500 )
 dp . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
 dp . close ( )
 Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
 if 26 - 26: o0000oOoOoO0o % IIII + IIII % O0oO * i11iIiiIii / iiiIi1i1I
 if 64 - 64: oO0o0ooO0 % OoOO0ooOOoo0O / II111iiii % iii11I111 - iiiIi1i1I
 if '[Realstream]' or '[Mybox]' in name :
  restante = IiII1IiiIiI1 . getSetting ( 'restante' )
 elif restante == 'true' :
  dialog = xbmcgui . Dialog ( )
  ok = dialog . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
 oO0oooooo = xbmcgui . ListItem ( path = i1I11iIII1i1I )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO0oooooo )
 if 2 - 2: OoOo - o00O0oo + o0000oOoOoO0o * OoOO / iiiIi1i1I
def I1ii1i1iiii ( name , url ) :
 if 26 - 26: IIII * ii11ii1ii
 if 31 - 31: O0oO * oO0o0ooO0 . o0oO0
 if 'https://www.rapidvideo.com/v/' in url :
  if 35 - 35: O0oO
  i1iI1 = i11ii1ii11i ( url )
  ooO0OoOO = re . compile ( 'rapidvideo' ) . findall ( i1iI1 )
  for url in ooO0OoOO :
   if 94 - 94: iii11I111 / i11iIiiIii % O0
   if 70 - 70: O0oO - ii11ii1ii / OoooooooOO % OoooooooOO
   try :
    Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
    if Oo0OoO00oOO0o == 'true' :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oO0oooooo = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO0oooooo )
    if 95 - 95: OoooooooOO % OoooooooOO . o0oO0
   except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 26 - 26: oO0o0ooO0 + II11iII - II111iiii . II111iiii + o00O0oo + OoOO0ooOOoo0O
   if 68 - 68: O0
 else :
  if 76 - 76: o00O0oo
  import urlresolver
  from urlresolver import common
  if 99 - 99: o0000oOoOoO0o
  iIIi1I1ii = urlresolver . HostedMediaFile ( url )
  if 1 - 1: o0oO0 * OoOO0ooOOoo0O * OoOO + ii11ii1ii
  if not iIIi1I1ii :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 90 - 90: OoOo % ii11ii1ii - ii11ii1ii . iIii1I11I1II1 / IIII + O0oO
   if 89 - 89: oO0o0ooO0
  try :
   i1I11iIII1i1I = iIIi1I1ii . resolve ( )
   if not i1I11iIII1i1I or not isinstance ( i1I11iIII1i1I , basestring ) :
    try : oOO0oo = i1I11iIII1i1I . msg
    except : oOO0oo = url
    raise Exception ( oOO0oo )
  except Exception as OOo00OoO :
   try : oOO0oo = str ( OOo00OoO )
   except : oOO0oo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 87 - 87: iiiIi1i1I % ii11ii1ii
  Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if Oo0OoO00oOO0o == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  oO0oooooo = xbmcgui . ListItem ( path = i1I11iIII1i1I )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO0oooooo )
  if 62 - 62: OoOO + iii11I111 / iiiIi1i1I * i11iIiiIii
 return
 if 37 - 37: iiiIi1i1I
 if 33 - 33: OoOO - O0 - OoOO
 if 94 - 94: II11iII * O0oO * OoooooooOO / o0000oOoOoO0o . II11iII - o0000oOoOoO0o
def I1I1i ( name , url ) :
 if 45 - 45: IIII
 i1I11iIII1i1I = url
 Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
 if Oo0OoO00oOO0o == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  oO0oooooo = xbmcgui . ListItem ( path = i1I11iIII1i1I )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO0oooooo )
 else :
  oO0oooooo = xbmcgui . ListItem ( path = i1I11iIII1i1I )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO0oooooo )
 return
 if 25 - 25: IIII % O0
def I11oO0oo ( name , url ) :
 if 54 - 54: IIII . OoOo * oO0o0ooO0 % ii11ii1ii - O0oO
 if 74 - 74: o00O0oo - iiiIi1i1I * i1IIi
 if '[Youtube]' in name :
  if 12 - 12: O0
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 75 - 75: iIii1I11I1II1 % II11iII + o00O0oo * O0 . iiiIi1i1I - iii11I111
  try :
   Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if Oo0OoO00oOO0o == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oO0oooooo = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO0oooooo )
    if 32 - 32: o0oO0 % oO0o0ooO0 - i1IIi
    if 40 - 40: iIii1I11I1II1 + iiiIi1i1I * OoOO0ooOOoo0O + oO0o0ooO0
    if 15 - 15: O0oO % OOooOOo - iIii1I11I1II1 * iii11I111
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 71 - 71: OoOO0ooOOoo0O % ii11ii1ii % iii11I111
  if 34 - 34: O0oO / O0oO % II11iII . OoOO0ooOOoo0O / ii11ii1ii
 else :
  if 99 - 99: iii11I111 * OOooOOo - iii11I111 % o0oO0
  import xbmcgui
  import urlresolver
  from urlresolver import common
  if 40 - 40: IIII / II11iII / iIii1I11I1II1 + o0oO0
  iIIi1I1ii = urlresolver . HostedMediaFile ( url )
  if 59 - 59: O0oO * OoooooooOO + IIII . iIii1I11I1II1 / i1IIi
  if not iIIi1I1ii :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 75 - 75: O0oO . IIII - iIii1I11I1II1 * OoOO * iiiIi1i1I
  import resolveurl as urlresolver
  if 93 - 93: iii11I111
  iIIi1I1ii = urlresolver . HostedMediaFile ( url )
  if 18 - 18: iii11I111
  if 66 - 66: oO0o0ooO0 * i11iIiiIii + OoOO0ooOOoo0O / IIII
  if not iIIi1I1ii :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 96 - 96: IIII + IIII % II11iII % IIII
  try :
   i1I11iIII1i1I = iIIi1I1ii . resolve ( )
   if not i1I11iIII1i1I or not isinstance ( i1I11iIII1i1I , basestring ) :
    try : oOO0oo = i1I11iIII1i1I . msg
    except : oOO0oo = url
    raise Exception ( oOO0oo )
  except Exception as OOo00OoO :
   try : oOO0oo = str ( OOo00OoO )
   except : oOO0oo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 28 - 28: iIii1I11I1II1 + OoOO0ooOOoo0O . o0000oOoOoO0o % i11iIiiIii
   if 58 - 58: O0oO / OoooooooOO % oO0o0ooO0 + OoOO
   if 58 - 58: O0
  Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if Oo0OoO00oOO0o == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 91 - 91: iiiIi1i1I / o00O0oo . iiiIi1i1I - o0000oOoOoO0o + o00O0oo
   if '[Realstream]' in name :
    if 72 - 72: o0oO0 . II11iII * o00O0oo / o00O0oo / iiiIi1i1I
    OOoOO0oo0ooO = IiII1IiiIiI1 . getSetting ( 'restante' )
    if OOoOO0oo0ooO == 'true' :
     iiI1 = xbmcgui . Dialog ( )
     oooo0OOo = iiI1 . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 4 - 4: ii11ii1ii - OoOO - i11iIiiIii * OoOo / o0oO0 - IIII
   oO0oooooo = xbmcgui . ListItem ( path = i1I11iIII1i1I )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO0oooooo )
   if 45 - 45: o0000oOoOoO0o % ii11ii1ii * i1IIi - O0
   if 82 - 82: II111iiii / iiiIi1i1I
   if 96 - 96: ii11ii1ii / oO0o0ooO0 . II111iiii . ii11ii1ii
 return
 if 91 - 91: II111iiii . IIII + o0000oOoOoO0o
 if 8 - 8: IIII * ii11ii1ii / iiiIi1i1I - OoOO - OoooooooOO
 if 100 - 100: oO0o0ooO0 . iIii1I11I1II1 . iIii1I11I1II1
def oOOo0ooO0 ( name , url ) :
 if 38 - 38: OoOo
 if 18 - 18: iiiIi1i1I / o0000oOoOoO0o + II11iII % oO0o0ooO0 - II11iII
 if '[Youtube]' in name :
  if 18 - 18: OOooOOo + iii11I111 % o00O0oo - OoOO0ooOOoo0O * i11iIiiIii . o0000oOoOoO0o
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 16 - 16: ii11ii1ii
  try :
   Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if Oo0OoO00oOO0o == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oO0oooooo = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO0oooooo )
    if 74 - 74: O0oO
    if 98 - 98: oO0o0ooO0 / OoooooooOO % o0oO0 * II111iiii - OoOO
    if 95 - 95: OOooOOo % OoOo * OOooOOo + O0 . OoOo % OoooooooOO
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 6 - 6: OoOO0ooOOoo0O - iii11I111 * o0000oOoOoO0o + OoOO0ooOOoo0O % o0000oOoOoO0o
 else :
  if 100 - 100: OoOO % OoOo - O0oO % O0oO % O0oO / iii11I111
  import resolveurl
  if 83 - 83: oO0o0ooO0 - iii11I111 - II11iII % i1IIi - iiiIi1i1I . o0000oOoOoO0o
  iIIi1I1ii = urlresolver . HostedMediaFile ( url )
  if 96 - 96: ii11ii1ii + OoOo . i1IIi
  if 54 - 54: II111iiii . i1IIi / o00O0oo % OOooOOo / OoOo
  if not iIIi1I1ii :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 65 - 65: OoOO0ooOOoo0O . OoOO0ooOOoo0O - oO0o0ooO0 + ii11ii1ii / i11iIiiIii
  try :
   i1I11iIII1i1I = iIIi1I1ii . resolve ( )
   if not i1I11iIII1i1I or not isinstance ( i1I11iIII1i1I , basestring ) :
    try : oOO0oo = i1I11iIII1i1I . msg
    except : oOO0oo = url
    raise Exception ( oOO0oo )
  except Exception as OOo00OoO :
   try : oOO0oo = str ( OOo00OoO )
   except : oOO0oo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 90 - 90: iIii1I11I1II1 + OoOO0ooOOoo0O
   if 9 - 9: iIii1I11I1II1 . OoooooooOO + i1IIi - ii11ii1ii
   if 30 - 30: iiiIi1i1I / OoOO . iiiIi1i1I
  Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if Oo0OoO00oOO0o == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 17 - 17: ii11ii1ii + OoooooooOO * OoooooooOO
   if '[Realstream]' in name :
    if 5 - 5: OoOo % OoooooooOO . OoOO0ooOOoo0O
    OOoOO0oo0ooO = IiII1IiiIiI1 . getSetting ( 'restante' )
    if OOoOO0oo0ooO == 'true' :
     iiI1 = xbmcgui . Dialog ( )
     oooo0OOo = iiI1 . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 67 - 67: o00O0oo + o0oO0
   oO0oooooo = xbmcgui . ListItem ( path = i1I11iIII1i1I )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO0oooooo )
   if 72 - 72: II11iII % o0000oOoOoO0o
   if 93 - 93: iIii1I11I1II1 + i11iIiiIii . o0000oOoOoO0o . i1IIi % OOooOOo % iii11I111
   if 74 - 74: OoOO0ooOOoo0O / i1IIi % OoooooooOO
 return
 if 52 - 52: II11iII % iii11I111
def I111 ( name , url ) :
 if 51 - 51: o00O0oo * oO0o0ooO0
 if 23 - 23: i11iIiiIii
 if '[Youtube]' in name :
  if 100 - 100: oO0o0ooO0 + O0 . OOooOOo + i1IIi - OoOO0ooOOoo0O + o0000oOoOoO0o
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 65 - 65: II111iiii / ii11ii1ii
  try :
   Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if Oo0OoO00oOO0o == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oO0oooooo = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO0oooooo )
    if 42 - 42: i11iIiiIii . O0
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 75 - 75: OoOo + iIii1I11I1II1
 else :
  if 19 - 19: OOooOOo + i11iIiiIii . II11iII - O0oO / o0oO0 + o0000oOoOoO0o
  if 'https://team.com' in url :
   if 38 - 38: ii11ii1ii / iIii1I11I1II1 * iIii1I11I1II1 % o00O0oo
   url = url . replace ( 'https://team.com' , 'https://verystream.com' )
   if 92 - 92: O0oO / O0 * OOooOOo - O0oO
  if 'https://mybox.com' in url :
   if 99 - 99: i11iIiiIii % OoooooooOO
   url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
   if 56 - 56: II11iII * OoOo
  if 'https://drive.com' in url :
   if 98 - 98: O0oO + O0 * OoOo + i11iIiiIii - IIII - iIii1I11I1II1
   url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
   if 5 - 5: IIII % ii11ii1ii % II11iII % iii11I111
  if 'https://vid.co' in url :
   if 17 - 17: o0oO0 + II111iiii + OoooooooOO / IIII / II11iII
   url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
   if 80 - 80: o0000oOoOoO0o % i1IIi / O0oO
  if 'https://limited.to' in url :
   if 56 - 56: i1IIi . i11iIiiIii
   url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
   if 15 - 15: II111iiii * oO0o0ooO0 % iiiIi1i1I / i11iIiiIii - oO0o0ooO0 + ii11ii1ii
  import resolveurl
  if 9 - 9: O0oO - oO0o0ooO0 + O0 / iiiIi1i1I % i1IIi
  iIIi1I1ii = urlresolver . HostedMediaFile ( url )
  if 97 - 97: o0000oOoOoO0o * iii11I111
  if 78 - 78: O0oO . IIII + oO0o0ooO0 * iiiIi1i1I - i1IIi
  if not iIIi1I1ii :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no encontrado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 27 - 27: o0oO0 % i1IIi . ii11ii1ii % OoOo
  try :
   i1I11iIII1i1I = iIIi1I1ii . resolve ( )
   if not i1I11iIII1i1I or not isinstance ( i1I11iIII1i1I , basestring ) :
    try : oOO0oo = i1I11iIII1i1I . msg
    except : oOO0oo = url
    raise Exception ( oOO0oo )
  except Exception as OOo00OoO :
   try : oOO0oo = str ( OOo00OoO )
   except : oOO0oo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace borrado, o no encontrado. Prueba a reiniciar el router o poner una VPN.[/COLOR]  ,5000)" )
   return False
   if 10 - 10: II11iII / OoooooooOO
   if 50 - 50: i11iIiiIii - OoooooooOO . oO0o0ooO0 + O0 . i1IIi
   if 91 - 91: o0000oOoOoO0o . iiiIi1i1I % ii11ii1ii - iiiIi1i1I . oO0o0ooO0 % i11iIiiIii
   Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if Oo0OoO00oOO0o == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
    if 25 - 25: iIii1I11I1II1
    if '[Realstream]' or '[Mybox]' in name :
     OOoOO0oo0ooO = IiII1IiiIiI1 . getSetting ( 'restante' )
    elif OOoOO0oo0ooO == 'true' :
     iiI1 = xbmcgui . Dialog ( )
     oooo0OOo = iiI1 . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 63 - 63: iii11I111
  oO0oooooo = xbmcgui . ListItem ( path = i1I11iIII1i1I )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO0oooooo )
  if 96 - 96: O0oO
 return
 if 34 - 34: OoOO0ooOOoo0O / OoOO - OOooOOo . O0 . IIII
def oooO0o0oOoO ( name , url ) :
 if 23 - 23: II11iII + iIii1I11I1II1 % iIii1I11I1II1 / iii11I111 . oO0o0ooO0 + iIii1I11I1II1
 if 93 - 93: oO0o0ooO0 * o0000oOoOoO0o / IIII - IIII . iiiIi1i1I / OOooOOo
 if '[Youtube]' in name :
  if 11 - 11: OoOo - O0oO % i11iIiiIii . iIii1I11I1II1 * OOooOOo - ii11ii1ii
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 73 - 73: O0 + iii11I111 - O0 / OoooooooOO * ii11ii1ii
  try :
   Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if Oo0OoO00oOO0o == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oO0oooooo = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO0oooooo )
    if 32 - 32: OoOO % OOooOOo % iiiIi1i1I
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 66 - 66: OoOO0ooOOoo0O + o0000oOoOoO0o
 else :
  if 54 - 54: o00O0oo + o00O0oo + O0oO % i1IIi % i11iIiiIii
  Oo0oOOo = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
  i1Oo0oO00o = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  i11I1II1I11i = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  ooO000O = IiII1IiiIiI1 . getSetting ( 'key_ext' )
  i1iI1 = i11ii1ii11i ( i11I1II1I11i )
  ooO0OoOO = re . compile ( I1IIII1i ) . findall ( i1iI1 )
  for oOIII111iiIi1 in ooO0OoOO :
   if 100 - 100: o00O0oo
   try :
    if 96 - 96: OOooOOo . II11iII * II111iiii % II11iII . OoOo * i1IIi
    if 83 - 83: iIii1I11I1II1
    Oo0oOOo = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
    if 97 - 97: i11iIiiIii + ii11ii1ii * IIII % iiiIi1i1I . II11iII
    if 4 - 4: O0 . iiiIi1i1I - iIii1I11I1II1
    if Oo0oOOo == oOIII111iiIi1 :
     if 19 - 19: IIII % OoOO / o0oO0 + II111iiii % OoooooooOO
     if 89 - 89: o0oO0
     if 'https://team.com' in url :
      if 51 - 51: iiiIi1i1I
      url = url . replace ( 'https://team.com' , 'https://verystream.com' )
      if 68 - 68: iiiIi1i1I - o0000oOoOoO0o * OoOO % iii11I111 . iii11I111 - iIii1I11I1II1
     if 'https://mybox.com' in url :
      if 22 - 22: OoooooooOO / o00O0oo % iiiIi1i1I * OoOO0ooOOoo0O
      url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
      if 32 - 32: OoooooooOO % oO0o0ooO0 % iIii1I11I1II1 / O0
      if 61 - 61: II111iiii . O0 - o0oO0 - o00O0oo / i11iIiiIii - II111iiii
     if 'https://vidcloud.co/' in url :
      if 98 - 98: o0oO0 - OOooOOo . i11iIiiIii * ii11ii1ii
      url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
      if 29 - 29: o0oO0 / iii11I111 % O0oO
     if 'https://gounlimited.to' in url :
      if 10 - 10: iIii1I11I1II1 % OoooooooOO % o00O0oo
      url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
      if 39 - 39: II111iiii * OoOO0ooOOoo0O . O0 * O0oO
     if 'https://drive.com' in url :
      if 89 - 89: o0oO0 - iii11I111 . O0oO - OoOo - OOooOOo
      url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
      if 79 - 79: II11iII + II11iII + o0oO0
      if 39 - 39: O0 - OoooooooOO
     import resolveurl
     if 63 - 63: iIii1I11I1II1 % o0000oOoOoO0o * iii11I111
     iIIi1I1ii = urlresolver . HostedMediaFile ( url )
     if 79 - 79: O0
     if not iIIi1I1ii :
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
      return False
      if 32 - 32: II111iiii . O0 + o0oO0 / OoOO0ooOOoo0O / II11iII / IIII
     try :
      oO0 = xbmcgui . DialogProgress ( )
      oO0 . create ( 'Realstream:' , 'Iniciando ...' )
      oO0 . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
      xbmc . sleep ( 1000 )
      if 15 - 15: o00O0oo
      i1I11iIII1i1I = iIIi1I1ii . resolve ( )
      if not i1I11iIII1i1I or not isinstance ( i1I11iIII1i1I , basestring ) :
       if 4 - 4: II11iII + iIii1I11I1II1 * iiiIi1i1I + ii11ii1ii * o0000oOoOoO0o % II111iiii
       try : oOO0oo = i1I11iIII1i1I . msg
       except : oOO0oo = url
       raise Exception ( oOO0oo )
       if 88 - 88: oO0o0ooO0 - i1IIi % i11iIiiIii % II111iiii * OoooooooOO
     except Exception as OOo00OoO :
      try : oOO0oo = str ( OOo00OoO )
      except : oOO0oo = url
      oO0 . update ( 45 , 'RESOLVEURL:' , 'Reiniciando ... ' )
      xbmc . sleep ( 1000 )
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no disponible.  ,3000)" )
      oO0 . close ( )
      if 40 - 40: ii11ii1ii
     oO0 . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
     xbmc . sleep ( 500 )
     oO0 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
     xbmc . sleep ( 1000 )
     oO0 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
     oO0 . close ( )
     Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'notificar' )
     oO0oooooo = xbmcgui . ListItem ( path = i1I11iIII1i1I )
     xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO0oooooo )
     if 47 - 47: OoOO0ooOOoo0O
     if 65 - 65: O0 + OoOo % o0oO0 * OOooOOo / iii11I111 / OoOO0ooOOoo0O
    else :
     if 71 - 71: i11iIiiIii / OoOO0ooOOoo0O . oO0o0ooO0
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold]>El addon esta desactivado.[/COLOR]" )
     return False
     if 33 - 33: oO0o0ooO0
   except :
    pass
    if 39 - 39: OoOO + O0 + iii11I111 * II111iiii % O0 - O0
 return
 if 41 - 41: II11iII % o0000oOoOoO0o
def oo0O0oOOO0o ( ) :
 if 70 - 70: ii11ii1ii % o0oO0 . o00O0oo
 Ii1111iiI = [ ]
 I1I = sys . argv [ 2 ]
 if len ( I1I ) >= 2 :
  o0oO0oo = sys . argv [ 2 ]
  ooOO00Oo = o0oO0oo . replace ( '?' , '' )
  if ( o0oO0oo [ len ( o0oO0oo ) - 1 ] == '/' ) :
   o0oO0oo = o0oO0oo [ 0 : len ( o0oO0oo ) - 2 ]
  oO00OOOOOO0o = ooOO00Oo . split ( '&' )
  Ii1111iiI = { }
  for iIII in range ( len ( oO00OOOOOO0o ) ) :
   OoO0000 = { }
   OoO0000 = oO00OOOOOO0o [ iIII ] . split ( '=' )
   if ( len ( OoO0000 ) ) == 2 :
    Ii1111iiI [ OoO0000 [ 0 ] ] = OoO0000 [ 1 ]
 return Ii1111iiI
 if 11 - 11: OoOO - o0oO0 + O0 * OoOO
 if 59 - 59: II111iiii
def iIiIi11I1iIii1i11 ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  import urlresolver
  xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
  if 42 - 42: OoOO * i11iIiiIii
def i1II11i1iI1 ( ) :
 iiI1 = xbmcgui . Dialog ( )
 list = (
 OO0 ,
 IIi1II11
 )
 if 63 - 63: OoOo - i1IIi
 iIi11iI1i = iiI1 . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=%s]Accede a themoviedb.com[/COLOR]' % O0ii1ii1ii ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 46 - 46: i1IIi + II111iiii * i1IIi - o0oO0
 if iIi11iI1i :
  if 79 - 79: II111iiii - oO0o0ooO0 * o00O0oo - OoOO0ooOOoo0O . o00O0oo
  if iIi11iI1i < 0 :
   return
  iiII1IIii1i1 = list [ iIi11iI1i - 2 ]
  return iiII1IIii1i1 ( )
 else :
  iiII1IIii1i1 = list [ iIi11iI1i ]
  return iiII1IIii1i1 ( )
 return
 if 38 - 38: iiiIi1i1I * OoooooooOO
def iIi11III ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 16 - 16: OoooooooOO * i11iIiiIii . OoooooooOO - iIii1I11I1II1 * i1IIi
i1iI1IIi1I = iIi11III ( )
if 52 - 52: OoooooooOO / II11iII % II111iiii
def OO0 ( ) :
 if i1iI1IIi1I == 'android' :
  o00oo0000 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  o00oo0000 = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 40 - 40: OOooOOo % iii11I111 % II11iII + OoOO
  if 75 - 75: oO0o0ooO0 - o00O0oo + oO0o0ooO0 + OoooooooOO . i11iIiiIii
def IIi1II11 ( ) :
 if 52 - 52: iiiIi1i1I / iii11I111 - i11iIiiIii + OoooooooOO
 main ( )
 if 33 - 33: O0 + ii11ii1ii - iIii1I11I1II1 % i11iIiiIii / OOooOOo
 if 47 - 47: o00O0oo * oO0o0ooO0 + iIii1I11I1II1 - oO0o0ooO0 / II11iII
 if 86 - 86: II11iII
def Iii1I ( ) :
 iiI1 = xbmcgui . Dialog ( )
 oooII111 = (
 I11iIi ,
 Ii1IIiII1I
 )
 if 85 - 85: ii11ii1ii . i11iIiiIii - i11iIiiIii . OOooOOo . OoOO % OoooooooOO
 iIi11iI1i = iiI1 . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 20 - 20: OoOo + OoOo * II111iiii * iIii1I11I1II1 % O0 * OOooOOo
 if iIi11iI1i :
  if 62 - 62: OoooooooOO / OoOO0ooOOoo0O . II11iII . II11iII % iii11I111
  if iIi11iI1i < 0 :
   return
  iiII1IIii1i1 = oooII111 [ iIi11iI1i - 2 ]
  return iiII1IIii1i1 ( )
 else :
  iiII1IIii1i1 = oooII111 [ iIi11iI1i ]
  return iiII1IIii1i1 ( )
 return
 if 42 - 42: o0000oOoOoO0o . IIII - iii11I111
def iIi11III ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 33 - 33: II111iiii / O0 / II11iII - O0oO - i1IIi
i1iI1IIi1I = iIi11III ( )
if 8 - 8: i11iIiiIii . iiiIi1i1I / iIii1I11I1II1 / o00O0oo / II11iII - o0oO0
def I11iIi ( ) :
 if i1iI1IIi1I == 'android' :
  o00oo0000 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  o00oo0000 = webbrowser . open ( 'https://olpair.com/' )
  if 32 - 32: o0000oOoOoO0o . i1IIi * ii11ii1ii
  if 98 - 98: o0oO0 - II111iiii / OOooOOo . oO0o0ooO0 * II11iII . O0oO
def Ii1IIiII1I ( ) :
 if 25 - 25: i11iIiiIii / OoOO0ooOOoo0O - OoOo / OoOO . o0000oOoOoO0o . o0000oOoOoO0o
 main ( )
 if 6 - 6: oO0o0ooO0 . O0oO
 if 43 - 43: o00O0oo + o0000oOoOoO0o
def iI1iiiiiii ( name , url , id , trailer ) :
 iiI1 = xbmcgui . Dialog ( )
 oooII111 = (
 Oo00oo ,
 oO0oO ,
 o0ooo ,
 i1II11i1iI1 ,
 IiIii11I
 )
 if 97 - 97: i1IIi + iiiIi1i1I . iii11I111 - iiiIi1i1I
 iIi11iI1i = iiI1 . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % O0ii1ii1ii ,

 '[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % O0ii1ii1ii ,

 '[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % O0ii1ii1ii ,

 '[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % O0ii1ii1ii ,

 '[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % O0ii1ii1ii ] )
 if 53 - 53: O0 . OOooOOo
 if iIi11iI1i :
  if 74 - 74: iii11I111 % OoOO0ooOOoo0O / ii11ii1ii
  if iIi11iI1i < 0 :
   return
  iiII1IIii1i1 = oooII111 [ iIi11iI1i - 5 ]
  return iiII1IIii1i1 ( )
 else :
  iiII1IIii1i1 = oooII111 [ iIi11iI1i ]
  return iiII1IIii1i1 ( )
 return
 if 2 - 2: II11iII % II11iII % OoOo
 if 60 - 60: IIII
 if 73 - 73: iii11I111
def Oo00oo ( ) :
 if 86 - 86: OoOO0ooOOoo0O . O0oO / ii11ii1ii * O0oO
 oooO0o0oOoO ( IiI , iI1ii1i )
 if 20 - 20: iii11I111 - IIII * OoOO * o0000oOoOoO0o * IIII / II11iII
def oO0oO ( ) :
 if 40 - 40: OOooOOo * o0000oOoOoO0o . OOooOOo
 I1i ( IiI , Oo0oooO0oO )
 if 62 - 62: iii11I111 + II111iiii % iii11I111
def o0ooo ( ) :
 if 50 - 50: OoooooooOO + oO0o0ooO0 * OOooOOo - o0oO0 / i11iIiiIii
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  iiiIIiiIi = id
  if 86 - 86: OoooooooOO % II111iiii . OoooooooOO * o00O0oo
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % iiiIIiiIi )
  if 9 - 9: ii11ii1ii + iiiIi1i1I
 if Oo0OoO00oOO0o == 'true' :
  if 64 - 64: O0 * OOooOOo / OOooOOo
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + IiI + "[/COLOR] ,5000)" )
  if 57 - 57: o00O0oo / OoooooooOO % o00O0oo . O0 / o00O0oo
def O0OoOo ( ) :
 if 94 - 94: OoOO + OoOO + o00O0oo . OoOO * o0oO0
 i1II11i1iI1 ( )
 if 62 - 62: o0000oOoOoO0o / iIii1I11I1II1
def IiIii11I ( ) :
 if 55 - 55: o0oO0 / OoOO + iiiIi1i1I . II11iII
 i1i1i1I ( )
def IIiIiI1I ( name , url , mode , iconimage , fanart ) :
 if 47 - 47: O0
 OoooO0o = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 oooo0OOo = True
 IIIii1iiIi = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 IIIii1iiIi . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IIIii1iiIi . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  OoooO0o = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  oooo0OOo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OoooO0o , listitem = IIIii1iiIi , isFolder = True )
  return oooo0OOo
 oooo0OOo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OoooO0o , listitem = IIIii1iiIi , isFolder = True )
 return oooo0OOo
 if 83 - 83: O0 + OoOO0ooOOoo0O / O0 / O0oO
def iioo0o0OoOOO ( name , url , mode , iconimage , fanart , description ) :
 if 68 - 68: i1IIi . O0oO . i1IIi + II11iII % OOooOOo
 OoooO0o = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 oooo0OOo = True
 IIIii1iiIi = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 IIIii1iiIi . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 IIIii1iiIi . setProperty ( 'fanart_image' , fanart )
 oooo0OOo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OoooO0o , listitem = IIIii1iiIi , isFolder = True )
 return oooo0OOo
 if 32 - 32: OoOO0ooOOoo0O . iIii1I11I1II1 % oO0o0ooO0 . O0 . OoOO0ooOOoo0O / iiiIi1i1I
def OoOi1iI11Iii ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 45 - 45: iIii1I11I1II1
 oo00O00oO = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 41 - 41: iiiIi1i1I % iiiIi1i1I - II11iII % OoOO - OoooooooOO - iiiIi1i1I
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 oOOo00O0O0 = [ ]
 if 11 - 11: i11iIiiIii + o00O0oo + i11iIiiIii
 oOOo00O0O0 . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 OoooO0o = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 IIIii1iiIi = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 IIIii1iiIi . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IIIii1iiIi . setProperty ( 'fanart_image' , fanart )
 IIIii1iiIi . setProperty ( 'IsPlayable' , 'true' )
 if 31 - 31: oO0o0ooO0 * OoOo . OoOO0ooOOoo0O * O0oO
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  oOOo00O0O0 . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 28 - 28: II11iII + OOooOOo - ii11ii1ii % IIII . O0oO + OOooOOo
  IIIii1iiIi . addContextMenuItems ( oOOo00O0O0 , replaceItems = True )
 oooo0OOo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OoooO0o , listitem = IIIii1iiIi )
 return oooo0OOo
 if 72 - 72: o0oO0 / ii11ii1ii / oO0o0ooO0 * OoOO0ooOOoo0O + IIII
 if 58 - 58: o0000oOoOoO0o % OOooOOo . OOooOOo * OoOO - II11iII . OoooooooOO
def OOooOO ( name , url , mode , iconimage , fanart , id , trailer , description ) :
 if 10 - 10: OoOo
 oo00O00oO = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 48 - 48: iiiIi1i1I * i1IIi % OoooooooOO * o0oO0 * OoOO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 oOOo00O0O0 = [ ]
 if 7 - 7: iiiIi1i1I . o0oO0 . iiiIi1i1I - OoOo
 oOOo00O0O0 . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 OoooO0o = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 IIIii1iiIi = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 IIIii1iiIi . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 IIIii1iiIi . setProperty ( 'fanart_image' , fanart )
 IIIii1iiIi . setProperty ( 'IsPlayable' , 'true' )
 if 33 - 33: iii11I111 + OoooooooOO - OoOO / i1IIi / OoooooooOO
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  oOOo00O0O0 . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 82 - 82: o00O0oo / IIII - iiiIi1i1I / ii11ii1ii * OoOO
  IIIii1iiIi . addContextMenuItems ( oOOo00O0O0 , replaceItems = True )
 oooo0OOo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OoooO0o , listitem = IIIii1iiIi )
 return oooo0OOo
 if 55 - 55: OoooooooOO
def iiIi ( name , url , mode , iconimage , fanart ) :
 if 73 - 73: OoOO0ooOOoo0O - o00O0oo % ii11ii1ii + o00O0oo - O0 . OoOO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 38 - 38: O0
 OoooO0o = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 IIIii1iiIi = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 IIIii1iiIi . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IIIii1iiIi . setProperty ( 'fanart_image' , fanart )
 IIIii1iiIi . setProperty ( 'IsPlayable' , 'true' )
 oooo0OOo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OoooO0o , listitem = IIIii1iiIi )
 return oooo0OOo
 if 79 - 79: i1IIi . oO0o0ooO0
def i1i1i11iI11II ( name , url , mode ) :
 if 6 - 6: OoOO0ooOOoo0O . II111iiii * OOooOOo . OOooOOo / o0oO0
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 14 - 14: OoOo % II11iII - O0 / OoOo
 OoooO0o = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 IIIii1iiIi = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = i1iI )
 IIIii1iiIi . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IIIii1iiIi . setProperty ( 'fanart_image' , oo00 )
 IIIii1iiIi . setProperty ( 'IsPlayable' , 'true' )
 oooo0OOo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OoooO0o , listitem = IIIii1iiIi )
 return oooo0OOo
 if 91 - 91: i11iIiiIii % OoOo * oO0o0ooO0 - o00O0oo . OoOo
def iI ( name , url , mode , iconimage ) :
 OoooO0o = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 oooo0OOo = True
 IIIii1iiIi = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 oooo0OOo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OoooO0o , listitem = IIIii1iiIi , isFolder = True )
 return oooo0OOo
 if 66 - 66: iiiIi1i1I / i11iIiiIii * O0
def O000Oo00 ( ) :
 if 43 - 43: OoOO . iii11I111 * ii11ii1ii
 if 20 - 20: i1IIi . i1IIi - O0oO
 if 89 - 89: iii11I111 - O0oO . O0 % OoooooooOO . i11iIiiIii
 i11I1I1I = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 i11I1I1I . doModal ( )
 if ( i11I1I1I . isConfirmed ( ) ) :
  if 35 - 35: II111iiii / OoOO0ooOOoo0O - O0 . II111iiii
  oo00O00Oo = urllib . quote_plus ( i11I1I1I . getText ( ) ) . replace ( '+' , ' ' )
  if 55 - 55: ii11ii1ii % i1IIi * O0oO
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 95 - 95: IIII / II111iiii - o0000oOoOoO0o % OoOo . O0oO
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % oo00O00Oo )
    if 63 - 63: iIii1I11I1II1 / iii11I111
    if Oo0OoO00oOO0o == 'true' :
     if 24 - 24: ii11ii1ii / iIii1I11I1II1 % IIII * OoOO0ooOOoo0O - iIii1I11I1II1
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + IiI + "[/COLOR] ,10000)" )
     if 50 - 50: II111iiii
   except :
    if 39 - 39: II111iiii . OoOO0ooOOoo0O - ii11ii1ii * i1IIi . OoooooooOO
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 44 - 44: OOooOOo
o0oO0oo = oo0O0oOOO0o ( )
iI1ii1i = None
IiI = None
oOO0O0O0OO00oo = None
i1iI = None
id = None
Oo0oooO0oO = None
if 39 - 39: II11iII % OoOO0ooOOoo0O * o00O0oo - OoooooooOO - ii11ii1ii
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 75 - 75: i11iIiiIii . iii11I111 % i1IIi . OOooOOo - oO0o0ooO0 + ii11ii1ii
try :
 iI1ii1i = urllib . unquote_plus ( o0oO0oo [ "url" ] )
except :
 pass
try :
 IiI = urllib . unquote_plus ( o0oO0oo [ "name" ] )
except :
 pass
try :
 oOO0O0O0OO00oo = int ( o0oO0oo [ "mode" ] )
except :
 pass
try :
 i1iI = urllib . unquote_plus ( o0oO0oo [ "iconimage" ] )
except :
 pass
try :
 id = int ( o0oO0oo [ "id" ] )
except :
 pass
try :
 Oo0oooO0oO = urllib . unquote_plus ( o0oO0oo [ "trailer" ] )
except :
 pass
 if 66 - 66: oO0o0ooO0 % o00O0oo . II111iiii / OoOO0ooOOoo0O / OoOO
 if 47 - 47: iiiIi1i1I + O0 / II111iiii * OOooOOo - OoooooooOO . o0oO0
print "Mode: " + str ( oOO0O0O0OO00oo )
print "URL: " + str ( iI1ii1i )
print "Name: " + str ( IiI )
print "iconimage: " + str ( i1iI )
print "id: " + str ( id )
print "trailer: " + str ( Oo0oooO0oO )
if 28 - 28: oO0o0ooO0 . oO0o0ooO0 . iIii1I11I1II1 . IIII . o00O0oo * i11iIiiIii
if oOO0O0O0OO00oo == None or iI1ii1i == None or len ( iI1ii1i ) < 1 :
 if 72 - 72: O0oO
 i1i1i1I ( )
 Oo00o0OO0O00o ( )
 if 26 - 26: II11iII % ii11ii1ii
elif oOO0O0O0OO00oo == 1 :
 iI1iiiiiii ( IiI , iI1ii1i , id , Oo0oooO0oO )
elif oOO0O0O0OO00oo == 2 :
 oOo0OooOo ( )
elif oOO0O0O0OO00oo == 3 :
 oo0O ( )
elif oOO0O0O0OO00oo == 4 :
 OOooO0Oo0o000 ( IiI , iI1ii1i )
elif oOO0O0O0OO00oo == 5 :
 OOoO00ooO ( )
elif oOO0O0O0OO00oo == 6 :
 iIiIi1ii ( )
elif oOO0O0O0OO00oo == 7 :
 i1iI1IIIII1 ( )
elif oOO0O0O0OO00oo == 8 :
 oOOOO ( )
elif oOO0O0O0OO00oo == 9 :
 oo0iIiI ( )
elif oOO0O0O0OO00oo == 10 :
 Oooo0oooo0OoO0o ( )
elif oOO0O0O0OO00oo == 11 :
 Ooo0o0oo0 ( )
elif oOO0O0O0OO00oo == 12 :
 i1I1i1i ( )
elif oOO0O0O0OO00oo == 13 :
 iii ( )
elif oOO0O0O0OO00oo == 14 :
 oO00 ( )
elif oOO0O0O0OO00oo == 15 :
 OOOO0oOo00O ( )
elif oOO0O0O0OO00oo == 16 :
 i1IiiiiIi1I ( )
elif oOO0O0O0OO00oo == 17 :
 o0O ( )
elif oOO0O0O0OO00oo == 18 :
 Oo00O0OO ( )
elif oOO0O0O0OO00oo == 19 :
 oo0O0o00I1ii1i ( )
elif oOO0O0O0OO00oo == 20 :
 oOooo00000 ( )
elif oOO0O0O0OO00oo == 21 :
 o00oo0OO0 ( )
elif oOO0O0O0OO00oo == 22 :
 i1I1Ii11i ( )
elif oOO0O0O0OO00oo == 23 :
 OOo00ooOoO0o ( )
elif oOO0O0O0OO00oo == 24 :
 IIiii11ii1i ( )
elif oOO0O0O0OO00oo == 25 :
 o0iIIIIi ( )
elif oOO0O0O0OO00oo == 26 :
 i1i1IiIiIi1Ii ( )
elif oOO0O0O0OO00oo == 28 :
 i1II ( IiI , iI1ii1i )
elif oOO0O0O0OO00oo == 29 :
 oo0O0o00 ( )
elif oOO0O0O0OO00oo == 30 :
 OoO0O0oO00 ( )
elif oOO0O0O0OO00oo == 31 :
 prueba ( )
elif oOO0O0O0OO00oo == 98 :
 busqueda_global ( )
elif oOO0O0O0OO00oo == 97 :
 Iii1I ( )
elif oOO0O0O0OO00oo == 99 :
 oo0 ( )
elif oOO0O0O0OO00oo == 100 :
 menu_player ( IiI , iI1ii1i )
elif oOO0O0O0OO00oo == 111 :
 iiiII ( )
elif oOO0O0O0OO00oo == 115 :
 I1i ( iI1ii1i )
elif oOO0O0O0OO00oo == 116 :
 oooO0 ( )
elif oOO0O0O0OO00oo == 117 :
 IIi11IIiIii1 ( )
elif oOO0O0O0OO00oo == 119 :
 OoOo00o0OO ( )
elif oOO0O0O0OO00oo == 120 :
 oOO ( )
elif oOO0O0O0OO00oo == 121 :
 OOoO0 ( )
elif oOO0O0O0OO00oo == 125 :
 OO0oii1I11II1 ( )
elif oOO0O0O0OO00oo == 112 :
 list_proxy ( )
elif oOO0O0O0OO00oo == 127 :
 O000Oo00 ( )
elif oOO0O0O0OO00oo == 128 :
 TESTLINKS ( )
elif oOO0O0O0OO00oo == 130 :
 oooO0o0oOoO ( IiI , iI1ii1i )
elif oOO0O0O0OO00oo == 140 :
 OOO00O0oOOo ( )
elif oOO0O0O0OO00oo == 141 :
 ii1IIiII111I ( )
elif oOO0O0O0OO00oo == 142 :
 Oo00OOo00O ( )
elif oOO0O0O0OO00oo == 143 :
 o000 ( IiI , iI1ii1i )
elif oOO0O0O0OO00oo == 144 :
 i1II ( IiI , iI1ii1i )
elif oOO0O0O0OO00oo == 145 :
 oOoOOo0oo0 ( )
elif oOO0O0O0OO00oo == 150 :
 iIII1i1i ( )
elif oOO0O0O0OO00oo == 151 :
 oo0o0000Oo0 ( )
elif oOO0O0O0OO00oo == 152 :
 ii111i ( )
 if 72 - 72: O0 + o0000oOoOoO0o + OOooOOo / ii11ii1ii
xbmcplugin . endOfDirectory ( o0OoOoOO00 ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
