Database = ''
Novedades = ''
Accion = ''
Aventuras = ''
Animacion = ''
Biografica = ''
Ficcion = ''
Comedia = ''
Crimen = ''
Deporte = ''
Documental = ''
Drama = ''
Familiar = ''
Fantasia = ''
Belico = ''
Suspense = ''
Thriller = ''
Musical = ''
Terror = ''
Romance = ''
Western = ''
Estrenos = ''

def Database():
    name = re.sub('\s+', ' ', name).strip()			
    url = url.replace('"', ' ').replace('&amp;', '&').strip()
	image = image.replace('"', ' ').replace('&amp;', '&').strip()
	fanart = fanart.replace('"', ' ').replace('&amp;', '&').strip()
    content = make_request(Database)
    match = re.compile(Regex).findall(content)
    for name,url,image,fanart in match:
    addDir2(name,url,1,image,fanart)
	
def Novedades():
    name = re.sub('\s+', ' ', name).strip()			
    url = url.replace('"', ' ').replace('&amp;', '&').strip()
	image = image.replace('"', ' ').replace('&amp;', '&').strip()
	fanart = fanart.replace('"', ' ').replace('&amp;', '&').strip()
    content = make_request(Novedades)
    match = re.compile(Regex).findall(content)
    for name,url,image,fanart in match:
    addDir2(name,url,1,image,fanart)

def Accion():
    name = re.sub('\s+', ' ', name).strip()			
    url = url.replace('"', ' ').replace('&amp;', '&').strip()
	image = image.replace('"', ' ').replace('&amp;', '&').strip()
	fanart = fanart.replace('"', ' ').replace('&amp;', '&').strip()
    content = make_request(Accion)
    match = re.compile(Regex).findall(content)
    for name,url,image,fanart in match:
    addDir2(name,url,1,image,fanart)
	
def Aventuras():
    name = re.sub('\s+', ' ', name).strip()			
    url = url.replace('"', ' ').replace('&amp;', '&').strip()
	image = image.replace('"', ' ').replace('&amp;', '&').strip()
	fanart = fanart.replace('"', ' ').replace('&amp;', '&').strip()
    content = make_request(Aventuras)
    match = re.compile(Regex).findall(content)
    for name,url,image,fanart in match:
    addDir2(name,url,1,image,fanart)
	
def Animacion():
    name = re.sub('\s+', ' ', name).strip()			
    url = url.replace('"', ' ').replace('&amp;', '&').strip()
	image = image.replace('"', ' ').replace('&amp;', '&').strip()
	fanart = fanart.replace('"', ' ').replace('&amp;', '&').strip()
    content = make_request(Animacion)
    match = re.compile(Regex).findall(content)
    for name,url,image,fanart in match:
    addDir2(name,url,1,image,fanart)
	
def Biografica():
    name = re.sub('\s+', ' ', name).strip()			
    url = url.replace('"', ' ').replace('&amp;', '&').strip()
	image = image.replace('"', ' ').replace('&amp;', '&').strip()
	fanart = fanart.replace('"', ' ').replace('&amp;', '&').strip()
    content = make_request(Biografica)
    match = re.compile(Regex).findall(content)
    for name,url,image,fanart in match:
    addDir2(name,url,1,image,fanart)
	
def Ficcion():
    name = re.sub('\s+', ' ', name).strip()			
    url = url.replace('"', ' ').replace('&amp;', '&').strip()
	image = image.replace('"', ' ').replace('&amp;', '&').strip()
	fanart = fanart.replace('"', ' ').replace('&amp;', '&').strip()
    content = make_request(Ficcion)
    match = re.compile(Regex).findall(content)
    for name,url,image,fanart in match:
    addDir2(name,url,1,image,fanart)
	
def Comedia():
    name = re.sub('\s+', ' ', name).strip()			
    url = url.replace('"', ' ').replace('&amp;', '&').strip()
	image = image.replace('"', ' ').replace('&amp;', '&').strip()
	fanart = fanart.replace('"', ' ').replace('&amp;', '&').strip()
    content = make_request(Comedia)
    match = re.compile(Regex).findall(content)
    for name,url,image,fanart in match:
    addDir2(name,url,1,image,fanart)
	
def Crimen():
    name = re.sub('\s+', ' ', name).strip()			
    url = url.replace('"', ' ').replace('&amp;', '&').strip()
	image = image.replace('"', ' ').replace('&amp;', '&').strip()
	fanart = fanart.replace('"', ' ').replace('&amp;', '&').strip()
    content = make_request(Crimen)
    match = re.compile(Regex).findall(content)
    for name,url,image,fanart in match:
    addDir2(name,url,1,image,fanart)
	
def Deporte():
    name = re.sub('\s+', ' ', name).strip()			
    url = url.replace('"', ' ').replace('&amp;', '&').strip()
	image = image.replace('"', ' ').replace('&amp;', '&').strip()
	fanart = fanart.replace('"', ' ').replace('&amp;', '&').strip()
    content = make_request(Deporte)
    match = re.compile(Regex).findall(content)
    for name,url,image,fanart in match:
    addDir2(name,url,1,image,fanart)
	
def Documental():
    name = re.sub('\s+', ' ', name).strip()			
    url = url.replace('"', ' ').replace('&amp;', '&').strip()
	image = image.replace('"', ' ').replace('&amp;', '&').strip()
	fanart = fanart.replace('"', ' ').replace('&amp;', '&').strip()
    content = make_request(Documental)
    match = re.compile(Regex).findall(content)
    for name,url,image,fanart in match:
    addDir2(name,url,1,image,fanart)
	
def Drama():
    name = re.sub('\s+', ' ', name).strip()			
    url = url.replace('"', ' ').replace('&amp;', '&').strip()
	image = image.replace('"', ' ').replace('&amp;', '&').strip()
	fanart = fanart.replace('"', ' ').replace('&amp;', '&').strip()
    content = make_request(Drama)
    match = re.compile(Regex).findall(content)
    for name,url,image,fanart in match:
    addDir2(name,url,1,image,fanart)
	
def Familiar():
    name = re.sub('\s+', ' ', name).strip()			
    url = url.replace('"', ' ').replace('&amp;', '&').strip()
	image = image.replace('"', ' ').replace('&amp;', '&').strip()
	fanart = fanart.replace('"', ' ').replace('&amp;', '&').strip()
    content = make_request(Familiar)
    match = re.compile(Regex).findall(content)
    for name,url,image,fanart in match:
    addDir2(name,url,1,image,fanart)
	
def Fantasia():
    name = re.sub('\s+', ' ', name).strip()			
    url = url.replace('"', ' ').replace('&amp;', '&').strip()
	image = image.replace('"', ' ').replace('&amp;', '&').strip()
	fanart = fanart.replace('"', ' ').replace('&amp;', '&').strip()
    content = make_request(Fantasia)
    match = re.compile(Regex).findall(content)
    for name,url,image,fanart in match:
    addDir2(name,url,1,image,fanart)
	
def Belico():
    name = re.sub('\s+', ' ', name).strip()			
    url = url.replace('"', ' ').replace('&amp;', '&').strip()
	image = image.replace('"', ' ').replace('&amp;', '&').strip()
	fanart = fanart.replace('"', ' ').replace('&amp;', '&').strip()
    content = make_request(Belico)
    match = re.compile(Regex).findall(content)
    for name,url,image,fanart in match:
    addDir2(name,url,1,image,fanart)
	
def Suspense():
    name = re.sub('\s+', ' ', name).strip()			
    url = url.replace('"', ' ').replace('&amp;', '&').strip()
	image = image.replace('"', ' ').replace('&amp;', '&').strip()
	fanart = fanart.replace('"', ' ').replace('&amp;', '&').strip()
    content = make_request(Suspense)
    match = re.compile(Regex).findall(content)
    for name,url,image,fanart in match:
    addDir2(name,url,1,image,fanart)
	
def Thriller():
    name = re.sub('\s+', ' ', name).strip()			
    url = url.replace('"', ' ').replace('&amp;', '&').strip()
	image = image.replace('"', ' ').replace('&amp;', '&').strip()
	fanart = fanart.replace('"', ' ').replace('&amp;', '&').strip()
    content = make_request(Novedades)
    match = re.compile(Regex).findall(content)
    for name,url,image,fanart in match:
    addDir2(name,url,1,image,fanart)
	
def Musical():
    name = re.sub('\s+', ' ', name).strip()			
    url = url.replace('"', ' ').replace('&amp;', '&').strip()
	image = image.replace('"', ' ').replace('&amp;', '&').strip()
	fanart = fanart.replace('"', ' ').replace('&amp;', '&').strip()
    content = make_request(Musical)
    match = re.compile(Regex).findall(content)
    for name,url,image,fanart in match:
    addDir2(name,url,1,image,fanart)
	
def Terror():
    name = re.sub('\s+', ' ', name).strip()			
    url = url.replace('"', ' ').replace('&amp;', '&').strip()
	image = image.replace('"', ' ').replace('&amp;', '&').strip()
	fanart = fanart.replace('"', ' ').replace('&amp;', '&').strip()
    content = make_request(Terror)
    match = re.compile(Regex).findall(content)
    for name,url,image,fanart in match:
    addDir2(name,url,1,image,fanart)
	
def Romance():
    name = re.sub('\s+', ' ', name).strip()			
    url = url.replace('"', ' ').replace('&amp;', '&').strip()
	image = image.replace('"', ' ').replace('&amp;', '&').strip()
	fanart = fanart.replace('"', ' ').replace('&amp;', '&').strip()
    content = make_request(Romance)
    match = re.compile(Regex).findall(content)
    for name,url,image,fanart in match:
    addDir2(name,url,1,image,fanart)
	
def Western():
    name = re.sub('\s+', ' ', name).strip()			
    url = url.replace('"', ' ').replace('&amp;', '&').strip()
	image = image.replace('"', ' ').replace('&amp;', '&').strip()
	fanart = fanart.replace('"', ' ').replace('&amp;', '&').strip()
    content = make_request(Western)
    match = re.compile(Regex).findall(content)
    for name,url,image,fanart in match:
    addDir2(name,url,1,image,fanart)
	
def Estrenos():
    name = re.sub('\s+', ' ', name).strip()			
    url = url.replace('"', ' ').replace('&amp;', '&').strip()
	image = image.replace('"', ' ').replace('&amp;', '&').strip()
	fanart = fanart.replace('"', ' ').replace('&amp;', '&').strip()
    content = make_request(Estrenos)
    match = re.compile(Regex).findall(content)
    for name,url,image,fanart in match:
    addDir2(name,url,1,image,fanart)
	

