# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 1.1.6
#
############################################
# Dependencias 
# Script ExtendedInfo
# Script Urlresolver de TVAddons
# Script ResolveURL Por Jsergio.
#
############################################
#
# Agregar sinopsis a Peliculas y series.
# Supresion de Licencia
# Novedades en episodios agregados en series.
# mejorados los buscadore
# resolve uptobox.
#
############################################
if 64 - 64: i11iIiiIii
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import urlresolver
import cookielib , base64
import requests
import plugintools
import config
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
IiII1IiiIiI1 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
o0OoOoOO00 = int ( sys . argv [ 1 ] )
I11i = 'gruponetai/'
O0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
Oo = O0O . getAddonInfo ( 'profile' )
I1ii11iIi11i = O0O . getAddonInfo ( 'path' )
I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
if 73 - 73: OOooOOo / ii11ii1ii
if 94 - 94: OoOO + OoOO0ooOOoo0O + o0000oOoOoO0o * o00O0oo
if I1IiI == 'true' :
 if 97 - 97: oO0o0ooO0 - IIII / O0oO - o0oO0
 oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.png' ) )
 o00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 Oo0oO0ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.png' ) )
 i1111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.png' ) )
 i11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'estrenos.png' ) )
 I11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.png' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.png' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.png' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.png' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.png' ) )
 oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.png' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.png' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.png' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.png' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.png' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.png' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.png' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'marvel.png' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.png' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.png' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.png' ) )
 II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.png' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.png' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.png' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.png' ) )
 OO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.png' ) )
 Ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.png' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.png' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.png' ) )
 O0OO00o0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.jpg' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.jpg' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_series.png' ) )
 OOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_Episodios.png' ) )
 if 87 - 87: O0ooOooooO / i1I111II1I - Oooo0Ooo000 - iI - II111iiii / O0
else :
 if 97 - 97: iI - IIII * i11iIiiIii / OoOO0ooOOoo0O % Oooo0Ooo000 - OoooooooOO
 if 59 - 59: O0 + OOooOOo + i1I111II1I % OOooOOo
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
 oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.jpg' ) )
 o00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 Oo0oO0ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.jpg' ) )
 i1111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.jpg' ) )
 i11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'encines.jpg' ) )
 I11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.jpg' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.jpg' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.jpg' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.jpg' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.jpg' ) )
 oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.jpg' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.jpg' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.jpg' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.jpg' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.jpg' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.jpg' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.jpg' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'superheroes.jpg' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.jpg' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.jpg' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.jpg' ) )
 II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.jpg' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.jpg' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.jpg' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.jpg' ) )
 OO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.jpg' ) )
 Ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.jpg' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.jpg' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.jpg' ) )
 O0OO00o0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.jpg' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.jpg' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.jpg' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favoritos.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_series.png' ) )
 OOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_Episodios.png' ) )
 if 70 - 70: O0ooOooooO * o00O0oo
 if 46 - 46: iI / OoOO
 if 52 - 52: o0000oOoOoO0o - OoooooooOO + o0oO0 + o0oO0 - o0000oOoOoO0o / Oooo0Ooo000
I1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'peliculas.png' ) )
iIi11Ii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series.png' ) )
Ii11iII1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ajustes.png' ) )
Oo0O0O0ooO0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'videoteca.png' ) )
IIIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
O0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'resolver.png' ) )
OO00Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'test.png' ) )
O0OOO0OOoO0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'video-tutoriales.png' ) )
O00Oo000ooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'proxy.png' ) )
if 100 - 100: O0 + i1I111II1I - IIII + i11iIiiIii * o0oO0
if 30 - 30: o0000oOoOoO0o . o0oO0 - OoooooooOO
if 8 - 8: i1IIi - iIii1I11I1II1 * II111iiii + i11iIiiIii / Oooo0Ooo000 % IIII
iIIIi1 = IiII1IiiIiI1 . getSetting ( 'mostrar_cat' )
iiII1i1 = IiII1IiiIiI1 . getSetting ( 'sel_tobox' )
o00oOO0o = IiII1IiiIiI1 . getSetting ( 'videos' )
OOO00O = IiII1IiiIiI1 . getSetting ( 'activar' )
OOoOO0oo0ooO = IiII1IiiIiI1 . getSetting ( 'favcopy' )
O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'anticopia' )
O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
i1i = IiII1IiiIiI1 . getSetting ( 'mostrar_bus' )
iiI111I1iIiI = IiII1IiiIiI1 . getSetting ( 'restante' )
IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'selecton' )
O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'aviso' )
oooooOoo0ooo = IiII1IiiIiI1 . getSetting ( 'RealStream_Settings' )
I1I1IiI1 = IiII1IiiIiI1 . getSetting ( 'Resolver_Settings' )
iiI111I1iIiI = IiII1IiiIiI1 . getSetting ( 'restante' )
III1iII1I1ii = IiII1IiiIiI1 . getSetting ( 'fav' )
oOOo0 = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
oo00O00oO = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
iIiIIIi = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
ooo00OOOooO = 'bienvenida'
O00OOOoOoo0O = 'bienvenida'
copyright = IiII1IiiIiI1 . getSetting ( 'copyright' )
O000OOo00oo = 'cGx1Z2luLnZpZGVvLg==' . decode ( 'base64' ) + copyright
oo0OOo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
ooOOO00Ooo = IiII1IiiIiI1 . getSetting ( 'Forceupdate' )
if ooOOO00Ooo == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
IiIIIi1iIi = 'LnR4dA==' . decode ( 'base64' )
if 68 - 68: i11iIiiIii % o00O0oo + i11iIiiIii
if 31 - 31: II111iiii . OOooOOo
if 1 - 1: ii11ii1ii / o0000oOoOoO0o % O0ooOooooO * i1I111II1I . i11iIiiIii
III1Iiii1I11 = 'aHR0cDovL2JpdC5seS8yU1FOSnlP' . decode ( 'base64' )
IIIIiiIiI = iIiIIIi + ooo00OOOooO + IiIIIi1iIi
o00oooO0Oo = 'http://www.youtube.com'
o0O0OOO0Ooo = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
iiIiI = 'http://bit.ly/2ImelUx'
I1 = '.xsl.pt'
OOO00O0O = 'L21hc3Rlci8=' . decode ( 'base64' )
iii = o0O0OOO0Ooo + I1
oOooOOOoOo = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*'
i1Iii1i1I = 'tvg-logo=[\'"](.*?)[\'"]'
if 91 - 91: o00O0oo + OOooOOo . IIII * o00O0oo + OOooOOo * ii11ii1ii
O000OOOOOo = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.*)'
Iiii1i1 = '(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)'
OO = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
oo000o = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
iiIi1IIi1I = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
o0OoOO000ooO0 = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
o0o0o0oO0oOO = '#(.+?),(.+)\s*(.+)'
ii1Ii11I = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
if 80 - 80: II111iiii
O0Oi1I1I = 'source src=[\'"](.*?)[\'"]\s*title=[\'"](.*?)[\'"]'
iiI1I = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
IiIiiIIiI = '[\'"](.*?)[\'"]'
ooOO0OOOO0oo0 = r'066">\s*(.+)</f'
I11iiI1i1 = '[\'"](.*?)[\'"]'
I1i1Iiiii = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
if 94 - 94: o0000oOoOoO0o * o0oO0 / ii11ii1ii / o0oO0
oO0 = 'src":"(.*?)"label":"(.*?)"lang":"(.*?)"'
if 75 - 75: iI + OoOO0ooOOoo0O + o0000oOoOoO0o * O0oO % oO0o0ooO0 . O0ooOooooO
oOI1Ii1I1 = '[\'"](.*?)[\'"]'
IiII111iI1ii1 = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( 'base64' )
iI11I1II = IiII111iI1ii1 + I11i
Ii1I = '[\'"](.*?)[\'"]'
IiI1i = 'UmVhbHN0cmVhbQ==' . decode ( 'base64' )
o0O = 'video=[\'"](.*?)[\'"]'
o00iI = '0110nhu' . replace ( '0110nhu' , 'nhu' )
O0O0Oooo0o = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( 'base64' ) + o00iI
oOOoo00O00o = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
O0O00Oo = '0110R0N' . replace ( '0110R0N' , 'R0N' )
oooooo0O000o = 'aHR0cDovL2JpdC5seS8yWEIx' . decode ( 'base64' ) + O0O00Oo
OoO = '0110pEJ' . replace ( '0110pEJ' , 'pEJ' )
ooO0O0O0ooOOO = 'aHR0cDovL2JpdC5seS8yd1Nh' . decode ( 'base64' ) + OoO
oOOo0O00o = 'ABBAOb5' . replace ( 'ABBAOb5' , 'Ob5' )
iIiIi11 = 'aHR0cDovL2JpdC5seS8yRVhV' . decode ( 'base64' ) + oOOo0O00o
OOO = '0110jaw' . replace ( '0110jaw' , 'jaw' )
iiiiI = 'aHR0cDovL2JpdC5seS8yd01M' . decode ( 'base64' ) + OOO
oooOo0OOOoo0 = '01109DI' . replace ( '01109DI' , '9DI' )
OOoO = 'aHR0cDovL2JpdC5seS8ySXgz' . decode ( 'base64' ) + oooOo0OOOoo0
OO0O000 = '01103hs' . replace ( '01103hs' , '3hs' )
iiIiI1i1 = 'aHR0cDovL2JpdC5seS8zMW1U' . decode ( 'base64' ) + OO0O000
oO0O00oOOoooO = '01107DW' . replace ( '01107DW' , '7DW' )
IiIi11iI = 'aHR0cDovL2JpdC5seS8yV1ln' . decode ( 'base64' ) + oO0O00oOOoooO
Oo0O00O000 = '0110mLl' . replace ( '0110mLl' , 'mLl' )
i11I1IiII1i1i = 'aHR0cDovL2JpdC5seS8yS0cw' . decode ( 'base64' ) + Oo0O00O000
oo = '01102Hj' . replace ( '01102Hj' , '2Hj' )
I1111i = 'aHR0cDovL2JpdC5seS8yWEJo' . decode ( 'base64' ) + oo
iIIii = '0110fXg' . replace ( '0110fXg' , 'fXg' )
o00O0O = 'aHR0cDovL2JpdC5seS8ySTVy' . decode ( 'base64' ) + iIIii
ii1iii1i = '0110NMH' . replace ( '0110NMH' , 'NMH' )
Iii1I1111ii = 'aHR0cDovL2JpdC5seS8yd0t6' . decode ( 'base64' ) + ii1iii1i
ooOoO00 = '0110bwQ' . replace ( '0110bwQ' , 'bwQ' )
Ii1IIiI1i = 'aHR0cDovL2JpdC5seS8yd01V' . decode ( 'base64' ) + ooOoO00
o0O00Oo0 = '0110xzG' . replace ( '0110xzG' , 'xzG' )
IiII111i1i11 = 'aHR0cDovL2JpdC5seS8yWHhz' . decode ( 'base64' ) + o0O00Oo0
i111iIi1i1II1 = '0110x64' . replace ( '0110x64' , 'x64' )
oooO = 'aHR0cDovL2JpdC5seS8yRVlF' . decode ( 'base64' ) + i111iIi1i1II1
i1I1i111Ii = '0110vUE' . replace ( '0110vUE' , 'vUE' )
ooo = 'aHR0cDovL2JpdC5seS8yWmhW' . decode ( 'base64' ) + i1I1i111Ii
i1i1iI1iiiI = '01107ZL' . replace ( '01107ZL' , '7ZL' )
Ooo0oOooo0 = 'aHR0cDovL2JpdC5seS8yWm4w' . decode ( 'base64' ) + i1i1iI1iiiI
oOOOoo00 = '01106cf' . replace ( '01106cf' , '6cf' )
iiIiIIIiiI = 'aHR0cDovL2JpdC5seS8yRVlk' . decode ( 'base64' ) + oOOOoo00
iiI1IIIi = '0110Jtp' . replace ( '0110Jtp' , 'Jtp' )
II11IiIi11 = 'aHR0cDovL2JpdC5seS8yV3Nq' . decode ( 'base64' ) + iiI1IIIi
IIOOO0O00O0OOOO = '0110a5b' . replace ( '0110a5b' , 'a5b' )
I1iiii1I = 'aHR0cDovL2JpdC5seS8yV3dj' . decode ( 'base64' ) + IIOOO0O00O0OOOO
OOo0 = '0110Q7u' . replace ( '0110Q7u' , 'Q7u' )
oO00ooooO0o = 'aHR0cDovL2JpdC5seS8yV3NL' . decode ( 'base64' ) + OOo0
oo0o = '0110rsq' . replace ( '0110rsq' , 'rsq' )
o0oO0oooOoo = 'aHR0cDovL2JpdC5seS8ySzhE' . decode ( 'base64' ) + oo0o
I1III1111iIi = '0110DDR' . replace ( '0110DDR' , 'DDR' )
I1i111I = 'aHR0cDovL2JpdC5seS8ySzd5' . decode ( 'base64' ) + I1III1111iIi
OooOo0oo0O0o00O = '0110feQ' . replace ( '0110feQ' , 'feQ' )
I1i11 = 'aHR0cDovL2JpdC5seS8yS0cz' . decode ( 'base64' ) + OooOo0oo0O0o00O
IiIi1I1 = '0110MHY' . replace ( '0110MHY' , 'MHY' )
IiIIi1 = 'aHR0cDovL2JpdC5seS8ySXVo' . decode ( 'base64' ) + IiIi1I1
IIIIiii1IIii = '0110xdb' . replace ( '0110xdb' , 'xdb' )
II1i11I = 'aHR0cDovL2JpdC5seS8yWEJu' . decode ( 'base64' ) + IIIIiii1IIii
ii1I1IIii11 = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( 'base64' )
O0o0oO = 'aHR0cHM6Ly9uZXRhaS5ldS92aXNpdGFzL2luZGV4LnBocA==' . decode ( 'base64' )
O000OOo00oo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
IIIIiIiIi1 = '0110lxu' . replace ( '0110lxu' , 'lxu' )
I11iiiiI1i = 'aHR0cDovL2JpdC5seS8yV1Bj' . decode ( 'base64' ) + IIIIiIiIi1
iI1i11 = '0110pzp' . replace ( '0110pzp' , 'pzp' )
OoOOoooOO0O = 'aHR0cDovL2JpdC5seS8yVHpB' . decode ( 'base64' ) + iI1i11
ooo00Ooo = '01105yt' . replace ( '01105yt' , '5yt' )
Oo0o0O00 = 'aHR0cDovL2JpdC5seS8yTVpp' . decode ( 'base64' ) + ooo00Ooo
if 40 - 40: OoooooooOO
if 25 - 25: i1I111II1I + o0oO0 / iI . o0000oOoOoO0o % O0 * OoOO
o0O0oo0OO0O = '1001DTs' . replace ( '1001DTs' , 'DTs' )
OO0 = 'aHR0cDovL2JpdC5seS8ySzhP' . decode ( 'base64' ) + o0O0oo0OO0O
o0Oooo = '1001Hky' . replace ( '1001Hky' , 'Hky' )
iiI = 'aHR0cDovL2JpdC5seS8yTGVL' . decode ( 'base64' ) + o0Oooo
oOIIiIi = '1001VFU' . replace ( '1001VFU' , 'VFU' )
OOoOooOoOOOoo = 'aHR0cDovL2JpdC5seS8zMERx' . decode ( 'base64' ) + oOIIiIi
Iiii1iI1i = '3545OMZ' . replace ( '3545OMZ' , 'OMZ' )
I1ii1ii11i1I = 'aHR0cDovL2JpdC5seS8yazhk' . decode ( 'base64' ) + Iiii1iI1i
o0OoOO = '4224tZO' . replace ( '4224tZO' , 'tZO' )
O0O0Oo00 = 'aHR0cDovL2JpdC5seS8zNXd4' . decode ( 'base64' ) + o0OoOO
if 80 - 80: oO0o0ooO0 + IIII / O0oO
def oOOO00O0O0OOo ( ) :
 if 77 - 77: oO0o0ooO0 + iI . ii11ii1ii % o0oO0
 if 97 - 97: II111iiii . o0000oOoOoO0o - o00O0oo
 try :
  o0OOOo = ii1iiIiIII1ii ( oooooo0O000o )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   try :
    if 21 - 21: O0 % i1I111II1I . OOooOOo / II111iiii + i1I111II1I
    ooO0O0O0ooOOO = IiIiII1
    if 53 - 53: oO0o0ooO0 - OOooOOo - oO0o0ooO0 * O0ooOooooO
    oooooo0OO = xbmc . Keyboard ( '' , 'Busqueda por titulo' )
    oooooo0OO . doModal ( )
    if ( oooooo0OO . isConfirmed ( ) ) :
     iI1I = xbmcgui . DialogProgress ( )
     iI1I . create ( 'Realstream:' , 'Buscando ...' )
     OooOoOo = range ( 0 , 76 )
     for III1I1Iii1iiI in OooOoOo :
      III1I1Iii1iiI = III1I1Iii1iiI + 1
      if 17 - 17: o0oO0 % iIii1I11I1II1 - iIii1I11I1II1
     O0o0O0 = urllib . quote_plus ( oooooo0OO . getText ( ) ) . replace ( '+' , ' ' )
     Ii1II1I11i1 = ii1iiIiIII1ii ( ooO0O0O0ooOOO )
     oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( Ii1II1I11i1 )
     for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
      if 1 - 1: O0oO % IIII + O0 + i1IIi - OoOO
      iI1I . update ( III1I1Iii1iiI , '[COLOR orange]Realstream: Buscando ...[/COLOR]' , ' [COLOR yellow] %s [/COLOR]' % Ii111 )
      xbmc . sleep ( 1 )
      if iI1I . iscanceled ( ) : break ;
      if re . search ( O0o0O0 , iIIIII1ii1I ( Ii111 . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       if 13 - 13: i11iIiiIii + i1IIi * iIii1I11I1II1 % OoooooooOO - II111iiii * IIII
       iI1I . update ( 80 , ' [COLOR orange]Busqueda finalizada[/COLOR] ' )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR gold]Generando listado ...  [/COLOR][COLOR orange] Por favor espere ![/COLOR] ,1000)" )
       iI1I . update ( 100 , '[COLOR orange]Realstream: [/COLOR]' , '[COLOR gold] Busqueda finalizada ...[/COLOR]' )
       iI1I . close ( )
       iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
       if 68 - 68: IIII
       if 82 - 82: iIii1I11I1II1 + ii11ii1ii . iIii1I11I1II1 % i1I111II1I / o0oO0 . o0oO0
     IIi ( '[COLOR %s]Buscar Pelicula[/COLOR]' % oo00O00oO , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Resultados para: [COLOR orange]" + O0o0O0 + "[/COLOR] ,2000)" )
     if 66 - 66: oO0o0ooO0 % OoOO . IIII
   except : IIi ( '[COLOR %s]Buscar Pelicula[/COLOR]' % oo00O00oO , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
   if 86 - 86: iIii1I11I1II1
 except :
  pass
  if 76 - 76: iI + iIii1I11I1II1 / O0 / o00O0oo
  if 61 - 61: IIII % IIII * o0000oOoOoO0o / o0000oOoOoO0o
  if 75 - 75: i1I111II1I . iI
  if 50 - 50: OoOO0ooOOoo0O
def O00o0OO0000oo ( ) :
 if 27 - 27: O0
 try :
  if 79 - 79: o0000oOoOoO0o - O0oO + o0000oOoOoO0o . oO0o0ooO0
  O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'aviso' )
  if 28 - 28: i1IIi - O0ooOooooO
  if O0ii1ii1ii == 'true' :
   o0OOOo = ii1iiIiIII1ii ( IIIIiiIiI )
   oO0o0oooO0oO = re . compile ( oOooOOOoOo ) . findall ( o0OOOo )
   for o00o000oo , ii11i11i1 in oO0o0oooO0oO :
    try :
     if 53 - 53: OoooooooOO % o0oO0 . i1I111II1I / i11iIiiIii % O0ooOooooO
     if 28 - 28: O0oO
     oOOOOoo = o00o000oo
     OOo0ii11I1 = ii11i11i1
     if 75 - 75: OoOO / II111iiii % O0
     if 38 - 38: OoooooooOO * iI % O0 * OoOO0ooOOoo0O
     from datetime import datetime
     if 29 - 29: o00O0oo / i1IIi . OOooOOo - OoOO0ooOOoo0O - OoOO0ooOOoo0O - o0oO0
     IiiIiI111iI = datetime . now ( )
     OOo = IiiIiI111iI . strftime ( '%d/%m/%Y' )
     if 50 - 50: iI
     o0O0O0ooo0oOO = ii1iiIiIII1ii ( O0o0oO )
     oO0o0oooO0oO = re . compile ( ooOO0OOOO0oo0 ) . findall ( o0O0O0ooo0oOO )
     for oo000 in oO0o0oooO0oO :
      if 32 - 32: i1IIi . o0oO0
      oOO = "[B]" + oOOOOoo + "[/B]"
      Oooo = "" + OOo0ii11I1 + ""
      I1i1iiiII1i = "[COLOR white]Hoy: " + OOo + ", Es usted el visitante numero: [B][COLOR gold]" + oo000 + "[/B][/COLOR]"
      if 100 - 100: OoOO
     xbmcgui . Dialog ( ) . ok ( "Real Stream" , oOO , Oooo , I1i1iiiII1i )
     if 46 - 46: OoOO0ooOOoo0O / iIii1I11I1II1 % O0ooOooooO . iIii1I11I1II1 * O0ooOooooO
    except :
     pass
     if 38 - 38: o00O0oo - O0ooOooooO / O0 . Oooo0Ooo000
     if 45 - 45: Oooo0Ooo000
     if 83 - 83: OoOO0ooOOoo0O . OoooooooOO
     if 58 - 58: i11iIiiIii + OoooooooOO % OoooooooOO / i1I111II1I / i11iIiiIii
   Ii1II1I11i1 = ii1iiIiIII1ii ( ii1I1IIii11 )
   oO0o0oooO0oO = re . compile ( IiIiiIIiI ) . findall ( Ii1II1I11i1 )
   for oOOoo in oO0o0oooO0oO :
    try :
     if 14 - 14: o0000oOoOoO0o * oO0o0ooO0
     import xbmc
     import xbmcaddon
     if 81 - 81: o0oO0 * o0000oOoOoO0o + Oooo0Ooo000 + ii11ii1ii - OoooooooOO
     __addon__ = xbmcaddon . Addon ( )
     __addonname__ = __addon__ . getAddonInfo ( 'name' )
     __icon__ = __addon__ . getAddonInfo ( 'icon' )
     if 32 - 32: o0oO0 * O0
     iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
     O00oOo00o0o = oOOoo
     if 85 - 85: O0ooOooooO + OoooooooOO * O0ooOooooO - Oooo0Ooo000 % i11iIiiIii
     oOO = "[COLOR orange]Version instalada: [COLOR gold][B] " + iIiiiI1IiI1I1 + "[/B] [/COLOR][/COLOR][COLOR white] Disponible: [B]" + oOOoo + " [/B][/COLOR]"
     OOo00OoO = 4000
     if 10 - 10: o0000oOoOoO0o / i11iIiiIii
     xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , oOO , OOo00OoO , __icon__ ) )
     if 92 - 92: O0oO . Oooo0Ooo000
    except :
     pass
     if 85 - 85: o00O0oo . Oooo0Ooo000
   if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 78 - 78: iI * Oooo0Ooo000 + iIii1I11I1II1 + iIii1I11I1II1 / Oooo0Ooo000 . o0oO0
    if 97 - 97: iI / Oooo0Ooo000 % i1IIi % o00O0oo
 except :
  pass
  if 18 - 18: iIii1I11I1II1 % O0oO
  if 95 - 95: iI + i11iIiiIii * Oooo0Ooo000 - i1IIi * Oooo0Ooo000 - iIii1I11I1II1
def iIIIII1ii1I ( s ) :
 if 75 - 75: OoooooooOO * i1I111II1I
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 9 - 9: i1I111II1I - II111iiii + O0 / iIii1I11I1II1 / i11iIiiIii
def I1IIIiI1I1ii1 ( file ) :
 if 30 - 30: O0 * OoooooooOO
 try :
  I1iIIIi1 = open ( file , 'r' )
  o0OOOo = I1iIIIi1 . read ( )
  I1iIIIi1 . close ( )
  return o0OOOo
 except :
  pass
  if 17 - 17: iIii1I11I1II1 . OoooooooOO / O0oO % II111iiii % i1IIi / i11iIiiIii
def ii1iiIiIII1ii ( url ) :
 if 58 - 58: ii11ii1ii . II111iiii + oO0o0ooO0 - i11iIiiIii / II111iiii / O0
 try :
  oOOoOo = urllib2 . Request ( url )
  oOOoOo . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  ooOooo0 = urllib2 . urlopen ( oOOoOo )
  oO0OO0 = ooOooo0 . read ( )
  ooOooo0 . close ( )
  return oO0OO0
 except urllib2 . URLError , o0O0Oo00 :
  print 'We failed to open "%s".' % url
  if hasattr ( o0O0Oo00 , 'code' ) :
   print 'We failed with error code - %s.' % o0O0Oo00 . code
  if hasattr ( o0O0Oo00 , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , o0O0Oo00 . reason
   if 51 - 51: IIII % iIii1I11I1II1 - OoooooooOO % iI * iIii1I11I1II1 % OoOO
def oO0o00oOOooO0 ( url ) :
 oOOoOo = urllib2 . Request ( url )
 oOOoOo . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 oOOoOo . add_header ( 'Referer' , '%s' % url )
 oOOoOo . add_header ( 'Connection' , 'keep-alive' )
 ooOooo0 = urllib2 . urlopen ( oOOoOo )
 oO0OO0 = ooOooo0 . read ( )
 ooOooo0 . close ( )
 return oO0OO0
 if 79 - 79: OoOO - iIii1I11I1II1 + o0oO0 - Oooo0Ooo000
 if 93 - 93: II111iiii . OOooOOo - ii11ii1ii + OoOO0ooOOoo0O
def ooO0o ( ) :
 if 89 - 89: O0oO / Oooo0Ooo000
 oo00O00oO = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 if 90 - 90: O0ooOooooO
 if OOO00O == 'true' :
  if 31 - 31: IIII + O0
  IIi ( '[COLOR %s]Buscar Pelicula[/COLOR]' % oo00O00oO , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
  IIi ( '[COLOR %s]Buscar Serie[/COLOR]' % oo00O00oO , 'search' , 145 , I1IIIii , oo00 )
  IIi ( '[COLOR %s]Peliculas[/COLOR] ' % oo00O00oO , 'movieDB' , 116 , I1I , oo00 )
  IIi ( '[COLOR %s]Series[/COLOR] ' % oo00O00oO , 'movieDB' , 117 , iIi11Ii1 , oo00 )
  if 87 - 87: iI
  if 45 - 45: OoOO / OoooooooOO - O0ooOooooO / o0oO0 % i1I111II1I
 if oooooOoo0ooo == 'true' :
  IIi ( '[COLOR %s]Ajustes[/COLOR]' % oo00O00oO , 'Settings' , 119 , Ii11iII1 , oo00 )
  if 83 - 83: OOooOOo . iIii1I11I1II1 - i1I111II1I * i11iIiiIii
  if 20 - 20: i1IIi * Oooo0Ooo000 + II111iiii % o0000oOoOoO0o % oO0o0ooO0
  if iIIIi1 == 'true' :
   iIi1II ( )
   if 17 - 17: IIII % ii11ii1ii / o00O0oo . i1I111II1I * IIII - II111iiii
  if I1I1IiI1 == 'true' :
   i1i1IIii1i1 ( )
   oOoO00 ( )
   if 40 - 40: o0000oOoOoO0o
  if O0o0O00Oo0o0 == 'false' :
   if 67 - 67: oO0o0ooO0 + II111iiii - O0 . oO0o0ooO0 * II111iiii * O0oO
   oOO = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   Oooo = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Script.ResolveURL para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   I1i1iiiII1i = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 90 - 90: o0oO0 . i1I111II1I
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , oOO , Oooo , I1i1iiiII1i )
   if 81 - 81: IIII - O0oO % iI - OoOO / ii11ii1ii
def Ii1iI111 ( ) :
 IIi ( '[COLOR orange]Buscador por id[/COLOR]' , o00oooO0Oo , 127 , oOOoo00O0O , oo00 )
 if 51 - 51: i1I111II1I * O0 / II111iiii . o0oO0 % IIII / OOooOOo
def ii1iii1I1I ( ) :
 oo00O00oO = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 IIi ( '[COLOR %s]The movie DB[/COLOR]' % oo00O00oO , 'movieDB' , 99 , oOOoo00O0O , oo00 )
 if 95 - 95: i1I111II1I
 IIi ( '[COLOR %s]Video tutoriales[/COLOR]' % oo00O00oO , o00oooO0Oo , 125 , O0OOO0OOoO0O , oo00 )
 if 51 - 51: II111iiii + i1I111II1I . i1IIi . o00O0oo + OoOO0ooOOoo0O * OOooOOo
 if 72 - 72: oO0o0ooO0 + oO0o0ooO0 / II111iiii . OoooooooOO % o0oO0
 if 49 - 49: oO0o0ooO0 . OoOO - ii11ii1ii * OoooooooOO . ii11ii1ii
def ii1Ii1IiIIi ( ) :
 if 83 - 83: O0oO / o00O0oo
 ooO0o ( )
 ii1iii1I1I ( )
 if 34 - 34: OOooOOo * ii11ii1ii * Oooo0Ooo000 / OoOO * O0oO / iIii1I11I1II1
def OOOo ( ) :
 if 88 - 88: i11iIiiIii - iI
 ii1Ii1IiIIi ( )
 if 67 - 67: IIII . ii11ii1ii + OoOO0ooOOoo0O - OoooooooOO
def OOOoO ( ) :
 if xbmc . getCondVisibility ( 'System.HasAddon(script.favourites)' ) :
  try :
   xbmc . executebuiltin ( "RunScript(script.favourites)" )
  except :
   pass
def I1i ( ) :
 IiII1IiiIiI1 . openSettings ( )
 if 12 - 12: OoooooooOO
 if 20 - 20: i1IIi - O0oO
def ii1ii11 ( ) :
 urlresolver . display_settings ( )
 if 84 - 84: O0 . O0oO - II111iiii . iI / II111iiii
def i1i1IIii1i1 ( ) :
 IIi ( '[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % oo00O00oO , 'resolve' , 120 , O0o0 , oo00 )
 if 47 - 47: OoooooooOO
def ii1i1i1IiII ( ) :
 if 63 - 63: O0ooOooooO . OoOO / II111iiii * i1I111II1I + oO0o0ooO0 % o0oO0
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 12 - 12: Oooo0Ooo000 . OoOO . O0ooOooooO - OoooooooOO % ii11ii1ii
def oOoO00 ( ) :
 IIi ( '[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % oo00O00oO , 'resolve' , 140 , O0o0 , oo00 )
 if 36 - 36: IIII
def iIi1II ( ) :
 if 84 - 84: Oooo0Ooo000 . OoOO . II111iiii . O0oO / o0oO0 % o00O0oo
 oo00O00oO = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 IIi ( '[COLOR %s]Buscador[/COLOR]' % oo00O00oO , 'search' , 111 , o0oOoO00o , oo00 )
 IIi ( '[COLOR %s]Estrenos[/COLOR]' % oo00O00oO , o00oooO0Oo , 3 , i11 , oo00 )
 IIi ( '[COLOR %s]Todas[/COLOR]' % oo00O00oO , o00oooO0Oo , 26 , I11 , oo00 )
 IIi ( '[COLOR %s]4K[/COLOR]' % oo00O00oO , o00oooO0Oo , 141 , O0o0Oo , oo00 )
 IIi ( '[COLOR %s]Novedades[/COLOR]' % oo00O00oO , o00oooO0Oo , 2 , i1111 , oo00 )
 IIi ( '[COLOR %s]Accion[/COLOR]' % oo00O00oO , o00oooO0Oo , 5 , Oo0o0000o0o0 , oo00 )
 IIi ( '[COLOR %s]Animacion[/COLOR]' % oo00O00oO , o00oooO0Oo , 6 , oOo0oooo00o , oo00 )
 IIi ( '[COLOR %s]Artes Marciales[/COLOR]' % oo00O00oO , o00oooO0Oo , 29 , o0 , oo00 )
 IIi ( '[COLOR %s]Aventuras[/COLOR]' % oo00O00oO , o00oooO0Oo , 7 , oO0o0o0ooO0oO , oo00 )
 IIi ( '[COLOR %s]Belico[/COLOR]' % oo00O00oO , o00oooO0Oo , 8 , oo0o0O00 , oo00 )
 IIi ( '[COLOR %s]Ciencia Ficcion[/COLOR]' % oo00O00oO , o00oooO0Oo , 9 , oO , oo00 )
 IIi ( '[COLOR %s]Cine Clasico[/COLOR]' % oo00O00oO , o00oooO0Oo , 30 , i1iiIIiiI111 , oo00 )
 IIi ( '[COLOR %s]Comedia[/COLOR]' % oo00O00oO , o00oooO0Oo , 10 , oooOOOOO , oo00 )
 IIi ( '[COLOR %s]Crimen[/COLOR]' % oo00O00oO , o00oooO0Oo , 11 , i1iiIII111ii , oo00 )
 IIi ( '[COLOR %s]Drama[/COLOR]' % oo00O00oO , o00oooO0Oo , 12 , i1iIIi1 , oo00 )
 IIi ( '[COLOR %s]Familiar[/COLOR]' % oo00O00oO , o00oooO0Oo , 13 , ii11iIi1I , oo00 )
 IIi ( '[COLOR %s]Fantasia[/COLOR]' % oo00O00oO , o00oooO0Oo , 14 , iI111I11I1I1 , oo00 )
 IIi ( '[COLOR %s]Historia[/COLOR]' % oo00O00oO , o00oooO0Oo , 15 , OOooO0OOoo , oo00 )
 IIi ( '[COLOR %s]Misterio[/COLOR]' % oo00O00oO , o00oooO0Oo , 16 , oOOoO0 , oo00 )
 IIi ( '[COLOR %s]Musical[/COLOR]' % oo00O00oO , o00oooO0Oo , 17 , O0OoO000O0OO , oo00 )
 IIi ( '[COLOR %s]Romance[/COLOR]' % oo00O00oO , o00oooO0Oo , 18 , iiI1IiI , oo00 )
 IIi ( '[COLOR %s]Thriller[/COLOR]' % oo00O00oO , o00oooO0Oo , 19 , II11iiii1Ii , oo00 )
 IIi ( '[COLOR %s]Suspense[/COLOR]' % oo00O00oO , o00oooO0Oo , 20 , ooOoOoo0O , oo00 )
 IIi ( '[COLOR %s]Terror[/COLOR]' % oo00O00oO , o00oooO0Oo , 21 , OooO0 , oo00 )
 IIi ( '[COLOR %s]Western[/COLOR]' % oo00O00oO , o00oooO0Oo , 22 , OO0o , oo00 )
 IIi ( '[COLOR %s]Spain[/COLOR]' % oo00O00oO , o00oooO0Oo , 23 , II , oo00 )
 IIi ( '[COLOR %s]Super heroes[/COLOR]' % oo00O00oO , o00oooO0Oo , 24 , iIii1 , oo00 )
 IIi ( '[COLOR %s]Sagas[/COLOR]' % oo00O00oO , o00oooO0Oo , 25 , Ooo , oo00 )
 if 57 - 57: OOooOOo % O0oO - IIII . OOooOOo / ii11ii1ii % O0ooOooooO
def OOI1iIi1iiIIiI ( ) :
 if 81 - 81: OoOO * OoOO0ooOOoo0O . IIII
 IIi ( '[COLOR %s]Buscar Serie[/COLOR]' % oo00O00oO , 'search' , 145 , O0OO00o0OO , oo00 )
 if 11 - 11: i11iIiiIii - oO0o0ooO0 . oO0o0ooO0
 I11I ( )
 if 6 - 6: o00O0oo + oO0o0ooO0
 IIi ( '[COLOR %s]En emision[/COLOR]' % oo00O00oO , o00oooO0Oo , 150 , I11II1i , oo00 )
 IIi ( '[COLOR %s]Mejor valoradas[/COLOR]' % oo00O00oO , o00oooO0Oo , 151 , IIIII , oo00 )
 IIi ( '[COLOR %s]Series Retro[/COLOR]' % oo00O00oO , o00oooO0Oo , 152 , ooooooO0oo , oo00 )
 IIi ( '[COLOR %s]Todas[/COLOR]' % oo00O00oO , o00oooO0Oo , 142 , I11i1 , oo00 )
 if 48 - 48: iIii1I11I1II1 % i1IIi % O0ooOooooO + iI
def I11I ( ) :
 if 30 - 30: i11iIiiIii % iIii1I11I1II1 . O0oO % iIii1I11I1II1
 oOO00oO00O0OO = 'aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtLw==' . decode ( 'base64' )
 oOo00OO = 'Y29uZGljaW9uLnR4dA==' . decode ( 'base64' )
 oO0OO0 = oOO00oO00O0OO + oOo00OO
 o0oOO0OO = '[\'"](.*?)[\'"]'
 OOI1iIi1iiIIiI = ii1iiIiIII1ii ( oO0OO0 )
 oO0o0oooO0oO = re . compile ( o0oOO0OO ) . findall ( OOI1iIi1iiIIiI )
 for Oo00OoO00o0 in oO0o0oooO0oO :
  try :
   if 87 - 87: oO0o0ooO0 * oO0o0ooO0 / OOooOOo / iI % IIII
   if Oo00OoO00o0 == 'si' :
    if 96 - 96: OOooOOo % ii11ii1ii . o00O0oo + IIII
    IIi ( '[COLOR %s]Hay Nuevos Episodios[/COLOR]' % oo00O00oO , o00oooO0Oo , 155 , OOOO , oo00 )
    if 42 - 42: II111iiii * O0ooOooooO * i11iIiiIii - IIII . OoooooooOO
   elif Oo00OoO00o0 == 'no' :
    if 76 - 76: II111iiii
    IIi ( '[COLOR %s]No hay Nuevos Episodios[/COLOR]' % oo00O00oO , o00oooO0Oo , 155 , oOoOooOo0o0 , oo00 )
    if 26 - 26: II111iiii % i11iIiiIii % iIii1I11I1II1 % O0oO * O0oO * o00O0oo
   return
   if 24 - 24: II111iiii % Oooo0Ooo000 - iI + OOooOOo * o00O0oo
  except :
   pass
   if 2 - 2: o0oO0 - i1I111II1I
def OO0OO00oo0 ( ) :
 if 19 - 19: ii11ii1ii - OoOO
 if 56 - 56: o00O0oo
 try :
  if 26 - 26: OoooooooOO % OoooooooOO
  iIIIII1iiiiII = ii1iiIiIII1ii ( OO0 )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( iIIIII1iiiiII )
  for IiIiII1 in oO0o0oooO0oO :
   if 54 - 54: i1IIi
   try :
    if 22 - 22: i1IIi + o0oO0
    O0o0O0OO00o = IiIiII1
    oooooo0OO = xbmc . Keyboard ( '' , 'Buscar' )
    oooooo0OO . doModal ( )
    if ( oooooo0OO . isConfirmed ( ) ) :
     iI1I = xbmcgui . DialogProgress ( )
     iI1I . create ( 'Realstream:' , 'Buscando ...' )
     OooOoOo = range ( 0 , 69 )
     for III1I1Iii1iiI in OooOoOo :
      III1I1Iii1iiI = III1I1Iii1iiI + 1
     O0o0O0 = urllib . quote_plus ( oooooo0OO . getText ( ) ) . replace ( '+' , ' ' )
     Ii1II1I11i1 = ii1iiIiIII1ii ( O0o0O0OO00o )
     oO0o0oooO0oO = re . compile ( OO ) . findall ( Ii1II1I11i1 )
     for OOo00O , Ii111 , oo00 , I111i1i1111 , I1I1i in oO0o0oooO0oO :
      iI1I . update ( III1I1Iii1iiI , '[COLOR orange]Realstream: Buscando ...[/COLOR]' , '[COLOR gold] %s [/COLOR]' % Ii111 )
      xbmc . sleep ( 5 )
      if iI1I . iscanceled ( ) : break ;
      if re . search ( O0o0O0 , iIIIII1ii1I ( Ii111 . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       if 81 - 81: i1I111II1I . o0000oOoOoO0o / Oooo0Ooo000
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Generando listado ...  [COLOR orange] Por favor espere ![/COLOR] , 4000)" )
       Iii111Ii ( Ii111 , I111i1i1111 , 143 , OOo00O , oo00 , I1I1i )
       iI1I . update ( 100 , '[COLOR orange]Realstream: [/COLOR]' , '[COLOR gold] Busqueda finalizada ...[/COLOR]' )
       xbmc . sleep ( 2000 )
       iI1I . close ( )
     IIi ( '[COLOR %s]Buscar Serie[/COLOR]' % oo00O00oO , 'search' , 145 , O0OO00o0OO , oo00 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Sin Resultados para: [COLOR orange]" + O0o0O0 + "[/COLOR] , 2000)" )
     if 54 - 54: o0oO0 * Oooo0Ooo000 - OoooooooOO % OOooOOo + O0
     if 6 - 6: o00O0oo - II111iiii / oO0o0ooO0 + i11iIiiIii + IIII
   except : IIi ( '[COLOR %s]Buscar Serie[/COLOR]' % oo00O00oO , 'search' , 145 , O0OO00o0OO , oo00 )
   if 54 - 54: o0oO0 - O0oO - Oooo0Ooo000 . iIii1I11I1II1
 except :
  pass
  if 79 - 79: o0oO0 . OoOO
def IIiI1I1 ( ) :
 if 15 - 15: o0oO0 * ii11ii1ii % o00O0oo * iIii1I11I1II1 - i11iIiiIii
 try :
  if 60 - 60: OOooOOo * Oooo0Ooo000 % OoOO + oO0o0ooO0
  iIIIII1iiiiII = ii1iiIiIII1ii ( O0O0Oo00 )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( iIIIII1iiiiII )
  for IiIiII1 in oO0o0oooO0oO :
   if 52 - 52: i1IIi
   try :
    if 84 - 84: o0oO0 / i1I111II1I
    O0o0O0OO00o = IiIiII1
    if 86 - 86: OoOO0ooOOoo0O * II111iiii - O0 . OoOO0ooOOoo0O % iIii1I11I1II1 / IIII
   except :
    pass
    if 11 - 11: OOooOOo * oO0o0ooO0 + o00O0oo / o00O0oo
  Ii1II1I11i1 = ii1iiIiIII1ii ( O0o0O0OO00o )
  oO0o0oooO0oO = re . compile ( OO ) . findall ( Ii1II1I11i1 )
  for OOo00O , Ii111 , oo00 , I111i1i1111 , I1I1i in oO0o0oooO0oO :
   try :
    if 37 - 37: i11iIiiIii + i1IIi
    Iii111Ii ( Ii111 , I111i1i1111 , 143 , OOo00O , oo00 , I1I1i )
    if 23 - 23: O0ooOooooO + O0oO . OoOO0ooOOoo0O * OOooOOo + o00O0oo
   except :
    pass
 except :
  pass
  if 18 - 18: i1I111II1I * o0000oOoOoO0o . i1I111II1I / O0
def iiIII1II ( ) :
 if 100 - 100: ii11ii1ii % o0oO0 / O0oO
 try :
  if 30 - 30: ii11ii1ii - IIII - O0ooOooooO
  iIIIII1iiiiII = ii1iiIiIII1ii ( I1ii1ii11i1I )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( iIIIII1iiiiII )
  for IiIiII1 in oO0o0oooO0oO :
   if 81 - 81: o0000oOoOoO0o . OoooooooOO + IIII * iI
   try :
    if 74 - 74: i1IIi + O0 + ii11ii1ii
    O0o0O0OO00o = IiIiII1
    if 5 - 5: ii11ii1ii * OoOO0ooOOoo0O
   except :
    pass
    if 46 - 46: iI
  Ii1II1I11i1 = ii1iiIiIII1ii ( O0o0O0OO00o )
  oO0o0oooO0oO = re . compile ( OO ) . findall ( Ii1II1I11i1 )
  for OOo00O , Ii111 , oo00 , I111i1i1111 , I1I1i in oO0o0oooO0oO :
   try :
    if 33 - 33: O0ooOooooO - II111iiii * OoooooooOO - ii11ii1ii - IIII
    Iii111Ii ( Ii111 , I111i1i1111 , 143 , OOo00O , oo00 , I1I1i )
    if 84 - 84: Oooo0Ooo000 + ii11ii1ii - OoOO0ooOOoo0O * OoOO0ooOOoo0O
   except :
    pass
 except :
  pass
  if 61 - 61: OoooooooOO . oO0o0ooO0 . OoooooooOO / ii11ii1ii
  if 72 - 72: i1IIi
def OOoo0oo ( ) :
 if 58 - 58: oO0o0ooO0
 try :
  if 4 - 4: II111iiii . iI / o00O0oo - i11iIiiIii
  iIIIII1iiiiII = ii1iiIiIII1ii ( OOoOooOoOOOoo )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( iIIIII1iiiiII )
  for IiIiII1 in oO0o0oooO0oO :
   if 72 - 72: O0 / iI + OoooooooOO * O0ooOooooO
   try :
    if 61 - 61: OoooooooOO % II111iiii - OOooOOo % o00O0oo + i1IIi
    O0o0O0OO00o = IiIiII1
    if 39 - 39: i1IIi
   except :
    pass
    if 86 - 86: iIii1I11I1II1 + OoOO0ooOOoo0O . i11iIiiIii - o0oO0
  Ii1II1I11i1 = ii1iiIiIII1ii ( O0o0O0OO00o )
  oO0o0oooO0oO = re . compile ( OO ) . findall ( Ii1II1I11i1 )
  for OOo00O , Ii111 , oo00 , I111i1i1111 , I1I1i in oO0o0oooO0oO :
   try :
    if 51 - 51: OoOO0ooOOoo0O
    Iii111Ii ( Ii111 , I111i1i1111 , 143 , OOo00O , oo00 , I1I1i )
    if 14 - 14: i1I111II1I % oO0o0ooO0 % ii11ii1ii - i11iIiiIii
   except :
    pass
 except :
  pass
  if 53 - 53: o0oO0 % ii11ii1ii
def O0ooOo0o0Oo ( ) :
 if 71 - 71: iIii1I11I1II1 - IIII . OOooOOo % OoooooooOO + IIII
 try :
  if 26 - 26: ii11ii1ii + IIII / OoOO % OoOO0ooOOoo0O % o00O0oo + II111iiii
  iIIIII1iiiiII = ii1iiIiIII1ii ( iiI )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( iIIIII1iiiiII )
  for IiIiII1 in oO0o0oooO0oO :
   if 31 - 31: O0oO % IIII * O0oO
   try :
    if 45 - 45: i1IIi . OOooOOo + IIII - OoooooooOO % iI
    O0o0O0OO00o = IiIiII1
    if 1 - 1: iIii1I11I1II1
   except :
    pass
    if 93 - 93: i1IIi . i11iIiiIii . ii11ii1ii
  Ii1II1I11i1 = ii1iiIiIII1ii ( O0o0O0OO00o )
  oO0o0oooO0oO = re . compile ( OO ) . findall ( Ii1II1I11i1 )
  for OOo00O , Ii111 , oo00 , I111i1i1111 , I1I1i in oO0o0oooO0oO :
   try :
    if 99 - 99: O0oO - Oooo0Ooo000 - oO0o0ooO0 % OoOO
    Iii111Ii ( Ii111 , I111i1i1111 , 143 , OOo00O , oo00 , I1I1i )
    if 21 - 21: II111iiii % o00O0oo . i1IIi - OoooooooOO
   except :
    pass
 except :
  pass
  if 4 - 4: OoooooooOO . iI
def oOO0oo ( ) :
 if 29 - 29: OOooOOo * II111iiii * OoooooooOO - o00O0oo * II111iiii
 try :
  if 41 - 41: O0
  iIIIII1iiiiII = ii1iiIiIII1ii ( OO0 )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( iIIIII1iiiiII )
  for IiIiII1 in oO0o0oooO0oO :
   if 30 - 30: iI % O0ooOooooO * IIII - o00O0oo * o0oO0 % iI
   try :
    if 46 - 46: i11iIiiIii - O0 . oO0o0ooO0
    O0o0O0OO00o = IiIiII1
    if 100 - 100: OOooOOo / o0000oOoOoO0o * O0ooOooooO . O0 / IIII
   except :
    pass
    if 83 - 83: Oooo0Ooo000
  Ii1II1I11i1 = ii1iiIiIII1ii ( O0o0O0OO00o )
  oO0o0oooO0oO = re . compile ( OO ) . findall ( Ii1II1I11i1 )
  for OOo00O , Ii111 , oo00 , I111i1i1111 , I1I1i in oO0o0oooO0oO :
   try :
    if 48 - 48: II111iiii * IIII * Oooo0Ooo000
    Iii111Ii ( Ii111 , I111i1i1111 , 143 , OOo00O , oo00 , I1I1i )
    if 50 - 50: i1I111II1I % i1IIi
   except :
    pass
 except :
  pass
  if 21 - 21: OoooooooOO - iIii1I11I1II1
def OO0OoOOO0 ( name , url ) :
 if 90 - 90: iI + II111iiii * o00O0oo / o0oO0 . o0000oOoOoO0o + o0000oOoOoO0o
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 40 - 40: iI / OoOO0ooOOoo0O % i11iIiiIii % o00O0oo / OOooOOo
 ooOOOOo0 = ii1iiIiIII1ii ( url )
 oO0o0oooO0oO = re . compile ( iiIi1IIi1I ) . findall ( ooOOOOo0 )
 for OOo00O , name , oo00 , url in oO0o0oooO0oO :
  try :
   if 38 - 38: OoooooooOO / o00O0oo . O0 / i1IIi / ii11ii1ii + iIii1I11I1II1
   if 96 - 96: O0ooOooooO
   oOOo0 = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % oOOo0 + name + '[/COLOR]'
   i1I11iIII1i1I ( name , url , 144 , OOo00O , oo00 )
   if 63 - 63: ii11ii1ii + Oooo0Ooo000 - II111iiii
   if 2 - 2: i1I111II1I
  except :
   pass
   if 97 - 97: oO0o0ooO0 - OoooooooOO
   if 79 - 79: OoOO0ooOOoo0O % i1I111II1I % ii11ii1ii
   if 29 - 29: OoooooooOO . OOooOOo % o00O0oo - O0ooOooooO
def i1I11iIII1i1I ( name , url , mode , iconimage , fanart ) :
 if 8 - 8: i1IIi
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 32 - 32: oO0o0ooO0 / II111iiii
 II1Iii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage="
 O0oooo0OoO0oo = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 O0oooo0OoO0oo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 O0oooo0OoO0oo . setProperty ( 'fanart_image' , fanart )
 O0oooo0OoO0oo . setProperty ( 'IsPlayable' , 'true' )
 IiiiIi1iI1iI = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1Iii , listitem = O0oooo0OoO0oo )
 return IiiiIi1iI1iI
 if 98 - 98: OoOO / IIII * o00O0oo / oO0o0ooO0
 if 64 - 64: oO0o0ooO0 - OOooOOo / O0ooOooooO - OoOO
def ii11I ( name , url ) :
 if 47 - 47: Oooo0Ooo000
 if 95 - 95: OoOO . i1IIi / i11iIiiIii
 O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 o00iI = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 O0O0Oooo0o = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 iIi1IIiI = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 o0OOOo = ii1iiIiIII1ii ( O0O0Oooo0o )
 oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
 for I11i11I1iiII in oO0o0oooO0oO :
  if 28 - 28: i11iIiiIii / o0000oOoOoO0o . iIii1I11I1II1 / II111iiii
  try :
   if 72 - 72: OoooooooOO / OOooOOo + o0oO0 / OoOO0ooOOoo0O * o0oO0
   if 34 - 34: O0 * O0 % OoooooooOO + O0ooOooooO * iIii1I11I1II1 % o0oO0
   O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 25 - 25: O0oO + OoOO0ooOOoo0O . o0000oOoOoO0o % OoOO0ooOOoo0O * IIII
   if 32 - 32: i11iIiiIii - Oooo0Ooo000
   if O00O0oOO00O00 == I11i11I1iiII :
    if 53 - 53: OoooooooOO - i1I111II1I
    if 87 - 87: oO0o0ooO0 . OOooOOo
    if 'https://team.com' in url :
     if 17 - 17: o0oO0 . i11iIiiIii
     url = url . replace ( 'https://team.com' , 'https://verystream.com' )
     if 5 - 5: o00O0oo + O0 + O0 . Oooo0Ooo000 - iI
    if 'https://mybox.com' in url :
     if 63 - 63: oO0o0ooO0
     url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
     if 71 - 71: i1IIi . o0oO0 * O0ooOooooO % OoooooooOO + IIII
     if 36 - 36: i1I111II1I
    if 'https://vidcloud.co/' in url :
     if 49 - 49: IIII / OoooooooOO / OOooOOo
     url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
     if 74 - 74: Oooo0Ooo000 % o00O0oo
    if 'https://gounlimited.to' in url :
     if 7 - 7: II111iiii
     url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
     if 27 - 27: oO0o0ooO0 . OoooooooOO + i11iIiiIii
    if 'https://drive.com' in url :
     if 86 - 86: O0oO / o0000oOoOoO0o - o0000oOoOoO0o + o00O0oo + oO0o0ooO0
     url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
     if 33 - 33: o0000oOoOoO0o . O0ooOooooO . i1I111II1I . i1IIi
     if 49 - 49: o00O0oo
    import resolveurl
    if 84 - 84: O0oO - ii11ii1ii / O0 - Oooo0Ooo000
    ii1iI1II11ii = urlresolver . HostedMediaFile ( url )
    if 8 - 8: iI * O0
    if not ii1iI1II11ii :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
     return False
     if 73 - 73: o0000oOoOoO0o / oO0o0ooO0 / O0oO / OoOO
    try :
     iI1I = xbmcgui . DialogProgress ( )
     iI1I . create ( 'Realstream:' , 'Iniciando ...' )
     iI1I . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
     xbmc . sleep ( 1000 )
     III1ii = ii1iI1II11ii . resolve ( )
     if not III1ii or not isinstance ( III1ii , basestring ) :
      try : i1I = III1ii . msg
      except : i1I = url
      raise Exception ( i1I )
      if 36 - 36: OOooOOo * ii11ii1ii
    except Exception as o0O0Oo00 :
     try : i1I = str ( o0O0Oo00 )
     except : i1I = url
     iI1I . update ( 45 , 'RESOLVEURL:' , 'Reiniciando ... ' )
     xbmc . sleep ( 1000 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Episodio no disponible.  ,3000)" )
     iI1I . close ( )
     if 77 - 77: oO0o0ooO0 % i1IIi - o0oO0
    iI1I . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    iI1I . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
    xbmc . sleep ( 500 )
    iI1I . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
    xbmc . sleep ( 500 )
    iI1I . update ( 100 , 'RESOLVEURL:' , 'Disfrute de este capitulo!' )
    iI1I . close ( )
    i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
    oOO00OO0ooo0o = xbmcgui . ListItem ( path = III1ii )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO00OO0ooo0o )
    if 83 - 83: o00O0oo / Oooo0Ooo000 - i11iIiiIii . iIii1I11I1II1 + ii11ii1ii
    if 59 - 59: O0 % ii11ii1ii
   else :
    if 92 - 92: o0oO0 % O0ooOooooO / o00O0oo % o00O0oo * OOooOOo
    i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
    if i1Oo00 == 'true' :
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Por favor compruebe los ajustes de realstream.[/COLOR]" , "[COLOR white] Desde la seccion Tutoriales puede sacarle mayor partido a su Realstream, tambien puede configurarlo a su gusto. [/COLOR]" , "[COLOR gold]El addon no esta activado o bien configurado.[/COLOR]" )
     if 74 - 74: O0 . OOooOOo % OoOO % i1I111II1I
     oo00O00oO = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
     IIi ( '[COLOR %s]Video tutoriales[/COLOR]' % oo00O00oO , o00oooO0Oo , 125 , O0OOO0OOoO0O , oo00 )
  except :
   pass
   if 87 - 87: oO0o0ooO0 - i11iIiiIii
   if 78 - 78: i11iIiiIii / iIii1I11I1II1 - o0000oOoOoO0o
   if 23 - 23: O0oO
   if 40 - 40: o0000oOoOoO0o - II111iiii / ii11ii1ii
   if 14 - 14: o00O0oo
def iI1 ( ) :
 if 14 - 14: o00O0oo
 if 49 - 49: oO0o0ooO0 / i1IIi % o0oO0 . OOooOOo
 oOOoOoo0O0 = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 oOOoOoo0O0 . doModal ( )
 if not oOOoOoo0O0 . isConfirmed ( ) :
  return None ;
 Ii111 = oOOoOoo0O0 . getText ( ) . strip ( )
 if 45 - 45: i11iIiiIii
 if 82 - 82: o0oO0 + i1I111II1I
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 12 - 12: Oooo0Ooo000
  Oo0oOooOoOo = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + Ii111 + '&language=es-ES' ) )
  if 49 - 49: IIII . o00O0oo . i11iIiiIii - II111iiii / o0oO0
  if 62 - 62: IIII
  return 'android'
  if 1 - 1: i1I111II1I / i1I111II1I - i11iIiiIii
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 87 - 87: ii11ii1ii / O0 * i1I111II1I / o0000oOoOoO0o
  Oo0oOooOoOo = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + Ii111 + '&language=es-ES' )
  if 19 - 19: Oooo0Ooo000 + i1IIi . OOooOOo - ii11ii1ii
  if 16 - 16: oO0o0ooO0 + iI / o0000oOoOoO0o
  return 'windows'
  if 82 - 82: i1I111II1I * i11iIiiIii % II111iiii - OoooooooOO
  if 90 - 90: ii11ii1ii . oO0o0ooO0 * i1IIi - i1IIi
def IiIiiI11i1Ii ( ) :
 if 100 - 100: Oooo0Ooo000 . OOooOOo * Oooo0Ooo000 - OOooOOo . O0oO * o0oO0
 try :
  if 89 - 89: OoOO + i1I111II1I * Oooo0Ooo000
  o0OOOo = ii1iiIiIII1ii ( oooooo0O000o )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 28 - 28: OoooooooOO . oO0o0ooO0 % o00O0oo / i1IIi / IIII
   try :
    if 36 - 36: o0000oOoOoO0o + O0oO - i1I111II1I + iIii1I11I1II1 + OoooooooOO
    all = IiIiII1
    if 4 - 4: II111iiii . O0oO + o0oO0 * Oooo0Ooo000 . iI
   except :
    pass
    if 87 - 87: OoOO0ooOOoo0O / OoOO / i11iIiiIii
  ooOOOOo0 = ii1iiIiIII1ii ( all )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( ooOOOOo0 )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    if 74 - 74: oO0o0ooO0 / o00O0oo % o0000oOoOoO0o
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 88 - 88: OoOO0ooOOoo0O - i11iIiiIii % o0000oOoOoO0o * O0oO + o00O0oo
   except :
    pass
 except :
  pass
  if 52 - 52: II111iiii . OOooOOo + OoOO0ooOOoo0O % OoOO
def oo0O0o00 ( ) :
 if 70 - 70: OoOO
 try :
  if 46 - 46: O0oO - i1IIi
  i1111 = ii1iiIiIII1ii ( ooO0O0O0ooOOO )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( i1111 )
  for IiIiII1 in oO0o0oooO0oO :
   if 46 - 46: Oooo0Ooo000 % o0oO0
   try :
    if 72 - 72: iIii1I11I1II1
    O0o0O0OO00o = IiIiII1
    if 45 - 45: ii11ii1ii - o0000oOoOoO0o % Oooo0Ooo000
   except :
    pass
    if 38 - 38: Oooo0Ooo000 % IIII - OoooooooOO
  Ii1II1I11i1 = ii1iiIiIII1ii ( O0o0O0OO00o )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( Ii1II1I11i1 )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    if 87 - 87: OoOO % OOooOOo
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 77 - 77: iIii1I11I1II1 - i1IIi . oO0o0ooO0
   except :
    pass
 except :
  pass
  if 26 - 26: o0000oOoOoO0o * i1I111II1I . i1IIi
def ooOoOO ( ) :
 if 56 - 56: iIii1I11I1II1 . i11iIiiIii - IIII * II111iiii * Oooo0Ooo000
 try :
  if 5 - 5: IIII / IIII - o00O0oo
  i11 = ii1iiIiIII1ii ( iIiIi11 )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( i11 )
  for IiIiII1 in oO0o0oooO0oO :
   if 79 - 79: o00O0oo + Oooo0Ooo000
   try :
    iIiIIi = IiIiII1
   except :
    pass
    if 14 - 14: o0000oOoOoO0o / IIII - iIii1I11I1II1 - oO0o0ooO0 % iI
  o0OOOo = ii1iiIiIII1ii ( iIiIIi )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    if 49 - 49: iI * oO0o0ooO0 / o0000oOoOoO0o / ii11ii1ii * iIii1I11I1II1
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 57 - 57: OoOO0ooOOoo0O - oO0o0ooO0 / iI % i11iIiiIii
   except :
    pass
 except :
  pass
  if 3 - 3: O0ooOooooO . iI % OOooOOo + o00O0oo
def oo0oo0 ( ) :
 if 35 - 35: i11iIiiIii - OOooOOo / IIII + o0oO0 * oO0o0ooO0
 try :
  if 49 - 49: o0000oOoOoO0o * o0oO0 + O0oO + O0ooOooooO
  o0OOOo = ii1iiIiIII1ii ( db2 )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 30 - 30: o0000oOoOoO0o / IIII / i1I111II1I % iI + II111iiii
   try :
    if 4 - 4: O0ooOooooO - ii11ii1ii - i1I111II1I - O0oO % i11iIiiIii / OoOO
    i1iii11 = IiIiII1
    if 92 - 92: OoOO0ooOOoo0O . OoooooooOO - Oooo0Ooo000
   except :
    pass
    if 74 - 74: iIii1I11I1II1 % O0ooOooooO * IIII * iIii1I11I1II1
    if 73 - 73: o0000oOoOoO0o % Oooo0Ooo000 . IIII
  o0OOOo = ii1iiIiIII1ii ( i1iii11 )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 60 - 60: OoOO0ooOOoo0O
   except :
    pass
 except :
  pass
  if 5 - 5: OOooOOo - OOooOOo - OOooOOo * OoooooooOO
def iiiiiII ( ) :
 if 21 - 21: iIii1I11I1II1 / II111iiii % i1IIi
 try :
  if 8 - 8: OoOO + OoOO0ooOOoo0O . iIii1I11I1II1 % O0
  iI11Ii111 = ii1iiIiIII1ii ( OoOOoooOO0O )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( iI11Ii111 )
  for IiIiII1 in oO0o0oooO0oO :
   if 54 - 54: OoOO0ooOOoo0O % O0ooOooooO . OoOO0ooOOoo0O * IIII + OoOO0ooOOoo0O % i1IIi
   try :
    if 23 - 23: Oooo0Ooo000 - IIII + o0oO0 - OoOO0ooOOoo0O * OoOO0ooOOoo0O . ii11ii1ii
    iIii11iI1II = IiIiII1
    if 42 - 42: iI - OOooOOo + o00O0oo % o0oO0
   except :
    pass
    if 44 - 44: i1IIi - O0 - o00O0oo * o00O0oo + OoOO0ooOOoo0O
    if 56 - 56: iI / iIii1I11I1II1 . o0oO0 % OoOO0ooOOoo0O + IIII
  o0OOOo = ii1iiIiIII1ii ( iIii11iI1II )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    if 10 - 10: Oooo0Ooo000 * i11iIiiIii - iIii1I11I1II1 . ii11ii1ii - o00O0oo
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 20 - 20: o00O0oo / OOooOOo * OoOO * OOooOOo * O0
   except :
    pass
 except :
  pass
  if 1 - 1: iIii1I11I1II1 + ii11ii1ii / O0 - O0ooOooooO % i1I111II1I + i1I111II1I
def IiIIII ( ) :
 if 48 - 48: Oooo0Ooo000 + O0ooOooooO
 try :
  if 16 - 16: iIii1I11I1II1 % i11iIiiIii . OoOO0ooOOoo0O % iI + oO0o0ooO0 . OoOO
  o0OOOo = ii1iiIiIII1ii ( iiiiI )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 46 - 46: OoOO - o0000oOoOoO0o / OoOO0ooOOoo0O - OoooooooOO + oO0o0ooO0
   try :
    if 58 - 58: o0000oOoOoO0o / o0000oOoOoO0o + iI + O0oO - OoOO0ooOOoo0O . IIII
    I11Ii1iI11iI1 = IiIiII1
    if 32 - 32: OOooOOo
   except :
    pass
    if 78 - 78: OoOO0ooOOoo0O - OoOO % iI
    if 80 - 80: Oooo0Ooo000 . O0oO
  o0OOOo = ii1iiIiIII1ii ( I11Ii1iI11iI1 )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 73 - 73: OoOO0ooOOoo0O . O0 / O0ooOooooO * oO0o0ooO0
   except :
    pass
 except :
  pass
  if 29 - 29: o0000oOoOoO0o
def oo0 ( ) :
 if 2 - 2: OoooooooOO
 try :
  if 60 - 60: OoOO
  o0OOOo = ii1iiIiIII1ii ( OOoO )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 81 - 81: OoOO0ooOOoo0O % o0oO0
   try :
    if 87 - 87: iIii1I11I1II1 . OoooooooOO * OoOO0ooOOoo0O
    OOOoo0ooOo00O = IiIiII1
    if 38 - 38: iIii1I11I1II1 + i11iIiiIii * OoOO * iI % IIII
   except :
    pass
    if 5 - 5: iI - Oooo0Ooo000 + OOooOOo * O0 / ii11ii1ii - o0oO0
  o0OOOo = ii1iiIiIII1ii ( OOOoo0ooOo00O )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 75 - 75: OoooooooOO - IIII + o0000oOoOoO0o / O0ooOooooO % i11iIiiIii
   except :
    pass
 except :
  pass
  if 10 - 10: OoOO
def iii1 ( ) :
 if 66 - 66: oO0o0ooO0 * iIii1I11I1II1 % iIii1I11I1II1 * i1I111II1I - iI - i1I111II1I
 try :
  if 70 - 70: Oooo0Ooo000 + oO0o0ooO0
  o0OOOo = ii1iiIiIII1ii ( iiIiI1i1 )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 93 - 93: Oooo0Ooo000 + o0oO0
   try :
    if 33 - 33: O0
    oo0oO = IiIiII1
    if 50 - 50: OoooooooOO - iIii1I11I1II1 + i1IIi % Oooo0Ooo000 - iIii1I11I1II1 % O0
   except :
    pass
    if 58 - 58: i1I111II1I + iIii1I11I1II1
    if 65 - 65: II111iiii - Oooo0Ooo000 % o0000oOoOoO0o - OoOO0ooOOoo0O * O0ooOooooO + o0oO0
  o0OOOo = ii1iiIiIII1ii ( oo0oO )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 79 - 79: iI . OoOO0ooOOoo0O % Oooo0Ooo000 - ii11ii1ii
   except :
    pass
 except :
  pass
  if 69 - 69: iI - o0000oOoOoO0o . iI
def iIiiIi11IIi ( ) :
 if 64 - 64: OoooooooOO . o00O0oo % O0 + OOooOOo - o0000oOoOoO0o
 try :
  if 84 - 84: i11iIiiIii * o0oO0 . i11iIiiIii
  o0OOOo = ii1iiIiIII1ii ( IiIi11iI )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 12 - 12: OoOO0ooOOoo0O % i1I111II1I % o00O0oo . i11iIiiIii * iIii1I11I1II1
   try :
    if 66 - 66: i11iIiiIii * iIii1I11I1II1 % OoooooooOO
    iIiI1iI1i1I = IiIiII1
    if 82 - 82: OOooOOo % o00O0oo * O0ooOooooO . o0oO0 % OOooOOo - iIii1I11I1II1
   except :
    pass
    if 15 - 15: o00O0oo % Oooo0Ooo000 + i11iIiiIii
    if 10 - 10: o0oO0 - OoOO0ooOOoo0O . OoooooooOO . IIII . OoOO * O0ooOooooO
  o0OOOo = ii1iiIiIII1ii ( iIiI1iI1i1I )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 78 - 78: oO0o0ooO0 / OoOO - oO0o0ooO0 * OoooooooOO . OoOO0ooOOoo0O
   except :
    pass
 except :
  pass
  if 96 - 96: OOooOOo % i1IIi . o0000oOoOoO0o . O0
def Ii1Iii11 ( ) :
 if 97 - 97: IIII / oO0o0ooO0 . II111iiii
 try :
  if 44 - 44: o0oO0 % O0oO . Oooo0Ooo000
  o0OOOo = ii1iiIiIII1ii ( i11I1IiII1i1i )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 18 - 18: iIii1I11I1II1 + O0oO * OOooOOo - IIII / OOooOOo
   try :
    if 78 - 78: O0oO . i1I111II1I
    iI1i1II = IiIiII1
    if 14 - 14: iI - iIii1I11I1II1 / O0 % i1I111II1I . OoOO0ooOOoo0O
   except :
    pass
    if 18 - 18: oO0o0ooO0 * oO0o0ooO0 % oO0o0ooO0
    if 17 - 17: O0 * OoOO0ooOOoo0O * o00O0oo * II111iiii * O0oO % i1IIi
  o0OOOo = ii1iiIiIII1ii ( iI1i1II )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 33 - 33: o00O0oo * o00O0oo . iI . i11iIiiIii
   except :
    pass
 except :
  pass
  if 48 - 48: o0000oOoOoO0o . o0oO0 + OoOO0ooOOoo0O % o00O0oo / i11iIiiIii
def OoOi111i ( ) :
 if 46 - 46: OoOO * ii11ii1ii % oO0o0ooO0 + O0 * i1I111II1I
 try :
  if 34 - 34: OoOO
  o0OOOo = ii1iiIiIII1ii ( Oo0o0O00 )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 27 - 27: o0oO0 - O0 % O0oO * Oooo0Ooo000 . i1I111II1I % iIii1I11I1II1
   try :
    if 37 - 37: OoooooooOO + O0 - i1IIi % iI
    i1I1i1i = IiIiII1
    if 36 - 36: II111iiii % O0
   except :
    pass
    if 35 - 35: iIii1I11I1II1 - IIII % o0000oOoOoO0o
    if 30 - 30: Oooo0Ooo000 % Oooo0Ooo000 % i1I111II1I . OoOO0ooOOoo0O
  o0OOOo = ii1iiIiIII1ii ( i1I1i1i )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 9 - 9: iI / II111iiii . OoOO0ooOOoo0O % o0000oOoOoO0o * II111iiii - iI
   except :
    pass
 except :
  pass
  if 55 - 55: OOooOOo
  if 45 - 45: O0 / i1IIi * oO0o0ooO0 * OoOO
def II11I ( ) :
 if 31 - 31: o0oO0
 try :
  if 18 - 18: iI + o0oO0
  o0OOOo = ii1iiIiIII1ii ( I1111i )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 5 - 5: OoooooooOO + O0oO * II111iiii
   try :
    if 98 - 98: IIII % i1IIi . OOooOOo . II111iiii . o00O0oo / i11iIiiIii
    iIii1I = IiIiII1
    if 50 - 50: OoOO0ooOOoo0O
   except :
    pass
    if 33 - 33: O0oO
    if 98 - 98: OoOO0ooOOoo0O % II111iiii
  o0OOOo = ii1iiIiIII1ii ( iIii1I )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 95 - 95: iIii1I11I1II1 - Oooo0Ooo000 - IIII + Oooo0Ooo000 % o00O0oo . OOooOOo
   except :
    pass
 except :
  pass
  if 41 - 41: O0 + oO0o0ooO0 . i1IIi - II111iiii * o0000oOoOoO0o . OoOO
  if 68 - 68: o0000oOoOoO0o
def i11Ii1IIi ( ) :
 if 36 - 36: O0 * OoOO % O0ooOooooO * O0ooOooooO / OoOO * i1I111II1I
 try :
  if 14 - 14: i1IIi . i1I111II1I + O0 * iI
  o0OOOo = ii1iiIiIII1ii ( o00O0O )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 76 - 76: OoOO
   try :
    if 92 - 92: O0oO - iIii1I11I1II1 % OoooooooOO
    I1oOooo00O = IiIiII1
    if 66 - 66: OoOO0ooOOoo0O + i1IIi % II111iiii . O0 * o00O0oo % o00O0oo
   except :
    pass
    if 87 - 87: IIII + o0000oOoOoO0o . O0ooOooooO - OoooooooOO
    if 6 - 6: iIii1I11I1II1 * OoooooooOO
  o0OOOo = ii1iiIiIII1ii ( I1oOooo00O )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 28 - 28: ii11ii1ii * o0000oOoOoO0o / Oooo0Ooo000
   except :
    pass
    if 52 - 52: O0 / o0000oOoOoO0o % O0ooOooooO * OOooOOo % IIII
 except :
  pass
  if 69 - 69: o00O0oo
  if 83 - 83: o0000oOoOoO0o
def i1iiii ( ) :
 if 90 - 90: o0000oOoOoO0o % o00O0oo - iIii1I11I1II1 % OoOO0ooOOoo0O
 try :
  if 8 - 8: OoOO0ooOOoo0O * ii11ii1ii / i1I111II1I % o0oO0 - OOooOOo
  o0OOOo = ii1iiIiIII1ii ( Iii1I1111ii )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 71 - 71: O0ooOooooO
   try :
    if 23 - 23: i1IIi . iIii1I11I1II1 . IIII . O0 % o0oO0 % i11iIiiIii
    Iiiii111 = IiIiII1
    if 93 - 93: OoooooooOO * ii11ii1ii
   except :
    pass
    if 10 - 10: Oooo0Ooo000 * OoooooooOO + O0oO - o00O0oo / o00O0oo . i11iIiiIii
    if 22 - 22: Oooo0Ooo000 / o0000oOoOoO0o
  o0OOOo = ii1iiIiIII1ii ( Iiiii111 )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 98 - 98: i1IIi
   except :
    pass
    if 51 - 51: o00O0oo + iI + ii11ii1ii / i1IIi + i1IIi
 except :
  pass
  if 12 - 12: iIii1I11I1II1 . o0oO0 . o00O0oo % OOooOOo . II111iiii . oO0o0ooO0
def IIi1ii1 ( ) :
 if 48 - 48: iI / iIii1I11I1II1 + IIII + iIii1I11I1II1 . OoOO
 try :
  if 60 - 60: Oooo0Ooo000
  o0OOOo = ii1iiIiIII1ii ( Ii1IIiI1i )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 98 - 98: iI
   try :
    if 34 - 34: iIii1I11I1II1 * O0oO * O0oO / o00O0oo
    IIIIIIi1i = IiIiII1
    if 26 - 26: iIii1I11I1II1 - O0 . O0
   except :
    pass
    if 68 - 68: IIII + oO0o0ooO0 . O0 . o0oO0 % i1IIi % IIII
  o0OOOo = ii1iiIiIII1ii ( IIIIIIi1i )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 50 - 50: i1I111II1I + o0000oOoOoO0o
   except :
    pass
 except :
  pass
  if 96 - 96: OoOO
  if 92 - 92: ii11ii1ii / i11iIiiIii + o00O0oo
def oOo0Oo0O0O ( ) :
 if 48 - 48: ii11ii1ii - iI + ii11ii1ii - OOooOOo * i11iIiiIii . O0ooOooooO
 try :
  if 35 - 35: i1I111II1I . O0 + ii11ii1ii + IIII + i1IIi
  o0OOOo = ii1iiIiIII1ii ( IiII111i1i11 )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 65 - 65: O0 * OOooOOo / OOooOOo . OoOO0ooOOoo0O
   try :
    if 87 - 87: II111iiii * o00O0oo % ii11ii1ii * ii11ii1ii
    O0OOOOOO0 = IiIiII1
    if 79 - 79: II111iiii - iI . i1IIi + O0 % O0 * OOooOOo
   except :
    pass
    if 7 - 7: i1IIi + IIII % O0ooOooooO / o0000oOoOoO0o + i1IIi
    if 41 - 41: o0oO0 + i11iIiiIii / i1I111II1I % o00O0oo
  o0OOOo = ii1iiIiIII1ii ( O0OOOOOO0 )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 22 - 22: OoOO0ooOOoo0O % o0000oOoOoO0o * o0oO0 - o00O0oo + o0000oOoOoO0o - ii11ii1ii
   except :
    pass
 except :
  pass
  if 15 - 15: IIII
  if 31 - 31: O0ooOooooO / i1IIi . OoOO
def OOOoo ( ) :
 if 25 - 25: o00O0oo + oO0o0ooO0 + OoooooooOO . II111iiii . O0ooOooooO
 try :
  if 66 - 66: iI * OoOO0ooOOoo0O
  o0OOOo = ii1iiIiIII1ii ( oooO )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 2 - 2: oO0o0ooO0 . Oooo0Ooo000 * ii11ii1ii + O0 - O0oO * iIii1I11I1II1
   try :
    if 12 - 12: o0000oOoOoO0o * Oooo0Ooo000 % II111iiii * i1IIi * iIii1I11I1II1
    oO0oOoo0O = IiIiII1
    if 26 - 26: ii11ii1ii + OOooOOo * IIII + iI
   except :
    pass
  o0OOOo = ii1iiIiIII1ii ( oO0oOoo0O )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 88 - 88: O0oO + i11iIiiIii % oO0o0ooO0 * IIII * IIII * o0oO0
   except :
    pass
 except :
  pass
  if 24 - 24: iI / O0ooOooooO + i1I111II1I . i1I111II1I
def I1ii1i ( ) :
 if 22 - 22: oO0o0ooO0 * o0oO0 * i11iIiiIii + O0ooOooooO * OoOO0ooOOoo0O * OoOO
 try :
  if 85 - 85: O0ooOooooO * IIII % ii11ii1ii - O0ooOooooO - O0oO
  o0OOOo = ii1iiIiIII1ii ( ooo )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 46 - 46: O0
   try :
    if 65 - 65: iIii1I11I1II1 % oO0o0ooO0 + O0 / OoooooooOO
    O0000oO0o00 = IiIiII1
    if 80 - 80: OoooooooOO + i1I111II1I
   except :
    pass
    if 95 - 95: Oooo0Ooo000 / oO0o0ooO0 * Oooo0Ooo000 - OoooooooOO * OoooooooOO % OoOO
    if 43 - 43: ii11ii1ii . Oooo0Ooo000
  o0OOOo = ii1iiIiIII1ii ( O0000oO0o00 )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 12 - 12: Oooo0Ooo000 + IIII + O0oO . i1I111II1I / o0oO0
   except :
    pass
 except :
  pass
  if 29 - 29: i1I111II1I . iI - II111iiii
  if 68 - 68: iIii1I11I1II1 + II111iiii / oO0o0ooO0
def oOooo00000 ( ) :
 if 26 - 26: O0
 try :
  if 34 - 34: iI * Oooo0Ooo000
  o0OOOo = ii1iiIiIII1ii ( Ooo0oOooo0 )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 97 - 97: i11iIiiIii % oO0o0ooO0 / ii11ii1ii / ii11ii1ii
   try :
    if 97 - 97: II111iiii - Oooo0Ooo000 - iIii1I11I1II1 * OOooOOo
    oooO0o0O0oo0o = IiIiII1
    if 100 - 100: i1I111II1I . o0oO0 - iIii1I11I1II1 . i11iIiiIii / II111iiii
   except :
    pass
    if 71 - 71: Oooo0Ooo000 * ii11ii1ii . O0oO
    if 49 - 49: i1I111II1I * O0 . i1I111II1I
  o0OOOo = ii1iiIiIII1ii ( oooO0o0O0oo0o )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 19 - 19: II111iiii - i1I111II1I
   except :
    pass
 except :
  pass
  if 59 - 59: o0000oOoOoO0o * OoOO - o0oO0 . IIII
def o0OO00oo0O ( ) :
 if 46 - 46: i11iIiiIii - IIII * OOooOOo * O0oO % o00O0oo * i1IIi
 try :
  if 5 - 5: O0 / iI . ii11ii1ii + OoooooooOO
  o0OOOo = ii1iiIiIII1ii ( iiIiIIIiiI )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 97 - 97: i1I111II1I . o0oO0 . o0oO0 / iIii1I11I1II1 - OoOO + O0ooOooooO
   try :
    if 32 - 32: IIII . o0000oOoOoO0o % i1I111II1I + o00O0oo + OoOO
    OOOoOOo0o = IiIiII1
    if 50 - 50: II111iiii - Oooo0Ooo000 + iIii1I11I1II1 + iIii1I11I1II1
   except :
    pass
    if 91 - 91: II111iiii - O0 . iIii1I11I1II1 . O0 + o00O0oo - II111iiii
    if 26 - 26: o0000oOoOoO0o
  o0OOOo = ii1iiIiIII1ii ( OOOoOOo0o )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 12 - 12: OoooooooOO / O0 + II111iiii * o00O0oo
   except :
    pass
 except :
  pass
  if 46 - 46: II111iiii - i1I111II1I * OoooooooOO / oO0o0ooO0 % i1I111II1I
  if 11 - 11: iIii1I11I1II1 . OoOO0ooOOoo0O / i1I111II1I % iI
def o0O00Oooo ( ) :
 if 12 - 12: iI
 try :
  if 86 - 86: oO0o0ooO0 - OoOO
  o0OOOo = ii1iiIiIII1ii ( II11IiIi11 )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 63 - 63: OOooOOo / OoOO0ooOOoo0O + OoooooooOO . O0oO . iI
   try :
    if 48 - 48: i1IIi - O0ooOooooO - i11iIiiIii . O0oO - O0ooOooooO * O0oO
    OOOOO = IiIiII1
    if 68 - 68: O0oO + OoOO - O0 / OoOO * OoOO0ooOOoo0O
   except :
    pass
    if 50 - 50: IIII + II111iiii . OOooOOo / i1IIi / OOooOOo * oO0o0ooO0
    if 85 - 85: II111iiii . iI % IIII % O0oO
  o0OOOo = ii1iiIiIII1ii ( OOOOO )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 80 - 80: oO0o0ooO0 * O0oO / iIii1I11I1II1 % oO0o0ooO0 / iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 42 - 42: i1IIi / i11iIiiIii . ii11ii1ii * O0ooOooooO . i11iIiiIii * O0
  if 44 - 44: i1IIi . OOooOOo / i11iIiiIii + i1I111II1I
def iI111II1ii ( ) :
 if 62 - 62: O0ooOooooO * iIii1I11I1II1 . i1I111II1I - OoooooooOO * II111iiii
 try :
  if 45 - 45: O0 % OOooOOo - O0ooOooooO . OoOO
  o0OOOo = ii1iiIiIII1ii ( I1iiii1I )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 42 - 42: O0ooOooooO / o0000oOoOoO0o + ii11ii1ii . ii11ii1ii % IIII
   try :
    if 16 - 16: i1IIi + OoOO % OoOO0ooOOoo0O + o0oO0 * ii11ii1ii
    i1o0oo0 = IiIiII1
    if 67 - 67: O0 * O0oO - o0000oOoOoO0o - II111iiii
   except :
    pass
    if 41 - 41: OOooOOo - Oooo0Ooo000 % II111iiii . Oooo0Ooo000 - O0oO
    if 45 - 45: o0oO0 - IIII
  o0OOOo = ii1iiIiIII1ii ( i1o0oo0 )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 70 - 70: OoOO % OOooOOo / OOooOOo . O0oO % iI . II111iiii
   except :
    pass
 except :
  pass
  if 10 - 10: o0oO0 - i11iIiiIii . o00O0oo % i1IIi
  if 78 - 78: iIii1I11I1II1 * ii11ii1ii . ii11ii1ii - IIII . iIii1I11I1II1
def I111I1I ( ) :
 if 54 - 54: II111iiii + O0oO % O0oO % o0000oOoOoO0o
 try :
  if 25 - 25: O0ooOooooO - ii11ii1ii
  o0OOOo = ii1iiIiIII1ii ( oO00ooooO0o )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 10 - 10: O0 % i1I111II1I . OoOO + o0000oOoOoO0o + o00O0oo
   try :
    if 52 - 52: OoOO0ooOOoo0O / OoOO + Oooo0Ooo000
    Iii1i11iiI1 = IiIiII1
    if 95 - 95: oO0o0ooO0 * iIii1I11I1II1 + o00O0oo
   except :
    pass
    if 5 - 5: ii11ii1ii
    if 100 - 100: o0oO0 + iIii1I11I1II1
  o0OOOo = ii1iiIiIII1ii ( Iii1i11iiI1 )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 59 - 59: i1I111II1I
   except :
    pass
 except :
  pass
  if 89 - 89: OoOO0ooOOoo0O % iIii1I11I1II1
  if 35 - 35: o00O0oo + Oooo0Ooo000 - OoOO0ooOOoo0O % oO0o0ooO0 % o0000oOoOoO0o % OoOO0ooOOoo0O
def ii1IIiII111I ( ) :
 if 87 - 87: o0oO0 - o00O0oo % o00O0oo . oO0o0ooO0 / o00O0oo
 try :
  if 6 - 6: OoOO0ooOOoo0O / iIii1I11I1II1 * OoooooooOO * i11iIiiIii
  o0OOOo = ii1iiIiIII1ii ( o0oO0oooOoo )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 79 - 79: i1I111II1I % OoOO
   try :
    if 81 - 81: i11iIiiIii + i11iIiiIii * OoOO + i1I111II1I
    iiiiiI = IiIiII1
    if 17 - 17: i11iIiiIii / ii11ii1ii . OoOO / OOooOOo
   except :
    pass
    if 38 - 38: i1IIi . o00O0oo % o0oO0 + iIii1I11I1II1 + O0
  o0OOOo = ii1iiIiIII1ii ( iiiiiI )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 47 - 47: OoOO + i1I111II1I / II111iiii
   except :
    pass
 except :
  pass
  if 97 - 97: o00O0oo / OOooOOo % O0 + i1IIi - iI
  if 38 - 38: o0000oOoOoO0o % Oooo0Ooo000 + i11iIiiIii + O0ooOooooO + iI / i11iIiiIii
def o0OOOOOo0 ( ) :
 if 57 - 57: iIii1I11I1II1 + iIii1I11I1II1
 try :
  if 56 - 56: oO0o0ooO0 + iI
  o0OOOo = ii1iiIiIII1ii ( I1i111I )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 32 - 32: II111iiii + OoOO0ooOOoo0O % iI / OoOO0ooOOoo0O + o00O0oo
   try :
    if 2 - 2: i11iIiiIii - Oooo0Ooo000 + OoOO % O0oO * o0oO0
    Ooo000O00 = IiIiII1
    if 36 - 36: IIII % i11iIiiIii
   except :
    pass
    if 47 - 47: i1IIi + II111iiii . ii11ii1ii * oO0o0ooO0 . O0oO / i1IIi
    if 50 - 50: Oooo0Ooo000 / i1IIi % OoooooooOO
  o0OOOo = ii1iiIiIII1ii ( Ooo000O00 )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 83 - 83: o00O0oo * o00O0oo + IIII
   except :
    pass
 except :
  pass
  if 57 - 57: O0 - O0 . o00O0oo / o0000oOoOoO0o / o0oO0
def I1IiII1I1i1I1 ( ) :
 if 28 - 28: ii11ii1ii + i1I111II1I % II111iiii / OoOO + i11iIiiIii
 try :
  if 20 - 20: o00O0oo
  o0OOOo = ii1iiIiIII1ii ( I1i11 )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 3 - 3: OoOO * i1IIi . OOooOOo . O0 - OoOO0ooOOoo0O
   try :
    if 81 - 81: OOooOOo - iIii1I11I1II1 / OOooOOo / O0
    I1I1IIiiii1ii = IiIiII1
    if 92 - 92: oO0o0ooO0 / IIII . o00O0oo
   except :
    pass
  o0OOOo = ii1iiIiIII1ii ( I1I1IIiiii1ii )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 30 - 30: o0oO0 . o00O0oo / IIII
   except :
    pass
 except :
  pass
  if 2 - 2: i1I111II1I % OOooOOo - Oooo0Ooo000
def oooOo ( ) :
 if 79 - 79: oO0o0ooO0 - II111iiii
 try :
  if 43 - 43: i1IIi + O0 % OoOO / o0oO0 * OOooOOo
  o0OOOo = ii1iiIiIII1ii ( IiIIi1 )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 89 - 89: OOooOOo . ii11ii1ii + o00O0oo . O0 % o0000oOoOoO0o
   try :
    if 84 - 84: OoooooooOO + Oooo0Ooo000 / OOooOOo % IIII % o00O0oo * OOooOOo
    OOoO0oooo = IiIiII1
    if 24 - 24: O0oO / OOooOOo * i1IIi % OoooooooOO
   except :
    pass
  o0OOOo = ii1iiIiIII1ii ( OOoO0oooo )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 99 - 99: i11iIiiIii . II111iiii . OoooooooOO
   except :
    pass
 except :
  pass
  if 59 - 59: i11iIiiIii . OoooooooOO / O0oO * o00O0oo + OoooooooOO
def Ii1I1i1ii1I1 ( ) :
 if 98 - 98: i1I111II1I * iIii1I11I1II1 . o0oO0 * ii11ii1ii / o00O0oo + iI
 try :
  if 25 - 25: oO0o0ooO0
  o0OOOo = ii1iiIiIII1ii ( I11iiiiI1i )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 19 - 19: OOooOOo % o0oO0 . i1I111II1I * iI
   try :
    if 89 - 89: OoOO0ooOOoo0O . IIII
    IIIIIiI11Ii = IiIiII1
    if 41 - 41: i11iIiiIii - i1IIi / ii11ii1ii * i1I111II1I / Oooo0Ooo000 - ii11ii1ii
   except :
    pass
  o0OOOo = ii1iiIiIII1ii ( IIIIIiI11Ii )
  oO0o0oooO0oO = re . compile ( O000OOOOOo ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 , id , IIII1 , I1I1i , oo00 in oO0o0oooO0oO :
   try :
    iiIi1iI1iIii ( Ii111 , I111i1i1111 , oOoooooOoO , id , IIII1 , I1I1i , oo00 )
    if 56 - 56: O0
   except :
    pass
 except :
  pass
  if 45 - 45: OoOO0ooOOoo0O - OoOO - OoOO0ooOOoo0O
def IIiiI ( ) :
 if 36 - 36: O0ooOooooO
 try :
  if 52 - 52: Oooo0Ooo000 % O0 . i1IIi . OoooooooOO
  o0OOOo = ii1iiIiIII1ii ( II1i11I )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for IiIiII1 in oO0o0oooO0oO :
   if 33 - 33: IIII % II111iiii
   try :
    if 71 - 71: o0oO0 * Oooo0Ooo000 % II111iiii . o0oO0 % OoOO + o00O0oo
    o0oOo0OO = IiIiII1
    if 79 - 79: OoOO0ooOOoo0O % OOooOOo % o0oO0 / i1IIi % OoOO
   except :
    pass
  o0OOOo = ii1iiIiIII1ii ( o0oOo0OO )
  oO0o0oooO0oO = re . compile ( o0o0o0oO0oOO ) . findall ( o0OOOo )
  for oOoooooOoO , Ii111 , I111i1i1111 in oO0o0oooO0oO :
   try :
    oo0o00OO ( oOoooooOoO , Ii111 , I111i1i1111 )
    if 69 - 69: o0000oOoOoO0o % i11iIiiIii / o0oO0
   except :
    pass
    if 93 - 93: iI
 except :
  pass
  if 34 - 34: oO0o0ooO0 - iI * ii11ii1ii / o0000oOoOoO0o
  if 19 - 19: o00O0oo
  if 46 - 46: iIii1I11I1II1 . i11iIiiIii - OoOO0ooOOoo0O % O0 / II111iiii * i1IIi
def oo0o00OO ( thumb , name , url ) :
 if 66 - 66: O0
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 if 52 - 52: OoOO * OoooooooOO
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( i1Iii1i1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   IIi ( name , url , '' , o00 , oo00 )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 12 - 12: O0 + i1I111II1I * i1IIi . OoOO
  if 'tvg-logo' in thumb :
   thumb = re . compile ( i1Iii1i1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 71 - 71: Oooo0Ooo000 - o0000oOoOoO0o - IIII
   iiIO0OO0o0O00oO ( name , url , 4 , OOo00O , oo00 )
   if 81 - 81: i1I111II1I / O0oO
  else :
   if 46 - 46: o00O0oo / Oooo0Ooo000 + i1I111II1I / oO0o0ooO0 / Oooo0Ooo000 / IIII
   iiIO0OO0o0O00oO ( name , url , 4 , OOo00O , oo00 )
   if 73 - 73: iI + o00O0oo
def o0o ( name , url , thumb , id , trailer ) :
 if 46 - 46: OoOO0ooOOoo0O - O0
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 70 - 70: O0oO + ii11ii1ii * iIii1I11I1II1 . OOooOOo * O0oO
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( i1Iii1i1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   IIi ( name , url , '' , o00 , oo00 )
 else :
  oOOo0 = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
  if 49 - 49: o0000oOoOoO0o
  name = '[COLOR %s]' % oOOo0 + name + '[/COLOR]'
  if 25 - 25: O0ooOooooO . OoooooooOO * iIii1I11I1II1 . o0000oOoOoO0o / O0 + o0oO0
  if 'tvg-logo' in thumb :
   thumb = re . compile ( i1Iii1i1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'selecton' )
   if IIIi1I1IIii1II == 'true' :
    if 68 - 68: ii11ii1ii
    ii111I11Ii ( name , url , 1 , thumb , thumb , id , trailer )
    if 6 - 6: o0oO0
   else :
    if 77 - 77: i1IIi + OoOO . OOooOOo * IIII / i1I111II1I / o0oO0
    ii111I11Ii ( name , url , 130 , thumb , thumb , id , trailer )
    if 84 - 84: OoOO / iIii1I11I1II1
  else :
   if 33 - 33: i1IIi / Oooo0Ooo000 - i1IIi . ii11ii1ii
   if IIIi1I1IIii1II == 'true' :
    if 18 - 18: ii11ii1ii / O0 + O0ooOooooO
    ii111I11Ii ( name , url , 1 , thumb , thumb , id , trailer )
    if 65 - 65: i1IIi . o00O0oo / iI
   else :
    if 11 - 11: i1I111II1I * iI / iI - IIII
    ii111I11Ii ( name , url , 130 , thumb , thumb , id , trailer )
    if 68 - 68: OOooOOo % i1I111II1I - i1I111II1I / OOooOOo + o00O0oo - ii11ii1ii
    if 65 - 65: iI - i1IIi
def iiIi1iI1iIii ( name , url , thumb , id , trailer , description , fanart ) :
 if 62 - 62: O0oO / oO0o0ooO0 % ii11ii1ii . OoooooooOO / i11iIiiIii / Oooo0Ooo000
 if 60 - 60: OOooOOo % oO0o0ooO0 / o0000oOoOoO0o % oO0o0ooO0 * i11iIiiIii / O0ooOooooO
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 oOOo0 = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
 fanart = fanart . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 name = '[COLOR %s]' % oOOo0 + name + '[/COLOR]'
 if 34 - 34: Oooo0Ooo000 - IIII
 if 'tvg-logo' in thumb :
  thumb = re . compile ( i1Iii1i1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'selecton' )
  if IIIi1I1IIii1II == 'true' :
   if 25 - 25: oO0o0ooO0 % OOooOOo + i11iIiiIii + O0 * OoooooooOO
   ooO0 ( name , url , 1 , thumb , fanart , id , trailer , description )
   if 94 - 94: O0oO . OOooOOo
  else :
   if 73 - 73: i1IIi / II111iiii
   ooO0 ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 45 - 45: o0oO0 / iI . OoooooooOO + OoOO
 else :
  if 51 - 51: O0ooOooooO % i11iIiiIii % i1I111II1I + Oooo0Ooo000 % o00O0oo
  if IIIi1I1IIii1II == 'true' :
   if 16 - 16: OoOO0ooOOoo0O / ii11ii1ii + O0 - OoOO0ooOOoo0O . OoooooooOO
   ooO0 ( name , url , 1 , thumb , fanart , id , trailer , description )
   if 19 - 19: o0000oOoOoO0o
  else :
   if 73 - 73: Oooo0Ooo000 * ii11ii1ii * OoOO0ooOOoo0O
   ooO0 ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 65 - 65: i11iIiiIii + ii11ii1ii * OoooooooOO - OoOO
   if 26 - 26: o0000oOoOoO0o % IIII + IIII % O0oO * i11iIiiIii / O0ooOooooO
   if 64 - 64: oO0o0ooO0 % OoOO0ooOOoo0O / II111iiii % iI - O0ooOooooO
def I1II1IiI1 ( name , trailer ) :
 if 26 - 26: IIII * ii11ii1ii
 if i1Oo00 == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Realstream, Reproduciendo Trailer de: [COLOR green]" + name + "[/COLOR] ,5000)" )
  if 31 - 31: O0oO * oO0o0ooO0 . o0oO0
  I111i1i1111 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  i1Ii11ii1I = I111i1i1111
  OO0oI1iii1i = xbmcgui . ListItem ( name , trailer , path = i1Ii11ii1I )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , OO0oI1iii1i )
 else :
  I111i1i1111 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  i1Ii11ii1I = I111i1i1111
  OO0oI1iii1i = xbmcgui . ListItem ( name , trailer , path = i1Ii11ii1I )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , OO0oI1iii1i )
  if 91 - 91: oO0o0ooO0 - OoooooooOO * II111iiii
  if 38 - 38: o00O0oo + OoOO0ooOOoo0O
def o0IiIiI111IIII1 ( name , url ) :
 if 100 - 100: IIII * O0 + OOooOOo + OoOO0ooOOoo0O . IIII
 if i1Oo00 == 'true' :
  if 73 - 73: oO0o0ooO0 . II111iiii * O0ooOooooO % oO0o0ooO0 + OoOO0ooOOoo0O - OoOO
  try :
   if 19 - 19: O0ooOooooO * ii11ii1ii . O0ooOooooO . OoOO / OoOO - oO0o0ooO0
   iI1I = xbmcgui . DialogProgress ( )
   iI1I . create ( 'Realstream:' , 'Iniciando ...' )
   iI1I . update ( 30 , 'Realstream:' , 'Conectando al servidor ...' )
   xbmc . sleep ( 1000 )
   iI1I . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   iI1I . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   iI1I . close ( )
   if 9 - 9: Oooo0Ooo000 * i1I111II1I * Oooo0Ooo000
   i1Ii11ii1I = url
   OO0oI1iii1i = xbmcgui . ListItem ( name , IIII1 , path = i1Ii11ii1I )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , OO0oI1iii1i )
   if 74 - 74: iIii1I11I1II1 / o0000oOoOoO0o
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. ,3000)" )
  if 58 - 58: iIii1I11I1II1 - OOooOOo % o0000oOoOoO0o % OoooooooOO * iIii1I11I1II1 + IIII
 else :
  if 25 - 25: IIII % O0
  try :
   if 44 - 44: Oooo0Ooo000 . o0oO0 * II111iiii / i1I111II1I + iIii1I11I1II1
   iI1I = xbmcgui . DialogProgress ( )
   iI1I . create ( 'Realstream:' , 'Iniciando ...' )
   iI1I . update ( 30 , 'Realstream:' , 'Conectando al servidor ...' )
   xbmc . sleep ( 1000 )
   iI1I . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   iI1I . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   iI1I . close ( )
   if 14 - 14: O0 % i1I111II1I % o0oO0 * oO0o0ooO0
   i1Ii11ii1I = url
   OO0oI1iii1i = xbmcgui . ListItem ( name , IIII1 , path = i1Ii11ii1I )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , OO0oI1iii1i )
   if 65 - 65: O0oO % oO0o0ooO0 + o00O0oo
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. ,3000)" )
  if 86 - 86: iIii1I11I1II1 / O0 . Oooo0Ooo000 % iIii1I11I1II1 % ii11ii1ii
 return
 if 86 - 86: i11iIiiIii - o0000oOoOoO0o . iI * ii11ii1ii / o0oO0 % o0000oOoOoO0o
 if 61 - 61: o0000oOoOoO0o + OoOO0ooOOoo0O
def IIIIiI11Ii1i ( trailer ) :
 if 100 - 100: O0ooOooooO + O0oO + iI + O0ooOooooO / i1IIi
 if 'https://www.youtube.com' in trailer :
  if 74 - 74: O0 % OoooooooOO * ii11ii1ii + IIII * O0ooOooooO
  try :
   if 100 - 100: IIII + o0oO0 * o0000oOoOoO0o + II111iiii
   import resolveurl
   if 70 - 70: ii11ii1ii * iIii1I11I1II1
   ii1iI1II11ii = urlresolver . HostedMediaFile ( I111i1i1111 )
   iI1I = xbmcgui . DialogProgress ( )
   iI1I . create ( 'Realstream:' , 'Conectando al servidor ... ' )
   iI1I . update ( 20 , 'Por favor, espere ...' )
   xbmc . sleep ( 500 )
   if 76 - 76: O0ooOooooO % OoOO0ooOOoo0O % iIii1I11I1II1 . IIII
   if not ii1iI1II11ii :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    return False
    if 30 - 30: i1IIi
   try :
    if 75 - 75: O0oO . IIII - iIii1I11I1II1 * OoOO * O0ooOooooO
    iI1I . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    III1ii = ii1iI1II11ii . resolve ( )
    if not III1ii or not isinstance ( III1ii , basestring ) :
     try : i1I = III1ii . msg
     except : i1I = III1ii
     raise Exception ( i1I )
   except Exception as o0O0Oo00 :
    try : i1I = str ( o0O0Oo00 )
    except : i1I = III1ii
    iI1I . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
    iI1I . close ( )
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    if 93 - 93: iI
   iI1I . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
   xbmc . sleep ( 500 )
   iI1I . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   iI1I . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
   xbmc . sleep ( 500 )
   iI1I . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   iI1I . close ( )
   if 18 - 18: iI
   oOO00OO0ooo0o = xbmcgui . ListItem ( path = III1ii )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO00OO0ooo0o )
   if 66 - 66: oO0o0ooO0 * i11iIiiIii + OoOO0ooOOoo0O / IIII
  except :
   pass
   if 96 - 96: IIII + IIII % i1I111II1I % IIII
  else :
   if 28 - 28: iIii1I11I1II1 + OoOO0ooOOoo0O . o0000oOoOoO0o % i11iIiiIii
   I111i1i1111 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
   i1Ii11ii1I = I111i1i1111
   OO0oI1iii1i = xbmcgui . ListItem ( trailer , path = i1Ii11ii1I )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , OO0oI1iii1i )
   return
   if 58 - 58: O0oO / OoooooooOO % oO0o0ooO0 + OoOO
def o0ooOO0OOO00o ( name , url ) :
 if 76 - 76: OoooooooOO * OoooooooOO - O0ooOooooO - iIii1I11I1II1 . OoooooooOO / o00O0oo
 if '[Youtube]' in name :
  if 86 - 86: iI
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  i1Ii11ii1I = url
  OO0oI1iii1i = xbmcgui . ListItem ( IIII1 , path = i1Ii11ii1I )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , OO0oI1iii1i )
  if 51 - 51: OoOO - i11iIiiIii * OOooOOo
  if 95 - 95: IIII % o00O0oo + o0000oOoOoO0o % iI
 else :
  if 36 - 36: O0 / i1IIi % II111iiii / O0ooOooooO
  import urlresolver
  from urlresolver import common
  if 96 - 96: ii11ii1ii / oO0o0ooO0 . II111iiii . ii11ii1ii
  ii1iI1II11ii = urlresolver . HostedMediaFile ( url )
  if 91 - 91: II111iiii . IIII + o0000oOoOoO0o
  if not ii1iI1II11ii :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 8 - 8: IIII * ii11ii1ii / O0ooOooooO - OoOO - OoooooooOO
   if 100 - 100: oO0o0ooO0 . iIii1I11I1II1 . iIii1I11I1II1
  try :
   III1ii = ii1iI1II11ii . resolve ( )
   if not III1ii or not isinstance ( III1ii , basestring ) :
    try : i1I = III1ii . msg
    except : i1I = url
    raise Exception ( i1I )
  except Exception as o0O0Oo00 :
   try : i1I = str ( o0O0Oo00 )
   except : i1I = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 55 - 55: oO0o0ooO0
  i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if i1Oo00 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  oOO00OO0ooo0o = xbmcgui . ListItem ( path = III1ii )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO00OO0ooo0o )
  if 37 - 37: i1I111II1I / i11iIiiIii / ii11ii1ii
  if 97 - 97: Oooo0Ooo000 . O0oO / OOooOOo
 return
 if 83 - 83: O0oO - o00O0oo * oO0o0ooO0
def oOO00OO0OooOo ( name , url ) :
 if 13 - 13: O0 % iI % O0oO
 import resolveurl
 if 25 - 25: OoooooooOO % o0oO0 * II111iiii - OoOO
 ii1iI1II11ii = urlresolver . HostedMediaFile ( url )
 dp = xbmcgui . DialogProgress ( )
 dp . create ( 'Realstream:' , 'Conectando al servidor ... ' )
 dp . update ( 20 , 'Por favor, espere ...' )
 xbmc . sleep ( 500 )
 if 95 - 95: OOooOOo % Oooo0Ooo000 * OOooOOo + O0 . Oooo0Ooo000 % OoooooooOO
 if not ii1iI1II11ii :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  return False
  if 6 - 6: OoOO0ooOOoo0O - iI * o0000oOoOoO0o + OoOO0ooOOoo0O % o0000oOoOoO0o
 try :
  if 100 - 100: OoOO % Oooo0Ooo000 - O0oO % O0oO % O0oO / iI
  dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
  xbmc . sleep ( 500 )
  III1ii = ii1iI1II11ii . resolve ( )
  if not III1ii or not isinstance ( III1ii , basestring ) :
   try : i1I = III1ii . msg
   except : i1I = III1ii
   raise Exception ( i1I )
 except Exception as o0O0Oo00 :
  try : i1I = str ( o0O0Oo00 )
  except : i1I = III1ii
  dp . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
  dp . close ( )
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  if 83 - 83: oO0o0ooO0 - iI - i1I111II1I % i1IIi - O0ooOooooO . o0000oOoOoO0o
 dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
 xbmc . sleep ( 500 )
 dp . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
 xbmc . sleep ( 500 )
 dp . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
 xbmc . sleep ( 500 )
 dp . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
 dp . close ( )
 i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
 if 96 - 96: ii11ii1ii + Oooo0Ooo000 . i1IIi
 if 54 - 54: II111iiii . i1IIi / o00O0oo % OOooOOo / Oooo0Ooo000
 if '[Realstream]' or '[Mybox]' in name :
  restante = IiII1IiiIiI1 . getSetting ( 'restante' )
 elif restante == 'true' :
  dialog = xbmcgui . Dialog ( )
  ok = dialog . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
 oOO00OO0ooo0o = xbmcgui . ListItem ( path = III1ii )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO00OO0ooo0o )
 if 65 - 65: OoOO0ooOOoo0O . OoOO0ooOOoo0O - oO0o0ooO0 + ii11ii1ii / i11iIiiIii
def oOO00OO0OooOo ( name , url ) :
 if 90 - 90: iIii1I11I1II1 + OoOO0ooOOoo0O
 if 9 - 9: iIii1I11I1II1 . OoooooooOO + i1IIi - ii11ii1ii
 if 'https://www.rapidvideo.com/v/' in url :
  if 30 - 30: O0ooOooooO / OoOO . O0ooOooooO
  o0OOOo = ii1iiIiIII1ii ( url )
  oO0o0oooO0oO = re . compile ( 'rapidvideo' ) . findall ( o0OOOo )
  for url in oO0o0oooO0oO :
   if 17 - 17: ii11ii1ii + OoooooooOO * OoooooooOO
   if 5 - 5: Oooo0Ooo000 % OoooooooOO . OoOO0ooOOoo0O
   try :
    i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
    if i1Oo00 == 'true' :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oOO00OO0ooo0o = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO00OO0ooo0o )
    if 67 - 67: o00O0oo + o0oO0
   except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 72 - 72: i1I111II1I % o0000oOoOoO0o
   if 93 - 93: iIii1I11I1II1 + i11iIiiIii . o0000oOoOoO0o . i1IIi % OOooOOo % iI
 else :
  if 74 - 74: OoOO0ooOOoo0O / i1IIi % OoooooooOO
  import urlresolver
  from urlresolver import common
  if 52 - 52: i1I111II1I % iI
  ii1iI1II11ii = urlresolver . HostedMediaFile ( url )
  if 25 - 25: O0oO / O0oO % OoooooooOO - o00O0oo * oO0o0ooO0
  if not ii1iI1II11ii :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 23 - 23: i11iIiiIii
   if 100 - 100: oO0o0ooO0 + O0 . OOooOOo + i1IIi - OoOO0ooOOoo0O + o0000oOoOoO0o
  try :
   III1ii = ii1iI1II11ii . resolve ( )
   if not III1ii or not isinstance ( III1ii , basestring ) :
    try : i1I = III1ii . msg
    except : i1I = url
    raise Exception ( i1I )
  except Exception as o0O0Oo00 :
   try : i1I = str ( o0O0Oo00 )
   except : i1I = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 65 - 65: II111iiii / ii11ii1ii
  i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if i1Oo00 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  oOO00OO0ooo0o = xbmcgui . ListItem ( path = III1ii )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO00OO0ooo0o )
  if 42 - 42: i11iIiiIii . O0
 return
 if 75 - 75: Oooo0Ooo000 + iIii1I11I1II1
 if 19 - 19: OOooOOo + i11iIiiIii . i1I111II1I - O0oO / o0oO0 + o0000oOoOoO0o
 if 38 - 38: ii11ii1ii / iIii1I11I1II1 * iIii1I11I1II1 % o00O0oo
def O00o ( name , url ) :
 if 55 - 55: iI % O0oO / i11iIiiIii
 III1ii = url
 i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
 if i1Oo00 == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  oOO00OO0ooo0o = xbmcgui . ListItem ( path = III1ii )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO00OO0ooo0o )
 else :
  oOO00OO0ooo0o = xbmcgui . ListItem ( path = III1ii )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO00OO0ooo0o )
 return
 if 20 - 20: i1I111II1I / Oooo0Ooo000 * i1I111II1I * OoOO
def OOOOoO ( name , url ) :
 if 80 - 80: ii11ii1ii % i1I111II1I % OoooooooOO * ii11ii1ii % o0oO0
 if 41 - 41: OoooooooOO / i1IIi
 if '[Youtube]' in name :
  if 70 - 70: OoOO0ooOOoo0O % o0000oOoOoO0o % i1IIi / o00O0oo % i11iIiiIii / i1IIi
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 4 - 4: i1I111II1I
  try :
   i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if i1Oo00 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oOO00OO0ooo0o = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO00OO0ooo0o )
    if 93 - 93: oO0o0ooO0 % i1IIi
    if 83 - 83: OOooOOo . ii11ii1ii - O0oO . o0000oOoOoO0o
    if 73 - 73: OOooOOo - O0ooOooooO . O0ooOooooO
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 22 - 22: iI / iI - o0oO0 % O0oO . IIII + i1I111II1I
  if 64 - 64: i1IIi % o00O0oo / o0oO0 % OoooooooOO
 else :
  if 24 - 24: Oooo0Ooo000 + OoooooooOO . i1I111II1I / OoOO0ooOOoo0O / O0oO
  import xbmcgui
  import urlresolver
  from urlresolver import common
  if 65 - 65: OoooooooOO
  ii1iI1II11ii = urlresolver . HostedMediaFile ( url )
  if 18 - 18: O0 - i1IIi . Oooo0Ooo000
  if not ii1iI1II11ii :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 98 - 98: o0000oOoOoO0o
  import resolveurl as urlresolver
  if 73 - 73: ii11ii1ii - O0ooOooooO . oO0o0ooO0 % i1IIi . O0
  ii1iI1II11ii = urlresolver . HostedMediaFile ( url )
  if 15 - 15: iI . iIii1I11I1II1 * OOooOOo % O0oO
  if 21 - 21: OoOO - OOooOOo . OoooooooOO
  if not ii1iI1II11ii :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 6 - 6: iIii1I11I1II1 - iIii1I11I1II1 % o0000oOoOoO0o / iIii1I11I1II1 * Oooo0Ooo000
  try :
   III1ii = ii1iI1II11ii . resolve ( )
   if not III1ii or not isinstance ( III1ii , basestring ) :
    try : i1I = III1ii . msg
    except : i1I = url
    raise Exception ( i1I )
  except Exception as o0O0Oo00 :
   try : i1I = str ( o0O0Oo00 )
   except : i1I = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 3 - 3: IIII . i1I111II1I / ii11ii1ii
   if 89 - 89: OoooooooOO . iIii1I11I1II1 . ii11ii1ii * iIii1I11I1II1 - Oooo0Ooo000
   if 92 - 92: OoooooooOO - o00O0oo - OoooooooOO % OOooOOo % OOooOOo % iIii1I11I1II1
  i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if i1Oo00 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 92 - 92: O0ooOooooO * O0 % Oooo0Ooo000 . iIii1I11I1II1
   if '[Realstream]' in name :
    if 66 - 66: O0oO + o0oO0
    iiI111I1iIiI = IiII1IiiIiI1 . getSetting ( 'restante' )
    if iiI111I1iIiI == 'true' :
     i1ii1iIi = xbmcgui . Dialog ( )
     IiiiIi1iI1iI = i1ii1iIi . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 43 - 43: o0oO0 + O0ooOooooO + i1IIi - OoOO0ooOOoo0O + o0000oOoOoO0o
   oOO00OO0ooo0o = xbmcgui . ListItem ( path = III1ii )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO00OO0ooo0o )
   if 54 - 54: o00O0oo + o00O0oo + O0oO % i1IIi % i11iIiiIii
   if 100 - 100: o00O0oo
   if 96 - 96: OOooOOo . i1I111II1I * II111iiii % i1I111II1I . Oooo0Ooo000 * i1IIi
 return
 if 83 - 83: iIii1I11I1II1
 if 97 - 97: i11iIiiIii + ii11ii1ii * IIII % O0ooOooooO . i1I111II1I
 if 4 - 4: O0 . O0ooOooooO - iIii1I11I1II1
def I1iII11ii1 ( name , url ) :
 if 4 - 4: i11iIiiIii - IIII % o00O0oo * Oooo0Ooo000 % o0000oOoOoO0o
 if 71 - 71: iI . iI - iIii1I11I1II1
 if '[Youtube]' in name :
  if 22 - 22: OoooooooOO / o00O0oo % O0ooOooooO * OoOO0ooOOoo0O
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 32 - 32: OoooooooOO % oO0o0ooO0 % iIii1I11I1II1 / O0
  try :
   i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if i1Oo00 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oOO00OO0ooo0o = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO00OO0ooo0o )
    if 61 - 61: II111iiii . O0 - o0oO0 - o00O0oo / i11iIiiIii - II111iiii
    if 98 - 98: o0oO0 - OOooOOo . i11iIiiIii * ii11ii1ii
    if 29 - 29: o0oO0 / iI % O0oO
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 10 - 10: iIii1I11I1II1 % OoooooooOO % o00O0oo
 else :
  if 39 - 39: II111iiii * OoOO0ooOOoo0O . O0 * O0oO
  import resolveurl
  if 89 - 89: o0oO0 - iI . O0oO - Oooo0Ooo000 - OOooOOo
  ii1iI1II11ii = urlresolver . HostedMediaFile ( url )
  if 79 - 79: i1I111II1I + i1I111II1I + o0oO0
  if 39 - 39: O0 - OoooooooOO
  if not ii1iI1II11ii :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 63 - 63: iIii1I11I1II1 % o0000oOoOoO0o * iI
  try :
   III1ii = ii1iI1II11ii . resolve ( )
   if not III1ii or not isinstance ( III1ii , basestring ) :
    try : i1I = III1ii . msg
    except : i1I = url
    raise Exception ( i1I )
  except Exception as o0O0Oo00 :
   try : i1I = str ( o0O0Oo00 )
   except : i1I = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 79 - 79: O0
   if 32 - 32: II111iiii . O0 + o0oO0 / OoOO0ooOOoo0O / i1I111II1I / IIII
   if 15 - 15: o00O0oo
  i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if i1Oo00 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 4 - 4: i1I111II1I + iIii1I11I1II1 * O0ooOooooO + ii11ii1ii * o0000oOoOoO0o % II111iiii
   if 'uptostream.com' or 'uptobox.com' in url :
    if 88 - 88: oO0o0ooO0 - i1IIi % i11iIiiIii % II111iiii * OoooooooOO
    iiI111I1iIiI = IiII1IiiIiI1 . getSetting ( 'restante' )
    if iiI111I1iIiI == 'true' :
     i1ii1iIi = xbmcgui . Dialog ( )
     IiiiIi1iI1iI = i1ii1iIi . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 40 - 40: ii11ii1ii
   oOO00OO0ooo0o = xbmcgui . ListItem ( path = III1ii )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO00OO0ooo0o )
   if 47 - 47: OoOO0ooOOoo0O
   if 65 - 65: O0 + Oooo0Ooo000 % o0oO0 * OOooOOo / iI / OoOO0ooOOoo0O
   if 71 - 71: i11iIiiIii / OoOO0ooOOoo0O . oO0o0ooO0
 return
 if 33 - 33: oO0o0ooO0
def IIIi11 ( name , url ) :
 if 69 - 69: O0 - O0
 if 41 - 41: i1I111II1I % o0000oOoOoO0o
 if '[Youtube]' in name :
  if 67 - 67: O0 % Oooo0Ooo000
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 35 - 35: OOooOOo . OoOO0ooOOoo0O + OoooooooOO % ii11ii1ii % IIII
  try :
   i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if i1Oo00 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oOO00OO0ooo0o = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO00OO0ooo0o )
    if 39 - 39: o0oO0
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 60 - 60: IIII
 else :
  if 62 - 62: Oooo0Ooo000 * O0oO
  if 'https://team.com' in url :
   if 74 - 74: OoOO0ooOOoo0O . iIii1I11I1II1
   url = url . replace ( 'https://team.com' , 'https://verystream.com' )
   if 87 - 87: iI
   if 41 - 41: OoOO0ooOOoo0O . iIii1I11I1II1 % iI + O0
  if 'https://drive.com' in url :
   if 22 - 22: o0000oOoOoO0o + ii11ii1ii . iI + o00O0oo * O0ooOooooO . i11iIiiIii
   url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
   if 90 - 90: IIII * OoOO0ooOOoo0O - ii11ii1ii + o0000oOoOoO0o
  if 'https://vid.co' in url :
   if 53 - 53: OoooooooOO . OoooooooOO + o0000oOoOoO0o - O0ooOooooO + IIII
   url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
   if 44 - 44: Oooo0Ooo000 - i1I111II1I
  if 'https://limited.to' in url :
   if 100 - 100: oO0o0ooO0 . OoOO - o0oO0 + O0 * OoOO
   url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
   if 59 - 59: II111iiii
  import resolveurl
  if 43 - 43: ii11ii1ii + OoooooooOO
  ii1iI1II11ii = urlresolver . HostedMediaFile ( url )
  if 47 - 47: iI
  if 92 - 92: O0oO % i11iIiiIii % ii11ii1ii
  if not ii1iI1II11ii :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no encontrado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 23 - 23: II111iiii * O0ooOooooO
  try :
   III1ii = ii1iI1II11ii . resolve ( )
   if not III1ii or not isinstance ( III1ii , basestring ) :
    try : i1I = III1ii . msg
    except : i1I = url
    raise Exception ( i1I )
  except Exception as o0O0Oo00 :
   try : i1I = str ( o0O0Oo00 )
   except : i1I = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace borrado, o no encontrado. Prueba a reiniciar el router o poner una VPN.[/COLOR]  ,5000)" )
   return False
   if 80 - 80: Oooo0Ooo000 / i11iIiiIii + OoooooooOO
   if 38 - 38: o00O0oo % iI + i1IIi * OoooooooOO * oO0o0ooO0
   if 83 - 83: iIii1I11I1II1 - iI - Oooo0Ooo000 / OoOO - O0
   i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if i1Oo00 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
    if 81 - 81: o0oO0 - oO0o0ooO0 * o00O0oo / Oooo0Ooo000
    if 'uptostream.com' or 'uptobox.com' in url :
     iiI111I1iIiI = IiII1IiiIiI1 . getSetting ( 'restante' )
    elif iiI111I1iIiI == 'true' :
     i1ii1iIi = xbmcgui . Dialog ( )
     IiiiIi1iI1iI = i1ii1iIi . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 21 - 21: OoOO
  oOO00OO0ooo0o = xbmcgui . ListItem ( path = III1ii )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO00OO0ooo0o )
  if 63 - 63: O0oO . O0 * O0oO + iIii1I11I1II1
 return
 if 46 - 46: i1IIi + II111iiii * i1IIi - o0oO0
 if 79 - 79: II111iiii - oO0o0ooO0 * o00O0oo - OoOO0ooOOoo0O . o00O0oo
def iiII1IIii1i1 ( name , url ) :
 if 38 - 38: O0ooOooooO * OoooooooOO
 if 'mybox.com' in url :
  if 2 - 2: oO0o0ooO0 - i11iIiiIii
  url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
  if 98 - 98: oO0o0ooO0 + OoooooooOO - Oooo0Ooo000 % i11iIiiIii / o0000oOoOoO0o . OoooooooOO
  try :
   if 87 - 87: i1IIi
   o0OOOo = ii1iiIiIII1ii ( url )
   oO0o0oooO0oO = re . compile ( oO0 ) . findall ( o0OOOo )
   for url , i1iI1IIi1I , oo00i1i11I1I1 in oO0o0oooO0oO :
    if 82 - 82: OoOO - ii11ii1ii - O0 - OoooooooOO
    i1iI1IIi1I = i1iI1IIi1I . replace ( '","res":"1080",' , '' ) . replace ( '","res":"720",' , '' ) . replace ( '","res":"480",' , '' ) . replace ( '","res":"360",' , '' )
    url = url . replace ( '\/' , '/' )
    url = url . replace ( ',"type":"video/mp4",' , ' ' )
    name = '[COLOR white]' + i1iI1IIi1I + '[/COLOR] - [COLOR gold]' + oo00i1i11I1I1 + '[/COLOR]'
    if 4 - 4: II111iiii - oO0o0ooO0 % ii11ii1ii * i11iIiiIii
    iIiII1iiiiI = [ ]
    iIiII1iiiiI . append ( '[COLOR orange]Real Stream: [/COLOR][COLOR gold]1. Mostrar mas info. [Reiniciar][/COLOR]' )
    iIiII1iiiiI . append ( '[COLOR gold]2. Mostar otras calidades disponibles [/COLOR]' )
    iIiII1iiiiI . append ( '[COLOR gold]3. Ver en: %s [/COLOR]' % name )
    if 80 - 80: ii11ii1ii - o0000oOoOoO0o - II111iiii . i1I111II1I - O0 * i1I111II1I
    if 43 - 43: OOooOOo / O0ooOooooO / iI + iIii1I11I1II1 + OoooooooOO
    iiI111i1 = 'Seleccione una calidad e idioma:'
    i1ii1iIi = xbmcgui . Dialog ( )
    IiIii11i1IIiI = i1ii1iIi . select ( iiI111i1 , iIiII1iiiiI )
    if 40 - 40: O0ooOooooO + iIii1I11I1II1 * oO0o0ooO0 + i11iIiiIii . i11iIiiIii
    if 11 - 11: OoOO % OoooooooOO
    if 20 - 20: Oooo0Ooo000 + Oooo0Ooo000 * II111iiii * iIii1I11I1II1 % O0 * OOooOOo
    if IiIii11i1IIiI == 0 :
     if 62 - 62: OoooooooOO / OoOO0ooOOoo0O . i1I111II1I . i1I111II1I % iI
     IiiiIi1iI1iI = i1ii1iIi . ok ( "[COLOR darkpink]REALSTREAM:[/COLOR] " , "[COLOR gold]  Reiniciadas las opciones.  [/COLOR]" , "" )
     del i1ii1iIi
     return
     if 42 - 42: o0000oOoOoO0o . IIII - iI
    elif IiIii11i1IIiI == 1 :
     if 33 - 33: II111iiii / O0 / i1I111II1I - O0oO - i1IIi
     pass
     if 8 - 8: i11iIiiIii . O0ooOooooO / iIii1I11I1II1 / o00O0oo / i1I111II1I - o0oO0
     del i1ii1iIi
     if 32 - 32: o0000oOoOoO0o . i1IIi * ii11ii1ii
     if 98 - 98: o0oO0 - II111iiii / OOooOOo . oO0o0ooO0 * i1I111II1I . O0oO
    elif IiIii11i1IIiI == 2 :
     if 25 - 25: i11iIiiIii / OoOO0ooOOoo0O - Oooo0Ooo000 / OoOO . o0000oOoOoO0o . o0000oOoOoO0o
     o0IiIiI111IIII1 ( name , url )
     if 6 - 6: oO0o0ooO0 . O0oO
     return
     if 43 - 43: o00O0oo + o0000oOoOoO0o
  except :
   pass
   if 50 - 50: oO0o0ooO0 % i1IIi * O0
 elif 'uptostream.com' in url :
  if 4 - 4: iIii1I11I1II1 . i1IIi
  try :
   if 63 - 63: iIii1I11I1II1 + i1I111II1I % i1IIi / OOooOOo % II111iiii
   o0OOOo = ii1iiIiIII1ii ( url )
   oO0o0oooO0oO = re . compile ( oO0 ) . findall ( o0OOOo )
   for url , i1iI1IIi1I , oo00i1i11I1I1 in oO0o0oooO0oO :
    if 60 - 60: o0000oOoOoO0o . OoOO0ooOOoo0O % Oooo0Ooo000 / OOooOOo / O0
    i1iI1IIi1I = i1iI1IIi1I . replace ( '","res":"1080",' , '' ) . replace ( '","res":"720",' , '' ) . replace ( '","res":"480",' , '' ) . replace ( '","res":"360",' , '' )
    url = url . replace ( '\/' , '/' )
    url = url . replace ( ',"type":"video/mp4",' , ' ' )
    name = '[COLOR white]Calidad: ' + i1iI1IIi1I + '[/COLOR] [COLOR gold]Idioma: ' + oo00i1i11I1I1 + '[/COLOR]'
    if 19 - 19: i11iIiiIii . OOooOOo + II111iiii / IIII . o00O0oo * iI
    iIiII1iiiiI = [ ]
    iIiII1iiiiI . append ( '[COLOR orange]Real Stream: [/COLOR][COLOR gold]1. Mostrar mas info. [Reiniciar][/COLOR]' )
    iIiII1iiiiI . append ( '[COLOR gold]2. Mostar otras calidades disponibles [/COLOR]' )
    iIiII1iiiiI . append ( '[COLOR gold]3. Ver en: %s [/COLOR]' % name )
    if 59 - 59: iIii1I11I1II1 / o00O0oo % iI
    if 84 - 84: iIii1I11I1II1 / OOooOOo . OoOO0ooOOoo0O % O0oO
    iiI111i1 = 'Seleccione una calidad e idioma:'
    i1ii1iIi = xbmcgui . Dialog ( )
    IiIii11i1IIiI = i1ii1iIi . select ( iiI111i1 , iIiII1iiiiI )
    if 99 - 99: ii11ii1ii + i11iIiiIii
    if 36 - 36: o0oO0 * Oooo0Ooo000 * iIii1I11I1II1 - O0oO % i11iIiiIii
    if IiIii11i1IIiI == 0 :
     if 98 - 98: iIii1I11I1II1 - i1IIi + iI % O0oO + iI / oO0o0ooO0
     IiiiIi1iI1iI = i1ii1iIi . ok ( "[COLOR darkpink]REALSTREAM:[/COLOR] " , "[COLOR gold]  Reiniciadas las opciones.  [/COLOR]" , "" )
     del i1ii1iIi
     return
     if 97 - 97: i1I111II1I % iI + II111iiii - i1I111II1I % OoOO + iI
    elif IiIii11i1IIiI == 1 :
     if 31 - 31: o0000oOoOoO0o
     pass
     if 35 - 35: OoOO0ooOOoo0O + o0oO0 * iI / OoOO0ooOOoo0O
     del i1ii1iIi
     if 69 - 69: iI . IIII - OOooOOo
     if 29 - 29: i11iIiiIii . o00O0oo / OOooOOo . IIII + i11iIiiIii
     if 26 - 26: i1I111II1I / o0oO0 - OoooooooOO
     if 9 - 9: OoooooooOO * o00O0oo
    elif IiIii11i1IIiI == 2 :
     if 9 - 9: ii11ii1ii + O0ooOooooO
     o0IiIiI111IIII1 ( name , url )
     if 64 - 64: O0 * OOooOOo / OOooOOo
     return
     if 57 - 57: o00O0oo / OoooooooOO % o00O0oo . O0 / o00O0oo
  except :
   pass
 else :
  if 63 - 63: i1I111II1I + iIii1I11I1II1 + OOooOOo + Oooo0Ooo000
  O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
  o00iI = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  O0O0Oooo0o = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  iIi1IIiI = IiII1IiiIiI1 . getSetting ( 'key_ext' )
  o0OOOo = ii1iiIiIII1ii ( O0O0Oooo0o )
  oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
  for I11i11I1iiII in oO0o0oooO0oO :
   if 72 - 72: OoOO + i11iIiiIii + o00O0oo
   try :
    if 96 - 96: oO0o0ooO0 % i1IIi / o0000oOoOoO0o
    if 13 - 13: II111iiii - ii11ii1ii % i11iIiiIii + O0ooOooooO
    O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
    if 88 - 88: O0 . oO0o0ooO0 % OOooOOo
    if 10 - 10: OOooOOo + O0
    if O00O0oOO00O00 == I11i11I1iiII :
     if 75 - 75: O0 % iIii1I11I1II1 / OoOO0ooOOoo0O % IIII / i1I111II1I
     if 31 - 31: i11iIiiIii * OoOO0ooOOoo0O
     if 'https://team.com' in url :
      if 69 - 69: i11iIiiIii
      url = url . replace ( 'https://team.com' , 'https://verystream.com' )
      if 61 - 61: O0
     if 'https://mybox.com' in url :
      if 21 - 21: OoOO % iIii1I11I1II1 . OoOO
      url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
      if 99 - 99: o0000oOoOoO0o * IIII % oO0o0ooO0 * oO0o0ooO0 + OoooooooOO
      if 82 - 82: O0oO / OoOO0ooOOoo0O - IIII / iI
     if 'https://vidcloud.co/' in url :
      if 50 - 50: IIII + OoOO . i11iIiiIii + o00O0oo + i11iIiiIii
      url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
      if 31 - 31: oO0o0ooO0 * Oooo0Ooo000 . OoOO0ooOOoo0O * O0oO
     if 'https://gounlimited.to' in url :
      if 28 - 28: i1I111II1I + OOooOOo - ii11ii1ii % IIII . O0oO + OOooOOo
      url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
      if 72 - 72: o0oO0 / ii11ii1ii / oO0o0ooO0 * OoOO0ooOOoo0O + IIII
     if 'https://drive.com' in url :
      if 58 - 58: o0000oOoOoO0o % OOooOOo . OOooOOo * OoOO - i1I111II1I . OoooooooOO
      url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
      if 10 - 10: Oooo0Ooo000
      if 48 - 48: O0ooOooooO * i1IIi % OoooooooOO * o0oO0 * OoOO
     import resolveurl
     if 7 - 7: O0ooOooooO . o0oO0 . O0ooOooooO - Oooo0Ooo000
     ii1iI1II11ii = urlresolver . HostedMediaFile ( url )
     if 33 - 33: iI + OoooooooOO - OoOO / i1IIi / OoooooooOO
     if not ii1iI1II11ii :
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
      return False
      if 82 - 82: o00O0oo / IIII - O0ooOooooO / ii11ii1ii * OoOO
     try :
      if 55 - 55: OoooooooOO
      iI1I = xbmcgui . DialogProgress ( )
      iI1I . create ( 'Realstream:' , 'Iniciando ...' )
      iI1I . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
      xbmc . sleep ( 1000 )
      if 73 - 73: OoOO0ooOOoo0O - o00O0oo % ii11ii1ii + o00O0oo - O0 . OoOO
      III1ii = ii1iI1II11ii . resolve ( )
      if not III1ii or not isinstance ( III1ii , basestring ) :
       if 38 - 38: O0
       try : i1I = III1ii . msg
       except : i1I = url
       raise Exception ( i1I )
       if 79 - 79: i1IIi . oO0o0ooO0
     except Exception as o0O0Oo00 :
      try : i1I = str ( o0O0Oo00 )
      except : i1I = url
      if 34 - 34: Oooo0Ooo000 * II111iiii
      if 71 - 71: i1I111II1I
      if 97 - 97: o00O0oo
      for OOo0oO0o in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       iI1iI = 1
       iI1I . update ( 45 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % OOo0oO0o )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5  Puede cancelar cuando desee o esperar...,  1000)" % iI1iI )
       iI1I . close ( )
       if 74 - 74: i1I111II1I - O0 / Oooo0Ooo000 * o0oO0 % iI . Oooo0Ooo000
      for OOo0oO0o in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       iI1iI = 2
       iI1I . update ( 48 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % OOo0oO0o )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % iI1iI )
       iI1I . close ( )
      for OOo0oO0o in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       iI1iI = 3
       iI1I . update ( 50 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % OOo0oO0o )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % iI1iI )
       iI1I . close ( )
      for OOo0oO0o in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       iI1iI = 4
       iI1I . update ( 53 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % OOo0oO0o )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % iI1iI )
       iI1I . close ( )
      for OOo0oO0o in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       iI1iI = 5
       iI1I . update ( 55 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % OOo0oO0o )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % iI1iI )
       iI1I . close ( )
       if 60 - 60: o00O0oo . II111iiii * i11iIiiIii . o0000oOoOoO0o
      if iI1I . iscanceled ( ) :
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Cancelando !! , 2000)" )
       iI1I . close ( )
       break
       if 66 - 66: O0ooOooooO / i11iIiiIii * O0
       if 78 - 78: i1I111II1I - O0oO % O0 - IIII % OoOO
       if 43 - 43: OoOO
     iI1I . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
     xbmc . sleep ( 500 )
     iI1I . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
     xbmc . sleep ( 1000 )
     iI1I . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
     iI1I . close ( )
     i1Oo00 = IiII1IiiIiI1 . getSetting ( 'notificar' )
     oOO00OO0ooo0o = xbmcgui . ListItem ( path = III1ii )
     xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO00OO0ooo0o )
     if 90 - 90: OoooooooOO + O0 + o00O0oo / O0oO / o0oO0 * o00O0oo
     if 100 - 100: O0oO
    else :
     if 82 - 82: iIii1I11I1II1
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold] El addon no ha podido conectar al servidor.[/COLOR]" )
     return False
     if 19 - 19: OOooOOo
   except :
    pass
    if 66 - 66: oO0o0ooO0 / OoOO0ooOOoo0O
 return
 if 13 - 13: II111iiii
 if 55 - 55: ii11ii1ii % i1IIi * O0oO
 if 95 - 95: IIII / II111iiii - o0000oOoOoO0o % Oooo0Ooo000 . O0oO
 if 63 - 63: iIii1I11I1II1 / iI
def II1i ( ) :
 if 98 - 98: OoOO0ooOOoo0O - OoOO0ooOOoo0O . II111iiii . O0ooOooooO + O0
 I1IiiiI = [ ]
 iIiI1111 = sys . argv [ 2 ]
 if len ( iIiI1111 ) >= 2 :
  O0OO00 = sys . argv [ 2 ]
  i1111I = O0OO00 . replace ( '?' , '' )
  if ( O0OO00 [ len ( O0OO00 ) - 1 ] == '/' ) :
   O0OO00 = O0OO00 [ 0 : len ( O0OO00 ) - 2 ]
  OoO00oo0 = i1111I . split ( '&' )
  I1IiiiI = { }
  for OOo0oO0o in range ( len ( OoO00oo0 ) ) :
   oOOO = { }
   oOOO = OoO00oo0 [ OOo0oO0o ] . split ( '=' )
   if ( len ( oOOO ) ) == 2 :
    I1IiiiI [ oOOO [ 0 ] ] = oOOO [ 1 ]
 return I1IiiiI
 if 62 - 62: o0oO0 - oO0o0ooO0 % iIii1I11I1II1
 if 57 - 57: OoooooooOO / OoOO0ooOOoo0O
def iI1ii1iIiii1i ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  import urlresolver
  xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
  if 87 - 87: oO0o0ooO0
def Ii ( ) :
 i1ii1iIi = xbmcgui . Dialog ( )
 list = (
 IIi1i1ii11I1 ,
 oOoO0OO
 )
 if 88 - 88: OOooOOo
 oOO0Oo = i1ii1iIi . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=%s]Accede a themoviedb.com[/COLOR]' % oo00O00oO ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 5 - 5: i11iIiiIii * O0ooOooooO - o0oO0 - o00O0oo - i1IIi + O0ooOooooO
 if oOO0Oo :
  if 4 - 4: iI + O0 . i1IIi * o00O0oo - o0000oOoOoO0o
  if oOO0Oo < 0 :
   return
  IIiIIIi1iii1 = list [ oOO0Oo - 2 ]
  return IIiIIIi1iii1 ( )
 else :
  IIiIIIi1iii1 = list [ oOO0Oo ]
  return IIiIIIi1iii1 ( )
 return
 if 37 - 37: iIii1I11I1II1 % O0oO / i1I111II1I
def i1IIIII1 ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 13 - 13: OoOO % iIii1I11I1II1 - II111iiii / OOooOOo
iII111iiiI11i = i1IIIII1 ( )
if 4 - 4: iI % i1I111II1I . Oooo0Ooo000
def IIi1i1ii11I1 ( ) :
 if iII111iiiI11i == 'android' :
  Oo0oOooOoOo = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  Oo0oOooOoOo = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 91 - 91: o00O0oo + iIii1I11I1II1 % i1I111II1I
  if 90 - 90: iI - O0oO . OoOO + OoOO
def oOoO0OO ( ) :
 if 45 - 45: OoOO0ooOOoo0O / OoooooooOO . Oooo0Ooo000 % O0 * o00O0oo * ii11ii1ii
 main ( )
 if 65 - 65: o0000oOoOoO0o + Oooo0Ooo000 - O0
 if 30 - 30: i1I111II1I - O0ooOooooO - OoOO
 if 33 - 33: iIii1I11I1II1 / O0ooOooooO
def OOOOiiI ( ) :
 i1ii1iIi = xbmcgui . Dialog ( )
 o000Ooo00o00O = (
 ooo0O0O0oo0 ,
 oo000oO
 )
 if 8 - 8: OOooOOo % II111iiii - o0000oOoOoO0o - O0oO % OOooOOo
 oOO0Oo = i1ii1iIi . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 93 - 93: o0oO0 * O0ooOooooO / IIII
 if oOO0Oo :
  if 88 - 88: oO0o0ooO0
  if oOO0Oo < 0 :
   return
  IIiIIIi1iii1 = o000Ooo00o00O [ oOO0Oo - 2 ]
  return IIiIIIi1iii1 ( )
 else :
  IIiIIIi1iii1 = o000Ooo00o00O [ oOO0Oo ]
  return IIiIIIi1iii1 ( )
 return
 if 1 - 1: ii11ii1ii
def i1IIIII1 ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 95 - 95: OoooooooOO / O0oO % OoooooooOO / iI * i1I111II1I
iII111iiiI11i = i1IIIII1 ( )
if 75 - 75: O0
def ooo0O0O0oo0 ( ) :
 if iII111iiiI11i == 'android' :
  Oo0oOooOoOo = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  Oo0oOooOoOo = webbrowser . open ( 'https://olpair.com/' )
  if 56 - 56: OoOO / II111iiii
  if 39 - 39: OoOO0ooOOoo0O - OoooooooOO - i1IIi / II111iiii
def oo000oO ( ) :
 if 49 - 49: ii11ii1ii + O0 + i1I111II1I . II111iiii % iI
 main ( )
 if 33 - 33: OoOO0ooOOoo0O . iIii1I11I1II1 / O0oO % o0oO0
 if 49 - 49: OoOO + II111iiii / i1I111II1I - O0 % o0oO0
def iII1i1 ( name , url , id , trailer ) :
 i1ii1iIi = xbmcgui . Dialog ( )
 o000Ooo00o00O = (
 IIIii ,
 OoOo00o00 ,
 OOOooO0o0 ,
 Ii ,
 o00o
 )
 if 3 - 3: ii11ii1ii . OoooooooOO + i1IIi / i1IIi % iIii1I11I1II1 / o0oO0
 oOO0Oo = i1ii1iIi . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % oo00O00oO ,

 '[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % oo00O00oO ,

 '[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % oo00O00oO ,

 '[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % oo00O00oO ,

 '[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % oo00O00oO ] )
 if 66 - 66: O0oO
 if oOO0Oo :
  if 27 - 27: O0
  if oOO0Oo < 0 :
   return
  IIiIIIi1iii1 = o000Ooo00o00O [ oOO0Oo - 5 ]
  return IIiIIIi1iii1 ( )
 else :
  IIiIIIi1iii1 = o000Ooo00o00O [ oOO0Oo ]
  return IIiIIIi1iii1 ( )
 return
 if 73 - 73: i11iIiiIii + oO0o0ooO0 % O0oO . OoooooooOO % oO0o0ooO0
 if 32 - 32: i11iIiiIii - II111iiii
 if 21 - 21: OoOO0ooOOoo0O - II111iiii
def IIIii ( ) :
 if 10 - 10: OoOO0ooOOoo0O - o0000oOoOoO0o * i11iIiiIii / ii11ii1ii + o0000oOoOoO0o + iIii1I11I1II1
 iiII1IIii1i1 ( Ii111 , I111i1i1111 )
 if 23 - 23: i1IIi + o00O0oo + OOooOOo - iI % OoooooooOO . i1I111II1I
def OoOo00o00 ( ) :
 if 49 - 49: oO0o0ooO0 . OoOO0ooOOoo0O
 I1II1IiI1 ( Ii111 , IIII1 )
 if 73 - 73: o0oO0 / OOooOOo / OoooooooOO + OOooOOo
def OOOooO0o0 ( ) :
 if 57 - 57: IIII . o0oO0 % o0000oOoOoO0o
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  I1I11 = id
  if 9 - 9: IIII
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % I1I11 )
  if 38 - 38: O0oO . OoOO . i11iIiiIii * OoooooooOO + O0ooOooooO
 if i1Oo00 == 'true' :
  if 49 - 49: ii11ii1ii - OoOO / Oooo0Ooo000 / o0000oOoOoO0o % oO0o0ooO0
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + Ii111 + "[/COLOR] ,5000)" )
  if 38 - 38: o0000oOoOoO0o . oO0o0ooO0 / o0000oOoOoO0o % II111iiii
def I11iI1iIii1ii ( ) :
 if 70 - 70: O0 / OoooooooOO + o00O0oo + i1IIi
 Ii ( )
 if 63 - 63: O0ooOooooO / o00O0oo * oO0o0ooO0 / II111iiii + IIII - O0
def o00o ( ) :
 if 16 - 16: II111iiii / o0oO0 . o0oO0 - o0oO0 / o00O0oo
 ii1Ii1IiIIi ( )
def IIi ( name , url , mode , iconimage , fanart ) :
 if 28 - 28: IIII * OoooooooOO + iI % O0ooOooooO . iIii1I11I1II1
 II1Iii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 IiiiIi1iI1iI = True
 O0oooo0OoO0oo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 O0oooo0OoO0oo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 O0oooo0OoO0oo . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  II1Iii = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  IiiiIi1iI1iI = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1Iii , listitem = O0oooo0OoO0oo , isFolder = True )
  return IiiiIi1iI1iI
 IiiiIi1iI1iI = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1Iii , listitem = O0oooo0OoO0oo , isFolder = True )
 return IiiiIi1iI1iI
 if 17 - 17: i1I111II1I / o0000oOoOoO0o . IIII + o0000oOoOoO0o / o00O0oo . ii11ii1ii
def Iii111Ii ( name , url , mode , iconimage , fanart , description ) :
 if 39 - 39: o0000oOoOoO0o / i1I111II1I - O0ooOooooO
 II1Iii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 IiiiIi1iI1iI = True
 O0oooo0OoO0oo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 O0oooo0OoO0oo . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 O0oooo0OoO0oo . setProperty ( 'fanart_image' , fanart )
 IiiiIi1iI1iI = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1Iii , listitem = O0oooo0OoO0oo , isFolder = True )
 return IiiiIi1iI1iI
 if 96 - 96: O0oO * o00O0oo * o0oO0 + o00O0oo % OOooOOo + i11iIiiIii
def i1iI11Ii1i ( name , url , mode , iconimage ) :
 if 45 - 45: OOooOOo . ii11ii1ii . Oooo0Ooo000 / oO0o0ooO0
 II1Iii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 IiiiIi1iI1iI = True
 O0oooo0OoO0oo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 O0oooo0OoO0oo . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 O0oooo0OoO0oo . setProperty ( 'fanart_image' , oo00 )
 IiiiIi1iI1iI = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1Iii , listitem = O0oooo0OoO0oo , isFolder = True )
 return IiiiIi1iI1iI
 if 4 - 4: i11iIiiIii + IIII
 if 26 - 26: O0ooOooooO * Oooo0Ooo000 * oO0o0ooO0 * OoOO0ooOOoo0O
def ii111I11Ii ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 48 - 48: O0ooOooooO % i11iIiiIii . OoooooooOO * i1I111II1I % OoOO . O0ooOooooO
 oo0OOo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 6 - 6: O0 . iI - oO0o0ooO0 / i11iIiiIii
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 O00O0 = [ ]
 if 52 - 52: O0ooOooooO + O0 % o0000oOoOoO0o % O0 % II111iiii + OoooooooOO
 O00O0 . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 II1Iii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 O0oooo0OoO0oo = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 O0oooo0OoO0oo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 O0oooo0OoO0oo . setProperty ( 'fanart_image' , fanart )
 O0oooo0OoO0oo . setProperty ( 'IsPlayable' , 'true' )
 if 51 - 51: O0ooOooooO % i11iIiiIii
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  O00O0 . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 28 - 28: o00O0oo + o00O0oo % OoOO0ooOOoo0O
  O0oooo0OoO0oo . addContextMenuItems ( O00O0 , replaceItems = True )
 IiiiIi1iI1iI = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1Iii , listitem = O0oooo0OoO0oo )
 return IiiiIi1iI1iI
 if 12 - 12: O0oO
 if 19 - 19: o0oO0 * i1IIi % O0 + O0oO
def ooO0 ( name , url , mode , iconimage , fanart , id , trailer , description ) :
 if 25 - 25: Oooo0Ooo000 - o0oO0 / O0 . OoooooooOO % OOooOOo . i1IIi
 oo0OOo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 19 - 19: II111iiii / II111iiii % o00O0oo + oO0o0ooO0 + oO0o0ooO0 + O0ooOooooO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 O00O0 = [ ]
 if 4 - 4: o0000oOoOoO0o + O0oO / O0ooOooooO + i1IIi % o0000oOoOoO0o % O0ooOooooO
 O00O0 . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 II1Iii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 O0oooo0OoO0oo = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 O0oooo0OoO0oo . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 O0oooo0OoO0oo . setProperty ( 'fanart_image' , fanart )
 O0oooo0OoO0oo . setProperty ( 'IsPlayable' , 'true' )
 if 80 - 80: o0oO0
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  O00O0 . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 26 - 26: iIii1I11I1II1 . OoooooooOO - iIii1I11I1II1
  O0oooo0OoO0oo . addContextMenuItems ( O00O0 , replaceItems = True )
 IiiiIi1iI1iI = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1Iii , listitem = O0oooo0OoO0oo )
 return IiiiIi1iI1iI
 if 59 - 59: o00O0oo + O0oO . oO0o0ooO0
def iiIO0OO0o0O00oO ( name , url , mode , iconimage , fanart ) :
 if 87 - 87: OoOO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 34 - 34: Oooo0Ooo000 . OoOO0ooOOoo0O / i11iIiiIii / O0ooOooooO
 II1Iii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 O0oooo0OoO0oo = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 O0oooo0OoO0oo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 O0oooo0OoO0oo . setProperty ( 'fanart_image' , fanart )
 O0oooo0OoO0oo . setProperty ( 'IsPlayable' , 'true' )
 IiiiIi1iI1iI = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1Iii , listitem = O0oooo0OoO0oo )
 return IiiiIi1iI1iI
 if 46 - 46: ii11ii1ii + II111iiii * OOooOOo + IIII
def I11II11IiI11 ( name , url , mode , iconimage ) :
 if 97 - 97: iI / iIii1I11I1II1 % iI / OOooOOo * O0ooOooooO % OoOO0ooOOoo0O
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 17 - 17: iIii1I11I1II1
 II1Iii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 O0oooo0OoO0oo = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 O0oooo0OoO0oo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 O0oooo0OoO0oo . setProperty ( 'fanart_image' , oo00 )
 O0oooo0OoO0oo . setProperty ( 'IsPlayable' , 'true' )
 IiiiIi1iI1iI = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1Iii , listitem = O0oooo0OoO0oo )
 return IiiiIi1iI1iI
 if 89 - 89: i1IIi . i1IIi
def i1IIII1111 ( name , url , mode , iconimage ) :
 II1Iii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 IiiiIi1iI1iI = True
 O0oooo0OoO0oo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 IiiiIi1iI1iI = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1Iii , listitem = O0oooo0OoO0oo , isFolder = True )
 return IiiiIi1iI1iI
 if 84 - 84: O0 % o0oO0 . o0oO0 . O0ooOooooO * O0oO
def iIOO0O ( ) :
 if 34 - 34: o0oO0 - oO0o0ooO0 * OoooooooOO . OoOO / OOooOOo
 if 66 - 66: ii11ii1ii / i11iIiiIii % iI
 if 43 - 43: IIII
 oooooo0OO = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 oooooo0OO . doModal ( )
 if ( oooooo0OO . isConfirmed ( ) ) :
  if 84 - 84: IIII . i1I111II1I . O0ooOooooO
  O0o0O0 = urllib . quote_plus ( oooooo0OO . getText ( ) ) . replace ( '+' , ' ' )
  if 2 - 2: ii11ii1ii - OoOO0ooOOoo0O
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 49 - 49: o0oO0 + II111iiii / oO0o0ooO0 - OoOO0ooOOoo0O % OoOO0ooOOoo0O + OOooOOo
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % O0o0O0 )
    if 54 - 54: iI % ii11ii1ii - IIII
    if i1Oo00 == 'true' :
     if 16 - 16: o00O0oo * O0ooOooooO / O0oO
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + Ii111 + "[/COLOR] ,10000)" )
     if 46 - 46: II111iiii
   except :
    if 13 - 13: i1I111II1I + II111iiii % OOooOOo
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 30 - 30: OoooooooOO - i11iIiiIii + oO0o0ooO0 / ii11ii1ii - i11iIiiIii
O0OO00 = II1i ( )
I111i1i1111 = None
Ii111 = None
oo0o00o0 = None
OOo00O = None
id = None
IIII1 = None
if 84 - 84: OoOO0ooOOoo0O - ii11ii1ii . iI . i1I111II1I - ii11ii1ii
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 99 - 99: Oooo0Ooo000
try :
 I111i1i1111 = urllib . unquote_plus ( O0OO00 [ "url" ] )
except :
 pass
try :
 Ii111 = urllib . unquote_plus ( O0OO00 [ "name" ] )
except :
 pass
try :
 oo0o00o0 = int ( O0OO00 [ "mode" ] )
except :
 pass
try :
 OOo00O = urllib . unquote_plus ( O0OO00 [ "iconimage" ] )
except :
 pass
try :
 id = int ( O0OO00 [ "id" ] )
except :
 pass
try :
 IIII1 = urllib . unquote_plus ( O0OO00 [ "trailer" ] )
except :
 pass
 if 75 - 75: iI . IIII / i1I111II1I
 if 84 - 84: OoooooooOO . OOooOOo / o0000oOoOoO0o
print "Mode: " + str ( oo0o00o0 )
print "URL: " + str ( I111i1i1111 )
print "Name: " + str ( Ii111 )
print "iconimage: " + str ( OOo00O )
print "id: " + str ( id )
print "trailer: " + str ( IIII1 )
if 86 - 86: ii11ii1ii % OoOO0ooOOoo0O
if oo0o00o0 == None or I111i1i1111 == None or len ( I111i1i1111 ) < 1 :
 if 77 - 77: o0oO0 % IIII / oO0o0ooO0
 O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 o00iI = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 O0O0Oooo0o = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 iIi1IIiI = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 o0OOOo = ii1iiIiIII1ii ( O0O0Oooo0o )
 oO0o0oooO0oO = re . compile ( Ii1I ) . findall ( o0OOOo )
 for I11i11I1iiII in oO0o0oooO0oO :
  if 91 - 91: OoOO / OoOO . II111iiii . iI - OOooOOo
  try :
   if 23 - 23: OOooOOo
   if 7 - 7: O0ooOooooO % o00O0oo
   O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 64 - 64: Oooo0Ooo000 + i11iIiiIii
   if 35 - 35: OoOO0ooOOoo0O + i1IIi % IIII
   if O00O0oOO00O00 == I11i11I1iiII :
    ii1Ii1IiIIi ( )
    O00o0OO0000oo ( )
    if 68 - 68: i1I111II1I . iI
   else :
    if 64 - 64: i1IIi + ii11ii1ii * OOooOOo / IIII
    oo00O00oO = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
    IIi ( '[COLOR %s]Video tutoriales[/COLOR]' % oo00O00oO , o00oooO0Oo , 125 , O0OOO0OOoO0O , oo00 )
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Por favor compruebe los ajustes de realstream.[/COLOR]" , "[COLOR white] Desde la seccion Tutoriales puede sacarle mayor partido a su Realstream, tambien puede configurarlo a su gusto. [/COLOR]" , "[COLOR gold]El addon no esta activado o bien configurado.[/COLOR]" )
    if 3 - 3: ii11ii1ii / iI + iI . o00O0oo
    if 50 - 50: iIii1I11I1II1 * oO0o0ooO0
  except :
   pass
   if 85 - 85: i1IIi
elif oo0o00o0 == 1 :
 iII1i1 ( Ii111 , I111i1i1111 , id , IIII1 )
elif oo0o00o0 == 2 :
 oo0O0o00 ( )
elif oo0o00o0 == 3 :
 ooOoOO ( )
elif oo0o00o0 == 4 :
 o0ooOO0OOO00o ( Ii111 , I111i1i1111 )
elif oo0o00o0 == 5 :
 IiIIII ( )
elif oo0o00o0 == 6 :
 oo0 ( )
elif oo0o00o0 == 7 :
 iii1 ( )
elif oo0o00o0 == 8 :
 iIiiIi11IIi ( )
elif oo0o00o0 == 9 :
 Ii1Iii11 ( )
elif oo0o00o0 == 10 :
 II11I ( )
elif oo0o00o0 == 11 :
 i11Ii1IIi ( )
elif oo0o00o0 == 12 :
 i1iiii ( )
elif oo0o00o0 == 13 :
 IIi1ii1 ( )
elif oo0o00o0 == 14 :
 oOo0Oo0O0O ( )
elif oo0o00o0 == 15 :
 OOOoo ( )
elif oo0o00o0 == 16 :
 I1ii1i ( )
elif oo0o00o0 == 17 :
 oOooo00000 ( )
elif oo0o00o0 == 18 :
 o0OO00oo0O ( )
elif oo0o00o0 == 19 :
 o0O00Oooo ( )
elif oo0o00o0 == 20 :
 iI111II1ii ( )
elif oo0o00o0 == 21 :
 I111I1I ( )
elif oo0o00o0 == 22 :
 ii1IIiII111I ( )
elif oo0o00o0 == 23 :
 o0OOOOOo0 ( )
elif oo0o00o0 == 24 :
 I1IiII1I1i1I1 ( )
elif oo0o00o0 == 25 :
 oooOo ( )
elif oo0o00o0 == 26 :
 IiIiiI11i1Ii ( )
elif oo0o00o0 == 28 :
 ii11I ( Ii111 , I111i1i1111 )
elif oo0o00o0 == 29 :
 iiiiiII ( )
elif oo0o00o0 == 30 :
 OoOi111i ( )
elif oo0o00o0 == 31 :
 prueba ( )
elif oo0o00o0 == 98 :
 busqueda_global ( )
elif oo0o00o0 == 97 :
 OOOOiiI ( )
elif oo0o00o0 == 99 :
 iI1 ( )
elif oo0o00o0 == 100 :
 menu_player ( Ii111 , I111i1i1111 )
elif oo0o00o0 == 111 :
 oOOO00O0O0OOo ( )
elif oo0o00o0 == 115 :
 I1II1IiI1 ( I111i1i1111 )
elif oo0o00o0 == 116 :
 iIi1II ( )
elif oo0o00o0 == 117 :
 OOI1iIi1iiIIiI ( )
elif oo0o00o0 == 119 :
 I1i ( )
elif oo0o00o0 == 120 :
 ii1ii11 ( )
elif oo0o00o0 == 121 :
 OOOoO ( )
elif oo0o00o0 == 125 :
 IIiiI ( )
elif oo0o00o0 == 112 :
 list_proxy ( )
elif oo0o00o0 == 127 :
 iIOO0O ( )
elif oo0o00o0 == 128 :
 TESTLINKS ( )
elif oo0o00o0 == 130 :
 iiII1IIii1i1 ( Ii111 , I111i1i1111 )
elif oo0o00o0 == 140 :
 ii1i1i1IiII ( )
elif oo0o00o0 == 141 :
 Ii1I1i1ii1I1 ( )
elif oo0o00o0 == 142 :
 oOO0oo ( )
elif oo0o00o0 == 143 :
 OO0OoOOO0 ( Ii111 , I111i1i1111 )
elif oo0o00o0 == 144 :
 ii11I ( Ii111 , I111i1i1111 )
elif oo0o00o0 == 145 :
 OO0OO00oo0 ( )
elif oo0o00o0 == 150 :
 OOoo0oo ( )
elif oo0o00o0 == 151 :
 O0ooOo0o0Oo ( )
elif oo0o00o0 == 152 :
 iiIII1II ( )
elif oo0o00o0 == 155 :
 IIiI1I1 ( )
 if 100 - 100: OoooooooOO / O0oO % OoOO + o0oO0
 if 42 - 42: ii11ii1ii / i1I111II1I . o0oO0 * OOooOOo
xbmcplugin . endOfDirectory ( o0OoOoOO00 ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
