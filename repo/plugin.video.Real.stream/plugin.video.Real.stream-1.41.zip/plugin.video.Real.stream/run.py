# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 1.41
#
############################################
# Dependencias 
# Script ExtendedInfo
# Script Urlresolver de TVAddons
# Script ResolveURL Por Jsergio.
#
############################################
#
# Agregado multi enlace de servidores.
# Agregado sistema individual de usuarios.
#
############################################
if 64 - 64: i11iIiiIii
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import urlresolver
import cookielib , base64
import requests
import plugintools
import config
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
IiII1IiiIiI1 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
o0OoOoOO00 = int ( sys . argv [ 1 ] )
I11i = 'gruponetai/'
O0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
Oo = O0O . getAddonInfo ( 'profile' )
I1ii11iIi11i = O0O . getAddonInfo ( 'path' )
I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
if 73 - 73: OOooOOo / ii11ii1ii
if 94 - 94: OoOO + OoOO0ooOOoo0O + o0000oOoOoO0o * o00O0oo
if I1IiI == 'true' :
 if 97 - 97: oO0o0ooO0 - IIII / O0oO - o0oO0
 oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.png' ) )
 o00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 Oo0oO0ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.png' ) )
 i1111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.png' ) )
 i11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'estrenos.png' ) )
 I11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.png' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.png' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.png' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.png' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.png' ) )
 oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.png' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.png' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.png' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.png' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.png' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.png' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.png' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'marvel.png' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.png' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.png' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.png' ) )
 II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.png' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.png' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.png' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.png' ) )
 OO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.png' ) )
 Ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.png' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.png' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.png' ) )
 O0OO00o0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.png' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.png' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_series.png' ) )
 OOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_Episodios.png' ) )
 if 87 - 87: O0ooOooooO / i1I111II1I - Oooo0Ooo000 - iI - II111iiii / O0
else :
 if 97 - 97: iI - IIII * i11iIiiIii / OoOO0ooOOoo0O % Oooo0Ooo000 - OoooooooOO
 if 59 - 59: O0 + OOooOOo + i1I111II1I % OOooOOo
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
 oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.jpg' ) )
 o00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 Oo0oO0ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.jpg' ) )
 i1111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.jpg' ) )
 i11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'encines.jpg' ) )
 I11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.jpg' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.jpg' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.jpg' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.jpg' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.jpg' ) )
 oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.jpg' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.jpg' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.jpg' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.jpg' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.jpg' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.jpg' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.jpg' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'superheroes.jpg' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.jpg' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.jpg' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.jpg' ) )
 II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.jpg' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.jpg' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.jpg' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.jpg' ) )
 OO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.jpg' ) )
 Ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.jpg' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.jpg' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.jpg' ) )
 O0OO00o0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.png' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.png' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.png' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favoritos.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_series.png' ) )
 OOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_Episodios.png' ) )
 if 70 - 70: O0ooOooooO * o00O0oo
 if 46 - 46: iI / OoOO
 if 52 - 52: o0000oOoOoO0o - OoooooooOO + o0oO0 + o0oO0 - o0000oOoOoO0o / Oooo0Ooo000
I1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'peliculas.png' ) )
iIi11Ii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series.png' ) )
Ii11iII1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ajustes.png' ) )
Oo0O0O0ooO0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'videoteca.png' ) )
IIIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
O0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'resolver.png' ) )
OO00Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'test.png' ) )
O0OOO0OOoO0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'video-tutoriales.png' ) )
O00Oo000ooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'proxy.png' ) )
if 100 - 100: O0 + i1I111II1I - IIII + i11iIiiIii * o0oO0
if 30 - 30: o0000oOoOoO0o . o0oO0 - OoooooooOO
if 8 - 8: i1IIi - iIii1I11I1II1 * II111iiii + i11iIiiIii / Oooo0Ooo000 % IIII
iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
OOoOO0oo0ooO = IiII1IiiIiI1 . getSetting ( 'mostrar_cat' )
O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'sel_tobox' )
O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'videos' )
i1Oo00 = IiII1IiiIiI1 . getSetting ( 'activar' )
i1i = IiII1IiiIiI1 . getSetting ( 'favcopy' )
iiI111I1iIiI = IiII1IiiIiI1 . getSetting ( 'anticopia' )
IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
oooooOoo0ooo = IiII1IiiIiI1 . getSetting ( 'mostrar_bus' )
I1I1IiI1 = IiII1IiiIiI1 . getSetting ( 'restante' )
III1iII1I1ii = IiII1IiiIiI1 . getSetting ( 'selecton' )
oOOo0 = IiII1IiiIiI1 . getSetting ( 'aviso' )
oo00O00oO = IiII1IiiIiI1 . getSetting ( 'RealStream_Settings' )
iIiIIIi = IiII1IiiIiI1 . getSetting ( 'Resolver_Settings' )
I1I1IiI1 = IiII1IiiIiI1 . getSetting ( 'restante' )
ooo00OOOooO = IiII1IiiIiI1 . getSetting ( 'fav' )
O00OOOoOoo0O = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
O000OOo00oo = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
oo0OOo = 'bienvenida'
ooOOO00Ooo = 'bienvenida'
copyright = IiII1IiiIiI1 . getSetting ( 'copyright' )
IiIIIi1iIi = 'cGx1Z2luLnZpZGVvLg==' . decode ( 'base64' ) + copyright
ooOOoooooo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
II1I = IiII1IiiIiI1 . getSetting ( 'Forceupdate' )
if II1I == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
O0i1II1Iiii1I11 = 'LnR4dA==' . decode ( 'base64' )
IIIIiiIiI = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1NQOUpRZExS' . decode ( 'base64' )
if 91 - 91: O0ooOooooO % i1IIi % iIii1I11I1II1
if 20 - 20: IIII % o0oO0 / o0oO0 + o0oO0
III1IiiI = 'aHR0cDovL2JpdC5seS8yU1FOSnlP' . decode ( 'base64' )
iIi1 = O000OOo00oo + oo0OOo + O0i1II1Iiii1I11
IIIII11I1IiI = 'http://www.youtube.com'
i1I = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
OoOOooOOO0 = 'http://bit.ly/2ImelUx'
o0o = '.xsl.pt'
O0OOoO00OO0o = 'L21hc3Rlci8=' . decode ( 'base64' )
I1111IIIIIi = i1I + o0o
Iiii1i1 = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*'
OO = 'tvg-logo=[\'"](.*?)[\'"]'
if 77 - 77: ii11ii1ii
I1iII1iIi1I = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.*)'
oO0O00OoOO0 = '(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)'
OoO = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
O00 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
I1iI1 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
iiiIi1 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
i1I1ii11i1Iii = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.+)\s*'
I1IiiiiI = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
o0O = '#(.+?),(.+)\s*(.+)'
IiII = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
ii1iII1II = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
Iii1I1I11iiI1 = '[\'"](.*?)[\'"]'
I1I1i1I = r'066">\s*(.+)</f'
ii1I = '[\'"](.*?)[\'"]'
O0oO0 = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
oO0 = '[\'"](.*?)[\'"]'
O0OO0O = 'src":"(.*?)"label":"(.*?)"lang":"(.*?)"'
OOOoOoO = 'https://pastebin.com/raw/SP9JQdLR'
Ii1I1i = '[\'"](.*?)[\'"]'
OOI1iI1ii1II = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( 'base64' )
O0O0OOOOoo = OOI1iI1ii1II + I11i
oOooO0 = '(.+),(.+),(.*)\s*'
Ii1I1Ii = '[\'"](.*?)[\'"]'
OOoO0 = 'UmVhbHN0cmVhbQ==' . decode ( 'base64' )
OO0Oooo0oOO0O = 'video=[\'"](.*?)[\'"]'
o00O0 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
oOO0O00Oo0O0o = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( 'base64' ) + o00O0
ii1 = '0101ahn' . replace ( '0101ahn' , 'sZn' )
I1iIIiiIIi1i = 'aHR0cDovL2JpdC5seS8yTnpB' . decode ( 'base64' ) + ii1
O0O0ooOOO = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
oOOo0O00o = '0110R0N' . replace ( '0110R0N' , 'R0N' )
iIiIi11 = 'aHR0cDovL2JpdC5seS8yWEIx' . decode ( 'base64' ) + oOOo0O00o
OOO = '0110pEJ' . replace ( '0110pEJ' , 'pEJ' )
iiiiI = 'aHR0cDovL2JpdC5seS8yd1Nh' . decode ( 'base64' ) + OOO
oooOo0OOOoo0 = 'ABBAOb5' . replace ( 'ABBAOb5' , 'Ob5' )
OOoO = 'aHR0cDovL2JpdC5seS8yRVhV' . decode ( 'base64' ) + oooOo0OOOoo0
OO0O000 = '0110jaw' . replace ( '0110jaw' , 'jaw' )
iiIiI1i1 = 'aHR0cDovL2JpdC5seS8yd01M' . decode ( 'base64' ) + OO0O000
oO0O00oOOoooO = '01109DI' . replace ( '01109DI' , '9DI' )
IiIi11iI = 'aHR0cDovL2JpdC5seS8ySXgz' . decode ( 'base64' ) + oO0O00oOOoooO
Oo0O00O000 = '01103hs' . replace ( '01103hs' , '3hs' )
i11I1IiII1i1i = 'aHR0cDovL2JpdC5seS8zMW1U' . decode ( 'base64' ) + Oo0O00O000
oo = '01107DW' . replace ( '01107DW' , '7DW' )
I1111i = 'aHR0cDovL2JpdC5seS8yV1ln' . decode ( 'base64' ) + oo
iIIii = '0110mLl' . replace ( '0110mLl' , 'mLl' )
o00O0O = 'aHR0cDovL2JpdC5seS8yS0cw' . decode ( 'base64' ) + iIIii
ii1iii1i = '01102Hj' . replace ( '01102Hj' , '2Hj' )
Iii1I1111ii = 'aHR0cDovL2JpdC5seS8yWEJo' . decode ( 'base64' ) + ii1iii1i
ooOoO00 = '0110fXg' . replace ( '0110fXg' , 'fXg' )
Ii1IIiI1i = 'aHR0cDovL2JpdC5seS8ySTVy' . decode ( 'base64' ) + ooOoO00
o0O00Oo0 = '0110NMH' . replace ( '0110NMH' , 'NMH' )
IiII111i1i11 = 'aHR0cDovL2JpdC5seS8yd0t6' . decode ( 'base64' ) + o0O00Oo0
i111iIi1i1II1 = '0110bwQ' . replace ( '0110bwQ' , 'bwQ' )
oooO = 'aHR0cDovL2JpdC5seS8yd01V' . decode ( 'base64' ) + i111iIi1i1II1
i1I1i111Ii = '0110xzG' . replace ( '0110xzG' , 'xzG' )
ooo = 'aHR0cDovL2JpdC5seS8yWHhz' . decode ( 'base64' ) + i1I1i111Ii
i1i1iI1iiiI = '0110x64' . replace ( '0110x64' , 'x64' )
Ooo0oOooo0 = 'aHR0cDovL2JpdC5seS8yRVlF' . decode ( 'base64' ) + i1i1iI1iiiI
oOOOoo00 = '0110vUE' . replace ( '0110vUE' , 'vUE' )
iiIiIIIiiI = 'aHR0cDovL2JpdC5seS8yWmhW' . decode ( 'base64' ) + oOOOoo00
iiI1IIIi = '01107ZL' . replace ( '01107ZL' , '7ZL' )
II11IiIi11 = 'aHR0cDovL2JpdC5seS8yWm4w' . decode ( 'base64' ) + iiI1IIIi
IIOOO0O00O0OOOO = '01106cf' . replace ( '01106cf' , '6cf' )
I1iiii1I = 'aHR0cDovL2JpdC5seS8yRVlk' . decode ( 'base64' ) + IIOOO0O00O0OOOO
OOo0 = '0110Jtp' . replace ( '0110Jtp' , 'Jtp' )
oO00ooooO0o = 'aHR0cDovL2JpdC5seS8yV3Nq' . decode ( 'base64' ) + OOo0
oo0o = '0110a5b' . replace ( '0110a5b' , 'a5b' )
o0oO0oooOoo = 'aHR0cDovL2JpdC5seS8yV3dj' . decode ( 'base64' ) + oo0o
I1III1111iIi = '0110Q7u' . replace ( '0110Q7u' , 'Q7u' )
I1i111I = 'aHR0cDovL2JpdC5seS8yV3NL' . decode ( 'base64' ) + I1III1111iIi
OooOo0oo0O0o00O = '0110rsq' . replace ( '0110rsq' , 'rsq' )
I1i11 = 'aHR0cDovL2JpdC5seS8ySzhE' . decode ( 'base64' ) + OooOo0oo0O0o00O
IiIi1I1 = '0110DDR' . replace ( '0110DDR' , 'DDR' )
IiIIi1 = 'aHR0cDovL2JpdC5seS8ySzd5' . decode ( 'base64' ) + IiIi1I1
IIIIiii1IIii = '0110feQ' . replace ( '0110feQ' , 'feQ' )
II1i11I = 'aHR0cDovL2JpdC5seS8yS0cz' . decode ( 'base64' ) + IIIIiii1IIii
ii1I1IIii11 = '0110MHY' . replace ( '0110MHY' , 'MHY' )
O0o0oO = 'aHR0cDovL2JpdC5seS8ySXVo' . decode ( 'base64' ) + ii1I1IIii11
IIIIiIiIi1 = '0110xdb' . replace ( '0110xdb' , 'xdb' )
I11iiiiI1i = 'aHR0cDovL2JpdC5seS8yWEJu' . decode ( 'base64' ) + IIIIiIiIi1
iI1i11 = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( 'base64' )
OoOOoooOO0O = 'aHR0cHM6Ly9uZXRhaS5ldS92aXNpdGFzL2luZGV4LnBocA==' . decode ( 'base64' )
IiIIIi1iIi = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
ooo00Ooo = '0110lxu' . replace ( '0110lxu' , 'lxu' )
Oo0o0O00 = 'aHR0cDovL2JpdC5seS8yV1Bj' . decode ( 'base64' ) + ooo00Ooo
ii1I1i11 = '0110pzp' . replace ( '0110pzp' , 'pzp' )
OOo0O0oo0OO0O = 'aHR0cDovL2JpdC5seS8yVHpB' . decode ( 'base64' ) + ii1I1i11
OO0 = '01105yt' . replace ( '01105yt' , '5yt' )
o0Oooo = 'aHR0cDovL2JpdC5seS8yTVpp' . decode ( 'base64' ) + OO0
if 36 - 36: OoooooooOO . OoOO
if 56 - 56: ii11ii1ii . o00O0oo . OOooOOo
ii111I = '1001DTs' . replace ( '1001DTs' , 'DTs' )
iiI = 'aHR0cDovL2JpdC5seS8ySzhP' . decode ( 'base64' ) + ii111I
iIiiiII = '1001Hky' . replace ( '1001Hky' , 'Hky' )
i1iI1 = 'aHR0cDovL2JpdC5seS8yTGVL' . decode ( 'base64' ) + iIiiiII
i11ii1ii11i = '1001VFU' . replace ( '1001VFU' , 'VFU' )
ooO0OoOO = 'aHR0cDovL2JpdC5seS8zMERx' . decode ( 'base64' ) + i11ii1ii11i
O0O0Oo00 = '3545OMZ' . replace ( '3545OMZ' , 'OMZ' )
oOoO00o = 'aHR0cDovL2JpdC5seS8yazhk' . decode ( 'base64' ) + O0O0Oo00
oO00O0 = '4224tZO' . replace ( '4224tZO' , 'tZO' )
IIi1IIIi = 'aHR0cDovL2JpdC5seS8zNXd4' . decode ( 'base64' ) + oO00O0
if 99 - 99: o0oO0 + OoOO * II111iiii . o0000oOoOoO0o - o00O0oo
if 58 - 58: o0oO0 + o0000oOoOoO0o - OOooOOo
if 3 - 3: OoOO
def oooOoOOO0oo0o ( ) :
 if 85 - 85: OoooooooOO % i1IIi * OoooooooOO / o00O0oo
 if 96 - 96: OoooooooOO + oO0o0ooO0
 try :
  iiII1i11i = IiIi ( iIiIi11 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   try :
    if 31 - 31: o0000oOoOoO0o % OoOO
    iiiiI = Iii
    if 14 - 14: oO0o0ooO0 / oO0o0ooO0 % iI
    ooO = xbmc . Keyboard ( '' , 'Busqueda por titulo' )
    ooO . doModal ( )
    if ( ooO . isConfirmed ( ) ) :
     ii = xbmcgui . DialogProgress ( )
     ii . create ( 'Realstream:' , 'Buscando ...' )
     OO0O0Ooo = range ( 0 , 76 )
     for oOoO0 in OO0O0Ooo :
      oOoO0 = oOoO0 + 1
      if 77 - 77: iIii1I11I1II1 . O0ooOooooO % O0ooOooooO + i11iIiiIii
     Oo00o0OO0O00o = urllib . quote_plus ( ooO . getText ( ) ) . replace ( '+' , ' ' )
     O0Oooo = IiIi ( iiiiI )
     OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( O0Oooo )
     for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
      if 27 - 27: o00O0oo + OoOO0ooOOoo0O - IIII + O0 . o0oO0
      ii . update ( oOoO0 , '[COLOR orange]Realstream: Buscando ...[/COLOR]' , ' [COLOR yellow] %s [/COLOR]' % I1i11111i1i11 )
      xbmc . sleep ( 1 )
      if ii . iscanceled ( ) : break ;
      if re . search ( Oo00o0OO0O00o , iIi1i1iIi1iI ( I1i11111i1i11 . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       if 26 - 26: OoooooooOO * OOooOOo + IIII
       ii . update ( 80 , ' [COLOR orange]Busqueda finalizada[/COLOR] ' )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR gold]Generando listado ...  [/COLOR][COLOR orange] Por favor espere ![/COLOR] ,1000)" )
       ii . update ( 100 , '[COLOR orange]Realstream: [/COLOR]' , '[COLOR gold] Busqueda finalizada ...[/COLOR]' )
       ii . close ( )
       IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
       if 43 - 43: O0
       if 39 - 39: OOooOOo . iIii1I11I1II1 * o0oO0 % iI . iIii1I11I1II1
     oO0OoO00o ( '[COLOR %s]Buscar Pelicula[/COLOR]' % iIIIi1 , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Resultados para: [COLOR orange]" + Oo00o0OO0O00o + "[/COLOR] ,2000)" )
     if 11 - 11: ii11ii1ii - OOooOOo * II111iiii . o00O0oo . oO0o0ooO0
   except : oO0OoO00o ( '[COLOR %s]Buscar Pelicula[/COLOR]' % iIIIi1 , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
   if 61 - 61: O0ooOooooO % OOooOOo - o0000oOoOoO0o - II111iiii % O0
 except :
  pass
  if 90 - 90: iIii1I11I1II1 + o00O0oo + iI - Oooo0Ooo000 * i1I111II1I . o00O0oo
def I11iiiii1II ( ) :
 if 51 - 51: O0 % oO0o0ooO0 - II111iiii
 oOOo0 = IiII1IiiIiI1 . getSetting ( 'aviso' )
 if 31 - 31: O0ooOooooO / ii11ii1ii - O0ooOooooO - IIII
 if oOOo0 == 'true' :
  if 7 - 7: O0ooOooooO % O0 . OoOO0ooOOoo0O + OOooOOo - O0oO
  try :
   iiII1i11i = IiIi ( iIi1 )
   OOOOO0O00 = re . compile ( Iiii1i1 ) . findall ( iiII1i11i )
   for o0o0O00oo0 , Ii1ii1IiIII in OOOOO0O00 :
    try :
     if 57 - 57: iIii1I11I1II1 / O0oO - i1IIi
     if 51 - 51: i1I111II1I
     ii11I1 = o0o0O00oo0
     oO0oo = Ii1ii1IiIII
     if 38 - 38: OoooooooOO * iI % O0 * OoOO0ooOOoo0O
     if 29 - 29: o00O0oo / i1IIi . OOooOOo - OoOO0ooOOoo0O - OoOO0ooOOoo0O - o0oO0
     from datetime import datetime
     if 20 - 20: i1IIi % OoOO . OOooOOo / i1I111II1I * i11iIiiIii * IIII
     OOo = datetime . now ( )
     i1i11I1I1iii1 = OOo . strftime ( '%d/%m/%Y' )
     if 8 - 8: iI + II111iiii / O0ooOooooO / O0oO
     ooo0O = IiIi ( OoOOoooOO0O )
     OOOOO0O00 = re . compile ( I1I1i1I ) . findall ( ooo0O )
     for iII1iii in OOOOO0O00 :
      if 12 - 12: IIII
      O0iII1 = "[B]" + ii11I1 + "[/B]"
      IIII1i = "" + oO0oo + ""
      Ii1IIIIi1ii1I = "[COLOR white]Hoy: " + i1i11I1I1iii1 + ", Es usted el visitante numero: [B][COLOR gold]" + iII1iii + "[/B][/COLOR]"
      if 13 - 13: OOooOOo % OoOO0ooOOoo0O . o00O0oo / ii11ii1ii % IIII . OoooooooOO
      xbmcgui . Dialog ( ) . ok ( "Real Stream" , O0iII1 , IIII1i , Ii1IIIIi1ii1I )
    except :
     pass
     if 22 - 22: i1I111II1I / i11iIiiIii
  except :
   pass
   if 62 - 62: OoOO / o00O0oo
  try :
   O0Oooo = IiIi ( iI1i11 )
   OOOOO0O00 = re . compile ( Iii1I1I11iiI1 ) . findall ( O0Oooo )
   for ii1O000OOO0OOo in OOOOO0O00 :
    if 32 - 32: o0oO0 * O0
    import xbmc
    import xbmcaddon
    if 100 - 100: iI % iIii1I11I1II1 * II111iiii - O0ooOooooO
    __addon__ = xbmcaddon . Addon ( )
    __addonname__ = __addon__ . getAddonInfo ( 'name' )
    __icon__ = __addon__ . getAddonInfo ( 'icon' )
    if 92 - 92: iI
    iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
    II11iI111i1 = ii1O000OOO0OOo
    if 95 - 95: OoooooooOO - i1I111II1I * OOooOOo + OoOO0ooOOoo0O
    O0iII1 = "[COLOR orange]Version instalada: [COLOR gold][B] " + iIiiiI1IiI1I1 + "[/B] [/COLOR][/COLOR][COLOR white] Disponible: [B]" + ii1O000OOO0OOo + " [/B][/COLOR]"
    iIi1i11iiI1111 = 4000
    xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , O0iII1 , iIi1i11iiI1111 , __icon__ ) )
    if 97 - 97: ii11ii1ii * OOooOOo . iIii1I11I1II1
    if iIiiiI1IiI1I1 < ii1O000OOO0OOo :
     if 16 - 16: iI % OoooooooOO - IIII * o0oO0 * o00O0oo / OoooooooOO
     xbmcgui . Dialog ( ) . ok ( "Real Stream" , "[COLOR white] Existe una nueva version de [/COLOR][COLOR fuchsia]Realstream[/COLOR]" , "[COLOR orange]Actualimete tiene instalada la version[/COLOR] [COLOR white][B] %s [/B][/COLOR]" % iIiiiI1IiI1I1 , " [COLOR white]Ya esta disponible la[/COLOR] [COLOR gold][B] %s [/B][/COLOR]" % ii1O000OOO0OOo )
     if 31 - 31: O0oO . Oooo0Ooo000 * iI + i11iIiiIii * oO0o0ooO0
     if 93 - 93: o00O0oo / iIii1I11I1II1 * i1IIi % OoooooooOO * O0 * O0oO
  except :
   pass
   if 64 - 64: II111iiii + O0 / iIii1I11I1II1 / ii11ii1ii . iI % i1I111II1I
   if 50 - 50: iIii1I11I1II1 - i1I111II1I + IIII
   if 69 - 69: O0
   if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 85 - 85: iI / O0
    if 18 - 18: o0000oOoOoO0o % O0 * o00O0oo
    if 62 - 62: Oooo0Ooo000 . i1I111II1I . OoooooooOO
def iIi1i1iIi1iI ( s ) :
 if 11 - 11: IIII / O0oO
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 73 - 73: i1IIi / i11iIiiIii
def OOOIiiiii1iI ( file ) :
 if 49 - 49: o0000oOoOoO0o . i1I111II1I / OoOO + II111iiii
 try :
  ii11i = open ( file , 'r' )
  iiII1i11i = ii11i . read ( )
  ii11i . close ( )
  return iiII1i11i
 except :
  pass
  if 35 - 35: o00O0oo * O0ooOooooO - OoOO % o0000oOoOoO0o
def IiIi ( url ) :
 if 87 - 87: OoOO0ooOOoo0O * Oooo0Ooo000 . O0oO
 try :
  O0Oo0o000oO = urllib2 . Request ( url )
  O0Oo0o000oO . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  oO0o00oOOooO0 = urllib2 . urlopen ( O0Oo0o000oO )
  OOOoO000 = oO0o00oOOooO0 . read ( )
  oO0o00oOOooO0 . close ( )
  return OOOoO000
 except urllib2 . URLError , oOOOO :
  print 'We failed to open "%s".' % url
  if hasattr ( oOOOO , 'code' ) :
   print 'We failed with error code - %s.' % oOOOO . code
  if hasattr ( oOOOO , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , oOOOO . reason
   if 49 - 49: II111iiii . oO0o0ooO0 . i11iIiiIii % i1I111II1I
def i11i1iiI1i ( url ) :
 O0Oo0o000oO = urllib2 . Request ( url )
 O0Oo0o000oO . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 O0Oo0o000oO . add_header ( 'Referer' , '%s' % url )
 O0Oo0o000oO . add_header ( 'Connection' , 'keep-alive' )
 oO0o00oOOooO0 = urllib2 . urlopen ( O0Oo0o000oO )
 OOOoO000 = oO0o00oOOooO0 . read ( )
 oO0o00oOOooO0 . close ( )
 return OOOoO000
 if 87 - 87: iI
 if 45 - 45: OoOO / OoooooooOO - O0ooOooooO / o0oO0 % i1I111II1I
 if 83 - 83: OOooOOo . iIii1I11I1II1 - i1I111II1I * i11iIiiIii
def IiI11i1IIiiI ( ) :
 if 60 - 60: o00O0oo * OOooOOo
 iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 if 17 - 17: IIII % ii11ii1ii / o00O0oo . i1I111II1I * IIII - II111iiii
 if i1Oo00 == 'true' :
  if 41 - 41: o0oO0
  if 77 - 77: Oooo0Ooo000
  try :
   if 65 - 65: II111iiii . OOooOOo % oO0o0ooO0 * OoOO
   iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
   o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
   OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
   if 38 - 38: OoOO0ooOOoo0O / O0ooOooooO % ii11ii1ii
   I1IIIiii1 = IiIi ( I1iIIiiIIi1i )
   OOOOO0O00 = re . compile ( oOooO0 ) . findall ( I1IIIiii1 )
   for O00oo , O0OO00O0oOO , Ii1iI111 in OOOOO0O00 :
    if re . search ( OOO00O , Ii1iI111 ) :
     if 51 - 51: i1I111II1I * O0 / II111iiii . o0oO0 % IIII / OOooOOo
     if iiII1i1 == O00oo and o00oOO0o == O0OO00O0oOO and OOO00O == Ii1iI111 :
      xbmc . sleep ( 3000 )
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR orange]Bienvenido![/COLOR][COLOR white] " + O00oo + "[/COLOR] ,3000)" )
      oO0OoO00o ( '[COLOR %s]Buscar Serie[/COLOR]' % iIIIi1 , 'search' , 145 , I1IIIii , oo00 )
      oO0OoO00o ( '[COLOR %s]Series[/COLOR] ' % iIIIi1 , 'movieDB' , 117 , iIi11Ii1 , oo00 )
      oO0OoO00o ( '[COLOR %s]Buscar Pelicula[/COLOR]' % iIIIi1 , 'search' , 146 , IIiiiiiiIi1I1 , oo00 )
      oO0OoO00o ( '[COLOR %s]Peliculas[/COLOR] ' % iIIIi1 , 'movieDB' , 116 , I1I , oo00 )
      if 9 - 9: OOooOOo % OOooOOo % II111iiii
  except :
   pass
   if 30 - 30: i1I111II1I + Oooo0Ooo000 - i1I111II1I . i1I111II1I - II111iiii + O0
 if oo00O00oO == 'true' :
  oO0OoO00o ( '[COLOR %s]Ajustes[/COLOR]' % iIIIi1 , 'Settings' , 119 , Ii11iII1 , oo00 )
  if 86 - 86: i1IIi
  if 41 - 41: OoOO0ooOOoo0O * O0oO / OoOO0ooOOoo0O % oO0o0ooO0
  if OOoOO0oo0ooO == 'true' :
   try :
    if 18 - 18: II111iiii . OoooooooOO % OoOO0ooOOoo0O % o0oO0
    iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
    o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
    OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
    if 9 - 9: OoOO - ii11ii1ii * OoooooooOO . ii11ii1ii
    I1IIIiii1 = IiIi ( I1iIIiiIIi1i )
    OOOOO0O00 = re . compile ( oOooO0 ) . findall ( I1IIIiii1 )
    for O0OO00O0oOO , O00oo , Ii1iI111 in OOOOO0O00 :
     if re . search ( OOO00O , Ii1iI111 ) :
      if 2 - 2: OoooooooOO % IIII
      if iiII1i1 == O00oo and o00oOO0o == O0OO00O0oOO and OOO00O == Ii1iI111 :
       if 63 - 63: OOooOOo % iIii1I11I1II1
       I1ii ( )
   except :
    pass
    if 73 - 73: i1I111II1I + OOooOOo * ii11ii1ii * OoooooooOO
  if iIiIIIi == 'true' :
   Oo0o0O ( )
   ii1iIi1II ( )
   if 2 - 2: ii11ii1ii + OoOO0ooOOoo0O - IIII . OOooOOo - IIII
  if iiI111I1iIiI == 'false' :
   if 67 - 67: iIii1I11I1II1 - O0ooOooooO
   O0iII1 = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   IIII1i = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Script.ResolveURL para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   Ii1IIIIi1ii1I = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 11 - 11: iIii1I11I1II1 . OoooooooOO . II111iiii / i1IIi - O0oO
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , O0iII1 , IIII1i , Ii1IIIIi1ii1I )
   if 30 - 30: OoOO0ooOOoo0O
def Ii111 ( ) :
 oO0OoO00o ( '[COLOR orange]Buscador por id[/COLOR]' , IIIII11I1IiI , 127 , oOOoo00O0O , oo00 )
 if 67 - 67: O0
def Oooooooo0o ( ) :
 iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 oO0OoO00o ( '[COLOR %s]The movie DB[/COLOR]' % iIIIi1 , 'movieDB' , 99 , oOOoo00O0O , oo00 )
 if 74 - 74: o0oO0
 oO0OoO00o ( '[COLOR %s]Video tutoriales[/COLOR]' % iIIIi1 , IIIII11I1IiI , 125 , O0OOO0OOoO0O , oo00 )
 if 5 - 5: OoooooooOO - OoOO + i1I111II1I - O0ooOooooO . OoOO / iI
 if 28 - 28: o0oO0 * o0oO0 - iIii1I11I1II1
 if 70 - 70: Oooo0Ooo000
def i11iIIi11 ( ) :
 if 98 - 98: Oooo0Ooo000
 IiI11i1IIiiI ( )
 Oooooooo0o ( )
 if 12 - 12: II111iiii . O0oO / IIII
def O00OO0oO ( ) :
 if 25 - 25: ii11ii1ii % o00O0oo * iI
 i11iIIi11 ( )
 if 6 - 6: O0ooOooooO . i1I111II1I * OoOO0ooOOoo0O . i1IIi
def oOOo ( ) :
 if xbmc . getCondVisibility ( 'System.HasAddon(script.favourites)' ) :
  try :
   xbmc . executebuiltin ( "RunScript(script.favourites)" )
  except :
   pass
def I1IiIIi ( ) :
 IiII1IiiIiI1 . openSettings ( )
 if 42 - 42: O0 . oO0o0ooO0 - o0000oOoOoO0o / i1IIi
 if 68 - 68: O0 + OoOO0ooOOoo0O / oO0o0ooO0 - IIII + iIii1I11I1II1 % o0oO0
def i1iI1iii11i ( ) :
 urlresolver . display_settings ( )
 if 62 - 62: ii11ii1ii * OoOO0ooOOoo0O
def Oo0o0O ( ) :
 oO0OoO00o ( '[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % iIIIi1 , 'resolve' , 120 , O0o0 , oo00 )
 if 79 - 79: OoOO . O0ooOooooO * o0oO0 - IIII + iI
def ii11II1i ( ) :
 if 58 - 58: ii11ii1ii . i1I111II1I - ii11ii1ii - Oooo0Ooo000 * o0oO0
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 28 - 28: OoOO0ooOOoo0O * OoOO . O0oO % O0oO / O0oO * Oooo0Ooo000
def ii1iIi1II ( ) :
 oO0OoO00o ( '[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % iIIIi1 , 'resolve' , 140 , O0o0 , oo00 )
 if 64 - 64: II111iiii - OOooOOo
def I1ii ( ) :
 if 68 - 68: iI - IIII - iIii1I11I1II1 / OoOO0ooOOoo0O + IIII - OoOO
 try :
  if 75 - 75: O0ooOooooO / o0000oOoOoO0o % iIii1I11I1II1 . OoooooooOO % OoooooooOO % II111iiii
  iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
  OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 26 - 26: II111iiii % i11iIiiIii % iIii1I11I1II1 % O0oO * O0oO * o00O0oo
  I1IIIiii1 = IiIi ( I1iIIiiIIi1i )
  OOOOO0O00 = re . compile ( oOooO0 ) . findall ( I1IIIiii1 )
  for O00oo , O0OO00O0oOO , Ii1iI111 in OOOOO0O00 :
   if re . search ( OOO00O , Ii1iI111 ) :
    if 24 - 24: II111iiii % Oooo0Ooo000 - iI + OOooOOo * o00O0oo
    if iiII1i1 == O00oo and o00oOO0o == O0OO00O0oOO and OOO00O == Ii1iI111 :
     if 2 - 2: o0oO0 - i1I111II1I
     oO0OoO00o ( '[COLOR %s]Buscador[/COLOR]' % iIIIi1 , 'search' , 146 , o0oOoO00o , oo00 )
     oO0OoO00o ( '[COLOR %s]Estrenos[/COLOR]' % iIIIi1 , IIIII11I1IiI , 3 , i11 , oo00 )
#     oO0OoO00o ( '[COLOR %s]Todas[/COLOR]' % iIIIi1 , IIIII11I1IiI , 26 , I11 , oo00 )
     oO0OoO00o ( '[COLOR %s]Novedades[/COLOR]' % iIIIi1 , IIIII11I1IiI , 2 , i1111 , oo00 )
     if 83 - 83: oO0o0ooO0 % o0000oOoOoO0o % o0oO0 - II111iiii * IIII / OoooooooOO
     if 18 - 18: OoOO + iIii1I11I1II1 - II111iiii - OOooOOo
     if 71 - 71: OoooooooOO
     if 33 - 33: Oooo0Ooo000
     if 62 - 62: o00O0oo + o0oO0 + i1IIi / OoooooooOO
     if 7 - 7: o0000oOoOoO0o + i1IIi . OOooOOo / ii11ii1ii
     oO0OoO00o ( '[COLOR %s]Grandes Pelis[/COLOR]' % iIIIi1 , IIIII11I1IiI , 30 , i1iiIIiiI111 , oo00 )
     if 22 - 22: iI - iI % IIII . Oooo0Ooo000 + oO0o0ooO0
     if 63 - 63: OOooOOo % Oooo0Ooo000 * o0000oOoOoO0o + Oooo0Ooo000 / ii11ii1ii % O0ooOooooO
     if 45 - 45: i1I111II1I
     if 20 - 20: OoooooooOO * o0000oOoOoO0o * O0 . IIII
     if 78 - 78: iIii1I11I1II1 + O0oO - o0oO0 * Oooo0Ooo000 - OoooooooOO % OoOO0ooOOoo0O
     if 34 - 34: O0
     if 80 - 80: i1IIi - ii11ii1ii / OoOO - i11iIiiIii
     if 68 - 68: oO0o0ooO0 - o00O0oo % O0 % Oooo0Ooo000
     if 11 - 11: O0 / OoOO % IIII + o0000oOoOoO0o + iIii1I11I1II1
     if 40 - 40: iI - IIII . o0oO0 * ii11ii1ii % Oooo0Ooo000
     if 56 - 56: i11iIiiIii . o0000oOoOoO0o - OOooOOo * O0oO
     if 91 - 91: oO0o0ooO0 + OoooooooOO - i1IIi
     if 84 - 84: o0oO0 / i1I111II1I
     if 86 - 86: OoOO0ooOOoo0O * II111iiii - O0 . OoOO0ooOOoo0O % iIii1I11I1II1 / IIII
     if 11 - 11: OOooOOo * oO0o0ooO0 + o00O0oo / o00O0oo
     if 37 - 37: i11iIiiIii + i1IIi
     if 23 - 23: O0ooOooooO + O0oO . OoOO0ooOOoo0O * OOooOOo + o00O0oo
     if 18 - 18: i1I111II1I * o0000oOoOoO0o . i1I111II1I / O0
 except :
  pass
  if 8 - 8: o0000oOoOoO0o
  if 4 - 4: o00O0oo + o00O0oo * iI - OoOO0ooOOoo0O
def o00o ( ) :
 if 47 - 47: o0000oOoOoO0o + O0ooOooooO - oO0o0ooO0 % OoooooooOO
 try :
  if 52 - 52: Oooo0Ooo000 / iI - O0oO
  iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
  OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 49 - 49: OoOO0ooOOoo0O / ii11ii1ii . i11iIiiIii
  I1IIIiii1 = IiIi ( I1iIIiiIIi1i )
  OOOOO0O00 = re . compile ( oOooO0 ) . findall ( I1IIIiii1 )
  for O00oo , O0OO00O0oOO , Ii1iI111 in OOOOO0O00 :
   if re . search ( OOO00O , Ii1iI111 ) :
    if 21 - 21: OoOO0ooOOoo0O + i11iIiiIii + OOooOOo * o0000oOoOoO0o % O0ooOooooO % II111iiii
    if iiII1i1 == O00oo and o00oOO0o == O0OO00O0oOO and OOO00O == Ii1iI111 :
     if 55 - 55: ii11ii1ii - IIII
     oO0OoO00o ( '[COLOR %s]Buscar Serie[/COLOR]' % iIIIi1 , 'search' , 145 , O0OO00o0OO , oo00 )
     if 84 - 84: Oooo0Ooo000 + ii11ii1ii - OoOO0ooOOoo0O * OoOO0ooOOoo0O
     OoooO0o ( )
     if 24 - 24: OoOO0ooOOoo0O % i1IIi + O0ooOooooO . i11iIiiIii . o00O0oo
     oO0OoO00o ( '[COLOR %s]En emision[/COLOR]' % iIIIi1 , IIIII11I1IiI , 150 , I11II1i , oo00 )
     oO0OoO00o ( '[COLOR %s]Mejor valoradas[/COLOR]' % iIIIi1 , IIIII11I1IiI , 151 , IIIII , oo00 )
     oO0OoO00o ( '[COLOR %s]Series Retro[/COLOR]' % iIIIi1 , IIIII11I1IiI , 152 , ooooooO0oo , oo00 )
     oO0OoO00o ( '[COLOR %s]Todas[/COLOR]' % iIIIi1 , IIIII11I1IiI , 142 , I11i1 , oo00 )
     if 17 - 17: o00O0oo . II111iiii . iI / o00O0oo
     if 57 - 57: O0oO
 except :
  pass
  if 67 - 67: OoOO . iI
  if 87 - 87: oO0o0ooO0 % o0oO0
  if 83 - 83: II111iiii - O0oO
def OoooO0o ( ) :
 if 35 - 35: i1IIi - iIii1I11I1II1 + i1IIi
 OooOOo0 = 'aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtLw==' . decode ( 'base64' )
 ooO000O = 'Y29uZGljaW9uLnR4dA==' . decode ( 'base64' )
 OOOoO000 = OooOOo0 + ooO000O
 oOIII111iiIi1 = '[\'"](.*?)[\'"]'
 o00o = IiIi ( OOOoO000 )
 OOOOO0O00 = re . compile ( oOIII111iiIi1 ) . findall ( o00o )
 for Ii11Ii in OOOOO0O00 :
  try :
   if 1 - 1: OOooOOo % OoooooooOO + II111iiii - i1I111II1I
   if Ii11Ii == 'si' :
    if 43 - 43: IIII / OoOO % o0oO0
    oO0OoO00o ( '[COLOR %s]Hay Nuevos Episodios[/COLOR]' % iIIIi1 , IIIII11I1IiI , 155 , OOOO , oo00 )
    if 49 - 49: II111iiii - OOooOOo / O0oO
   elif Ii11Ii == 'no' :
    if 74 - 74: O0oO - IIII + i1IIi . OOooOOo + IIII - O0oO
    oO0OoO00o ( '[COLOR %s]No hay Nuevos Episodios[/COLOR]' % iIIIi1 , IIIII11I1IiI , 155 , oOoOooOo0o0 , oo00 )
    if 17 - 17: O0 . Oooo0Ooo000 . O0 + O0 / ii11ii1ii . iI
   return
   if 62 - 62: o00O0oo % O0ooOooooO * OoOO - i1IIi
  except :
   pass
   if 66 - 66: i11iIiiIii / o0000oOoOoO0o - OoooooooOO / i1IIi . i11iIiiIii
def IIIII1iii11 ( ) :
 if 35 - 35: oO0o0ooO0 / Oooo0Ooo000 / II111iiii - iIii1I11I1II1 + II111iiii . Oooo0Ooo000
 if 81 - 81: O0ooOooooO * IIII - o00O0oo * o0oO0 % OoOO0ooOOoo0O * OoOO0ooOOoo0O
 try :
  if 59 - 59: iIii1I11I1II1
  I1ii1Ii1ii11i = IiIi ( iiI )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( I1ii1Ii1ii11i )
  for Iii in OOOOO0O00 :
   if 94 - 94: i1I111II1I + Oooo0Ooo000 / IIII
   try :
    if 91 - 91: O0oO / i1IIi * i1IIi
    Ii1 = Iii
    ooO = xbmc . Keyboard ( '' , 'Buscar' )
    ooO . doModal ( )
    if ( ooO . isConfirmed ( ) ) :
     ii = xbmcgui . DialogProgress ( )
     ii . create ( 'Realstream:' , 'Buscando ...' )
     OO0O0Ooo = range ( 0 , 69 )
     for oOoO0 in OO0O0Ooo :
      oOoO0 = oOoO0 + 1
     Oo00o0OO0O00o = urllib . quote_plus ( ooO . getText ( ) ) . replace ( '+' , ' ' )
     O0Oooo = IiIi ( Ii1 )
     OOOOO0O00 = re . compile ( OoO ) . findall ( O0Oooo )
     for O0OoOOO00 , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
      ii . update ( oOoO0 , '[COLOR orange]Realstream: Buscando ...[/COLOR]' , '[COLOR gold] %s [/COLOR]' % I1i11111i1i11 )
      xbmc . sleep ( 5 )
      if ii . iscanceled ( ) : break ;
      if re . search ( Oo00o0OO0O00o , iIi1i1iIi1iI ( I1i11111i1i11 . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       if 87 - 87: Oooo0Ooo000 * i1IIi / o00O0oo
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Generando listado ...  [COLOR orange] Por favor espere ![/COLOR] , 4000)" )
       IIII1i1 ( I1i11111i1i11 , OOoOOO0 , 143 , O0OoOOO00 , oo00 , I1IIIiIiIi )
       ii . update ( 100 , '[COLOR orange]Realstream: [/COLOR]' , '[COLOR gold] Busqueda finalizada ...[/COLOR]' )
       xbmc . sleep ( 2000 )
       ii . close ( )
     oO0OoO00o ( '[COLOR %s]Buscar Serie[/COLOR]' % iIIIi1 , 'search' , 145 , O0OO00o0OO , oo00 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Sin Resultados para: [COLOR orange]" + Oo00o0OO0O00o + "[/COLOR] , 2000)" )
     if 70 - 70: i11iIiiIii % o00O0oo / OOooOOo
     if 62 - 62: i1IIi - OoOO0ooOOoo0O
   except : oO0OoO00o ( '[COLOR %s]Buscar Serie[/COLOR]' % iIIIi1 , 'search' , 145 , O0OO00o0OO , oo00 )
   if 62 - 62: i1IIi + ii11ii1ii % i1I111II1I
 except :
  pass
  if 28 - 28: o00O0oo . i1IIi
def iIIi ( ) :
 if 96 - 96: O0ooOooooO
 try :
  if 18 - 18: O0ooOooooO * O0oO - o0oO0
  I1ii1Ii1ii11i = IiIi ( IIi1IIIi )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( I1ii1Ii1ii11i )
  for Iii in OOOOO0O00 :
   if 31 - 31: ii11ii1ii - O0 % OoOO0ooOOoo0O % oO0o0ooO0
   try :
    if 45 - 45: o00O0oo + II111iiii * i11iIiiIii
    Ii1 = Iii
    if 13 - 13: OoooooooOO * oO0o0ooO0 - o0oO0 / IIII + O0oO + i1I111II1I
   except :
    pass
    if 39 - 39: iIii1I11I1II1 - OoooooooOO
  O0Oooo = IiIi ( Ii1 )
  OOOOO0O00 = re . compile ( OoO ) . findall ( O0Oooo )
  for O0OoOOO00 , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 81 - 81: o00O0oo - O0 * OoooooooOO
    IIII1i1 ( I1i11111i1i11 , OOoOOO0 , 143 , O0OoOOO00 , oo00 , I1IIIiIiIi )
    if 23 - 23: II111iiii / oO0o0ooO0
   except :
    pass
 except :
  pass
  if 28 - 28: ii11ii1ii * iI - OoOO
def iI11iiii1I ( ) :
 if 3 - 3: O0 % OoooooooOO / IIII
 try :
  if 89 - 89: II111iiii / oO0o0ooO0
  I1ii1Ii1ii11i = IiIi ( oOoO00o )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( I1ii1Ii1ii11i )
  for Iii in OOOOO0O00 :
   if 14 - 14: IIII . OOooOOo * iI + II111iiii - iI + IIII
   try :
    if 18 - 18: oO0o0ooO0 - o0000oOoOoO0o - OOooOOo - OOooOOo
    Ii1 = Iii
    if 54 - 54: ii11ii1ii + OOooOOo / O0ooOooooO . OOooOOo * OoOO0ooOOoo0O
   except :
    pass
    if 1 - 1: OoOO0ooOOoo0O * OoOO . i1IIi / ii11ii1ii . o00O0oo + ii11ii1ii
  O0Oooo = IiIi ( Ii1 )
  OOOOO0O00 = re . compile ( OoO ) . findall ( O0Oooo )
  for O0OoOOO00 , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 17 - 17: ii11ii1ii + OoOO / o0oO0 / O0ooOooooO * IIII
    IIII1i1 ( I1i11111i1i11 , OOoOOO0 , 143 , O0OoOOO00 , oo00 , I1IIIiIiIi )
    if 29 - 29: OoOO % OoooooooOO * oO0o0ooO0 / II111iiii - oO0o0ooO0
   except :
    pass
 except :
  pass
  if 19 - 19: i11iIiiIii
  if 54 - 54: II111iiii . O0oO
def oOO ( ) :
 if 32 - 32: OoOO0ooOOoo0O * OOooOOo % iI * o0oO0 . O0
 try :
  if 48 - 48: O0ooOooooO * O0ooOooooO
  I1ii1Ii1ii11i = IiIi ( ooO0OoOO )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( I1ii1Ii1ii11i )
  for Iii in OOOOO0O00 :
   if 13 - 13: o0oO0 / O0oO + OoOO0ooOOoo0O . o0000oOoOoO0o % iI
   try :
    if 48 - 48: OOooOOo / i11iIiiIii - o0000oOoOoO0o * oO0o0ooO0 / OoooooooOO
    Ii1 = Iii
    if 89 - 89: iIii1I11I1II1 / OOooOOo - II111iiii / o0oO0 . i11iIiiIii . o0oO0
   except :
    pass
    if 48 - 48: O0 + O0 . Oooo0Ooo000 - iI
  O0Oooo = IiIi ( Ii1 )
  OOOOO0O00 = re . compile ( OoO ) . findall ( O0Oooo )
  for O0OoOOO00 , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 63 - 63: oO0o0ooO0
    IIII1i1 ( I1i11111i1i11 , OOoOOO0 , 143 , O0OoOOO00 , oo00 , I1IIIiIiIi )
    if 71 - 71: i1IIi . o0oO0 * O0ooOooooO % OoooooooOO + IIII
   except :
    pass
 except :
  pass
  if 36 - 36: i1I111II1I
def i1iiI ( ) :
 if 74 - 74: Oooo0Ooo000 % o00O0oo
 try :
  if 7 - 7: II111iiii
  I1ii1Ii1ii11i = IiIi ( i1iI1 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( I1ii1Ii1ii11i )
  for Iii in OOOOO0O00 :
   if 27 - 27: oO0o0ooO0 . OoooooooOO + i11iIiiIii
   try :
    if 86 - 86: O0oO / o0000oOoOoO0o - o0000oOoOoO0o + o00O0oo + oO0o0ooO0
    Ii1 = Iii
    if 33 - 33: o0000oOoOoO0o . O0ooOooooO . i1I111II1I . i1IIi
   except :
    pass
    if 49 - 49: o00O0oo
  O0Oooo = IiIi ( Ii1 )
  OOOOO0O00 = re . compile ( OoO ) . findall ( O0Oooo )
  for O0OoOOO00 , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 84 - 84: O0oO - ii11ii1ii / O0 - Oooo0Ooo000
    IIII1i1 ( I1i11111i1i11 , OOoOOO0 , 143 , O0OoOOO00 , oo00 , I1IIIiIiIi )
    if 21 - 21: O0 * O0 % o00O0oo
   except :
    pass
 except :
  pass
  if 94 - 94: O0oO + II111iiii % i11iIiiIii
def i1i1IiIiIi1Ii ( ) :
 if 64 - 64: IIII + OoooooooOO * OoooooooOO
 try :
  if 41 - 41: iI . ii11ii1ii + OOooOOo
  I1ii1Ii1ii11i = IiIi ( iiI )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( I1ii1Ii1ii11i )
  for Iii in OOOOO0O00 :
   if 100 - 100: o0oO0 + OoOO
   try :
    if 73 - 73: i1IIi - Oooo0Ooo000 % iI / OoOO
    Ii1 = Iii
    if 40 - 40: o00O0oo * iI - OOooOOo / i1I111II1I / i11iIiiIii
   except :
    pass
    if 83 - 83: o00O0oo / Oooo0Ooo000 - i11iIiiIii . iIii1I11I1II1 + ii11ii1ii
  O0Oooo = IiIi ( Ii1 )
  OOOOO0O00 = re . compile ( OoO ) . findall ( O0Oooo )
  for O0OoOOO00 , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 59 - 59: O0 % ii11ii1ii
    IIII1i1 ( I1i11111i1i11 , OOoOOO0 , 143 , O0OoOOO00 , oo00 , I1IIIiIiIi )
    if 92 - 92: o0oO0 % O0ooOooooO / o00O0oo % o00O0oo * OOooOOo
   except :
    pass
 except :
  pass
  if 74 - 74: O0 . OOooOOo % OoOO % i1I111II1I
def oOo0OooOo ( name , url ) :
 if 51 - 51: O0oO . ii11ii1ii
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 45 - 45: i1IIi - ii11ii1ii / O0 . o00O0oo
 iI1 = IiIi ( url )
 OOOOO0O00 = re . compile ( iiiIi1 ) . findall ( iI1 )
 for O0OoOOO00 , name , oo00 , url in OOOOO0O00 :
  try :
   if 14 - 14: o00O0oo
   if 49 - 49: oO0o0ooO0 / i1IIi % o0oO0 . OOooOOo
   O00OOOoOoo0O = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % O00OOOoOoo0O + name + '[/COLOR]'
   oOOoOoo0O0 ( name , url , 144 , O0OoOOO00 , oo00 )
   if 45 - 45: i11iIiiIii
   if 82 - 82: o0oO0 + i1I111II1I
  except :
   pass
   if 12 - 12: Oooo0Ooo000
   if 93 - 93: i11iIiiIii % iIii1I11I1II1 % i11iIiiIii + o0000oOoOoO0o / o0000oOoOoO0o / II111iiii
   if 49 - 49: IIII . o00O0oo . i11iIiiIii - II111iiii / o0oO0
def oOOoOoo0O0 ( name , url , mode , iconimage , fanart ) :
 if 62 - 62: IIII
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 1 - 1: i1I111II1I / i1I111II1I - i11iIiiIii
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage="
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 iII . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 iII . setProperty ( 'fanart_image' , fanart )
 iII . setProperty ( 'IsPlayable' , 'true' )
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII )
 return oO0O000oOoo0O
 if 9 - 9: oO0o0ooO0 * i1IIi - i1IIi
 if 16 - 16: OOooOOo * i1IIi - o0000oOoOoO0o . i1I111II1I % O0oO / o0000oOoOoO0o
def Ii11iI1ii1111 ( name , url ) :
 if 42 - 42: Oooo0Ooo000 + Oooo0Ooo000 * II111iiii
 if 78 - 78: OoooooooOO
 IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 o00O0 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 oOO0O00Oo0O0o = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 OOoo0 = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 iiII1i11i = IiIi ( oOO0O00Oo0O0o )
 OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
 for III1I1I in OOOOO0O00 :
  if 14 - 14: o0oO0 . i11iIiiIii
  try :
   if 27 - 27: iI % O0 % Oooo0Ooo000
   if 99 - 99: OOooOOo + i1IIi + i11iIiiIii + ii11ii1ii % oO0o0ooO0 / O0oO
   IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 60 - 60: o0oO0 * OoOO0ooOOoo0O - i11iIiiIii % iI
   if 52 - 52: o00O0oo % oO0o0ooO0 - i11iIiiIii
   if IIIi1I1IIii1II == III1I1I :
    if 30 - 30: O0ooOooooO / OoOO + oO0o0ooO0
    if 6 - 6: O0ooOooooO . O0oO + o0oO0 . Oooo0Ooo000
    if 'https://team.com' in url :
     if 70 - 70: OoOO
     url = url . replace ( 'https://team.com' , 'https://verystream.com' )
     if 46 - 46: O0oO - i1IIi
    if 'https://mybox.com' in url :
     if 46 - 46: Oooo0Ooo000 % o0oO0
     url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
     if 72 - 72: iIii1I11I1II1
     if 45 - 45: ii11ii1ii - o0000oOoOoO0o % Oooo0Ooo000
    if 'https://vidcloud.co/' in url :
     if 38 - 38: Oooo0Ooo000 % IIII - OoooooooOO
     url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
     if 87 - 87: OoOO % OOooOOo
    if 'https://gounlimited.to' in url :
     if 77 - 77: iIii1I11I1II1 - i1IIi . oO0o0ooO0
     url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
     if 26 - 26: o0000oOoOoO0o * i1I111II1I . i1IIi
    if 'https://drive.com' in url :
     if 59 - 59: O0 + i1IIi - o0000oOoOoO0o
     url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
     if 62 - 62: i11iIiiIii % IIII . i1I111II1I . IIII
     if 84 - 84: i11iIiiIii * OoOO
    import resolveurl
    if 18 - 18: IIII - o0oO0 - OoOO0ooOOoo0O / Oooo0Ooo000 - O0
    iiIIii = urlresolver . HostedMediaFile ( url )
    if 70 - 70: o0000oOoOoO0o - IIII
    if not iiIIii :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
     return False
     if 62 - 62: O0oO
    try :
     ii = xbmcgui . DialogProgress ( )
     ii . create ( 'Realstream:' , 'Iniciando ...' )
     ii . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
     xbmc . sleep ( 1000 )
     O000oOo = iiIIii . resolve ( )
     if not O000oOo or not isinstance ( O000oOo , basestring ) :
      try : OoOOOO = O000oOo . msg
      except : OoOOOO = url
      raise Exception ( OoOOOO )
      if 18 - 18: iI % i11iIiiIii . iIii1I11I1II1 - O0ooOooooO
    except Exception as oOOOO :
     try : OoOOOO = str ( oOOOO )
     except : OoOOOO = url
     ii . update ( 45 , 'RESOLVEURL:' , 'Reiniciando ... ' )
     xbmc . sleep ( 1000 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Episodio no disponible.  ,3000)" )
     ii . close ( )
     if 80 - 80: OOooOOo + oO0o0ooO0 - i1IIi . o0oO0 / o0000oOoOoO0o / OOooOOo
    ii . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    ii . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
    xbmc . sleep ( 500 )
    ii . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
    xbmc . sleep ( 500 )
    ii . update ( 100 , 'RESOLVEURL:' , 'Disfrute de este capitulo!' )
    ii . close ( )
    O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
    I1Iiii = xbmcgui . ListItem ( path = O000oOo )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1Iiii )
    if 34 - 34: o0oO0 * OoOO0ooOOoo0O - i1I111II1I - OOooOOo - o0oO0
    if 42 - 42: II111iiii * OOooOOo % i1IIi - o0oO0 % i1I111II1I
   else :
    if 36 - 36: i11iIiiIii / oO0o0ooO0 * o00O0oo * o00O0oo + o0oO0 * O0oO
    O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
    if O0ii1ii1ii == 'true' :
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Por favor compruebe los ajustes de realstream.[/COLOR]" , "[COLOR white] Desde la seccion Tutoriales puede sacarle mayor partido a su Realstream, tambien puede configurarlo a su gusto. [/COLOR]" , "[COLOR gold]El addon no esta activado o bien configurado.[/COLOR]" )
     if 32 - 32: OoOO
     iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
     oO0OoO00o ( '[COLOR %s]Video tutoriales[/COLOR]' % iIIIi1 , IIIII11I1IiI , 125 , O0OOO0OOoO0O , oo00 )
  except :
   pass
   if 50 - 50: iI + i1IIi
   if 31 - 31: o0oO0
   if 78 - 78: i11iIiiIii + o0000oOoOoO0o + Oooo0Ooo000 / o0000oOoOoO0o % iIii1I11I1II1 % i1I111II1I
   if 83 - 83: iIii1I11I1II1 % OoOO0ooOOoo0O % o0000oOoOoO0o % Oooo0Ooo000 . o00O0oo % O0
iIiIi1ii = '10011hI' . replace ( '10011hI' , '1hI' )
iiiiiII = 'aHR0cDovL2JpdC5seS8yUUJQ' . decode ( 'base64' ) + iIiIi1ii
ii1ii = '1001j1G' . replace ( '1001j1G' , 'j1G' )
IIiI1i = 'aHR0cDovL2JpdC5seS8zNXpw' . decode ( 'base64' ) + ii1ii
iII1 = '1001N00' . replace ( '1001N00' , 'N00' )
O000O = 'aHR0cDovL2JpdC5seS8zMGRS' . decode ( 'base64' ) + iII1
Oo00OO0 = '1001Q7q' . replace ( '1001Q7q' , 'Q7q' )
oo0O = 'aHR0cDovL2JpdC5seS8zN1Bi' . decode ( 'base64' ) + Oo00OO0
if 92 - 92: IIII % i1I111II1I % OoOO0ooOOoo0O
def iIi1Ii ( ) :
 if 11 - 11: OOooOOo % o0oO0 - OoOO - oO0o0ooO0 + o0000oOoOoO0o
 if 98 - 98: O0ooOooooO + o0oO0 - OoOO
 try :
  if 79 - 79: IIII / Oooo0Ooo000 . OoOO0ooOOoo0O - o00O0oo
  I1ii1Ii1ii11i = IiIi ( iiiiiII )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( I1ii1Ii1ii11i )
  for Iii in OOOOO0O00 :
   if 47 - 47: OoooooooOO % O0 * O0ooOooooO . o0oO0
   try :
    if 38 - 38: O0 - i1I111II1I % Oooo0Ooo000
    Ii1 = Iii
    ooO = xbmc . Keyboard ( '' , 'Buscar' )
    ooO . doModal ( )
    if ( ooO . isConfirmed ( ) ) :
     ii = xbmcgui . DialogProgress ( )
     ii . create ( 'Realstream:' , 'Buscando ...' )
     OO0O0Ooo = range ( 0 , 69 )
     for oOoO0 in OO0O0Ooo :
      oOoO0 = oOoO0 + 1
     Oo00o0OO0O00o = urllib . quote_plus ( ooO . getText ( ) ) . replace ( '+' , ' ' )
     O0Oooo = IiIi ( Ii1 )
     OOOOO0O00 = re . compile ( I1iI1 ) . findall ( O0Oooo )
     for O0OoOOO00 , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
      ii . update ( oOoO0 , '[COLOR orange]Realstream: Buscando ...[/COLOR]' , '[COLOR gold] %s [/COLOR]' % I1i11111i1i11 )
      xbmc . sleep ( 5 )
      if ii . iscanceled ( ) : break ;
      if re . search ( Oo00o0OO0O00o , iIi1i1iIi1iI ( I1i11111i1i11 . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       if 64 - 64: iIii1I11I1II1
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Generando listado ...  [COLOR orange] Por favor espere ![/COLOR] , 4000)" )
       IIII1i1 ( I1i11111i1i11 , OOoOOO0 , 147 , O0OoOOO00 , oo00 , I1IIIiIiIi )
       ii . update ( 100 , '[COLOR orange]Realstream: [/COLOR]' , '[COLOR gold] Busqueda finalizada ...[/COLOR]' )
       xbmc . sleep ( 2000 )
       ii . close ( )
     oO0OoO00o ( '[COLOR %s]Buscar Pelicula[/COLOR]' % iIIIi1 , 'search' , 146 , O0OO00o0OO , oo00 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Sin Resultados para: [COLOR orange]" + Oo00o0OO0O00o + "[/COLOR] , 2000)" )
     if 15 - 15: o00O0oo + IIII / o00O0oo / Oooo0Ooo000
     if 31 - 31: iI + O0 + iI . iIii1I11I1II1 + ii11ii1ii / o0000oOoOoO0o
   except : oO0OoO00o ( '[COLOR %s]Buscar Pelicula[/COLOR]' % iIIIi1 , 'search' , 146 , O0OO00o0OO , oo00 )
   if 6 - 6: ii11ii1ii % i1I111II1I * O0oO / OOooOOo + ii11ii1ii
 except :
  pass
  if 39 - 39: OoOO0ooOOoo0O - ii11ii1ii / O0ooOooooO * OoooooooOO
def Oooo0oOOO0 ( ) :
 if 61 - 61: o0000oOoOoO0o / OoOO0ooOOoo0O - ii11ii1ii
 try :
  if 19 - 19: O0ooOooooO - o0000oOoOoO0o / o0000oOoOoO0o + ii11ii1ii
  I1ii1Ii1ii11i = IiIi ( iiiiiII )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( I1ii1Ii1ii11i )
  for Iii in OOOOO0O00 :
   if 98 - 98: iIii1I11I1II1 % IIII + O0oO . iI
   try :
    if 99 - 99: O0 + O0 * O0oO + O0 * oO0o0ooO0
    Ii1 = Iii
    if 80 - 80: OOooOOo . o0oO0
   except :
    pass
    if 47 - 47: O0oO + iI + II111iiii % i11iIiiIii
  O0Oooo = IiIi ( Ii1 )
  OOOOO0O00 = re . compile ( I1iI1 ) . findall ( O0Oooo )
  for O0OoOOO00 , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 93 - 93: o00O0oo % OoOO0ooOOoo0O . O0 / O0ooOooooO * oO0o0ooO0
    IIII1i1 ( I1i11111i1i11 , OOoOOO0 , 147 , O0OoOOO00 , oo00 , I1IIIiIiIi )
    if 29 - 29: o0000oOoOoO0o
   except :
    pass
 except :
  pass
  if 86 - 86: II111iiii . i1I111II1I
def iIiI ( ) :
 if 81 - 81: OoOO0ooOOoo0O % o0oO0
 try :
  if 87 - 87: iIii1I11I1II1 . OoooooooOO * OoOO0ooOOoo0O
  I1ii1Ii1ii11i = IiIi ( IIiI1i )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( I1ii1Ii1ii11i )
  for Iii in OOOOO0O00 :
   if 100 - 100: OoOO / i1IIi - OOooOOo % o0oO0 - iIii1I11I1II1
   try :
    if 17 - 17: O0oO / o0000oOoOoO0o % ii11ii1ii
    Ii1 = Iii
    if 71 - 71: i1I111II1I . Oooo0Ooo000 . OoOO
   except :
    pass
    if 68 - 68: i11iIiiIii % oO0o0ooO0 * OoOO * i1I111II1I * II111iiii + O0
  O0Oooo = IiIi ( Ii1 )
  OOOOO0O00 = re . compile ( I1iI1 ) . findall ( O0Oooo )
  for O0OoOOO00 , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 66 - 66: O0oO % o00O0oo % OoooooooOO
    IIII1i1 ( I1i11111i1i11 , OOoOOO0 , 147 , O0OoOOO00 , oo00 , I1IIIiIiIi )
    if 34 - 34: o0000oOoOoO0o / O0ooOooooO % O0 . OoOO . i1IIi
   except :
    pass
 except :
  pass
  if 29 - 29: O0 . Oooo0Ooo000
def OO0o0oO0O000o ( ) :
 if 47 - 47: Oooo0Ooo000 - OoOO / o0oO0 * OoooooooOO / o0oO0 . ii11ii1ii
 try :
  if 34 - 34: iI
  I1ii1Ii1ii11i = IiIi ( O000O )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( I1ii1Ii1ii11i )
  for Iii in OOOOO0O00 :
   if 27 - 27: Oooo0Ooo000 + OoooooooOO - OoOO0ooOOoo0O
   try :
    if 15 - 15: oO0o0ooO0 / O0oO * O0 . II111iiii - OoOO
    Ii1 = Iii
    if 90 - 90: oO0o0ooO0
   except :
    pass
    if 94 - 94: O0oO / o00O0oo * Oooo0Ooo000 - OoOO0ooOOoo0O
  O0Oooo = IiIi ( Ii1 )
  OOOOO0O00 = re . compile ( I1iI1 ) . findall ( O0Oooo )
  for O0OoOOO00 , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 44 - 44: o0oO0 % i11iIiiIii - O0ooOooooO * o00O0oo + ii11ii1ii * IIII
    IIII1i1 ( I1i11111i1i11 , OOoOOO0 , 147 , O0OoOOO00 , oo00 , I1IIIiIiIi )
    if 41 - 41: O0 * iI - OoOO0ooOOoo0O . o0oO0
   except :
    pass
 except :
  pass
  if 65 - 65: ii11ii1ii . OoooooooOO
def OOoO0oo0O ( ) :
 if 49 - 49: o0000oOoOoO0o
 try :
  if 31 - 31: OoOO * i11iIiiIii * o0oO0 . i11iIiiIii
  I1ii1Ii1ii11i = IiIi ( oo0O )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( I1ii1Ii1ii11i )
  for Iii in OOOOO0O00 :
   if 12 - 12: OoOO0ooOOoo0O % i1I111II1I % o00O0oo . i11iIiiIii * iIii1I11I1II1
   try :
    if 66 - 66: i11iIiiIii * iIii1I11I1II1 % OoooooooOO
    Ii1 = Iii
    if 5 - 5: OoOO0ooOOoo0O % OoooooooOO
   except :
    pass
    if 60 - 60: OoOO0ooOOoo0O . i1IIi % OoOO % iI % IIII
  O0Oooo = IiIi ( Ii1 )
  OOOOO0O00 = re . compile ( I1iI1 ) . findall ( O0Oooo )
  for O0OoOOO00 , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 33 - 33: iIii1I11I1II1 - o0oO0 * o00O0oo % iIii1I11I1II1 + OoOO . IIII
    IIII1i1 ( I1i11111i1i11 , OOoOOO0 , 147 , O0OoOOO00 , oo00 , I1IIIiIiIi )
    if 56 - 56: i11iIiiIii * O0ooOooooO . oO0o0ooO0
   except :
    pass
 except :
  pass
  if 78 - 78: OoOO0ooOOoo0O
  if 1 - 1: IIII . i1I111II1I
  if 42 - 42: IIII % oO0o0ooO0 / OoOO - oO0o0ooO0 * i11iIiiIii
def iI1IiiiIiI1Ii ( name , url ) :
 if 78 - 78: OoooooooOO / IIII % OoOO0ooOOoo0O * OoooooooOO
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 68 - 68: oO0o0ooO0
 iI1 = IiIi ( url )
 OOOOO0O00 = re . compile ( i1I1ii11i1Iii ) . findall ( iI1 )
 for O0OoOOO00 , name , oo00 , url , id in OOOOO0O00 :
  try :
   if 29 - 29: O0ooOooooO + i11iIiiIii % O0oO
   O00OOOoOoo0O = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % O00OOOoOoo0O + name + '[/COLOR]'
   oOo00Ooo0o0 ( name , url , 130 , O0OoOOO00 , oo00 , id )
   if 33 - 33: O0oO
   if 87 - 87: OoOO0ooOOoo0O / i1I111II1I + iIii1I11I1II1
  except :
   pass
   if 93 - 93: iIii1I11I1II1 + oO0o0ooO0 % iI
def oOo00Ooo0o0 ( name , url , mode , iconimage , fanart , id ) :
 if 21 - 21: IIII
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 6 - 6: i1I111II1I
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + "&id=" + str ( id )
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 iII . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 iII . setProperty ( 'fanart_image' , fanart )
 iII . setProperty ( 'IsPlayable' , 'true' )
 i1I1II = [ ]
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  i1I1II . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 17 - 17: O0 * OoOO0ooOOoo0O * o00O0oo * II111iiii * O0oO % i1IIi
  iII . addContextMenuItems ( i1I1II , replaceItems = True )
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII )
 return oO0O000oOoo0O
 if 33 - 33: o00O0oo * o00O0oo . iI . i11iIiiIii
def IIIIiIi11iiIi ( ) :
 if 48 - 48: i1I111II1I % O0oO
 if 3 - 3: i1I111II1I % o0oO0 + ii11ii1ii
 Ii1iiIi1I11i = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 Ii1iiIi1I11i . doModal ( )
 if not Ii1iiIi1I11i . isConfirmed ( ) :
  return None ;
 I1i11111i1i11 = Ii1iiIi1I11i . getText ( ) . strip ( )
 if 89 - 89: Oooo0Ooo000 . i1I111II1I % ii11ii1ii . ii11ii1ii - OoooooooOO
 if 56 - 56: O0oO
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 21 - 21: iIii1I11I1II1 / Oooo0Ooo000 + iI - O0oO / ii11ii1ii / II111iiii
  oOI11 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + I1i11111i1i11 + '&language=es-ES' ) )
  if 54 - 54: o0oO0 - Oooo0Ooo000
  if 81 - 81: i1I111II1I . O0 + II111iiii * iIii1I11I1II1 * IIII / OoOO0ooOOoo0O
  return 'android'
  if 88 - 88: II111iiii - o0000oOoOoO0o * OOooOOo . OoOO
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 65 - 65: i1I111II1I . i1IIi
  oOI11 = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + I1i11111i1i11 + '&language=es-ES' )
  if 95 - 95: OOooOOo + OOooOOo - IIII - O0ooOooooO
  if 45 - 45: o0oO0 . OoooooooOO
  return 'windows'
  if 27 - 27: o0oO0 * ii11ii1ii . OoOO0ooOOoo0O
  if 17 - 17: II111iiii % O0ooOooooO * IIII % i1IIi . OOooOOo . iIii1I11I1II1
def iiiIIIii ( ) :
 if 93 - 93: iIii1I11I1II1 + OOooOOo + i11iIiiIii
 try :
  if 74 - 74: O0oO / II111iiii + iI * iIii1I11I1II1 - Oooo0Ooo000 - OoOO
  iiII1i11i = IiIi ( iIiIi11 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 69 - 69: iIii1I11I1II1 * OOooOOo - O0ooOooooO + O0 + O0
   try :
    if 65 - 65: Oooo0Ooo000 / i11iIiiIii / OoOO - IIII
    all = Iii
    if 9 - 9: OOooOOo / Oooo0Ooo000 - ii11ii1ii * iIii1I11I1II1
   except :
    pass
    if 86 - 86: II111iiii + iI + i1I111II1I
  iI1 = IiIi ( all )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iI1 )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    if 9 - 9: iI + II111iiii % iI % i1I111II1I + iIii1I11I1II1
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 59 - 59: i1IIi
   except :
    pass
 except :
  pass
  if 48 - 48: O0 * o0oO0 * OoOO . OoOO * O0oO - o0oO0
def iIi11i ( ) :
 if 56 - 56: i11iIiiIii . iI / O0ooOooooO
 try :
  if 48 - 48: OoOO * IIII + iIii1I11I1II1 / II111iiii
  iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
  OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 100 - 100: O0oO
  I1IIIiii1 = IiIi ( I1iIIiiIIi1i )
  OOOOO0O00 = re . compile ( oOooO0 ) . findall ( I1IIIiii1 )
  for O0OO00O0oOO , O00oo , Ii1iI111 in OOOOO0O00 :
   if re . search ( OOO00O , Ii1iI111 ) :
    if 59 - 59: oO0o0ooO0 * IIII + o0000oOoOoO0o . o00O0oo
    if iiII1i1 == O00oo and o00oOO0o == O0OO00O0oOO and OOO00O == Ii1iI111 :
     if 85 - 85: O0
     i1111 = IiIi ( iiiiI )
     OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( i1111 )
     for Iii in OOOOO0O00 :
      if 32 - 32: OoooooooOO . OoOO / ii11ii1ii * o0000oOoOoO0o / o0000oOoOoO0o * o0oO0
      try :
       if 19 - 19: o0oO0
       Ii1 = Iii
       if 55 - 55: IIII % IIII / O0 % O0ooOooooO - o0000oOoOoO0o . ii11ii1ii
      except :
       pass
       if 49 - 49: iIii1I11I1II1 * i1IIi . OoooooooOO
     O0Oooo = IiIi ( Ii1 )
     OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( O0Oooo )
     for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
      try :
       if 90 - 90: o0000oOoOoO0o % o00O0oo - iIii1I11I1II1 % OoOO0ooOOoo0O
       IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
       if 8 - 8: OoOO0ooOOoo0O * ii11ii1ii / i1I111II1I % o0oO0 - OOooOOo
      except :
       pass
       if 71 - 71: O0ooOooooO
    else :
     if 23 - 23: i1IIi . iIii1I11I1II1 . IIII . O0 % o0oO0 % i11iIiiIii
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Esta seccion ha sido cerrada![COLOR orange] Lo sentimos ...[/COLOR] ,5000)" )
     if 11 - 11: O0 - II111iiii . IIII . o0oO0 % Oooo0Ooo000
     return False
     if 21 - 21: ii11ii1ii / O0ooOooooO . Oooo0Ooo000 * OoooooooOO + O0oO - i1IIi
 except :
  pass
  if 58 - 58: o00O0oo
def ii1IoO0O ( ) :
 if 59 - 59: OoooooooOO * ii11ii1ii + i1IIi
 try :
  if 23 - 23: iI
  iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
  OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 13 - 13: iIii1I11I1II1
  I1IIIiii1 = IiIi ( I1iIIiiIIi1i )
  OOOOO0O00 = re . compile ( oOooO0 ) . findall ( I1IIIiii1 )
  for O00oo , O0OO00O0oOO , Ii1iI111 in OOOOO0O00 :
   if re . search ( OOO00O , Ii1iI111 ) :
    if 77 - 77: i11iIiiIii - iIii1I11I1II1 / oO0o0ooO0 / iI / OoOO
    if iiII1i1 == O00oo and o00oOO0o == O0OO00O0oOO and OOO00O == Ii1iI111 :
     if 56 - 56: OoooooooOO * O0
     i11 = IiIi ( OOoO )
     OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( i11 )
     for Iii in OOOOO0O00 :
      if 85 - 85: OoooooooOO % OoOO0ooOOoo0O * iIii1I11I1II1
      try :
       IiI = Iii
      except :
       pass
       if 60 - 60: Oooo0Ooo000
     iiII1i11i = IiIi ( IiI )
     OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
     for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
      try :
       if 98 - 98: iI
       IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
       if 34 - 34: iIii1I11I1II1 * O0oO * O0oO / o00O0oo
      except :
       pass
       if 28 - 28: OoOO - oO0o0ooO0 + OoOO0ooOOoo0O + o0oO0 / iIii1I11I1II1
    else :
     if 26 - 26: iIii1I11I1II1 - O0 . O0
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Esta seccion ha sido cerrada![COLOR orange] Lo sentimos ...[/COLOR] ,5000)" )
     if 68 - 68: IIII + oO0o0ooO0 . O0 . o0oO0 % i1IIi % IIII
     return False
 except :
  pass
  if 50 - 50: i1I111II1I + o0000oOoOoO0o
def o0OoOOo ( ) :
 if 56 - 56: O0oO / iIii1I11I1II1 + OoOO0ooOOoo0O % IIII . IIII - o00O0oo
 try :
  if 48 - 48: ii11ii1ii - iI + ii11ii1ii - OOooOOo * i11iIiiIii . O0ooOooooO
  iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
  OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 35 - 35: i1I111II1I . O0 + ii11ii1ii + IIII + i1IIi
  I1IIIiii1 = IiIi ( I1iIIiiIIi1i )
  OOOOO0O00 = re . compile ( oOooO0 ) . findall ( I1IIIiii1 )
  for O0OO00O0oOO , O00oo , Ii1iI111 in OOOOO0O00 :
   if re . search ( OOO00O , Ii1iI111 ) :
    if 65 - 65: O0 * OOooOOo / OOooOOo . OoOO0ooOOoo0O
    if iiII1i1 == O00oo and o00oOO0o == O0OO00O0oOO and OOO00O == Ii1iI111 :
     if 87 - 87: II111iiii * o00O0oo % ii11ii1ii * ii11ii1ii
     iiII1i11i = IiIi ( db2 )
     OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
     for Iii in OOOOO0O00 :
      if 58 - 58: IIII . o0000oOoOoO0o + OOooOOo % ii11ii1ii - OoOO
      try :
       if 50 - 50: O0ooOooooO % II111iiii - iI . i1IIi + O0 % O0ooOooooO
       i1iIi1IIiIII1 = Iii
       if 19 - 19: O0oO
      except :
       pass
       if 87 - 87: iI / OoOO0ooOOoo0O % o0000oOoOoO0o * oO0o0ooO0
       if 77 - 77: oO0o0ooO0 - ii11ii1ii - iIii1I11I1II1
     iiII1i11i = IiIi ( i1iIi1IIiIII1 )
     OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
     for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
      try :
       IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
       if 16 - 16: OoOO / O0ooOooooO / i1IIi . O0ooOooooO + oO0o0ooO0
      except :
       pass
    else :
     if 26 - 26: iIii1I11I1II1 + i1IIi / OoOO0ooOOoo0O % o00O0oo
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Esta seccion ha sido cerrada![COLOR orange] Lo sentimos ...[/COLOR] ,5000)" )
     if 44 - 44: OoooooooOO . II111iiii . IIII % OoooooooOO
     return False
     if 86 - 86: i11iIiiIii + O0 * i1I111II1I - OoOO * IIII + O0
 except :
  pass
  if 95 - 95: iIii1I11I1II1 . Oooo0Ooo000 % O0ooOooooO - Oooo0Ooo000 * II111iiii
def o0oooOoo0OoOO ( ) :
 if 38 - 38: OoOO / iI % Oooo0Ooo000 * O0oO + i11iIiiIii % iI
 try :
  if 61 - 61: Oooo0Ooo000 - o0oO0 % o00O0oo / iI / O0ooOooooO + iIii1I11I1II1
  O0O0oo = IiIi ( OOo0O0oo0OO0O )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( O0O0oo )
  for Iii in OOOOO0O00 :
   if 83 - 83: i1I111II1I / Oooo0Ooo000
   try :
    if 64 - 64: OoOO % i1I111II1I . Oooo0Ooo000 % OoOO + O0oO * i1I111II1I
    OOOO00OooO = Iii
    if 64 - 64: OoOO . OOooOOo - OoooooooOO . iI - O0ooOooooO
   except :
    pass
    if 77 - 77: o0oO0 % OoOO0ooOOoo0O / II111iiii % O0ooOooooO % OoooooooOO % OoOO
    if 19 - 19: i1I111II1I * Oooo0Ooo000 / oO0o0ooO0 * Oooo0Ooo000 - OoooooooOO * O0oO
  iiII1i11i = IiIi ( OOOO00OooO )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    if 17 - 17: II111iiii + ii11ii1ii . Oooo0Ooo000
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 12 - 12: Oooo0Ooo000 + IIII + O0oO . i1I111II1I / o0oO0
   except :
    pass
 except :
  pass
  if 29 - 29: i1I111II1I . iI - II111iiii
def ooooO0 ( ) :
 if 37 - 37: i11iIiiIii + OOooOOo . IIII % O0oO % O0oO
 try :
  if 26 - 26: O0
  iiII1i11i = IiIi ( iiIiI1i1 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 34 - 34: iI * Oooo0Ooo000
   try :
    if 97 - 97: i11iIiiIii % oO0o0ooO0 / ii11ii1ii / ii11ii1ii
    OoO00ooO = Iii
    if 15 - 15: i11iIiiIii
   except :
    pass
    if 13 - 13: O0oO * II111iiii * oO0o0ooO0 * II111iiii % i1I111II1I / OOooOOo
    if 100 - 100: i1I111II1I . o0oO0 - iIii1I11I1II1 . i11iIiiIii / II111iiii
  iiII1i11i = IiIi ( OoO00ooO )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 71 - 71: Oooo0Ooo000 * ii11ii1ii . O0oO
   except :
    pass
 except :
  pass
  if 49 - 49: i1I111II1I * O0 . i1I111II1I
def ii1II1II ( ) :
 if 42 - 42: o0oO0
 try :
  if 68 - 68: IIII . ii11ii1ii % iI - OoooooooOO * O0ooOooooO . IIII
  iiII1i11i = IiIi ( IiIi11iI )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 46 - 46: i11iIiiIii - IIII * OOooOOo * O0oO % o00O0oo * i1IIi
   try :
    if 5 - 5: O0 / iI . ii11ii1ii + OoooooooOO
    O0o = Iii
    if 78 - 78: IIII % iIii1I11I1II1
   except :
    pass
    if 50 - 50: OOooOOo % iIii1I11I1II1 % IIII
  iiII1i11i = IiIi ( O0o )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 84 - 84: i1I111II1I + o00O0oo + o0oO0 + O0ooOooooO
   except :
    pass
 except :
  pass
  if 62 - 62: i11iIiiIii + OoOO0ooOOoo0O + i1IIi
def oOOoO0O ( ) :
 if 15 - 15: Oooo0Ooo000
 try :
  if 85 - 85: i11iIiiIii / i11iIiiIii . OoOO . O0
  iiII1i11i = IiIi ( i11I1IiII1i1i )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 67 - 67: II111iiii / o0000oOoOoO0o . IIII . OoooooooOO
   try :
    if 19 - 19: i1I111II1I . o00O0oo / OoOO0ooOOoo0O
    O00ooOoOoooO000OO = Iii
    if 62 - 62: IIII + ii11ii1ii % iIii1I11I1II1 / iIii1I11I1II1 . iI . i1I111II1I
   except :
    pass
    if 21 - 21: OoOO - o0oO0 - OOooOOo / OoOO0ooOOoo0O
    if 48 - 48: OoooooooOO
  iiII1i11i = IiIi ( O00ooOoOoooO000OO )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 16 - 16: OoOO0ooOOoo0O * o00O0oo * o00O0oo / O0 * i11iIiiIii
   except :
    pass
 except :
  pass
  if 64 - 64: O0ooOooooO * o00O0oo % II111iiii - OoOO0ooOOoo0O + o00O0oo
def OO0OOoo0OOO ( ) :
 if 94 - 94: i11iIiiIii % OoooooooOO / OOooOOo
 try :
  if 24 - 24: OOooOOo * oO0o0ooO0
  iiII1i11i = IiIi ( I1111i )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 85 - 85: II111iiii . iI % IIII % O0oO
   try :
    if 80 - 80: oO0o0ooO0 * O0oO / iIii1I11I1II1 % oO0o0ooO0 / iIii1I11I1II1
    Iiii1 = Iii
    if 36 - 36: O0ooOooooO
   except :
    pass
    if 90 - 90: O0
    if 44 - 44: i1IIi . OOooOOo / i11iIiiIii + i1I111II1I
  iiII1i11i = IiIi ( Iiii1 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 27 - 27: IIII
   except :
    pass
 except :
  pass
  if 52 - 52: Oooo0Ooo000 % OoOO0ooOOoo0O + iIii1I11I1II1 * oO0o0ooO0 . o0oO0
def OoOooOO0oOOo0O ( ) :
 if 42 - 42: O0ooOooooO / o0000oOoOoO0o + ii11ii1ii . ii11ii1ii % IIII
 try :
  if 16 - 16: i1IIi + OoOO % OoOO0ooOOoo0O + o0oO0 * ii11ii1ii
  iiII1i11i = IiIi ( o00O0O )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 3 - 3: i11iIiiIii
   try :
    if 81 - 81: OOooOOo . OoooooooOO * o0oO0 . oO0o0ooO0 - O0 * oO0o0ooO0
    OoO0Oo00 = Iii
    if 1 - 1: Oooo0Ooo000 - O0oO
   except :
    pass
    if 45 - 45: o0oO0 - IIII
    if 70 - 70: OoOO % OOooOOo / OOooOOo . O0oO % iI . II111iiii
  iiII1i11i = IiIi ( OoO0Oo00 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 10 - 10: o0oO0 - i11iIiiIii . o00O0oo % i1IIi
   except :
    pass
 except :
  pass
  if 78 - 78: iIii1I11I1II1 * ii11ii1ii . ii11ii1ii - IIII . iIii1I11I1II1
def I111I1I ( ) :
 if 54 - 54: II111iiii + O0oO % O0oO % o0000oOoOoO0o
 try :
  if 25 - 25: O0ooOooooO - ii11ii1ii
  iiII1i11i = IiIi ( o0Oooo )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 10 - 10: O0 % i1I111II1I . OoOO + o0000oOoOoO0o + o00O0oo
   try :
    if 52 - 52: OoOO0ooOOoo0O / OoOO + Oooo0Ooo000
    Iii1i11iiI1 = Iii
    if 95 - 95: oO0o0ooO0 * iIii1I11I1II1 + o00O0oo
   except :
    pass
    if 5 - 5: ii11ii1ii
    if 100 - 100: o0oO0 + iIii1I11I1II1
  iiII1i11i = IiIi ( Iii1i11iiI1 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 59 - 59: i1I111II1I
   except :
    pass
 except :
  pass
  if 89 - 89: OoOO0ooOOoo0O % iIii1I11I1II1
  if 35 - 35: o00O0oo + Oooo0Ooo000 - OoOO0ooOOoo0O % oO0o0ooO0 % o0000oOoOoO0o % OoOO0ooOOoo0O
def ii1IIiII111I ( ) :
 if 87 - 87: o0oO0 - o00O0oo % o00O0oo . oO0o0ooO0 / o00O0oo
 try :
  if 6 - 6: OoOO0ooOOoo0O / iIii1I11I1II1 * OoooooooOO * i11iIiiIii
  iiII1i11i = IiIi ( Iii1I1111ii )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 79 - 79: i1I111II1I % OoOO
   try :
    if 81 - 81: i11iIiiIii + i11iIiiIii * OoOO + i1I111II1I
    iii = Iii
    if 15 - 15: OOooOOo . OoOO
   except :
    pass
    if 17 - 17: i11iIiiIii / ii11ii1ii . OoOO / OOooOOo
    if 38 - 38: i1IIi . o00O0oo % o0oO0 + iIii1I11I1II1 + O0
  iiII1i11i = IiIi ( iii )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 47 - 47: OoOO + i1I111II1I / II111iiii
   except :
    pass
 except :
  pass
  if 97 - 97: o00O0oo / OOooOOo % O0 + i1IIi - iI
  if 38 - 38: o0000oOoOoO0o % Oooo0Ooo000 + i11iIiiIii + O0ooOooooO + iI / i11iIiiIii
def o0OOOOOo0 ( ) :
 if 57 - 57: iIii1I11I1II1 + iIii1I11I1II1
 try :
  if 56 - 56: oO0o0ooO0 + iI
  iiII1i11i = IiIi ( Ii1IIiI1i )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 32 - 32: II111iiii + OoOO0ooOOoo0O % iI / OoOO0ooOOoo0O + o00O0oo
   try :
    if 2 - 2: i11iIiiIii - Oooo0Ooo000 + OoOO % O0oO * o0oO0
    Ooo000O00 = Iii
    if 36 - 36: IIII % i11iIiiIii
   except :
    pass
    if 47 - 47: i1IIi + II111iiii . ii11ii1ii * oO0o0ooO0 . O0oO / i1IIi
    if 50 - 50: Oooo0Ooo000 / i1IIi % OoooooooOO
  iiII1i11i = IiIi ( Ooo000O00 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 83 - 83: o00O0oo * o00O0oo + IIII
   except :
    pass
    if 57 - 57: O0 - O0 . o00O0oo / o0000oOoOoO0o / o0oO0
 except :
  pass
  if 20 - 20: IIII * II111iiii - OoOO0ooOOoo0O - oO0o0ooO0 * Oooo0Ooo000
  if 6 - 6: iI + IIII / ii11ii1ii + i1I111II1I % II111iiii / OoOO
def iiIi ( ) :
 if 74 - 74: O0 + OoooooooOO / oO0o0ooO0 / OoOO0ooOOoo0O . o00O0oo % oO0o0ooO0
 try :
  if 34 - 34: i1IIi . OOooOOo
  iiII1i11i = IiIi ( IiII111i1i11 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 6 - 6: Oooo0Ooo000 % oO0o0ooO0 % o0oO0
   try :
    if 63 - 63: O0 . OOooOOo . O0 * iIii1I11I1II1
    oOo0O = Iii
    if 30 - 30: o0oO0 . o00O0oo / IIII
   except :
    pass
    if 2 - 2: i1I111II1I % OOooOOo - Oooo0Ooo000
    if 79 - 79: OoooooooOO / o00O0oo . O0
  iiII1i11i = IiIi ( oOo0O )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 79 - 79: oO0o0ooO0 - II111iiii
   except :
    pass
    if 43 - 43: i1IIi + O0 % OoOO / o0oO0 * OOooOOo
 except :
  pass
  if 89 - 89: OOooOOo . ii11ii1ii + o00O0oo . O0 % o0000oOoOoO0o
def Ooo00O0 ( ) :
 if 70 - 70: OOooOOo - iI - OoOO - OoOO0ooOOoo0O . i11iIiiIii % i1IIi
 try :
  if 1 - 1: oO0o0ooO0 / i1IIi
  iiII1i11i = IiIi ( oooO )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 74 - 74: O0oO / OoooooooOO / ii11ii1ii * i11iIiiIii . II111iiii . OoooooooOO
   try :
    if 59 - 59: i11iIiiIii . OoooooooOO / O0oO * o00O0oo + OoooooooOO
    Ii1I1i1ii1I1 = Iii
    if 98 - 98: i1I111II1I * iIii1I11I1II1 . o0oO0 * ii11ii1ii / o00O0oo + iI
   except :
    pass
    if 25 - 25: oO0o0ooO0
  iiII1i11i = IiIi ( Ii1I1i1ii1I1 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 19 - 19: OOooOOo % o0oO0 . i1I111II1I * iI
   except :
    pass
 except :
  pass
  if 89 - 89: OoOO0ooOOoo0O . IIII
  if 7 - 7: oO0o0ooO0 % OoOO0ooOOoo0O - OOooOOo + ii11ii1ii
def OoO0Ooo ( ) :
 if 21 - 21: OOooOOo + o00O0oo * ii11ii1ii * iIii1I11I1II1 - OoOO . ii11ii1ii
 try :
  if 59 - 59: OoOO - OoOO + O0ooOooooO
  iiII1i11i = IiIi ( ooo )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 32 - 32: i1IIi / ii11ii1ii - O0
   try :
    if 85 - 85: o0oO0 - O0 * i11iIiiIii . i1IIi
    i11i1 = Iii
    if 100 - 100: O0oO % i11iIiiIii * O0ooOooooO / OoOO % o00O0oo + IIII
   except :
    pass
    if 48 - 48: iIii1I11I1II1 % i1IIi + OoOO0ooOOoo0O % o0000oOoOoO0o
    if 79 - 79: OoOO0ooOOoo0O % OOooOOo % o0oO0 / i1IIi % OoOO
  iiII1i11i = IiIi ( i11i1 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 56 - 56: iIii1I11I1II1 - i11iIiiIii * O0ooOooooO
   except :
    pass
 except :
  pass
  if 84 - 84: IIII + o0oO0 + o0000oOoOoO0o
  if 33 - 33: o0oO0
def ooOOO00oOOooO ( ) :
 if 46 - 46: iIii1I11I1II1 . i11iIiiIii - OoOO0ooOOoo0O % O0 / II111iiii * i1IIi
 try :
  if 66 - 66: O0
  iiII1i11i = IiIi ( Ooo0oOooo0 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 52 - 52: OoOO * OoooooooOO
   try :
    if 12 - 12: O0 + i1I111II1I * i1IIi . OoOO
    o0OO0oooo = Iii
    if 40 - 40: Oooo0Ooo000 - OoOO0ooOOoo0O * O0oO - i1I111II1I / OoOO0ooOOoo0O
   except :
    pass
  iiII1i11i = IiIi ( o0OO0oooo )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 71 - 71: oO0o0ooO0 / OoooooooOO % i1I111II1I / OoOO0ooOOoo0O % Oooo0Ooo000
   except :
    pass
 except :
  pass
  if 19 - 19: Oooo0Ooo000 + i1I111II1I / oO0o0ooO0 / II111iiii
def OoO0O0oo0o ( ) :
 if 46 - 46: OoOO0ooOOoo0O - O0
 try :
  if 70 - 70: O0oO + ii11ii1ii * iIii1I11I1II1 . OOooOOo * O0oO
  iiII1i11i = IiIi ( iiIiIIIiiI )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 49 - 49: o0000oOoOoO0o
   try :
    if 25 - 25: O0ooOooooO . OoooooooOO * iIii1I11I1II1 . o0000oOoOoO0o / O0 + o0oO0
    ooo0o0 = Iii
    if 84 - 84: O0oO - ii11ii1ii * O0 / o0oO0 . o0oO0
   except :
    pass
    if 93 - 93: O0 / iI + OOooOOo
    if 20 - 20: i1I111II1I / O0ooOooooO % OoooooooOO / iIii1I11I1II1 + OOooOOo
  iiII1i11i = IiIi ( ooo0o0 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 57 - 57: o0000oOoOoO0o / Oooo0Ooo000
   except :
    pass
 except :
  pass
  if 13 - 13: OoooooooOO + OoOO
  if 32 - 32: O0 + oO0o0ooO0 % ii11ii1ii
def iI1iI ( ) :
 if 100 - 100: iI / iI - IIII % IIII * oO0o0ooO0 / i1I111II1I
 try :
  if 32 - 32: OOooOOo + o00O0oo - oO0o0ooO0 + o00O0oo / i1IIi * oO0o0ooO0
  iiII1i11i = IiIi ( II11IiIi11 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 90 - 90: o0oO0 % oO0o0ooO0
   try :
    if 6 - 6: OoooooooOO / i11iIiiIii / Oooo0Ooo000
    OooO0O0Ooo = Iii
    if 85 - 85: o0000oOoOoO0o / Oooo0Ooo000
   except :
    pass
    if 67 - 67: O0oO % oO0o0ooO0
    if 39 - 39: i11iIiiIii + i1I111II1I
  iiII1i11i = IiIi ( OooO0O0Ooo )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 7 - 7: iIii1I11I1II1 - i1IIi
   except :
    pass
 except :
  pass
  if 10 - 10: Oooo0Ooo000 % O0 / OOooOOo % O0oO
def iiII ( ) :
 if 28 - 28: iI . OoooooooOO + o0000oOoOoO0o + o0oO0 % O0ooOooooO
 try :
  if 80 - 80: ii11ii1ii
  iiII1i11i = IiIi ( I1iiii1I )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 86 - 86: o00O0oo * O0oO . OoOO0ooOOoo0O / ii11ii1ii + oO0o0ooO0
   try :
    if 8 - 8: OoOO0ooOOoo0O
    iIo00OOOOOo0OOo = Iii
    if 44 - 44: O0oO * o0000oOoOoO0o
   except :
    pass
    if 49 - 49: IIII % O0oO * i11iIiiIii / oO0o0ooO0 % IIII
    if 70 - 70: OoOO0ooOOoo0O / II111iiii % iI - O0ooOooooO
  iiII1i11i = IiIi ( iIo00OOOOOo0OOo )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 2 - 2: Oooo0Ooo000 - o00O0oo + o0000oOoOoO0o * OoOO / O0ooOooooO
   except :
    pass
 except :
  pass
  if 26 - 26: IIII * ii11ii1ii
  if 31 - 31: O0oO * oO0o0ooO0 . o0oO0
def i1Ii11ii1I ( ) :
 if 66 - 66: ii11ii1ii / OoooooooOO % Oooo0Ooo000 / O0ooOooooO + OoooooooOO
 try :
  if 6 - 6: II111iiii % Oooo0Ooo000
  iiII1i11i = IiIi ( oO00ooooO0o )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 41 - 41: i1I111II1I - II111iiii . II111iiii + OOooOOo
   try :
    if 59 - 59: iIii1I11I1II1 % o0oO0 . i11iIiiIii
    OOoO0OOOO0000O = Iii
    if 38 - 38: ii11ii1ii
   except :
    pass
    if 34 - 34: OoOO0ooOOoo0O
    if 70 - 70: iIii1I11I1II1 * i1I111II1I - IIII / ii11ii1ii % oO0o0ooO0
  iiII1i11i = IiIi ( OOoO0OOOO0000O )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 66 - 66: OoooooooOO + iI * O0ooOooooO
   except :
    pass
 except :
  pass
  if 2 - 2: O0ooOooooO . OoOO / oO0o0ooO0
  if 41 - 41: OoOO . Oooo0Ooo000 * i1I111II1I * Oooo0Ooo000
def ooOO ( ) :
 if 86 - 86: o0oO0 . IIII / i1I111II1I - OoooooooOO
 try :
  if 45 - 45: IIII
  iiII1i11i = IiIi ( o0oO0oooOoo )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 25 - 25: IIII % O0
   try :
    if 44 - 44: Oooo0Ooo000 . o0oO0 * II111iiii / i1I111II1I + iIii1I11I1II1
    Ii1111III1 = Iii
    if 74 - 74: o00O0oo - O0ooOooooO * i1IIi
   except :
    pass
    if 12 - 12: O0
    if 75 - 75: iIii1I11I1II1 % i1I111II1I + o00O0oo * O0 . O0ooOooooO - iI
  iiII1i11i = IiIi ( Ii1111III1 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 32 - 32: o0oO0 % oO0o0ooO0 - i1IIi
   except :
    pass
 except :
  pass
  if 40 - 40: iIii1I11I1II1 + O0ooOooooO * OoOO0ooOOoo0O + oO0o0ooO0
  if 15 - 15: O0oO % OOooOOo - iIii1I11I1II1 * iI
def oO0O0o0o000 ( ) :
 if 6 - 6: OoOO0ooOOoo0O / iI + O0ooOooooO - o0000oOoOoO0o * IIII + iI
 try :
  if 76 - 76: II111iiii - OoooooooOO % i1I111II1I
  iiII1i11i = IiIi ( I1i111I )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 40 - 40: o0oO0
   try :
    if 59 - 59: O0oO * OoooooooOO + IIII . iIii1I11I1II1 / i1IIi
    O0Oo0O00o0oo0OO = Iii
    if 97 - 97: i11iIiiIii + OoOO0ooOOoo0O / iI % IIII
   except :
    pass
    if 38 - 38: IIII % i1I111II1I % II111iiii - ii11ii1ii - iIii1I11I1II1
    if 9 - 9: o0000oOoOoO0o % o00O0oo . o00O0oo
  iiII1i11i = IiIi ( O0Oo0O00o0oo0OO )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 28 - 28: OoooooooOO % oO0o0ooO0 + o00O0oo + O0 . Oooo0Ooo000
   except :
    pass
 except :
  pass
  if 80 - 80: i11iIiiIii % o00O0oo
  if 54 - 54: o0000oOoOoO0o + O0oO - iIii1I11I1II1 % iI % i1I111II1I
def II1i ( ) :
 if 13 - 13: o00O0oo . i1I111II1I
 try :
  if 4 - 4: ii11ii1ii - OoOO - i11iIiiIii * Oooo0Ooo000 / o0oO0 - IIII
  iiII1i11i = IiIi ( I1i11 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 45 - 45: o0000oOoOoO0o % ii11ii1ii * i1IIi - O0
   try :
    if 82 - 82: II111iiii / O0ooOooooO
    OOoOi1IiiI = Iii
    if 70 - 70: O0oO . IIII * ii11ii1ii / IIII
   except :
    pass
    if 83 - 83: OoooooooOO + OoOO * oO0o0ooO0 . O0
  iiII1i11i = IiIi ( OOoOi1IiiI )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 13 - 13: o0000oOoOoO0o
   except :
    pass
 except :
  pass
  if 7 - 7: OOooOOo + i1I111II1I / i11iIiiIii / ii11ii1ii
  if 97 - 97: Oooo0Ooo000 . O0oO / OOooOOo
def o00OO0o0 ( ) :
 if 39 - 39: iI % o00O0oo - O0ooOooooO
 try :
  if 48 - 48: i11iIiiIii
  iiII1i11i = IiIi ( IiIIi1 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 52 - 52: iIii1I11I1II1
   try :
    if 38 - 38: O0oO . O0oO * oO0o0ooO0 / OoooooooOO % iI
    OO000 = Iii
    if 31 - 31: OoOO * O0 / O0oO . OoooooooOO * O0oO . o00O0oo
   except :
    pass
    if 50 - 50: OoOO * O0oO - o0000oOoOoO0o + i1I111II1I * OoOO % oO0o0ooO0
    if 92 - 92: O0oO % i1IIi % iI % i1I111II1I % o0000oOoOoO0o
  iiII1i11i = IiIi ( OO000 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 61 - 61: IIII * o0000oOoOoO0o * O0 / O0ooOooooO
   except :
    pass
 except :
  pass
  if 52 - 52: ii11ii1ii + iIii1I11I1II1 + i1IIi * o0oO0 - II111iiii . II111iiii
def Iii1I1iI ( ) :
 if 62 - 62: oO0o0ooO0 + ii11ii1ii / i11iIiiIii
 try :
  if 90 - 90: iIii1I11I1II1 + OoOO0ooOOoo0O
  iiII1i11i = IiIi ( II1i11I )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 9 - 9: iIii1I11I1II1 . OoooooooOO + i1IIi - ii11ii1ii
   try :
    if 30 - 30: O0ooOooooO / OoOO . O0ooOooooO
    iI1iiiI = Iii
    if 75 - 75: OoooooooOO . IIII + OoOO / o0oO0 - OOooOOo % o0oO0
   except :
    pass
  iiII1i11i = IiIi ( iI1iiiI )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 89 - 89: O0ooOooooO * iIii1I11I1II1 + i11iIiiIii . OoooooooOO
   except :
    pass
 except :
  pass
  if 51 - 51: IIII / iI + OoOO % OoOO0ooOOoo0O / o0oO0
def ii111i1i ( ) :
 if 71 - 71: o0000oOoOoO0o % iI / oO0o0ooO0 - iIii1I11I1II1 / i11iIiiIii
 try :
  if 100 - 100: oO0o0ooO0 + O0 . OOooOOo + i1IIi - OoOO0ooOOoo0O + o0000oOoOoO0o
  iiII1i11i = IiIi ( O0o0oO )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 65 - 65: II111iiii / ii11ii1ii
   try :
    if 42 - 42: i11iIiiIii . O0
    o0oo0Oo = Iii
    if 10 - 10: o00O0oo
   except :
    pass
  iiII1i11i = IiIi ( o0oo0Oo )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 87 - 87: ii11ii1ii % o0oO0
   except :
    pass
 except :
  pass
  if 53 - 53: i1IIi - i1I111II1I + iIii1I11I1II1
def o0Oo00oOO ( ) :
 if 73 - 73: O0oO / OoooooooOO . II111iiii - i1I111II1I * iI * i1I111II1I
 try :
  if 45 - 45: O0 * Oooo0Ooo000 + i11iIiiIii - IIII - iIii1I11I1II1
  iiII1i11i = IiIi ( Oo0o0O00 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 5 - 5: IIII % ii11ii1ii % i1I111II1I % iI
   try :
    if 17 - 17: o0oO0 + II111iiii + OoooooooOO / IIII / i1I111II1I
    oOoo0Ooooo = Iii
    if 15 - 15: II111iiii * oO0o0ooO0 % O0ooOooooO / i11iIiiIii - oO0o0ooO0 + ii11ii1ii
   except :
    pass
  iiII1i11i = IiIi ( oOoo0Ooooo )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 9 - 9: O0oO - oO0o0ooO0 + O0 / O0ooOooooO % i1IIi
   except :
    pass
 except :
  pass
  if 97 - 97: o0000oOoOoO0o * iI
def O0OOO0ooO00o ( ) :
 if 24 - 24: Oooo0Ooo000 + OoooooooOO . i1I111II1I / OoOO0ooOOoo0O / O0oO
 try :
  if 65 - 65: OoooooooOO
  iiII1i11i = IiIi ( I11iiiiI1i )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 18 - 18: O0 - i1IIi . Oooo0Ooo000
   try :
    if 98 - 98: o0000oOoOoO0o
    OOo00Oooo = Iii
    if 15 - 15: iI . iIii1I11I1II1 * OOooOOo % O0oO
   except :
    pass
  iiII1i11i = IiIi ( OOo00Oooo )
  OOOOO0O00 = re . compile ( o0O ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 in OOOOO0O00 :
   try :
    iIiiii1I ( iiIi1i , I1i11111i1i11 , OOoOOO0 )
    if 13 - 13: II111iiii . O0ooOooooO - Oooo0Ooo000 . OoOO . iIii1I11I1II1
   except :
    pass
    if 66 - 66: ii11ii1ii * i1I111II1I
 except :
  pass
  if 83 - 83: OoooooooOO
  if 12 - 12: iI
  if 36 - 36: Oooo0Ooo000 . i1I111II1I * OoooooooOO - o0000oOoOoO0o
def iIiiii1I ( thumb , name , url ) :
 if 60 - 60: IIII . O0ooOooooO / iIii1I11I1II1 + IIII * Oooo0Ooo000
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 if 82 - 82: i11iIiiIii . iIii1I11I1II1 * OOooOOo - O0oO + o0oO0
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   oO0OoO00o ( name , url , '' , o00 , oo00 )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 48 - 48: o00O0oo
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 96 - 96: iI . OoooooooOO
   i1I1I1I ( name , url , 4 , O0OoOOO00 , oo00 )
   if 25 - 25: o0000oOoOoO0o + O0ooOooooO - ii11ii1ii
  else :
   if 59 - 59: IIII - O0oO % i1IIi
   i1I1I1I ( name , url , 4 , O0OoOOO00 , oo00 )
   if 1 - 1: o00O0oo . Oooo0Ooo000 * OOooOOo . i1I111II1I * II111iiii % iIii1I11I1II1
def Oo0oo00Oo0O0 ( name , url , thumb , id , trailer ) :
 if 67 - 67: O0ooOooooO
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 88 - 88: ii11ii1ii
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   oO0OoO00o ( name , url , '' , o00 , oo00 )
 else :
  O00OOOoOoo0O = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
  if 8 - 8: o00O0oo
  name = '[COLOR %s]' % O00OOOoOoo0O + name + '[/COLOR]'
  if 82 - 82: OoooooooOO
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   III1iII1I1ii = IiII1IiiIiI1 . getSetting ( 'selecton' )
   if III1iII1I1ii == 'true' :
    if 75 - 75: II111iiii % OOooOOo + IIII % OoooooooOO / i1I111II1I
    Ii111I11 ( name , url , 1 , thumb , thumb , id , trailer )
    if 51 - 51: OoooooooOO + o0000oOoOoO0o * iIii1I11I1II1 * oO0o0ooO0 / i1IIi
   else :
    if 19 - 19: O0ooOooooO - OoOO0ooOOoo0O % oO0o0ooO0 / OoooooooOO % O0ooOooooO
    Ii111I11 ( name , url , 130 , thumb , thumb , id , trailer )
    if 65 - 65: O0 . oO0o0ooO0
  else :
   if 85 - 85: II111iiii
   if III1iII1I1ii == 'true' :
    if 55 - 55: o00O0oo
    Ii111I11 ( name , url , 1 , thumb , thumb , id , trailer )
    if 76 - 76: oO0o0ooO0 - i11iIiiIii
   else :
    if 27 - 27: o00O0oo - i11iIiiIii % Oooo0Ooo000 / ii11ii1ii . ii11ii1ii / OoooooooOO
    Ii111I11 ( name , url , 130 , thumb , thumb , id , trailer )
    if 76 - 76: O0oO * OoOO . iIii1I11I1II1 % OoooooooOO % o00O0oo
def IiIii1i111 ( name , url , thumb , id , trailer , description , fanart ) :
 if 39 - 39: II111iiii * OoOO0ooOOoo0O . O0 * O0oO
 if 89 - 89: o0oO0 - iI . O0oO - Oooo0Ooo000 - OOooOOo
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . strip ( )
 O00OOOoOoo0O = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
 fanart = fanart . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 name = '[COLOR %s]' % O00OOOoOoo0O + name + '[/COLOR]'
 if 79 - 79: i1I111II1I + i1I111II1I + o0oO0
 if 39 - 39: O0 - OoooooooOO
 if 'tvg-logo' in thumb :
  thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  if III1iII1I1ii == 'true' :
   oo0O00ooo0o ( name , url , 1 , thumb , fanart , id , trailer , description )
  else :
   if 29 - 29: OoooooooOO . II111iiii % OoOO0ooOOoo0O
   oo0O00ooo0o ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 26 - 26: iIii1I11I1II1 - o00O0oo . i1I111II1I . i1I111II1I + iIii1I11I1II1 * ii11ii1ii
 else :
  if 85 - 85: IIII + II111iiii - IIII * oO0o0ooO0 - i1IIi % O0ooOooooO
  if III1iII1I1ii == 'true' :
   if 1 - 1: OoooooooOO / O0 + OoOO0ooOOoo0O + OoOO0ooOOoo0O . Oooo0Ooo000 - OoOO0ooOOoo0O
   oo0O00ooo0o ( name , url , 1 , thumb , fanart , id , trailer , description )
   if 9 - 9: Oooo0Ooo000 * OoooooooOO % OOooOOo / OoOO0ooOOoo0O * O0oO
  else :
   if 48 - 48: OoooooooOO . OoOO0ooOOoo0O
   oo0O00ooo0o ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 65 - 65: oO0o0ooO0 . ii11ii1ii
   if 94 - 94: OoOO0ooOOoo0O + i1I111II1I . iI
def oooOo00O0 ( name , trailer ) :
 if 26 - 26: Oooo0Ooo000 . o0oO0 + OOooOOo . OoOO0ooOOoo0O + IIII
 if O0ii1ii1ii == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Realstream, Reproduciendo Trailer de: [COLOR green]" + name + "[/COLOR] ,5000)" )
  if 17 - 17: IIII + i11iIiiIii + o00O0oo % IIII . oO0o0ooO0
  OOoOOO0 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  I11iiIi1i1IIi = OOoOOO0
  II1 = xbmcgui . ListItem ( name , trailer , path = I11iiIi1i1IIi )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1 )
 else :
  OOoOOO0 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  I11iiIi1i1IIi = OOoOOO0
  II1 = xbmcgui . ListItem ( name , trailer , path = I11iiIi1i1IIi )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1 )
  if 10 - 10: OoOO * o0000oOoOoO0o
  if 17 - 17: iI + o00O0oo * i11iIiiIii
def oO00OOOOOO0o ( name , url ) :
 if 18 - 18: o00O0oo / ii11ii1ii - O0ooOooooO
 if O0ii1ii1ii == 'true' :
  if 69 - 69: oO0o0ooO0 / i1I111II1I * iI
  try :
   if 81 - 81: oO0o0ooO0
   ii = xbmcgui . DialogProgress ( )
   ii . create ( 'Realstream:' , 'Iniciando ...' )
   ii . update ( 30 , 'Realstream:' , 'Conectando al servidor ...' )
   xbmc . sleep ( 1000 )
   ii . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   ii . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   ii . close ( )
   if 62 - 62: o0oO0 + O0 * OoOO
   I11iiIi1i1IIi = url
   II1 = xbmcgui . ListItem ( name , I1I1i , path = I11iiIi1i1IIi )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1 )
   if 59 - 59: II111iiii
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. ,3000)" )
  if 43 - 43: ii11ii1ii + OoooooooOO
 else :
  if 47 - 47: iI
  try :
   if 92 - 92: O0oO % i11iIiiIii % ii11ii1ii
   ii = xbmcgui . DialogProgress ( )
   ii . create ( 'Realstream:' , 'Iniciando ...' )
   ii . update ( 30 , 'Realstream:' , 'Conectando al servidor ...' )
   xbmc . sleep ( 1000 )
   ii . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   ii . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   ii . close ( )
   if 23 - 23: II111iiii * O0ooOooooO
   I11iiIi1i1IIi = url
   II1 = xbmcgui . ListItem ( name , I1I1i , path = I11iiIi1i1IIi )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1 )
   if 80 - 80: Oooo0Ooo000 / i11iIiiIii + OoooooooOO
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. ,3000)" )
  if 38 - 38: o00O0oo % iI + i1IIi * OoooooooOO * oO0o0ooO0
 return
 if 83 - 83: iIii1I11I1II1 - iI - Oooo0Ooo000 / OoOO - O0
 if 81 - 81: o0oO0 - oO0o0ooO0 * o00O0oo / Oooo0Ooo000
def iIIi11i ( trailer ) :
 if 39 - 39: OoOO0ooOOoo0O . ii11ii1ii - i1I111II1I / o0000oOoOoO0o / i1IIi
 if 'https://www.youtube.com' in trailer :
  if 79 - 79: IIII % Oooo0Ooo000 / oO0o0ooO0 - iIii1I11I1II1 - OoOO0ooOOoo0O
  try :
   if 60 - 60: II111iiii
   import resolveurl
   if 90 - 90: OoOO0ooOOoo0O
   iiIIii = urlresolver . HostedMediaFile ( OOoOOO0 )
   ii = xbmcgui . DialogProgress ( )
   ii . create ( 'Realstream:' , 'Conectando al servidor ... ' )
   ii . update ( 20 , 'Por favor, espere ...' )
   xbmc . sleep ( 500 )
   if 37 - 37: OoOO0ooOOoo0O + O0 . O0 * ii11ii1ii % Oooo0Ooo000 / O0ooOooooO
   if not iiIIii :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    return False
    if 18 - 18: OoooooooOO
   try :
    if 57 - 57: iI . OoOO0ooOOoo0O * o0000oOoOoO0o - OoooooooOO
    ii . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    O000oOo = iiIIii . resolve ( )
    if not O000oOo or not isinstance ( O000oOo , basestring ) :
     try : OoOOOO = O000oOo . msg
     except : OoOOOO = O000oOo
     raise Exception ( OoOOOO )
   except Exception as oOOOO :
    try : OoOOOO = str ( oOOOO )
    except : OoOOOO = O000oOo
    ii . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
    ii . close ( )
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    if 75 - 75: i11iIiiIii / o0000oOoOoO0o . i1I111II1I . i1IIi . i1IIi / O0oO
   ii . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
   xbmc . sleep ( 500 )
   ii . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   ii . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
   xbmc . sleep ( 500 )
   ii . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   ii . close ( )
   if 94 - 94: iI + OOooOOo
   I1Iiii = xbmcgui . ListItem ( path = O000oOo )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1Iiii )
   if 56 - 56: OoOO0ooOOoo0O % o0000oOoOoO0o
  except :
   pass
   if 40 - 40: IIII / i1I111II1I
  else :
   if 29 - 29: o0oO0 - o0oO0 / iI
   OOoOOO0 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
   I11iiIi1i1IIi = OOoOOO0
   II1 = xbmcgui . ListItem ( trailer , path = I11iiIi1i1IIi )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1 )
   return
   if 49 - 49: O0oO + oO0o0ooO0 % OoOO - ii11ii1ii - O0 - OoooooooOO
def Ii1I1Iiii ( name , url ) :
 if 80 - 80: IIII . o0oO0 + iIii1I11I1II1
 if '[Youtube]' in name :
  if 32 - 32: OOooOOo
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  I11iiIi1i1IIi = url
  II1 = xbmcgui . ListItem ( I1I1i , path = I11iiIi1i1IIi )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1 )
  if 47 - 47: o00O0oo * oO0o0ooO0 + iIii1I11I1II1 - oO0o0ooO0 / i1I111II1I
  if 86 - 86: i1I111II1I
 else :
  if 43 - 43: OOooOOo / O0ooOooooO / iI + iIii1I11I1II1 + OoooooooOO
  import urlresolver
  from urlresolver import common
  if 33 - 33: II111iiii - i1I111II1I - iI
  iiIIii = urlresolver . HostedMediaFile ( url )
  if 92 - 92: OoOO * i1I111II1I
  if not iiIIii :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 92 - 92: oO0o0ooO0
   if 7 - 7: O0ooOooooO
  try :
   O000oOo = iiIIii . resolve ( )
   if not O000oOo or not isinstance ( O000oOo , basestring ) :
    try : OoOOOO = O000oOo . msg
    except : OoOOOO = url
    raise Exception ( OoOOOO )
  except Exception as oOOOO :
   try : OoOOOO = str ( oOOOO )
   except : OoOOOO = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 73 - 73: OoOO % o00O0oo
  O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if O0ii1ii1ii == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  I1Iiii = xbmcgui . ListItem ( path = O000oOo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1Iiii )
  if 32 - 32: IIII + O0ooOooooO + iIii1I11I1II1 * ii11ii1ii
  if 62 - 62: i11iIiiIii
 return
 if 2 - 2: OOooOOo
 if 69 - 69: OoooooooOO / ii11ii1ii * Oooo0Ooo000
def Oo0o0ooO0ooo ( name , url ) :
 if 47 - 47: i1I111II1I
 if 'mybox.com' in url :
  if 76 - 76: OoOO * iIii1I11I1II1 + o00O0oo - iI - O0oO / i1IIi
  url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
  if 27 - 27: o00O0oo . i1I111II1I
  try :
   if 66 - 66: O0 / O0 * i1IIi . OoooooooOO % iIii1I11I1II1
   iiII1i11i = IiIi ( url )
   OOOOO0O00 = re . compile ( O0OO0O ) . findall ( iiII1i11i )
   for url , I11iIiI1 , i1I1iiii1Ii11 in OOOOO0O00 :
    if 25 - 25: i11iIiiIii / OoOO0ooOOoo0O - Oooo0Ooo000 / OoOO . o0000oOoOoO0o . o0000oOoOoO0o
    I11iIiI1 = I11iIiI1 . replace ( '","res":"1080",' , '' ) . replace ( '","res":"720",' , '' ) . replace ( '","res":"480",' , '' ) . replace ( '","res":"360",' , '' )
    url = url . replace ( '\/' , '/' )
    url = url . replace ( ',"type":"video/mp4",' , ' ' )
    name = '[COLOR white]' + I11iIiI1 + '[/COLOR] - [COLOR gold]' + i1I1iiii1Ii11 + '[/COLOR]'
    if 6 - 6: oO0o0ooO0 . O0oO
    iIIII1 = [ ]
    iIIII1 . append ( '[COLOR orange]Real Stream: [/COLOR][COLOR gold]1. Mostrar mas info. [Reiniciar][/COLOR]' )
    iIIII1 . append ( '[COLOR gold]2. Mostar otras calidades disponibles [/COLOR]' )
    iIIII1 . append ( '[COLOR gold]3. Ver en: %s [/COLOR]' % name )
    if 65 - 65: O0 / II111iiii . iIii1I11I1II1 . oO0o0ooO0 / ii11ii1ii % iIii1I11I1II1
    if 74 - 74: i1IIi / OOooOOo % o00O0oo / O0 % O0oO - OoOO0ooOOoo0O
    Iiii = 'Seleccione una calidad e idioma:'
    oOii11I = xbmcgui . Dialog ( )
    Ooo0O00 = oOii11I . select ( Iiii , iIIII1 )
    if 53 - 53: O0 . OOooOOo
    if 74 - 74: iI % OoOO0ooOOoo0O / ii11ii1ii
    if 2 - 2: i1I111II1I % i1I111II1I % Oooo0Ooo000
    if Ooo0O00 == 0 :
     if 60 - 60: IIII
     oO0O000oOoo0O = oOii11I . ok ( "[COLOR darkpink]REALSTREAM:[/COLOR] " , "[COLOR gold]  Reiniciadas las opciones.  [/COLOR]" , "" )
     del oOii11I
     return
     if 73 - 73: iI
    elif Ooo0O00 == 1 :
     if 86 - 86: OoOO0ooOOoo0O . O0oO / ii11ii1ii * O0oO
     pass
     if 20 - 20: iI - IIII * OoOO * o0000oOoOoO0o * IIII / i1I111II1I
     del oOii11I
     if 40 - 40: OOooOOo * o0000oOoOoO0o . OOooOOo
     if 62 - 62: iI + II111iiii % iI
    elif Ooo0O00 == 2 :
     if 50 - 50: OoooooooOO + oO0o0ooO0 * OOooOOo - o0oO0 / i11iIiiIii
     oO00OOOOOO0o ( name , url )
     if 5 - 5: O0 - OOooOOo
     return
     if 44 - 44: II111iiii . II111iiii + IIII * o0oO0
  except :
   pass
   if 16 - 16: II111iiii
 elif 'uptostream.com' in url :
  if 100 - 100: O0 - i1IIi
  try :
   if 48 - 48: oO0o0ooO0 % iI + O0
   iiII1i11i = IiIi ( url )
   OOOOO0O00 = re . compile ( O0OO0O ) . findall ( iiII1i11i )
   for url , I11iIiI1 , i1I1iiii1Ii11 in OOOOO0O00 :
    if 27 - 27: o00O0oo / IIII
    I11iIiI1 = I11iIiI1 . replace ( '","res":"1080",' , '' ) . replace ( '","res":"720",' , '' ) . replace ( '","res":"480",' , '' ) . replace ( '","res":"360",' , '' )
    url = url . replace ( '\/' , '/' )
    url = url . replace ( ',"type":"video/mp4",' , ' ' )
    name = '[COLOR white]Calidad: ' + I11iIiI1 + '[/COLOR] [COLOR gold]Idioma: ' + i1I1iiii1Ii11 + '[/COLOR]'
    if 33 - 33: OoooooooOO % o00O0oo . O0 / o00O0oo
    iIIII1 = [ ]
    iIIII1 . append ( '[COLOR white]Reiniciar calidades disponibles[/COLOR]' )
    iIIII1 . append ( '[COLOR white]Otras calidades e idiomas[/COLOR]' )
    iIIII1 . append ( '[COLOR white]Ver en: %s ' % name )
    if 63 - 63: i1I111II1I + iIii1I11I1II1 + OOooOOo + Oooo0Ooo000
    if 72 - 72: OoOO + i11iIiiIii + o00O0oo
    Iiii = 'Seleccione una calidad e idioma:'
    oOii11I = xbmcgui . Dialog ( )
    Ooo0O00 = oOii11I . select ( Iiii , iIIII1 )
    if 96 - 96: oO0o0ooO0 % i1IIi / o0000oOoOoO0o
    if 13 - 13: II111iiii - ii11ii1ii % i11iIiiIii + O0ooOooooO
    if Ooo0O00 == 0 :
     if 88 - 88: O0 . oO0o0ooO0 % OOooOOo
     oO0O000oOoo0O = oOii11I . ok ( "[COLOR darkpink]REALSTREAM:[/COLOR] " , "[COLOR gold]  Reiniciadas las opciones.  [/COLOR]" , "" )
     del oOii11I
     return
     if 10 - 10: OOooOOo + O0
    elif Ooo0O00 == 1 :
     if 75 - 75: O0 % iIii1I11I1II1 / OoOO0ooOOoo0O % IIII / i1I111II1I
     pass
     if 31 - 31: i11iIiiIii * OoOO0ooOOoo0O
     del oOii11I
     if 69 - 69: i11iIiiIii
     if 61 - 61: O0
     if 21 - 21: OoOO % iIii1I11I1II1 . OoOO
     if 99 - 99: o0000oOoOoO0o * IIII % oO0o0ooO0 * oO0o0ooO0 + OoooooooOO
    elif Ooo0O00 == 2 :
     if 82 - 82: O0oO / OoOO0ooOOoo0O - IIII / iI
     oO00OOOOOO0o ( name , url )
     if 50 - 50: IIII + OoOO . i11iIiiIii + o00O0oo + i11iIiiIii
     return
     if 31 - 31: oO0o0ooO0 * Oooo0Ooo000 . OoOO0ooOOoo0O * O0oO
  except :
   pass
 else :
  if 28 - 28: i1I111II1I + OOooOOo - ii11ii1ii % IIII . O0oO + OOooOOo
  IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
  o00O0 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  oOO0O00Oo0O0o = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  OOoo0 = IiII1IiiIiI1 . getSetting ( 'key_ext' )
  iiII1i11i = IiIi ( oOO0O00Oo0O0o )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for III1I1I in OOOOO0O00 :
   if 72 - 72: o0oO0 / ii11ii1ii / oO0o0ooO0 * OoOO0ooOOoo0O + IIII
   try :
    if 58 - 58: o0000oOoOoO0o % OOooOOo . OOooOOo * OoOO - i1I111II1I . OoooooooOO
    if 10 - 10: Oooo0Ooo000
    IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
    if 48 - 48: O0ooOooooO * i1IIi % OoooooooOO * o0oO0 * OoOO
    if 7 - 7: O0ooOooooO . o0oO0 . O0ooOooooO - Oooo0Ooo000
    if IIIi1I1IIii1II == III1I1I :
     if 33 - 33: iI + OoooooooOO - OoOO / i1IIi / OoooooooOO
     if 82 - 82: o00O0oo / IIII - O0ooOooooO / ii11ii1ii * OoOO
     if 'https://team.com' in url :
      if 55 - 55: OoooooooOO
      url = url . replace ( 'https://team.com' , 'https://verystream.com' )
      if 73 - 73: OoOO0ooOOoo0O - o00O0oo % ii11ii1ii + o00O0oo - O0 . OoOO
     if 'https://mybox.com' in url :
      if 38 - 38: O0
      url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
      if 79 - 79: i1IIi . oO0o0ooO0
      if 34 - 34: Oooo0Ooo000 * II111iiii
     if 'https://vidcloud.co/' in url :
      if 71 - 71: i1I111II1I
      url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
      if 97 - 97: o00O0oo
     if 'https://gounlimited.to' in url :
      if 86 - 86: ii11ii1ii - IIII . OoOO0ooOOoo0O . II111iiii * OOooOOo . II111iiii
      url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
      if 34 - 34: o0000oOoOoO0o . Oooo0Ooo000 % i1I111II1I - O0 / Oooo0Ooo000
     if 'https://drive.com' in url :
      if 91 - 91: i11iIiiIii % Oooo0Ooo000 * oO0o0ooO0 - o00O0oo . Oooo0Ooo000
      url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
      if 28 - 28: i11iIiiIii
      if 51 - 51: OOooOOo + iI * O0 . o0oO0
     import resolveurl
     if 82 - 82: IIII * o00O0oo % o0oO0 . IIII
     iiIIii = urlresolver . HostedMediaFile ( url )
     if 43 - 43: OoOO . iI * ii11ii1ii
     if not iiIIii :
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
      return False
      if 20 - 20: i1IIi . i1IIi - O0oO
     try :
      if 89 - 89: iI - O0oO . O0 % OoooooooOO . i11iIiiIii
      ii = xbmcgui . DialogProgress ( )
      ii . create ( 'Realstream:' , 'Iniciando ...' )
      ii . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
      xbmc . sleep ( 1000 )
      if 35 - 35: II111iiii / OoOO0ooOOoo0O - O0 . II111iiii
      O000oOo = iiIIii . resolve ( )
      if not O000oOo or not isinstance ( O000oOo , basestring ) :
       if 55 - 55: ii11ii1ii % i1IIi * O0oO
       try : OoOOOO = O000oOo . msg
       except : OoOOOO = url
       raise Exception ( OoOOOO )
       if 95 - 95: IIII / II111iiii - o0000oOoOoO0o % Oooo0Ooo000 . O0oO
     except Exception as oOOOO :
      try : OoOOOO = str ( oOOOO )
      except : OoOOOO = url
      if 63 - 63: iIii1I11I1II1 / iI
      if 24 - 24: ii11ii1ii / iIii1I11I1II1 % IIII * OoOO0ooOOoo0O - iIii1I11I1II1
      if 50 - 50: II111iiii
      for IiIIiiiIi in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       IiI111 = 1
       ii . update ( 45 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % IiIIiiiIi )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5  Puede cancelar cuando desee o esperar...,  1000)" % IiI111 )
       ii . close ( )
       if 82 - 82: OOooOOo % OoOO % O0oO + O0oO
      for IiIIiiiIi in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       IiI111 = 2
       ii . update ( 48 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % IiIIiiiIi )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % IiI111 )
       ii . close ( )
      for IiIIiiiIi in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       IiI111 = 3
       ii . update ( 50 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % IiIIiiiIi )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % IiI111 )
       ii . close ( )
      for IiIIiiiIi in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       IiI111 = 4
       ii . update ( 53 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % IiIIiiiIi )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % IiI111 )
       ii . close ( )
      for IiIIiiiIi in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       IiI111 = 5
       ii . update ( 55 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % IiIIiiiIi )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % IiI111 )
       ii . close ( )
       if 6 - 6: ii11ii1ii
      if ii . iscanceled ( ) :
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Cancelando !! , 2000)" )
       ii . close ( )
       break
       if 73 - 73: Oooo0Ooo000 * o00O0oo + o0000oOoOoO0o - ii11ii1ii . O0oO
       if 93 - 93: i11iIiiIii
       if 80 - 80: i1IIi . OOooOOo - oO0o0ooO0 + IIII + O0ooOooooO % oO0o0ooO0
     ii . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
     xbmc . sleep ( 500 )
     ii . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
     xbmc . sleep ( 1000 )
     ii . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
     ii . close ( )
     O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
     I1Iiii = xbmcgui . ListItem ( path = O000oOo )
     xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1Iiii )
     if 13 - 13: II111iiii / OoOO0ooOOoo0O / OoOO0ooOOoo0O + iI
     if 49 - 49: O0 / II111iiii * OOooOOo - OoooooooOO . II111iiii % i1I111II1I
    else :
     if 13 - 13: oO0o0ooO0 . iIii1I11I1II1 . IIII . i1I111II1I
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold] El addon no ha podido conectar al servidor.[/COLOR]" )
     return False
     if 58 - 58: O0oO
   except :
    pass
    if 7 - 7: II111iiii / i1I111II1I % O0oO + OOooOOo - O0
 return
 if 45 - 45: OOooOOo / O0ooOooooO + oO0o0ooO0 + i1I111II1I
 if 15 - 15: OOooOOo % OoOO
def oOoo00oO0O0OO ( ) :
 if 35 - 35: i11iIiiIii % O0oO
 Ii = [ ]
 oOOO00Oo = sys . argv [ 2 ]
 if len ( oOOO00Oo ) >= 2 :
  Ii1iii1 = sys . argv [ 2 ]
  iii11III1I = Ii1iii1 . replace ( '?' , '' )
  if ( Ii1iii1 [ len ( Ii1iii1 ) - 1 ] == '/' ) :
   Ii1iii1 = Ii1iii1 [ 0 : len ( Ii1iii1 ) - 2 ]
  oO0oO0O = iii11III1I . split ( '&' )
  Ii = { }
  for IiIIiiiIi in range ( len ( oO0oO0O ) ) :
   ooooO = { }
   ooooO = oO0oO0O [ IiIIiiiIi ] . split ( '=' )
   if ( len ( ooooO ) ) == 2 :
    Ii [ ooooO [ 0 ] ] = ooooO [ 1 ]
 return Ii
 if 99 - 99: o0oO0 - i1I111II1I * iIii1I11I1II1 . II111iiii
 if 56 - 56: iIii1I11I1II1 % OoOO . iI % i1I111II1I . Oooo0Ooo000 * ii11ii1ii
def Ii11II1i1I ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  import urlresolver
  xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
  if 45 - 45: O0ooOooooO + OoOO0ooOOoo0O / iIii1I11I1II1
def I1i1IIIIIII1 ( ) :
 oOii11I = xbmcgui . Dialog ( )
 list = (
 iI1I1I ,
 ii11
 )
 if 99 - 99: o00O0oo - oO0o0ooO0
 iiIo000Ooo00o00O = oOii11I . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=%s]Accede a themoviedb.com[/COLOR]' % iIIIi1 ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 80 - 80: O0ooOooooO
 if iiIo000Ooo00o00O :
  if 3 - 3: o00O0oo * O0oO
  if iiIo000Ooo00o00O < 0 :
   return
  Oo00O = list [ iiIo000Ooo00o00O - 2 ]
  return Oo00O ( )
 else :
  Oo00O = list [ iiIo000Ooo00o00O ]
  return Oo00O ( )
 return
 if 44 - 44: iI * O0oO
def i1ooOO00o0 ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 44 - 44: OOooOOo % IIII * i11iIiiIii * i11iIiiIii - ii11ii1ii . Oooo0Ooo000
o00i111iiIiiIiI = i1ooOO00o0 ( )
if 59 - 59: IIII + OOooOOo / II111iiii / OoOO0ooOOoo0O
def iI1I1I ( ) :
 if o00i111iiIiiIiI == 'android' :
  oOI11 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  oOI11 = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 80 - 80: OoOO0ooOOoo0O + iIii1I11I1II1 . i1I111II1I
  if 76 - 76: OOooOOo * IIII
def ii11 ( ) :
 if 12 - 12: iIii1I11I1II1 / O0oO % o0oO0
 main ( )
 if 49 - 49: OoOO + II111iiii / i1I111II1I - O0 % o0oO0
 if 27 - 27: OoOO + ii11ii1ii
 if 92 - 92: OOooOOo % O0ooOooooO
def iiiI1IiI ( ) :
 oOii11I = xbmcgui . Dialog ( )
 Ii111IIIIii = (
 O00o ,
 Iii1iIIiii1ii
 )
 if 13 - 13: iIii1I11I1II1 - II111iiii % O0 . o0oO0 % OoOO
 iiIo000Ooo00o00O = oOii11I . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 2 - 2: OoooooooOO - o0oO0 % oO0o0ooO0 / OOooOOo / o0000oOoOoO0o
 if iiIo000Ooo00o00O :
  if 3 - 3: II111iiii / IIII
  if iiIo000Ooo00o00O < 0 :
   return
  Oo00O = Ii111IIIIii [ iiIo000Ooo00o00O - 2 ]
  return Oo00O ( )
 else :
  Oo00O = Ii111IIIIii [ iiIo000Ooo00o00O ]
  return Oo00O ( )
 return
 if 48 - 48: iI . o00O0oo
def i1ooOO00o0 ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 49 - 49: i1IIi - OoOO0ooOOoo0O . ii11ii1ii + iIii1I11I1II1 - iI / ii11ii1ii
o00i111iiIiiIiI = i1ooOO00o0 ( )
if 24 - 24: oO0o0ooO0 - O0ooOooooO / iI
def O00o ( ) :
 if o00i111iiIiiIiI == 'android' :
  oOI11 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  oOI11 = webbrowser . open ( 'https://olpair.com/' )
  if 10 - 10: OoOO0ooOOoo0O * i1IIi
  if 15 - 15: O0oO + i1IIi - II111iiii % OOooOOo
def Iii1iIIiii1ii ( ) :
 if 34 - 34: OOooOOo
 main ( )
 if 57 - 57: IIII . o0oO0 % o0000oOoOoO0o
 if 32 - 32: O0oO / i1I111II1I - O0 * iIii1I11I1II1
def oo0oO0oOo0O ( name , url , id , trailer ) :
 oOii11I = xbmcgui . Dialog ( )
 Ii111IIIIii = (
 OoOo00 ,
 OOoOoO ,
 OO000o0oOoo0o ,
 I1i1IIIIIII1 ,
 IiiIiIIi
 )
 if 63 - 63: O0ooOooooO / o00O0oo * oO0o0ooO0 / II111iiii + IIII - O0
 iiIo000Ooo00o00O = oOii11I . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % iIIIi1 ,

 '[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % iIIIi1 ,

 '[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % iIIIi1 ,

 '[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % iIIIi1 ,

 '[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % iIIIi1 ] )
 if 16 - 16: II111iiii / o0oO0 . o0oO0 - o0oO0 / o00O0oo
 if iiIo000Ooo00o00O :
  if 28 - 28: IIII * OoooooooOO + iI % O0ooOooooO . iIii1I11I1II1
  if iiIo000Ooo00o00O < 0 :
   return
  Oo00O = Ii111IIIIii [ iiIo000Ooo00o00O - 5 ]
  return Oo00O ( )
 else :
  Oo00O = Ii111IIIIii [ iiIo000Ooo00o00O ]
  return Oo00O ( )
 return
 if 17 - 17: i1I111II1I / o0000oOoOoO0o . IIII + o0000oOoOoO0o / o00O0oo . ii11ii1ii
 if 39 - 39: o0000oOoOoO0o / i1I111II1I - O0ooOooooO
 if 96 - 96: O0oO * o00O0oo * o0oO0 + o00O0oo % OOooOOo + i11iIiiIii
def OoOo00 ( ) :
 if 37 - 37: O0oO % o00O0oo / iI
 Oo0o0ooO0ooo ( I1i11111i1i11 , OOoOOO0 )
 if 94 - 94: O0oO / OoOO . o0000oOoOoO0o
def OOoOoO ( ) :
 if 1 - 1: ii11ii1ii . II111iiii
 oooOo00O0 ( I1i11111i1i11 , I1I1i )
 if 93 - 93: II111iiii . i11iIiiIii + II111iiii % oO0o0ooO0
def OO000o0oOoo0o ( ) :
 if 98 - 98: Oooo0Ooo000 * oO0o0ooO0 * OoOO0ooOOoo0O + o0oO0 * O0ooOooooO
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  ii11iI1iIiiI = id
  if 99 - 99: i11iIiiIii - O0ooOooooO
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % ii11iI1iIiiI )
  if 85 - 85: Oooo0Ooo000 % o00O0oo
 if O0ii1ii1ii == 'true' :
  if 95 - 95: OoOO * IIII * O0ooOooooO . o0000oOoOoO0o
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + I1i11111i1i11 + "[/COLOR] ,5000)" )
  if 73 - 73: OoOO
def ii11iiII ( ) :
 if 57 - 57: OoOO0ooOOoo0O - O0 . OoooooooOO % iI - o0oO0
 I1i1IIIIIII1 ( )
 if 79 - 79: O0 + O0oO
def IiiIiIIi ( ) :
 if 25 - 25: Oooo0Ooo000 - o0oO0 / O0 . OoooooooOO % OOooOOo . i1IIi
 i11iIIi11 ( )
def oO0OoO00o ( name , url , mode , iconimage , fanart ) :
 if 19 - 19: II111iiii / II111iiii % o00O0oo + oO0o0ooO0 + oO0o0ooO0 + O0ooOooooO
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 oO0O000oOoo0O = True
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iII . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 iII . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  OO0oIiII1iiI = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII , isFolder = True )
  return oO0O000oOoo0O
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII , isFolder = True )
 return oO0O000oOoo0O
 if 4 - 4: o0000oOoOoO0o + O0oO / O0ooOooooO + i1IIi % o0000oOoOoO0o % O0ooOooooO
def IIII1i1 ( name , url , mode , iconimage , fanart , description ) :
 if 80 - 80: o0oO0
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 oO0O000oOoo0O = True
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iII . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 iII . setProperty ( 'fanart_image' , fanart )
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII , isFolder = True )
 return oO0O000oOoo0O
 if 26 - 26: iIii1I11I1II1 . OoooooooOO - iIii1I11I1II1
def oOo0O0 ( name , url , mode , iconimage ) :
 if 1 - 1: oO0o0ooO0 + Oooo0Ooo000 . OOooOOo
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 oO0O000oOoo0O = True
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iII . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 iII . setProperty ( 'fanart_image' , oo00 )
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII , isFolder = True )
 return oO0O000oOoo0O
 if 47 - 47: O0ooOooooO . OoOO0ooOOoo0O
 if 58 - 58: O0ooOooooO + ii11ii1ii / OOooOOo
def Ii111I11 ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 68 - 68: i1I111II1I * o0oO0
 ooOOoooooo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 91 - 91: o0oO0 + OoOO * o0000oOoOoO0o . Oooo0Ooo000
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 i1I1II = [ ]
 if 89 - 89: OoooooooOO * o0oO0 * OOooOOo . iI * o0oO0 / O0ooOooooO
 i1I1II . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 iII . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 iII . setProperty ( 'fanart_image' , fanart )
 iII . setProperty ( 'IsPlayable' , 'true' )
 if 46 - 46: i11iIiiIii
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  i1I1II . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 15 - 15: O0 / i1IIi / i1IIi . O0ooOooooO % OoOO0ooOOoo0O + OOooOOo
  iII . addContextMenuItems ( i1I1II , replaceItems = True )
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII )
 return oO0O000oOoo0O
 if 48 - 48: Oooo0Ooo000 % O0ooOooooO % o0oO0 % iIii1I11I1II1 . o0oO0
 if 14 - 14: O0ooOooooO * OoOO % O0 + O0oO + o00O0oo
def oo0O00ooo0o ( name , url , mode , iconimage , fanart , id , trailer , description ) :
 if 23 - 23: ii11ii1ii % O0ooOooooO + o0oO0 - Oooo0Ooo000
 ooOOoooooo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 65 - 65: OoooooooOO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 i1I1II = [ ]
 if 22 - 22: IIII + II111iiii + ii11ii1ii
 i1I1II . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 iII . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 iII . setProperty ( 'fanart_image' , fanart )
 iII . setProperty ( 'IsPlayable' , 'true' )
 if 83 - 83: iI
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  i1I1II . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 43 - 43: IIII
  iII . addContextMenuItems ( i1I1II , replaceItems = True )
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII )
 return oO0O000oOoo0O
 if 84 - 84: IIII . i1I111II1I . O0ooOooooO
def i1I1I1I ( name , url , mode , iconimage , fanart ) :
 if 2 - 2: ii11ii1ii - OoOO0ooOOoo0O
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 49 - 49: o0oO0 + II111iiii / oO0o0ooO0 - OoOO0ooOOoo0O % OoOO0ooOOoo0O + OOooOOo
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 iII . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 iII . setProperty ( 'fanart_image' , fanart )
 iII . setProperty ( 'IsPlayable' , 'true' )
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII )
 return oO0O000oOoo0O
 if 54 - 54: iI % ii11ii1ii - IIII
def iIi11IiiiII11 ( name , url , mode , iconimage ) :
 if 26 - 26: O0ooOooooO / OoooooooOO - ii11ii1ii
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 2 - 2: o00O0oo - ii11ii1ii
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 iII . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 iII . setProperty ( 'fanart_image' , oo00 )
 iII . setProperty ( 'IsPlayable' , 'true' )
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII )
 return oO0O000oOoo0O
 if 4 - 4: O0 / O0oO . OoOO - iI / IIII
def I1IIiIi1I1I1 ( name , url , mode , iconimage ) :
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 oO0O000oOoo0O = True
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII , isFolder = True )
 return oO0O000oOoo0O
 if 8 - 8: OoOO % iI . IIII / O0ooOooooO * iIii1I11I1II1 + OoooooooOO
def i1i1II1I ( ) :
 if 75 - 75: IIII / Oooo0Ooo000 - II111iiii % i11iIiiIii + OoOO
 if 13 - 13: iI - OOooOOo
 if 23 - 23: OOooOOo
 ooO = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 ooO . doModal ( )
 if ( ooO . isConfirmed ( ) ) :
  if 7 - 7: O0ooOooooO % o00O0oo
  Oo00o0OO0O00o = urllib . quote_plus ( ooO . getText ( ) ) . replace ( '+' , ' ' )
  if 64 - 64: Oooo0Ooo000 + i11iIiiIii
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 35 - 35: OoOO0ooOOoo0O + i1IIi % IIII
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % Oo00o0OO0O00o )
    if 68 - 68: i1I111II1I . iI
    if O0ii1ii1ii == 'true' :
     if 64 - 64: i1IIi + ii11ii1ii * OOooOOo / IIII
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + I1i11111i1i11 + "[/COLOR] ,10000)" )
     if 3 - 3: ii11ii1ii / iI + iI . o00O0oo
   except :
    if 50 - 50: iIii1I11I1II1 * oO0o0ooO0
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 85 - 85: i1IIi
    if 100 - 100: OoooooooOO / O0oO % OoOO + o0oO0
Ii1iii1 = oOoo00oO0O0OO ( )
OOoOOO0 = None
I1i11111i1i11 = None
IIi11 = None
O0OoOOO00 = None
id = None
I1I1i = None
if 77 - 77: ii11ii1ii - i1I111II1I
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 50 - 50: OoOO % OoooooooOO * II111iiii
try :
 OOoOOO0 = urllib . unquote_plus ( Ii1iii1 [ "url" ] )
except :
 pass
try :
 I1i11111i1i11 = urllib . unquote_plus ( Ii1iii1 [ "name" ] )
except :
 pass
try :
 IIi11 = int ( Ii1iii1 [ "mode" ] )
except :
 pass
try :
 O0OoOOO00 = urllib . unquote_plus ( Ii1iii1 [ "iconimage" ] )
except :
 pass
try :
 id = int ( Ii1iii1 [ "id" ] )
except :
 pass
try :
 I1I1i = urllib . unquote_plus ( Ii1iii1 [ "trailer" ] )
except :
 pass
 if 54 - 54: OoooooooOO + ii11ii1ii * IIII
 if 98 - 98: oO0o0ooO0 - oO0o0ooO0 . iI
print "Mode: " + str ( IIi11 )
print "URL: " + str ( OOoOOO0 )
print "Name: " + str ( I1i11111i1i11 )
print "iconimage: " + str ( O0OoOOO00 )
print "id: " + str ( id )
print "trailer: " + str ( I1I1i )
if 60 - 60: OOooOOo * o00O0oo / O0 + O0oO + i1I111II1I
if 66 - 66: i1I111II1I * ii11ii1ii . OoooooooOO * Oooo0Ooo000
def OOOoOoO ( ) :
 if 93 - 93: i1I111II1I / i1IIi
 try :
  if 47 - 47: iI - o0oO0
  OOoo0oo000 = IiIi ( OOOoOoO )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( OOoo0oo000 )
  for Ii11Ii in OOOOO0O00 :
   if 87 - 87: OoOO
   if Ii11Ii == 'si' :
    if 27 - 27: o0oO0 . o0000oOoOoO0o - OoOO0ooOOoo0O . II111iiii % ii11ii1ii
    import urlresolver
    from urlresolver import common
    import random
    from random import choice
    O0OOOo = xbmc . Player ( )
    Oo0O0O0ooO0O = [ 'gtG1Y3_34ug' , '3d_ACcf0rDc' , 'AKpPeLAMY9I' , 'sVBa5hNZFHM' , '5ZCVhFmbAY0' ]
    i1iiII11iiI = random . choice ( Oo0O0O0ooO0O )
    OOoOOO0 = 'https://www.youtube.com/watch?v=%s' % i1iiII11iiI
    OOoOOO0 = urlresolver . HostedMediaFile ( OOoOOO0 ) . resolve ( )
    O0OOOo . play ( OOoOOO0 )
    if 8 - 8: i1IIi + II111iiii / o0oO0 + o00O0oo % o0oO0 - iIii1I11I1II1
    iIi1iI == 'false'
    if 48 - 48: O0oO / iIii1I11I1II1 % II111iiii
   else :
    if 39 - 39: i1IIi . o00O0oo / O0oO / O0oO
    iIi1iI == 'false'
    if 100 - 100: OoooooooOO - OoooooooOO + i1I111II1I
    return False
    if 32 - 32: OoOO0ooOOoo0O * o0000oOoOoO0o / OoooooooOO
 except :
  pass
  if 90 - 90: Oooo0Ooo000
  if 35 - 35: II111iiii / o0oO0
  if 79 - 79: OoOO0ooOOoo0O + Oooo0Ooo000 * O0ooOooooO * o0oO0
if IIi11 == None or OOoOOO0 == None or len ( OOoOOO0 ) < 1 :
 if 53 - 53: IIII / ii11ii1ii
 if 10 - 10: o00O0oo . o0000oOoOoO0o
 IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 o00O0 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 oOO0O00Oo0O0o = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 OOoo0 = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 iiII1i11i = IiIi ( oOO0O00Oo0O0o )
 OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
 for III1I1I in OOOOO0O00 :
  if 75 - 75: O0 * i1IIi - O0oO / IIII % IIII / OoOO0ooOOoo0O
  try :
   if 5 - 5: O0 - O0ooOooooO / Oooo0Ooo000 . o0000oOoOoO0o
   if 7 - 7: o00O0oo - OoOO0ooOOoo0O
   IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 54 - 54: oO0o0ooO0 / iIii1I11I1II1 / OoooooooOO . i1IIi - OoOO0ooOOoo0O
   if 57 - 57: iIii1I11I1II1 * o0oO0 * O0ooOooooO / oO0o0ooO0
   if IIIi1I1IIii1II == III1I1I :
    if 46 - 46: o0oO0
    i11iIIi11 ( )
    I11iiiii1II ( )
    if 61 - 61: o0000oOoOoO0o / iI - II111iiii
    iIi1iI = IiII1IiiIiI1 . getSetting ( 'videos_event' )
    if iIi1iI == 'true' :
     xbmc . sleep ( 3000 )
     OOOoOoO ( )
     if 87 - 87: o00O0oo / OOooOOo
   else :
    if 45 - 45: OoOO0ooOOoo0O * iI / OoooooooOO + OoOO . Oooo0Ooo000 / OoOO
    iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
    oO0OoO00o ( '[COLOR %s]Video tutoriales[/COLOR]' % iIIIi1 , IIIII11I1IiI , 125 , O0OOO0OOoO0O , oo00 )
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Por favor compruebe los ajustes de realstream.[/COLOR]" , "[COLOR white] Desde la seccion Tutoriales puede sacarle mayor partido a su Realstream, tambien puede configurarlo a su gusto. [/COLOR]" , "[COLOR gold]El addon no esta activado o bien configurado.[/COLOR]" )
    if 64 - 64: o0oO0 / i1IIi % OOooOOo - o0000oOoOoO0o
  except :
   pass
   if 11 - 11: o00O0oo - OoooooooOO
elif IIi11 == 1 :
 oo0oO0oOo0O ( I1i11111i1i11 , OOoOOO0 , id , I1I1i )
elif IIi11 == 2 :
 iIiI ( )
elif IIi11 == 3 :
 OO0o0oO0O000o ( )
elif IIi11 == 4 :
 Ii1I1Iiii ( I1i11111i1i11 , OOoOOO0 )
elif IIi11 == 5 :
 ooooO0 ( )
elif IIi11 == 6 :
 ii1II1II ( )
elif IIi11 == 7 :
 oOOoO0O ( )
elif IIi11 == 8 :
 OO0OOoo0OOO ( )
elif IIi11 == 9 :
 OoOooOO0oOOo0O ( )
elif IIi11 == 10 :
 ii1IIiII111I ( )
elif IIi11 == 11 :
 o0OOOOOo0 ( )
elif IIi11 == 12 :
 iiIi ( )
elif IIi11 == 13 :
 Ooo00O0 ( )
elif IIi11 == 14 :
 OoO0Ooo ( )
elif IIi11 == 15 :
 ooOOO00oOOooO ( )
elif IIi11 == 16 :
 OoO0O0oo0o ( )
elif IIi11 == 17 :
 iI1iI ( )
elif IIi11 == 18 :
 iiII ( )
elif IIi11 == 19 :
 i1Ii11ii1I ( )
elif IIi11 == 20 :
 ooOO ( )
elif IIi11 == 21 :
 oO0O0o0o000 ( )
elif IIi11 == 22 :
 II1i ( )
elif IIi11 == 23 :
 o00OO0o0 ( )
elif IIi11 == 24 :
 Iii1I1iI ( )
elif IIi11 == 25 :
 ii111i1i ( )
elif IIi11 == 26 :
 Oooo0oOOO0 ( )
elif IIi11 == 28 :
 Ii11iI1ii1111 ( I1i11111i1i11 , OOoOOO0 )
elif IIi11 == 29 :
 o0oooOoo0OoOO ( )
elif IIi11 == 30 :
 OOoO0oo0O ( )
elif IIi11 == 31 :
 prueba ( )
elif IIi11 == 98 :
 busqueda_global ( )
elif IIi11 == 97 :
 iiiI1IiI ( )
elif IIi11 == 99 :
 IIIIiIi11iiIi ( )
elif IIi11 == 100 :
 menu_player ( I1i11111i1i11 , OOoOOO0 )
elif IIi11 == 111 :
 oooOoOOO0oo0o ( )
elif IIi11 == 115 :
 oooOo00O0 ( OOoOOO0 )
elif IIi11 == 116 :
 I1ii ( )
elif IIi11 == 117 :
 o00o ( )
elif IIi11 == 119 :
 I1IiIIi ( )
elif IIi11 == 120 :
 i1iI1iii11i ( )
elif IIi11 == 121 :
 oOOo ( )
elif IIi11 == 125 :
 O0OOO0ooO00o ( )
elif IIi11 == 112 :
 list_proxy ( )
elif IIi11 == 127 :
 i1i1II1I ( )
elif IIi11 == 128 :
 TESTLINKS ( )
elif IIi11 == 130 :
 Oo0o0ooO0ooo ( I1i11111i1i11 , OOoOOO0 )
elif IIi11 == 140 :
 ii11II1i ( )
elif IIi11 == 141 :
 o0Oo00oOO ( )
elif IIi11 == 142 :
 i1i1IiIiIi1Ii ( )
elif IIi11 == 143 :
 oOo0OooOo ( I1i11111i1i11 , OOoOOO0 )
elif IIi11 == 144 :
 Ii11iI1ii1111 ( I1i11111i1i11 , OOoOOO0 )
elif IIi11 == 145 :
 IIIII1iii11 ( )
elif IIi11 == 146 :
 iIi1Ii ( )
elif IIi11 == 147 :
 iI1IiiiIiI1Ii ( I1i11111i1i11 , OOoOOO0 )
elif IIi11 == 150 :
 oOO ( )
elif IIi11 == 151 :
 i1iiI ( )
elif IIi11 == 152 :
 iI11iiii1I ( )
elif IIi11 == 155 :
 iIIi ( )
 if 16 - 16: i1I111II1I % OoooooooOO - iI * o0oO0 - o0oO0
 if 27 - 27: i1I111II1I + iIii1I11I1II1 / ii11ii1ii + OoOO % ii11ii1ii + OoOO
xbmcplugin . endOfDirectory ( o0OoOoOO00 ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
