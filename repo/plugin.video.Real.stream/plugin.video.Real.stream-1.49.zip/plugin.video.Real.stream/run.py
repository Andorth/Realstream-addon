# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 1.46
#
############################################
# Dependencias 
# Script ExtendedInfo
# Script ResolveURL Por Jsergio.
############################################
#
# Agregado multi enlace de servidores.
# Agregado sistema individual de usuarios.
# Agregadas categorias de peliculas.
#
############################################
if 64 - 64: i11iIiiIii
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import resolveurl
import cookielib , base64
import requests
import plugintools
import config
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
IiII1IiiIiI1 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
o0OoOoOO00 = int ( sys . argv [ 1 ] )
I11i = 'gruponetai/'
O0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
Oo = O0O . getAddonInfo ( 'profile' )
I1ii11iIi11i = O0O . getAddonInfo ( 'path' )
I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
if 73 - 73: OOooOOo / ii11ii1ii
if 94 - 94: OoOO + OoOO0ooOOoo0O + o0000oOoOoO0o * o00O0oo
if I1IiI == 'true' :
 if 97 - 97: oO0o0ooO0 - IIII / O0oO - o0oO0
 oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.png' ) )
 o00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 Oo0oO0ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.png' ) )
 i1111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.png' ) )
 i11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'estrenos.png' ) )
 I11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.png' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.png' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.png' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.png' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.png' ) )
 oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.png' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.png' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.png' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.png' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.png' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.png' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.png' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'marvel.png' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.png' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.png' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.png' ) )
 II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.png' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.png' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.png' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.png' ) )
 OO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.png' ) )
 Ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.png' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.png' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.png' ) )
 O0OO00o0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.png' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.png' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_series.png' ) )
 OOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_Episodios.png' ) )
 if 87 - 87: O0ooOooooO / i1I111II1I - Oooo0Ooo000 - iI - II111iiii / O0
else :
 if 97 - 97: iI - IIII * i11iIiiIii / OoOO0ooOOoo0O % Oooo0Ooo000 - OoooooooOO
 if 59 - 59: O0 + OOooOOo + i1I111II1I % OOooOOo
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
 oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.jpg' ) )
 o00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 Oo0oO0ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.jpg' ) )
 i1111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.jpg' ) )
 i11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'encines.jpg' ) )
 I11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.jpg' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.jpg' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.jpg' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.jpg' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.jpg' ) )
 oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.jpg' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.jpg' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.jpg' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.jpg' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.jpg' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.jpg' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.jpg' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'superheroes.jpg' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.jpg' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.jpg' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.jpg' ) )
 II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.jpg' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.jpg' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.jpg' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.jpg' ) )
 OO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.jpg' ) )
 Ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.jpg' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.jpg' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.jpg' ) )
 O0OO00o0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.png' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.png' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.png' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favoritos.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_series.png' ) )
 OOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_Episodios.png' ) )
 if 70 - 70: O0ooOooooO * o00O0oo
 if 46 - 46: iI / OoOO
 if 52 - 52: o0000oOoOoO0o - OoooooooOO + o0oO0 + o0oO0 - o0000oOoOoO0o / Oooo0Ooo000
I1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'peliculas.png' ) )
iIi11Ii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series.png' ) )
Ii11iII1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ajustes.png' ) )
Oo0O0O0ooO0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'videoteca.png' ) )
IIIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
O0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'resolver.png' ) )
OO00Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'test.png' ) )
O0OOO0OOoO0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'video-tutoriales.png' ) )
O00Oo000ooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'proxy.png' ) )
if 100 - 100: O0 + i1I111II1I - IIII + i11iIiiIii * o0oO0
if 30 - 30: o0000oOoOoO0o . o0oO0 - OoooooooOO
if 8 - 8: i1IIi - iIii1I11I1II1 * II111iiii + i11iIiiIii / Oooo0Ooo000 % IIII
iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
OOoOO0oo0ooO = IiII1IiiIiI1 . getSetting ( 'mostrar_cat' )
O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'sel_tobox' )
O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'videos' )
i1Oo00 = IiII1IiiIiI1 . getSetting ( 'activar' )
i1i = IiII1IiiIiI1 . getSetting ( 'favcopy' )
iiI111I1iIiI = IiII1IiiIiI1 . getSetting ( 'anticopia' )
IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
oooooOoo0ooo = IiII1IiiIiI1 . getSetting ( 'mostrar_bus' )
I1I1IiI1 = IiII1IiiIiI1 . getSetting ( 'restante' )
III1iII1I1ii = IiII1IiiIiI1 . getSetting ( 'selecton' )
oOOo0 = IiII1IiiIiI1 . getSetting ( 'aviso' )
oo00O00oO = IiII1IiiIiI1 . getSetting ( 'RealStream_Settings' )
iIiIIIi = IiII1IiiIiI1 . getSetting ( 'Resolver_Settings' )
I1I1IiI1 = IiII1IiiIiI1 . getSetting ( 'restante' )
ooo00OOOooO = IiII1IiiIiI1 . getSetting ( 'fav' )
O00OOOoOoo0O = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
O000OOo00oo = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
oo0OOo = 'bienvenida'
ooOOO00Ooo = 'bienvenida'
copyright = IiII1IiiIiI1 . getSetting ( 'copyright' )
IiIIIi1iIi = 'cGx1Z2luLnZpZGVvLg==' . decode ( 'base64' ) + copyright
ooOOoooooo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
II1I = IiII1IiiIiI1 . getSetting ( 'Forceupdate' )
if II1I == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
O0i1II1Iiii1I11 = 'LnR4dA==' . decode ( 'base64' )
IIIIiiIiI = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1NQOUpRZExS' . decode ( 'base64' )
if 91 - 91: O0ooOooooO % i1IIi % iIii1I11I1II1
if 20 - 20: IIII % o0oO0 / o0oO0 + o0oO0
III1IiiI = 'aHR0cDovL2JpdC5seS8yU1FOSnlP' . decode ( 'base64' )
iIi1 = O000OOo00oo + oo0OOo + O0i1II1Iiii1I11
IIIII11I1IiI = 'http://www.youtube.com'
i1I = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
OoOOooOOO0 = 'http://bit.ly/2ImelUx'
o0o = '.xsl.pt'
O0OOoO00OO0o = 'L21hc3Rlci8=' . decode ( 'base64' )
I1111IIIIIi = i1I + o0o
Iiii1i1 = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*'
OO = 'tvg-logo=[\'"](.*?)[\'"]'
if 77 - 77: ii11ii1ii
I1iII1iIi1I = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.*)'
oO0O00OoOO0 = '(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)'
OoO = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
O00 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
I1iI1 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
iiiIi1 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
i1I1ii11i1Iii = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.+)\s*'
I1IiiiiI = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
o0O = '#(.+?),(.+)\s*(.+)'
IiII = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
ii1iII1II = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
Iii1I1I11iiI1 = '[\'"](.*?)[\'"]'
I1I1i1I = r'066">\s*(.+)</f'
ii1I = '[\'"](.*?)[\'"]'
O0oO0 = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
oO0 = '[\'"](.*?)[\'"]'
O0OO0O = 'src":"(.*?)"label":"(.*?)"lang":"(.*?)"'
OOOoOoO = 'https://pastebin.com/raw/SP9JQdLR'
Ii1I1i = '[\'"](.*?)[\'"]'
OOI1iI1ii1II = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( 'base64' )
O0O0OOOOoo = OOI1iI1ii1II + I11i
oOooO0 = '(.+),(.+),(.*)\s*'
Ii1I1Ii = '[\'"](.*?)[\'"]'
OOoO0 = 'UmVhbHN0cmVhbQ==' . decode ( 'base64' )
OO0Oooo0oOO0O = 'video=[\'"](.*?)[\'"]'
o00O0 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
oOO0O00Oo0O0o = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( 'base64' ) + o00O0
ii1 = '0101ahn' . replace ( '0101ahn' , 'sZn' )
I1iIIiiIIi1i = 'aHR0cDovL2JpdC5seS8yTnpB' . decode ( 'base64' ) + ii1
O0O0ooOOO = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
oOOo0O00o = '0110R0N' . replace ( '0110R0N' , 'R0N' )
iIiIi11 = 'aHR0cDovL2JpdC5seS8yWEIx' . decode ( 'base64' ) + oOOo0O00o
OOO = '0110pEJ' . replace ( '0110pEJ' , 'pEJ' )
iiiiI = 'aHR0cDovL2JpdC5seS8yd1Nh' . decode ( 'base64' ) + OOO
oooOo0OOOoo0 = 'ABBAOb5' . replace ( 'ABBAOb5' , 'Ob5' )
OOoO = 'aHR0cDovL2JpdC5seS8yRVhV' . decode ( 'base64' ) + oooOo0OOOoo0
OO0O000 = '0110jaw' . replace ( '0110jaw' , 'jaw' )
iiIiI1i1 = 'aHR0cDovL2JpdC5seS8yd01M' . decode ( 'base64' ) + OO0O000
oO0O00oOOoooO = '01109DI' . replace ( '01109DI' , '9DI' )
IiIi11iI = 'aHR0cDovL2JpdC5seS8ySXgz' . decode ( 'base64' ) + oO0O00oOOoooO
Oo0O00O000 = '01103hs' . replace ( '01103hs' , '3hs' )
i11I1IiII1i1i = 'aHR0cDovL2JpdC5seS8zMW1U' . decode ( 'base64' ) + Oo0O00O000
oo = '01107DW' . replace ( '01107DW' , '7DW' )
I1111i = 'aHR0cDovL2JpdC5seS8yV1ln' . decode ( 'base64' ) + oo
iIIii = '0110mLl' . replace ( '0110mLl' , 'mLl' )
o00O0O = 'aHR0cDovL2JpdC5seS8yS0cw' . decode ( 'base64' ) + iIIii
ii1iii1i = '01102Hj' . replace ( '01102Hj' , '2Hj' )
Iii1I1111ii = 'aHR0cDovL2JpdC5seS8yWEJo' . decode ( 'base64' ) + ii1iii1i
ooOoO00 = '0110fXg' . replace ( '0110fXg' , 'fXg' )
Ii1IIiI1i = 'aHR0cDovL2JpdC5seS8ySTVy' . decode ( 'base64' ) + ooOoO00
o0O00Oo0 = '0110NMH' . replace ( '0110NMH' , 'NMH' )
IiII111i1i11 = 'aHR0cDovL2JpdC5seS8yd0t6' . decode ( 'base64' ) + o0O00Oo0
i111iIi1i1II1 = '0110bwQ' . replace ( '0110bwQ' , 'bwQ' )
oooO = 'aHR0cDovL2JpdC5seS8yd01V' . decode ( 'base64' ) + i111iIi1i1II1
i1I1i111Ii = '0110xzG' . replace ( '0110xzG' , 'xzG' )
ooo = 'aHR0cDovL2JpdC5seS8yWHhz' . decode ( 'base64' ) + i1I1i111Ii
i1i1iI1iiiI = '0110x64' . replace ( '0110x64' , 'x64' )
Ooo0oOooo0 = 'aHR0cDovL2JpdC5seS8yRVlF' . decode ( 'base64' ) + i1i1iI1iiiI
oOOOoo00 = '0110vUE' . replace ( '0110vUE' , 'vUE' )
iiIiIIIiiI = 'aHR0cDovL2JpdC5seS8yWmhW' . decode ( 'base64' ) + oOOOoo00
iiI1IIIi = '01107ZL' . replace ( '01107ZL' , '7ZL' )
II11IiIi11 = 'aHR0cDovL2JpdC5seS8yWm4w' . decode ( 'base64' ) + iiI1IIIi
IIOOO0O00O0OOOO = '01106cf' . replace ( '01106cf' , '6cf' )
I1iiii1I = 'aHR0cDovL2JpdC5seS8yRVlk' . decode ( 'base64' ) + IIOOO0O00O0OOOO
OOo0 = '0110Jtp' . replace ( '0110Jtp' , 'Jtp' )
oO00ooooO0o = 'aHR0cDovL2JpdC5seS8yV3Nq' . decode ( 'base64' ) + OOo0
oo0o = '0110a5b' . replace ( '0110a5b' , 'a5b' )
o0oO0oooOoo = 'aHR0cDovL2JpdC5seS8yV3dj' . decode ( 'base64' ) + oo0o
I1III1111iIi = '0110Q7u' . replace ( '0110Q7u' , 'Q7u' )
I1i111I = 'aHR0cDovL2JpdC5seS8yV3NL' . decode ( 'base64' ) + I1III1111iIi
OooOo0oo0O0o00O = '0110rsq' . replace ( '0110rsq' , 'rsq' )
I1i11 = 'aHR0cDovL2JpdC5seS8ySzhE' . decode ( 'base64' ) + OooOo0oo0O0o00O
IiIi1I1 = '0110DDR' . replace ( '0110DDR' , 'DDR' )
IiIIi1 = 'aHR0cDovL2JpdC5seS8ySzd5' . decode ( 'base64' ) + IiIi1I1
IIIIiii1IIii = '0110feQ' . replace ( '0110feQ' , 'feQ' )
II1i11I = 'aHR0cDovL2JpdC5seS8yS0cz' . decode ( 'base64' ) + IIIIiii1IIii
ii1I1IIii11 = '0110MHY' . replace ( '0110MHY' , 'MHY' )
O0o0oO = 'aHR0cDovL2JpdC5seS8ySXVo' . decode ( 'base64' ) + ii1I1IIii11
IIIIiIiIi1 = '0110xdb' . replace ( '0110xdb' , 'xdb' )
I11iiiiI1i = 'aHR0cDovL2JpdC5seS8yWEJu' . decode ( 'base64' ) + IIIIiIiIi1
iI1i11 = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( 'base64' )
OoOOoooOO0O = 'aHR0cHM6Ly9uZXRhaS5ldS92aXNpdGFzL2luZGV4LnBocA==' . decode ( 'base64' )
IiIIIi1iIi = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
ooo00Ooo = '0110lxu' . replace ( '0110lxu' , 'lxu' )
Oo0o0O00 = 'aHR0cDovL2JpdC5seS8yV1Bj' . decode ( 'base64' ) + ooo00Ooo
ii1I1i11 = '0110pzp' . replace ( '0110pzp' , 'pzp' )
OOo0O0oo0OO0O = 'aHR0cDovL2JpdC5seS8yVHpB' . decode ( 'base64' ) + ii1I1i11
OO0 = '01105yt' . replace ( '01105yt' , '5yt' )
o0Oooo = 'aHR0cDovL2JpdC5seS8yTVpp' . decode ( 'base64' ) + OO0
if 36 - 36: OoooooooOO . OoOO
if 56 - 56: ii11ii1ii . o00O0oo . OOooOOo
ii111I = '1001DTs' . replace ( '1001DTs' , 'DTs' )
iiI = 'aHR0cDovL2JpdC5seS8ySzhP' . decode ( 'base64' ) + ii111I
iIiiiII = '1001Hky' . replace ( '1001Hky' , 'Hky' )
i1iI1 = 'aHR0cDovL2JpdC5seS8yTGVL' . decode ( 'base64' ) + iIiiiII
i11ii1ii11i = '1001VFU' . replace ( '1001VFU' , 'VFU' )
ooO0OoOO = 'aHR0cDovL2JpdC5seS8zMERx' . decode ( 'base64' ) + i11ii1ii11i
O0O0Oo00 = '3545OMZ' . replace ( '3545OMZ' , 'OMZ' )
oOoO00o = 'aHR0cDovL2JpdC5seS8yazhk' . decode ( 'base64' ) + O0O0Oo00
oO00O0 = '4224tZO' . replace ( '4224tZO' , 'tZO' )
IIi1IIIi = 'aHR0cDovL2JpdC5seS8zNXd4' . decode ( 'base64' ) + oO00O0
if 99 - 99: o0oO0 + OoOO * II111iiii . o0000oOoOoO0o - o00O0oo
if 58 - 58: o0oO0 + o0000oOoOoO0o - OOooOOo
if 3 - 3: OoOO
def oooOoOOO0oo0o ( ) :
 if 85 - 85: OoooooooOO % i1IIi * OoooooooOO / o00O0oo
 if 96 - 96: OoooooooOO + oO0o0ooO0
 try :
  iiII1i11i = IiIi ( iIiIi11 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   try :
    if 31 - 31: o0000oOoOoO0o % OoOO
    iiiiI = Iii
    if 14 - 14: oO0o0ooO0 / oO0o0ooO0 % iI
    ooO = xbmc . Keyboard ( '' , 'Busqueda por titulo' )
    ooO . doModal ( )
    if ( ooO . isConfirmed ( ) ) :
     ii = xbmcgui . DialogProgress ( )
     ii . create ( 'Realstream:' , 'Buscando ...' )
     OO0O0Ooo = range ( 0 , 76 )
     for oOoO0 in OO0O0Ooo :
      oOoO0 = oOoO0 + 1
      if 77 - 77: iIii1I11I1II1 . O0ooOooooO % O0ooOooooO + i11iIiiIii
     Oo00o0OO0O00o = urllib . quote_plus ( ooO . getText ( ) ) . replace ( '+' , ' ' )
     O0Oooo = IiIi ( iiiiI )
     OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( O0Oooo )
     for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
      if 27 - 27: o00O0oo + OoOO0ooOOoo0O - IIII + O0 . o0oO0
      ii . update ( oOoO0 , '[COLOR orange]Realstream: Buscando ...[/COLOR]' , ' [COLOR yellow] %s [/COLOR]' % I1i11111i1i11 )
      xbmc . sleep ( 1 )
      if ii . iscanceled ( ) : break ;
      if re . search ( Oo00o0OO0O00o , iIi1i1iIi1iI ( I1i11111i1i11 . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       if 26 - 26: OoooooooOO * OOooOOo + IIII
       ii . update ( 80 , ' [COLOR orange]Busqueda finalizada[/COLOR] ' )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR gold]Generando listado ...  [/COLOR][COLOR orange] Por favor espere ![/COLOR] ,1000)" )
       ii . update ( 100 , '[COLOR orange]Realstream: [/COLOR]' , '[COLOR gold] Busqueda finalizada ...[/COLOR]' )
       ii . close ( )
       IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
       if 43 - 43: O0
       if 39 - 39: OOooOOo . iIii1I11I1II1 * o0oO0 % iI . iIii1I11I1II1
     oO0OoO00o ( '[COLOR %s]Buscar Pelicula[/COLOR]' % iIIIi1 , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Resultados para: [COLOR orange]" + Oo00o0OO0O00o + "[/COLOR] ,2000)" )
     if 11 - 11: ii11ii1ii - OOooOOo * II111iiii . o00O0oo . oO0o0ooO0
   except : oO0OoO00o ( '[COLOR %s]Buscar Pelicula[/COLOR]' % iIIIi1 , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
   if 61 - 61: O0ooOooooO % OOooOOo - o0000oOoOoO0o - II111iiii % O0
 except :
  pass
  if 90 - 90: iIii1I11I1II1 + o00O0oo + iI - Oooo0Ooo000 * i1I111II1I . o00O0oo
def I11iiiii1II ( ) :
 if 51 - 51: O0 % oO0o0ooO0 - II111iiii
 oOOo0 = IiII1IiiIiI1 . getSetting ( 'aviso' )
 if 31 - 31: O0ooOooooO / ii11ii1ii - O0ooOooooO - IIII
 if oOOo0 == 'true' :
  if 7 - 7: O0ooOooooO % O0 . OoOO0ooOOoo0O + OOooOOo - O0oO
  try :
   iiII1i11i = IiIi ( iIi1 )
   OOOOO0O00 = re . compile ( Iiii1i1 ) . findall ( iiII1i11i )
   for o0o0O00oo0 , Ii1ii1IiIII in OOOOO0O00 :
    try :
     if 57 - 57: iIii1I11I1II1 / O0oO - i1IIi
     if 51 - 51: i1I111II1I
     ii11I1 = o0o0O00oo0
     oO0oo = Ii1ii1IiIII
     if 38 - 38: OoooooooOO * iI % O0 * OoOO0ooOOoo0O
     if 29 - 29: o00O0oo / i1IIi . OOooOOo - OoOO0ooOOoo0O - OoOO0ooOOoo0O - o0oO0
     from datetime import datetime
     if 20 - 20: i1IIi % OoOO . OOooOOo / i1I111II1I * i11iIiiIii * IIII
     OOo = datetime . now ( )
     i1i11I1I1iii1 = OOo . strftime ( '%d/%m/%Y' )
     iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
     if 8 - 8: iI + II111iiii / O0ooOooooO / O0oO
     if 74 - 74: O0 / i1IIi
     if 78 - 78: OoooooooOO . OoOO + iI - i1IIi
     if 31 - 31: OoooooooOO . IIII
     if 83 - 83: O0ooOooooO . O0 / ii11ii1ii / IIII - II111iiii
     oO0oO0 = "[B]" + ii11I1 + "[/B]"
     i1i1IIIIi1i = "" + oO0oo + ""
     Ii11iiI = "[COLOR white]Hoy es: " + i1i11I1I1iii1 + ", Su version instalada es:[/COLOR][COLOR gold] " + iIiiiI1IiI1I1 + "[/COLOR]"
     if 17 - 17: ii11ii1ii % IIII . i1IIi / OoooooooOO
     xbmcgui . Dialog ( ) . ok ( "Real Stream" , oO0oO0 , i1i1IIIIi1i , Ii11iiI )
    except :
     pass
     if 28 - 28: oO0o0ooO0 . II111iiii / o00O0oo + II111iiii . OoooooooOO . i1I111II1I
  except :
   pass
   if 53 - 53: o0oO0 % o0oO0 * o0000oOoOoO0o + OoOO0ooOOoo0O
  try :
   O0Oooo = IiIi ( iI1i11 )
   OOOOO0O00 = re . compile ( Iii1I1I11iiI1 ) . findall ( O0Oooo )
   for Oooo00 in OOOOO0O00 :
    if 6 - 6: o0oO0 - iI * IIII . O0ooOooooO / O0 * iI
    import xbmc
    import xbmcaddon
    if 22 - 22: ii11ii1ii % O0ooOooooO * o00O0oo / IIII % i11iIiiIii * O0oO
    __addon__ = xbmcaddon . Addon ( )
    __addonname__ = __addon__ . getAddonInfo ( 'name' )
    __icon__ = __addon__ . getAddonInfo ( 'icon' )
    if 95 - 95: OoooooooOO - i1I111II1I * OOooOOo + OoOO0ooOOoo0O
    iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
    iIi1i11iiI1111 = Oooo00
    if 97 - 97: ii11ii1ii * OOooOOo . iIii1I11I1II1
    oO0oO0 = "[COLOR orange] Ultima version: [/COLOR][COLOR white] [B]" + Oooo00 + " [/B][/COLOR]"
    I1Ii1111iIi = 4000
    xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , oO0oO0 , I1Ii1111iIi , __icon__ ) )
    if 31 - 31: O0oO . Oooo0Ooo000 * iI + i11iIiiIii * oO0o0ooO0
    if iIiiiI1IiI1I1 < Oooo00 :
     if 93 - 93: o00O0oo / iIii1I11I1II1 * i1IIi % OoooooooOO * O0 * O0oO
     xbmcgui . Dialog ( ) . ok ( "Real Stream" , "[COLOR white] Existe una nueva version de [/COLOR][COLOR fuchsia]Realstream[/COLOR]" , "[COLOR orange]Actualimete tiene instalada la version[/COLOR] [COLOR white][B] %s [/B][/COLOR]" % iIiiiI1IiI1I1 , " [COLOR white]Ya esta disponible la[/COLOR] [COLOR gold][B] %s [/B][/COLOR]" % Oooo00 )
     if 64 - 64: II111iiii + O0 / iIii1I11I1II1 / ii11ii1ii . iI % i1I111II1I
     if 50 - 50: iIii1I11I1II1 - i1I111II1I + IIII
  except :
   pass
   if 69 - 69: O0
   if 85 - 85: iI / O0
   if 18 - 18: o0000oOoOoO0o % O0 * o00O0oo
   if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 62 - 62: Oooo0Ooo000 . i1I111II1I . OoooooooOO
    if 11 - 11: IIII / O0oO
    if 73 - 73: i1IIi / i11iIiiIii
def iIi1i1iIi1iI ( s ) :
 if 58 - 58: ii11ii1ii . II111iiii + oO0o0ooO0 - i11iIiiIii / II111iiii / O0
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 85 - 85: OoOO0ooOOoo0O + IIII
def I1II ( file ) :
 if 27 - 27: II111iiii / o0oO0 . IIII
 try :
  i1II11II = open ( file , 'r' )
  iiII1i11i = i1II11II . read ( )
  i1II11II . close ( )
  return iiII1i11i
 except :
  pass
  if 87 - 87: OoOO0ooOOoo0O * Oooo0Ooo000 . O0oO
def IiIi ( url ) :
 if 51 - 51: IIII % iIii1I11I1II1 - OoooooooOO % iI * iIii1I11I1II1 % OoOO
 try :
  oO0o00oOOooO0 = urllib2 . Request ( url )
  oO0o00oOOooO0 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  OOOoO000 = urllib2 . urlopen ( oO0o00oOOooO0 )
  oOOOO = OOOoO000 . read ( )
  OOOoO000 . close ( )
  return oOOOO
 except urllib2 . URLError , Ii :
  print 'We failed to open "%s".' % url
  if hasattr ( Ii , 'code' ) :
   print 'We failed with error code - %s.' % Ii . code
  if hasattr ( Ii , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , Ii . reason
   if 15 - 15: i11iIiiIii % OOooOOo * O0oO / Oooo0Ooo000
def oooO0o0o0O0 ( url ) :
 oO0o00oOOooO0 = urllib2 . Request ( url )
 oO0o00oOOooO0 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 oO0o00oOOooO0 . add_header ( 'Referer' , '%s' % url )
 oO0o00oOOooO0 . add_header ( 'Connection' , 'keep-alive' )
 OOOoO000 = urllib2 . urlopen ( oO0o00oOOooO0 )
 oOOOO = OOOoO000 . read ( )
 OOOoO000 . close ( )
 return oOOOO
 if 27 - 27: OoooooooOO - O0ooOooooO / O0oO
 if 76 - 76: o0000oOoOoO0o % OOooOOo . iIii1I11I1II1 - i1I111II1I * OoooooooOO . O0ooOooooO
 if 84 - 84: Oooo0Ooo000 + O0oO
def IIiiIIi1 ( ) :
 if 59 - 59: i1I111II1I . IIII % II111iiii
 iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 if 39 - 39: o00O0oo
 if i1Oo00 == 'true' :
  if 97 - 97: IIII - OoOO / o0oO0 . i11iIiiIii % oO0o0ooO0 * oO0o0ooO0
  if 1 - 1: OOooOOo % iI
  try :
   if 65 - 65: OOooOOo + OoOO0ooOOoo0O / IIII
   iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
   o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
   OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
   if 83 - 83: o0000oOoOoO0o . O0ooOooooO - ii11ii1ii
   Ooo0O = IiIi ( I1iIIiiIIi1i )
   OOOOO0O00 = re . compile ( oOooO0 ) . findall ( Ooo0O )
   for o0oo0000OO , O0oOOo0Oo , o000O000 in OOOOO0O00 :
    if re . search ( OOO00O , o000O000 ) :
     if 19 - 19: iIii1I11I1II1
     if iiII1i1 == o0oo0000OO and o00oOO0o == O0oOOo0Oo and OOO00O == o000O000 :
      xbmc . sleep ( 3000 )
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR orange]Bienvenido![/COLOR][COLOR white] " + o0oo0000OO + "[/COLOR] ,3000)" )
      oO0OoO00o ( '[COLOR %s]Buscar Serie[/COLOR]' % iIIIi1 , 'search' , 145 , I1IIIii , oo00 )
      oO0OoO00o ( '[COLOR %s]Series[/COLOR] ' % iIIIi1 , 'movieDB' , 117 , iIi11Ii1 , oo00 )
      oO0OoO00o ( '[COLOR %s]Buscar Pelicula[/COLOR]' % iIIIi1 , 'search' , 146 , IIiiiiiiIi1I1 , oo00 )
      oO0OoO00o ( '[COLOR %s]Peliculas[/COLOR] ' % iIIIi1 , 'movieDB' , 116 , I1I , oo00 )
      if 26 - 26: OoooooooOO % OOooOOo % ii11ii1ii . OOooOOo % o0oO0
  except :
   pass
   if 34 - 34: i1I111II1I / OoOO0ooOOoo0O
 if oo00O00oO == 'true' :
  oO0OoO00o ( '[COLOR %s]Ajustes[/COLOR]' % iIIIi1 , 'Settings' , 119 , Ii11iII1 , oo00 )
  if 87 - 87: O0 * o0000oOoOoO0o * ii11ii1ii * II111iiii
  if 6 - 6: i1IIi . o00O0oo + OoOO0ooOOoo0O * O0oO / OoOO0ooOOoo0O % oO0o0ooO0
  if OOoOO0oo0ooO == 'true' :
   try :
    if 18 - 18: II111iiii . OoooooooOO % OoOO0ooOOoo0O % o0oO0
    iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
    o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
    OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
    if 9 - 9: OoOO - ii11ii1ii * OoooooooOO . ii11ii1ii
    if 2 - 2: OoooooooOO % IIII
    Ooo0O = IiIi ( I1iIIiiIIi1i )
    OOOOO0O00 = re . compile ( oOooO0 ) . findall ( Ooo0O )
    for O0oOOo0Oo , o0oo0000OO , o000O000 in OOOOO0O00 :
     if re . search ( OOO00O , o000O000 ) :
      if 63 - 63: OOooOOo % iIii1I11I1II1
      if iiII1i1 == o0oo0000OO and o00oOO0o == O0oOOo0Oo and OOO00O == o000O000 :
       if 39 - 39: O0ooOooooO / II111iiii / o00O0oo % OOooOOo
       O0Oo00 ( )
   except :
    pass
    if 41 - 41: iIii1I11I1II1 % O0oO
  if iIiIIIi == 'true' :
   if 59 - 59: IIII + i11iIiiIii
   oo0OOo0O ( )
   if 39 - 39: OoooooooOO + oO0o0ooO0 % IIII / IIII
  if iiI111I1iIiI == 'false' :
   if 27 - 27: O0ooOooooO . O0oO . iIii1I11I1II1 . iIii1I11I1II1
   oO0oO0 = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   i1i1IIIIi1i = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.ResolveURL para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   Ii11iiI = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, Script.resolveurl instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 20 - 20: o0000oOoOoO0o / i1IIi
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , oO0oO0 , i1i1IIIIi1i , Ii11iiI )
   if 71 - 71: OoOO0ooOOoo0O . i1IIi
def o0OooO0ooo0o ( ) :
 oO0OoO00o ( '[COLOR orange]Buscador por id[/COLOR]' , IIIII11I1IiI , 127 , oOOoo00O0O , oo00 )
 if 47 - 47: OoooooooOO
def ii1i1i1IiII ( ) :
 iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 oO0OoO00o ( '[COLOR %s]The movie DB[/COLOR]' % iIIIi1 , 'movieDB' , 99 , oOOoo00O0O , oo00 )
 if 63 - 63: O0ooOooooO . OoOO / II111iiii * i1I111II1I + oO0o0ooO0 % o0oO0
 if 12 - 12: Oooo0Ooo000 . OoOO . O0ooOooooO - OoooooooOO % ii11ii1ii
 if 36 - 36: IIII
 if 84 - 84: Oooo0Ooo000 . OoOO . II111iiii . O0oO / o0oO0 % o00O0oo
 if 57 - 57: OOooOOo % O0oO - IIII . OOooOOo / ii11ii1ii % O0ooOooooO
def OOI1iIi1iiIIiI ( ) :
 if 81 - 81: OoOO * OoOO0ooOOoo0O . IIII
 IIiiIIi1 ( )
 ii1i1i1IiII ( )
 if 11 - 11: i11iIiiIii - oO0o0ooO0 . oO0o0ooO0
def I11I ( ) :
 if 6 - 6: o00O0oo + oO0o0ooO0
 OOI1iIi1iiIIiI ( )
 if 48 - 48: iIii1I11I1II1 % i1IIi % O0ooOooooO + iI
def Iiii11iIi1 ( ) :
 if xbmc . getCondVisibility ( 'System.HasAddon(script.favourites)' ) :
  try :
   xbmc . executebuiltin ( "RunScript(script.favourites)" )
  except :
   pass
def i1iI11I1II1 ( ) :
 IiII1IiiIiI1 . openSettings ( )
 if 14 - 14: i11iIiiIii - O0ooOooooO * OoOO0ooOOoo0O
 if 51 - 51: o00O0oo / iIii1I11I1II1 % oO0o0ooO0 + o0000oOoOoO0o * iI + Oooo0Ooo000
def o0OoO00o0000O ( ) :
 resoveurl . display_settings ( )
 if 21 - 21: OOooOOo / iI % iI - o0000oOoOoO0o
def oOO ( ) :
 oO0OoO00o ( '[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % iIIIi1 , 'resolve' , 120 , O0o0 , oo00 )
 if 58 - 58: O0oO + II111iiii * O0ooOooooO * i11iIiiIii - iIii1I11I1II1
def oooo00o0o0o ( ) :
 if 87 - 87: O0oO * i1IIi - o0oO0 % IIII / Oooo0Ooo000
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 39 - 39: OOooOOo * i11iIiiIii - oO0o0ooO0 / i1I111II1I % Oooo0Ooo000 % O0oO
def oo0OOo0O ( ) :
 oO0OoO00o ( '[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % iIIIi1 , 'resolve' , 140 , O0o0 , oo00 )
 if 65 - 65: oO0o0ooO0 - iI % OoooooooOO / OoooooooOO % OoooooooOO
def O0Oo00 ( ) :
 if 52 - 52: o00O0oo + o00O0oo . II111iiii
 try :
  if 34 - 34: OoooooooOO . O0 / oO0o0ooO0 * OoOO0ooOOoo0O - o00O0oo
  iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
  OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 36 - 36: i1IIi / O0 / OoOO - O0 - i1IIi
  Ooo0O = IiIi ( I1iIIiiIIi1i )
  OOOOO0O00 = re . compile ( oOooO0 ) . findall ( Ooo0O )
  for o0oo0000OO , O0oOOo0Oo , o000O000 in OOOOO0O00 :
   if re . search ( OOO00O , o000O000 ) :
    if 22 - 22: i1IIi + o0oO0
    if iiII1i1 == o0oo0000OO and o00oOO0o == O0oOOo0Oo and OOO00O == o000O000 :
     if 54 - 54: iI % IIII . Oooo0Ooo000 + oO0o0ooO0 - IIII * OOooOOo
     oO0OoO00o ( '[COLOR %s]Buscador[/COLOR]' % iIIIi1 , 'search' , 146 , o0oOoO00o , oo00 )
     oO0OoO00o ( '[COLOR %s]Estrenos[/COLOR]' % iIIIi1 , IIIII11I1IiI , 3 , i11 , oo00 )
     if 92 - 92: o0000oOoOoO0o + Oooo0Ooo000 / ii11ii1ii % OoOO % i1I111II1I . OoooooooOO
     if 52 - 52: iI / i11iIiiIii - IIII . i1I111II1I % iIii1I11I1II1 + o0000oOoOoO0o
     if 71 - 71: oO0o0ooO0 % O0oO * OoOO0ooOOoo0O . O0 / o0oO0 . o00O0oo
     oO0OoO00o ( '[COLOR %s]Animacion[/COLOR]' % iIIIi1 , IIIII11I1IiI , 6 , oOo0oooo00o , oo00 )
     if 58 - 58: ii11ii1ii / oO0o0ooO0
     if 44 - 44: IIII
     if 54 - 54: o0oO0 - O0oO - Oooo0Ooo000 . iIii1I11I1II1
     if 79 - 79: o0oO0 . OoOO
     oO0OoO00o ( '[COLOR %s]Grandes Peliculas[/COLOR]' % iIIIi1 , IIIII11I1IiI , 30 , i1iiIIiiI111 , oo00 )
     if 40 - 40: o0000oOoOoO0o + ii11ii1ii . o0000oOoOoO0o % iI
     if 15 - 15: o0oO0 * ii11ii1ii % o00O0oo * iIii1I11I1II1 - i11iIiiIii
     if 60 - 60: OOooOOo * Oooo0Ooo000 % OoOO + oO0o0ooO0
     oO0OoO00o ( '[COLOR %s]Familiar[/COLOR]' % iIIIi1 , IIIII11I1IiI , 13 , ii11iIi1I , oo00 )
     if 52 - 52: i1IIi
     if 84 - 84: o0oO0 / i1I111II1I
     if 86 - 86: OoOO0ooOOoo0O * II111iiii - O0 . OoOO0ooOOoo0O % iIii1I11I1II1 / IIII
     if 11 - 11: OOooOOo * oO0o0ooO0 + o00O0oo / o00O0oo
     if 37 - 37: i11iIiiIii + i1IIi
     if 23 - 23: O0ooOooooO + O0oO . OoOO0ooOOoo0O * OOooOOo + o00O0oo
     if 18 - 18: i1I111II1I * o0000oOoOoO0o . i1I111II1I / O0
     if 8 - 8: o0000oOoOoO0o
     if 4 - 4: o00O0oo + o00O0oo * iI - OoOO0ooOOoo0O
     if 78 - 78: o0oO0 / II111iiii % OoOO0ooOOoo0O
     oO0OoO00o ( '[COLOR %s]Super heroes[/COLOR]' % iIIIi1 , IIIII11I1IiI , 24 , iIii1 , oo00 )
     oO0OoO00o ( '[COLOR %s]4k[/COLOR] En pruebas' % iIIIi1 , IIIII11I1IiI , 141 , O0o0Oo , oo00 )
     if 52 - 52: IIII - O0ooOooooO * oO0o0ooO0
     if 17 - 17: OoooooooOO + IIII * O0oO * OoOO0ooOOoo0O
     if 36 - 36: O0 + ii11ii1ii
 except :
  pass
  if 5 - 5: ii11ii1ii * OoOO0ooOOoo0O
  if 46 - 46: iI
def I11iIiII ( ) :
 if 66 - 66: ii11ii1ii - o0000oOoOoO0o * i1I111II1I + OoOO0ooOOoo0O + o0000oOoOoO0o - iIii1I11I1II1
 try :
  if 17 - 17: oO0o0ooO0
  iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
  OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 22 - 22: O0oO + iIii1I11I1II1
  Ooo0O = IiIi ( I1iIIiiIIi1i )
  OOOOO0O00 = re . compile ( oOooO0 ) . findall ( Ooo0O )
  for o0oo0000OO , O0oOOo0Oo , o000O000 in OOOOO0O00 :
   if re . search ( OOO00O , o000O000 ) :
    if 24 - 24: OoOO0ooOOoo0O % i1IIi + O0ooOooooO . i11iIiiIii . o00O0oo
    if iiII1i1 == o0oo0000OO and o00oOO0o == O0oOOo0Oo and OOO00O == o000O000 :
     if 17 - 17: o00O0oo . II111iiii . iI / o00O0oo
     oO0OoO00o ( '[COLOR %s]Buscar Serie[/COLOR]' % iIIIi1 , 'search' , 145 , O0OO00o0OO , oo00 )
     if 57 - 57: O0oO
     oO0oO00oOo0OOO ( )
     if 23 - 23: i1IIi . o0000oOoOoO0o * OoOO
     oO0OoO00o ( '[COLOR %s]En emision[/COLOR]' % iIIIi1 , IIIII11I1IiI , 150 , I11II1i , oo00 )
     oO0OoO00o ( '[COLOR %s]Mejor valoradas[/COLOR]' % iIIIi1 , IIIII11I1IiI , 151 , IIIII , oo00 )
     oO0OoO00o ( '[COLOR %s]Series Retro[/COLOR]' % iIIIi1 , IIIII11I1IiI , 152 , ooooooO0oo , oo00 )
     oO0OoO00o ( '[COLOR %s]Todas[/COLOR]' % iIIIi1 , IIIII11I1IiI , 142 , I11i1 , oo00 )
     if 15 - 15: OoOO0ooOOoo0O
     if 62 - 62: o0oO0
 except :
  pass
  if 51 - 51: OoOO0ooOOoo0O
  if 14 - 14: i1I111II1I % oO0o0ooO0 % ii11ii1ii - i11iIiiIii
  if 53 - 53: o0oO0 % ii11ii1ii
def oO0oO00oOo0OOO ( ) :
 if 59 - 59: IIII % iIii1I11I1II1 . i1IIi + II111iiii * i1I111II1I
 i1IiiI1iIi = 'aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtLw==' . decode ( 'base64' )
 oOOo00O0OOOo = 'Y29uZGljaW9uLnR4dA==' . decode ( 'base64' )
 oOOOO = i1IiiI1iIi + oOOo00O0OOOo
 i11I1I1iiI = '[\'"](.*?)[\'"]'
 I11iIiII = IiIi ( oOOOO )
 OOOOO0O00 = re . compile ( i11I1I1iiI ) . findall ( I11iIiII )
 for I1i1iii1Ii in OOOOO0O00 :
  try :
   if 23 - 23: i11iIiiIii
   if I1i1iii1Ii == 'si' or I1i1iii1Ii == 'Si' :
    if 39 - 39: o0000oOoOoO0o - o00O0oo % O0ooOooooO * OoOO - IIII / O0ooOooooO
    oO0OoO00o ( '[COLOR lime]+[/COLOR][COLOR %s] Hay Nuevos Episodios[/COLOR]' % iIIIi1 , IIIII11I1IiI , 155 , OOOO , oo00 )
    if 29 - 29: o00O0oo
   elif I1i1iii1Ii == 'no' or I1i1iii1Ii == 'No' :
    if 52 - 52: i11iIiiIii / i1IIi
    oO0OoO00o ( '[COLOR red]+[/COLOR][COLOR %s] No hay Nuevos Episodios[/COLOR]' % iIIIi1 , IIIII11I1IiI , 155 , oOoOooOo0o0 , oo00 )
    if 1 - 1: iI
   return
   if 78 - 78: o00O0oo + O0oO - O0
  except :
   pass
   if 10 - 10: Oooo0Ooo000 % OOooOOo
def oo0OoOooo ( ) :
 if 95 - 95: i1I111II1I * o00O0oo % iI % o0oO0 - o0oO0
 if 97 - 97: o00O0oo + iIii1I11I1II1 . O0
 try :
  if 64 - 64: i1IIi % iI / i11iIiiIii - i1IIi % IIII . O0ooOooooO
  II1i111 = IiIi ( iiI )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( II1i111 )
  for Iii in OOOOO0O00 :
   if 50 - 50: i1I111II1I % i1IIi
   try :
    if 21 - 21: OoooooooOO - iIii1I11I1II1
    OO0OoOOO0 = Iii
    ooO = xbmc . Keyboard ( '' , 'Buscar' )
    ooO . doModal ( )
    if ( ooO . isConfirmed ( ) ) :
     ii = xbmcgui . DialogProgress ( )
     ii . create ( 'Realstream:' , 'Buscando ...' )
     OO0O0Ooo = range ( 0 , 69 )
     for oOoO0 in OO0O0Ooo :
      oOoO0 = oOoO0 + 1
     Oo00o0OO0O00o = urllib . quote_plus ( ooO . getText ( ) ) . replace ( '+' , ' ' )
     O0Oooo = IiIi ( OO0OoOOO0 )
     OOOOO0O00 = re . compile ( OoO ) . findall ( O0Oooo )
     for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
      ii . update ( oOoO0 , '[COLOR orange]Realstream: Buscando ...[/COLOR]' , '[COLOR gold] %s [/COLOR]' % I1i11111i1i11 )
      xbmc . sleep ( 5 )
      if ii . iscanceled ( ) : break ;
      if re . search ( Oo00o0OO0O00o , iIi1i1iIi1iI ( I1i11111i1i11 . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       if 80 - 80: o0000oOoOoO0o - IIII + OoooooooOO
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Generando listado ...  [COLOR orange] Por favor espere ![/COLOR] , 4000)" )
       O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 143 , O00ooOo , oo00 , I1IIIiIiIi )
       ii . update ( 100 , '[COLOR orange]Realstream: [/COLOR]' , '[COLOR gold] Busqueda finalizada ...[/COLOR]' )
       xbmc . sleep ( 2000 )
       ii . close ( )
     oO0OoO00o ( '[COLOR %s]Buscar Serie[/COLOR]' % iIIIi1 , 'search' , 145 , O0OO00o0OO , oo00 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Sin Resultados para: [COLOR orange]" + Oo00o0OO0O00o + "[/COLOR] , 2000)" )
     if 26 - 26: OoOO0ooOOoo0O / ii11ii1ii - i1IIi + O0oO
     if 38 - 38: OoooooooOO / o00O0oo . O0 / i1IIi / ii11ii1ii + iIii1I11I1II1
   except : oO0OoO00o ( '[COLOR %s]Buscar Serie[/COLOR]' % iIIIi1 , 'search' , 145 , O0OO00o0OO , oo00 )
   if 96 - 96: O0ooOooooO
 except :
  pass
  if 18 - 18: O0ooOooooO * O0oO - o0oO0
def II1i1III ( ) :
 if 34 - 34: Oooo0Ooo000 - i11iIiiIii / iIii1I11I1II1
 try :
  if 87 - 87: o00O0oo / OoooooooOO - ii11ii1ii % OoOO0ooOOoo0O % i1I111II1I % ii11ii1ii
  II1i111 = IiIi ( IIi1IIIi )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( II1i111 )
  for Iii in OOOOO0O00 :
   if 29 - 29: OoooooooOO . OOooOOo % o00O0oo - O0ooOooooO
   try :
    if 8 - 8: i1IIi
    OO0OoOOO0 = Iii
    if 32 - 32: oO0o0ooO0 / II111iiii
   except :
    pass
    if 45 - 45: o00O0oo + OoOO * i11iIiiIii / IIII % O0oO * O0
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( OoO ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 17 - 17: O0
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 143 , O00ooOo , oo00 , I1IIIiIiIi )
    if 88 - 88: ii11ii1ii . O0 % OoooooooOO / IIII
   except :
    pass
 except :
  pass
  if 89 - 89: II111iiii / oO0o0ooO0
def IIo0OoO00 ( ) :
 if 18 - 18: oO0o0ooO0 - o0000oOoOoO0o - OOooOOo - OOooOOo
 try :
  if 54 - 54: ii11ii1ii + OOooOOo / O0ooOooooO . OOooOOo * OoOO0ooOOoo0O
  II1i111 = IiIi ( oOoO00o )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( II1i111 )
  for Iii in OOOOO0O00 :
   if 1 - 1: OoOO0ooOOoo0O * OoOO . i1IIi / ii11ii1ii . o00O0oo + ii11ii1ii
   try :
    if 17 - 17: ii11ii1ii + OoOO / o0oO0 / O0ooOooooO * IIII
    OO0OoOOO0 = Iii
    if 29 - 29: OoOO % OoooooooOO * oO0o0ooO0 / II111iiii - oO0o0ooO0
   except :
    pass
    if 19 - 19: i11iIiiIii
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( OoO ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 54 - 54: II111iiii . O0oO
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 143 , O00ooOo , oo00 , I1IIIiIiIi )
    if 73 - 73: OoOO0ooOOoo0O . OOooOOo
   except :
    pass
 except :
  pass
  if 32 - 32: OoOO0ooOOoo0O * OOooOOo % iI * o0oO0 . O0
  if 48 - 48: O0ooOooooO * O0ooOooooO
def I1I1 ( ) :
 if 4 - 4: o0000oOoOoO0o % OoOO0ooOOoo0O * IIII
 try :
  if 32 - 32: i11iIiiIii - Oooo0Ooo000
  II1i111 = IiIi ( ooO0OoOO )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( II1i111 )
  for Iii in OOOOO0O00 :
   if 53 - 53: OoooooooOO - i1I111II1I
   try :
    if 87 - 87: oO0o0ooO0 . OOooOOo
    OO0OoOOO0 = Iii
    if 17 - 17: o0oO0 . i11iIiiIii
   except :
    pass
    if 5 - 5: o00O0oo + O0 + O0 . Oooo0Ooo000 - iI
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( OoO ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 63 - 63: oO0o0ooO0
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 143 , O00ooOo , oo00 , I1IIIiIiIi )
    if 71 - 71: i1IIi . o0oO0 * O0ooOooooO % OoooooooOO + IIII
   except :
    pass
 except :
  pass
  if 36 - 36: i1I111II1I
def i1iiI ( ) :
 if 74 - 74: Oooo0Ooo000 % o00O0oo
 try :
  if 7 - 7: II111iiii
  II1i111 = IiIi ( i1iI1 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( II1i111 )
  for Iii in OOOOO0O00 :
   if 27 - 27: oO0o0ooO0 . OoooooooOO + i11iIiiIii
   try :
    if 86 - 86: O0oO / o0000oOoOoO0o - o0000oOoOoO0o + o00O0oo + oO0o0ooO0
    OO0OoOOO0 = Iii
    if 33 - 33: o0000oOoOoO0o . O0ooOooooO . i1I111II1I . i1IIi
   except :
    pass
    if 49 - 49: o00O0oo
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( OoO ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 84 - 84: O0oO - ii11ii1ii / O0 - Oooo0Ooo000
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 143 , O00ooOo , oo00 , I1IIIiIiIi )
    if 21 - 21: O0 * O0 % o00O0oo
   except :
    pass
 except :
  pass
  if 94 - 94: O0oO + II111iiii % i11iIiiIii
def i1i1IiIiIi1Ii ( ) :
 if 64 - 64: IIII + OoooooooOO * OoooooooOO
 try :
  if 41 - 41: iI . ii11ii1ii + OOooOOo
  II1i111 = IiIi ( iiI )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( II1i111 )
  for Iii in OOOOO0O00 :
   if 100 - 100: o0oO0 + OoOO
   try :
    if 73 - 73: i1IIi - Oooo0Ooo000 % iI / OoOO
    OO0OoOOO0 = Iii
    if 40 - 40: o00O0oo * iI - OOooOOo / i1I111II1I / i11iIiiIii
   except :
    pass
    if 83 - 83: o00O0oo / Oooo0Ooo000 - i11iIiiIii . iIii1I11I1II1 + ii11ii1ii
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( OoO ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 59 - 59: O0 % ii11ii1ii
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 143 , O00ooOo , oo00 , I1IIIiIiIi )
    if 92 - 92: o0oO0 % O0ooOooooO / o00O0oo % o00O0oo * OOooOOo
   except :
    pass
 except :
  pass
  if 74 - 74: O0 . OOooOOo % OoOO % i1I111II1I
def oOo0OooOo ( name , url ) :
 if 51 - 51: O0oO . ii11ii1ii
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 45 - 45: i1IIi - ii11ii1ii / O0 . o00O0oo
 iI1 = IiIi ( url )
 OOOOO0O00 = re . compile ( iiiIi1 ) . findall ( iI1 )
 for O00ooOo , name , oo00 , url in OOOOO0O00 :
  try :
   if 14 - 14: o00O0oo
   if 49 - 49: oO0o0ooO0 / i1IIi % o0oO0 . OOooOOo
   O00OOOoOoo0O = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % O00OOOoOoo0O + name + '[/COLOR]'
   oOOoOoo0O0 ( name , url , 144 , O00ooOo , oo00 )
   if 45 - 45: i11iIiiIii
   if 82 - 82: o0oO0 + i1I111II1I
  except :
   pass
   if 12 - 12: Oooo0Ooo000
   if 93 - 93: i11iIiiIii % iIii1I11I1II1 % i11iIiiIii + o0000oOoOoO0o / o0000oOoOoO0o / II111iiii
   if 49 - 49: IIII . o00O0oo . i11iIiiIii - II111iiii / o0oO0
def oOOoOoo0O0 ( name , url , mode , iconimage , fanart ) :
 if 62 - 62: IIII
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 1 - 1: i1I111II1I / i1I111II1I - i11iIiiIii
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage="
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 iII . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 iII . setProperty ( 'fanart_image' , fanart )
 iII . setProperty ( 'IsPlayable' , 'true' )
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII )
 return oO0O000oOoo0O
 if 9 - 9: oO0o0ooO0 * i1IIi - i1IIi
 if 16 - 16: OOooOOo * i1IIi - o0000oOoOoO0o . i1I111II1I % O0oO / o0000oOoOoO0o
def Ii11iI1ii1111 ( name , url ) :
 if 42 - 42: Oooo0Ooo000 + Oooo0Ooo000 * II111iiii
 if 78 - 78: OoooooooOO
 IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 o00O0 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 oOO0O00Oo0O0o = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 OOoo0 = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 iiII1i11i = IiIi ( oOO0O00Oo0O0o )
 OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
 for III1I1I in OOOOO0O00 :
  if 14 - 14: o0oO0 . i11iIiiIii
  try :
   if 27 - 27: iI % O0 % Oooo0Ooo000
   if 99 - 99: OOooOOo + i1IIi + i11iIiiIii + ii11ii1ii % oO0o0ooO0 / O0oO
   IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 60 - 60: o0oO0 * OoOO0ooOOoo0O - i11iIiiIii % iI
   if 52 - 52: o00O0oo % oO0o0ooO0 - i11iIiiIii
   if IIIi1I1IIii1II == III1I1I :
    if 30 - 30: O0ooOooooO / OoOO + oO0o0ooO0
    if 'https://mybox.com' in url :
     if 6 - 6: O0ooOooooO . O0oO + o0oO0 . Oooo0Ooo000
     url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
     if 70 - 70: OoOO
    if 'uptostream.com' in url :
     if 46 - 46: O0oO - i1IIi
     try :
      if 46 - 46: Oooo0Ooo000 % o0oO0
      iiII1i11i = IiIi ( url )
      OOOOO0O00 = re . compile ( O0OO0O ) . findall ( iiII1i11i )
      for url , oOOoO0OO00OOo0 , Ii1IIii in OOOOO0O00 :
       if 21 - 21: OoOO0ooOOoo0O / o0000oOoOoO0o * i1I111II1I . i1IIi
       oOOoO0OO00OOo0 = oOOoO0OO00OOo0 . replace ( '","res":"2160",' , ' ' ) . replace ( '","res":"1080",' , ' ' ) . replace ( '","res":"720",' , ' ' ) . replace ( '","res":"480",' , ' ' ) . replace ( '","res":"360",' , ' ' )
       url = url . replace ( '\/' , '/' )
       url = url . replace ( ',"type":"video/mp4",' , ' ' )
       Ii1IIii = Ii1IIii . replace ( 'spa' , 'Castellano:' ) . replace ( 'eng' , 'Ingles:' ) . replace ( 'spa1' , 'Latino:' ) . replace ( 'eng2' , 'Americano:' )
       name = '[COLOR white]' + Ii1IIii + '[/COLOR] - [COLOR gold]' + oOOoO0OO00OOo0 + '[/COLOR]'
       if 59 - 59: O0 + i1IIi - o0000oOoOoO0o
       OooOo000o0o = [ ]
       OooOo000o0o . append ( '[COLOR orange]Real Stream: [/COLOR][COLOR gold]1. Mostrar mas info. [Reiniciar][/COLOR]' )
       OooOo000o0o . append ( '[COLOR gold]2. Mostar otras calidades disponibles [/COLOR]' )
       OooOo000o0o . append ( '[COLOR gold]3. Ver en: %s [/COLOR]' % name )
       if 42 - 42: oO0o0ooO0 % IIII
       if 60 - 60: OoOO0ooOOoo0O / Oooo0Ooo000 - II111iiii . ii11ii1ii + O0
       Ii1iI = 'Seleccione una calidad e idioma:'
       Oo0O0O000 = xbmcgui . Dialog ( )
       II1Ii = Oo0O0O000 . select ( Ii1iI , OooOo000o0o )
       if 57 - 57: OoOO0ooOOoo0O - oO0o0ooO0 / iI % i11iIiiIii
       if 3 - 3: O0ooOooooO . iI % OOooOOo + o00O0oo
       if II1Ii == 0 :
        if 64 - 64: i1IIi
        oO0O000oOoo0O = Oo0O0O000 . ok ( "[COLOR darkpink]REALSTREAM:[/COLOR] " , "[COLOR gold]  Reiniciadas las opciones.  [/COLOR]" , "" )
        del Oo0O0O000
        return
        if 29 - 29: o0000oOoOoO0o / i11iIiiIii / OOooOOo % oO0o0ooO0 % i11iIiiIii
       elif II1Ii == 1 :
        if 18 - 18: IIII + Oooo0Ooo000
        pass
        if 80 - 80: oO0o0ooO0 + o0000oOoOoO0o * o0oO0 + OoOO
        del Oo0O0O000
        if 75 - 75: O0oO / o0000oOoOoO0o / IIII / i1I111II1I % iI + II111iiii
        if 4 - 4: O0ooOooooO - ii11ii1ii - i1I111II1I - O0oO % i11iIiiIii / OoOO
        if 50 - 50: iI + i1IIi
        if 31 - 31: o0oO0
       elif II1Ii == 2 :
        if 78 - 78: i11iIiiIii + o0000oOoOoO0o + Oooo0Ooo000 / o0000oOoOoO0o % iIii1I11I1II1 % i1I111II1I
        Oo0O0Oo00O ( name , url )
        if 9 - 9: o0000oOoOoO0o . OOooOOo - o00O0oo
        return
        if 32 - 32: OoooooooOO / OOooOOo / iIii1I11I1II1 + II111iiii . oO0o0ooO0 . o0000oOoOoO0o
     except :
      pass
      if 21 - 21: iIii1I11I1II1 / II111iiii % i1IIi
      if 8 - 8: OoOO + OoOO0ooOOoo0O . iIii1I11I1II1 % O0
    if 'https://team.com' in url :
     if 43 - 43: o00O0oo - O0ooOooooO
     url = url . replace ( 'https://team.com' , 'https://verystream.com' )
     if 70 - 70: O0ooOooooO / IIII % iI - o0oO0
     if 47 - 47: O0ooOooooO
     if 92 - 92: IIII + OoOO0ooOOoo0O % i1IIi
    if 'https://vidcloud.co/' in url :
     if 23 - 23: Oooo0Ooo000 - IIII + o0oO0 - OoOO0ooOOoo0O * OoOO0ooOOoo0O . ii11ii1ii
     url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
     if 47 - 47: oO0o0ooO0 % iIii1I11I1II1
    if 'https://gounlimited.to' in url :
     if 11 - 11: OOooOOo % o0oO0 - OoOO - oO0o0ooO0 + o0000oOoOoO0o
     url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
     if 98 - 98: O0ooOooooO + o0oO0 - OoOO
    if 'https://drive.com' in url :
     if 79 - 79: IIII / Oooo0Ooo000 . OoOO0ooOOoo0O - o00O0oo
     url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
     if 47 - 47: OoooooooOO % O0 * O0ooOooooO . o0oO0
     if 38 - 38: O0 - i1I111II1I % Oooo0Ooo000
     if 64 - 64: iIii1I11I1II1
     if 15 - 15: o00O0oo + IIII / o00O0oo / Oooo0Ooo000
    import resolveurl
    if 31 - 31: iI + O0 + iI . iIii1I11I1II1 + ii11ii1ii / o0000oOoOoO0o
    II11i1IiIII = resolveurl . HostedMediaFile ( url )
    if 67 - 67: ii11ii1ii / O0ooOooooO * OoooooooOO
    if not II11i1IiIII :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
     return False
     if 100 - 100: O0 . O0oO . OoOO + O0 * oO0o0ooO0
    try :
     ii = xbmcgui . DialogProgress ( )
     ii . create ( 'Realstream:' , 'Iniciando ...' )
     ii . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
     xbmc . sleep ( 1000 )
     iIIiIIIIiII = II11i1IiIII . resolve ( )
     if not iIIiIIIIiII or not isinstance ( iIIiIIIIiII , basestring ) :
      try : oOOO0O0o = iIIiIIIIiII . msg
      except : oOOO0O0o = url
      raise Exception ( oOOO0O0o )
      if 49 - 49: O0oO . iI * OoOO0ooOOoo0O % i1I111II1I . O0
    except Exception as Ii :
     try : oOOO0O0o = str ( Ii )
     except : oOOO0O0o = url
     ii . update ( 45 , 'RESOLVEURL:' , 'Reiniciando ... ' )
     xbmc . sleep ( 1000 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Episodio no disponible.  ,3000)" )
     ii . close ( )
     if 48 - 48: O0 * o0oO0 - O0 / o0oO0 + OoOO0ooOOoo0O
    ii . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    ii . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
    xbmc . sleep ( 500 )
    ii . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
    xbmc . sleep ( 500 )
    ii . update ( 100 , 'RESOLVEURL:' , 'Disfrute de este capitulo!' )
    ii . close ( )
    O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
    oO00oo000O = xbmcgui . ListItem ( path = iIIiIIIIiII )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO00oo000O )
    if 7 - 7: O0 / O0ooOooooO * oO0o0ooO0
    if 29 - 29: o0000oOoOoO0o
   else :
    if 86 - 86: II111iiii . i1I111II1I
    O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
    if O0ii1ii1ii == 'true' :
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Por favor compruebe los ajustes de realstream.[/COLOR]" , "[COLOR white] Desde la seccion Tutoriales puede sacarle mayor partido a su Realstream, tambien puede configurarlo a su gusto. [/COLOR]" , "[COLOR gold]El addon no esta activado o bien configurado.[/COLOR]" )
     if 2 - 2: OoooooooOO
     iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
     oO0OoO00o ( '[COLOR %s]Video tutoriales[/COLOR]' % iIIIi1 , IIIII11I1IiI , 125 , O0OOO0OOoO0O , oo00 )
  except :
   pass
   if 60 - 60: OoOO
   if 81 - 81: OoOO0ooOOoo0O % o0oO0
   if 87 - 87: iIii1I11I1II1 . OoooooooOO * OoOO0ooOOoo0O
   if 100 - 100: OoOO / i1IIi - OOooOOo % o0oO0 - iIii1I11I1II1
i11II = '10011hI' . replace ( '10011hI' , '1hI' )
o0oo00o0O0O00 = 'aHR0cDovL2JpdC5seS8yUUJQ' . decode ( 'base64' ) + i11II
iIIOOoO0oO00o = '1001j1G' . replace ( '1001j1G' , 'j1G' )
iiiiii1 = 'aHR0cDovL2JpdC5seS8zNXpw' . decode ( 'base64' ) + iIIOOoO0oO00o
OO0o0oO0O000o = '1001N00' . replace ( '1001N00' , 'N00' )
I1iI11iii = 'aHR0cDovL2JpdC5seS8zMGRS' . decode ( 'base64' ) + OO0o0oO0O000o
oo0oO = '1001Q7q' . replace ( '1001Q7q' , 'Q7q' )
IiIi1iI11 = 'aHR0cDovL2JpdC5seS8zN1Bi' . decode ( 'base64' ) + oo0oO
iiI1iI1I = '1001K0z' . replace ( '1001K0z' , 'K0z' )
III1II111Ii1 = 'aHR0cDovL2JpdC5seS8yU2NS' . decode ( 'base64' ) + iiI1iI1I
o0O0OO0o = '1001TTi' . replace ( '1001TTi' , 'TTi' )
OOOoOo = 'aHR0cDovL2JpdC5seS8zNkhT' . decode ( 'base64' ) + o0O0OO0o
OOoO0oo0O = '011057w' . replace ( '011057w' , '57w' )
iiiiI = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0Q5TXl1' . decode ( 'base64' ) + OOoO0oo0O
if 49 - 49: o0000oOoOoO0o
def II1ii1ii11I1 ( ) :
 if 88 - 88: o00O0oo
 if 93 - 93: iIii1I11I1II1
 try :
  if 66 - 66: i11iIiiIii * iIii1I11I1II1 % OoooooooOO
  II1i111 = IiIi ( o0oo00o0O0O00 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( II1i111 )
  for Iii in OOOOO0O00 :
   if 5 - 5: OoOO0ooOOoo0O % OoooooooOO
   try :
    if 60 - 60: OoOO0ooOOoo0O . i1IIi % OoOO % iI % IIII
    OO0OoOOO0 = Iii
    ooO = xbmc . Keyboard ( '' , 'Buscar' )
    ooO . doModal ( )
    if ( ooO . isConfirmed ( ) ) :
     ii = xbmcgui . DialogProgress ( )
     ii . create ( 'Realstream:' , 'Buscando ...' )
     OO0O0Ooo = range ( 0 , 69 )
     for oOoO0 in OO0O0Ooo :
      oOoO0 = oOoO0 + 1
     Oo00o0OO0O00o = urllib . quote_plus ( ooO . getText ( ) ) . replace ( '+' , ' ' )
     O0Oooo = IiIi ( OO0OoOOO0 )
     OOOOO0O00 = re . compile ( I1iI1 ) . findall ( O0Oooo )
     for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
      ii . update ( oOoO0 , '[COLOR orange]Realstream: Buscando ...[/COLOR]' , '[COLOR gold] %s [/COLOR]' % I1i11111i1i11 )
      xbmc . sleep ( 5 )
      if ii . iscanceled ( ) : break ;
      if re . search ( Oo00o0OO0O00o , iIi1i1iIi1iI ( I1i11111i1i11 . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       if 33 - 33: iIii1I11I1II1 - o0oO0 * o00O0oo % iIii1I11I1II1 + OoOO . IIII
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Generando listado ...  [COLOR orange] Por favor espere ![/COLOR] , 4000)" )
       O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 147 , O00ooOo , oo00 , I1IIIiIiIi )
       ii . update ( 100 , '[COLOR orange]Realstream: [/COLOR]' , '[COLOR gold] Busqueda finalizada ...[/COLOR]' )
       xbmc . sleep ( 2000 )
       ii . close ( )
     oO0OoO00o ( '[COLOR %s]Buscar Pelicula[/COLOR]' % iIIIi1 , 'search' , 146 , O0OO00o0OO , oo00 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Sin Resultados para: [COLOR orange]" + Oo00o0OO0O00o + "[/COLOR] , 2000)" )
     if 56 - 56: i11iIiiIii * O0ooOooooO . oO0o0ooO0
     if 78 - 78: OoOO0ooOOoo0O
   except : oO0OoO00o ( '[COLOR %s]Buscar Pelicula[/COLOR]' % iIIIi1 , 'search' , 146 , O0OO00o0OO , oo00 )
   if 1 - 1: IIII . i1I111II1I
 except :
  pass
  if 42 - 42: IIII % oO0o0ooO0 / OoOO - oO0o0ooO0 * i11iIiiIii
def iI1IiiiIiI1Ii ( ) :
 if 78 - 78: OoooooooOO / IIII % OoOO0ooOOoo0O * OoooooooOO
 try :
  if 68 - 68: oO0o0ooO0
  II1i111 = IiIi ( o0oo00o0O0O00 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( II1i111 )
  for Iii in OOOOO0O00 :
   if 29 - 29: O0ooOooooO + i11iIiiIii % O0oO
   try :
    if 93 - 93: OoOO0ooOOoo0O % iIii1I11I1II1
    OO0OoOOO0 = Iii
    if 90 - 90: OOooOOo - IIII / o0oO0 / O0 / O0oO
   except :
    pass
    if 87 - 87: OoOO0ooOOoo0O / i1I111II1I + iIii1I11I1II1
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( I1iI1 ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 93 - 93: iIii1I11I1II1 + oO0o0ooO0 % iI
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 147 , O00ooOo , oo00 , I1IIIiIiIi )
    if 21 - 21: IIII
   except :
    pass
 except :
  pass
  if 6 - 6: i1I111II1I
  if 46 - 46: i1I111II1I + oO0o0ooO0
  if 79 - 79: OoooooooOO - i1I111II1I * i1I111II1I . OoOO0ooOOoo0O
def Oo00ooO0OoOo ( ) :
 if 99 - 99: OoOO0ooOOoo0O
 try :
  if 77 - 77: o0000oOoOoO0o
  II1i111 = IiIi ( iiiiii1 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( II1i111 )
  for Iii in OOOOO0O00 :
   if 48 - 48: OoOO0ooOOoo0O % o00O0oo / O0oO . iIii1I11I1II1 * II111iiii
   try :
    if 65 - 65: OoOO0ooOOoo0O
    OO0OoOOO0 = Iii
    if 31 - 31: O0oO * OoOO0ooOOoo0O . i1I111II1I % o0oO0 + ii11ii1ii
   except :
    pass
    if 47 - 47: O0 * OOooOOo * OoOO . II111iiii
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( I1iI1 ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 95 - 95: o0oO0 % i1I111II1I . O0 % Oooo0Ooo000
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 147 , O00ooOo , oo00 , I1IIIiIiIi )
    if 68 - 68: ii11ii1ii . ii11ii1ii - o00O0oo / O0oO . iI / i1IIi
   except :
    pass
 except :
  pass
  if 12 - 12: o00O0oo * i1IIi * O0oO
def i1iiII11 ( ) :
 if 54 - 54: o0oO0 - Oooo0Ooo000
 try :
  if 81 - 81: i1I111II1I . O0 + II111iiii * iIii1I11I1II1 * IIII / OoOO0ooOOoo0O
  Oo0OoOOOo = IiIi ( III1II111Ii1 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( Oo0OoOOOo )
  for Iii in OOOOO0O00 :
   if 7 - 7: Oooo0Ooo000 / OoOO - oO0o0ooO0 + o00O0oo / O0ooOooooO % OoOO
   try :
    if 31 - 31: o0oO0
    OO0OoOOO0 = Iii
    if 18 - 18: iI + o0oO0
   except :
    pass
    if 5 - 5: OoooooooOO + O0oO * II111iiii
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( I1iI1 ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 98 - 98: IIII % i1IIi . OOooOOo . II111iiii . o00O0oo / i11iIiiIii
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 147 , O00ooOo , oo00 , I1IIIiIiIi )
    if 32 - 32: o0000oOoOoO0o + OOooOOo . Oooo0Ooo000
   except :
    pass
 except :
  pass
  if 41 - 41: OoOO0ooOOoo0O . i11iIiiIii / O0oO
def oOo00OoO0O ( ) :
 if 69 - 69: iIii1I11I1II1 * OOooOOo - O0ooOooooO + O0 + O0
 try :
  if 65 - 65: Oooo0Ooo000 / i11iIiiIii / OoOO - IIII
  II1i111 = IiIi ( I1iI11iii )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( II1i111 )
  for Iii in OOOOO0O00 :
   if 9 - 9: OOooOOo / Oooo0Ooo000 - ii11ii1ii * iIii1I11I1II1
   try :
    if 86 - 86: II111iiii + iI + i1I111II1I
    OO0OoOOO0 = Iii
    if 9 - 9: iI + II111iiii % iI % i1I111II1I + iIii1I11I1II1
   except :
    pass
    if 59 - 59: i1IIi
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( I1iI1 ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 48 - 48: O0 * o0oO0 * OoOO . OoOO * O0oO - o0oO0
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 147 , O00ooOo , oo00 , I1IIIiIiIi )
    if 14 - 14: o00O0oo + i11iIiiIii
   except :
    pass
 except :
  pass
  if 83 - 83: o00O0oo / i11iIiiIii + II111iiii . O0ooOooooO * IIII + i1I111II1I
def iiii1i1II1 ( ) :
 if 63 - 63: iIii1I11I1II1 % o00O0oo - O0ooOooooO
 try :
  if 17 - 17: OOooOOo
  ooOoO0O0 = IiIi ( OOOoOo )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( ooOoO0O0 )
  for Iii in OOOOO0O00 :
   if 19 - 19: o0oO0
   try :
    if 55 - 55: IIII % IIII / O0 % O0ooOooooO - o0000oOoOoO0o . ii11ii1ii
    OO0OoOOO0 = Iii
    if 49 - 49: iIii1I11I1II1 * i1IIi . OoooooooOO
   except :
    pass
    if 90 - 90: o0000oOoOoO0o % o00O0oo - iIii1I11I1II1 % OoOO0ooOOoo0O
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( I1iI1 ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 8 - 8: OoOO0ooOOoo0O * ii11ii1ii / i1I111II1I % o0oO0 - OOooOOo
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 147 , O00ooOo , oo00 , I1IIIiIiIi )
    if 71 - 71: O0ooOooooO
   except :
    pass
 except :
  pass
  if 23 - 23: i1IIi . iIii1I11I1II1 . IIII . O0 % o0oO0 % i11iIiiIii
def Iiiii111 ( ) :
 if 93 - 93: OoooooooOO * ii11ii1ii
 try :
  if 10 - 10: Oooo0Ooo000 * OoooooooOO + O0oO - o00O0oo / o00O0oo . i11iIiiIii
  II1i111 = IiIi ( IiIi1iI11 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( II1i111 )
  for Iii in OOOOO0O00 :
   if 22 - 22: Oooo0Ooo000 / o0000oOoOoO0o
   try :
    if 98 - 98: i1IIi
    OO0OoOOO0 = Iii
    if 51 - 51: o00O0oo + iI + ii11ii1ii / i1IIi + i1IIi
   except :
    pass
    if 12 - 12: iIii1I11I1II1 . o0oO0 . o00O0oo % OOooOOo . II111iiii . oO0o0ooO0
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( I1iI1 ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 32 - 32: o00O0oo + i1I111II1I / O0 / OoOO0ooOOoo0O * OoooooooOO % iI
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 147 , O00ooOo , oo00 , I1IIIiIiIi )
    if 50 - 50: OoOO
   except :
    pass
 except :
  pass
  if 66 - 66: iIii1I11I1II1
def I11II1i11 ( ) :
 if 28 - 28: II111iiii - oO0o0ooO0 % OoOO0ooOOoo0O + OoOO - OoOO0ooOOoo0O
 try :
  if 28 - 28: II111iiii . oO0o0ooO0 + O0 . O0 . IIII
  II1i111 = IiIi ( iiiiI )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( II1i111 )
  for Iii in OOOOO0O00 :
   if 98 - 98: OoooooooOO % O0 - O0
   try :
    if 76 - 76: i1IIi % OoOO0ooOOoo0O - OOooOOo / o0000oOoOoO0o * iI
    OO0OoOOO0 = Iii
    if 4 - 4: ii11ii1ii * ii11ii1ii / OoOO0ooOOoo0O
   except :
    pass
    if 4 - 4: OOooOOo * OoOO0ooOOoo0O % O0oO . OoOO0ooOOoo0O
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( I1iI1 ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 11 - 11: IIII - OoOO0ooOOoo0O - o0000oOoOoO0o * OoOO0ooOOoo0O + iI
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 147 , O00ooOo , oo00 , I1IIIiIiIi )
    if 62 - 62: OOooOOo * i11iIiiIii . O0ooOooooO
   except :
    pass
 except :
  pass
  if 35 - 35: i1I111II1I . O0 + ii11ii1ii + IIII + i1IIi
def OooOooO0O0o0 ( ) :
 if 59 - 59: ii11ii1ii + O0ooOooooO - IIII . o0000oOoOoO0o + OOooOOo % oO0o0ooO0
 try :
  if 37 - 37: O0ooOooooO + O0ooOooooO % o0000oOoOoO0o
  iIi1i1iIi1Ii1 = IiIi ( O0o0oO )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iIi1i1iIi1Ii1 )
  for Iii in OOOOO0O00 :
   if 66 - 66: OoOO % o0000oOoOoO0o
   try :
    if 21 - 21: OoOO0ooOOoo0O - OoooooooOO % i11iIiiIii
    OO0OoOOO0 = Iii
    if 71 - 71: i1IIi - O0oO * Oooo0Ooo000 + oO0o0ooO0 - OoOO % o00O0oo
   except :
    pass
    if 63 - 63: iIii1I11I1II1 + IIII . OoOO / OOooOOo
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( I1iI1 ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 84 - 84: i1IIi
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 147 , O00ooOo , oo00 , I1IIIiIiIi )
    if 42 - 42: II111iiii - OoOO - OoooooooOO . O0ooOooooO / OoOO0ooOOoo0O
   except :
    pass
 except :
  pass
  if 56 - 56: i11iIiiIii - iIii1I11I1II1 . II111iiii
def O00O ( ) :
 if 2 - 2: oO0o0ooO0 . Oooo0Ooo000 * ii11ii1ii + O0 - O0oO * iIii1I11I1II1
 try :
  if 12 - 12: o0000oOoOoO0o * Oooo0Ooo000 % II111iiii * i1IIi * iIii1I11I1II1
  iiII1i11i = IiIi ( IiIi11iI )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 81 - 81: ii11ii1ii - O0oO
   try :
    if 24 - 24: OoooooooOO . OoOO * II111iiii
    OO0OoOOO0 = Iii
    if 59 - 59: Oooo0Ooo000 + OoOO / IIII
   except :
    pass
    if 97 - 97: ii11ii1ii * O0ooOooooO % iI . O0ooOooooO - Oooo0Ooo000 - IIII
    if 79 - 79: OOooOOo - iI
    if 37 - 37: i1I111II1I . ii11ii1ii * ii11ii1ii * II111iiii * O0
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( I1iI1 ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 83 - 83: i1I111II1I / Oooo0Ooo000
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 147 , O00ooOo , oo00 , I1IIIiIiIi )
    if 64 - 64: OoOO % i1I111II1I . Oooo0Ooo000 % OoOO + O0oO * i1I111II1I
   except :
    pass
 except :
  pass
  if 83 - 83: o0000oOoOoO0o % oO0o0ooO0 + O0oO % i11iIiiIii + O0
def OoOOoooO000 ( name , url ) :
 if 85 - 85: OOooOOo % O0oO + IIII / o0oO0 % OoooooooOO
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 42 - 42: Oooo0Ooo000 * i1I111II1I
 iI1 = IiIi ( url )
 OOOOO0O00 = re . compile ( i1I1ii11i1Iii ) . findall ( iI1 )
 for O00ooOo , name , oo00 , url , id in OOOOO0O00 :
  try :
   if 23 - 23: oO0o0ooO0 * Oooo0Ooo000 - OoooooooOO * OoooooooOO % OoOO + II111iiii
   O00OOOoOoo0O = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % O00OOOoOoo0O + name + '[/COLOR]'
   ii1I1I1i1i11i ( name , url , 130 , O00ooOo , oo00 , id )
   if 50 - 50: i1I111II1I
   if 61 - 61: IIII / OoOO + II111iiii . oO0o0ooO0 / ii11ii1ii * IIII
  except :
   pass
   if 46 - 46: iIii1I11I1II1
def ii1I1I1i1i11i ( name , url , mode , iconimage , fanart , id ) :
 if 33 - 33: O0oO % O0oO % O0 / OOooOOo . i1IIi
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 91 - 91: iI * O0oO - II111iiii . OOooOOo - ii11ii1ii + iI
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + "&id=" + str ( id )
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 iII . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 iII . setProperty ( 'fanart_image' , fanart )
 iII . setProperty ( 'IsPlayable' , 'true' )
 OO00o = [ ]
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  OO00o . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 32 - 32: iIii1I11I1II1 . iIii1I11I1II1 . O0ooOooooO * O0oO
  iII . addContextMenuItems ( OO00o , replaceItems = True )
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII )
 return oO0O000oOoo0O
 if 93 - 93: oO0o0ooO0 * o0oO0
def ii11i1I1iiii ( ) :
 if 27 - 27: iI + i11iIiiIii * O0oO + OoOO0ooOOoo0O + O0ooOooooO
 if 87 - 87: O0
 oOo0 = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 oOo0 . doModal ( )
 if not oOo0 . isConfirmed ( ) :
  return None ;
 I1i11111i1i11 = oOo0 . getText ( ) . strip ( )
 if 59 - 59: o0000oOoOoO0o * OoOO - o0oO0 . IIII
 if 89 - 89: IIII
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 69 - 69: iI - OoooooooOO * O0
  O0Oo0O0 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + I1i11111i1i11 + '&language=es-ES' ) )
  if 33 - 33: iI % i1IIi - oO0o0ooO0 . O0 / O0
  if 96 - 96: OoooooooOO + i1I111II1I * O0
  return 'android'
  if 86 - 86: o0oO0
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 29 - 29: iIii1I11I1II1 - OoOO + OOooOOo % iIii1I11I1II1 % IIII
  O0Oo0O0 = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + I1i11111i1i11 + '&language=es-ES' )
  if 84 - 84: i1I111II1I + o00O0oo + o0oO0 + O0ooOooooO
  if 62 - 62: i11iIiiIii + OoOO0ooOOoo0O + i1IIi
  return 'windows'
  if 69 - 69: OoOO0ooOOoo0O
  if 63 - 63: OoOO / OoOO0ooOOoo0O * iIii1I11I1II1 . Oooo0Ooo000
def Ooooo ( ) :
 if 43 - 43: IIII
 try :
  if 57 - 57: O0 / o0000oOoOoO0o
  iiII1i11i = IiIi ( iIiIi11 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 12 - 12: OoooooooOO / O0 + II111iiii * o00O0oo
   try :
    if 46 - 46: II111iiii - i1I111II1I * OoooooooOO / oO0o0ooO0 % i1I111II1I
    all = Iii
    if 11 - 11: iIii1I11I1II1 . OoOO0ooOOoo0O / i1I111II1I % iI
   except :
    pass
    if 61 - 61: iI - IIII + IIII
  iI1 = IiIi ( all )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iI1 )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    if 40 - 40: i11iIiiIii . iIii1I11I1II1
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 2 - 2: i1IIi * oO0o0ooO0 - oO0o0ooO0 + OoooooooOO % OoOO0ooOOoo0O / OoOO0ooOOoo0O
   except :
    pass
 except :
  pass
  if 3 - 3: OoooooooOO
def O0OoO0o ( ) :
 if 1 - 1: iI % O0oO * o00O0oo - II111iiii
 try :
  if 49 - 49: oO0o0ooO0 - O0ooOooooO % OoOO0ooOOoo0O
  iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
  OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 72 - 72: OOooOOo + i1I111II1I . OoOO0ooOOoo0O + OoOO0ooOOoo0O
  Ooo0O = IiIi ( I1iIIiiIIi1i )
  OOOOO0O00 = re . compile ( oOooO0 ) . findall ( Ooo0O )
  for O0oOOo0Oo , o0oo0000OO , o000O000 in OOOOO0O00 :
   if re . search ( OOO00O , o000O000 ) :
    if 94 - 94: i11iIiiIii % OoooooooOO / OOooOOo
    if iiII1i1 == o0oo0000OO and o00oOO0o == O0oOOo0Oo and OOO00O == o000O000 :
     if 24 - 24: OOooOOo * oO0o0ooO0
     i1111 = IiIi ( iiiiI )
     OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( i1111 )
     for Iii in OOOOO0O00 :
      if 85 - 85: II111iiii . iI % IIII % O0oO
      try :
       if 80 - 80: oO0o0ooO0 * O0oO / iIii1I11I1II1 % oO0o0ooO0 / iIii1I11I1II1
       OO0OoOOO0 = Iii
       if 42 - 42: i1IIi / i11iIiiIii . ii11ii1ii * O0ooOooooO . i11iIiiIii * O0
      except :
       pass
       if 44 - 44: i1IIi . OOooOOo / i11iIiiIii + i1I111II1I
     O0Oooo = IiIi ( OO0OoOOO0 )
     OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( O0Oooo )
     for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
      try :
       if 27 - 27: IIII
       IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
       if 52 - 52: Oooo0Ooo000 % OoOO0ooOOoo0O + iIii1I11I1II1 * oO0o0ooO0 . o0oO0
      except :
       pass
       if 95 - 95: iIii1I11I1II1 . i1I111II1I - OoooooooOO * OoOO / o0000oOoOoO0o
    else :
     if 74 - 74: oO0o0ooO0
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Esta seccion ha sido cerrada![COLOR orange] Lo sentimos ...[/COLOR] ,5000)" )
     if 34 - 34: O0ooOooooO
     return False
     if 44 - 44: i1IIi % OOooOOo % o0000oOoOoO0o
 except :
  pass
  if 9 - 9: ii11ii1ii % OoooooooOO - o0oO0
def iIII11Iiii1 ( ) :
 if 95 - 95: OOooOOo
 try :
  if 99 - 99: O0
  iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
  OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 76 - 76: Oooo0Ooo000 - oO0o0ooO0 . IIII % o0000oOoOoO0o
  Ooo0O = IiIi ( I1iIIiiIIi1i )
  OOOOO0O00 = re . compile ( oOooO0 ) . findall ( Ooo0O )
  for o0oo0000OO , O0oOOo0Oo , o000O000 in OOOOO0O00 :
   if re . search ( OOO00O , o000O000 ) :
    if 30 - 30: o00O0oo % O0oO / Oooo0Ooo000
    if iiII1i1 == o0oo0000OO and o00oOO0o == O0oOOo0Oo and OOO00O == o000O000 :
     if 1 - 1: Oooo0Ooo000 - O0oO
     i11 = IiIi ( OOoO )
     OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( i11 )
     for Iii in OOOOO0O00 :
      if 45 - 45: o0oO0 - IIII
      try :
       OOoooO00o0o = Iii
      except :
       pass
       if 10 - 10: o0oO0 - i11iIiiIii . o00O0oo % i1IIi
     iiII1i11i = IiIi ( OOoooO00o0o )
     OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
     for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
      try :
       if 78 - 78: iIii1I11I1II1 * ii11ii1ii . ii11ii1ii - IIII . iIii1I11I1II1
       IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
       if 30 - 30: iI + iI % i1I111II1I - o0000oOoOoO0o - o00O0oo
      except :
       pass
       if 36 - 36: O0oO % IIII
    else :
     if 72 - 72: OOooOOo / O0ooOooooO - O0 + O0oO
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Esta seccion ha sido cerrada![COLOR orange] Lo sentimos ...[/COLOR] ,5000)" )
     if 83 - 83: O0
     return False
 except :
  pass
  if 89 - 89: ii11ii1ii + o00O0oo - o0000oOoOoO0o
  if 40 - 40: OoOO + OoOO
  if 94 - 94: O0ooOooooO * iIii1I11I1II1 . O0oO
def IiiI11I1IIiI ( ) :
 if 5 - 5: ii11ii1ii
 try :
  if 100 - 100: o0oO0 + iIii1I11I1II1
  iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
  OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 59 - 59: i1I111II1I
  Ooo0O = IiIi ( I1iIIiiIIi1i )
  OOOOO0O00 = re . compile ( oOooO0 ) . findall ( Ooo0O )
  for O0oOOo0Oo , o0oo0000OO , o000O000 in OOOOO0O00 :
   if re . search ( OOO00O , o000O000 ) :
    if 89 - 89: OoOO0ooOOoo0O % iIii1I11I1II1
    if iiII1i1 == o0oo0000OO and o00oOO0o == O0oOOo0Oo and OOO00O == o000O000 :
     if 35 - 35: o00O0oo + Oooo0Ooo000 - OoOO0ooOOoo0O % oO0o0ooO0 % o0000oOoOoO0o % OoOO0ooOOoo0O
     iiII1i11i = IiIi ( db2 )
     OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
     for Iii in OOOOO0O00 :
      if 45 - 45: OOooOOo * IIII % OoOO
      try :
       if 24 - 24: iI - O0oO * oO0o0ooO0
       O00OoOoO = Iii
       if 58 - 58: o00O0oo
      except :
       pass
       if 19 - 19: iIii1I11I1II1 * OoooooooOO * i11iIiiIii
       if 79 - 79: i1I111II1I % OoOO
     iiII1i11i = IiIi ( O00OoOoO )
     OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
     for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
      try :
       IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
       if 81 - 81: i11iIiiIii + i11iIiiIii * OoOO + i1I111II1I
      except :
       pass
    else :
     if 32 - 32: O0 . OoooooooOO
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Esta seccion ha sido cerrada![COLOR orange] Lo sentimos ...[/COLOR] ,5000)" )
     if 15 - 15: OOooOOo . OoOO
     return False
     if 17 - 17: i11iIiiIii / ii11ii1ii . OoOO / OOooOOo
 except :
  pass
  if 38 - 38: i1IIi . o00O0oo % o0oO0 + iIii1I11I1II1 + O0
def iIi1i11 ( ) :
 if 25 - 25: OOooOOo % O0 + i1IIi - iI
 try :
  if 38 - 38: o0000oOoOoO0o % Oooo0Ooo000 + i11iIiiIii + O0ooOooooO + iI / i11iIiiIii
  o0OOOOOo0 = IiIi ( OOo0O0oo0OO0O )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( o0OOOOOo0 )
  for Iii in OOOOO0O00 :
   if 57 - 57: iIii1I11I1II1 + iIii1I11I1II1
   try :
    if 56 - 56: oO0o0ooO0 + iI
    Ii1Ii1 = Iii
    if 35 - 35: i11iIiiIii - oO0o0ooO0 % i11iIiiIii
   except :
    pass
    if 48 - 48: OoOO % O0oO * o0000oOoOoO0o % oO0o0ooO0 % i11iIiiIii . O0ooOooooO
    if 68 - 68: O0ooOooooO + ii11ii1ii % o0oO0 / i11iIiiIii % OoOO0ooOOoo0O
  iiII1i11i = IiIi ( Ii1Ii1 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    if 94 - 94: i11iIiiIii / Oooo0Ooo000 / ii11ii1ii
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 9 - 9: O0oO / OoOO0ooOOoo0O / II111iiii + Oooo0Ooo000
   except :
    pass
 except :
  pass
  if 71 - 71: O0ooOooooO / ii11ii1ii
def OOOO0Oo ( ) :
 if 13 - 13: II111iiii
 try :
  if 57 - 57: o0oO0 - OoooooooOO
  iiII1i11i = IiIi ( iiIiI1i1 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 68 - 68: o0000oOoOoO0o % o00O0oo / Oooo0Ooo000 + Oooo0Ooo000 - Oooo0Ooo000 . OoOO
   try :
    if 100 - 100: OoOO0ooOOoo0O % ii11ii1ii
    OoOOiI = Iii
    if 3 - 3: OoOO * i1IIi . OOooOOo . O0 - OoOO0ooOOoo0O
   except :
    pass
    if 81 - 81: OOooOOo - iIii1I11I1II1 / OOooOOo / O0
    if 34 - 34: o0oO0 * o0oO0 - o00O0oo - O0 . i11iIiiIii
  iiII1i11i = IiIi ( OoOOiI )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 32 - 32: iIii1I11I1II1 . OoOO * oO0o0ooO0 / IIII . II111iiii - ii11ii1ii
   except :
    pass
 except :
  pass
  if 10 - 10: o00O0oo / i11iIiiIii - o0oO0 + oO0o0ooO0 * OOooOOo
def OoooOo0 ( ) :
 if 20 - 20: II111iiii - O0oO + i1IIi + o0oO0
 try :
  if 7 - 7: iI + o0oO0
  iiII1i11i = IiIi ( IiIi11iI )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 32 - 32: iIii1I11I1II1 % OOooOOo / i11iIiiIii + IIII - o0000oOoOoO0o . O0ooOooooO
   try :
    if 86 - 86: i1IIi / o0oO0 * OOooOOo
    OOoO0OOoO0ooo = Iii
    if 23 - 23: i1IIi - O0oO
   except :
    pass
    if 96 - 96: i1IIi % OoooooooOO
  iiII1i11i = IiIi ( OOoO0OOoO0ooo )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 99 - 99: i11iIiiIii . II111iiii . OoooooooOO
   except :
    pass
 except :
  pass
  if 59 - 59: i11iIiiIii . OoooooooOO / O0oO * o00O0oo + OoooooooOO
def Ii1I1i1ii1I1 ( ) :
 if 98 - 98: i1I111II1I * iIii1I11I1II1 . o0oO0 * ii11ii1ii / o00O0oo + iI
 try :
  if 25 - 25: oO0o0ooO0
  iiII1i11i = IiIi ( i11I1IiII1i1i )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 19 - 19: OOooOOo % o0oO0 . i1I111II1I * iI
   try :
    if 89 - 89: OoOO0ooOOoo0O . IIII
    IIIIIiI11Ii = Iii
    if 41 - 41: i11iIiiIii - i1IIi / ii11ii1ii * i1I111II1I / Oooo0Ooo000 - ii11ii1ii
   except :
    pass
    if 56 - 56: O0
    if 45 - 45: OoOO0ooOOoo0O - OoOO - OoOO0ooOOoo0O
  iiII1i11i = IiIi ( IIIIIiI11Ii )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 41 - 41: ii11ii1ii / i1IIi / ii11ii1ii - O0ooOooooO . o0000oOoOoO0o
   except :
    pass
 except :
  pass
  if 65 - 65: O0 * i11iIiiIii . OoooooooOO / OOooOOo / O0ooOooooO
def o00000oo00 ( ) :
 if 41 - 41: IIII - o0000oOoOoO0o + o0oO0
 try :
  if 15 - 15: O0oO / o0000oOoOoO0o + o0oO0
  iiII1i11i = IiIi ( I1111i )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 76 - 76: o0oO0 + OoooooooOO / IIII % OoOO / o00O0oo
   try :
    if 38 - 38: Oooo0Ooo000 . O0ooOooooO . OOooOOo * OoOO
    oOoo00o0oOO = Iii
    if 61 - 61: i1IIi * o0000oOoOoO0o + iIii1I11I1II1 / OoOO0ooOOoo0O - O0 * iIii1I11I1II1
   except :
    pass
    if 56 - 56: IIII
    if 49 - 49: iI . II111iiii
  iiII1i11i = IiIi ( oOoo00o0oOO )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 24 - 24: O0 . OoooooooOO - OoOO * OoooooooOO
   except :
    pass
 except :
  pass
  if 12 - 12: O0 + i1I111II1I * i1IIi . OoOO
def o0OO0oooo ( ) :
 if 40 - 40: Oooo0Ooo000 - OoOO0ooOOoo0O * O0oO - i1I111II1I / OoOO0ooOOoo0O
 try :
  if 71 - 71: oO0o0ooO0 / OoooooooOO % i1I111II1I / OoOO0ooOOoo0O % Oooo0Ooo000
  iiII1i11i = IiIi ( o00O0O )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 19 - 19: Oooo0Ooo000 + i1I111II1I / oO0o0ooO0 / II111iiii
   try :
    if 92 - 92: i1IIi % iI + iI - iIii1I11I1II1 . o0oO0
    iIIi1 = Iii
    if 75 - 75: i1I111II1I % i11iIiiIii + iIii1I11I1II1
   except :
    pass
    if 92 - 92: OoOO0ooOOoo0O % O0
    if 55 - 55: iIii1I11I1II1 * O0ooOooooO
  iiII1i11i = IiIi ( iIIi1 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 85 - 85: iIii1I11I1II1 . II111iiii
   except :
    pass
 except :
  pass
  if 54 - 54: o0oO0 . OoooooooOO % ii11ii1ii
def ii111I11Ii ( ) :
 if 6 - 6: o0oO0
 try :
  if 77 - 77: i1IIi + OoOO . OOooOOo * IIII / i1I111II1I / o0oO0
  iiII1i11i = IiIi ( o0Oooo )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 84 - 84: OoOO / iIii1I11I1II1
   try :
    if 33 - 33: i1IIi / Oooo0Ooo000 - i1IIi . ii11ii1ii
    iIIi1oo = Iii
    if 31 - 31: iIii1I11I1II1 * iI - OoooooooOO * iI
   except :
    pass
    if 60 - 60: IIII % IIII * oO0o0ooO0 / OOooOOo * OoOO0ooOOoo0O * OOooOOo
    if 61 - 61: oO0o0ooO0 + o00O0oo / i1IIi * oO0o0ooO0
  iiII1i11i = IiIi ( iIIi1oo )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 90 - 90: o0oO0 % oO0o0ooO0
   except :
    pass
 except :
  pass
  if 6 - 6: OoooooooOO / i11iIiiIii / Oooo0Ooo000
  if 60 - 60: OOooOOo % oO0o0ooO0 / o0000oOoOoO0o % oO0o0ooO0 * i11iIiiIii / O0ooOooooO
def i1Ii11II ( ) :
 if 33 - 33: i1I111II1I . OoooooooOO . oO0o0ooO0
 try :
  if 15 - 15: o00O0oo . O0ooOooooO
  iiII1i11i = IiIi ( Iii1I1111ii )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 94 - 94: O0oO . OOooOOo
   try :
    if 73 - 73: i1IIi / II111iiii
    I1i1I = Iii
    if 17 - 17: O0oO - O0ooOooooO % o0oO0
   except :
    pass
    if 2 - 2: o0oO0 * o00O0oo * OoooooooOO
    if 73 - 73: OoOO0ooOOoo0O + ii11ii1ii
  iiII1i11i = IiIi ( I1i1I )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 61 - 61: iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 47 - 47: OoooooooOO
  if 2 - 2: OoOO0ooOOoo0O % Oooo0Ooo000 * ii11ii1ii * OoOO0ooOOoo0O
def Oo0OOo ( ) :
 if 44 - 44: O0oO * o0000oOoOoO0o
 try :
  if 49 - 49: IIII % O0oO * i11iIiiIii / oO0o0ooO0 % IIII
  iiII1i11i = IiIi ( Ii1IIiI1i )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 70 - 70: OoOO0ooOOoo0O / II111iiii % iI - O0ooOooooO
   try :
    if 2 - 2: Oooo0Ooo000 - o00O0oo + o0000oOoOoO0o * OoOO / O0ooOooooO
    iIIiI11iI1Ii1 = Iii
    if 94 - 94: iI / i11iIiiIii % O0
   except :
    pass
    if 70 - 70: O0oO - ii11ii1ii / OoooooooOO % OoooooooOO
    if 95 - 95: OoooooooOO % OoooooooOO . o0oO0
  iiII1i11i = IiIi ( iIIiI11iI1Ii1 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 26 - 26: oO0o0ooO0 + i1I111II1I - II111iiii . II111iiii + o00O0oo + OoOO0ooOOoo0O
   except :
    pass
    if 68 - 68: O0
 except :
  pass
  if 76 - 76: o00O0oo
  if 99 - 99: o0000oOoOoO0o
def I11IIII1111II ( ) :
 if 6 - 6: iIii1I11I1II1 / IIII + O0oO
 try :
  if 89 - 89: oO0o0ooO0
  iiII1i11i = IiIi ( IiII111i1i11 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 87 - 87: O0ooOooooO % ii11ii1ii
   try :
    if 62 - 62: OoOO + iI / O0ooOooooO * i11iIiiIii
    iiIIIIiI111 = Iii
    if 86 - 86: II111iiii % iIii1I11I1II1 / o00O0oo - o0000oOoOoO0o * o0oO0 . OOooOOo
   except :
    pass
    if 68 - 68: OoooooooOO * iIii1I11I1II1 + i1IIi - i1IIi
    if 76 - 76: OoOO . OoooooooOO % Oooo0Ooo000 * o0oO0
  iiII1i11i = IiIi ( iiIIIIiI111 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 23 - 23: i1I111II1I + iIii1I11I1II1
   except :
    pass
    if 14 - 14: O0 % i1I111II1I % o0oO0 * oO0o0ooO0
 except :
  pass
  if 65 - 65: O0oO % oO0o0ooO0 + o00O0oo
def Oooo ( ) :
 if 75 - 75: iIii1I11I1II1 % i1I111II1I + o00O0oo * O0 . O0ooOooooO - iI
 try :
  if 32 - 32: o0oO0 % oO0o0ooO0 - i1IIi
  iiII1i11i = IiIi ( oooO )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 40 - 40: iIii1I11I1II1 + O0ooOooooO * OoOO0ooOOoo0O + oO0o0ooO0
   try :
    if 15 - 15: O0oO % OOooOOo - iIii1I11I1II1 * iI
    oO0O0o0o000 = Iii
    if 6 - 6: OoOO0ooOOoo0O / iI + O0ooOooooO - o0000oOoOoO0o * IIII + iI
   except :
    pass
    if 76 - 76: II111iiii - OoooooooOO % i1I111II1I
  iiII1i11i = IiIi ( oO0O0o0o000 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 40 - 40: o0oO0
   except :
    pass
 except :
  pass
  if 59 - 59: O0oO * OoooooooOO + IIII . iIii1I11I1II1 / i1IIi
  if 75 - 75: O0oO . IIII - iIii1I11I1II1 * OoOO * O0ooOooooO
def ooo0OO0OOooO0 ( ) :
 if 96 - 96: IIII + IIII % i1I111II1I % IIII
 try :
  if 28 - 28: iIii1I11I1II1 + OoOO0ooOOoo0O . o0000oOoOoO0o % i11iIiiIii
  iiII1i11i = IiIi ( ooo )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 58 - 58: O0oO / OoooooooOO % oO0o0ooO0 + OoOO
   try :
    if 58 - 58: O0
    O0oOOOO00o0 = Iii
    if 97 - 97: o00O0oo / o00O0oo / iIii1I11I1II1 % i1IIi . o00O0oo . i1I111II1I
   except :
    pass
    if 4 - 4: ii11ii1ii - OoOO - i11iIiiIii * Oooo0Ooo000 / o0oO0 - IIII
    if 45 - 45: o0000oOoOoO0o % ii11ii1ii * i1IIi - O0
  iiII1i11i = IiIi ( O0oOOOO00o0 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 82 - 82: II111iiii / O0ooOooooO
   except :
    pass
 except :
  pass
  if 96 - 96: ii11ii1ii / oO0o0ooO0 . II111iiii . ii11ii1ii
  if 91 - 91: II111iiii . IIII + o0000oOoOoO0o
def I1iII1IIi1IiI ( ) :
 if 8 - 8: iIii1I11I1II1
 try :
  if 55 - 55: oO0o0ooO0
  iiII1i11i = IiIi ( Ooo0oOooo0 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 37 - 37: i1I111II1I / i11iIiiIii / ii11ii1ii
   try :
    if 97 - 97: Oooo0Ooo000 . O0oO / OOooOOo
    o00OO0o0 = Iii
    if 39 - 39: iI % o00O0oo - O0ooOooooO
   except :
    pass
  iiII1i11i = IiIi ( o00OO0o0 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 48 - 48: i11iIiiIii
   except :
    pass
 except :
  pass
  if 52 - 52: iIii1I11I1II1
def I1 ( ) :
 if 98 - 98: oO0o0ooO0 / OoooooooOO % o0oO0 * II111iiii - OoOO
 try :
  if 95 - 95: OOooOOo % Oooo0Ooo000 * OOooOOo + O0 . Oooo0Ooo000 % OoooooooOO
  iiII1i11i = IiIi ( iiIiIIIiiI )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 6 - 6: OoOO0ooOOoo0O - iI * o0000oOoOoO0o + OoOO0ooOOoo0O % o0000oOoOoO0o
   try :
    if 100 - 100: OoOO % Oooo0Ooo000 - O0oO % O0oO % O0oO / iI
    OOO000Oo = Iii
    if 8 - 8: iI - ii11ii1ii + iIii1I11I1II1 + i1IIi * o0oO0 - iIii1I11I1II1
   except :
    pass
    if 30 - 30: O0oO / o00O0oo
    if 22 - 22: oO0o0ooO0 * O0ooOooooO
  iiII1i11i = IiIi ( OOO000Oo )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 4 - 4: OoOO0ooOOoo0O - oO0o0ooO0 + OOooOOo
   except :
    pass
 except :
  pass
  if 36 - 36: i1I111II1I
  if 19 - 19: OoOO0ooOOoo0O . o0000oOoOoO0o . OoooooooOO
def iIi ( ) :
 if 40 - 40: OoooooooOO + O0ooOooooO
 try :
  if 11 - 11: OoooooooOO * OoOO + ii11ii1ii
  iiII1i11i = IiIi ( II11IiIi11 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 88 - 88: i11iIiiIii / ii11ii1ii
   try :
    if 75 - 75: OoooooooOO . IIII + OoOO / o0oO0 - OOooOOo % o0oO0
    O0OooooO0o0O0 = Iii
    if 74 - 74: OoOO0ooOOoo0O / i1IIi % OoooooooOO
   except :
    pass
    if 52 - 52: i1I111II1I % iI
    if 25 - 25: O0oO / O0oO % OoooooooOO - o00O0oo * oO0o0ooO0
  iiII1i11i = IiIi ( O0OooooO0o0O0 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 23 - 23: i11iIiiIii
   except :
    pass
 except :
  pass
  if 100 - 100: oO0o0ooO0 + O0 . OOooOOo + i1IIi - OoOO0ooOOoo0O + o0000oOoOoO0o
def ooOOo ( ) :
 if 5 - 5: O0
 try :
  if 75 - 75: Oooo0Ooo000 + iIii1I11I1II1
  iiII1i11i = IiIi ( I1iiii1I )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 19 - 19: OOooOOo + i11iIiiIii . i1I111II1I - O0oO / o0oO0 + o0000oOoOoO0o
   try :
    if 38 - 38: ii11ii1ii / iIii1I11I1II1 * iIii1I11I1II1 % o00O0oo
    O00o = Iii
    if 55 - 55: iI % O0oO / i11iIiiIii
   except :
    pass
    if 20 - 20: i1I111II1I / Oooo0Ooo000 * i1I111II1I * OoOO
    if 72 - 72: OoOO . o0000oOoOoO0o * o00O0oo . iIii1I11I1II1 % o00O0oo . o0oO0
  iiII1i11i = IiIi ( O00o )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 70 - 70: IIII + iI * o0oO0 . o0oO0 + OoOO
   except :
    pass
 except :
  pass
  if 28 - 28: i1IIi . IIII
  if 88 - 88: O0oO + OOooOOo - O0oO / OoooooooOO - i11iIiiIii
def i11Ii1IiIIIi ( ) :
 if 71 - 71: OoOO % OOooOOo - O0ooOooooO . O0ooOooooO
 try :
  if 22 - 22: iI / iI - o0oO0 % O0oO . IIII + i1I111II1I
  iiII1i11i = IiIi ( oO00ooooO0o )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 64 - 64: i1IIi % o00O0oo / o0oO0 % OoooooooOO
   try :
    if 24 - 24: Oooo0Ooo000 + OoooooooOO . i1I111II1I / OoOO0ooOOoo0O / O0oO
    ooOoo = Iii
    if 91 - 91: o0000oOoOoO0o . O0ooOooooO % ii11ii1ii - O0ooOooooO . oO0o0ooO0 % i11iIiiIii
   except :
    pass
    if 25 - 25: iIii1I11I1II1
    if 63 - 63: iI
  iiII1i11i = IiIi ( ooOoo )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 96 - 96: O0oO
   except :
    pass
 except :
  pass
  if 34 - 34: OoOO0ooOOoo0O / OoOO - OOooOOo . O0 . IIII
  if 63 - 63: O0ooOooooO
def i1i1iIiI ( ) :
 if 23 - 23: i1I111II1I + iIii1I11I1II1 % iIii1I11I1II1 / iI . oO0o0ooO0 + iIii1I11I1II1
 try :
  if 93 - 93: oO0o0ooO0 * o0000oOoOoO0o / IIII - IIII . O0ooOooooO / OOooOOo
  iiII1i11i = IiIi ( o0oO0oooOoo )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 11 - 11: Oooo0Ooo000 - O0oO % i11iIiiIii . iIii1I11I1II1 * OOooOOo - ii11ii1ii
   try :
    if 73 - 73: O0 + iI - O0 / OoooooooOO * ii11ii1ii
    iI1I1IiIII = Iii
    if 54 - 54: o00O0oo + o00O0oo + O0oO % i1IIi % i11iIiiIii
   except :
    pass
    if 100 - 100: o00O0oo
    if 96 - 96: OOooOOo . i1I111II1I * II111iiii % i1I111II1I . Oooo0Ooo000 * i1IIi
  iiII1i11i = IiIi ( iI1I1IiIII )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 83 - 83: iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 97 - 97: i11iIiiIii + ii11ii1ii * IIII % O0ooOooooO . i1I111II1I
  if 4 - 4: O0 . O0ooOooooO - iIii1I11I1II1
def I1iII11ii1 ( ) :
 if 4 - 4: i11iIiiIii - IIII % o00O0oo * Oooo0Ooo000 % o0000oOoOoO0o
 try :
  if 71 - 71: iI . iI - iIii1I11I1II1
  iiII1i11i = IiIi ( I1i111I )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 22 - 22: OoooooooOO / o00O0oo % O0ooOooooO * OoOO0ooOOoo0O
   try :
    if 32 - 32: OoooooooOO % oO0o0ooO0 % iIii1I11I1II1 / O0
    Ooo0oOOoo0O = Iii
    if 57 - 57: OOooOOo . i11iIiiIii * II111iiii + OoooooooOO + o0oO0
   except :
    pass
    if 73 - 73: O0 % O0oO + O0ooOooooO . o00O0oo . o00O0oo + i1I111II1I
    if 30 - 30: OoOO0ooOOoo0O
  iiII1i11i = IiIi ( Ooo0oOOoo0O )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 89 - 89: O0oO
   except :
    pass
 except :
  pass
  if 89 - 89: o0oO0 - iI . O0oO - Oooo0Ooo000 - OOooOOo
  if 79 - 79: i1I111II1I + i1I111II1I + o0oO0
def iiiII1i1I ( ) :
 if 97 - 97: O0 . Oooo0Ooo000 / II111iiii . O0 + OoooooooOO
 try :
  if 78 - 78: II111iiii + i1I111II1I
  iiII1i11i = IiIi ( I1i11 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 66 - 66: iIii1I11I1II1
   try :
    if 57 - 57: i1I111II1I
    IiI11I1Ii11II = Iii
    if 75 - 75: i11iIiiIii % i1I111II1I
   except :
    pass
    if 30 - 30: ii11ii1ii
  iiII1i11i = IiIi ( IiI11I1Ii11II )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 8 - 8: O0 + oO0o0ooO0 + Oooo0Ooo000
   except :
    pass
 except :
  pass
  if 47 - 47: O0oO
  if 92 - 92: OoooooooOO % OOooOOo / OoOO0ooOOoo0O * OoOO0ooOOoo0O % i11iIiiIii / OoooooooOO
def IiII1 ( ) :
 if 37 - 37: O0 + iI * IIII
 try :
  if 27 - 27: O0 . II111iiii + i1I111II1I % o0000oOoOoO0o
  iiII1i11i = IiIi ( IiIIi1 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 67 - 67: O0 % Oooo0Ooo000
   try :
    if 35 - 35: OOooOOo . OoOO0ooOOoo0O + OoooooooOO % ii11ii1ii % IIII
    iIi1Ii1111i = Iii
    if 16 - 16: i1I111II1I . iI . OoOO
   except :
    pass
    if 53 - 53: OoOO0ooOOoo0O
    if 84 - 84: OoOO
  iiII1i11i = IiIi ( iIi1Ii1111i )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 97 - 97: i1IIi
   except :
    pass
 except :
  pass
  if 98 - 98: OoooooooOO - OOooOOo + iI
def O0I11IIIII ( ) :
 if 53 - 53: OoooooooOO . OoooooooOO + o0000oOoOoO0o - O0ooOooooO + IIII
 try :
  if 44 - 44: Oooo0Ooo000 - i1I111II1I
  iiII1i11i = IiIi ( II1i11I )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 100 - 100: oO0o0ooO0 . OoOO - o0oO0 + O0 * OoOO
   try :
    if 59 - 59: II111iiii
    iIiIi11I1iIii1i11 = Iii
    if 42 - 42: OoOO * i11iIiiIii
   except :
    pass
  iiII1i11i = IiIi ( iIiIi11I1iIii1i11 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 16 - 16: O0ooOooooO % OOooOOo - iI
   except :
    pass
 except :
  pass
  if 100 - 100: OoooooooOO * oO0o0ooO0
def OoO0o0OO ( ) :
 if 10 - 10: oO0o0ooO0 - O0ooOooooO % II111iiii - Oooo0Ooo000 - i1IIi
 try :
  if 10 - 10: o00O0oo - O0oO . Oooo0Ooo000
  iiII1i11i = IiIi ( O0o0oO )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 8 - 8: iIii1I11I1II1 % oO0o0ooO0 + ii11ii1ii
   try :
    if 24 - 24: o0000oOoOoO0o / o0oO0 / o0oO0 % II111iiii - oO0o0ooO0 * oO0o0ooO0
    oOoo0oO = Iii
    if 37 - 37: OoOO0ooOOoo0O + O0 . O0 * ii11ii1ii % Oooo0Ooo000 / O0ooOooooO
   except :
    pass
  iiII1i11i = IiIi ( oOoo0oO )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 18 - 18: OoooooooOO
   except :
    pass
 except :
  pass
  if 57 - 57: iI . OoOO0ooOOoo0O * o0000oOoOoO0o - OoooooooOO
def OooO ( ) :
 if 16 - 16: i1IIi . i1IIi / Oooo0Ooo000 % OoOO0ooOOoo0O / OOooOOo * o00O0oo
 try :
  if 30 - 30: o0000oOoOoO0o + OoooooooOO + IIII / II111iiii * ii11ii1ii
  iiII1i11i = IiIi ( Oo0o0O00 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 59 - 59: o0oO0 / OoOO0ooOOoo0O * OoOO * O0ooOooooO % oO0o0ooO0
   try :
    if 61 - 61: ii11ii1ii - O0 - OoooooooOO
    Ii1I1Iiii = Iii
    if 80 - 80: IIII . o0oO0 + iIii1I11I1II1
   except :
    pass
  iiII1i11i = IiIi ( Ii1I1Iiii )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 32 - 32: OOooOOo
   except :
    pass
 except :
  pass
  if 47 - 47: o00O0oo * oO0o0ooO0 + iIii1I11I1II1 - oO0o0ooO0 / i1I111II1I
def oO0ooo0O0Ooo ( ) :
 if 33 - 33: II111iiii - i1I111II1I - iI
 try :
  if 92 - 92: OoOO * i1I111II1I
  iiII1i11i = IiIi ( I11iiiiI1i )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 92 - 92: oO0o0ooO0
   try :
    if 7 - 7: O0ooOooooO
    oOOoOO0O00o = Iii
    if 38 - 38: i11iIiiIii . iIii1I11I1II1 . IIII / OoOO
   except :
    pass
  iiII1i11i = IiIi ( oOOoOO0O00o )
  OOOOO0O00 = re . compile ( o0O ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 in OOOOO0O00 :
   try :
    iI1111i1i1ii ( iiIi1i , I1i11111i1i11 , OOoOOO0 )
    if 62 - 62: OoooooooOO / OoOO0ooOOoo0O . i1I111II1I . i1I111II1I % iI
   except :
    pass
    if 42 - 42: o0000oOoOoO0o . IIII - iI
 except :
  pass
  if 33 - 33: II111iiii / O0 / i1I111II1I - O0oO - i1IIi
  if 8 - 8: i11iIiiIii . O0ooOooooO / iIii1I11I1II1 / o00O0oo / i1I111II1I - o0oO0
  if 32 - 32: o0000oOoOoO0o . i1IIi * ii11ii1ii
def iI1111i1i1ii ( thumb , name , url ) :
 if 98 - 98: o0oO0 - II111iiii / OOooOOo . oO0o0ooO0 * i1I111II1I . O0oO
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 if 25 - 25: i11iIiiIii / OoOO0ooOOoo0O - Oooo0Ooo000 / OoOO . o0000oOoOoO0o . o0000oOoOoO0o
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   oO0OoO00o ( name , url , '' , o00 , oo00 )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 6 - 6: oO0o0ooO0 . O0oO
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 43 - 43: o00O0oo + o0000oOoOoO0o
   iI1iiiiiii ( name , url , 4 , O00ooOo , oo00 )
   if 63 - 63: iIii1I11I1II1 + i1I111II1I % i1IIi / OOooOOo % II111iiii
  else :
   if 60 - 60: o0000oOoOoO0o . OoOO0ooOOoo0O % Oooo0Ooo000 / OOooOOo / O0
   iI1iiiiiii ( name , url , 4 , O00ooOo , oo00 )
   if 19 - 19: i11iIiiIii . OOooOOo + II111iiii / IIII . o00O0oo * iI
def oo0O ( name , url , thumb , id , trailer ) :
 if 100 - 100: OoooooooOO - O0 . O0oO / O0oO + II111iiii * OoOO0ooOOoo0O
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 37 - 37: ii11ii1ii
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   oO0OoO00o ( name , url , '' , o00 , oo00 )
 else :
  O00OOOoOoo0O = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
  if 72 - 72: i1I111II1I % o00O0oo * IIII . i11iIiiIii % i1I111II1I * IIII
  name = '[COLOR %s]' % O00OOOoOoo0O + name + '[/COLOR]'
  if 15 - 15: O0oO / ii11ii1ii * O0oO
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   III1iII1I1ii = IiII1IiiIiI1 . getSetting ( 'selecton' )
   if III1iII1I1ii == 'true' :
    if 20 - 20: iI - IIII * OoOO * o0000oOoOoO0o * IIII / i1I111II1I
    iiiIIIII11i1I ( name , url , 1 , thumb , thumb , id , trailer )
    if 69 - 69: iI . IIII - OOooOOo
   else :
    if 29 - 29: i11iIiiIii . o00O0oo / OOooOOo . IIII + i11iIiiIii
    iiiIIIII11i1I ( name , url , 130 , thumb , thumb , id , trailer )
    if 26 - 26: i1I111II1I / o0oO0 - OoooooooOO
  else :
   if 9 - 9: OoooooooOO * o00O0oo
   if III1iII1I1ii == 'true' :
    if 9 - 9: ii11ii1ii + O0ooOooooO
    iiiIIIII11i1I ( name , url , 1 , thumb , thumb , id , trailer )
    if 64 - 64: O0 * OOooOOo / OOooOOo
   else :
    if 57 - 57: o00O0oo / OoooooooOO % o00O0oo . O0 / o00O0oo
    iiiIIIII11i1I ( name , url , 130 , thumb , thumb , id , trailer )
    if 63 - 63: i1I111II1I + iIii1I11I1II1 + OOooOOo + Oooo0Ooo000
def IiIii1i111 ( name , url , thumb , id , trailer , description , fanart ) :
 if 72 - 72: OoOO + i11iIiiIii + o00O0oo
 if 96 - 96: oO0o0ooO0 % i1IIi / o0000oOoOoO0o
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . strip ( )
 O00OOOoOoo0O = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
 fanart = fanart . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 name = '[COLOR %s]' % O00OOOoOoo0O + name + '[/COLOR]'
 if 13 - 13: II111iiii - ii11ii1ii % i11iIiiIii + O0ooOooooO
 if 88 - 88: O0 . oO0o0ooO0 % OOooOOo
 if 'tvg-logo' in thumb :
  thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  if III1iII1I1ii == 'true' :
   iii111i ( name , url , 1 , thumb , fanart , id , trailer , description )
  else :
   if 21 - 21: O0oO
   iii111i ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 50 - 50: i1I111II1I % OOooOOo
 else :
  if 32 - 32: OoOO0ooOOoo0O . iIii1I11I1II1 % oO0o0ooO0 . O0 . OoOO0ooOOoo0O / O0ooOooooO
  if III1iII1I1ii == 'true' :
   if 45 - 45: iIii1I11I1II1
   iii111i ( name , url , 1 , thumb , fanart , id , trailer , description )
   if 41 - 41: O0ooOooooO % O0ooOooooO - i1I111II1I % OoOO - OoooooooOO - O0ooOooooO
  else :
   if 66 - 66: o0000oOoOoO0o % OoOO0ooOOoo0O
   iii111i ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 30 - 30: OoOO0ooOOoo0O * ii11ii1ii % iIii1I11I1II1 % OoOO + i11iIiiIii
   if 46 - 46: OOooOOo . i1I111II1I - i11iIiiIii - Oooo0Ooo000
def oo0O0OO0Oo ( name , trailer ) :
 if 66 - 66: OOooOOo % o0oO0 % II111iiii
 if O0ii1ii1ii == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Realstream, Reproduciendo Trailer de: [COLOR green]" + name + "[/COLOR] ,5000)" )
  if 77 - 77: Oooo0Ooo000 + oO0o0ooO0
  OOoOOO0 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  iI11Iii1I = OOoOOO0
  o0i1I = xbmcgui . ListItem ( name , trailer , path = iI11Iii1I )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o0i1I )
 else :
  OOoOOO0 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  iI11Iii1I = OOoOOO0
  o0i1I = xbmcgui . ListItem ( name , trailer , path = iI11Iii1I )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o0i1I )
  if 76 - 76: O0oO % i1I111II1I / i1I111II1I / OoOO % oO0o0ooO0 . iIii1I11I1II1
  if 85 - 85: o0oO0
def Oo0O0Oo00O ( name , url ) :
 if 61 - 61: OOooOOo * ii11ii1ii % o00O0oo * II111iiii / II111iiii + i1IIi
 if O0ii1ii1ii == 'true' :
  if 17 - 17: OoooooooOO % oO0o0ooO0 - i1IIi % i1I111II1I % ii11ii1ii
  try :
   if 41 - 41: OoooooooOO . Oooo0Ooo000 % OoOO0ooOOoo0O - O0ooOooooO
   ii = xbmcgui . DialogProgress ( )
   ii . create ( 'Realstream:' , 'Iniciando ...' )
   ii . update ( 30 , 'Realstream:' , 'Conectando al servidor ...' )
   xbmc . sleep ( 1000 )
   ii . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   ii . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   ii . close ( )
   if 58 - 58: oO0o0ooO0 + iIii1I11I1II1 - O0
   iI11Iii1I = url
   o0i1I = xbmcgui . ListItem ( name , path = iI11Iii1I )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o0i1I )
   if 43 - 43: O0 . II111iiii % iIii1I11I1II1
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. ,3000)" )
  if 24 - 24: i1IIi / Oooo0Ooo000 * O0oO / O0
 else :
  if 88 - 88: o00O0oo . Oooo0Ooo000 * ii11ii1ii - IIII . OoOO0ooOOoo0O . Oooo0Ooo000
  try :
   if 27 - 27: OOooOOo
   ii = xbmcgui . DialogProgress ( )
   ii . create ( 'Realstream:' , 'Iniciando ...' )
   ii . update ( 30 , 'Realstream:' , 'Conectando al servidor ...' )
   xbmc . sleep ( 1000 )
   ii . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   ii . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   ii . close ( )
   if 27 - 27: iIii1I11I1II1 % O0oO - Oooo0Ooo000
   iI11Iii1I = url
   o0i1I = xbmcgui . ListItem ( name , path = iI11Iii1I )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o0i1I )
   if 67 - 67: O0 / Oooo0Ooo000 * o0oO0 % iI . o00O0oo * oO0o0ooO0
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. ,3000)" )
  if 9 - 9: II111iiii * i11iIiiIii . IIII - OoOO
 return
 if 31 - 31: i11iIiiIii * o0oO0 . o0000oOoOoO0o % IIII * o00O0oo % O0
 if 77 - 77: OoOO + OoOO . iI * OoooooooOO + OoOO
def ii111I1i1 ( trailer ) :
 if 82 - 82: iIii1I11I1II1
 if 'https://www.youtube.com' in trailer :
  if 19 - 19: OOooOOo
  try :
   if 66 - 66: oO0o0ooO0 / OoOO0ooOOoo0O
   import resolveurl
   if 13 - 13: II111iiii
   II11i1IiIII = resolveurl . HostedMediaFile ( OOoOOO0 )
   ii = xbmcgui . DialogProgress ( )
   ii . create ( 'Realstream:' , 'Conectando al servidor ... ' )
   ii . update ( 20 , 'Por favor, espere ...' )
   xbmc . sleep ( 500 )
   if 55 - 55: ii11ii1ii % i1IIi * O0oO
   if not II11i1IiIII :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    return False
    if 95 - 95: IIII / II111iiii - o0000oOoOoO0o % Oooo0Ooo000 . O0oO
   try :
    if 63 - 63: iIii1I11I1II1 / iI
    ii . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    iIIiIIIIiII = II11i1IiIII . resolve ( )
    if not iIIiIIIIiII or not isinstance ( iIIiIIIIiII , basestring ) :
     try : oOOO0O0o = iIIiIIIIiII . msg
     except : oOOO0O0o = iIIiIIIIiII
     raise Exception ( oOOO0O0o )
   except Exception as Ii :
    try : oOOO0O0o = str ( Ii )
    except : oOOO0O0o = iIIiIIIIiII
    ii . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
    ii . close ( )
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    if 24 - 24: ii11ii1ii / iIii1I11I1II1 % IIII * OoOO0ooOOoo0O - iIii1I11I1II1
   ii . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
   xbmc . sleep ( 500 )
   ii . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   ii . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
   xbmc . sleep ( 500 )
   ii . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   ii . close ( )
   if 50 - 50: II111iiii
   oO00oo000O = xbmcgui . ListItem ( path = iIIiIIIIiII )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO00oo000O )
   if 39 - 39: II111iiii . OoOO0ooOOoo0O - ii11ii1ii * i1IIi . OoooooooOO
  except :
   pass
   if 44 - 44: OOooOOo
  else :
   if 55 - 55: oO0o0ooO0 . Oooo0Ooo000 * Oooo0Ooo000
   OOoOOO0 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
   iI11Iii1I = OOoOOO0
   o0i1I = xbmcgui . ListItem ( trailer , path = iI11Iii1I )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o0i1I )
   return
   if 82 - 82: OOooOOo % OoOO % O0oO + O0oO
def i1111I ( name , url ) :
 if 58 - 58: OoooooooOO - O0oO + iIii1I11I1II1 * i11iIiiIii
 if '[Youtube]' in name :
  if 80 - 80: i1IIi . OOooOOo - oO0o0ooO0 + IIII + O0ooOooooO % oO0o0ooO0
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  iI11Iii1I = url
  o0i1I = xbmcgui . ListItem ( I1I1i , path = iI11Iii1I )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o0i1I )
  if 13 - 13: II111iiii / OoOO0ooOOoo0O / OoOO0ooOOoo0O + iI
  if 49 - 49: O0 / II111iiii * OOooOOo - OoooooooOO . II111iiii % i1I111II1I
 else :
  if 13 - 13: oO0o0ooO0 . iIii1I11I1II1 . IIII . i1I111II1I
  import resolveurl
  if 58 - 58: O0oO
  II11i1IiIII = resolveurl . HostedMediaFile ( url )
  if 7 - 7: II111iiii / i1I111II1I % O0oO + OOooOOo - O0
  if not II11i1IiIII :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 45 - 45: OOooOOo / O0ooOooooO + oO0o0ooO0 + i1I111II1I
   if 15 - 15: OOooOOo % OoOO
  try :
   iIIiIIIIiII = II11i1IiIII . resolve ( )
   if not iIIiIIIIiII or not isinstance ( iIIiIIIIiII , basestring ) :
    try : oOOO0O0o = iIIiIIIIiII . msg
    except : oOOO0O0o = url
    raise Exception ( oOOO0O0o )
  except Exception as Ii :
   try : oOOO0O0o = str ( Ii )
   except : oOOO0O0o = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 66 - 66: oO0o0ooO0 * i11iIiiIii . Oooo0Ooo000
  O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if O0ii1ii1ii == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  oO00oo000O = xbmcgui . ListItem ( path = iIIiIIIIiII )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO00oo000O )
  if 92 - 92: oO0o0ooO0
  if 81 - 81: o0000oOoOoO0o % OOooOOo - O0ooOooooO / i11iIiiIii
 return
 if 73 - 73: O0 * Oooo0Ooo000 . i1IIi
 if 51 - 51: OoOO - O0ooOooooO % O0 - OoOO0ooOOoo0O
def o0ooo ( name , url ) :
 if 77 - 77: O0oO + i1IIi . O0oO
 if 'mybox.com' in url :
  if 89 - 89: o0000oOoOoO0o + IIII * oO0o0ooO0
  url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
  if 45 - 45: O0ooOooooO - o0000oOoOoO0o . o0oO0
  try :
   if 41 - 41: II111iiii . OOooOOo / OoOO . iI
   iiII1i11i = IiIi ( url )
   OOOOO0O00 = re . compile ( O0OO0O ) . findall ( iiII1i11i )
   for url , oOOoO0OO00OOo0 , Ii1IIii in OOOOO0O00 :
    if 58 - 58: i1I111II1I % i11iIiiIii * II111iiii . o00O0oo
    oOOoO0OO00OOo0 = oOOoO0OO00OOo0 . replace ( '","res":"2160",' , ' 2160 ' ) . replace ( '","res":"1080",' , ' 1080' ) . replace ( '","res":"720",' , ' 720' ) . replace ( '","res":"480",' , ' 480' ) . replace ( '","res":"360",' , ' 360' )
    url = url . replace ( '\/' , '/' )
    url = url . replace ( ',"type":"video/mp4",' , ' ' )
    Ii1IIii = Ii1IIii . replace ( 'spa' , 'Castellano:' ) . replace ( 'eng' , 'Ingles:' ) . replace ( 'spa1' , 'Latino:' ) . replace ( 'eng2' , 'Americano:' )
    name = '[COLOR white]' + Ii1IIii + '[/COLOR] - [COLOR gold]' + oOOoO0OO00OOo0 + '[/COLOR]'
    if 94 - 94: i11iIiiIii . IIII + iIii1I11I1II1 * Oooo0Ooo000 * Oooo0Ooo000
    OooOo000o0o = [ ]
    OooOo000o0o . append ( '[COLOR orange]Real Stream: [/COLOR][COLOR gold]1. Mostrar mas info. [Reiniciar][/COLOR]' )
    OooOo000o0o . append ( '[COLOR gold]2. Mostar otras calidades disponibles [/COLOR]' )
    OooOo000o0o . append ( '[COLOR gold]3. Ver en: %s [/COLOR]' % name )
    if 36 - 36: O0oO - i1I111II1I . i1I111II1I
    if 60 - 60: i11iIiiIii * ii11ii1ii % OoOO + OoOO
    Ii1iI = 'Seleccione una calidad e idioma:'
    Oo0O0O000 = xbmcgui . Dialog ( )
    II1Ii = Oo0O0O000 . select ( Ii1iI , OooOo000o0o )
    if 84 - 84: iIii1I11I1II1 + OoooooooOO
    if 77 - 77: O0 * o00O0oo * oO0o0ooO0 + OoOO + o00O0oo - Oooo0Ooo000
    if 10 - 10: o00O0oo + i1I111II1I
    if II1Ii == 0 :
     if 58 - 58: OOooOOo + OoooooooOO / O0ooOooooO . iI % o0000oOoOoO0o / o00O0oo
     oO0O000oOoo0O = Oo0O0O000 . ok ( "[COLOR darkpink]REALSTREAM:[/COLOR] " , "[COLOR gold]  Reiniciadas las opciones.  [/COLOR]" , "" )
     del Oo0O0O000
     return
     if 62 - 62: II111iiii
    elif II1Ii == 1 :
     if 12 - 12: i1I111II1I + II111iiii
     pass
     if 92 - 92: Oooo0Ooo000 % iIii1I11I1II1 - O0ooOooooO / i11iIiiIii % iI * o0000oOoOoO0o
     del Oo0O0O000
     if 80 - 80: O0ooOooooO
     if 3 - 3: o00O0oo * O0oO
    elif II1Ii == 2 :
     if 53 - 53: iIii1I11I1II1 / O0ooOooooO % OoOO + i1I111II1I / iI
     Oo0O0Oo00O ( name , url )
     if 74 - 74: ii11ii1ii
     return
     if 8 - 8: OOooOOo % II111iiii - o0000oOoOoO0o - O0oO % OOooOOo
  except :
   pass
   if 93 - 93: o0oO0 * O0ooOooooO / IIII
 elif 'uptostream.com' in url :
  if 88 - 88: oO0o0ooO0
  try :
   if 1 - 1: ii11ii1ii
   iiII1i11i = IiIi ( url )
   OOOOO0O00 = re . compile ( O0OO0O ) . findall ( iiII1i11i )
   for url , oOOoO0OO00OOo0 , Ii1IIii in OOOOO0O00 :
    if 95 - 95: OoooooooOO / O0oO % OoooooooOO / iI * i1I111II1I
    oOOoO0OO00OOo0 = oOOoO0OO00OOo0 . replace ( '","res":"2160",' , ' ' ) . replace ( '","res":"1080",' , ' ' ) . replace ( '","res":"720",' , ' ' ) . replace ( '","res":"480",' , ' ' ) . replace ( '","res":"360",' , ' ' )
    url = url . replace ( '\/' , '/' )
    url = url . replace ( ',"type":"video/mp4",' , ' ' )
    Ii1IIii = Ii1IIii . replace ( 'spa' , 'Castellano:' ) . replace ( 'eng' , 'Ingles:' ) . replace ( 'spa1' , 'Latino:' ) . replace ( 'eng2' , 'Americano:' )
    name = '[COLOR white]' + Ii1IIii + '[/COLOR] - [COLOR gold]' + oOOoO0OO00OOo0 + '[/COLOR]'
    if 75 - 75: O0
    OooOo000o0o = [ ]
    OooOo000o0o . append ( '[COLOR orange]Real Stream: [/COLOR][COLOR gold]1. Mostrar mas info. [Reiniciar][/COLOR]' )
    OooOo000o0o . append ( '[COLOR gold]2. Mostar otras calidades disponibles [/COLOR]' )
    OooOo000o0o . append ( '[COLOR gold]3. Ver en: %s [/COLOR]' % name )
    if 56 - 56: OoOO / II111iiii
    if 39 - 39: OoOO0ooOOoo0O - OoooooooOO - i1IIi / II111iiii
    Ii1iI = 'Seleccione una calidad e idioma:'
    Oo0O0O000 = xbmcgui . Dialog ( )
    II1Ii = Oo0O0O000 . select ( Ii1iI , OooOo000o0o )
    if 49 - 49: ii11ii1ii + O0 + i1I111II1I . II111iiii % iI
    if 33 - 33: OoOO0ooOOoo0O . iIii1I11I1II1 / O0oO % o0oO0
    if II1Ii == 0 :
     if 49 - 49: OoOO + II111iiii / i1I111II1I - O0 % o0oO0
     oO0O000oOoo0O = Oo0O0O000 . ok ( "[COLOR darkpink]REALSTREAM:[/COLOR] " , "[COLOR gold]  Reiniciadas las opciones.  [/COLOR]" , "" )
     del Oo0O0O000
     return
     if 27 - 27: OoOO + ii11ii1ii
    elif II1Ii == 1 :
     if 92 - 92: OOooOOo % O0ooOooooO
     pass
     if 31 - 31: OoooooooOO - oO0o0ooO0 / Oooo0Ooo000
     del Oo0O0O000
     if 62 - 62: i11iIiiIii - O0oO
     if 81 - 81: O0oO
     if 92 - 92: IIII - ii11ii1ii - OoooooooOO / i1I111II1I - i1IIi
     if 81 - 81: i1IIi / Oooo0Ooo000 % i11iIiiIii . iIii1I11I1II1 * OoOO0ooOOoo0O + OoooooooOO
    elif II1Ii == 2 :
     if 31 - 31: i1IIi % II111iiii
     Oo0O0Oo00O ( name , url )
     if 13 - 13: iIii1I11I1II1 - II111iiii % O0 . o0oO0 % OoOO
     return
     if 2 - 2: OoooooooOO - o0oO0 % oO0o0ooO0 / OOooOOo / o0000oOoOoO0o
  except :
   pass
 else :
  if 3 - 3: II111iiii / IIII
  IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
  o00O0 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  oOO0O00Oo0O0o = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  OOoo0 = IiII1IiiIiI1 . getSetting ( 'key_ext' )
  iiII1i11i = IiIi ( oOO0O00Oo0O0o )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for III1I1I in OOOOO0O00 :
   if 48 - 48: iI . o00O0oo
   try :
    if 49 - 49: i1IIi - OoOO0ooOOoo0O . ii11ii1ii + iIii1I11I1II1 - iI / ii11ii1ii
    if 24 - 24: oO0o0ooO0 - O0ooOooooO / iI
    IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
    if 10 - 10: OoOO0ooOOoo0O * i1IIi
    if 15 - 15: O0oO + i1IIi - II111iiii % OOooOOo
    if IIIi1I1IIii1II == III1I1I :
     if 34 - 34: OOooOOo
     if 57 - 57: IIII . o0oO0 % o0000oOoOoO0o
     if 'https://team.com' in url :
      if 32 - 32: O0oO / i1I111II1I - O0 * iIii1I11I1II1
      url = url . replace ( 'https://team.com' , 'https://verystream.com' )
      if 70 - 70: OoooooooOO % OoooooooOO % OoOO
     if 'https://mybox.com' in url :
      if 98 - 98: OoOO
      url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
      if 18 - 18: O0oO + ii11ii1ii - OoOO / Oooo0Ooo000 / IIII
      if 53 - 53: IIII + o0000oOoOoO0o . oO0o0ooO0 / O0oO
     if 'https://vidcloud.co/' in url :
      if 52 - 52: Oooo0Ooo000 + Oooo0Ooo000
      url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
      if 73 - 73: o0000oOoOoO0o . i11iIiiIii % OoooooooOO + iI . OoooooooOO / IIII
     if 'https://gounlimited.to' in url :
      if 54 - 54: OoOO0ooOOoo0O . OoooooooOO
      url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
      if 36 - 36: oO0o0ooO0 / II111iiii * i1I111II1I % o00O0oo
     if 'https://drive.com' in url :
      if 31 - 31: II111iiii + IIII - OoooooooOO . O0oO
      url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
      if 28 - 28: o0oO0 . o00O0oo
      if 77 - 77: o00O0oo % II111iiii
     import resolveurl
     if 81 - 81: OoOO0ooOOoo0O % o0oO0 / O0 * iIii1I11I1II1 % i1I111II1I . OOooOOo
     II11i1IiIII = resolveurl . HostedMediaFile ( url )
     if 90 - 90: o0000oOoOoO0o
     if 44 - 44: o0000oOoOoO0o / o00O0oo . ii11ii1ii + OoOO0ooOOoo0O
     if 32 - 32: i1I111II1I - iI * O0ooOooooO * O0oO
     if 84 - 84: o0oO0 + o00O0oo % OOooOOo + i11iIiiIii
     if not II11i1IiIII :
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
      return False
      if 37 - 37: O0oO % o00O0oo / iI
     try :
      if 94 - 94: O0oO / OoOO . o0000oOoOoO0o
      ii = xbmcgui . DialogProgress ( )
      ii . create ( 'Realstream:' , 'Iniciando ...' )
      ii . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
      xbmc . sleep ( 1000 )
      if 1 - 1: ii11ii1ii . II111iiii
      iIIiIIIIiII = II11i1IiIII . resolve ( )
      if not iIIiIIIIiII or not isinstance ( iIIiIIIIiII , basestring ) :
       if 93 - 93: II111iiii . i11iIiiIii + II111iiii % oO0o0ooO0
       try : oOOO0O0o = iIIiIIIIiII . msg
       except : oOOO0O0o = url
       raise Exception ( oOOO0O0o )
       if 98 - 98: Oooo0Ooo000 * oO0o0ooO0 * OoOO0ooOOoo0O + o0oO0 * O0ooOooooO
     except Exception as Ii :
      try : oOOO0O0o = str ( Ii )
      except : oOOO0O0o = url
      if 4 - 4: i1I111II1I
      if 16 - 16: iIii1I11I1II1 * O0ooOooooO + oO0o0ooO0 . O0 . o0000oOoOoO0o
      if 99 - 99: i11iIiiIii - O0ooOooooO
      for o0O0O0O00o in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       OoOooOo00o = 1
       ii . update ( 45 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % o0O0O0O00o )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5  Puede cancelar cuando desee o esperar...,  1000)" % OoOooOo00o )
       ii . close ( )
       if 28 - 28: o00O0oo + o00O0oo % OoOO0ooOOoo0O
      for o0O0O0O00o in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       OoOooOo00o = 2
       ii . update ( 48 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % o0O0O0O00o )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % OoOooOo00o )
       ii . close ( )
      for o0O0O0O00o in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       OoOooOo00o = 3
       ii . update ( 50 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % o0O0O0O00o )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % OoOooOo00o )
       ii . close ( )
      for o0O0O0O00o in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       OoOooOo00o = 4
       ii . update ( 53 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % o0O0O0O00o )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % OoOooOo00o )
       ii . close ( )
      for o0O0O0O00o in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       OoOooOo00o = 5
       ii . update ( 55 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % o0O0O0O00o )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % OoOooOo00o )
       ii . close ( )
       if 12 - 12: O0oO
      if ii . iscanceled ( ) :
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Cancelando !! , 2000)" )
       ii . close ( )
       break
       if 19 - 19: o0oO0 * i1IIi % O0 + O0oO
       if 25 - 25: Oooo0Ooo000 - o0oO0 / O0 . OoooooooOO % OOooOOo . i1IIi
       if 19 - 19: II111iiii / II111iiii % o00O0oo + oO0o0ooO0 + oO0o0ooO0 + O0ooOooooO
     ii . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
     xbmc . sleep ( 500 )
     ii . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
     xbmc . sleep ( 1000 )
     ii . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
     ii . close ( )
     O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
     oO00oo000O = xbmcgui . ListItem ( path = iIIiIIIIiII )
     xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO00oo000O )
     if 4 - 4: o0000oOoOoO0o + O0oO / O0ooOooooO + i1IIi % o0000oOoOoO0o % O0ooOooooO
     if 80 - 80: o0oO0
    else :
     if 26 - 26: iIii1I11I1II1 . OoooooooOO - iIii1I11I1II1
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold] El addon no ha podido conectar al servidor.[/COLOR]" )
     return False
     if 59 - 59: o00O0oo + O0oO . oO0o0ooO0
   except :
    pass
    if 87 - 87: OoOO
 return
 if 34 - 34: Oooo0Ooo000 . OoOO0ooOOoo0O / i11iIiiIii / O0ooOooooO
def II1iII1 ( ) :
 if 31 - 31: o0oO0 * o0000oOoOoO0o * o0oO0 + OoOO * o0000oOoOoO0o . Oooo0Ooo000
 Oo00oo00o00Oo = [ ]
 iiiiiii11III = sys . argv [ 2 ]
 if len ( iiiiiii11III ) >= 2 :
  I11111ii1i = sys . argv [ 2 ]
  O0OOoO0OoO0 = I11111ii1i . replace ( '?' , '' )
  if ( I11111ii1i [ len ( I11111ii1i ) - 1 ] == '/' ) :
   I11111ii1i = I11111ii1i [ 0 : len ( I11111ii1i ) - 2 ]
  iI11IiiiIII = O0OOoO0OoO0 . split ( '&' )
  Oo00oo00o00Oo = { }
  for o0O0O0O00o in range ( len ( iI11IiiiIII ) ) :
   i1i1Ii = { }
   i1i1Ii = iI11IiiiIII [ o0O0O0O00o ] . split ( '=' )
   if ( len ( i1i1Ii ) ) == 2 :
    Oo00oo00o00Oo [ i1i1Ii [ 0 ] ] = i1i1Ii [ 1 ]
 return Oo00oo00o00Oo
 if 69 - 69: O0 + iIii1I11I1II1 % O0ooOooooO * OOooOOo . ii11ii1ii - OoOO0ooOOoo0O
 if 49 - 49: o0oO0 + II111iiii / oO0o0ooO0 - OoOO0ooOOoo0O % OoOO0ooOOoo0O + OOooOOo
def o0OO0oO0Oo0 ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  pass
  if 73 - 73: II111iiii . OoOO0ooOOoo0O . ii11ii1ii
def OOo0O ( ) :
 Oo0O0O000 = xbmcgui . Dialog ( )
 list = (
 iiOo0ooo ,
 Oo00o00
 )
 if 74 - 74: O0 + iIii1I11I1II1 + oO0o0ooO0 * i1I111II1I
 I1o0 = Oo0O0O000 . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=%s]Accede a themoviedb.com[/COLOR]' % iIIIi1 ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 26 - 26: O0ooOooooO * iIii1I11I1II1 + II111iiii / OOooOOo
 if I1o0 :
  if 52 - 52: o0oO0 / OoOO0ooOOoo0O + OoOO % o0oO0 % IIII / oO0o0ooO0
  if I1o0 < 0 :
   return
  OOoOo = list [ I1o0 - 2 ]
  return OOoOo ( )
 else :
  OOoOo = list [ I1o0 ]
  return OOoOo ( )
 return
 if 27 - 27: OOooOOo * i11iIiiIii / O0 / II111iiii
def OOoO0oOOO ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 47 - 47: IIII / II111iiii % i1I111II1I . oO0o0ooO0 * o00O0oo
iIii1iIiII1i1 = OOoO0oOOO ( )
if 56 - 56: Oooo0Ooo000 / oO0o0ooO0 . O0ooOooooO
def iiOo0ooo ( ) :
 if iIii1iIiII1i1 == 'android' :
  O0Oo0O0 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  O0Oo0O0 = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 10 - 10: o00O0oo * OoooooooOO
  if 16 - 16: OoOO % o0oO0 + o00O0oo + ii11ii1ii / iIii1I11I1II1
def Oo00o00 ( ) :
 if 89 - 89: OOooOOo % ii11ii1ii - OoOO0ooOOoo0O * O0ooOooooO + Oooo0Ooo000 + OoooooooOO
 main ( )
 if 29 - 29: OoOO0ooOOoo0O + Oooo0Ooo000 / IIII + iI
 if 42 - 42: iIii1I11I1II1 - iI - O0oO - Oooo0Ooo000
 if 33 - 33: OoOO0ooOOoo0O - O0
def III11iI1i11i ( ) :
 Oo0O0O000 = xbmcgui . Dialog ( )
 IIiI = (
 OOoOo0oO0oo00 ,
 OOI1I
 )
 if 54 - 54: OoOO0ooOOoo0O
 I1o0 = Oo0O0O000 . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 73 - 73: O0ooOooooO + o0oO0
 if I1o0 :
  if 37 - 37: oO0o0ooO0 - iIii1I11I1II1 + II111iiii . o0oO0 % iIii1I11I1II1
  if I1o0 < 0 :
   return
  OOoOo = IIiI [ I1o0 - 2 ]
  return OOoOo ( )
 else :
  OOoOo = IIiI [ I1o0 ]
  return OOoOo ( )
 return
 if 17 - 17: Oooo0Ooo000 + i1IIi % O0
def OOoO0oOOO ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 65 - 65: i1I111II1I
iIii1iIiII1i1 = OOoO0oOOO ( )
if 50 - 50: II111iiii / OoOO
def OOoOo0oO0oo00 ( ) :
 if iIii1iIiII1i1 == 'android' :
  O0Oo0O0 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  O0Oo0O0 = webbrowser . open ( 'https://olpair.com/' )
  if 79 - 79: o00O0oo - iIii1I11I1II1 % i1IIi / ii11ii1ii + II111iiii
  if 95 - 95: oO0o0ooO0
def OOI1I ( ) :
 if 48 - 48: O0oO / iIii1I11I1II1 % II111iiii
 main ( )
 if 39 - 39: i1IIi . o00O0oo / O0oO / O0oO
 if 100 - 100: OoooooooOO - OoooooooOO + i1I111II1I
def iIiIi1i1Iiii ( name , url , id , trailer ) :
 Oo0O0O000 = xbmcgui . Dialog ( )
 IIiI = (
 OOO00000O ,
 iIiiiII11 ,
 ooo00Oo0 ,
 OOo0O ,
 iIii1i1Ii
 )
 if 23 - 23: OoOO0ooOOoo0O - o0oO0 - oO0o0ooO0 / OoooooooOO
 I1o0 = Oo0O0O000 . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % iIIIi1 ,

 '[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % iIIIi1 ,

 '[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % iIIIi1 ,

 '[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % iIIIi1 ,

 '[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % iIIIi1 ] )
 if 12 - 12: OoooooooOO
 if I1o0 :
  if 55 - 55: o00O0oo + o00O0oo
  if I1o0 < 0 :
   return
  OOoOo = IIiI [ I1o0 - 5 ]
  return OOoOo ( )
 else :
  OOoOo = IIiI [ I1o0 ]
  return OOoOo ( )
 return
 if 87 - 87: i1I111II1I
 if 78 - 78: oO0o0ooO0 % OoOO0ooOOoo0O
 if 1 - 1: OoOO0ooOOoo0O - o0000oOoOoO0o / iI - i1I111II1I / i1IIi
def OOO00000O ( ) :
 if 28 - 28: OoOO / Oooo0Ooo000 * OOooOOo + iI
 o0ooo ( I1i11111i1i11 , OOoOOO0 )
 if 48 - 48: O0
def iIiiiII11 ( ) :
 if 44 - 44: OoOO * oO0o0ooO0
 oo0O0OO0Oo ( I1i11111i1i11 , I1I1i )
 if 54 - 54: o0oO0 % i1IIi
def ooo00Oo0 ( ) :
 if 51 - 51: iIii1I11I1II1 - OOooOOo
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  Oo0 = id
  if 79 - 79: OoooooooOO - iI * o0oO0 - II111iiii % OoOO0ooOOoo0O * i1I111II1I
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % Oo0 )
  if 31 - 31: OOooOOo
 if O0ii1ii1ii == 'true' :
  if 36 - 36: OoOO + OoOO + OoOO % ii11ii1ii * O0ooOooooO
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + I1i11111i1i11 + "[/COLOR] ,5000)" )
  if 98 - 98: O0oO . O0oO / ii11ii1ii / o0oO0 / OOooOOo
def oO0o ( ) :
 if 25 - 25: O0oO + OoOO0ooOOoo0O
 OOo0O ( )
 if 98 - 98: IIII
def iIii1i1Ii ( ) :
 if 69 - 69: II111iiii + ii11ii1ii - oO0o0ooO0 . ii11ii1ii / iIii1I11I1II1 * iIii1I11I1II1
 OOI1iIi1iiIIiI ( )
def oO0OoO00o ( name , url , mode , iconimage , fanart ) :
 if 75 - 75: OoOO % OoooooooOO
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 oO0O000oOoo0O = True
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iII . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 iII . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  OO0oIiII1iiI = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII , isFolder = True )
  return oO0O000oOoo0O
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII , isFolder = True )
 return oO0O000oOoo0O
 if 16 - 16: O0 / i1IIi
def O0ooOoO ( name , url , mode , iconimage , fanart , description ) :
 if 58 - 58: o0000oOoOoO0o / i11iIiiIii / O0 % O0oO % OOooOOo
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 oO0O000oOoo0O = True
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iII . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 iII . setProperty ( 'fanart_image' , fanart )
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII , isFolder = True )
 return oO0O000oOoo0O
 if 86 - 86: i1I111II1I + OoOO0ooOOoo0O / OOooOOo + O0oO % O0oO / i11iIiiIii
def iIiI1I ( name , url , mode , iconimage ) :
 if 2 - 2: o0000oOoOoO0o . o0oO0 % OoOO0ooOOoo0O
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 oO0O000oOoo0O = True
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iII . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 iII . setProperty ( 'fanart_image' , oo00 )
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII , isFolder = True )
 return oO0O000oOoo0O
 if 58 - 58: o00O0oo % o0oO0 * o0oO0 - O0ooOooooO
 if 9 - 9: iI - o0oO0 % II111iiii + i1I111II1I + IIII % O0
def iiiIIIII11i1I ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 65 - 65: IIII - OoOO % i11iIiiIii
 ooOOoooooo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 58 - 58: O0ooOooooO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 OO00o = [ ]
 if 2 - 2: II111iiii + i1IIi
 OO00o . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 iII . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 iII . setProperty ( 'fanart_image' , fanart )
 iII . setProperty ( 'IsPlayable' , 'true' )
 if 68 - 68: IIII + o0oO0
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  OO00o . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 58 - 58: i1I111II1I * o0oO0 . i1IIi
  iII . addContextMenuItems ( OO00o , replaceItems = True )
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII )
 return oO0O000oOoo0O
 if 19 - 19: oO0o0ooO0
 if 85 - 85: iI - OOooOOo / i1IIi / OoOO / II111iiii
def iii111i ( name , url , mode , iconimage , fanart , id , trailer , description ) :
 if 94 - 94: iIii1I11I1II1 + i1I111II1I
 ooOOoooooo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 44 - 44: OoOO + O0oO % OoOO + i1IIi + O0ooOooooO + O0
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 OO00o = [ ]
 if 18 - 18: iIii1I11I1II1 % iIii1I11I1II1 % oO0o0ooO0 + OOooOOo % iI / o0oO0
 OO00o . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 iII . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 iII . setProperty ( 'fanart_image' , fanart )
 iII . setProperty ( 'IsPlayable' , 'true' )
 if 36 - 36: OoOO0ooOOoo0O . i11iIiiIii
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  OO00o . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 81 - 81: ii11ii1ii * O0ooOooooO * OoOO
  iII . addContextMenuItems ( OO00o , replaceItems = True )
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII )
 return oO0O000oOoo0O
 if 85 - 85: O0 * oO0o0ooO0
def iI1iiiiiii ( name , url , mode , iconimage , fanart ) :
 if 39 - 39: II111iiii * OOooOOo - iIii1I11I1II1
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 25 - 25: OoooooooOO . o0oO0 % O0ooOooooO . i1I111II1I
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 iII . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 iII . setProperty ( 'fanart_image' , fanart )
 iII . setProperty ( 'IsPlayable' , 'true' )
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII )
 return oO0O000oOoo0O
 if 67 - 67: OoooooooOO + Oooo0Ooo000 / iI
def O0oo ( name , url , mode , iconimage ) :
 if 50 - 50: Oooo0Ooo000 - II111iiii
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 33 - 33: i1I111II1I / i1I111II1I . i11iIiiIii * o00O0oo + o0000oOoOoO0o
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 iII . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 iII . setProperty ( 'fanart_image' , oo00 )
 iII . setProperty ( 'IsPlayable' , 'true' )
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII )
 return oO0O000oOoo0O
 if 16 - 16: i1I111II1I
def II1 ( name , url , mode , iconimage ) :
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 oO0O000oOoo0O = True
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII , isFolder = True )
 return oO0O000oOoo0O
 if 86 - 86: oO0o0ooO0 . OOooOOo - Oooo0Ooo000 + iIii1I11I1II1
def o0O00ooo0 ( ) :
 if 23 - 23: O0
 if 41 - 41: i1IIi . IIII / iI / o0000oOoOoO0o % i1I111II1I - o0oO0
 if 14 - 14: o00O0oo - i11iIiiIii * Oooo0Ooo000
 ooO = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 ooO . doModal ( )
 if ( ooO . isConfirmed ( ) ) :
  if 39 - 39: OoooooooOO
  Oo00o0OO0O00o = urllib . quote_plus ( ooO . getText ( ) ) . replace ( '+' , ' ' )
  if 19 - 19: i11iIiiIii
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 80 - 80: OOooOOo
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % Oo00o0OO0O00o )
    if 58 - 58: oO0o0ooO0 + o00O0oo % OoOO0ooOOoo0O
    if O0ii1ii1ii == 'true' :
     if 22 - 22: iIii1I11I1II1 - o0oO0 / OOooOOo * i1I111II1I
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + I1i11111i1i11 + "[/COLOR] ,10000)" )
     if 26 - 26: o0000oOoOoO0o + IIII - o0000oOoOoO0o + ii11ii1ii . oO0o0ooO0
   except :
    if 97 - 97: i1IIi
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 46 - 46: o00O0oo
    if 30 - 30: OoOO / O0 * o0000oOoOoO0o * Oooo0Ooo000 + OoooooooOO * O0ooOooooO
I11111ii1i = II1iII1 ( )
OOoOOO0 = None
I1i11111i1i11 = None
iIIi1I1Ii1 = None
O00ooOo = None
id = None
I1I1i = None
if 54 - 54: OoooooooOO . oO0o0ooO0 - O0ooOooooO
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 76 - 76: Oooo0Ooo000
try :
 OOoOOO0 = urllib . unquote_plus ( I11111ii1i [ "url" ] )
except :
 pass
try :
 I1i11111i1i11 = urllib . unquote_plus ( I11111ii1i [ "name" ] )
except :
 pass
try :
 iIIi1I1Ii1 = int ( I11111ii1i [ "mode" ] )
except :
 pass
try :
 O00ooOo = urllib . unquote_plus ( I11111ii1i [ "iconimage" ] )
except :
 pass
try :
 id = int ( I11111ii1i [ "id" ] )
except :
 pass
try :
 I1I1i = urllib . unquote_plus ( I11111ii1i [ "trailer" ] )
except :
 pass
 if 61 - 61: iI / II111iiii * iI * OoOO0ooOOoo0O * Oooo0Ooo000 . i11iIiiIii
 if 26 - 26: Oooo0Ooo000 / iI - OoOO . iIii1I11I1II1
print "Mode: " + str ( iIIi1I1Ii1 )
print "URL: " + str ( OOoOOO0 )
print "Name: " + str ( I1i11111i1i11 )
print "iconimage: " + str ( O00ooOo )
print "id: " + str ( id )
print "trailer: " + str ( I1I1i )
if 83 - 83: iI % o0oO0 / ii11ii1ii - O0ooOooooO / O0
if 97 - 97: iIii1I11I1II1 * O0oO
def OOOoOoO ( ) :
 if 95 - 95: OoOO
 try :
  if 68 - 68: iIii1I11I1II1 . iIii1I11I1II1 / OoOO0ooOOoo0O - II111iiii - iIii1I11I1II1
  o0o0O0o = IiIi ( OOOoOoO )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( o0o0O0o )
  for I1i1iii1Ii in OOOOO0O00 :
   if 47 - 47: IIII * o0oO0 % iIii1I11I1II1 / iI
   if I1i1iii1Ii == 'si' :
    if 61 - 61: i1I111II1I + O0ooOooooO - OoOO * oO0o0ooO0
    import resoveurl
    from resoveurl import common
    import random
    from random import choice
    oooOO00oo0 = xbmc . Player ( )
    Oo0O0O0ooO0O = [ 'gtG1Y3_34ug' , '3d_ACcf0rDc' , 'AKpPeLAMY9I' , 'sVBa5hNZFHM' , '5ZCVhFmbAY0' ]
    iIi11I1II = random . choice ( Oo0O0O0ooO0O )
    OOoOOO0 = 'https://www.youtube.com/watch?v=%s' % iIi11I1II
    OOoOOO0 = resoveurl . HostedMediaFile ( OOoOOO0 ) . resolve ( )
    oooOO00oo0 . play ( OOoOOO0 )
    if 93 - 93: o00O0oo - iI % o00O0oo
    I11II1 == 'false'
    if 35 - 35: o00O0oo * Oooo0Ooo000 - oO0o0ooO0 % IIII % i11iIiiIii
   else :
    if 57 - 57: Oooo0Ooo000
    I11II1 == 'false'
    if 10 - 10: O0oO % II111iiii * OOooOOo % i1IIi * i11iIiiIii + OoOO0ooOOoo0O
    return False
    if 100 - 100: i1IIi % o0oO0
 except :
  pass
  if 55 - 55: OOooOOo + O0ooOooooO
  if 85 - 85: oO0o0ooO0 + O0ooOooooO % O0ooOooooO / O0oO . OOooOOo - OoOO0ooOOoo0O
  if 19 - 19: O0oO / O0ooOooooO + i1I111II1I
if iIIi1I1Ii1 == None or OOoOOO0 == None or len ( OOoOOO0 ) < 1 :
 if 76 - 76: iIii1I11I1II1 / Oooo0Ooo000 - o00O0oo % o0000oOoOoO0o % IIII + OoooooooOO
 if 10 - 10: OoOO * O0oO / ii11ii1ii - Oooo0Ooo000
 IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 o00O0 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 oOO0O00Oo0O0o = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 OOoo0 = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 iiII1i11i = IiIi ( oOO0O00Oo0O0o )
 OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
 for III1I1I in OOOOO0O00 :
  if 11 - 11: i1I111II1I % o00O0oo / iI . i11iIiiIii + IIII - II111iiii
  try :
   if 50 - 50: i1IIi * oO0o0ooO0 / i11iIiiIii / i11iIiiIii / oO0o0ooO0
   if 84 - 84: o00O0oo - O0ooOooooO + o00O0oo
   IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 63 - 63: O0oO * iI % II111iiii % Oooo0Ooo000 + OOooOOo * ii11ii1ii
   if 96 - 96: i1I111II1I
   if IIIi1I1IIii1II == III1I1I :
    if 99 - 99: iIii1I11I1II1 - iI
    OOI1iIi1iiIIiI ( )
    I11iiiii1II ( )
    if 79 - 79: OOooOOo + oO0o0ooO0 % O0oO % oO0o0ooO0
    I11II1 = IiII1IiiIiI1 . getSetting ( 'videos_event' )
    if I11II1 == 'true' :
     xbmc . sleep ( 3000 )
     OOOoOoO ( )
     if 56 - 56: o00O0oo + oO0o0ooO0 . OoOO + OoooooooOO * o00O0oo - O0
   else :
    if 35 - 35: IIII . O0oO . Oooo0Ooo000 - O0oO % O0oO + Oooo0Ooo000
    iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
    if 99 - 99: o0000oOoOoO0o + IIII
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Por favor compruebe los ajustes de realstream.[/COLOR]" , "[COLOR white] Desde la seccion Tutoriales puede sacarle mayor partido a su Realstream, tambien puede configurarlo a su gusto. [/COLOR]" , "[COLOR gold]El addon no esta activado o bien configurado.[/COLOR]" )
    if 34 - 34: Oooo0Ooo000 * o0000oOoOoO0o . OOooOOo % i11iIiiIii
  except :
   pass
   if 61 - 61: iIii1I11I1II1 + oO0o0ooO0 * O0oO - i1IIi % oO0o0ooO0
elif iIIi1I1Ii1 == 1 :
 iIiIi1i1Iiii ( I1i11111i1i11 , OOoOOO0 , id , I1I1i )
elif iIIi1I1Ii1 == 2 :
 Oo00ooO0OoOo ( )
elif iIIi1I1Ii1 == 3 :
 oOo00OoO0O ( )
elif iIIi1I1Ii1 == 4 :
 i1111I ( I1i11111i1i11 , OOoOOO0 )
elif iIIi1I1Ii1 == 5 :
 OOOO0Oo ( )
elif iIIi1I1Ii1 == 6 :
 O00O ( )
elif iIIi1I1Ii1 == 7 :
 Ii1I1i1ii1I1 ( )
elif iIIi1I1Ii1 == 8 :
 o00000oo00 ( )
elif iIIi1I1Ii1 == 9 :
 o0OO0oooo ( )
elif iIIi1I1Ii1 == 10 :
 i1Ii11II ( )
elif iIIi1I1Ii1 == 11 :
 Oo0OOo ( )
elif iIIi1I1Ii1 == 12 :
 I11IIII1111II ( )
elif iIIi1I1Ii1 == 13 :
 i1iiII11 ( )
elif iIIi1I1Ii1 == 14 :
 ooo0OO0OOooO0 ( )
elif iIIi1I1Ii1 == 15 :
 I1iII1IIi1IiI ( )
elif iIIi1I1Ii1 == 16 :
 I1 ( )
elif iIIi1I1Ii1 == 17 :
 iIi ( )
elif iIIi1I1Ii1 == 18 :
 ooOOo ( )
elif iIIi1I1Ii1 == 19 :
 i11Ii1IiIIIi ( )
elif iIIi1I1Ii1 == 20 :
 i1i1iIiI ( )
elif iIIi1I1Ii1 == 21 :
 I1iII11ii1 ( )
elif iIIi1I1Ii1 == 22 :
 iiiII1i1I ( )
elif iIIi1I1Ii1 == 23 :
 IiII1 ( )
elif iIIi1I1Ii1 == 24 :
 iiii1i1II1 ( )
elif iIIi1I1Ii1 == 25 :
 OooOooO0O0o0 ( )
elif iIIi1I1Ii1 == 26 :
 iI1IiiiIiI1Ii ( )
elif iIIi1I1Ii1 == 28 :
 Ii11iI1ii1111 ( I1i11111i1i11 , OOoOOO0 )
elif iIIi1I1Ii1 == 29 :
 iIi1i11 ( )
elif iIIi1I1Ii1 == 30 :
 Iiiii111 ( )
elif iIIi1I1Ii1 == 31 :
 prueba ( )
elif iIIi1I1Ii1 == 98 :
 busqueda_global ( )
elif iIIi1I1Ii1 == 97 :
 III11iI1i11i ( )
elif iIIi1I1Ii1 == 99 :
 ii11i1I1iiii ( )
elif iIIi1I1Ii1 == 100 :
 menu_player ( I1i11111i1i11 , OOoOOO0 )
elif iIIi1I1Ii1 == 111 :
 oooOoOOO0oo0o ( )
elif iIIi1I1Ii1 == 115 :
 oo0O0OO0Oo ( OOoOOO0 )
elif iIIi1I1Ii1 == 116 :
 O0Oo00 ( )
elif iIIi1I1Ii1 == 117 :
 I11iIiII ( )
elif iIIi1I1Ii1 == 119 :
 i1iI11I1II1 ( )
elif iIIi1I1Ii1 == 120 :
 o0OoO00o0000O ( )
elif iIIi1I1Ii1 == 121 :
 Iiii11iIi1 ( )
elif iIIi1I1Ii1 == 125 :
 oO0ooo0O0Ooo ( )
elif iIIi1I1Ii1 == 112 :
 list_proxy ( )
elif iIIi1I1Ii1 == 127 :
 o0O00ooo0 ( )
elif iIIi1I1Ii1 == 128 :
 TESTLINKS ( )
elif iIIi1I1Ii1 == 130 :
 o0ooo ( I1i11111i1i11 , OOoOOO0 )
elif iIIi1I1Ii1 == 140 :
 oooo00o0o0o ( )
elif iIIi1I1Ii1 == 141 :
 I11II1i11 ( )
elif iIIi1I1Ii1 == 142 :
 i1i1IiIiIi1Ii ( )
elif iIIi1I1Ii1 == 143 :
 oOo0OooOo ( I1i11111i1i11 , OOoOOO0 )
elif iIIi1I1Ii1 == 144 :
 Ii11iI1ii1111 ( I1i11111i1i11 , OOoOOO0 )
elif iIIi1I1Ii1 == 145 :
 oo0OoOooo ( )
elif iIIi1I1Ii1 == 146 :
 II1ii1ii11I1 ( )
elif iIIi1I1Ii1 == 147 :
 OoOOoooO000 ( I1i11111i1i11 , OOoOOO0 )
elif iIIi1I1Ii1 == 150 :
 I1I1 ( )
elif iIIi1I1Ii1 == 151 :
 i1iiI ( )
elif iIIi1I1Ii1 == 152 :
 IIo0OoO00 ( )
elif iIIi1I1Ii1 == 155 :
 II1i1III ( )
 if 76 - 76: oO0o0ooO0 / OoOO0ooOOoo0O
xbmcplugin . endOfDirectory ( o0OoOoOO00 ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
