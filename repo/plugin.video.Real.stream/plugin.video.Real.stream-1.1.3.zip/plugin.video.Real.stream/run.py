# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 1.1.3
#
############################################
# Dependencias 
# Script ExtendedInfo
# Script Urlresolver de TVAddons
# Script ResolveURL Por Jsergio.
#
############################################
#
# Agregar sinopsis a Peliculas y series.
# Supresion de Licencia
# Novedades en episodios agregados en series.
#
############################################
if 64 - 64: i11iIiiIii
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import urlresolver
import cookielib , base64
import requests
import plugintools
import config
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
IiII1IiiIiI1 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
o0OoOoOO00 = int ( sys . argv [ 1 ] )
I11i = 'gruponetai/'
O0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
Oo = O0O . getAddonInfo ( 'profile' )
I1ii11iIi11i = O0O . getAddonInfo ( 'path' )
I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
if 73 - 73: OOooOOo / ii11ii1ii
if 94 - 94: OoOO + OoOO0ooOOoo0O + o0000oOoOoO0o * o00O0oo
if I1IiI == 'true' :
 if 97 - 97: oO0o0ooO0 - IIII / O0oO - o0oO0
 oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.png' ) )
 o00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 Oo0oO0ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.png' ) )
 i1111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.png' ) )
 i11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'estrenos.png' ) )
 I11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.png' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.png' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.png' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.png' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.png' ) )
 oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.png' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.png' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.png' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.png' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.png' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.png' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.png' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'marvel.png' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.png' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.png' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.png' ) )
 II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.png' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.png' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.png' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.png' ) )
 OO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.png' ) )
 Ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.png' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.png' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.png' ) )
 O0OO00o0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.jpg' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.jpg' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_series.png' ) )
 OOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_Episodios.png' ) )
else :
 if 87 - 87: O0ooOooooO / i1I111II1I - Oooo0Ooo000 - iI - II111iiii / O0
 if 97 - 97: iI - IIII * i11iIiiIii / OoOO0ooOOoo0O % Oooo0Ooo000 - OoooooooOO
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
 oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.jpg' ) )
 o00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 Oo0oO0ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.jpg' ) )
 i1111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.jpg' ) )
 i11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'encines.jpg' ) )
 I11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.jpg' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.jpg' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.jpg' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.jpg' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.jpg' ) )
 oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.jpg' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.jpg' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.jpg' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.jpg' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.jpg' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.jpg' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.jpg' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'superheroes.jpg' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.jpg' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.jpg' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.jpg' ) )
 II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.jpg' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.jpg' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.jpg' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.jpg' ) )
 OO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.jpg' ) )
 Ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.jpg' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.jpg' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.jpg' ) )
 O0OO00o0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.jpg' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.jpg' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.jpg' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favoritos.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_series.png' ) )
 OOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_Episodios.png' ) )
 if 59 - 59: O0 + OOooOOo + i1I111II1I % OOooOOo
 if 70 - 70: O0ooOooooO * o00O0oo
 if 46 - 46: iI / OoOO
OOOoO0O0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'peliculas.png' ) )
O0o0Ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series.png' ) )
O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ajustes.png' ) )
iI1Ii11iII1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'videoteca.png' ) )
Oo0O0O0ooO0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
IIIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'resolver.png' ) )
O0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'test.png' ) )
OO00Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'video-tutoriales.png' ) )
O0OOO0OOoO0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'proxy.png' ) )
if 70 - 70: i1I111II1I * ii11ii1ii * O0oO / o0oO0
if 88 - 88: O0
if 64 - 64: O0oO * O0 + i1I111II1I - IIII + i11iIiiIii * o0oO0
if 30 - 30: o0000oOoOoO0o . o0oO0 - OoooooooOO
Ii1iIiii1 = IiII1IiiIiI1 . getSetting ( 'mostrar_cat' )
OOO = IiII1IiiIiI1 . getSetting ( 'videos' )
Oo0oOOo = IiII1IiiIiI1 . getSetting ( 'activar' )
Oo0OoO00oOO0o = IiII1IiiIiI1 . getSetting ( 'favcopy' )
OOO00O = IiII1IiiIiI1 . getSetting ( 'anticopia' )
OOoOO0oo0ooO = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'notificar' )
O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'mostrar_bus' )
i1Oo00 = IiII1IiiIiI1 . getSetting ( 'restante' )
i1i = IiII1IiiIiI1 . getSetting ( 'selecton' )
iiI111I1iIiI = IiII1IiiIiI1 . getSetting ( 'aviso' )
IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'RealStream_Settings' )
O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'Resolver_Settings' )
i1Oo00 = IiII1IiiIiI1 . getSetting ( 'restante' )
oooooOoo0ooo = IiII1IiiIiI1 . getSetting ( 'fav' )
I1I1IiI1 = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
III1iII1I1ii = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
oOOo0 = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
oo00O00oO = 'bienvenida'
iIiIIIi = 'bienvenida'
copyright = IiII1IiiIiI1 . getSetting ( 'copyright' )
ooo00OOOooO = 'cGx1Z2luLnZpZGVvLg==' . decode ( 'base64' ) + copyright
O00OOOoOoo0O = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
O000OOo00oo = IiII1IiiIiI1 . getSetting ( 'Forceupdate' )
if O000OOo00oo == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
oo0OOo = 'LnR4dA==' . decode ( 'base64' )
if 64 - 64: O0oO
if 22 - 22: ii11ii1ii + o0oO0 % o00O0oo
iI1 = 'aHR0cDovL2JpdC5seS8yU1FOSnlP' . decode ( 'base64' )
IIi1iIi = oOOo0 + oo00O00oO + oo0OOo
ooOOoooooo = 'http://www.youtube.com'
II1I = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
O0i1II1Iiii1I11 = 'http://bit.ly/2ImelUx'
IIIIiiIiI = '.xsl.pt'
o00oooO0Oo = 'L21hc3Rlci8=' . decode ( 'base64' )
o0O0OOO0Ooo = II1I + IIIIiiIiI
iiIiI = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*'
I1 = 'tvg-logo=[\'"](.*?)[\'"]'
if 86 - 86: OoOO0ooOOoo0O - o0oO0 - OoOO * O0ooOooooO
oooo0O0 = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.*)'
oOOO = '(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)'
iIII1 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
o0o = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
O0OOoO00OO0o = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
I1111IIIIIi = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
Iiii1i1 = '#(.+?),(.+)\s*(.+)'
OO = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
if 77 - 77: ii11ii1ii
I1iII1iIi1I = 'source src=[\'"](.*?)[\'"]\s*title=[\'"](.*?)[\'"]'
oO0O00OoOO0 = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
OoO = '[\'"](.*?)[\'"]'
O00I1iI1 = r'066">\s*(.+)</f'
iiiIi1 = '[\'"](.*?)[\'"]'
i1I1ii11i1Iii = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
I1IiiiiI = '[\'"](.*?)[\'"]'
o0O = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( 'base64' )
IiII = o0O + I11i
ii1iII1II = '[\'"](.*?)[\'"]'
Iii1I1I11iiI1 = 'UmVhbHN0cmVhbQ==' . decode ( 'base64' )
I1I1i1I = 'video=[\'"](.*?)[\'"]'
ii1I = '0110nhu' . replace ( '0110nhu' , 'nhu' )
O0oO0 = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( 'base64' ) + ii1I
oO0 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
O0OO0O = '0110R0N' . replace ( '0110R0N' , 'R0N' )
OOOoOoO = 'aHR0cDovL2JpdC5seS8yWEIx' . decode ( 'base64' ) + O0OO0O
Ii1I1i = '0110pEJ' . replace ( '0110pEJ' , 'pEJ' )
OOI1iI1ii1II = 'aHR0cDovL2JpdC5seS8yd1Nh' . decode ( 'base64' ) + Ii1I1i
O0O0OOOOoo = 'ABBAOb5' . replace ( 'ABBAOb5' , 'Ob5' )
oOooO0 = 'aHR0cDovL2JpdC5seS8yRVhV' . decode ( 'base64' ) + O0O0OOOOoo
Ii1I1Ii = '0110jaw' . replace ( '0110jaw' , 'jaw' )
OOoO0 = 'aHR0cDovL2JpdC5seS8yd01M' . decode ( 'base64' ) + Ii1I1Ii
OO0Oooo0oOO0O = '01109DI' . replace ( '01109DI' , '9DI' )
o00O0 = 'aHR0cDovL2JpdC5seS8ySXgz' . decode ( 'base64' ) + OO0Oooo0oOO0O
oOO0O00Oo0O0o = '01103hs' . replace ( '01103hs' , '3hs' )
ii1 = 'aHR0cDovL2JpdC5seS8zMW1U' . decode ( 'base64' ) + oOO0O00Oo0O0o
I1iIIiiIIi1i = '01107DW' . replace ( '01107DW' , '7DW' )
O0O0ooOOO = 'aHR0cDovL2JpdC5seS8yV1ln' . decode ( 'base64' ) + I1iIIiiIIi1i
oOOo0O00o = '0110mLl' . replace ( '0110mLl' , 'mLl' )
iIiIi11 = 'aHR0cDovL2JpdC5seS8yS0cw' . decode ( 'base64' ) + oOOo0O00o
OOOiiiiI = '01102Hj' . replace ( '01102Hj' , '2Hj' )
oooOo0OOOoo0 = 'aHR0cDovL2JpdC5seS8yWEJo' . decode ( 'base64' ) + OOOiiiiI
OOoO = '0110fXg' . replace ( '0110fXg' , 'fXg' )
OO0O000 = 'aHR0cDovL2JpdC5seS8ySTVy' . decode ( 'base64' ) + OOoO
iiIiI1i1 = '0110NMH' . replace ( '0110NMH' , 'NMH' )
oO0O00oOOoooO = 'aHR0cDovL2JpdC5seS8yd0t6' . decode ( 'base64' ) + iiIiI1i1
IiIi11iI = '0110bwQ' . replace ( '0110bwQ' , 'bwQ' )
Oo0O00O000 = 'aHR0cDovL2JpdC5seS8yd01V' . decode ( 'base64' ) + IiIi11iI
i11I1IiII1i1i = '0110xzG' . replace ( '0110xzG' , 'xzG' )
oo = 'aHR0cDovL2JpdC5seS8yWHhz' . decode ( 'base64' ) + i11I1IiII1i1i
I1111i = '0110x64' . replace ( '0110x64' , 'x64' )
iIIii = 'aHR0cDovL2JpdC5seS8yRVlF' . decode ( 'base64' ) + I1111i
o00O0O = '0110vUE' . replace ( '0110vUE' , 'vUE' )
ii1iii1i = 'aHR0cDovL2JpdC5seS8yWmhW' . decode ( 'base64' ) + o00O0O
Iii1I1111ii = '01107ZL' . replace ( '01107ZL' , '7ZL' )
ooOoO00 = 'aHR0cDovL2JpdC5seS8yWm4w' . decode ( 'base64' ) + Iii1I1111ii
Ii1IIiI1i = '01106cf' . replace ( '01106cf' , '6cf' )
o0O00Oo0 = 'aHR0cDovL2JpdC5seS8yRVlk' . decode ( 'base64' ) + Ii1IIiI1i
IiII111i1i11 = '0110Jtp' . replace ( '0110Jtp' , 'Jtp' )
i111iIi1i1II1 = 'aHR0cDovL2JpdC5seS8yV3Nq' . decode ( 'base64' ) + IiII111i1i11
oooO = '0110a5b' . replace ( '0110a5b' , 'a5b' )
i1I1i111Ii = 'aHR0cDovL2JpdC5seS8yV3dj' . decode ( 'base64' ) + oooO
ooo = '0110Q7u' . replace ( '0110Q7u' , 'Q7u' )
i1i1iI1iiiI = 'aHR0cDovL2JpdC5seS8yV3NL' . decode ( 'base64' ) + ooo
Ooo0oOooo0 = '0110rsq' . replace ( '0110rsq' , 'rsq' )
oOOOoo00 = 'aHR0cDovL2JpdC5seS8ySzhE' . decode ( 'base64' ) + Ooo0oOooo0
iiIiIIIiiI = '0110DDR' . replace ( '0110DDR' , 'DDR' )
iiI1IIIi = 'aHR0cDovL2JpdC5seS8ySzd5' . decode ( 'base64' ) + iiIiIIIiiI
II11IiIi11 = '0110feQ' . replace ( '0110feQ' , 'feQ' )
IIOOO0O00O0OOOO = 'aHR0cDovL2JpdC5seS8yS0cz' . decode ( 'base64' ) + II11IiIi11
I1iiii1I = '0110MHY' . replace ( '0110MHY' , 'MHY' )
OOo0 = 'aHR0cDovL2JpdC5seS8ySXVo' . decode ( 'base64' ) + I1iiii1I
oO00ooooO0o = '0110xdb' . replace ( '0110xdb' , 'xdb' )
oo0o = 'aHR0cDovL2JpdC5seS8yWEJu' . decode ( 'base64' ) + oO00ooooO0o
o0oO0oooOoo = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( 'base64' )
I1III1111iIi = 'aHR0cHM6Ly9uZXRhaS5ldS92aXNpdGFzL2luZGV4LnBocA==' . decode ( 'base64' )
ooo00OOOooO = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
I1i111I = '0110lxu' . replace ( '0110lxu' , 'lxu' )
OooOo0oo0O0o00O = 'aHR0cDovL2JpdC5seS8yV1Bj' . decode ( 'base64' ) + I1i111I
I1i11 = '0110pzp' . replace ( '0110pzp' , 'pzp' )
IiIi1I1 = 'aHR0cDovL2JpdC5seS8yVHpB' . decode ( 'base64' ) + I1i11
IiIIi1 = '01105yt' . replace ( '01105yt' , '5yt' )
IIIIiii1IIii = 'aHR0cDovL2JpdC5seS8yTVpp' . decode ( 'base64' ) + IiIIi1
if 38 - 38: IIII + II111iiii % iI % OoOO0ooOOoo0O - o0oO0 / OoooooooOO
if 73 - 73: o0000oOoOoO0o * O0 - i11iIiiIii
O0O0o0oOOO = '1001DTs' . replace ( '1001DTs' , 'DTs' )
OOoOoOo = 'aHR0cDovL2JpdC5seS8ySzhP' . decode ( 'base64' ) + O0O0o0oOOO
o000ooooO0o = '1001Hky' . replace ( '1001Hky' , 'Hky' )
iI1i11 = 'aHR0cDovL2JpdC5seS8yTGVL' . decode ( 'base64' ) + o000ooooO0o
OoOOoooOO0O = '1001VFU' . replace ( '1001VFU' , 'VFU' )
ooo00Ooo = 'aHR0cDovL2JpdC5seS8zMERx' . decode ( 'base64' ) + OoOOoooOO0O
Oo0o0O00 = '3545OMZ' . replace ( '3545OMZ' , 'OMZ' )
ii1I1i11 = 'aHR0cDovL2JpdC5seS8yazhk' . decode ( 'base64' ) + Oo0o0O00
OOo0O0oo0OO0O = '4224tZO' . replace ( '4224tZO' , 'tZO' )
OO0 = 'aHR0cDovL2JpdC5seS8zNXd4' . decode ( 'base64' ) + OOo0O0oo0OO0O
if 72 - 72: OoooooooOO
def OooooOoooO ( ) :
 if 56 - 56: ii11ii1ii . o00O0oo . OOooOOo
 if 39 - 39: O0 + Oooo0Ooo000
 try :
  if 91 - 91: OoooooooOO - iIii1I11I1II1 + OoOO0ooOOoo0O / OoOO . OoOO0ooOOoo0O + O0
  iIiii1iI1 = i11ii1ii11i ( OOOoOoO )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   try :
    if 80 - 80: oO0o0ooO0 + IIII / O0oO
    OOI1iI1ii1II = O0O0Oo00
    if 79 - 79: iI
    i11I1I1I = xbmc . Keyboard ( '' , 'Busqueda por titulo' )
    i11I1I1I . doModal ( )
    if ( i11I1I1I . isConfirmed ( ) ) :
     if 64 - 64: o0oO0
     oo00O00Oo = urllib . quote_plus ( i11I1I1I . getText ( ) ) . replace ( '+' , ' ' )
     IIIII1II = i11ii1ii11i ( OOI1iI1ii1II )
     ooO0OoOO = re . compile ( oooo0O0 ) . findall ( IIIII1II )
     for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
      if re . search ( oo00O00Oo , OO0O00oOo ( iI1ii1i . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
       if 14 - 14: oO0o0ooO0 / oO0o0ooO0 % iI
    ooO ( '[COLOR %s]Buscar Pelicula[/COLOR]' % III1iII1I1ii , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
   except : ooO ( '[COLOR %s]Buscar Pelicula[/COLOR]' % III1iII1I1ii , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
   if 6 - 6: iIii1I11I1II1 . iI % o0000oOoOoO0o
   if 50 - 50: O0ooOooooO + O0 + o0oO0 . II111iiii / o0000oOoOoO0o
 except :
  pass
  if 17 - 17: o0oO0 % iIii1I11I1II1 - iIii1I11I1II1
  if 78 - 78: O0ooOooooO + O0oO . iI - O0ooOooooO . o0oO0
def II1I11i ( ) :
 if 82 - 82: O0oO + OoooooooOO - i1IIi . i1IIi
 iiI111I1iIiI = IiII1IiiIiI1 . getSetting ( 'aviso' )
 if iiI111I1iIiI == 'true' :
  iIiii1iI1 = i11ii1ii11i ( IIi1iIi )
  ooO0OoOO = re . compile ( iiIiI ) . findall ( iIiii1iI1 )
  for iIi1i , I1i11111i1i11 in ooO0OoOO :
   try :
    if 77 - 77: o00O0oo + OoOO / oO0o0ooO0 + O0 * o0000oOoOoO0o
    if 28 - 28: iI + i11iIiiIii / O0oO % OoOO0ooOOoo0O % ii11ii1ii - O0
    ooo0OOO = iIi1i
    iii1Ii1Ii1 = I1i11111i1i11
    if 21 - 21: oO0o0ooO0 . Oooo0Ooo000 . IIII / ii11ii1ii / Oooo0Ooo000
    if 17 - 17: IIII / IIII / O0oO
    from datetime import datetime
    if 1 - 1: i1IIi . i11iIiiIii % IIII
    OooO0oo = datetime . now ( )
    o0o0oOoOO0O = OooO0oo . strftime ( '%d/%m/%Y' )
    if 16 - 16: i1I111II1I % iIii1I11I1II1 . o0oO0
    oooooOOO000Oo = i11ii1ii11i ( I1III1111iIi )
    ooO0OoOO = re . compile ( O00I1iI1 ) . findall ( oooooOOO000Oo )
    for Ooo00OoOOO in ooO0OoOO :
     if 98 - 98: iIii1I11I1II1 * o00O0oo * IIII + iI % i11iIiiIii % O0
     i1OO0oOOoo = "[B]" + ooo0OOO + "[/B]"
     oOOO00o000o = "" + iii1Ii1Ii1 + ""
     iIi11i1 = "[COLOR white]Hoy: " + o0o0oOoOO0O + ", Es usted el visitante numero: [B][COLOR gold]" + Ooo00OoOOO + "[/B][/COLOR]"
     if 71 - 71: iI
     xbmcgui . Dialog ( ) . ok ( "Real Stream" , i1OO0oOOoo , oOOO00o000o , iIi11i1 )
     if 53 - 53: OoooooooOO % o0oO0 . i1I111II1I / i11iIiiIii % O0ooOooooO
   except :
    pass
    if 28 - 28: O0oO
    if 58 - 58: OoOO0ooOOoo0O
  IIIII1II = i11ii1ii11i ( o0oO0oooOoo )
  ooO0OoOO = re . compile ( OoO ) . findall ( IIIII1II )
  for iIiiI1iI in ooO0OoOO :
   try :
    if 5 - 5: OoOO0ooOOoo0O / OoooooooOO + i1I111II1I * Oooo0Ooo000 - OoOO % OOooOOo
    import xbmc
    import xbmcaddon
    if 42 - 42: O0 / o0000oOoOoO0o + OoooooooOO * iI % iI
    __addon__ = xbmcaddon . Addon ( )
    __addonname__ = __addon__ . getAddonInfo ( 'name' )
    __icon__ = __addon__ . getAddonInfo ( 'icon' )
    if 7 - 7: O0ooOooooO / o00O0oo / i11iIiiIii
    iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
    IIIIIo0ooOoO000oO = iIiiI1iI
    if 85 - 85: o0000oOoOoO0o . OoOO0ooOOoo0O / iI . O0 % Oooo0Ooo000
    i1OO0oOOoo = "[COLOR orange]Version instalada: [COLOR gold] " + iIiiiI1IiI1I1 + " [/COLOR][/COLOR] Disponible: " + iIiiI1iI + ""
    OO0ooo0oOO = 4000
    if 97 - 97: OOooOOo / O0ooOooooO
    xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , i1OO0oOOoo , OO0ooo0oOO , __icon__ ) )
    if 71 - 71: II111iiii / i1IIi . o00O0oo % OoooooooOO . OoOO0ooOOoo0O
   except :
    pass
    if 41 - 41: i1IIi * II111iiii / OoooooooOO . IIII
 if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
 return
 if 83 - 83: O0ooOooooO . O0 / ii11ii1ii / IIII - II111iiii
def OO0O00oOo ( s ) :
 if 100 - 100: OoOO
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 46 - 46: OoOO0ooOOoo0O / iIii1I11I1II1 % O0ooOooooO . iIii1I11I1II1 * O0ooOooooO
def IIi1ii1Ii ( file ) :
 if 91 - 91: i11iIiiIii / OoooooooOO + O0ooOooooO - i11iIiiIii + IIII
 try :
  ii1i = open ( file , 'r' )
  iIiii1iI1 = ii1i . read ( )
  ii1i . close ( )
  return iIiii1iI1
 except :
  pass
  if 62 - 62: OoOO / o00O0oo
def i11ii1ii11i ( url ) :
 if 7 - 7: OoooooooOO . i1I111II1I
 try :
  O000OOO0OOo = urllib2 . Request ( url )
  O000OOO0OOo . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  i1i1I111iIi1 = urllib2 . urlopen ( O000OOO0OOo )
  oo00O00oO000o = i1i1I111iIi1 . read ( )
  i1i1I111iIi1 . close ( )
  return oo00O00oO000o
 except urllib2 . URLError , OOo00OoO :
  print 'We failed to open "%s".' % url
  if hasattr ( OOo00OoO , 'code' ) :
   print 'We failed with error code - %s.' % OOo00OoO . code
  if hasattr ( OOo00OoO , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , OOo00OoO . reason
   if 10 - 10: o0000oOoOoO0o / i11iIiiIii
def o00oO ( url ) :
 O000OOO0OOo = urllib2 . Request ( url )
 O000OOO0OOo . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 O000OOO0OOo . add_header ( 'Referer' , '%s' % url )
 O000OOO0OOo . add_header ( 'Connection' , 'keep-alive' )
 i1i1I111iIi1 = urllib2 . urlopen ( O000OOO0OOo )
 oo00O00oO000o = i1i1I111iIi1 . read ( )
 i1i1I111iIi1 . close ( )
 return oo00O00oO000o
 if 92 - 92: i1I111II1I * ii11ii1ii * ii11ii1ii * OOooOOo . iIii1I11I1II1
 if 16 - 16: iI % OoooooooOO - IIII * o0oO0 * o00O0oo / OoooooooOO
def I11o0oO00oO0o0o0 ( ) :
 if 17 - 17: O0oO . i1I111II1I - II111iiii + O0 / iIii1I11I1II1 / i11iIiiIii
 III1iII1I1ii = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 if 39 - 39: i1I111II1I * ii11ii1ii + iIii1I11I1II1 - i1I111II1I + IIII
 if Oo0oOOo == 'true' :
  if 69 - 69: O0
  ooO ( '[COLOR %s]Buscar Pelicula[/COLOR]' % III1iII1I1ii , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
  ooO ( '[COLOR %s]Buscar Serie[/COLOR]' % III1iII1I1ii , 'search' , 145 , I1IIIii , oo00 )
  ooO ( '[COLOR %s]Peliculas[/COLOR] ' % III1iII1I1ii , 'movieDB' , 116 , OOOoO0O0o , oo00 )
  ooO ( '[COLOR %s]Series[/COLOR] ' % III1iII1I1ii , 'movieDB' , 117 , O0o0Ooo , oo00 )
  if 85 - 85: iI / O0
  if 18 - 18: o0000oOoOoO0o % O0 * o00O0oo
 if IIIi1I1IIii1II == 'true' :
  ooO ( '[COLOR %s]Ajustes[/COLOR]' % III1iII1I1ii , 'Settings' , 119 , O00 , oo00 )
  if 62 - 62: Oooo0Ooo000 . i1I111II1I . OoooooooOO
  if 11 - 11: IIII / O0oO
  if Ii1iIiii1 == 'true' :
   oooO0 ( )
   if 16 - 16: II111iiii + oO0o0ooO0 - OoooooooOO
  if O0ii1ii1ii == 'true' :
   ii1iI ( )
   IIi ( )
   if 89 - 89: II111iiii + i1IIi + II111iiii
  if OOO00O == 'false' :
   if 7 - 7: O0 % o0000oOoOoO0o + o00O0oo * O0ooOooooO - O0ooOooooO
   i1OO0oOOoo = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   oOOO00o000o = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Script.ResolveURL para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   iIi11i1 = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 42 - 42: OoOO0ooOOoo0O * OoOO0ooOOoo0O * Oooo0Ooo000 . O0oO
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , i1OO0oOOoo , oOOO00o000o , iIi11i1 )
   if 51 - 51: IIII % iIii1I11I1II1 - OoooooooOO % iI * iIii1I11I1II1 % OoOO
def oO0o00oOOooO0 ( ) :
 ooO ( '[COLOR orange]Buscador por id[/COLOR]' , ooOOoooooo , 127 , oOOoo00O0O , oo00 )
 if 79 - 79: OoOO - iIii1I11I1II1 + o0oO0 - Oooo0Ooo000
def OoOiIIiii ( ) :
 III1iII1I1ii = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 ooO ( '[COLOR %s]The movie DB[/COLOR]' % III1iII1I1ii , 'movieDB' , 99 , oOOoo00O0O , oo00 )
 if 61 - 61: i1I111II1I . i1IIi / Oooo0Ooo000 % i11iIiiIii * O0ooOooooO
 ooO ( '[COLOR %s]Video tutoriales[/COLOR]' % III1iII1I1ii , ooOOoooooo , 125 , OO00Oo , oo00 )
 if 31 - 31: IIII + O0
 if 87 - 87: iI
 if 45 - 45: OoOO / OoooooooOO - O0ooOooooO / o0oO0 % i1I111II1I
def OoOIii11iI11i1I ( ) :
 if 64 - 64: i11iIiiIii
 I11o0oO00oO0o0o0 ( )
 OoOiIIiii ( )
 if 38 - 38: i1I111II1I / OOooOOo - i1I111II1I . O0oO
def ooO00O ( ) :
 if 68 - 68: i11iIiiIii + o0oO0
 OoOIii11iI11i1I ( )
 if 77 - 77: Oooo0Ooo000
def OooOOOOoO00OoOO ( ) :
 if xbmc . getCondVisibility ( 'System.HasAddon(script.favourites)' ) :
  try :
   xbmc . executebuiltin ( "RunScript(script.favourites)" )
  except :
   pass
def oOooo0O0o ( ) :
 IiII1IiiIiI1 . openSettings ( )
 if 72 - 72: iIii1I11I1II1 / i1I111II1I % O0ooOooooO % IIII - O0oO % IIII
 if 100 - 100: ii11ii1ii + i11iIiiIii
def O0oOOO000oooo0 ( ) :
 urlresolver . display_settings ( )
 if 77 - 77: OOooOOo % O0
def ii1iI ( ) :
 ooO ( '[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % III1iII1I1ii , 'resolve' , 120 , IIIIii , oo00 )
 if 36 - 36: o0oO0 / II111iiii / i1I111II1I / i1I111II1I + o00O0oo
def oO0Ooo0ooOO0 ( ) :
 if 46 - 46: o0oO0 % OoOO0ooOOoo0O
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 64 - 64: i11iIiiIii - II111iiii
def IIi ( ) :
 ooO ( '[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % III1iII1I1ii , 'resolve' , 140 , IIIIii , oo00 )
 if 77 - 77: OoOO0ooOOoo0O % o0oO0
def oooO0 ( ) :
 if 9 - 9: OoOO - ii11ii1ii * OoooooooOO . ii11ii1ii
 III1iII1I1ii = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 ooO ( '[COLOR %s]Buscador[/COLOR]' % III1iII1I1ii , 'search' , 111 , o0oOoO00o , oo00 )
 ooO ( '[COLOR %s]Estrenos[/COLOR]' % III1iII1I1ii , ooOOoooooo , 3 , i11 , oo00 )
 ooO ( '[COLOR %s]Todas[/COLOR]' % III1iII1I1ii , ooOOoooooo , 26 , I11 , oo00 )
 ooO ( '[COLOR %s]4K[/COLOR]' % III1iII1I1ii , ooOOoooooo , 141 , O0o0Oo , oo00 )
 ooO ( '[COLOR %s]Novedades[/COLOR]' % III1iII1I1ii , ooOOoooooo , 2 , i1111 , oo00 )
 ooO ( '[COLOR %s]Accion[/COLOR]' % III1iII1I1ii , ooOOoooooo , 5 , Oo0o0000o0o0 , oo00 )
 ooO ( '[COLOR %s]Animacion[/COLOR]' % III1iII1I1ii , ooOOoooooo , 6 , oOo0oooo00o , oo00 )
 ooO ( '[COLOR %s]Artes Marciales[/COLOR]' % III1iII1I1ii , ooOOoooooo , 29 , o0 , oo00 )
 ooO ( '[COLOR %s]Aventuras[/COLOR]' % III1iII1I1ii , ooOOoooooo , 7 , oO0o0o0ooO0oO , oo00 )
 ooO ( '[COLOR %s]Belico[/COLOR]' % III1iII1I1ii , ooOOoooooo , 8 , oo0o0O00 , oo00 )
 ooO ( '[COLOR %s]Ciencia Ficcion[/COLOR]' % III1iII1I1ii , ooOOoooooo , 9 , oO , oo00 )
 ooO ( '[COLOR %s]Cine Clasico[/COLOR]' % III1iII1I1ii , ooOOoooooo , 30 , i1iiIIiiI111 , oo00 )
 ooO ( '[COLOR %s]Comedia[/COLOR]' % III1iII1I1ii , ooOOoooooo , 10 , oooOOOOO , oo00 )
 ooO ( '[COLOR %s]Crimen[/COLOR]' % III1iII1I1ii , ooOOoooooo , 11 , i1iiIII111ii , oo00 )
 ooO ( '[COLOR %s]Drama[/COLOR]' % III1iII1I1ii , ooOOoooooo , 12 , i1iIIi1 , oo00 )
 ooO ( '[COLOR %s]Familiar[/COLOR]' % III1iII1I1ii , ooOOoooooo , 13 , ii11iIi1I , oo00 )
 ooO ( '[COLOR %s]Fantasia[/COLOR]' % III1iII1I1ii , ooOOoooooo , 14 , iI111I11I1I1 , oo00 )
 ooO ( '[COLOR %s]Historia[/COLOR]' % III1iII1I1ii , ooOOoooooo , 15 , OOooO0OOoo , oo00 )
 ooO ( '[COLOR %s]Misterio[/COLOR]' % III1iII1I1ii , ooOOoooooo , 16 , oOOoO0 , oo00 )
 ooO ( '[COLOR %s]Musical[/COLOR]' % III1iII1I1ii , ooOOoooooo , 17 , O0OoO000O0OO , oo00 )
 ooO ( '[COLOR %s]Romance[/COLOR]' % III1iII1I1ii , ooOOoooooo , 18 , iiI1IiI , oo00 )
 ooO ( '[COLOR %s]Thriller[/COLOR]' % III1iII1I1ii , ooOOoooooo , 19 , II11iiii1Ii , oo00 )
 ooO ( '[COLOR %s]Suspense[/COLOR]' % III1iII1I1ii , ooOOoooooo , 20 , ooOoOoo0O , oo00 )
 ooO ( '[COLOR %s]Terror[/COLOR]' % III1iII1I1ii , ooOOoooooo , 21 , OooO0 , oo00 )
 ooO ( '[COLOR %s]Western[/COLOR]' % III1iII1I1ii , ooOOoooooo , 22 , OO0o , oo00 )
 ooO ( '[COLOR %s]Spain[/COLOR]' % III1iII1I1ii , ooOOoooooo , 23 , II , oo00 )
 ooO ( '[COLOR %s]Super heroes[/COLOR]' % III1iII1I1ii , ooOOoooooo , 24 , iIii1 , oo00 )
 ooO ( '[COLOR %s]Sagas[/COLOR]' % III1iII1I1ii , ooOOoooooo , 25 , Ooo , oo00 )
 if 2 - 2: OoooooooOO % IIII
def oOoOOo0oo0 ( ) :
 if 60 - 60: iI * Oooo0Ooo000 + ii11ii1ii
 ooO ( '[COLOR %s]Buscar Serie[/COLOR]' % III1iII1I1ii , 'search' , 145 , O0OO00o0OO , oo00 )
 if 19 - 19: OoOO * O0oO / O0oO . OoooooooOO - IIII + i11iIiiIii
 oo0OOo0O ( )
 if 39 - 39: OoooooooOO + oO0o0ooO0 % IIII / IIII
 ooO ( '[COLOR %s]En emision[/COLOR]' % III1iII1I1ii , ooOOoooooo , 150 , I11II1i , oo00 )
 ooO ( '[COLOR %s]Mejor valoradas[/COLOR]' % III1iII1I1ii , ooOOoooooo , 151 , IIIII , oo00 )
 ooO ( '[COLOR %s]Series Retro[/COLOR]' % III1iII1I1ii , ooOOoooooo , 152 , ooooooO0oo , oo00 )
 ooO ( '[COLOR %s]Todas[/COLOR]' % III1iII1I1ii , ooOOoooooo , 142 , I11i1 , oo00 )
 if 27 - 27: O0ooOooooO . O0oO . iIii1I11I1II1 . iIii1I11I1II1
def oo0OOo0O ( ) :
 if 20 - 20: o0000oOoOoO0o / i1IIi
 oOIi111 = 'aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtLw==' . decode ( 'base64' )
 oO0i1iI = 'Y29uZGljaW9uLnR4dA==' . decode ( 'base64' )
 oo00O00oO000o = oOIi111 + oO0i1iI
 ii = '[\'"](.*?)[\'"]'
 oOoOOo0oo0 = i11ii1ii11i ( oo00O00oO000o )
 ooO0OoOO = re . compile ( ii ) . findall ( oOoOOo0oo0 )
 for oo0o0OoOOO in ooO0OoOO :
  try :
   if 88 - 88: O0ooOooooO
   if oo0o0OoOOO == 'si' :
    if 19 - 19: II111iiii * i1I111II1I + o0oO0
    ooO ( '[COLOR %s]Hay Nuevos Episodios[/COLOR]' % III1iII1I1ii , ooOOoooooo , 155 , OOOO , oo00 )
    if 65 - 65: IIII . Oooo0Ooo000 . OoOO . O0ooOooooO - IIII
   return
   if 19 - 19: i11iIiiIii + O0ooOooooO % iI
  except :
   pass
   if 14 - 14: OoOO . II111iiii . O0oO / o0oO0 % o00O0oo - iI
def o0oOoO0O ( ) :
 if 84 - 84: O0 * OoooooooOO - i1I111II1I * i1I111II1I
 if 8 - 8: iI / i1IIi . oO0o0ooO0
 try :
  if 41 - 41: O0ooOooooO + OoOO
  oOO = i11ii1ii11i ( OOoOoOo )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( oOO )
  for O0O0Oo00 in ooO0OoOO :
   if 11 - 11: i11iIiiIii - oO0o0ooO0 . oO0o0ooO0
   try :
    if 31 - 31: IIII / ii11ii1ii * i1IIi . OoOO0ooOOoo0O
    OO0o0oO = O0O0Oo00
    i11I1I1I = xbmc . Keyboard ( '' , 'Buscar' )
    i11I1I1I . doModal ( )
    if ( i11I1I1I . isConfirmed ( ) ) :
     OO0oo = xbmcgui . DialogProgress ( )
     OO0oo . create ( 'Realstream:' , 'Buscando ...' )
     OO0oo . update ( 10 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     OO0oo . update ( 15 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     OO0oo . update ( 20 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     OO0oo . update ( 25 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     OO0oo . update ( 35 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     OO0oo . update ( 45 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     OO0oo . update ( 55 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     OO0oo . update ( 65 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     OO0oo . update ( 80 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     OO0oo . update ( 90 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 50 )
     OO0oo . update ( 100 , 'RESOLVEURL:' , 'Buscando ... Por favor, espere!' )
     xbmc . sleep ( 100 )
     OO0oo . close ( )
     oo00O00Oo = urllib . quote_plus ( i11I1I1I . getText ( ) ) . replace ( '+' , ' ' )
     IIIII1II = i11ii1ii11i ( OO0o0oO )
     ooO0OoOO = re . compile ( iIII1 ) . findall ( IIIII1II )
     for IiIi1II11i , iI1ii1i , oo00 , Oo0oooO0oO , Iii1iiIi1II in ooO0OoOO :
      if re . search ( oo00O00Oo , OO0O00oOo ( iI1ii1i . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       ooO ( '[COLOR %s]Buscar Serie[/COLOR]' % III1iII1I1ii , 'search' , 145 , O0OO00o0OO , oo00 )
       II1II1iIIi11 ( iI1ii1i , Oo0oooO0oO , 143 , IiIi1II11i , oo00 , Iii1iiIi1II )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Resultados para: [COLOR orange]" + oo00O00Oo + "[/COLOR] ,3000)" )
       if 49 - 49: OoooooooOO * O0oO - ii11ii1ii . oO0o0ooO0
       if 89 - 89: iI + o0oO0 * iI / iI
   except : ooO ( '[COLOR %s]Buscar Serie[/COLOR]' % III1iII1I1ii , 'search' , 145 , O0OO00o0OO , oo00 )
   if 46 - 46: OoOO
 except :
  pass
  if 71 - 71: O0oO / O0oO * oO0o0ooO0 * oO0o0ooO0 / II111iiii
def II1I1iiIII1I1 ( ) :
 if 85 - 85: O0ooOooooO * o0000oOoOoO0o
 try :
  if 3 - 3: IIII
  oOO = i11ii1ii11i ( OO0 )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( oOO )
  for O0O0Oo00 in ooO0OoOO :
   if 20 - 20: II111iiii . O0ooOooooO / II111iiii % i11iIiiIii % O0ooOooooO
   try :
    if 11 - 11: i1I111II1I % o00O0oo % o0oO0 / II111iiii % Oooo0Ooo000 - ii11ii1ii
    OO0o0oO = O0O0Oo00
    if 96 - 96: o00O0oo / II111iiii . o0oO0 - O0ooOooooO * O0oO * oO0o0ooO0
   except :
    pass
    if 76 - 76: o0oO0 - II111iiii * IIII / OoooooooOO
  IIIII1II = i11ii1ii11i ( OO0o0oO )
  ooO0OoOO = re . compile ( iIII1 ) . findall ( IIIII1II )
  for IiIi1II11i , iI1ii1i , oo00 , Oo0oooO0oO , Iii1iiIi1II in ooO0OoOO :
   try :
    if 18 - 18: OoOO + iIii1I11I1II1 - II111iiii - OOooOOo
    II1II1iIIi11 ( iI1ii1i , Oo0oooO0oO , 143 , IiIi1II11i , oo00 , Iii1iiIi1II )
    if 71 - 71: OoooooooOO
   except :
    pass
 except :
  pass
  if 33 - 33: Oooo0Ooo000
def OOO0ooo ( ) :
 if 7 - 7: o0000oOoOoO0o + i1IIi . OOooOOo / ii11ii1ii
 try :
  if 22 - 22: iI - iI % IIII . Oooo0Ooo000 + oO0o0ooO0
  oOO = i11ii1ii11i ( ii1I1i11 )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( oOO )
  for O0O0Oo00 in ooO0OoOO :
   if 63 - 63: OOooOOo % Oooo0Ooo000 * o0000oOoOoO0o + Oooo0Ooo000 / ii11ii1ii % O0ooOooooO
   try :
    if 45 - 45: i1I111II1I
    OO0o0oO = O0O0Oo00
    if 20 - 20: OoooooooOO * o0000oOoOoO0o * O0 . IIII
   except :
    pass
    if 78 - 78: iIii1I11I1II1 + O0oO - o0oO0 * Oooo0Ooo000 - OoooooooOO % OoOO0ooOOoo0O
  IIIII1II = i11ii1ii11i ( OO0o0oO )
  ooO0OoOO = re . compile ( iIII1 ) . findall ( IIIII1II )
  for IiIi1II11i , iI1ii1i , oo00 , Oo0oooO0oO , Iii1iiIi1II in ooO0OoOO :
   try :
    if 34 - 34: O0
    II1II1iIIi11 ( iI1ii1i , Oo0oooO0oO , 143 , IiIi1II11i , oo00 , Iii1iiIi1II )
    if 80 - 80: i1IIi - ii11ii1ii / OoOO - i11iIiiIii
   except :
    pass
 except :
  pass
  if 68 - 68: oO0o0ooO0 - o00O0oo % O0 % Oooo0Ooo000
  if 11 - 11: O0 / OoOO % IIII + o0000oOoOoO0o + iIii1I11I1II1
def I1i1111I ( ) :
 if 95 - 95: iIii1I11I1II1 - o00O0oo . Oooo0Ooo000 - OOooOOo
 try :
  if 75 - 75: OoOO + o0000oOoOoO0o - i1IIi . OoooooooOO * o0oO0 / i1I111II1I
  oOO = i11ii1ii11i ( ooo00Ooo )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( oOO )
  for O0O0Oo00 in ooO0OoOO :
   if 86 - 86: OoOO0ooOOoo0O * II111iiii - O0 . OoOO0ooOOoo0O % iIii1I11I1II1 / IIII
   try :
    if 11 - 11: OOooOOo * oO0o0ooO0 + o00O0oo / o00O0oo
    OO0o0oO = O0O0Oo00
    if 37 - 37: i11iIiiIii + i1IIi
   except :
    pass
    if 23 - 23: O0ooOooooO + O0oO . OoOO0ooOOoo0O * OOooOOo + o00O0oo
  IIIII1II = i11ii1ii11i ( OO0o0oO )
  ooO0OoOO = re . compile ( iIII1 ) . findall ( IIIII1II )
  for IiIi1II11i , iI1ii1i , oo00 , Oo0oooO0oO , Iii1iiIi1II in ooO0OoOO :
   try :
    if 18 - 18: i1I111II1I * o0000oOoOoO0o . i1I111II1I / O0
    II1II1iIIi11 ( iI1ii1i , Oo0oooO0oO , 143 , IiIi1II11i , oo00 , Iii1iiIi1II )
    if 8 - 8: o0000oOoOoO0o
   except :
    pass
 except :
  pass
  if 4 - 4: o00O0oo + o00O0oo * iI - OoOO0ooOOoo0O
def o00o ( ) :
 if 47 - 47: o0000oOoOoO0o + O0ooOooooO - oO0o0ooO0 % OoooooooOO
 try :
  if 52 - 52: Oooo0Ooo000 / iI - O0oO
  oOO = i11ii1ii11i ( iI1i11 )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( oOO )
  for O0O0Oo00 in ooO0OoOO :
   if 49 - 49: OoOO0ooOOoo0O / ii11ii1ii . i11iIiiIii
   try :
    if 21 - 21: OoOO0ooOOoo0O + i11iIiiIii + OOooOOo * o0000oOoOoO0o % O0ooOooooO % II111iiii
    OO0o0oO = O0O0Oo00
    if 55 - 55: ii11ii1ii - IIII
   except :
    pass
    if 84 - 84: Oooo0Ooo000 + ii11ii1ii - OoOO0ooOOoo0O * OoOO0ooOOoo0O
  IIIII1II = i11ii1ii11i ( OO0o0oO )
  ooO0OoOO = re . compile ( iIII1 ) . findall ( IIIII1II )
  for IiIi1II11i , iI1ii1i , oo00 , Oo0oooO0oO , Iii1iiIi1II in ooO0OoOO :
   try :
    if 61 - 61: OoooooooOO . oO0o0ooO0 . OoooooooOO / ii11ii1ii
    II1II1iIIi11 ( iI1ii1i , Oo0oooO0oO , 143 , IiIi1II11i , oo00 , Iii1iiIi1II )
    if 72 - 72: i1IIi
   except :
    pass
 except :
  pass
  if 82 - 82: OoOO0ooOOoo0O + OoooooooOO / i11iIiiIii * o00O0oo . OoooooooOO
def oooo0OOo ( ) :
 if 72 - 72: O0 / iI + OoooooooOO * O0ooOooooO
 try :
  if 61 - 61: OoooooooOO % II111iiii - OOooOOo % o00O0oo + i1IIi
  oOO = i11ii1ii11i ( OOoOoOo )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( oOO )
  for O0O0Oo00 in ooO0OoOO :
   if 39 - 39: i1IIi
   try :
    if 86 - 86: iIii1I11I1II1 + OoOO0ooOOoo0O . i11iIiiIii - o0oO0
    OO0o0oO = O0O0Oo00
    if 51 - 51: OoOO0ooOOoo0O
   except :
    pass
    if 14 - 14: i1I111II1I % oO0o0ooO0 % ii11ii1ii - i11iIiiIii
  IIIII1II = i11ii1ii11i ( OO0o0oO )
  ooO0OoOO = re . compile ( iIII1 ) . findall ( IIIII1II )
  for IiIi1II11i , iI1ii1i , oo00 , Oo0oooO0oO , Iii1iiIi1II in ooO0OoOO :
   try :
    if 53 - 53: o0oO0 % ii11ii1ii
    II1II1iIIi11 ( iI1ii1i , Oo0oooO0oO , 143 , IiIi1II11i , oo00 , Iii1iiIi1II )
    if 59 - 59: IIII % iIii1I11I1II1 . i1IIi + II111iiii * i1I111II1I
   except :
    pass
 except :
  pass
  if 41 - 41: o0oO0 % o00O0oo
def i1iIiIi1I ( name , url ) :
 if 37 - 37: o0oO0 % OoOO
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 79 - 79: o00O0oo + OOooOOo / OOooOOo
 OO0O0ooOOO00 = i11ii1ii11i ( url )
 ooO0OoOO = re . compile ( O0OOoO00OO0o ) . findall ( OO0O0ooOOO00 )
 for IiIi1II11i , name , oo00 , url in ooO0OoOO :
  try :
   if 17 - 17: O0 . Oooo0Ooo000 . O0 + O0 / ii11ii1ii . iI
   if 62 - 62: o00O0oo % O0ooOooooO * OoOO - i1IIi
   I1I1IiI1 = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % I1I1IiI1 + name + '[/COLOR]'
   OoOOo ( name , url , 144 , IiIi1II11i , oo00 )
   if 17 - 17: i1IIi
   if 1 - 1: iI
  except :
   pass
   if 78 - 78: o00O0oo + O0oO - O0
   if 10 - 10: Oooo0Ooo000 % OOooOOo
   if 97 - 97: OoooooooOO - Oooo0Ooo000
def OoOOo ( name , url , mode , iconimage , fanart ) :
 if 58 - 58: iIii1I11I1II1 + O0
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 30 - 30: iI % O0ooOooooO * IIII - o00O0oo * o0oO0 % iI
 iiiiI11ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage="
 O0i1i1II1i11 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 O0i1i1II1i11 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 O0i1i1II1i11 . setProperty ( 'fanart_image' , fanart )
 O0i1i1II1i11 . setProperty ( 'IsPlayable' , 'true' )
 o00oiii11II1I = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiiiI11ii , listitem = O0i1i1II1i11 )
 return o00oiii11II1I
 if 5 - 5: OoOO0ooOOoo0O - i1I111II1I * i1I111II1I
 if 50 - 50: II111iiii * o00O0oo / o0oO0 . o0000oOoOoO0o + ii11ii1ii - IIII
def II1iiIiIiI ( name , url ) :
 if 24 - 24: ii11ii1ii - i1IIi + O0oO
 if 38 - 38: OoooooooOO / o00O0oo . O0 / i1IIi / ii11ii1ii + iIii1I11I1II1
 OOoOO0oo0ooO = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 ii1I = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 O0oO0 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 ooO00O00oOO = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 iIiii1iI1 = i11ii1ii11i ( O0oO0 )
 ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
 for I1IIII1ii in ooO0OoOO :
  if 13 - 13: OoooooooOO * oO0o0ooO0 - o0oO0 / IIII + O0oO + i1I111II1I
  try :
   if 39 - 39: iIii1I11I1II1 - OoooooooOO
   if 81 - 81: o00O0oo - O0 * OoooooooOO
   OOoOO0oo0ooO = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 23 - 23: II111iiii / oO0o0ooO0
   if 28 - 28: ii11ii1ii * iI - OoOO
   if OOoOO0oo0ooO == I1IIII1ii :
    if 19 - 19: O0oO
    if 67 - 67: O0 % iIii1I11I1II1 / i1I111II1I . i11iIiiIii - o0oO0 + O0
    if 'https://team.com' in url :
     if 27 - 27: IIII
     url = url . replace ( 'https://team.com' , 'https://verystream.com' )
     if 89 - 89: II111iiii / oO0o0ooO0
    if 'https://mybox.com' in url :
     if 14 - 14: IIII . OOooOOo * iI + II111iiii - iI + IIII
     url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
     if 18 - 18: oO0o0ooO0 - o0000oOoOoO0o - OOooOOo - OOooOOo
     if 54 - 54: ii11ii1ii + OOooOOo / O0ooOooooO . OOooOOo * OoOO0ooOOoo0O
    if 'https://vidcloud.co/' in url :
     if 1 - 1: OoOO0ooOOoo0O * OoOO . i1IIi / ii11ii1ii . o00O0oo + ii11ii1ii
     url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
     if 17 - 17: ii11ii1ii + OoOO / o0oO0 / O0ooOooooO * IIII
    if 'https://gounlimited.to' in url :
     if 29 - 29: OoOO % OoooooooOO * oO0o0ooO0 / II111iiii - oO0o0ooO0
     url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
     if 19 - 19: i11iIiiIii
    if 'https://drive.com' in url :
     if 54 - 54: II111iiii . O0oO
     url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
     if 73 - 73: OoOO0ooOOoo0O . OOooOOo
     if 32 - 32: OoOO0ooOOoo0O * OOooOOo % iI * o0oO0 . O0
    import resolveurl
    if 48 - 48: O0ooOooooO * O0ooOooooO
    I1I1 = urlresolver . HostedMediaFile ( url )
    if 4 - 4: o0000oOoOoO0o % OoOO0ooOOoo0O * IIII
    if not I1I1 :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
     return False
     if 32 - 32: i11iIiiIii - Oooo0Ooo000
    try :
     OO0oo = xbmcgui . DialogProgress ( )
     OO0oo . create ( 'Realstream:' , 'Iniciando ...' )
     OO0oo . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
     xbmc . sleep ( 1000 )
     oo00ooOoo = I1I1 . resolve ( )
     if not oo00ooOoo or not isinstance ( oo00ooOoo , basestring ) :
      try : iii1IIIiiiI = oo00ooOoo . msg
      except : iii1IIIiiiI = url
      raise Exception ( iii1IIIiiiI )
      if 94 - 94: O0 - O0oO - iIii1I11I1II1 % iI / o0oO0 % O0ooOooooO
    except Exception as OOo00OoO :
     try : iii1IIIiiiI = str ( OOo00OoO )
     except : iii1IIIiiiI = url
     OO0oo . update ( 45 , 'RESOLVEURL:' , 'Reiniciando ... ' )
     xbmc . sleep ( 1000 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Episodio no disponible.  ,3000)" )
     OO0oo . close ( )
     if 44 - 44: ii11ii1ii % iIii1I11I1II1
    OO0oo . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    OO0oo . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
    xbmc . sleep ( 500 )
    OO0oo . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
    xbmc . sleep ( 500 )
    OO0oo . update ( 100 , 'RESOLVEURL:' , 'Disfrute de este capitulo!' )
    OO0oo . close ( )
    O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'notificar' )
    oo0ooO0 = xbmcgui . ListItem ( path = oo00ooOoo )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0ooO0 )
    if 28 - 28: o00O0oo * OoooooooOO . II111iiii / i11iIiiIii + oO0o0ooO0
    if 38 - 38: i1I111II1I . o0oO0
   else :
    if 24 - 24: o0000oOoOoO0o - o0000oOoOoO0o + o00O0oo + OOooOOo - oO0o0ooO0
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold]>El addon esta desactivado.[/COLOR]" )
    if 12 - 12: O0ooOooooO . i1I111II1I . OoOO0ooOOoo0O / O0
    if 58 - 58: o0000oOoOoO0o - II111iiii % oO0o0ooO0 + Oooo0Ooo000 . OoOO0ooOOoo0O / i1I111II1I
  except :
   pass
   if 8 - 8: o00O0oo . OoOO * O0oO + II111iiii % i11iIiiIii
   if 8 - 8: iI * O0
   if 73 - 73: o0000oOoOoO0o / oO0o0ooO0 / O0oO / OoOO
   if 11 - 11: OoOO0ooOOoo0O + i1I111II1I - OoooooooOO / OoOO
   if 34 - 34: iI
   if 45 - 45: iI / ii11ii1ii / o0oO0
def IIi11i1II ( ) :
 if 73 - 73: o0000oOoOoO0o - OOooOOo * i1IIi / i11iIiiIii * IIII % II111iiii
 if 56 - 56: OoooooooOO * ii11ii1ii . ii11ii1ii . o00O0oo
 II1 = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 II1 . doModal ( )
 if not II1 . isConfirmed ( ) :
  return None ;
 iI1ii1i = II1 . getText ( ) . strip ( )
 if 74 - 74: OoooooooOO % IIII % Oooo0Ooo000 - OOooOOo - O0oO
 if 58 - 58: O0
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 78 - 78: OoOO % i1I111II1I * i1IIi
  O0iI = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + iI1ii1i + '&language=es-ES' ) )
  if 15 - 15: O0 / ii11ii1ii % o00O0oo + o0000oOoOoO0o
  if 23 - 23: iIii1I11I1II1 + O0
  return 'android'
  if 58 - 58: ii11ii1ii
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 9 - 9: iIii1I11I1II1 % o00O0oo . IIII + OoooooooOO
  O0iI = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + iI1ii1i + '&language=es-ES' )
  if 62 - 62: O0 / OOooOOo % O0 * OoOO % OOooOOo
  if 33 - 33: OOooOOo . oO0o0ooO0 * OoOO * iIii1I11I1II1
  return 'windows'
  if 5 - 5: ii11ii1ii / i1I111II1I % O0 . Oooo0Ooo000 * i1I111II1I
  if 83 - 83: IIII
def iiooO0o0oO ( ) :
 if 67 - 67: OoooooooOO
 try :
  if 29 - 29: O0 - i11iIiiIii - II111iiii + IIII * i1I111II1I
  iIiii1iI1 = i11ii1ii11i ( OOOoOoO )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 2 - 2: i1IIi - iI + OOooOOo . o0000oOoOoO0o * o0000oOoOoO0o / OoOO0ooOOoo0O
   try :
    if 93 - 93: i1IIi
    all = O0O0Oo00
    if 53 - 53: OoooooooOO + ii11ii1ii + oO0o0ooO0
   except :
    pass
    if 24 - 24: O0ooOooooO - i1I111II1I - O0ooOooooO * o00O0oo . OoooooooOO / i1I111II1I
  OO0O0ooOOO00 = i11ii1ii11i ( all )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( OO0O0ooOOO00 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    if 66 - 66: ii11ii1ii
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 97 - 97: i1IIi - OoooooooOO / Oooo0Ooo000 * OOooOOo
   except :
    pass
 except :
  pass
  if 55 - 55: o0000oOoOoO0o . O0ooOooooO
def oOo00o00oO ( ) :
 if 95 - 95: OOooOOo
 try :
  if 88 - 88: i1I111II1I % OoOO + Oooo0Ooo000 + Oooo0Ooo000 * II111iiii
  i1111 = i11ii1ii11i ( OOI1iI1ii1II )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( i1111 )
  for O0O0Oo00 in ooO0OoOO :
   if 78 - 78: OoooooooOO
   try :
    if 77 - 77: o00O0oo / i1IIi / ii11ii1ii % IIII
    OO0o0oO = O0O0Oo00
    if 48 - 48: O0oO - i1I111II1I + iIii1I11I1II1 + OoooooooOO
   except :
    pass
    if 4 - 4: II111iiii . O0oO + o0oO0 * Oooo0Ooo000 . iI
  IIIII1II = i11ii1ii11i ( OO0o0oO )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( IIIII1II )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    if 87 - 87: OoOO0ooOOoo0O / OoOO / i11iIiiIii
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 74 - 74: oO0o0ooO0 / o00O0oo % o0000oOoOoO0o
   except :
    pass
 except :
  pass
  if 88 - 88: OoOO0ooOOoo0O - i11iIiiIii % o0000oOoOoO0o * O0oO + o00O0oo
def OoiIIIiIi1I1i ( ) :
 if 78 - 78: iIii1I11I1II1 % OoOO0ooOOoo0O + o00O0oo / i1IIi % II111iiii + IIII
 try :
  if 91 - 91: iIii1I11I1II1 % OoOO . o0000oOoOoO0o + o0oO0 + o0000oOoOoO0o
  i11 = i11ii1ii11i ( oOooO0 )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( i11 )
  for O0O0Oo00 in ooO0OoOO :
   if 95 - 95: o0oO0 + o00O0oo * IIII
   try :
    I1Ii = O0O0Oo00
   except :
    pass
    if 77 - 77: iIii1I11I1II1 - i1IIi . oO0o0ooO0
  iIiii1iI1 = i11ii1ii11i ( I1Ii )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( iIiii1iI1 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    if 26 - 26: o0000oOoOoO0o * i1I111II1I . i1IIi
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 59 - 59: O0 + i1IIi - o0000oOoOoO0o
   except :
    pass
 except :
  pass
  if 62 - 62: i11iIiiIii % IIII . i1I111II1I . IIII
def ooOo0O0O0oOO0 ( ) :
 if 10 - 10: ii11ii1ii + O0
 try :
  if 43 - 43: iIii1I11I1II1 / II111iiii % o0000oOoOoO0o - IIII
  iIiii1iI1 = i11ii1ii11i ( db2 )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 62 - 62: O0oO
   try :
    if 63 - 63: IIII + iI * oO0o0ooO0 / o0000oOoOoO0o / ii11ii1ii * iIii1I11I1II1
    OOoO00ooO = O0O0Oo00
    if 12 - 12: iI % OOooOOo + oO0o0ooO0 - i1IIi . o0oO0 / OOooOOo
   except :
    pass
    if 51 - 51: IIII . OOooOOo
    if 73 - 73: OoooooooOO . OOooOOo / Oooo0Ooo000 % o0oO0
  iIiii1iI1 = i11ii1ii11i ( OOoO00ooO )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( iIiii1iI1 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 65 - 65: i1I111II1I - OOooOOo - o0oO0
   except :
    pass
 except :
  pass
  if 42 - 42: II111iiii * OOooOOo % i1IIi - o0oO0 % i1I111II1I
def Ii1I1 ( ) :
 if 58 - 58: i1I111II1I - O0oO % OOooOOo
 try :
  if 4 - 4: i1IIi + iI + i1IIi
  i11IiIIi11I = i11ii1ii11i ( IiIi1I1 )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( i11IiIIi11I )
  for O0O0Oo00 in ooO0OoOO :
   if 78 - 78: i1I111II1I
   try :
    if 83 - 83: iIii1I11I1II1 % OoOO0ooOOoo0O % o0000oOoOoO0o % Oooo0Ooo000 . o00O0oo % O0
    iIiIi1ii = O0O0Oo00
    if 28 - 28: iIii1I11I1II1 + iIii1I11I1II1
   except :
    pass
    if 28 - 28: oO0o0ooO0
    if 52 - 52: OOooOOo + iIii1I11I1II1
  iIiii1iI1 = i11ii1ii11i ( iIiIi1ii )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( iIiii1iI1 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    if 71 - 71: O0 / oO0o0ooO0
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 34 - 34: OoOO0ooOOoo0O . iIii1I11I1II1 % O0
   except :
    pass
 except :
  pass
  if 43 - 43: o00O0oo - O0ooOooooO
def O000O ( ) :
 if 98 - 98: iIii1I11I1II1 + Oooo0Ooo000 % OoOO0ooOOoo0O + O0oO % OoOO0ooOOoo0O
 try :
  if 24 - 24: oO0o0ooO0 * Oooo0Ooo000
  iIiii1iI1 = i11ii1ii11i ( OOoO0 )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 40 - 40: o0oO0 - OoOO0ooOOoo0O * OoOO0ooOOoo0O . OoOO0ooOOoo0O + OoooooooOO
   try :
    if 77 - 77: iIii1I11I1II1 . o0oO0 % oO0o0ooO0 / o0oO0
    oOO0OO = O0O0Oo00
    if 82 - 82: OoOO % o0000oOoOoO0o % IIII / O0
   except :
    pass
    if 94 - 94: o00O0oo + o00O0oo + OoooooooOO % iI
    if 7 - 7: O0ooOooooO
  iIiii1iI1 = i11ii1ii11i ( oOO0OO )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( iIiii1iI1 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 78 - 78: IIII + O0ooOooooO . i1I111II1I
   except :
    pass
 except :
  pass
  if 91 - 91: iIii1I11I1II1 . o0000oOoOoO0o . o00O0oo + OoooooooOO
def o0o0O0Oo ( ) :
 if 1 - 1: iIii1I11I1II1 + ii11ii1ii / O0 - O0ooOooooO % i1I111II1I + i1I111II1I
 try :
  if 24 - 24: OOooOOo + ii11ii1ii + IIII - OoooooooOO + ii11ii1ii
  iIiii1iI1 = i11ii1ii11i ( o00O0 )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 93 - 93: iI . iIii1I11I1II1 % i11iIiiIii . OoOO0ooOOoo0O % iI + O0
   try :
    if 65 - 65: o0oO0 + OoOO - OoooooooOO
    OOoOO0o = O0O0Oo00
    if 51 - 51: ii11ii1ii - o00O0oo * O0oO
   except :
    pass
    if 12 - 12: iIii1I11I1II1 % iI % iI
  iIiii1iI1 = i11ii1ii11i ( OOoOO0o )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( iIiii1iI1 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 78 - 78: i1I111II1I . OoOO0ooOOoo0O . O0oO
   except :
    pass
 except :
  pass
  if 97 - 97: oO0o0ooO0
def oOoO0O00oo ( ) :
 if 93 - 93: o00O0oo % OoOO0ooOOoo0O . O0 / O0ooOooooO * oO0o0ooO0
 try :
  if 29 - 29: o0000oOoOoO0o
  iIiii1iI1 = i11ii1ii11i ( ii1 )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 86 - 86: II111iiii . i1I111II1I
   try :
    if 2 - 2: OoooooooOO
    o0o0O00 = O0O0Oo00
    if 35 - 35: iIii1I11I1II1
   except :
    pass
    if 94 - 94: OoOO0ooOOoo0O
    if 100 - 100: OoOO / i1IIi - OOooOOo % o0oO0 - iIii1I11I1II1
  iIiii1iI1 = i11ii1ii11i ( o0o0O00 )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( iIiii1iI1 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 17 - 17: O0oO / o0000oOoOoO0o % ii11ii1ii
   except :
    pass
 except :
  pass
  if 71 - 71: i1I111II1I . Oooo0Ooo000 . OoOO
def Oo0O0O00Oo ( ) :
 if 10 - 10: o0oO0 + O0oO % OoooooooOO - OOooOOo
 try :
  if 70 - 70: IIII - O0ooOooooO
  iIiii1iI1 = i11ii1ii11i ( O0O0ooOOO )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 2 - 2: iIii1I11I1II1
   try :
    if 45 - 45: OoooooooOO / i11iIiiIii
    I11I1i1iI = O0O0Oo00
    if 90 - 90: i1I111II1I * II111iiii % Oooo0Ooo000 + oO0o0ooO0
   except :
    pass
    if 93 - 93: Oooo0Ooo000 + o0oO0
    if 33 - 33: O0
  iIiii1iI1 = i11ii1ii11i ( I11I1i1iI )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( iIiii1iI1 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 78 - 78: O0 / II111iiii * OoOO
   except :
    pass
 except :
  pass
  if 50 - 50: OoooooooOO - iIii1I11I1II1 + i1IIi % Oooo0Ooo000 - iIii1I11I1II1 % O0
def o0oO0Oo ( ) :
 if 71 - 71: o0000oOoOoO0o - OoOO0ooOOoo0O * O0ooOooooO + o0oO0 % i11iIiiIii - iI
 try :
  if 82 - 82: Oooo0Ooo000 - IIII + OoOO
  iIiii1iI1 = i11ii1ii11i ( iIiIi11 )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 64 - 64: o0000oOoOoO0o . O0 * o0oO0 + OoooooooOO - ii11ii1ii . OoooooooOO
   try :
    if 70 - 70: ii11ii1ii - oO0o0ooO0 . iIii1I11I1II1 % O0oO / OoOO0ooOOoo0O - O0
    o0O0oo0o = O0O0Oo00
    if 12 - 12: OoOO0ooOOoo0O % i1I111II1I % o00O0oo . i11iIiiIii * iIii1I11I1II1
   except :
    pass
    if 66 - 66: i11iIiiIii * iIii1I11I1II1 % OoooooooOO
    if 5 - 5: OoOO0ooOOoo0O % OoooooooOO
  iIiii1iI1 = i11ii1ii11i ( o0O0oo0o )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( iIiii1iI1 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 60 - 60: OoOO0ooOOoo0O . i1IIi % OoOO % iI % IIII
   except :
    pass
 except :
  pass
  if 33 - 33: iIii1I11I1II1 - o0oO0 * o00O0oo % iIii1I11I1II1 + OoOO . IIII
def ooo0O0oOoooO0 ( ) :
 if 42 - 42: IIII % oO0o0ooO0 / OoOO - oO0o0ooO0 * i11iIiiIii
 try :
  if 19 - 19: oO0o0ooO0 * OOooOOo % i11iIiiIii
  iIiii1iI1 = i11ii1ii11i ( IIIIiii1IIii )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 24 - 24: o0000oOoOoO0o
   try :
    if 10 - 10: o0000oOoOoO0o % o0oO0 / IIII
    i11Ii1iIiII = O0O0Oo00
    if 81 - 81: O0oO . OoooooooOO * OoOO0ooOOoo0O % i1I111II1I . O0oO
   except :
    pass
    if 60 - 60: IIII / OOooOOo
    if 78 - 78: O0oO . i1I111II1I
  iIiii1iI1 = i11ii1ii11i ( i11Ii1iIiII )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( iIiii1iI1 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 38 - 38: OoOO0ooOOoo0O + i1I111II1I
   except :
    pass
 except :
  pass
  if 15 - 15: ii11ii1ii + O0oO . iI - iIii1I11I1II1 / O0 % iIii1I11I1II1
  if 86 - 86: OOooOOo / oO0o0ooO0 * o0oO0
def O00o ( ) :
 if 86 - 86: o00O0oo * II111iiii * O0oO
 try :
  if 74 - 74: o00O0oo / i1I111II1I
  iIiii1iI1 = i11ii1ii11i ( oooOo0OOOoo0 )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 60 - 60: o00O0oo
   try :
    if 1 - 1: OoOO0ooOOoo0O . i11iIiiIii % OoOO0ooOOoo0O - O0ooOooooO % i1IIi + o00O0oo
    IiiIiIi111iI1 = O0O0Oo00
    if 88 - 88: ii11ii1ii % oO0o0ooO0 + i1I111II1I
   except :
    pass
    if 8 - 8: i11iIiiIii / II111iiii + o0000oOoOoO0o * o0oO0 % i1I111II1I . O0oO
    if 6 - 6: i1I111II1I % ii11ii1ii . ii11ii1ii - o00O0oo / O0oO . i1IIi
  iIiii1iI1 = i11ii1ii11i ( IiiIiIi111iI1 )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( iIiii1iI1 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 99 - 99: OoOO0ooOOoo0O . Oooo0Ooo000
   except :
    pass
 except :
  pass
  if 59 - 59: O0oO / ii11ii1ii / IIII / O0 / OoOO0ooOOoo0O + o0000oOoOoO0o
  if 13 - 13: o0000oOoOoO0o % oO0o0ooO0 / Oooo0Ooo000 % Oooo0Ooo000 % O0
def o0Ii1 ( ) :
 if 50 - 50: oO0o0ooO0 - iI / iIii1I11I1II1 - OoOO + II111iiii - O0
 try :
  if 88 - 88: oO0o0ooO0 * OoOO
  iIiii1iI1 = i11ii1ii11i ( OO0O000 )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 35 - 35: o00O0oo / O0ooOooooO % OOooOOo + iIii1I11I1II1
   try :
    if 79 - 79: OoOO0ooOOoo0O / iI
    oOo00o = O0O0Oo00
    if 98 - 98: IIII % i1IIi . OOooOOo . II111iiii . o00O0oo / i11iIiiIii
   except :
    pass
    if 32 - 32: o0000oOoOoO0o + OOooOOo . Oooo0Ooo000
    if 41 - 41: OoOO0ooOOoo0O . i11iIiiIii / O0oO
  iIiii1iI1 = i11ii1ii11i ( oOo00o )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( iIiii1iI1 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 98 - 98: OoOO0ooOOoo0O % II111iiii
   except :
    pass
    if 95 - 95: iIii1I11I1II1 - Oooo0Ooo000 - IIII + Oooo0Ooo000 % o00O0oo . OOooOOo
 except :
  pass
  if 41 - 41: O0 + oO0o0ooO0 . i1IIi - II111iiii * o0000oOoOoO0o . OoOO
  if 68 - 68: o0000oOoOoO0o
def i11Ii1IIi ( ) :
 if 36 - 36: O0 * OoOO % O0ooOooooO * O0ooOooooO / OoOO * i1I111II1I
 try :
  if 14 - 14: i1IIi . i1I111II1I + O0 * iI
  iIiii1iI1 = i11ii1ii11i ( oO0O00oOOoooO )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 76 - 76: OoOO
   try :
    if 92 - 92: O0oO - iIii1I11I1II1 % OoooooooOO
    I1oOooo00O = O0O0Oo00
    if 66 - 66: OoOO0ooOOoo0O + i1IIi % II111iiii . O0 * o00O0oo % o00O0oo
   except :
    pass
    if 87 - 87: IIII + o0000oOoOoO0o . O0ooOooooO - OoooooooOO
    if 6 - 6: iIii1I11I1II1 * OoooooooOO
  iIiii1iI1 = i11ii1ii11i ( I1oOooo00O )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( iIiii1iI1 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 28 - 28: ii11ii1ii * o0000oOoOoO0o / Oooo0Ooo000
   except :
    pass
    if 52 - 52: O0 / o0000oOoOoO0o % O0ooOooooO * OOooOOo % IIII
 except :
  pass
  if 69 - 69: o00O0oo
def oOOO0ooo ( ) :
 if 19 - 19: O0ooOooooO - o0000oOoOoO0o - o0oO0 - OoOO0ooOOoo0O . O0ooOooooO . Oooo0Ooo000
 try :
  if 48 - 48: O0ooOooooO + i1I111II1I
  iIiii1iI1 = i11ii1ii11i ( Oo0O00O000 )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 60 - 60: O0oO + O0ooOooooO . i1I111II1I / i1IIi . iIii1I11I1II1
   try :
    if 14 - 14: IIII
    o0oo0Ooooo0 = O0O0Oo00
    if 76 - 76: i1IIi * OoooooooOO * O0 + Oooo0Ooo000 * Oooo0Ooo000
   except :
    pass
    if 35 - 35: o0000oOoOoO0o
  iIiii1iI1 = i11ii1ii11i ( o0oo0Ooooo0 )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( iIiii1iI1 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 73 - 73: O0 - o00O0oo
   except :
    pass
 except :
  pass
  if 2 - 2: II111iiii / Oooo0Ooo000
  if 54 - 54: i1IIi . O0oO - o00O0oo + iI + ii11ii1ii / ii11ii1ii
def i1ii1IiiiiIi1I ( ) :
 if 56 - 56: OoooooooOO * O0
 try :
  if 85 - 85: OoooooooOO % OoOO0ooOOoo0O * iIii1I11I1II1
  iIiii1iI1 = i11ii1ii11i ( oo )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 44 - 44: iIii1I11I1II1 . o00O0oo + Oooo0Ooo000 . iI
   try :
    if 7 - 7: o00O0oo + iIii1I11I1II1 * O0oO * O0oO / II111iiii - o0oO0
    oOOOo0o = O0O0Oo00
    if 26 - 26: iIii1I11I1II1 - O0 . O0
   except :
    pass
    if 68 - 68: IIII + oO0o0ooO0 . O0 . o0oO0 % i1IIi % IIII
    if 50 - 50: i1I111II1I + o0000oOoOoO0o
  iIiii1iI1 = i11ii1ii11i ( oOOOo0o )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( iIiii1iI1 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 96 - 96: OoOO
   except :
    pass
 except :
  pass
  if 92 - 92: ii11ii1ii / i11iIiiIii + o00O0oo
  if 87 - 87: OoOO0ooOOoo0O % iIii1I11I1II1
def o0OO0OOO0O ( ) :
 if 36 - 36: i11iIiiIii / O0ooOooooO . O0oO + i1I111II1I . O0 + OOooOOo
 try :
  if 36 - 36: i1IIi - o00O0oo - Oooo0Ooo000
  iIiii1iI1 = i11ii1ii11i ( iIIii )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 7 - 7: i11iIiiIii + OOooOOo
   try :
    if 47 - 47: Oooo0Ooo000 - IIII / iI - ii11ii1ii + O0ooOooooO - iIii1I11I1II1
    o0OOOOO0 = O0O0Oo00
    if 79 - 79: II111iiii - iI . i1IIi + O0 % O0 * OOooOOo
   except :
    pass
  iIiii1iI1 = i11ii1ii11i ( o0OOOOO0 )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( iIiii1iI1 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 7 - 7: i1IIi + IIII % O0ooOooooO / o0000oOoOoO0o + i1IIi
   except :
    pass
 except :
  pass
  if 41 - 41: o0oO0 + i11iIiiIii / i1I111II1I % o00O0oo
def II1II1IIII ( ) :
 if 37 - 37: OoooooooOO
 try :
  if 69 - 69: OOooOOo + O0ooOooooO
  iIiii1iI1 = i11ii1ii11i ( ii1iii1i )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 7 - 7: O0ooOooooO + oO0o0ooO0
   try :
    if 26 - 26: iIii1I11I1II1 + i1IIi / OoOO0ooOOoo0O % o00O0oo
    Ii = O0O0Oo00
    if 14 - 14: IIII % OoooooooOO
   except :
    pass
    if 86 - 86: i11iIiiIii + O0 * i1I111II1I - OoOO * IIII + O0
    if 95 - 95: iIii1I11I1II1 . Oooo0Ooo000 % O0ooOooooO - Oooo0Ooo000 * II111iiii
  iIiii1iI1 = i11ii1ii11i ( Ii )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( iIiii1iI1 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 89 - 89: O0ooOooooO . OOooOOo
   except :
    pass
 except :
  pass
  if 59 - 59: i1IIi % iIii1I11I1II1 + OoooooooOO
  if 97 - 97: o00O0oo / ii11ii1ii + Oooo0Ooo000
def i111I11i1I ( ) :
 if 85 - 85: IIII * i1IIi % OOooOOo - iI
 try :
  if 37 - 37: i1I111II1I . ii11ii1ii * ii11ii1ii * II111iiii * O0
  iIiii1iI1 = i11ii1ii11i ( ooOoO00 )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 83 - 83: i1I111II1I / Oooo0Ooo000
   try :
    if 64 - 64: OoOO % i1I111II1I . Oooo0Ooo000 % OoOO + O0oO * i1I111II1I
    OOOO00OooO = O0O0Oo00
    if 64 - 64: OoOO . OOooOOo - OoooooooOO . iI - O0ooOooooO
   except :
    pass
    if 77 - 77: o0oO0 % OoOO0ooOOoo0O / II111iiii % O0ooOooooO % OoooooooOO % OoOO
    if 19 - 19: i1I111II1I * Oooo0Ooo000 / oO0o0ooO0 * Oooo0Ooo000 - OoooooooOO * O0oO
  iIiii1iI1 = i11ii1ii11i ( OOOO00OooO )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( iIiii1iI1 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 17 - 17: II111iiii + ii11ii1ii . Oooo0Ooo000
   except :
    pass
 except :
  pass
  if 12 - 12: Oooo0Ooo000 + IIII + O0oO . i1I111II1I / o0oO0
def i1I ( ) :
 if 100 - 100: OoOO % OoOO
 try :
  if 15 - 15: oO0o0ooO0 / Oooo0Ooo000
  iIiii1iI1 = i11ii1ii11i ( o0O00Oo0 )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 37 - 37: i11iIiiIii + OOooOOo . IIII % O0oO % O0oO
   try :
    if 26 - 26: O0
    i111I1iiIiII = O0O0Oo00
    if 97 - 97: II111iiii - Oooo0Ooo000 - iIii1I11I1II1 * OOooOOo
   except :
    pass
    if 54 - 54: iIii1I11I1II1
    if 5 - 5: i1I111II1I
  iIiii1iI1 = i11ii1ii11i ( i111I1iiIiII )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( iIiii1iI1 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 84 - 84: II111iiii * oO0o0ooO0 * II111iiii % i1I111II1I / OOooOOo
   except :
    pass
 except :
  pass
  if 100 - 100: i1I111II1I . o0oO0 - iIii1I11I1II1 . i11iIiiIii / II111iiii
  if 71 - 71: Oooo0Ooo000 * ii11ii1ii . O0oO
def i1ii1iiIi1II ( ) :
 if 98 - 98: OoOO - o0oO0 . i1I111II1I % i11iIiiIii
 try :
  if 69 - 69: o00O0oo + O0ooOooooO * O0 . IIII % OoOO0ooOOoo0O
  iIiii1iI1 = i11ii1ii11i ( i111iIi1i1II1 )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 96 - 96: iI . iI - O0oO / O0oO
   try :
    if 96 - 96: i11iIiiIii / OOooOOo - O0 . iI
    i11i = O0O0Oo00
    if 86 - 86: o0oO0
   except :
    pass
    if 29 - 29: iIii1I11I1II1 - OoOO + OOooOOo % iIii1I11I1II1 % IIII
    if 84 - 84: i1I111II1I + o00O0oo + o0oO0 + O0ooOooooO
  iIiii1iI1 = i11ii1ii11i ( i11i )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( iIiii1iI1 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 62 - 62: i11iIiiIii + OoOO0ooOOoo0O + i1IIi
   except :
    pass
 except :
  pass
  if 69 - 69: OoOO0ooOOoo0O
  if 63 - 63: OoOO / OoOO0ooOOoo0O * iIii1I11I1II1 . Oooo0Ooo000
def Ooooo ( ) :
 if 43 - 43: IIII
 try :
  if 57 - 57: O0 / o0000oOoOoO0o
  iIiii1iI1 = i11ii1ii11i ( i1I1i111Ii )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 12 - 12: OoooooooOO / O0 + II111iiii * o00O0oo
   try :
    if 46 - 46: II111iiii - i1I111II1I * OoooooooOO / oO0o0ooO0 % i1I111II1I
    Iii11III1I11 = O0O0Oo00
    if 40 - 40: i11iIiiIii . iIii1I11I1II1
   except :
    pass
    if 2 - 2: i1IIi * oO0o0ooO0 - oO0o0ooO0 + OoooooooOO % OoOO0ooOOoo0O / OoOO0ooOOoo0O
    if 3 - 3: OoooooooOO
  iIiii1iI1 = i11ii1ii11i ( Iii11III1I11 )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( iIiii1iI1 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 71 - 71: i1I111II1I + i1IIi - O0ooOooooO - i11iIiiIii . O0oO - iI
   except :
    pass
 except :
  pass
  if 85 - 85: o00O0oo - OoOO0ooOOoo0O / o00O0oo + IIII - O0ooOooooO
  if 49 - 49: OoOO - O0 / OoOO * OoOO0ooOOoo0O + Oooo0Ooo000
def Iiii1I ( ) :
 if 61 - 61: iIii1I11I1II1 - O0oO / O0ooOooooO * O0oO % o0oO0 % O0ooOooooO
 try :
  if 63 - 63: IIII % iIii1I11I1II1
  iIiii1iI1 = i11ii1ii11i ( i1i1iI1iiiI )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 20 - 20: OoOO . OOooOOo * i11iIiiIii / i11iIiiIii
   try :
    if 89 - 89: O0ooOooooO . i11iIiiIii * O0
    Iii = O0O0Oo00
    if 35 - 35: i1I111II1I . OoooooooOO / IIII
   except :
    pass
    if 52 - 52: Oooo0Ooo000 % OoOO0ooOOoo0O + iIii1I11I1II1 * oO0o0ooO0 . o0oO0
    if 95 - 95: iIii1I11I1II1 . i1I111II1I - OoooooooOO * OoOO / o0000oOoOoO0o
  iIiii1iI1 = i11ii1ii11i ( Iii )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( iIiii1iI1 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 74 - 74: oO0o0ooO0
   except :
    pass
 except :
  pass
  if 34 - 34: O0ooOooooO
  if 44 - 44: i1IIi % OOooOOo % o0000oOoOoO0o
def iIIi1Ii1III ( ) :
 if 86 - 86: i11iIiiIii + i11iIiiIii . Oooo0Ooo000 % OOooOOo . iI
 try :
  if 17 - 17: o0oO0
  iIiii1iI1 = i11ii1ii11i ( oOOOoo00 )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 67 - 67: O0 * O0oO - o0000oOoOoO0o - II111iiii
   try :
    if 41 - 41: OOooOOo - Oooo0Ooo000 % II111iiii . Oooo0Ooo000 - O0oO
    i1I111Ii = O0O0Oo00
    if 31 - 31: OOooOOo
   except :
    pass
    if 73 - 73: iI . O0 / o0000oOoOoO0o - OoooooooOO % i11iIiiIii
  iIiii1iI1 = i11ii1ii11i ( i1I111Ii )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( iIiii1iI1 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 80 - 80: o0oO0 / iI % O0 . ii11ii1ii
   except :
    pass
 except :
  pass
  if 63 - 63: IIII . II111iiii . O0oO
  if 46 - 46: iI % i1I111II1I - o0000oOoOoO0o - ii11ii1ii - o0oO0 / O0oO
def OooO0Oo0 ( ) :
 if 83 - 83: O0
 try :
  if 89 - 89: ii11ii1ii + o00O0oo - o0000oOoOoO0o
  iIiii1iI1 = i11ii1ii11i ( iiI1IIIi )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 40 - 40: OoOO + OoOO
   try :
    if 94 - 94: O0ooOooooO * iIii1I11I1II1 . O0oO
    IiiI11I1IIiI = O0O0Oo00
    if 5 - 5: ii11ii1ii
   except :
    pass
    if 100 - 100: o0oO0 + iIii1I11I1II1
    if 59 - 59: i1I111II1I
  iIiii1iI1 = i11ii1ii11i ( IiiI11I1IIiI )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( iIiii1iI1 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 89 - 89: OoOO0ooOOoo0O % iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 35 - 35: o00O0oo + Oooo0Ooo000 - OoOO0ooOOoo0O % oO0o0ooO0 % o0000oOoOoO0o % OoOO0ooOOoo0O
def ii1IIiII111I ( ) :
 if 87 - 87: o0oO0 - o00O0oo % o00O0oo . oO0o0ooO0 / o00O0oo
 try :
  if 6 - 6: OoOO0ooOOoo0O / iIii1I11I1II1 * OoooooooOO * i11iIiiIii
  iIiii1iI1 = i11ii1ii11i ( IIOOO0O00O0OOOO )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 79 - 79: i1I111II1I % OoOO
   try :
    if 81 - 81: i11iIiiIii + i11iIiiIii * OoOO + i1I111II1I
    iii = O0O0Oo00
    if 15 - 15: OOooOOo . OoOO
   except :
    pass
  iIiii1iI1 = i11ii1ii11i ( iii )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( iIiii1iI1 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 17 - 17: i11iIiiIii / ii11ii1ii . OoOO / OOooOOo
   except :
    pass
 except :
  pass
  if 38 - 38: i1IIi . o00O0oo % o0oO0 + iIii1I11I1II1 + O0
def iIi1i11 ( ) :
 if 25 - 25: OOooOOo % O0 + i1IIi - iI
 try :
  if 38 - 38: o0000oOoOoO0o % Oooo0Ooo000 + i11iIiiIii + O0ooOooooO + iI / i11iIiiIii
  iIiii1iI1 = i11ii1ii11i ( OOo0 )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 94 - 94: O0ooOooooO - ii11ii1ii + oO0o0ooO0
   try :
    if 59 - 59: O0oO . OOooOOo - iIii1I11I1II1 + iIii1I11I1II1
    oO0o0Oo = O0O0Oo00
    if 76 - 76: iI / OoOO0ooOOoo0O + o00O0oo
   except :
    pass
  iIiii1iI1 = i11ii1ii11i ( oO0o0Oo )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( iIiii1iI1 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 2 - 2: i11iIiiIii - Oooo0Ooo000 + OoOO % O0oO * o0oO0
   except :
    pass
 except :
  pass
  if 54 - 54: O0 - O0ooOooooO . IIII % O0ooOooooO + O0ooOooooO
def i1iI1Iiii1I ( ) :
 if 9 - 9: O0oO / OoOO0ooOOoo0O / II111iiii + Oooo0Ooo000
 try :
  if 71 - 71: O0ooOooooO / ii11ii1ii
  iIiii1iI1 = i11ii1ii11i ( OooOo0oo0O0o00O )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 87 - 87: o00O0oo + o00O0oo - o00O0oo % O0
   try :
    if 13 - 13: II111iiii
    o0o000Oo = O0O0Oo00
    if 57 - 57: oO0o0ooO0 * O0 * Oooo0Ooo000
   except :
    pass
  iIiii1iI1 = i11ii1ii11i ( o0o000Oo )
  ooO0OoOO = re . compile ( oooo0O0 ) . findall ( iIiii1iI1 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO , id , IiIiII1 , Iii1iiIi1II , oo00 in ooO0OoOO :
   try :
    ii1II ( iI1ii1i , Oo0oooO0oO , iI1IiI , id , IiIiII1 , Iii1iiIi1II , oo00 )
    if 44 - 44: IIII / ii11ii1ii + i1I111II1I % II111iiii / OoOO + i11iIiiIii
   except :
    pass
 except :
  pass
  if 20 - 20: o00O0oo
def IIiiiiIiI1III ( ) :
 if 26 - 26: i1IIi
 try :
  if 35 - 35: OOooOOo
  iIiii1iI1 = i11ii1ii11i ( oo0o )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for O0O0Oo00 in ooO0OoOO :
   if 80 - 80: oO0o0ooO0 % oO0o0ooO0 % O0 - i11iIiiIii . O0ooOooooO / O0
   try :
    if 13 - 13: OOooOOo + O0 - o00O0oo % ii11ii1ii / o0oO0 . i1IIi
    OOOO00OoooO = O0O0Oo00
    if 7 - 7: o00O0oo / II111iiii - O0oO + i1IIi + o0oO0
   except :
    pass
  iIiii1iI1 = i11ii1ii11i ( OOOO00OoooO )
  ooO0OoOO = re . compile ( Iiii1i1 ) . findall ( iIiii1iI1 )
  for iI1IiI , iI1ii1i , Oo0oooO0oO in ooO0OoOO :
   try :
    i11i11i ( iI1IiI , iI1ii1i , Oo0oooO0oO )
    if 31 - 31: i11iIiiIii + IIII - O0
   except :
    pass
    if 51 - 51: OoOO * i1IIi / o0oO0 * IIII + iI % o00O0oo
 except :
  pass
  if 34 - 34: oO0o0ooO0 * OoooooooOO + o0oO0 + i11iIiiIii
  if 22 - 22: i1IIi
  if 24 - 24: O0oO / OOooOOo * i1IIi % OoooooooOO
def i11i11i ( thumb , name , url ) :
 if 99 - 99: i11iIiiIii . II111iiii . OoooooooOO
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( I1 ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   ooO ( name , url , '' , o00 , oo00 )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 59 - 59: i11iIiiIii . OoooooooOO / O0oO * o00O0oo + OoooooooOO
  if 'tvg-logo' in thumb :
   thumb = re . compile ( I1 ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 3 - 3: i11iIiiIii * ii11ii1ii % iIii1I11I1II1 % OOooOOo * O0ooOooooO / IIII
   O00oo00oOOO0o ( name , url , 4 , IiIi1II11i , oo00 )
   if 5 - 5: o0000oOoOoO0o / OOooOOo % o0oO0 . i1I111II1I
  else :
   if 86 - 86: i1IIi * OoOO0ooOOoo0O . O0 - o0oO0 - o0000oOoOoO0o - OoOO0ooOOoo0O
   O00oo00oOOO0o ( name , url , 4 , IiIi1II11i , oo00 )
   if 47 - 47: IIII + O0oO
def i1Iiii ( name , url , thumb , id , trailer ) :
 if 87 - 87: i1I111II1I / Oooo0Ooo000 - ii11ii1ii
 if 56 - 56: O0
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 45 - 45: OoOO0ooOOoo0O - OoOO - OoOO0ooOOoo0O
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( I1 ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   ooO ( name , url , '' , o00 , oo00 )
 else :
  I1I1IiI1 = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
  if 41 - 41: ii11ii1ii / i1IIi / ii11ii1ii - O0ooOooooO . o0000oOoOoO0o
  name = '[COLOR %s]' % I1I1IiI1 + name + '[/COLOR]'
  if 65 - 65: O0 * i11iIiiIii . OoooooooOO / OOooOOo / O0ooOooooO
  if 'tvg-logo' in thumb :
   thumb = re . compile ( I1 ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   i1i = IiII1IiiIiI1 . getSetting ( 'selecton' )
   if i1i == 'true' :
    if 69 - 69: iI % iI
    Ooo00OOOOOO0 ( name , url , 1 , thumb , thumb , id , trailer )
    if 15 - 15: O0oO / o0000oOoOoO0o + o0oO0
   else :
    if 76 - 76: o0oO0 + OoooooooOO / IIII % OoOO / o00O0oo
    Ooo00OOOOOO0 ( name , url , 130 , thumb , thumb , id , trailer )
    if 38 - 38: Oooo0Ooo000 . O0ooOooooO . OOooOOo * OoOO
  else :
   if 69 - 69: o0000oOoOoO0o % i11iIiiIii / o0oO0
   if i1i == 'true' :
    if 93 - 93: iI
    Ooo00OOOOOO0 ( name , url , 1 , thumb , thumb , id , trailer )
    if 34 - 34: oO0o0ooO0 - iI * ii11ii1ii / o0000oOoOoO0o
   else :
    if 19 - 19: o00O0oo
    Ooo00OOOOOO0 ( name , url , 130 , thumb , thumb , id , trailer )
    if 46 - 46: iIii1I11I1II1 . i11iIiiIii - OoOO0ooOOoo0O % O0 / II111iiii * i1IIi
    if 66 - 66: O0
def ii1II ( name , url , thumb , id , trailer , description , fanart ) :
 if 52 - 52: OoOO * OoooooooOO
 if 12 - 12: O0 + i1I111II1I * i1IIi . OoOO
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 I1I1IiI1 = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
 fanart = fanart . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 name = '[COLOR %s]' % I1I1IiI1 + name + '[/COLOR]'
 if 71 - 71: Oooo0Ooo000 - o0000oOoOoO0o - IIII
 if 'tvg-logo' in thumb :
  thumb = re . compile ( I1 ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  i1i = IiII1IiiIiI1 . getSetting ( 'selecton' )
  if i1i == 'true' :
   if 28 - 28: iIii1I11I1II1
   iI11II1i1I1 ( name , url , 1 , thumb , fanart , id , trailer , description )
   if 72 - 72: O0ooOooooO - OoooooooOO
  else :
   if 25 - 25: OoOO0ooOOoo0O % OoooooooOO * ii11ii1ii - i1IIi * II111iiii * oO0o0ooO0
   iI11II1i1I1 ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 30 - 30: O0oO % OoOO0ooOOoo0O / o00O0oo * O0 * o0oO0 . OOooOOo
 else :
  if 46 - 46: OoOO0ooOOoo0O - O0
  if i1i == 'true' :
   if 70 - 70: O0oO + ii11ii1ii * iIii1I11I1II1 . OOooOOo * O0oO
   iI11II1i1I1 ( name , url , 1 , thumb , fanart , id , trailer , description )
   if 49 - 49: o0000oOoOoO0o
  else :
   if 25 - 25: O0ooOooooO . OoooooooOO * iIii1I11I1II1 . o0000oOoOoO0o / O0 + o0oO0
   iI11II1i1I1 ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 68 - 68: ii11ii1ii
def ii111I11Ii ( name , trailer ) :
 if 6 - 6: o0oO0
 if O0o0O00Oo0o0 == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Realstream, Reproduciendo Trailer de: [COLOR green]" + name + "[/COLOR] ,5000)" )
  if 77 - 77: i1IIi + OoOO . OOooOOo * IIII / i1I111II1I / o0oO0
  Oo0oooO0oO = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  oOoo = Oo0oooO0oO
  oO0o = xbmcgui . ListItem ( name , trailer , path = oOoo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO0o )
 else :
  Oo0oooO0oO = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  oOoo = Oo0oooO0oO
  oO0o = xbmcgui . ListItem ( name , trailer , path = oOoo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO0o )
  if 22 - 22: OoOO / ii11ii1ii / OoOO0ooOOoo0O
  if 7 - 7: ii11ii1ii - i1IIi . o00O0oo / iIii1I11I1II1 * o0000oOoOoO0o
def O0O0 ( trailer ) :
 if 70 - 70: IIII * oO0o0ooO0 / OOooOOo * OoOO0ooOOoo0O * OOooOOo
 if 'https://www.youtube.com' in trailer :
  if 61 - 61: oO0o0ooO0 + o00O0oo / i1IIi * oO0o0ooO0
  try :
   if 90 - 90: o0oO0 % oO0o0ooO0
   import resolveurl
   if 6 - 6: OoooooooOO / i11iIiiIii / Oooo0Ooo000
   I1I1 = urlresolver . HostedMediaFile ( Oo0oooO0oO )
   OO0oo = xbmcgui . DialogProgress ( )
   OO0oo . create ( 'Realstream:' , 'Conectando al servidor ... ' )
   OO0oo . update ( 20 , 'Por favor, espere ...' )
   xbmc . sleep ( 500 )
   if 60 - 60: OOooOOo % oO0o0ooO0 / o0000oOoOoO0o % oO0o0ooO0 * i11iIiiIii / O0ooOooooO
   if not I1I1 :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    return False
    if 34 - 34: Oooo0Ooo000 - IIII
   try :
    if 25 - 25: oO0o0ooO0 % OOooOOo + i11iIiiIii + O0 * OoooooooOO
    OO0oo . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    oo00ooOoo = I1I1 . resolve ( )
    if not oo00ooOoo or not isinstance ( oo00ooOoo , basestring ) :
     try : iii1IIIiiiI = oo00ooOoo . msg
     except : iii1IIIiiiI = oo00ooOoo
     raise Exception ( iii1IIIiiiI )
   except Exception as OOo00OoO :
    try : iii1IIIiiiI = str ( OOo00OoO )
    except : iii1IIIiiiI = oo00ooOoo
    OO0oo . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
    OO0oo . close ( )
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    if 64 - 64: i1IIi
   OO0oo . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
   xbmc . sleep ( 500 )
   OO0oo . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   OO0oo . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
   xbmc . sleep ( 500 )
   OO0oo . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   OO0oo . close ( )
   if 10 - 10: Oooo0Ooo000 % O0 / OOooOOo % O0oO
   oo0ooO0 = xbmcgui . ListItem ( path = oo00ooOoo )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0ooO0 )
   if 25 - 25: II111iiii / OoOO
  except :
   pass
   if 64 - 64: O0 % iI
  else :
   if 40 - 40: o0000oOoOoO0o + O0oO
   Oo0oooO0oO = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
   oOoo = Oo0oooO0oO
   oO0o = xbmcgui . ListItem ( trailer , path = oOoo )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO0o )
   return
   if 77 - 77: i11iIiiIii % i1I111II1I + Oooo0Ooo000 % OoooooooOO - O0oO
def iIIiiIi ( name , url ) :
 if 19 - 19: o0000oOoOoO0o
 if '[Youtube]' in name :
  if 73 - 73: Oooo0Ooo000 * ii11ii1ii * OoOO0ooOOoo0O
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  oOoo = url
  oO0o = xbmcgui . ListItem ( IiIiII1 , path = oOoo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO0o )
  if 65 - 65: i11iIiiIii + ii11ii1ii * OoooooooOO - OoOO
  if 26 - 26: o0000oOoOoO0o % IIII + IIII % O0oO * i11iIiiIii / O0ooOooooO
 else :
  if 64 - 64: oO0o0ooO0 % OoOO0ooOOoo0O / II111iiii % iI - O0ooOooooO
  import urlresolver
  from urlresolver import common
  if 2 - 2: Oooo0Ooo000 - o00O0oo + o0000oOoOoO0o * OoOO / O0ooOooooO
  I1I1 = urlresolver . HostedMediaFile ( url )
  if 26 - 26: IIII * ii11ii1ii
  if not I1I1 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 31 - 31: O0oO * oO0o0ooO0 . o0oO0
   if 35 - 35: O0oO
  try :
   oo00ooOoo = I1I1 . resolve ( )
   if not oo00ooOoo or not isinstance ( oo00ooOoo , basestring ) :
    try : iii1IIIiiiI = oo00ooOoo . msg
    except : iii1IIIiiiI = url
    raise Exception ( iii1IIIiiiI )
  except Exception as OOo00OoO :
   try : iii1IIIiiiI = str ( OOo00OoO )
   except : iii1IIIiiiI = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 94 - 94: iI / i11iIiiIii % O0
  O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if O0o0O00Oo0o0 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  oo0ooO0 = xbmcgui . ListItem ( path = oo00ooOoo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0ooO0 )
  if 70 - 70: O0oO - ii11ii1ii / OoooooooOO % OoooooooOO
  if 95 - 95: OoooooooOO % OoooooooOO . o0oO0
 return
 if 26 - 26: oO0o0ooO0 + i1I111II1I - II111iiii . II111iiii + o00O0oo + OoOO0ooOOoo0O
def o0IiIiI111IIII1 ( name , url ) :
 if 100 - 100: IIII * O0 + OOooOOo + OoOO0ooOOoo0O . IIII
 import resolveurl
 if 73 - 73: oO0o0ooO0 . II111iiii * O0ooOooooO % oO0o0ooO0 + OoOO0ooOOoo0O - OoOO
 I1I1 = urlresolver . HostedMediaFile ( url )
 dp = xbmcgui . DialogProgress ( )
 dp . create ( 'Realstream:' , 'Conectando al servidor ... ' )
 dp . update ( 20 , 'Por favor, espere ...' )
 xbmc . sleep ( 500 )
 if 19 - 19: O0ooOooooO * ii11ii1ii . O0ooOooooO . OoOO / OoOO - oO0o0ooO0
 if not I1I1 :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  return False
  if 9 - 9: Oooo0Ooo000 * i1I111II1I * Oooo0Ooo000
 try :
  if 74 - 74: iIii1I11I1II1 / o0000oOoOoO0o
  dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
  xbmc . sleep ( 500 )
  oo00ooOoo = I1I1 . resolve ( )
  if not oo00ooOoo or not isinstance ( oo00ooOoo , basestring ) :
   try : iii1IIIiiiI = oo00ooOoo . msg
   except : iii1IIIiiiI = oo00ooOoo
   raise Exception ( iii1IIIiiiI )
 except Exception as OOo00OoO :
  try : iii1IIIiiiI = str ( OOo00OoO )
  except : iii1IIIiiiI = oo00ooOoo
  dp . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
  dp . close ( )
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  if 58 - 58: iIii1I11I1II1 - OOooOOo % o0000oOoOoO0o % OoooooooOO * iIii1I11I1II1 + IIII
 dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
 xbmc . sleep ( 500 )
 dp . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
 xbmc . sleep ( 500 )
 dp . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
 xbmc . sleep ( 500 )
 dp . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
 dp . close ( )
 O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'notificar' )
 if 25 - 25: IIII % O0
 if 44 - 44: Oooo0Ooo000 . o0oO0 * II111iiii / i1I111II1I + iIii1I11I1II1
 if '[Realstream]' or '[Mybox]' in name :
  restante = IiII1IiiIiI1 . getSetting ( 'restante' )
 elif restante == 'true' :
  dialog = xbmcgui . Dialog ( )
  ok = dialog . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
 oo0ooO0 = xbmcgui . ListItem ( path = oo00ooOoo )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0ooO0 )
 if 14 - 14: O0 % i1I111II1I % o0oO0 * oO0o0ooO0
def o0IiIiI111IIII1 ( name , url ) :
 if 65 - 65: O0oO % oO0o0ooO0 + o00O0oo
 if 86 - 86: iIii1I11I1II1 / O0 . Oooo0Ooo000 % iIii1I11I1II1 % ii11ii1ii
 if 'https://www.rapidvideo.com/v/' in url :
  if 86 - 86: i11iIiiIii - o0000oOoOoO0o . iI * ii11ii1ii / o0oO0 % o0000oOoOoO0o
  iIiii1iI1 = i11ii1ii11i ( url )
  ooO0OoOO = re . compile ( 'rapidvideo' ) . findall ( iIiii1iI1 )
  for url in ooO0OoOO :
   if 61 - 61: o0000oOoOoO0o + OoOO0ooOOoo0O
   if 15 - 15: OoOO0ooOOoo0O * oO0o0ooO0 + IIII . O0oO % OOooOOo - iI
   try :
    O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'notificar' )
    if O0o0O00Oo0o0 == 'true' :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oo0ooO0 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0ooO0 )
    if 13 - 13: OoOO0ooOOoo0O % OoOO0ooOOoo0O % ii11ii1ii % OOooOOo * i1IIi % O0oO
   except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 82 - 82: i1I111II1I . OoOO0ooOOoo0O / iI + O0ooOooooO - iI
   if 55 - 55: iI % ii11ii1ii % o0000oOoOoO0o
 else :
  if 29 - 29: i1I111II1I / iIii1I11I1II1 + o00O0oo % O0ooOooooO % O0oO
  import urlresolver
  from urlresolver import common
  if 46 - 46: iIii1I11I1II1
  I1I1 = urlresolver . HostedMediaFile ( url )
  if 70 - 70: i1IIi . O0oO
  if not I1I1 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 74 - 74: O0oO
   if 58 - 58: iIii1I11I1II1 * OoOO * Oooo0Ooo000 * iI . OoooooooOO
  try :
   oo00ooOoo = I1I1 . resolve ( )
   if not oo00ooOoo or not isinstance ( oo00ooOoo , basestring ) :
    try : iii1IIIiiiI = oo00ooOoo . msg
    except : iii1IIIiiiI = url
    raise Exception ( iii1IIIiiiI )
  except Exception as OOo00OoO :
   try : iii1IIIiiiI = str ( OOo00OoO )
   except : iii1IIIiiiI = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 6 - 6: o00O0oo - oO0o0ooO0 * i11iIiiIii + OoOO0ooOOoo0O / iI % IIII
  O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if O0o0O00Oo0o0 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  oo0ooO0 = xbmcgui . ListItem ( path = oo00ooOoo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0ooO0 )
  if 38 - 38: IIII % i1I111II1I % II111iiii - ii11ii1ii - iIii1I11I1II1
 return
 if 9 - 9: o0000oOoOoO0o % o00O0oo . o00O0oo
 if 28 - 28: OoooooooOO % oO0o0ooO0 + o00O0oo + O0 . Oooo0Ooo000
 if 80 - 80: i11iIiiIii % o00O0oo
def OOO00o0 ( name , url ) :
 if 97 - 97: o00O0oo / o00O0oo / iIii1I11I1II1 % i1IIi . o00O0oo . i1I111II1I
 oo00ooOoo = url
 O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'notificar' )
 if O0o0O00Oo0o0 == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  oo0ooO0 = xbmcgui . ListItem ( path = oo00ooOoo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0ooO0 )
 else :
  oo0ooO0 = xbmcgui . ListItem ( path = oo00ooOoo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0ooO0 )
 return
 if 4 - 4: ii11ii1ii - OoOO - i11iIiiIii * Oooo0Ooo000 / o0oO0 - IIII
def II1IIii1ii ( name , url ) :
 if 30 - 30: oO0o0ooO0 * ii11ii1ii / oO0o0ooO0 . II111iiii . ii11ii1ii
 if 91 - 91: II111iiii . IIII + o0000oOoOoO0o
 if '[Youtube]' in name :
  if 8 - 8: IIII * ii11ii1ii / O0ooOooooO - OoOO - OoooooooOO
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 100 - 100: oO0o0ooO0 . iIii1I11I1II1 . iIii1I11I1II1
  try :
   O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if O0o0O00Oo0o0 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oo0ooO0 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0ooO0 )
    if 55 - 55: oO0o0ooO0
    if 37 - 37: i1I111II1I / i11iIiiIii / ii11ii1ii
    if 97 - 97: Oooo0Ooo000 . O0oO / OOooOOo
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 83 - 83: O0oO - o00O0oo * oO0o0ooO0
  if 90 - 90: ii11ii1ii * OOooOOo
 else :
  if 75 - 75: o00O0oo - OoOO0ooOOoo0O * i11iIiiIii . OoooooooOO - ii11ii1ii . O0oO
  import xbmcgui
  import urlresolver
  from urlresolver import common
  if 6 - 6: O0oO * oO0o0ooO0 / OoooooooOO % o0oO0 * o0000oOoOoO0o
  I1I1 = urlresolver . HostedMediaFile ( url )
  if 28 - 28: i1I111II1I * OOooOOo % i1I111II1I
  if not I1I1 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 95 - 95: O0 / O0oO . Oooo0Ooo000
  import resolveurl as urlresolver
  if 17 - 17: O0oO
  I1I1 = urlresolver . HostedMediaFile ( url )
  if 56 - 56: iI * o0000oOoOoO0o + O0oO
  if 48 - 48: i1I111II1I * OoOO % Oooo0Ooo000 - O0oO
  if not I1I1 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 72 - 72: i1IIi % iI % i1I111II1I % oO0o0ooO0 - oO0o0ooO0
  try :
   oo00ooOoo = I1I1 . resolve ( )
   if not oo00ooOoo or not isinstance ( oo00ooOoo , basestring ) :
    try : iii1IIIiiiI = oo00ooOoo . msg
    except : iii1IIIiiiI = url
    raise Exception ( iii1IIIiiiI )
  except Exception as OOo00OoO :
   try : iii1IIIiiiI = str ( OOo00OoO )
   except : iii1IIIiiiI = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 97 - 97: o0000oOoOoO0o * O0 / o0000oOoOoO0o * OoOO * ii11ii1ii
   if 38 - 38: Oooo0Ooo000
   if 25 - 25: iIii1I11I1II1 % II111iiii / O0oO / o00O0oo
  O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if O0o0O00Oo0o0 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 22 - 22: oO0o0ooO0 * O0ooOooooO
   if '[Realstream]' in name :
    if 4 - 4: OoOO0ooOOoo0O - oO0o0ooO0 + OOooOOo
    i1Oo00 = IiII1IiiIiI1 . getSetting ( 'restante' )
    if i1Oo00 == 'true' :
     iiIiIiIiiIiI = xbmcgui . Dialog ( )
     o00oiii11II1I = iiIiIiIiiIiI . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 23 - 23: OoOO / O0ooOooooO / iIii1I11I1II1
   oo0ooO0 = xbmcgui . ListItem ( path = oo00ooOoo )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0ooO0 )
   if 44 - 44: ii11ii1ii . ii11ii1ii + OoooooooOO * i11iIiiIii / O0oO + Oooo0Ooo000
   if 17 - 17: IIII + II111iiii
   if 43 - 43: O0oO % o0oO0 / o0000oOoOoO0o * Oooo0Ooo000
 return
 if 85 - 85: iIii1I11I1II1 . OoooooooOO . o0000oOoOoO0o
 if 77 - 77: OOooOOo % iI
 if 74 - 74: OoOO0ooOOoo0O / i1IIi % OoooooooOO
def o00o0o000Oo ( name , url ) :
 if 100 - 100: i1IIi - i11iIiiIii . Oooo0Ooo000 * OoOO
 if 62 - 62: O0
 if '[Youtube]' in name :
  if 41 - 41: i1IIi - OOooOOo
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 48 - 48: OOooOOo - II111iiii / OoOO + OOooOOo
  try :
   O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if O0o0O00Oo0o0 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oo0ooO0 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0ooO0 )
    if 5 - 5: O0
    if 75 - 75: Oooo0Ooo000 + iIii1I11I1II1
    if 19 - 19: OOooOOo + i11iIiiIii . i1I111II1I - O0oO / o0oO0 + o0000oOoOoO0o
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 38 - 38: ii11ii1ii / iIii1I11I1II1 * iIii1I11I1II1 % o00O0oo
 else :
  if 92 - 92: O0oO / O0 * OOooOOo - O0oO
  import resolveurl
  if 99 - 99: i11iIiiIii % OoooooooOO
  I1I1 = urlresolver . HostedMediaFile ( url )
  if 56 - 56: i1I111II1I * Oooo0Ooo000
  if 98 - 98: O0oO + O0 * Oooo0Ooo000 + i11iIiiIii - IIII - iIii1I11I1II1
  if not I1I1 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 5 - 5: IIII % ii11ii1ii % i1I111II1I % iI
  try :
   oo00ooOoo = I1I1 . resolve ( )
   if not oo00ooOoo or not isinstance ( oo00ooOoo , basestring ) :
    try : iii1IIIiiiI = oo00ooOoo . msg
    except : iii1IIIiiiI = url
    raise Exception ( iii1IIIiiiI )
  except Exception as OOo00OoO :
   try : iii1IIIiiiI = str ( OOo00OoO )
   except : iii1IIIiiiI = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 17 - 17: o0oO0 + II111iiii + OoooooooOO / IIII / i1I111II1I
   if 80 - 80: o0000oOoOoO0o % i1IIi / O0oO
   if 56 - 56: i1IIi . i11iIiiIii
  O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if O0o0O00Oo0o0 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 15 - 15: II111iiii * oO0o0ooO0 % O0ooOooooO / i11iIiiIii - oO0o0ooO0 + ii11ii1ii
   if '[Realstream]' in name :
    if 9 - 9: O0oO - oO0o0ooO0 + O0 / O0ooOooooO % i1IIi
    i1Oo00 = IiII1IiiIiI1 . getSetting ( 'restante' )
    if i1Oo00 == 'true' :
     iiIiIiIiiIiI = xbmcgui . Dialog ( )
     o00oiii11II1I = iiIiIiIiiIiI . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 97 - 97: o0000oOoOoO0o * iI
   oo0ooO0 = xbmcgui . ListItem ( path = oo00ooOoo )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0ooO0 )
   if 78 - 78: O0oO . IIII + oO0o0ooO0 * O0ooOooooO - i1IIi
   if 27 - 27: o0oO0 % i1IIi . ii11ii1ii % Oooo0Ooo000
   if 10 - 10: i1I111II1I / OoooooooOO
 return
 if 50 - 50: i11iIiiIii - OoooooooOO . oO0o0ooO0 + O0 . i1IIi
def OO0Oo00Oo ( name , url ) :
 if 25 - 25: iIii1I11I1II1
 if 63 - 63: iI
 if '[Youtube]' in name :
  if 96 - 96: O0oO
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 34 - 34: OoOO0ooOOoo0O / OoOO - OOooOOo . O0 . IIII
  try :
   O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if O0o0O00Oo0o0 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oo0ooO0 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0ooO0 )
    if 63 - 63: O0ooOooooO
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 11 - 11: O0ooOooooO - iIii1I11I1II1
 else :
  if 92 - 92: OoOO
  if 'https://team.com' in url :
   if 15 - 15: i1I111II1I / i1I111II1I + iIii1I11I1II1 % OoooooooOO
   url = url . replace ( 'https://team.com' , 'https://verystream.com' )
   if 12 - 12: iI
  if 'https://mybox.com' in url :
   if 36 - 36: Oooo0Ooo000 . i1I111II1I * OoooooooOO - o0000oOoOoO0o
   url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
   if 60 - 60: IIII . O0ooOooooO / iIii1I11I1II1 + IIII * Oooo0Ooo000
  if 'https://drive.com' in url :
   if 82 - 82: i11iIiiIii . iIii1I11I1II1 * OOooOOo - O0oO + o0oO0
   url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
   if 48 - 48: o00O0oo
  if 'https://vid.co' in url :
   if 96 - 96: iI . OoooooooOO
   url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
   if 39 - 39: IIII + OoOO
  if 'https://limited.to' in url :
   if 80 - 80: IIII % OoOO / OoOO0ooOOoo0O
   url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
   if 54 - 54: ii11ii1ii % OoOO - IIII - O0oO
  import resolveurl
  if 71 - 71: iI . i11iIiiIii
  I1I1 = urlresolver . HostedMediaFile ( url )
  if 56 - 56: O0 * O0ooOooooO + O0ooOooooO * iIii1I11I1II1 / iI * Oooo0Ooo000
  if 25 - 25: iIii1I11I1II1 . O0oO * i11iIiiIii + ii11ii1ii * O0oO
  if not I1I1 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no encontrado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 67 - 67: O0ooOooooO
  try :
   oo00ooOoo = I1I1 . resolve ( )
   if not oo00ooOoo or not isinstance ( oo00ooOoo , basestring ) :
    try : iii1IIIiiiI = oo00ooOoo . msg
    except : iii1IIIiiiI = url
    raise Exception ( iii1IIIiiiI )
  except Exception as OOo00OoO :
   try : iii1IIIiiiI = str ( OOo00OoO )
   except : iii1IIIiiiI = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace borrado, o no encontrado. Prueba a reiniciar el router o poner una VPN.[/COLOR]  ,5000)" )
   return False
   if 88 - 88: ii11ii1ii
   if 8 - 8: o00O0oo
   if 82 - 82: OoooooooOO
   O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if O0o0O00Oo0o0 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
    if 75 - 75: II111iiii % OOooOOo + IIII % OoooooooOO / i1I111II1I
    if '[Realstream]' or '[Mybox]' in name :
     i1Oo00 = IiII1IiiIiI1 . getSetting ( 'restante' )
    elif i1Oo00 == 'true' :
     iiIiIiIiiIiI = xbmcgui . Dialog ( )
     o00oiii11II1I = iiIiIiIiiIiI . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 4 - 4: i11iIiiIii - IIII % o00O0oo * Oooo0Ooo000 % o0000oOoOoO0o
  oo0ooO0 = xbmcgui . ListItem ( path = oo00ooOoo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0ooO0 )
  if 71 - 71: iI . iI - iIii1I11I1II1
 return
 if 22 - 22: OoooooooOO / o00O0oo % O0ooOooooO * OoOO0ooOOoo0O
def Ii1IiiiI1ii ( name , url ) :
 if 55 - 55: o00O0oo
 if 76 - 76: oO0o0ooO0 - i11iIiiIii
 if '[Youtube]' in name :
  if 27 - 27: o00O0oo - i11iIiiIii % Oooo0Ooo000 / ii11ii1ii . ii11ii1ii / OoooooooOO
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 76 - 76: O0oO * OoOO . iIii1I11I1II1 % OoooooooOO % o00O0oo
  try :
   O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if O0o0O00Oo0o0 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oo0ooO0 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0ooO0 )
    if 39 - 39: II111iiii * OoOO0ooOOoo0O . O0 * O0oO
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 89 - 89: o0oO0 - iI . O0oO - Oooo0Ooo000 - OOooOOo
 else :
  if 79 - 79: i1I111II1I + i1I111II1I + o0oO0
  OOoOO0oo0ooO = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
  ii1I = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  O0oO0 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  ooO00O00oOO = IiII1IiiIiI1 . getSetting ( 'key_ext' )
  iIiii1iI1 = i11ii1ii11i ( O0oO0 )
  ooO0OoOO = re . compile ( ii1iII1II ) . findall ( iIiii1iI1 )
  for I1IIII1ii in ooO0OoOO :
   if 39 - 39: O0 - OoooooooOO
   try :
    if 63 - 63: iIii1I11I1II1 % o0000oOoOoO0o * iI
    if 79 - 79: O0
    OOoOO0oo0ooO = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
    if 32 - 32: II111iiii . O0 + o0oO0 / OoOO0ooOOoo0O / i1I111II1I / IIII
    if 15 - 15: o00O0oo
    if OOoOO0oo0ooO == I1IIII1ii :
     if 4 - 4: i1I111II1I + iIii1I11I1II1 * O0ooOooooO + ii11ii1ii * o0000oOoOoO0o % II111iiii
     if 88 - 88: oO0o0ooO0 - i1IIi % i11iIiiIii % II111iiii * OoooooooOO
     if 'https://team.com' in url :
      if 40 - 40: ii11ii1ii
      url = url . replace ( 'https://team.com' , 'https://verystream.com' )
      if 47 - 47: OoOO0ooOOoo0O
     if 'https://mybox.com' in url :
      if 65 - 65: O0 + Oooo0Ooo000 % o0oO0 * OOooOOo / iI / OoOO0ooOOoo0O
      url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
      if 71 - 71: i11iIiiIii / OoOO0ooOOoo0O . oO0o0ooO0
      if 33 - 33: oO0o0ooO0
     if 'https://vidcloud.co/' in url :
      if 39 - 39: OoOO + O0 + iI * II111iiii % O0 - O0
      url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
      if 41 - 41: i1I111II1I % o0000oOoOoO0o
     if 'https://gounlimited.to' in url :
      if 67 - 67: O0 % Oooo0Ooo000
      url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
      if 35 - 35: OOooOOo . OoOO0ooOOoo0O + OoooooooOO % ii11ii1ii % IIII
     if 'https://drive.com' in url :
      if 39 - 39: o0oO0
      url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
      if 60 - 60: IIII
      if 62 - 62: Oooo0Ooo000 * O0oO
     import resolveurl
     if 74 - 74: OoOO0ooOOoo0O . iIii1I11I1II1
     I1I1 = urlresolver . HostedMediaFile ( url )
     if 87 - 87: iI
     if not I1I1 :
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
      return False
      if 41 - 41: OoOO0ooOOoo0O . iIii1I11I1II1 % iI + O0
     try :
      OO0oo = xbmcgui . DialogProgress ( )
      OO0oo . create ( 'Realstream:' , 'Iniciando ...' )
      OO0oo . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
      xbmc . sleep ( 1000 )
      if 22 - 22: o0000oOoOoO0o + ii11ii1ii . iI + o00O0oo * O0ooOooooO . i11iIiiIii
      oo00ooOoo = I1I1 . resolve ( )
      if not oo00ooOoo or not isinstance ( oo00ooOoo , basestring ) :
       if 90 - 90: IIII * OoOO0ooOOoo0O - ii11ii1ii + o0000oOoOoO0o
       try : iii1IIIiiiI = oo00ooOoo . msg
       except : iii1IIIiiiI = url
       raise Exception ( iii1IIIiiiI )
       if 53 - 53: OoooooooOO . OoooooooOO + o0000oOoOoO0o - O0ooOooooO + IIII
     except Exception as OOo00OoO :
      try : iii1IIIiiiI = str ( OOo00OoO )
      except : iii1IIIiiiI = url
      OO0oo . update ( 45 , 'RESOLVEURL:' , 'Reiniciando ... ' )
      xbmc . sleep ( 1000 )
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no disponible.  ,3000)" )
      OO0oo . close ( )
      if 44 - 44: Oooo0Ooo000 - i1I111II1I
     OO0oo . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
     xbmc . sleep ( 500 )
     OO0oo . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
     xbmc . sleep ( 1000 )
     OO0oo . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
     OO0oo . close ( )
     O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'notificar' )
     oo0ooO0 = xbmcgui . ListItem ( path = oo00ooOoo )
     xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0ooO0 )
     if 100 - 100: oO0o0ooO0 . OoOO - o0oO0 + O0 * OoOO
     if 59 - 59: II111iiii
    else :
     if 43 - 43: ii11ii1ii + OoooooooOO
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold]>El addon esta desactivado.[/COLOR]" )
     return False
     if 47 - 47: iI
   except :
    pass
    if 92 - 92: O0oO % i11iIiiIii % ii11ii1ii
 return
 if 23 - 23: II111iiii * O0ooOooooO
def o0Oo ( ) :
 if 16 - 16: O0ooOooooO % OOooOOo - iI
 ooO00OoO0o0OO = [ ]
 II11IiI1 = sys . argv [ 2 ]
 if len ( II11IiI1 ) >= 2 :
  iIIi11i = sys . argv [ 2 ]
  III = iIIi11i . replace ( '?' , '' )
  if ( iIIi11i [ len ( iIIi11i ) - 1 ] == '/' ) :
   iIIi11i = iIIi11i [ 0 : len ( iIIi11i ) - 2 ]
  iiIi111Ii1II = III . split ( '&' )
  ooO00OoO0o0OO = { }
  for oOoo0oO in range ( len ( iiIi111Ii1II ) ) :
   IIii1i = { }
   IIii1i = iiIi111Ii1II [ oOoo0oO ] . split ( '=' )
   if ( len ( IIii1i ) ) == 2 :
    ooO00OoO0o0OO [ IIii1i [ 0 ] ] = IIii1i [ 1 ]
 return ooO00OoO0o0OO
 if 69 - 69: Oooo0Ooo000 / OoooooooOO % i11iIiiIii
 if 18 - 18: i11iIiiIii - iI * oO0o0ooO0 + o0000oOoOoO0o
def IiiiIi1iiii11 ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  import urlresolver
  xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
  if 27 - 27: OOooOOo * II111iiii - O0oO
def Iii11i ( ) :
 iiIiIiIiiIiI = xbmcgui . Dialog ( )
 list = (
 Ii11I1I11II ,
 IIiiiI
 )
 if 59 - 59: oO0o0ooO0 % iI
 ii1II1iiii = iiIiIiIiiIiI . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=%s]Accede a themoviedb.com[/COLOR]' % III1iII1I1ii ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 47 - 47: o00O0oo * oO0o0ooO0 + iIii1I11I1II1 - oO0o0ooO0 / i1I111II1I
 if ii1II1iiii :
  if 86 - 86: i1I111II1I
  if ii1II1iiii < 0 :
   return
  Iii1I = list [ ii1II1iiii - 2 ]
  return Iii1I ( )
 else :
  Iii1I = list [ ii1II1iiii ]
  return Iii1I ( )
 return
 if 100 - 100: OoooooooOO . ii11ii1ii / o00O0oo
def I11i1I11iIii ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 81 - 81: o0oO0 / o00O0oo + oO0o0ooO0 / IIII + OoOO0ooOOoo0O
OOOii = I11i1I11iIii ( )
if 33 - 33: OoooooooOO + Oooo0Ooo000 / Oooo0Ooo000 + Oooo0Ooo000 * i1I111II1I
def Ii11I1I11II ( ) :
 if OOOii == 'android' :
  O0iI = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  O0iI = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 26 - 26: Oooo0Ooo000 . OOooOOo . O0ooOooooO - OoooooooOO / iIii1I11I1II1
  if 47 - 47: i1I111II1I
def IIiiiI ( ) :
 if 76 - 76: OoOO * iIii1I11I1II1 + o00O0oo - iI - O0oO / i1IIi
 main ( )
 if 27 - 27: o00O0oo . i1I111II1I
 if 66 - 66: O0 / O0 * i1IIi . OoooooooOO % iIii1I11I1II1
 if 21 - 21: i1I111II1I - OOooOOo % OoooooooOO + o0000oOoOoO0o
def o00O0o ( ) :
 iiIiIiIiiIiI = xbmcgui . Dialog ( )
 i1Ii1 = (
 oooOOo0oOoOO ,
 iI1iIIII1
 )
 if 65 - 65: O0 / II111iiii . iIii1I11I1II1 . oO0o0ooO0 / ii11ii1ii % iIii1I11I1II1
 ii1II1iiii = iiIiIiIiiIiI . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 74 - 74: i1IIi / OOooOOo % o00O0oo / O0 % O0oO - OoOO0ooOOoo0O
 if ii1II1iiii :
  if 31 - 31: OOooOOo / OoooooooOO . iIii1I11I1II1 * OoOO0ooOOoo0O . OoooooooOO + II111iiii
  if ii1II1iiii < 0 :
   return
  Iii1I = i1Ii1 [ ii1II1iiii - 2 ]
  return Iii1I ( )
 else :
  Iii1I = i1Ii1 [ ii1II1iiii ]
  return Iii1I ( )
 return
 if 8 - 8: o00O0oo * o00O0oo * i1IIi + O0ooOooooO . o00O0oo
def I11i1I11iIii ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 100 - 100: OoooooooOO - O0 . O0oO / O0oO + II111iiii * OoOO0ooOOoo0O
OOOii = I11i1I11iIii ( )
if 37 - 37: ii11ii1ii
def oooOOo0oOoOO ( ) :
 if OOOii == 'android' :
  O0iI = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  O0iI = webbrowser . open ( 'https://olpair.com/' )
  if 72 - 72: i1I111II1I % o00O0oo * IIII . i11iIiiIii % i1I111II1I * IIII
  if 15 - 15: O0oO / ii11ii1ii * O0oO
def iI1iIIII1 ( ) :
 if 20 - 20: iI - IIII * OoOO * o0000oOoOoO0o * IIII / i1I111II1I
 main ( )
 if 40 - 40: OOooOOo * o0000oOoOoO0o . OOooOOo
 if 62 - 62: iI + II111iiii % iI
def Ii1IIii ( name , url , id , trailer ) :
 iiIiIiIiiIiI = xbmcgui . Dialog ( )
 i1Ii1 = (
 oooOOoo ,
 iI1iii1iIiiI ,
 II1iiiiI1 ,
 Iii11i ,
 IiiIiiIIII
 )
 if 88 - 88: OoOO . Oooo0Ooo000 / O0oO
 ii1II1iiii = iiIiIiIiiIiI . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % III1iII1I1ii ,

 '[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % III1iII1I1ii ,

 '[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % III1iII1I1ii ,

 '[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % III1iII1I1ii ,

 '[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % III1iII1I1ii ] )
 if 47 - 47: OoOO + o00O0oo . iI
 if ii1II1iiii :
  if 43 - 43: OOooOOo - o0000oOoOoO0o / o0000oOoOoO0o . II111iiii - o0oO0
  if ii1II1iiii < 0 :
   return
  Iii1I = i1Ii1 [ ii1II1iiii - 5 ]
  return Iii1I ( )
 else :
  Iii1I = i1Ii1 [ ii1II1iiii ]
  return Iii1I ( )
 return
 if 40 - 40: O0ooOooooO . OoOO0ooOOoo0O * O0
 if 6 - 6: OOooOOo - II111iiii . OOooOOo + O0oO . IIII
 if 74 - 74: i1IIi
def oooOOoo ( ) :
 if 15 - 15: i1IIi + i1I111II1I % OOooOOo / i11iIiiIii * OoOO0ooOOoo0O
 Ii1IiiiI1ii ( iI1ii1i , Oo0oooO0oO )
 if 69 - 69: i11iIiiIii
def iI1iii1iIiiI ( ) :
 if 61 - 61: O0
 ii111I11Ii ( iI1ii1i , IiIiII1 )
 if 21 - 21: OoOO % iIii1I11I1II1 . OoOO
def II1iiiiI1 ( ) :
 if 99 - 99: o0000oOoOoO0o * IIII % oO0o0ooO0 * oO0o0ooO0 + OoooooooOO
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  O0OO = id
  if 30 - 30: OoOO0ooOOoo0O * ii11ii1ii % iIii1I11I1II1 % OoOO + i11iIiiIii
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % O0OO )
  if 46 - 46: OOooOOo . i1I111II1I - i11iIiiIii - Oooo0Ooo000
 if O0o0O00Oo0o0 == 'true' :
  if 97 - 97: II111iiii % ii11ii1ii * i1I111II1I
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + iI1ii1i + "[/COLOR] ,5000)" )
  if 51 - 51: ii11ii1ii % IIII . ii11ii1ii
def o0o0oO0OOO ( ) :
 if 66 - 66: o0oO0 * iIii1I11I1II1 - iI / OOooOOo
 Iii11i ( )
 if 62 - 62: i1I111II1I . O0 . iIii1I11I1II1
def IiiIiiIIII ( ) :
 if 94 - 94: iI % O0oO % i1IIi
 OoOIii11iI11i1I ( )
def ooO ( name , url , mode , iconimage , fanart ) :
 if 90 - 90: o0oO0 * OoOO
 iiiiI11ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 o00oiii11II1I = True
 O0i1i1II1i11 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 O0i1i1II1i11 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 O0i1i1II1i11 . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  iiiiI11ii = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  o00oiii11II1I = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiiiI11ii , listitem = O0i1i1II1i11 , isFolder = True )
  return o00oiii11II1I
 o00oiii11II1I = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiiiI11ii , listitem = O0i1i1II1i11 , isFolder = True )
 return o00oiii11II1I
 if 7 - 7: O0ooOooooO . o0oO0 . O0ooOooooO - Oooo0Ooo000
def II1II1iIIi11 ( name , url , mode , iconimage , fanart , description ) :
 if 33 - 33: iI + OoooooooOO - OoOO / i1IIi / OoooooooOO
 iiiiI11ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 o00oiii11II1I = True
 O0i1i1II1i11 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 O0i1i1II1i11 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 O0i1i1II1i11 . setProperty ( 'fanart_image' , fanart )
 o00oiii11II1I = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiiiI11ii , listitem = O0i1i1II1i11 , isFolder = True )
 return o00oiii11II1I
 if 82 - 82: o00O0oo / IIII - O0ooOooooO / ii11ii1ii * OoOO
def Ooo00OOOOOO0 ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 55 - 55: OoooooooOO
 O00OOOoOoo0O = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 73 - 73: OoOO0ooOOoo0O - o00O0oo % ii11ii1ii + o00O0oo - O0 . OoOO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 i1iIii = [ ]
 if 95 - 95: O0oO / i1I111II1I . O0 * i1I111II1I - o0000oOoOoO0o * ii11ii1ii
 i1iIii . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 iiiiI11ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 O0i1i1II1i11 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 O0i1i1II1i11 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 O0i1i1II1i11 . setProperty ( 'fanart_image' , fanart )
 O0i1i1II1i11 . setProperty ( 'IsPlayable' , 'true' )
 if 6 - 6: OoOO0ooOOoo0O . II111iiii * OOooOOo . OOooOOo / o0oO0
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  i1iIii . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 14 - 14: Oooo0Ooo000 % i1I111II1I - O0 / Oooo0Ooo000
  O0i1i1II1i11 . addContextMenuItems ( i1iIii , replaceItems = True )
 o00oiii11II1I = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiiiI11ii , listitem = O0i1i1II1i11 )
 return o00oiii11II1I
 if 91 - 91: i11iIiiIii % Oooo0Ooo000 * oO0o0ooO0 - o00O0oo . Oooo0Ooo000
 if 28 - 28: i11iIiiIii
def iI11II1i1I1 ( name , url , mode , iconimage , fanart , id , trailer , description ) :
 if 51 - 51: OOooOOo + iI * O0 . o0oO0
 O00OOOoOoo0O = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 82 - 82: IIII * o00O0oo % o0oO0 . IIII
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 i1iIii = [ ]
 if 43 - 43: OoOO . iI * ii11ii1ii
 i1iIii . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 iiiiI11ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 O0i1i1II1i11 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 O0i1i1II1i11 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 O0i1i1II1i11 . setProperty ( 'fanart_image' , fanart )
 O0i1i1II1i11 . setProperty ( 'IsPlayable' , 'true' )
 if 20 - 20: i1IIi . i1IIi - O0oO
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  i1iIii . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 89 - 89: iI - O0oO . O0 % OoooooooOO . i11iIiiIii
  O0i1i1II1i11 . addContextMenuItems ( i1iIii , replaceItems = True )
 o00oiii11II1I = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiiiI11ii , listitem = O0i1i1II1i11 )
 return o00oiii11II1I
 if 35 - 35: II111iiii / OoOO0ooOOoo0O - O0 . II111iiii
def O00oo00oOOO0o ( name , url , mode , iconimage , fanart ) :
 if 55 - 55: ii11ii1ii % i1IIi * O0oO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 95 - 95: IIII / II111iiii - o0000oOoOoO0o % Oooo0Ooo000 . O0oO
 iiiiI11ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 O0i1i1II1i11 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 O0i1i1II1i11 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 O0i1i1II1i11 . setProperty ( 'fanart_image' , fanart )
 O0i1i1II1i11 . setProperty ( 'IsPlayable' , 'true' )
 o00oiii11II1I = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiiiI11ii , listitem = O0i1i1II1i11 )
 return o00oiii11II1I
 if 63 - 63: iIii1I11I1II1 / iI
def II1i ( name , url , mode ) :
 if 98 - 98: OoOO0ooOOoo0O - OoOO0ooOOoo0O . II111iiii . O0ooOooooO + O0
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 28 - 28: i1I111II1I + i11iIiiIii + OoooooooOO / OoOO
 iiiiI11ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 O0i1i1II1i11 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = IiIi1II11i )
 O0i1i1II1i11 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 O0i1i1II1i11 . setProperty ( 'fanart_image' , oo00 )
 O0i1i1II1i11 . setProperty ( 'IsPlayable' , 'true' )
 o00oiii11II1I = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiiiI11ii , listitem = O0i1i1II1i11 )
 return o00oiii11II1I
 if 6 - 6: OOooOOo - i11iIiiIii
def O00O0O0OO00oo ( name , url , mode , iconimage ) :
 iiiiI11ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 o00oiii11II1I = True
 O0i1i1II1i11 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 o00oiii11II1I = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiiiI11ii , listitem = O0i1i1II1i11 , isFolder = True )
 return o00oiii11II1I
 if 39 - 39: i1I111II1I % OoOO0ooOOoo0O * o00O0oo - OoooooooOO - ii11ii1ii
def Oo0 ( ) :
 if 96 - 96: i1IIi
 if 55 - 55: oO0o0ooO0 + IIII + o0oO0
 if 82 - 82: o00O0oo . II111iiii / OoOO0ooOOoo0O / OoOO
 i11I1I1I = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 i11I1I1I . doModal ( )
 if ( i11I1I1I . isConfirmed ( ) ) :
  if 47 - 47: O0ooOooooO + O0 / II111iiii * OOooOOo - OoooooooOO . o0oO0
  oo00O00Oo = urllib . quote_plus ( i11I1I1I . getText ( ) ) . replace ( '+' , ' ' )
  if 28 - 28: oO0o0ooO0 . oO0o0ooO0 . iIii1I11I1II1 . IIII . o00O0oo * i11iIiiIii
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 72 - 72: O0oO
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % oo00O00Oo )
    if 26 - 26: i1I111II1I % ii11ii1ii
    if O0o0O00Oo0o0 == 'true' :
     if 72 - 72: O0 + o0000oOoOoO0o + OOooOOo / ii11ii1ii
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + iI1ii1i + "[/COLOR] ,10000)" )
     if 83 - 83: i1I111II1I - OOooOOo . o0oO0
   except :
    if 34 - 34: OoOO0ooOOoo0O - oO0o0ooO0 * OoooooooOO
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 5 - 5: i11iIiiIii * O0ooOooooO - o0oO0 - o00O0oo - i1IIi + O0ooOooooO
iIIi11i = o0Oo ( )
Oo0oooO0oO = None
iI1ii1i = None
I1ii1i = None
IiIi1II11i = None
id = None
IiIiII1 = None
if 51 - 51: OoOO - O0ooOooooO % O0 - OoOO0ooOOoo0O
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 53 - 53: O0ooOooooO / i1IIi / i1IIi
try :
 Oo0oooO0oO = urllib . unquote_plus ( iIIi11i [ "url" ] )
except :
 pass
try :
 iI1ii1i = urllib . unquote_plus ( iIIi11i [ "name" ] )
except :
 pass
try :
 I1ii1i = int ( iIIi11i [ "mode" ] )
except :
 pass
try :
 IiIi1II11i = urllib . unquote_plus ( iIIi11i [ "iconimage" ] )
except :
 pass
try :
 id = int ( iIIi11i [ "id" ] )
except :
 pass
try :
 IiIiII1 = urllib . unquote_plus ( iIIi11i [ "trailer" ] )
except :
 pass
 if 77 - 77: O0oO + i1IIi . O0oO
 if 89 - 89: o0000oOoOoO0o + IIII * oO0o0ooO0
print "Mode: " + str ( I1ii1i )
print "URL: " + str ( Oo0oooO0oO )
print "Name: " + str ( iI1ii1i )
print "iconimage: " + str ( IiIi1II11i )
print "id: " + str ( id )
print "trailer: " + str ( IiIiII1 )
if 45 - 45: O0ooOooooO - o0000oOoOoO0o . o0oO0
if I1ii1i == None or Oo0oooO0oO == None or len ( Oo0oooO0oO ) < 1 :
 if 41 - 41: II111iiii . OOooOOo / OoOO . iI
 OoOIii11iI11i1I ( )
 II1I11i ( )
 if 58 - 58: i1I111II1I % i11iIiiIii * II111iiii . o00O0oo
elif I1ii1i == 1 :
 Ii1IIii ( iI1ii1i , Oo0oooO0oO , id , IiIiII1 )
elif I1ii1i == 2 :
 oOo00o00oO ( )
elif I1ii1i == 3 :
 OoiIIIiIi1I1i ( )
elif I1ii1i == 4 :
 iIIiiIi ( iI1ii1i , Oo0oooO0oO )
elif I1ii1i == 5 :
 O000O ( )
elif I1ii1i == 6 :
 o0o0O0Oo ( )
elif I1ii1i == 7 :
 oOoO0O00oo ( )
elif I1ii1i == 8 :
 Oo0O0O00Oo ( )
elif I1ii1i == 9 :
 o0oO0Oo ( )
elif I1ii1i == 10 :
 O00o ( )
elif I1ii1i == 11 :
 o0Ii1 ( )
elif I1ii1i == 12 :
 i11Ii1IIi ( )
elif I1ii1i == 13 :
 oOOO0ooo ( )
elif I1ii1i == 14 :
 i1ii1IiiiiIi1I ( )
elif I1ii1i == 15 :
 o0OO0OOO0O ( )
elif I1ii1i == 16 :
 II1II1IIII ( )
elif I1ii1i == 17 :
 i111I11i1I ( )
elif I1ii1i == 18 :
 i1I ( )
elif I1ii1i == 19 :
 i1ii1iiIi1II ( )
elif I1ii1i == 20 :
 Ooooo ( )
elif I1ii1i == 21 :
 Iiii1I ( )
elif I1ii1i == 22 :
 iIIi1Ii1III ( )
elif I1ii1i == 23 :
 OooO0Oo0 ( )
elif I1ii1i == 24 :
 ii1IIiII111I ( )
elif I1ii1i == 25 :
 iIi1i11 ( )
elif I1ii1i == 26 :
 iiooO0o0oO ( )
elif I1ii1i == 28 :
 II1iiIiIiI ( iI1ii1i , Oo0oooO0oO )
elif I1ii1i == 29 :
 Ii1I1 ( )
elif I1ii1i == 30 :
 ooo0O0oOoooO0 ( )
elif I1ii1i == 31 :
 prueba ( )
elif I1ii1i == 98 :
 busqueda_global ( )
elif I1ii1i == 97 :
 o00O0o ( )
elif I1ii1i == 99 :
 IIi11i1II ( )
elif I1ii1i == 100 :
 menu_player ( iI1ii1i , Oo0oooO0oO )
elif I1ii1i == 111 :
 OooooOoooO ( )
elif I1ii1i == 115 :
 ii111I11Ii ( Oo0oooO0oO )
elif I1ii1i == 116 :
 oooO0 ( )
elif I1ii1i == 117 :
 oOoOOo0oo0 ( )
elif I1ii1i == 119 :
 oOooo0O0o ( )
elif I1ii1i == 120 :
 O0oOOO000oooo0 ( )
elif I1ii1i == 121 :
 OooOOOOoO00OoOO ( )
elif I1ii1i == 125 :
 IIiiiiIiI1III ( )
elif I1ii1i == 112 :
 list_proxy ( )
elif I1ii1i == 127 :
 Oo0 ( )
elif I1ii1i == 128 :
 TESTLINKS ( )
elif I1ii1i == 130 :
 Ii1IiiiI1ii ( iI1ii1i , Oo0oooO0oO )
elif I1ii1i == 140 :
 oO0Ooo0ooOO0 ( )
elif I1ii1i == 141 :
 i1iI1Iiii1I ( )
elif I1ii1i == 142 :
 oooo0OOo ( )
elif I1ii1i == 143 :
 i1iIiIi1I ( iI1ii1i , Oo0oooO0oO )
elif I1ii1i == 144 :
 II1iiIiIiI ( iI1ii1i , Oo0oooO0oO )
elif I1ii1i == 145 :
 o0oOoO0O ( )
elif I1ii1i == 150 :
 I1i1111I ( )
elif I1ii1i == 151 :
 o00o ( )
elif I1ii1i == 152 :
 OOO0ooo ( )
elif I1ii1i == 155 :
 II1I1iiIII1I1 ( )
 if 94 - 94: i11iIiiIii . IIII + iIii1I11I1II1 * Oooo0Ooo000 * Oooo0Ooo000
xbmcplugin . endOfDirectory ( o0OoOoOO00 ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
