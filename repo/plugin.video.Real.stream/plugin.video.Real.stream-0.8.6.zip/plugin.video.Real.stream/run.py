# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 0.8.1
#
############################################
# Dependencias 
# Script ExtendedInfo
# Script Urlresolver de TVAddons
# Script ResolveURL Por Jsergio.
#
############################################
#
# Corregido imcompatibilidad con Servidor Team
# Agregados nuevos iconos, ahora se puede el aspecto desde ajustes del addon.
#
############################################
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import urlresolver
import cookielib , base64
import requests
import plugintools
import config
oo000 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
ii = oo000 . getAddonInfo ( 'version' )
oOOo = int ( sys . argv [ 1 ] )
O0 = 'gruponetai/'
o0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
iI11I1II1I1I = o0O . getAddonInfo ( 'profile' )
oooo = o0O . getAddonInfo ( 'path' )
iIIii1IIi = oo000 . getSetting ( 'iconos' )
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if iIIii1IIi == 'true' :
 if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
 O0oOO0o0 = xbmc . translatePath ( os . path . join ( oooo , 'fanart.png' ) )
 i1ii1iIII = xbmc . translatePath ( os . path . join ( oooo , 'icon.png' ) )
 Oo0oO0oo0oO00 = xbmc . translatePath ( os . path . join ( oooo , 'extended_info.png' ) )
 i111I = xbmc . translatePath ( os . path . join ( oooo , 'buscar.png' ) )
 II1Ii1iI1i = xbmc . translatePath ( os . path . join ( oooo , 'pair.png' ) )
 iiI1iIiI = xbmc . translatePath ( os . path . join ( oooo , 'theMovieDB.png' ) )
 OOo = xbmc . translatePath ( os . path . join ( oooo , 'novedades.png' ) )
 Ii1IIii11 = xbmc . translatePath ( os . path . join ( oooo , 'estrenos.png' ) )
 Oooo0000 = xbmc . translatePath ( os . path . join ( oooo , 'recomendadas.png' ) )
 i11 = xbmc . translatePath ( os . path . join ( oooo , 'accion.png' ) )
 I11 = xbmc . translatePath ( os . path . join ( oooo , 'animacion.png' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( oooo , 'aventuras.png' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( oooo , 'belico.png' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( oooo , 'ciencia-ficcion.png' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( oooo , 'comedia.png' ) )
 oO = xbmc . translatePath ( os . path . join ( oooo , 'crimen.png' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( oooo , 'drama.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( oooo , 'familiar.png' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( oooo , 'fantasia.png' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( oooo , 'historia.png' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( oooo , 'marvel.png' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( oooo , 'misterio.png' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( oooo , 'musical.png' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( oooo , 'romance.png' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( oooo , 'spain.png' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( oooo , 'suspense.png' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( oooo , 'terror.png' ) )
 II = xbmc . translatePath ( os . path . join ( oooo , 'thriller.png' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( oooo , 'western.png' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( oooo , 'sagas_cine.png' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( oooo , '4k.png' ) )
 OO0o = xbmc . translatePath ( os . path . join ( oooo , 'torrent.png' ) )
 Ooo = xbmc . translatePath ( os . path . join ( oooo , 'buscar-serie.jpg' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( oooo , 'series-todas.jpg' ) )
 if 78 - 78: IIIIII11i1I - o0o0OOO0o0 % IIII % o0O0 . o0oOOo0O0Ooo % II111iiii
else :
 if 95 - 95: ooOoO0o
 if 49 - 49: IiII % o00O0oo + OoOoOO00 . I1ii11iIi11i % iII111i
 iIIii1IIi = oo000 . getSetting ( 'iconos' )
 O0oOO0o0 = xbmc . translatePath ( os . path . join ( oooo , 'fanart.jpg' ) )
 i1ii1iIII = xbmc . translatePath ( os . path . join ( oooo , 'icon.png' ) )
 Oo0oO0oo0oO00 = xbmc . translatePath ( os . path . join ( oooo , 'extended_info.png' ) )
 i111I = xbmc . translatePath ( os . path . join ( oooo , 'buscar.png' ) )
 II1Ii1iI1i = xbmc . translatePath ( os . path . join ( oooo , 'pair.png' ) )
 iiI1iIiI = xbmc . translatePath ( os . path . join ( oooo , 'theMovieDB.jpg' ) )
 OOo = xbmc . translatePath ( os . path . join ( oooo , 'novedades.jpg' ) )
 Ii1IIii11 = xbmc . translatePath ( os . path . join ( oooo , 'encines.jpg' ) )
 Oooo0000 = xbmc . translatePath ( os . path . join ( oooo , 'recomendadas.jpg' ) )
 i11 = xbmc . translatePath ( os . path . join ( oooo , 'accion.jpg' ) )
 I11 = xbmc . translatePath ( os . path . join ( oooo , 'animacion.jpg' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( oooo , 'aventuras.jpg' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( oooo , 'belico.jpg' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( oooo , 'ciencia-ficcion.jpg' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( oooo , 'comedia.jpg' ) )
 oO = xbmc . translatePath ( os . path . join ( oooo , 'crimen.jpg' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( oooo , 'drama.jpg' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( oooo , 'familiar.jpg' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( oooo , 'fantasia.jpg' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( oooo , 'historia.jpg' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( oooo , 'superheroes.jpg' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( oooo , 'misterio.jpg' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( oooo , 'musical.jpg' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( oooo , 'romance.jpg' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( oooo , 'spain.jpg' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( oooo , 'suspense.jpg' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( oooo , 'terror.jpg' ) )
 II = xbmc . translatePath ( os . path . join ( oooo , 'thriller.jpg' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( oooo , 'western.jpg' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( oooo , 'sagas_cine.jpg' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( oooo , '4k.jpg' ) )
 OO0o = xbmc . translatePath ( os . path . join ( oooo , 'torrent.jpg' ) )
 Ooo = xbmc . translatePath ( os . path . join ( oooo , 'buscar-serie.jpg' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( oooo , 'series-todas.jpg' ) )
 if 48 - 48: ooOoO0o + ooOoO0o / o0oOOo0O0Ooo / Oo0Ooo
 if 20 - 20: Ii1I
 if 77 - 77: I11i / ooOoO0o
Ooooo = xbmc . translatePath ( os . path . join ( oooo , 'peliculas.png' ) )
I1I1i = xbmc . translatePath ( os . path . join ( oooo , 'series.png' ) )
oOOOoo0O0OoO = xbmc . translatePath ( os . path . join ( oooo , 'ajustes.png' ) )
ii1i1I1i = xbmc . translatePath ( os . path . join ( oooo , 'videoteca.png' ) )
o00oOO0 = xbmc . translatePath ( os . path . join ( oooo , 'favorites.png' ) )
oOoo = xbmc . translatePath ( os . path . join ( oooo , 'resolver.png' ) )
iIii11I = xbmc . translatePath ( os . path . join ( oooo , 'test.png' ) )
OOO0OOO00oo = xbmc . translatePath ( os . path . join ( oooo , 'video-tutoriales.png' ) )
Iii111II = xbmc . translatePath ( os . path . join ( oooo , 'proxy.png' ) )
if 9 - 9: OOooOOo
i11O0oo0OO0oOOOo = oo000 . getSetting ( 'mostrar_cat' )
i1i1i11IIi = oo000 . getSetting ( 'videos' )
II1III = oo000 . getSetting ( 'activar' )
iI1iI1I1i1I = oo000 . getSetting ( 'favcopy' )
iIi11Ii1 = oo000 . getSetting ( 'anticopia' )
Ii11iII1 = oo000 . getSetting ( 'licencia_addon' )
Oo0O0O0ooO0O = oo000 . getSetting ( 'notificar' )
IIIIii = oo000 . getSetting ( 'mostrar_bus' )
O0o0 = oo000 . getSetting ( 'restante' )
OO00Oo = oo000 . getSetting ( 'selecton' )
O0OOO0OOoO0O = oo000 . getSetting ( 'aviso' )
O00Oo000ooO0 = oo000 . getSetting ( 'RealStream_Settings' )
OoO0O00IIiII = oo000 . getSetting ( 'Resolver_Settings' )
O0o0 = oo000 . getSetting ( 'restante' )
o0 = oo000 . getSetting ( 'fav' )
ooOooo000oOO = oo000 . getSetting ( 'Fontcolor' )
Oo0oOOo = oo000 . getSetting ( 'MenuColor' )
Oo0OoO00oOO0o = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
OOO00O = 'bienvenida'
OOoOO0oo0ooO = 'bienvenida'
copyright = oo000 . getSetting ( 'copyright' )
O0o0O00Oo0o0 = 'cGx1Z2luLnZpZGVvLg==' . decode ( 'base64' ) + copyright
O00O0oOO00O00 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
i1 = oo000 . getSetting ( 'Forceupdate' )
if i1 == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
Oo00 = '.txt'
if 31 - 31: IIII . I11i / I1IiiI
o000O0o = 'aHR0cDovL2JpdC5seS8yU1FOSnlP' . decode ( 'base64' )
iI1iII1 = Oo0OoO00oOO0o + OOO00O + Oo00
oO0OOoo0OO = 'http://www.youtube.com'
O0ii1ii1ii = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
oooooOoo0ooo = '.xsl.pt'
I1I1IiI1 = 'L21hc3Rlci8=' . decode ( 'base64' )
III1iII1I1ii = O0ii1ii1ii + oooooOoo0ooo
oOOo0 = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*texto3=[\'"](.*?)[\'"]\s*'
oo00O00oO = 'tvg-logo=[\'"](.*?)[\'"]'
if 23 - 23: OOooOOo + OOooOOo . I1Ii111
ii1ii11IIIiiI = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)'
O00OOOoOoo0O = '(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)'
O000OOo00oo = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
oo0OOo = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
ooOOO00Ooo = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
IiIIIi1iIi = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
ooOOoooooo = '#(.+?),(.+)\s*(.+)'
II1I = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
if 84 - 84: o0o0OOO0o0 . II111iiii . o0o0OOO0o0 * iII111i - ooOoO0o
iiO0o0oOOOoOo = 'source src=[\'"](.*?)[\'"]\s*title=[\'"](.*?)[\'"]'
II1 = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
I1iiiI1Ii1I = '[\'"](.*?)[\'"]'
O0OOO0O = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
iiiiIiI = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( 'base64' )
I1 = iiiiIiI + O0
OOO00O0O = '[\'"](.*?)[\'"]'
iii = 'UmVhbHN0cmVhbQ==' . decode ( 'base64' )
oOooOOOoOo = 'video=[\'"](.*?)[\'"]'
i1Iii1i1I = '0110nhu' . replace ( '0110nhu' , 'nhu' )
OOoO00 = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( 'base64' ) + i1Iii1i1I
IiI111111IIII = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
i1Ii = '0110R0N' . replace ( '0110R0N' , 'R0N' )
ii111iI1iIi1 = 'aHR0cDovL2JpdC5seS8yWEIx' . decode ( 'base64' ) + i1Ii
OOO = '0110pEJ' . replace ( '0110pEJ' , 'pEJ' )
oo0OOo0 = 'aHR0cDovL2JpdC5seS8yd1Nh' . decode ( 'base64' ) + OOO
I11IiI = 'ABBAOb5' . replace ( 'ABBAOb5' , 'Ob5' )
O0ooO0Oo00o = 'aHR0cDovL2JpdC5seS8yRVhV' . decode ( 'base64' ) + I11IiI
ooO0oOOooOo0 = '0110jaw' . replace ( '0110jaw' , 'jaw' )
i1I1ii11i1Iii = 'aHR0cDovL2JpdC5seS8yd01M' . decode ( 'base64' ) + ooO0oOOooOo0
I1IiiiiI = '01109DI' . replace ( '01109DI' , '9DI' )
o0OIiII = 'aHR0cDovL2JpdC5seS8ySXgz' . decode ( 'base64' ) + I1IiiiiI
ii1iII1II = '01103hs' . replace ( '01103hs' , '3hs' )
Iii1I1I11iiI1 = 'aHR0cDovL2JpdC5seS8zMW1U' . decode ( 'base64' ) + ii1iII1II
I1I1i1I = '01107DW' . replace ( '01107DW' , '7DW' )
ii1I = 'aHR0cDovL2JpdC5seS8yV1ln' . decode ( 'base64' ) + I1I1i1I
O0oO0 = '0110mLl' . replace ( '0110mLl' , 'mLl' )
oO0 = 'aHR0cDovL2JpdC5seS8yS0cw' . decode ( 'base64' ) + O0oO0
O0OO0O = '01102Hj' . replace ( '01102Hj' , '2Hj' )
OO = 'aHR0cDovL2JpdC5seS8yWEJo' . decode ( 'base64' ) + O0OO0O
OoOoO = '0110fXg' . replace ( '0110fXg' , 'fXg' )
Ii1I1i = 'aHR0cDovL2JpdC5seS8ySTVy' . decode ( 'base64' ) + OoOoO
OOI1iI1ii1II = '0110NMH' . replace ( '0110NMH' , 'NMH' )
O0O0OOOOoo = 'aHR0cDovL2JpdC5seS8yd0t6' . decode ( 'base64' ) + OOI1iI1ii1II
oOooO0 = '0110bwQ' . replace ( '0110bwQ' , 'bwQ' )
Ii1I1Ii = 'aHR0cDovL2JpdC5seS8yd01V' . decode ( 'base64' ) + oOooO0
OOoO0 = '0110xzG' . replace ( '0110xzG' , 'xzG' )
OO0Oooo0oOO0O = 'aHR0cDovL2JpdC5seS8yWHhz' . decode ( 'base64' ) + OOoO0
o00O0 = '0110x64' . replace ( '0110x64' , 'x64' )
oOO0O00Oo0O0o = 'aHR0cDovL2JpdC5seS8yRVlF' . decode ( 'base64' ) + o00O0
ii1 = '0110vUE' . replace ( '0110vUE' , 'vUE' )
I1iIIiiIIi1i = 'aHR0cDovL2JpdC5seS8yWmhW' . decode ( 'base64' ) + ii1
O0O0ooOOO = '01107ZL' . replace ( '01107ZL' , '7ZL' )
oOOo0O00o = 'aHR0cDovL2JpdC5seS8yWm4w' . decode ( 'base64' ) + O0O0ooOOO
iIiIi11 = '01106cf' . replace ( '01106cf' , '6cf' )
OOOiiiiI = 'aHR0cDovL2JpdC5seS8yRVlk' . decode ( 'base64' ) + iIiIi11
oooOo0OOOoo0 = '0110Jtp' . replace ( '0110Jtp' , 'Jtp' )
OOoO = 'aHR0cDovL2JpdC5seS8yV3Nq' . decode ( 'base64' ) + oooOo0OOOoo0
OO0O000 = '0110a5b' . replace ( '0110a5b' , 'a5b' )
iiIiI1i1 = 'aHR0cDovL2JpdC5seS8yV3dj' . decode ( 'base64' ) + OO0O000
oO0O00oOOoooO = '0110Q7u' . replace ( '0110Q7u' , 'Q7u' )
IiIi11iI = 'aHR0cDovL2JpdC5seS8yV3NL' . decode ( 'base64' ) + oO0O00oOOoooO
Oo0O00O000 = '0110rsq' . replace ( '0110rsq' , 'rsq' )
i11I1IiII1i1i = 'aHR0cDovL2JpdC5seS8ySzhE' . decode ( 'base64' ) + Oo0O00O000
oo = '0110DDR' . replace ( '0110DDR' , 'DDR' )
I1111i = 'aHR0cDovL2JpdC5seS8ySzd5' . decode ( 'base64' ) + oo
iIIii = '0110feQ' . replace ( '0110feQ' , 'feQ' )
o00O0O = 'aHR0cDovL2JpdC5seS8yS0cz' . decode ( 'base64' ) + iIIii
ii1iii1i = '0110MHY' . replace ( '0110MHY' , 'MHY' )
Iii1I1111ii = 'aHR0cDovL2JpdC5seS8ySXVo' . decode ( 'base64' ) + ii1iii1i
ooOoO00 = '0110xdb' . replace ( '0110xdb' , 'xdb' )
Ii1IIiI1i = 'aHR0cDovL2JpdC5seS8yWEJu' . decode ( 'base64' ) + ooOoO00
o0O00Oo0 = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( 'base64' )
O0o0O00Oo0o0 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
IiII111i1i11 = '0110lxu' . replace ( '0110lxu' , 'lxu' )
i111iIi1i1II1 = 'aHR0cDovL2JpdC5seS8yV1Bj' . decode ( 'base64' ) + IiII111i1i11
if 86 - 86: Oo0Ooo / I11i . o0oOOo0O0Ooo
if 19 - 19: iII111i % OoO0O00 % o0o0OOO0o0 * Ii1I % I1IiiI
ooo = '1001DTs' . replace ( '1001DTs' , 'DTs' )
i1i1iI1iiiI = 'aHR0cDovL2JpdC5seS8ySzhP' . decode ( 'base64' ) + ooo
if 51 - 51: I1ii11iIi11i % IIII . IiII / Oo0Ooo / ooOoO0o . IiII
if 42 - 42: Ii1I + OoOoOO00 - o00O0oo / o0o0OOO0o0
if 9 - 9: I1IiiI % I1IiiI - Ii1I
if 51 - 51: I1ii11iIi11i . Oo0Ooo - iII111i / I1IiiI
def OOOoO00 ( ) :
 if 40 - 40: iII111i % I1ii11iIi11i . o0O0 . I1IiiI * IIII
 if 4 - 4: o00O0oo % IiII * OOooOOo
 try :
  if 100 - 100: IIII * I1Ii111 + I1Ii111
  OoOO0o = i1II1 ( ii111iI1iIi1 )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   try :
    if 87 - 87: Ii1I
    oo0OOo0 = IiiiiI1i1Iii
    if 29 - 29: I1ii11iIi11i % I1Ii111 - I1ii11iIi11i / I1Ii111 . OoOoOO00
    i11III1111iIi = xbmc . Keyboard ( '' , 'Busqueda por titulo,actor, director, año, servidor:' )
    i11III1111iIi . doModal ( )
    if ( i11III1111iIi . isConfirmed ( ) ) :
     if 38 - 38: IIIIII11i1I + ooOoO0o / IIII % o0O0 - iII111i
     iI11 = urllib . quote_plus ( i11III1111iIi . getText ( ) ) . replace ( '+' , ' ' )
     Ii1Io0OO0o0o00o = i1II1 ( oo0OOo0 )
     i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( Ii1Io0OO0o0o00o )
     if 100 - 100: IiII / IIII / iII111i
     for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
      if re . search ( iI11 , o0OO0o0oOOO0O ( OOOooo . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
       if 2 - 2: o0O0 / IIIIII11i1I . IIIIII11i1I % IIII
   except :
    pass
 except :
  pass
  if 11 - 11: Oo0Ooo
def IiIIII1i11I ( ) :
 if 86 - 86: oO0o . I1IiiI - OoO0O00 . OOooOOo + o00O0oo
 OOoIIii11Ii1i1I = i1II1 ( o0O00Oo0 )
 i11i1 = re . compile ( I1iiiI1Ii1I ) . findall ( OOoIIii11Ii1i1I )
 for Oooo0O in i11i1 :
  try :
   if 90 - 90: Oo0Ooo % o0O0
   import xbmc
   import xbmcaddon
   if 73 - 73: I1IiiI * IIIIII11i1I + o00O0oo + o0O0
   __addon__ = xbmcaddon . Addon ( )
   __addonname__ = __addon__ . getAddonInfo ( 'name' )
   __icon__ = __addon__ . getAddonInfo ( 'icon' )
   if 40 - 40: o0oOOo0O0Ooo . I11i * IIII + I1Ii111 + I1Ii111
   ii = oo000 . getAddonInfo ( 'version' )
   if 9 - 9: ooOoO0o % OoO0O00 . IiII % ooOoO0o
   iiiiI = "[COLOR gold]Version instalada: " + ii + " [/COLOR]" "[COLOR lime]Ultima Version: " + Oooo0O + "  [/COLOR]"
   oOIIiIi = 3000
   if 91 - 91: iII111i * oO0o / I1ii11iIi11i . I1IiiI + OOooOOo + I11i
   xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , iiiiI , oOIIiIi , __icon__ ) )
   if 8 - 8: IiII / iII111i
   if 20 - 20: I1ii11iIi11i
  except :
   pass
   if 95 - 95: IIIIII11i1I - I1ii11iIi11i
   if 34 - 34: o0O0 * I1ii11iIi11i . OoOoOO00 * o0O0 / o0O0
def IIiI1Ii ( ) :
 if 57 - 57: I1Ii111 - o0O0 - ooOoO0o + OOooOOo
 if 30 - 30: o00O0oo % I11i + OoOoOO00 - ooOoO0o - o00O0oo
 i1i1i11IIi = oo000 . getSetting ( 'videos' )
 if i1i1i11IIi == 'true' :
  if 8 - 8: OOooOOo + IIII - Ii1I % oO0o % Ii1I * IiII
  try :
   if 9 - 9: oO0o - II111iiii - I1Ii111 * o00O0oo + o0O0
   import urlresolver
   from urlresolver import common
   import random
   from random import choice
   iIIII = xbmc . Player ( )
   ii1i1I1i = [ 'iHJAKUyjomI' , '_pqbkWaTGX0' , '5sSQINZQjfU' , 'hEl07wzNkaE' , 'hflGH4jKU0k' , '1qP8wVmQ1eI' ]
   iIIIiiI1i1i = random . choice ( ii1i1I1i )
   OooO0OO = 'https://www.youtube.com/watch?v=%s' % iIIIiiI1i1i
   OooO0OO = urlresolver . HostedMediaFile ( OooO0OO ) . resolve ( )
   iIIII . play ( OooO0OO )
   if 32 - 32: I11i / OOooOOo + I1Ii111
   i1i1i11IIi == 'false'
   if 32 - 32: Oo0Ooo % IIIIII11i1I
  except :
   pass
   if 65 - 65: o0O0 . OoO0O00 / iII111i . OoOoOO00 * OOooOOo
   if 19 - 19: II111iiii + OoO0O00 - oO0o - ooOoO0o
 OoOO0o = i1II1 ( iI1iII1 )
 i11i1 = re . compile ( oOOo0 ) . findall ( OoOO0o )
 for Iii1iiIi1II , OO0O00oOo , ii1II in i11i1 :
  try :
   if 14 - 14: IiII / IiII % o0O0
   if 56 - 56: I1ii11iIi11i . I1IiiI + oO0o
   i1II1I1Iii1 = Iii1iiIi1II
   iiI11Iii = OO0O00oOo
   O0o0O0 = ii1II
   if 11 - 11: o0oOOo0O0Ooo % OOooOOo * IIIIII11i1I + o0O0 + o00O0oo
   if 24 - 24: oO0o - IiII % Oo0Ooo . OoOoOO00 / I1IiiI
   iiiiI = "[COLOR=red][B]" + i1II1I1Iii1 + "[/B][/COLOR]"
   ii1ii111 = "[COLOR yellow]" + iiI11Iii + "[/COLOR]"
   I111i1i1111 = "[COLOR yellow]" + O0o0O0 + "[/COLOR]"
   if 49 - 49: OOooOOo / IiII + I1IiiI * Ii1I
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , iiiiI , ii1ii111 , I111i1i1111 )
   if 28 - 28: o0O0 + II111iiii / ooOoO0o % I11i % oO0o - I1IiiI
  except : ooo0OOO ( )
  if 49 - 49: II111iiii % o00O0oo . I11i
  if 13 - 13: II111iiii + OoOoOO00 * Oo0Ooo % OoO0O00 - o0oOOo0O0Ooo * I1Ii111
  if 26 - 26: OoO0O00 * I1ii11iIi11i + I1Ii111
  if 24 - 24: II111iiii % Oo0Ooo + I1Ii111 / II111iiii
  if 70 - 70: OOooOOo * I1IiiI . ooOoO0o + I1ii11iIi11i . o0o0OOO0o0
 if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
  if 14 - 14: Oo0Ooo % Oo0Ooo * II111iiii - OOooOOo - ooOoO0o
  if 63 - 63: OOooOOo
def Oo0 ( ) :
 if 59 - 59: I1ii11iIi11i * o0oOOo0O0Ooo . I1IiiI
 if 56 - 56: o00O0oo - IIIIII11i1I % I1ii11iIi11i - Ii1I
 i1i1i11IIi = oo000 . getSetting ( 'videos' )
 if i1i1i11IIi == 'true' :
  if 51 - 51: I1IiiI / o0O0 * Oo0Ooo + iII111i + Ii1I
  try :
   OOoIIii11Ii1i1I = i1II1 ( o000O0o )
   i11i1 = re . compile ( O00OOOoOoo0O ) . findall ( OOoIIii11Ii1i1I )
   for Oo0OO0000oooo , IIII1iII , ii1III11 , I1iiIIIi11 , Ii1I11ii1i , O0iIiIIIIIii , OOo0 , ii11I1 , oO0oo , Ii111iIi1iIi in i11i1 :
    try :
     import urlresolver
     from urlresolver import common
     import random
     from random import choice
     iIIII = xbmc . Player ( )
     ii1i1I1i = [ Oo0OO0000oooo , IIII1iII , ii1III11 , I1iiIIIi11 , Ii1I11ii1i , O0iIiIIIIIii , OOo0 , ii11I1 , oO0oo , Ii111iIi1iIi ]
     iIIIiiI1i1i = random . choice ( ii1i1I1i )
     OooO0OO = 'https://www.youtube.com/watch?v=%s' % iIIIiiI1i1i
     OooO0OO = urlresolver . HostedMediaFile ( OooO0OO ) . resolve ( )
     iIIII . play ( OooO0OO )
     i1i1i11IIi == 'false'
    except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR red] Trailer no encontrado! [/COLOR] ,3000)" )
    if 21 - 21: IiII / iII111i + o00O0oo + OoO0O00
    if 91 - 91: II111iiii / OoOoOO00 + IIIIII11i1I + o0O0 * II111iiii
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR red] no se pudo conectar al servidor de origen! [/COLOR] ,3000)" )
  if 66 - 66: Oo0Ooo % OoOoOO00 - I1IiiI + ooOoO0o * IIII . o0o0OOO0o0
  if 52 - 52: o0O0 + I1IiiI . IIIIII11i1I . iII111i . OOooOOo
 O0OOO0OOoO0O = oo000 . getSetting ( 'aviso' )
 if O0OOO0OOoO0O == 'true' :
  OoOO0o = i1II1 ( iI1iII1 )
  i11i1 = re . compile ( oOOo0 ) . findall ( OoOO0o )
  for Iii1iiIi1II , OO0O00oOo , ii1II in i11i1 :
   try :
    if 97 - 97: I1ii11iIi11i / IIIIII11i1I
    if 71 - 71: o0oOOo0O0Ooo / OoOoOO00 . iII111i % OoO0O00 . I11i
    i1II1I1Iii1 = Iii1iiIi1II
    iiI11Iii = OO0O00oOo
    O0o0O0 = ii1II
    if 41 - 41: OoOoOO00 * o0oOOo0O0Ooo / OoO0O00 . I1Ii111
    if 83 - 83: IIIIII11i1I . I1IiiI / oO0o / I1Ii111 - o0oOOo0O0Ooo
    iiiiI = "[COLOR=red][B]" + i1II1I1Iii1 + "[/B][/COLOR]"
    ii1ii111 = "[COLOR yellow]" + iiI11Iii + "[/COLOR]"
    I111i1i1111 = "[COLOR yellow]" + O0o0O0 + "[/COLOR]"
    if 100 - 100: OOooOOo
    xbmcgui . Dialog ( ) . ok ( "Real Stream" , iiiiI , ii1ii111 , I111i1i1111 )
    if 46 - 46: I11i / Oo0Ooo % IIIIII11i1I . Oo0Ooo * IIIIII11i1I
   except : ooo0OOO ( )
 else : ooo0OOO ( )
 if 38 - 38: iII111i - IIIIII11i1I / I1IiiI . IIII
def o0OO0o0oOOO0O ( s ) :
 if 45 - 45: IIII
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 83 - 83: I11i . OoO0O00
def Oo0ooo ( file ) :
 if 28 - 28: IiII . o0oOOo0O0Ooo / iII111i + o0oOOo0O0Ooo . OoO0O00 . o0o0OOO0o0
 try :
  O000OOO0OOo = open ( file , 'r' )
  OoOO0o = O000OOO0OOo . read ( )
  O000OOO0OOo . close ( )
  return OoOO0o
 except :
  pass
  if 32 - 32: o00O0oo * I1IiiI
def i1II1 ( url ) :
 if 100 - 100: o0O0 % Oo0Ooo * o0oOOo0O0Ooo - IIIIII11i1I
 try :
  oo00O00oO000o = urllib2 . Request ( url )
  oo00O00oO000o . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  OOo00OoO = urllib2 . urlopen ( oo00O00oO000o )
  iIi1 = OOo00OoO . read ( )
  OOo00OoO . close ( )
  return iIi1
 except urllib2 . URLError , i11iiI1111 :
  print 'We failed to open "%s".' % url
  if hasattr ( i11iiI1111 , 'code' ) :
   print 'We failed with error code - %s.' % i11iiI1111 . code
  if hasattr ( i11iiI1111 , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , i11iiI1111 . reason
   if 97 - 97: oO0o * I1ii11iIi11i . Oo0Ooo
def I1Ii1111iIi ( url ) :
 oo00O00oO000o = urllib2 . Request ( url )
 oo00O00oO000o . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 oo00O00oO000o . add_header ( 'Referer' , '%s' % url )
 oo00O00oO000o . add_header ( 'Connection' , 'keep-alive' )
 OOo00OoO = urllib2 . urlopen ( oo00O00oO000o )
 iIi1 = OOo00OoO . read ( )
 OOo00OoO . close ( )
 return iIi1
 if 31 - 31: ooOoO0o . IIII * o0O0 + II111iiii * IiII
 if 93 - 93: iII111i / Oo0Ooo * OoOoOO00 % OoO0O00 * I1IiiI * ooOoO0o
def Ooooooo ( ) :
 if 39 - 39: o0o0OOO0o0 * oO0o + Oo0Ooo - o0o0OOO0o0 + I1Ii111
 Oo0oOOo = oo000 . getSetting ( 'MenuColor' )
 if 69 - 69: I1IiiI
 if II1III == 'true' :
  o0ooO ( '[COLOR %s]Peliculas[/COLOR] ' % Oo0oOOo , 'movieDB' , 116 , Ooooo , O0oOO0o0 )
  o0ooO ( '[COLOR %s]Series[/COLOR] ' % Oo0oOOo , 'movieDB' , 117 , I1I1i , O0oOO0o0 )
  if 74 - 74: I1IiiI * IiII - II111iiii + IIII
  if 17 - 17: Oo0Ooo . OoO0O00 / ooOoO0o % o0oOOo0O0Ooo % OoOoOO00 / II111iiii
 if O00Oo000ooO0 == 'true' :
  o0ooO ( '[COLOR %s]Ajustes[/COLOR]' % Oo0oOOo , 'Settings' , 119 , oOOOoo0O0OoO , O0oOO0o0 )
  if 58 - 58: oO0o . o0oOOo0O0Ooo + IiII - II111iiii / o0oOOo0O0Ooo / I1IiiI
  if 85 - 85: I11i + I1Ii111
  if i11O0oo0OO0oOOOo == 'true' :
   I1II ( )
   if 27 - 27: o0oOOo0O0Ooo / o00O0oo . I1Ii111
  if OoO0O00IIiII == 'true' :
   i1II11II ( )
   oOo00O000Oo0 ( )
   if 18 - 18: IIIIII11i1I * OOooOOo . OOooOOo * IiII * o0oOOo0O0Ooo * IIII
  if iIi11Ii1 == 'false' :
   if 92 - 92: oO0o
   iiiiI = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   ii1ii111 = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Program.favoritos-realstream para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   I111i1i1111 = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 40 - 40: I11i / o0o0OOO0o0
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , iiiiI , ii1ii111 , I111i1i1111 )
   if 79 - 79: OOooOOo - Oo0Ooo + o00O0oo - IIII
def OoO ( ) :
 o0ooO ( '[COLOR orange]Buscador por id[/COLOR]' , oO0OOoo0OO , 127 , iiI1iIiI , O0oOO0o0 )
 if 35 - 35: I11i + II111iiii - o0oOOo0O0Ooo
def ooo0OOO ( ) :
 if 15 - 15: II111iiii % I1ii11iIi11i * ooOoO0o / IIII
 Oo0oOOo = oo000 . getSetting ( 'MenuColor' )
 o0ooO ( '[COLOR %s]The movie DB[/COLOR]' % Oo0oOOo , 'movieDB' , 99 , iiI1iIiI , O0oOO0o0 )
 o0ooO ( '[COLOR %s]Buscador por id[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 127 , iiI1iIiI , O0oOO0o0 )
 o0ooO ( '[COLOR %s]Video tutoriales[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 125 , OOO0OOO00oo , O0oOO0o0 )
 if 90 - 90: IIIIII11i1I
 if 31 - 31: I1Ii111 + I1IiiI
 if 87 - 87: o0O0
 if 45 - 45: OOooOOo / OoO0O00 - IIIIII11i1I / o00O0oo % o0o0OOO0o0
 if 83 - 83: I1ii11iIi11i . Oo0Ooo - o0o0OOO0o0 * II111iiii
 if 20 - 20: OoOoOO00 * IIII + o0oOOo0O0Ooo % Ii1I % IiII
 o0ooO ( '[COLOR %s]Autorizar OPENLOAD[/COLOR]' % Oo0oOOo , 'movieDB' , 97 , II1Ii1iI1i , O0oOO0o0 )
 if 13 - 13: oO0o
 o0ooO ( '[COLOR %s]listado Proxy[/COLOR]' % Oo0oOOo , 'movieDB' , 112 , Iii111II , O0oOO0o0 )
 Ooooooo ( )
 if 60 - 60: iII111i * I1ii11iIi11i
 if 17 - 17: I1Ii111 % oO0o / iII111i . o0o0OOO0o0 * I1Ii111 - o0oOOo0O0Ooo
 if 41 - 41: o00O0oo
 if 77 - 77: IIII
 if 65 - 65: o0oOOo0O0Ooo . I1ii11iIi11i % IiII * OOooOOo
 if 38 - 38: I11i / IIIIII11i1I % oO0o
 if 11 - 11: IIIIII11i1I - IiII + o0oOOo0O0Ooo - Oo0Ooo
 if 7 - 7: o0o0OOO0o0 - ooOoO0o / o0oOOo0O0Ooo * o00O0oo . IIIIII11i1I * IIIIII11i1I
 if 61 - 61: ooOoO0o % o0O0 - OOooOOo / oO0o
 if 4 - 4: OoO0O00 - OoOoOO00 % o00O0oo - I1Ii111 * Ii1I
 if 85 - 85: OoO0O00 * Oo0Ooo . IIIIII11i1I / OoO0O00 % I1ii11iIi11i % I1IiiI
def I1iii ( ) :
 oO0o0O0Ooo0o = xbmcgui . Dialog ( )
 i1Ii11II = (
 Ii ,
 oO0oOOO0Ooo ,
 )
 if 38 - 38: I1ii11iIi11i
 oOo0OoOOo0 = oO0o0O0Ooo0o . select ( '[B][COLOR=yellow]Listado de Proxys Gratuitos:[/COLOR][/B]' , [
 '[COLOR=orange]                      Accede a la web[/COLOR]' ,

 '[B][COLOR=gold]                      Volver al Menu [/COLOR][/B]' , ] )
 if 30 - 30: iII111i % I1ii11iIi11i
 if oOo0OoOOo0 :
  if 89 - 89: IIII + OoO0O00 + IIII * OoOoOO00 + Oo0Ooo % ooOoO0o
  if oOo0OoOOo0 < 0 :
   return
  oOo0oO = i1Ii11II [ oOo0OoOOo0 - 2 ]
  return oOo0oO ( )
 else :
  oOo0oO = i1Ii11II [ oOo0OoOOo0 ]
  return oOo0oO ( )
 return
 if 5 - 5: I1Ii111 - I1Ii111 . oO0o + I11i - I1Ii111 . IiII
def IiIi1i1ii ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 11 - 11: o0oOOo0O0Ooo / Ii1I
IiIi1 = IiIi1i1ii ( )
if 34 - 34: I1Ii111
def Ii ( ) :
 if IiIi1 == 'android' :
  OooO0ooo0o = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://hidemyna.me/es/proxy-list/?country=ES&type=hs#list' ) )
  if 47 - 47: OoO0O00
 else :
  OooO0ooo0o = webbrowser . open ( 'https://hidemyna.me/es/proxy-list/?country=ES&type=hs#list' )
  if 4 - 4: I1ii11iIi11i % ooOoO0o
  if 10 - 10: o0o0OOO0o0 . OoO0O00 - OOooOOo + o0o0OOO0o0 - I1IiiI
def oO0oOOO0Ooo ( ) :
 if 82 - 82: o0O0 + o0oOOo0O0Ooo
 main ( )
 if 39 - 39: IiII % Oo0Ooo % I1IiiI % OoO0O00 * iII111i + IIIIII11i1I
 if 68 - 68: oO0o + II111iiii
 if 69 - 69: Oo0Ooo * Oo0Ooo * II111iiii + I1ii11iIi11i / I1Ii111 % o00O0oo
 if 58 - 58: I1Ii111 * Ii1I + I1IiiI % I1Ii111
 if 25 - 25: oO0o % iII111i * o0O0
def I11oo0ooOO ( ) :
 if 24 - 24: OOooOOo % OOooOOo * Oo0Ooo
 if xbmc . getCondVisibility ( 'System.HasAddon(plugin.program.favoritos-realstream)' ) :
  if 50 - 50: OOooOOo . II111iiii - IiII . IiII
  xbmc . executebuiltin ( 'RunAddon(plugin.program.favoritos-realstream)' )
  if 31 - 31: I1Ii111 / oO0o * OoOoOO00 . I11i
  if iI1iI1I1i1I == 'true' :
   if 57 - 57: I1Ii111 + Oo0Ooo % OoOoOO00 % I1ii11iIi11i
   xbmcgui . Dialog ( ) . ok ( "[COLOR orange]Real Stream Agradecimientos[/COLOR]" , "[COLOR gold]Netai quiere agradecer el genial trabajo de [/COLOR][COLOR lime][B]Spoyser[/B][/COLOR][COLOR gold] Autor de este genial script que originalmente se conoce como:[/COLOR]" , "[COLOR lime][B]Program.super.favorites[/B][/COLOR]" , "Usted puede descargar el script original desde el repositorio de Kodi >Addons de programas> program.super.favorites" )
   if 83 - 83: Ii1I / II111iiii % Oo0Ooo . ooOoO0o % IiII . OoO0O00
  oo000 . setSetting ( 'Favoritos-anuncio' , 'false' )
 else :
  if 94 - 94: o00O0oo + Oo0Ooo % OOooOOo
  xbmcgui . Dialog ( ) . ok ( "El programa Real stream Favoritos No esta instalado" , "[COLOR green]Necesario AddOn externo para agregar tus peliculas a favoritas dentro del addon.[/COLOR]" , "[COLOR yellow]Puedes agregarlo desde http://netai.eu/netai/ agregando la fuente a tu Kodi, instalar desde archivo zip.[/COLOR]" )
  if 93 - 93: o00O0oo - I1Ii111 + Oo0Ooo * Ii1I + IIII . IIIIII11i1I
def IiI1iII1II111 ( ) :
 oo000 . openSettings ( )
 if 28 - 28: I11i * OOooOOo . ooOoO0o % ooOoO0o / ooOoO0o * IIII
 if 64 - 64: o0oOOo0O0Ooo - I1ii11iIi11i
def O0O0ooOOOo0o00Ooo0o ( ) :
 urlresolver . display_settings ( )
 if 76 - 76: o0oOOo0O0Ooo
def i1II11II ( ) :
 o0ooO ( '[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % Oo0oOOo , 'resolve' , 120 , oOoo , O0oOO0o0 )
 if 26 - 26: o0oOOo0O0Ooo % II111iiii % Oo0Ooo % ooOoO0o * ooOoO0o * iII111i
def IiI1I11iIii ( ) :
 if 63 - 63: IIIIII11i1I * ooOoO0o * o00O0oo - IiII - o00O0oo
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 97 - 97: I1Ii111 / OoO0O00
def oOo00O000Oo0 ( ) :
 o0ooO ( '[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % Oo0oOOo , 'resolve' , 140 , oOoo , O0oOO0o0 )
 if 18 - 18: OOooOOo + Oo0Ooo - o0oOOo0O0Ooo - I1ii11iIi11i
def I1II ( ) :
 if 71 - 71: OoO0O00
 Oo0oOOo = oo000 . getSetting ( 'MenuColor' )
 o0ooO ( '[COLOR %s]Buscador[/COLOR]' % Oo0oOOo , 'search' , 111 , i111I , O0oOO0o0 )
 o0ooO ( '[COLOR %s]Estrenos[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 3 , Ii1IIii11 , O0oOO0o0 )
 o0ooO ( '[COLOR %s]Todas[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 26 , Oooo0000 , O0oOO0o0 )
 o0ooO ( '[COLOR %s]4K[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 141 , II11iiii1Ii , O0oOO0o0 )
 o0ooO ( '[COLOR %s]Novedades[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 2 , OOo , O0oOO0o0 )
 o0ooO ( '[COLOR %s]Accion[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 5 , i11 , O0oOO0o0 )
 o0ooO ( '[COLOR %s]Animacion[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 6 , I11 , O0oOO0o0 )
 o0ooO ( '[COLOR %s]Aventuras[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 7 , Oo0o0000o0o0 , O0oOO0o0 )
 o0ooO ( '[COLOR %s]Belico[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 8 , oOo0oooo00o , O0oOO0o0 )
 o0ooO ( '[COLOR %s]Ciencia Ficcion[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 9 , oO0o0o0ooO0oO , O0oOO0o0 )
 o0ooO ( '[COLOR %s]Comedia[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 10 , oo0o0O00 , O0oOO0o0 )
 o0ooO ( '[COLOR %s]Crimen[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 11 , oO , O0oOO0o0 )
 o0ooO ( '[COLOR %s]Drama[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 12 , i1iiIIiiI111 , O0oOO0o0 )
 o0ooO ( '[COLOR %s]Familiar[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 13 , oooOOOOO , O0oOO0o0 )
 o0ooO ( '[COLOR %s]Fantasia[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 14 , i1iiIII111ii , O0oOO0o0 )
 o0ooO ( '[COLOR %s]Historia[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 15 , i1iIIi1 , O0oOO0o0 )
 o0ooO ( '[COLOR %s]Misterio[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 16 , iI111I11I1I1 , O0oOO0o0 )
 o0ooO ( '[COLOR %s]Musical[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 17 , OOooO0OOoo , O0oOO0o0 )
 o0ooO ( '[COLOR %s]Romance[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 18 , iIii1 , O0oOO0o0 )
 o0ooO ( '[COLOR %s]Thriller[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 19 , II , O0oOO0o0 )
 o0ooO ( '[COLOR %s]Suspense[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 20 , O0OoO000O0OO , O0oOO0o0 )
 o0ooO ( '[COLOR %s]Terror[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 21 , iiI1IiI , O0oOO0o0 )
 o0ooO ( '[COLOR %s]Western[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 22 , ooOoOoo0O , O0oOO0o0 )
 o0ooO ( '[COLOR %s]Spain[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 23 , oOOoO0 , O0oOO0o0 )
 o0ooO ( '[COLOR %s]Super heroes[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 24 , ii11iIi1I , O0oOO0o0 )
 o0ooO ( '[COLOR %s]Sagas[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 25 , OooO0 , O0oOO0o0 )
 if 33 - 33: IIII
 if 62 - 62: iII111i + o00O0oo + OoOoOO00 / OoO0O00
def IIiiii ( ) :
 if 37 - 37: Ii1I % o0O0
 if 83 - 83: I1Ii111 . IIII + IiII - I1Ii111 * IIII / IIII
 try :
  if 39 - 39: IIII / oO0o % OOooOOo % II111iiii
  o0o0Ooo0 = i1II1 ( i1i1iI1iiiI )
  i11i1 = re . compile ( OOO00O0O ) . findall ( o0o0Ooo0 )
  for IiiiiI1i1Iii in i11i1 :
   if 78 - 78: Oo0Ooo + ooOoO0o - o00O0oo * IIII - OoO0O00 % I11i
   try :
    if 34 - 34: I1IiiI
    OooOOOo0 = IiiiiI1i1Iii
    i11III1111iIi = xbmc . Keyboard ( '' , 'Buscar' )
    i11III1111iIi . doModal ( )
    if ( i11III1111iIi . isConfirmed ( ) ) :
     if 54 - 54: o00O0oo - ooOoO0o - IIII . Oo0Ooo
     iI11 = urllib . quote_plus ( i11III1111iIi . getText ( ) ) . replace ( '+' , ' ' )
     OOoIIii11Ii1i1I = i1II1 ( OooOOOo0 )
     i11i1 = re . compile ( O000OOo00oo ) . findall ( OOoIIii11Ii1i1I )
     for i1ii1iIII , OOOooo , O0oOO0o0 , OooO0OO in i11i1 :
      if re . search ( iI11 , o0OO0o0oOOO0O ( OOOooo . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       o0ooO ( OOOooo , OooO0OO , 143 , i1ii1iIII , O0oOO0o0 )
       if 79 - 79: o00O0oo . OOooOOo
   except :
    pass
 except :
  pass
  if 40 - 40: Ii1I + oO0o . Ii1I % o0O0
def I11I1IIiiII1 ( ) :
 if 31 - 31: I1ii11iIi11i * IiII + OoO0O00 - IIIIII11i1I / OoO0O00
 o0ooO ( '[COLOR %s]Buscar Serie[/COLOR]' % Oo0oOOo , 'search' , 145 , Ooo , O0oOO0o0 )
 o0ooO ( '[COLOR %s]Todas[/COLOR]' % Oo0oOOo , oO0OOoo0OO , 142 , O0o0Oo , O0oOO0o0 )
 if 19 - 19: o0o0OOO0o0 * o0O0 * Ii1I + I1IiiI / I1IiiI
 if 73 - 73: Oo0Ooo / Oo0Ooo - IiII
def oOoOOOo ( ) :
 if 43 - 43: OoOoOO00
 try :
  if 23 - 23: IIIIII11i1I + ooOoO0o . I11i * I1ii11iIi11i + iII111i
  o0o0Ooo0 = i1II1 ( i1i1iI1iiiI )
  i11i1 = re . compile ( OOO00O0O ) . findall ( o0o0Ooo0 )
  for IiiiiI1i1Iii in i11i1 :
   if 18 - 18: o0o0OOO0o0 * Ii1I . o0o0OOO0o0 / I1IiiI
   try :
    if 8 - 8: Ii1I
    OooOOOo0 = IiiiiI1i1Iii
    if 4 - 4: iII111i + iII111i * o0O0 - I11i
   except :
    pass
    if 78 - 78: o00O0oo / o0oOOo0O0Ooo % I11i
  OOoIIii11Ii1i1I = i1II1 ( OooOOOo0 )
  i11i1 = re . compile ( O000OOo00oo ) . findall ( OOoIIii11Ii1i1I )
  for i1ii1iIII , OOOooo , O0oOO0o0 , OooO0OO in i11i1 :
   try :
    if 52 - 52: I1Ii111 - IIIIII11i1I * IiII
    o0ooO ( OOOooo , OooO0OO , 143 , i1ii1iIII , O0oOO0o0 )
    if 17 - 17: OoO0O00 + I1Ii111 * ooOoO0o * I11i
   except :
    pass
 except :
  pass
  if 36 - 36: I1IiiI + oO0o
def iIIIi1i1I11i ( name , url ) :
 if 55 - 55: oO0o - I1Ii111
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 84 - 84: IIII + oO0o - I11i * I11i
 Ii1Io0OO0o0o00o = i1II1 ( url )
 i11i1 = re . compile ( ooOOO00Ooo ) . findall ( Ii1Io0OO0o0o00o )
 for OoooO0o , name , O0oOO0o0 , url in i11i1 :
  try :
   if 24 - 24: I11i % OoOoOO00 + IIIIII11i1I . II111iiii . iII111i
   if 17 - 17: iII111i . o0oOOo0O0Ooo . o0O0 / iII111i
   ooOooo000oOO = oo000 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % ooOooo000oOO + name + '[/COLOR]'
   oOooO00o0O ( name , url , 144 , OoooO0o , O0oOO0o0 )
   if 80 - 80: I1Ii111 / ooOoO0o / I11i + OoOoOO00 - oO0o
   if 11 - 11: Ii1I * OOooOOo
  except :
   pass
   if 15 - 15: I11i
   if 62 - 62: o00O0oo
   if 51 - 51: I11i
def oOooO00o0O ( name , url , mode , iconimage , fanart ) :
 if 14 - 14: o0o0OOO0o0 % IiII % oO0o - II111iiii
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 53 - 53: o00O0oo % oO0o
 O0ooOo0o0Oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage="
 OooO0oOo = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 OooO0oOo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 OooO0oOo . setProperty ( 'fanart_image' , fanart )
 OooO0oOo . setProperty ( 'IsPlayable' , 'true' )
 oOOo00O0OOOo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0ooOo0o0Oo , listitem = OooO0oOo )
 return oOOo00O0OOOo
 if 31 - 31: ooOoO0o % I1Ii111 * ooOoO0o
def IiI ( name , url ) :
 if 34 - 34: ooOoO0o % o0O0 . I1IiiI . Oo0Ooo
 if 93 - 93: OoOoOO00 . II111iiii . oO0o
 if 'https://team.com' in url :
  if 99 - 99: ooOoO0o - IIII - IiII % OOooOOo
  url = url . replace ( 'https://team.com' , 'https://verystream.com' )
  if 21 - 21: o0oOOo0O0Ooo % iII111i . OoOoOO00 - OoO0O00
 if 'https://mybox.com' in url :
  if 4 - 4: OoO0O00 . o0O0
  url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
  if 78 - 78: iII111i + ooOoO0o - I1IiiI
 if 'https://drive.com' in url :
  if 10 - 10: IIII % I1ii11iIi11i
  url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
  if 97 - 97: OoO0O00 - IIII
 if 'https://https://vidcloud.co/' in url :
  if 58 - 58: Oo0Ooo + I1IiiI
  url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
  if 30 - 30: o0O0 % IIIIII11i1I * I1Ii111 - iII111i * o00O0oo % o0O0
 if 'https://gounlimited.to' in url :
  if 46 - 46: II111iiii - I1IiiI . IiII
  url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
  if 100 - 100: I1ii11iIi11i / Ii1I * IIIIII11i1I . I1IiiI / I1Ii111
  if 83 - 83: IIII
  if 48 - 48: o0oOOo0O0Ooo * I1Ii111 * IIII
 import resolveurl
 if 50 - 50: o0o0OOO0o0 % OoOoOO00
 iii11II1I = urlresolver . HostedMediaFile ( url )
 if 5 - 5: I11i - o0o0OOO0o0 * o0o0OOO0o0
 if 50 - 50: o0oOOo0O0Ooo * iII111i / o00O0oo . Ii1I + oO0o - I1Ii111
 if not iii11II1I :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
  return False
  if 18 - 18: I11i % II111iiii % iII111i / IiII / Ii1I / OoOoOO00
 try :
  IIi1I1 = iii11II1I . resolve ( )
  if not IIi1I1 or not isinstance ( IIi1I1 , basestring ) :
   try : iIi = IIi1I1 . msg
   except : iIi = url
   raise Exception ( iIi )
 except Exception as i11iiI1111 :
  try : iIi = str ( i11iiI1111 )
  except : iIi = url
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado, reportalo en nuesto grupo de telegram [COLOR ligthblue] https://t.me/OficialNetai [/COLOR]  ,5000)" )
  return False
  if 10 - 10: OOooOOo / oO0o
  if 15 - 15: IIIIII11i1I . I11i / IIIIII11i1I * ooOoO0o - I1ii11iIi11i % iII111i
  if 57 - 57: I1IiiI % I11i % IiII
 Oo0O0O0ooO0O = oo000 . getSetting ( 'notificar' )
 if Oo0O0O0ooO0O == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
  if 45 - 45: iII111i + o0oOOo0O0Ooo * II111iiii
  if 13 - 13: OoO0O00 * IiII - o00O0oo / I1Ii111 + ooOoO0o + o0o0OOO0o0
  iii1III1i = xbmcgui . ListItem ( path = IIi1I1 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iii1III1i )
  if 17 - 17: o0oOOo0O0Ooo / o0oOOo0O0Ooo
 else :
  if 65 - 65: o0o0OOO0o0 + oO0o
  iii1III1i = xbmcgui . ListItem ( path = IIi1I1 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iii1III1i )
  if 59 - 59: OoO0O00 + ooOoO0o . IIII - I1IiiI % Oo0Ooo / I1IiiI
  if 88 - 88: oO0o . I1IiiI % OoO0O00 / I1Ii111
  if 89 - 89: o0oOOo0O0Ooo / IiII
def IIo0OoO00 ( ) :
 if 18 - 18: IiII - Ii1I - I1ii11iIi11i - I1ii11iIi11i
 if 54 - 54: oO0o + I1ii11iIi11i / IIIIII11i1I . I1ii11iIi11i * I11i
 IIiIiiiIIIIi1 = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 IIiIiiiIIIIi1 . doModal ( )
 if not IIiIiiiIIIIi1 . isConfirmed ( ) :
  return None ;
 OOOooo = IIiIiiiIIIIi1 . getText ( ) . strip ( )
 if 39 - 39: OOooOOo / o00O0oo / IIII
 if 81 - 81: ooOoO0o / OOooOOo % OoO0O00 * IiII / IiII
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 28 - 28: II111iiii / Ii1I . Oo0Ooo / o0oOOo0O0Ooo
  OooO0ooo0o = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + OOOooo + '&language=es-ES' ) )
  if 72 - 72: OoO0O00 / I1ii11iIi11i + o00O0oo / I11i * o00O0oo
  if 34 - 34: I1IiiI * I1IiiI % OoO0O00 + IIIIII11i1I * Oo0Ooo % o00O0oo
  return 'android'
  if 25 - 25: ooOoO0o + I11i . Ii1I % I11i * I1Ii111
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 32 - 32: II111iiii - IIII
  OooO0ooo0o = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + OOOooo + '&language=es-ES' )
  if 53 - 53: OoO0O00 - o0o0OOO0o0
  if 87 - 87: IiII . I1ii11iIi11i
  return 'windows'
  if 17 - 17: o00O0oo . II111iiii
  if 5 - 5: iII111i + I1IiiI + I1IiiI . IIII - o0O0
def o00oo0000 ( ) :
 if 44 - 44: oO0o % Oo0Ooo
 try :
  if 90 - 90: o0oOOo0O0Ooo + OoO0O00 % OoO0O00
  OoOO0o = i1II1 ( ii111iI1iIi1 )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 35 - 35: IIIIII11i1I / iII111i * OoO0O00 . o0oOOo0O0Ooo / oO0o
   try :
    if 1 - 1: OoO0O00 + o0o0OOO0o0 . OoOoOO00 % ooOoO0o
    all = IiiiiI1i1Iii
    if 66 - 66: Ii1I + iII111i + I1ii11iIi11i - IiII
   except :
    pass
    if 12 - 12: IIIIII11i1I . o0o0OOO0o0 . I11i / I1IiiI
  Ii1Io0OO0o0o00o = i1II1 ( all )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( Ii1Io0OO0o0o00o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    if 58 - 58: Ii1I - o0oOOo0O0Ooo % IiII + IIII . I11i / o0o0OOO0o0
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 8 - 8: iII111i . OOooOOo * ooOoO0o + o0oOOo0O0Ooo % II111iiii
   except :
    pass
 except :
  pass
  if 8 - 8: o0O0 * I1IiiI
def OOoOIiIIII ( ) :
 if 89 - 89: OOooOOo / I1ii11iIi11i
 try :
  if 16 - 16: oO0o + o0O0 / oO0o / OOooOOo % IiII % iII111i
  OOo = i1II1 ( oo0OOo0 )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OOo )
  for IiiiiI1i1Iii in i11i1 :
   if 22 - 22: o0oOOo0O0Ooo * OOooOOo * ooOoO0o + iII111i * Ii1I
   try :
    if 100 - 100: OoOoOO00 / o0o0OOO0o0
    OooOOOo0 = IiiiiI1i1Iii
    if 3 - 3: o0oOOo0O0Ooo % iII111i - OoO0O00 * oO0o . Oo0Ooo
   except :
    pass
    if 37 - 37: IIIIII11i1I / oO0o . ooOoO0o * ooOoO0o
  OOoIIii11Ii1i1I = i1II1 ( OooOOOo0 )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OOoIIii11Ii1i1I )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    if 80 - 80: I1Ii111 % iII111i
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 91 - 91: ooOoO0o / I1IiiI - o00O0oo . I1ii11iIi11i
   except :
    pass
 except :
  pass
  if 82 - 82: o0o0OOO0o0 * I1Ii111 / IiII
def IiiIiI ( ) :
 if 23 - 23: ooOoO0o
 try :
  if 40 - 40: Ii1I - o0oOOo0O0Ooo / oO0o
  Ii1IIii11 = i1II1 ( O0ooO0Oo00o )
  i11i1 = re . compile ( OOO00O0O ) . findall ( Ii1IIii11 )
  for IiiiiI1i1Iii in i11i1 :
   if 14 - 14: iII111i
   try :
    iI1 = IiiiiI1i1Iii
   except :
    pass
    if 14 - 14: iII111i
  OoOO0o = i1II1 ( iI1 )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 49 - 49: IiII / OoOoOO00 % o00O0oo . I1ii11iIi11i
   except :
    pass
 except :
  pass
  if 93 - 93: I1Ii111
def iIii1Ooo0oO0 ( ) :
 if 86 - 86: I1IiiI
 try :
  if 95 - 95: IIIIII11i1I * I1Ii111 . I11i . OoOoOO00 . OoOoOO00 - Ii1I
  OoOO0o = i1II1 ( db2 )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 26 - 26: Oo0Ooo % II111iiii % iII111i
   try :
    if 67 - 67: OoO0O00
    IiIiIi1I1 = IiiiiI1i1Iii
    if 2 - 2: OoOoOO00 - o0O0 + I1ii11iIi11i . Ii1I * Ii1I / I11i
   except :
    pass
    if 93 - 93: OoOoOO00
    if 53 - 53: OoO0O00 + oO0o + IiII
  OoOO0o = i1II1 ( IiIiIi1I1 )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 24 - 24: IIIIII11i1I - o0o0OOO0o0 - IIIIII11i1I * iII111i . OoO0O00 / o0o0OOO0o0
   except :
    pass
 except :
  pass
  if 66 - 66: oO0o
def Oooo00oOo ( ) :
 if 14 - 14: o0o0OOO0o0 % ooOoO0o / Oo0Ooo - o0O0
 try :
  if 98 - 98: IIII
  OoOO0o = i1II1 ( i1I1ii11i1Iii )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 92 - 92: IIII - Oo0Ooo
   try :
    if 32 - 32: o00O0oo % OOooOOo * OOooOOo + o0o0OOO0o0 * o0oOOo0O0Ooo * o00O0oo
    iIiIii1I1II = IiiiiI1i1Iii
    if 61 - 61: o0o0OOO0o0 + Oo0Ooo + II111iiii / II111iiii % o0oOOo0O0Ooo
   except :
    pass
    if 42 - 42: o00O0oo * IIII . o0o0OOO0o0 * I1ii11iIi11i + I11i
    if 25 - 25: ooOoO0o . I1ii11iIi11i + IiII
  OoOO0o = i1II1 ( iIiIii1I1II )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 75 - 75: o0o0OOO0o0 - Ii1I % IIIIII11i1I + II111iiii
   except :
    pass
 except :
  pass
  if 100 - 100: ooOoO0o + Ii1I - II111iiii - o0oOOo0O0Ooo
def iIIIiIi1I1i ( ) :
 if 78 - 78: Oo0Ooo % I11i + iII111i / OoOoOO00 % o0oOOo0O0Ooo + I1Ii111
 try :
  if 91 - 91: Oo0Ooo % OOooOOo . Ii1I + o00O0oo + Ii1I
  OoOO0o = i1II1 ( o0OIiII )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 95 - 95: o00O0oo + iII111i * I1Ii111
   try :
    if 16 - 16: ooOoO0o / I1ii11iIi11i + OOooOOo % Oo0Ooo - OoOoOO00 . IiII
    iIi1iIIIiIiI = IiiiiI1i1Iii
    if 62 - 62: II111iiii % I1Ii111 . o0o0OOO0o0 . I1Ii111
   except :
    pass
    if 84 - 84: II111iiii * OOooOOo
  OoOO0o = i1II1 ( iIi1iIIIiIiI )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 18 - 18: I1Ii111 - o00O0oo - I11i / IIII - I1IiiI
   except :
    pass
 except :
  pass
  if 30 - 30: I1IiiI + iII111i + o0oOOo0O0Ooo
def III1I ( ) :
 if 11 - 11: o0O0 - I1Ii111 + o0O0 * IiII / I1ii11iIi11i
 try :
  if 53 - 53: Oo0Ooo + Ii1I - I11i - IiII / o0O0 % II111iiii
  OoOO0o = i1II1 ( Iii1I1I11iiI1 )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 3 - 3: IIIIII11i1I . o0O0 % I1ii11iIi11i + iII111i
   try :
    if 64 - 64: OoOoOO00
    IIii1 = IiiiiI1i1Iii
    if 35 - 35: II111iiii - I1ii11iIi11i / I1Ii111 + o00O0oo * IiII
   except :
    pass
    if 49 - 49: Ii1I * o00O0oo + ooOoO0o + IIIIII11i1I
    if 30 - 30: Ii1I / I1Ii111 / o0o0OOO0o0 % o0O0 + o0oOOo0O0Ooo
  OoOO0o = i1II1 ( IIii1 )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 4 - 4: IIIIII11i1I - oO0o - o0o0OOO0o0 - ooOoO0o % II111iiii / OOooOOo
   except :
    pass
 except :
  pass
  if 50 - 50: o0O0 + OoOoOO00
def i11IiIIi11I ( ) :
 if 78 - 78: o0o0OOO0o0
 try :
  if 83 - 83: Oo0Ooo % I11i % Ii1I % IIII . iII111i % I1IiiI
  OoOO0o = i1II1 ( ii1I )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 47 - 47: Ii1I
   try :
    if 66 - 66: I1ii11iIi11i - o0o0OOO0o0
    iiIii = IiiiiI1i1Iii
    if 28 - 28: IiII
   except :
    pass
    if 52 - 52: I1ii11iIi11i + Oo0Ooo
    if 71 - 71: I1IiiI / IiII
  OoOO0o = i1II1 ( iiIii )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 34 - 34: I11i . Oo0Ooo % I1IiiI
   except :
    pass
 except :
  pass
  if 43 - 43: iII111i - IIIIII11i1I
def O000O ( ) :
 if 98 - 98: Oo0Ooo + IIII % I11i + ooOoO0o % I11i
 try :
  if 24 - 24: IiII * IIII
  OoOO0o = i1II1 ( oO0 )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 40 - 40: o00O0oo - I11i * I11i . I11i + OoO0O00
   try :
    if 77 - 77: Oo0Ooo . o00O0oo % IiII / o00O0oo
    oOO0OO = IiiiiI1i1Iii
    if 82 - 82: OOooOOo % Ii1I % I1Ii111 / I1IiiI
   except :
    pass
    if 94 - 94: iII111i + iII111i + OoO0O00 % o0O0
    if 7 - 7: IIIIII11i1I
  OoOO0o = i1II1 ( oOO0OO )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 78 - 78: I1Ii111 + IIIIII11i1I . o0o0OOO0o0
   except :
    pass
 except :
  pass
  if 91 - 91: Oo0Ooo . Ii1I . iII111i + OoO0O00
  if 69 - 69: IIII - I1ii11iIi11i
def oOoo0OooOOo00 ( ) :
 if 36 - 36: OoOoOO00 * oO0o % oO0o / Ii1I + I11i - OoO0O00
 try :
  if 39 - 39: OoO0O00 * I1Ii111 * I1IiiI . ooOoO0o . OOooOOo + o0O0
  OoOO0o = i1II1 ( OO )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 9 - 9: I11i + IiII % OoO0O00 + Ii1I
   try :
    if 56 - 56: OoO0O00 + iII111i - IIIIII11i1I
    III1I1 = IiiiiI1i1Iii
    if 12 - 12: Oo0Ooo % o0O0 % o0O0
   except :
    pass
    if 78 - 78: o0o0OOO0o0 . I11i . ooOoO0o
    if 97 - 97: IiII
  OoOO0o = i1II1 ( III1I1 )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 80 - 80: I1ii11iIi11i . o00O0oo
   except :
    pass
 except :
  pass
  if 47 - 47: ooOoO0o + o0O0 + o0oOOo0O0Ooo % II111iiii
  if 93 - 93: iII111i % I11i . I1IiiI / IIIIII11i1I * IiII
def i1iii1ii ( ) :
 if 18 - 18: OOooOOo . o0oOOo0O0Ooo % I11i % o00O0oo
 try :
  if 87 - 87: Oo0Ooo . OoO0O00 * I11i
  OoOO0o = i1II1 ( Ii1I1i )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 100 - 100: OOooOOo / OoOoOO00 - I1ii11iIi11i % o00O0oo - Oo0Ooo
   try :
    if 17 - 17: ooOoO0o / Ii1I % oO0o
    o0o = IiiiiI1i1Iii
    if 93 - 93: o0O0 % II111iiii % IIII
   except :
    pass
    if 64 - 64: IIII + I1ii11iIi11i * I1IiiI / oO0o - ooOoO0o % ooOoO0o
    if 59 - 59: I1Ii111 + OoO0O00
  OoOO0o = i1II1 ( o0o )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 55 - 55: II111iiii % Oo0Ooo . OoOoOO00 + OoO0O00 / II111iiii
   except :
    pass
    if 10 - 10: IIIIII11i1I - IiII * Oo0Ooo % Oo0Ooo * o0o0OOO0o0 - iII111i
 except :
  pass
  if 97 - 97: o0oOOo0O0Ooo % IIII + IIII - OOooOOo / o00O0oo * I1ii11iIi11i
  if 17 - 17: o00O0oo
def i1i1IiIi1 ( ) :
 if 22 - 22: ooOoO0o * I1IiiI . o0oOOo0O0Ooo - OOooOOo
 try :
  if 90 - 90: IiII
  OoOO0o = i1II1 ( O0O0OOOOoo )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 94 - 94: ooOoO0o / iII111i * IIII - I11i
   try :
    if 44 - 44: o00O0oo % II111iiii - IIIIII11i1I * iII111i + oO0o * I1Ii111
    IiI1iI1IiiIi1 = IiiiiI1i1Iii
    if 90 - 90: I1IiiI + ooOoO0o - OoO0O00 . ooOoO0o
   except :
    pass
    if 60 - 60: Ii1I . Ii1I / IIIIII11i1I
    if 45 - 45: I1IiiI . II111iiii % IIIIII11i1I . I11i % o0o0OOO0o0 % Oo0Ooo
  OoOO0o = i1II1 ( IiI1iI1IiiIi1 )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 58 - 58: Oo0Ooo . I11i - II111iiii * Oo0Ooo % II111iiii / I1ii11iIi11i
   except :
    pass
    if 80 - 80: iII111i / Oo0Ooo % I11i
 except :
  pass
  if 80 - 80: OOooOOo % IIIIII11i1I
def O0Oo0 ( ) :
 if 80 - 80: I1ii11iIi11i - Oo0Ooo . I1Ii111 + OOooOOo - IIII
 try :
  if 5 - 5: IIIIII11i1I
  OoOO0o = i1II1 ( Ii1I1Ii )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 62 - 62: I11i . OoO0O00 . I1Ii111 . OOooOOo * IIIIII11i1I
   try :
    if 78 - 78: IiII / OOooOOo - IiII * OoO0O00 . I11i
    OOoooOoO0Oo = IiiiiI1i1Iii
    if 78 - 78: OoO0O00 / I1Ii111 % I11i * OoO0O00
   except :
    pass
    if 68 - 68: IiII
  OoOO0o = i1II1 ( OOoooOoO0Oo )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 29 - 29: IIIIII11i1I + II111iiii % ooOoO0o
   except :
    pass
 except :
  pass
  if 93 - 93: I11i % Oo0Ooo
  if 90 - 90: I1ii11iIi11i - I1Ii111 / o00O0oo / I1IiiI / ooOoO0o
def oOO0 ( ) :
 if 15 - 15: oO0o + ooOoO0o . o0O0 - Oo0Ooo / I1IiiI % Oo0Ooo
 try :
  if 86 - 86: I1ii11iIi11i / IiII * o00O0oo
  OoOO0o = i1II1 ( OO0Oooo0oOO0O )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 64 - 64: o0O0 / I1IiiI * I11i * o0O0
   try :
    if 60 - 60: ooOoO0o / OoOoOO00 % iII111i / iII111i * iII111i . II111iiii
    o0oOO00 = IiiiiI1i1Iii
    if 46 - 46: II111iiii - ooOoO0o
   except :
    pass
    if 95 - 95: o0oOOo0O0Ooo
    if 65 - 65: I11i
  OoOO0o = i1II1 ( o0oOO00 )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 31 - 31: ooOoO0o * I11i . o0o0OOO0o0 % o00O0oo + oO0o
   except :
    pass
 except :
  pass
  if 47 - 47: I1IiiI * I1ii11iIi11i * OOooOOo . o0oOOo0O0Ooo
  if 95 - 95: o00O0oo % o0o0OOO0o0 . I1IiiI % IIII
def OOOii1i1iiI ( ) :
 if 94 - 94: OoOoOO00 * OoOoOO00 % o0oOOo0O0Ooo + I1Ii111
 try :
  if 28 - 28: I1ii11iIi11i
  OoOO0o = i1II1 ( oOO0O00Oo0O0o )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 49 - 49: ooOoO0o . Ii1I % IiII / o00O0oo
   try :
    if 95 - 95: I1IiiI * I11i * o0o0OOO0o0 . o0O0 / Oo0Ooo
    I1IIi1I = IiiiiI1i1Iii
    if 14 - 14: IiII + I1IiiI / o0o0OOO0o0
   except :
    pass
  OoOO0o = i1II1 ( I1IIi1I )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 24 - 24: OOooOOo - IiII + iII111i / IIIIII11i1I % I1ii11iIi11i + Oo0Ooo
   except :
    pass
 except :
  pass
  if 79 - 79: I11i / o0O0
def oOo00o ( ) :
 if 98 - 98: I1Ii111 % OoOoOO00 . I1ii11iIi11i . o0oOOo0O0Ooo . iII111i / II111iiii
 try :
  if 32 - 32: Ii1I + I1ii11iIi11i . IIII
  OoOO0o = i1II1 ( I1iIIiiIIi1i )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 41 - 41: I11i . II111iiii / ooOoO0o
   try :
    if 98 - 98: I11i % o0oOOo0O0Ooo
    OoO0O000 = IiiiiI1i1Iii
    if 14 - 14: OOooOOo / OOooOOo * I1IiiI . IiII
   except :
    pass
    if 59 - 59: o0oOOo0O0Ooo * II111iiii
    if 54 - 54: I1IiiI % OoO0O00 - I1ii11iIi11i
  OoOO0o = i1II1 ( OoO0O000 )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 61 - 61: oO0o * o0o0OOO0o0 . oO0o + oO0o / o0o0OOO0o0 * I1IiiI
   except :
    pass
 except :
  pass
  if 73 - 73: IIIIII11i1I * IIIIII11i1I / o0O0
  if 43 - 43: iII111i . OoOoOO00 . o0o0OOO0o0 + I1IiiI * o00O0oo * I1IiiI
def II11ii ( ) :
 if 39 - 39: IIIIII11i1I . I1ii11iIi11i * I11i - II111iiii
 try :
  if 1 - 1: IIIIII11i1I * I11i
  OoOO0o = i1II1 ( oOOo0O00o )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 66 - 66: I11i + OoOoOO00 % o0oOOo0O0Ooo . I1IiiI * iII111i % iII111i
   try :
    if 87 - 87: I1Ii111 + Ii1I . IIIIII11i1I - OoO0O00
    iiiiI1IiI1I1 = IiiiiI1i1Iii
    if 19 - 19: o00O0oo
   except :
    pass
    if 55 - 55: I1Ii111 % I1Ii111 / I1IiiI % IIIIII11i1I - Ii1I . oO0o
    if 49 - 49: Oo0Ooo * OoOoOO00 . OoO0O00
  OoOO0o = i1II1 ( iiiiI1IiI1I1 )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 90 - 90: Ii1I % iII111i - Oo0Ooo % I11i
   except :
    pass
 except :
  pass
  if 8 - 8: I11i * oO0o / o0o0OOO0o0 % o00O0oo - I1ii11iIi11i
def oo0ooooo00o ( ) :
 if 78 - 78: Oo0Ooo . Ii1I % Oo0Ooo . I1IiiI / I1Ii111
 try :
  if 76 - 76: OoOoOO00 * OoO0O00 * I1IiiI + IIII * IIII
  OoOO0o = i1II1 ( OOOiiiiI )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 35 - 35: Ii1I
   try :
    if 73 - 73: I1IiiI - iII111i
    ii1IoO0O = IiiiiI1i1Iii
    if 59 - 59: OoO0O00 * oO0o + OoOoOO00
   except :
    pass
    if 23 - 23: o0O0
    if 13 - 13: Oo0Ooo
  OoOO0o = i1II1 ( ii1IoO0O )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 77 - 77: II111iiii - Oo0Ooo / IiII / o0O0 / OOooOOo
   except :
    pass
 except :
  pass
  if 56 - 56: OoO0O00 * I1IiiI
  if 85 - 85: OoO0O00 % I11i * Oo0Ooo
def IiIo0o0OO0o00o0O ( ) :
 if 28 - 28: OOooOOo - IiII + I11i + o00O0oo / Oo0Ooo
 try :
  if 26 - 26: Oo0Ooo - I1IiiI . I1IiiI
  OoOO0o = i1II1 ( OOoO )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 68 - 68: I1Ii111 + IiII . I1IiiI . o00O0oo % OoOoOO00 % I1Ii111
   try :
    if 50 - 50: o0o0OOO0o0 + Ii1I
    o0OoOOo = IiiiiI1i1Iii
    if 56 - 56: ooOoO0o / Oo0Ooo + I11i % I1Ii111 . I1Ii111 - iII111i
   except :
    pass
    if 48 - 48: oO0o - o0O0 + oO0o - I1ii11iIi11i * II111iiii . IIIIII11i1I
    if 35 - 35: o0o0OOO0o0 . I1IiiI + oO0o + I1Ii111 + OoOoOO00
  OoOO0o = i1II1 ( o0OoOOo )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 65 - 65: I1IiiI * I1ii11iIi11i / I1ii11iIi11i . I11i
   except :
    pass
 except :
  pass
  if 87 - 87: o0oOOo0O0Ooo * iII111i % oO0o * oO0o
  if 58 - 58: I1Ii111 . Ii1I + I1ii11iIi11i % oO0o - OOooOOo
def I1Iii1Ii1i1 ( ) :
 if 10 - 10: IIIIII11i1I . OoOoOO00 + o00O0oo
 try :
  if 66 - 66: OOooOOo % Ii1I
  OoOO0o = i1II1 ( iiIiI1i1 )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 21 - 21: I11i - OoO0O00 % II111iiii
   try :
    if 71 - 71: OoOoOO00 - ooOoO0o * IIII + IiII - OOooOOo % iII111i
    Ooo0oO = IiiiiI1i1Iii
    if 32 - 32: OoOoOO00 . IIIIII11i1I + o0oOOo0O0Ooo - OOooOOo - Oo0Ooo
   except :
    pass
    if 20 - 20: I11i % iII111i
    if 44 - 44: OoO0O00 . o0oOOo0O0Ooo . I1Ii111 % OoO0O00
  OoOO0o = i1II1 ( Ooo0oO )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 86 - 86: II111iiii + I1IiiI * o0o0OOO0o0 - OOooOOo * I1Ii111 + I1IiiI
   except :
    pass
 except :
  pass
  if 95 - 95: Oo0Ooo . IIII % IIIIII11i1I - IIII * o0oOOo0O0Ooo
  if 89 - 89: IIIIII11i1I . I1ii11iIi11i
def ooOoo0OoOO ( ) :
 if 38 - 38: OOooOOo / o0O0 % IIII * ooOoO0o + II111iiii % o0O0
 try :
  if 61 - 61: IIII - o00O0oo % iII111i / o0O0 / IIIIII11i1I + Oo0Ooo
  OoOO0o = i1II1 ( IiIi11iI )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 87 - 87: IIII + o0O0 + I1IiiI / OoOoOO00 % o0o0OOO0o0 / IIII
   try :
    if 64 - 64: OOooOOo % o0o0OOO0o0 . IIII % OOooOOo + ooOoO0o * o0o0OOO0o0
    OOOO00OooO = IiiiiI1i1Iii
    if 64 - 64: OOooOOo . I1ii11iIi11i - OoO0O00 . o0O0 - IIIIII11i1I
   except :
    pass
    if 77 - 77: o00O0oo % I11i / o0oOOo0O0Ooo % IIIIII11i1I % OoO0O00 % OOooOOo
    if 19 - 19: o0o0OOO0o0 * IIII / IiII * IIII - OoO0O00 * ooOoO0o
  OoOO0o = i1II1 ( OOOO00OooO )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 17 - 17: o0oOOo0O0Ooo + oO0o . IIII
   except :
    pass
 except :
  pass
  if 12 - 12: IIII + I1Ii111 + ooOoO0o . o0o0OOO0o0 / o00O0oo
  if 29 - 29: o0o0OOO0o0 . o0O0 - o0oOOo0O0Ooo
def ooooO0 ( ) :
 if 37 - 37: II111iiii + I1ii11iIi11i . I1Ii111 % ooOoO0o % ooOoO0o
 try :
  if 26 - 26: I1IiiI
  OoOO0o = i1II1 ( i11I1IiII1i1i )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 34 - 34: o0O0 * IIII
   try :
    if 97 - 97: II111iiii % IiII / oO0o / oO0o
    OoO00ooO = IiiiiI1i1Iii
    if 15 - 15: II111iiii
   except :
    pass
    if 13 - 13: ooOoO0o * o0oOOo0O0Ooo * IiII * o0oOOo0O0Ooo % o0o0OOO0o0 / I1ii11iIi11i
  OoOO0o = i1II1 ( OoO00ooO )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 100 - 100: o0o0OOO0o0 . o00O0oo - Oo0Ooo . II111iiii / o0oOOo0O0Ooo
   except :
    pass
 except :
  pass
  if 71 - 71: IIII * oO0o . ooOoO0o
  if 49 - 49: o0o0OOO0o0 * I1IiiI . o0o0OOO0o0
def ii1II1II ( ) :
 if 42 - 42: o00O0oo
 try :
  if 68 - 68: I1Ii111 . oO0o % o0O0 - OoO0O00 * IIIIII11i1I . I1Ii111
  OoOO0o = i1II1 ( I1111i )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 46 - 46: II111iiii - I1Ii111 * I1ii11iIi11i * ooOoO0o % iII111i * OoOoOO00
   try :
    if 5 - 5: I1IiiI / o0O0 . oO0o + OoO0O00
    O0o = IiiiiI1i1Iii
    if 78 - 78: I1Ii111 % Oo0Ooo
   except :
    pass
    if 50 - 50: I1ii11iIi11i % Oo0Ooo % I1Ii111
    if 84 - 84: o0o0OOO0o0 + iII111i + o00O0oo + IIIIII11i1I
  OoOO0o = i1II1 ( O0o )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 62 - 62: II111iiii + I11i + OoOoOO00
   except :
    pass
 except :
  pass
  if 69 - 69: I11i
def OO0Oo ( ) :
 if 13 - 13: Ii1I * II111iiii / II111iiii . OOooOOo . I1Ii111 . iII111i
 try :
  if 26 - 26: Ii1I . Oo0Ooo
  OoOO0o = i1II1 ( o00O0O )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 67 - 67: oO0o / I1IiiI
   try :
    if 88 - 88: I11i - I1Ii111
    o0oo0O0oOoooO = IiiiiI1i1Iii
    if 70 - 70: IiII * IiII + oO0o * I1Ii111 % I1ii11iIi11i + Oo0Ooo
   except :
    pass
  OoOO0o = i1II1 ( o0oo0O0oOoooO )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 2 - 2: II111iiii
   except :
    pass
 except :
  pass
  if 98 - 98: IiII / OOooOOo - o00O0oo - I1ii11iIi11i / I11i + II111iiii
def i1I1IiI1ii ( ) :
 if 64 - 64: IIIIII11i1I * iII111i % o0oOOo0O0Ooo - I11i + iII111i
 try :
  if 62 - 62: I11i % Ii1I % I1ii11iIi11i + o0o0OOO0o0 . OOooOOo
  OoOO0o = i1II1 ( Iii1I1111ii )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 48 - 48: I1ii11iIi11i * II111iiii % o0oOOo0O0Ooo
   try :
    if 20 - 20: OoOoOO00 / I1ii11iIi11i * IiII
    Oo0O0000Oo00o = IiiiiI1i1Iii
    if 20 - 20: OOooOOo . I1ii11iIi11i * II111iiii / II111iiii
   except :
    pass
  OoOO0o = i1II1 ( Oo0O0000Oo00o )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 89 - 89: IIIIII11i1I . II111iiii * I1IiiI
   except :
    pass
 except :
  pass
  if 44 - 44: OoOoOO00 . I1ii11iIi11i / II111iiii + o0o0OOO0o0
def iI111II1ii ( ) :
 if 62 - 62: IIIIII11i1I * Oo0Ooo . o0o0OOO0o0 - OoO0O00 * o0oOOo0O0Ooo
 try :
  if 45 - 45: I1IiiI % I1ii11iIi11i - IIIIII11i1I . OOooOOo
  OoOO0o = i1II1 ( i111iIi1i1II1 )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 42 - 42: IIIIII11i1I / Ii1I + oO0o . oO0o % I1Ii111
   try :
    if 16 - 16: OoOoOO00 + OOooOOo % I11i + o00O0oo * oO0o
    i1o0oo0 = IiiiiI1i1Iii
    if 67 - 67: I1IiiI * ooOoO0o - Ii1I - o0oOOo0O0Ooo
   except :
    pass
  OoOO0o = i1II1 ( i1o0oo0 )
  i11i1 = re . compile ( ii1ii11IIIiiI ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iI ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 41 - 41: I1ii11iIi11i - IIII % o0oOOo0O0Ooo . IIII - ooOoO0o
   except :
    pass
 except :
  pass
  if 45 - 45: o00O0oo - I1Ii111
def OOoooO00o0o ( ) :
 if 10 - 10: o00O0oo - II111iiii . iII111i % OoOoOO00
 try :
  if 78 - 78: Oo0Ooo * oO0o . oO0o - I1Ii111 . Oo0Ooo
  OoOO0o = i1II1 ( Ii1IIiI1i )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 30 - 30: o0O0 + o0O0 % o0o0OOO0o0 - Ii1I - iII111i
   try :
    if 36 - 36: ooOoO0o % I1Ii111
    OoO0 = IiiiiI1i1Iii
    if 37 - 37: ooOoO0o
   except :
    pass
  OoOO0o = i1II1 ( OoO0 )
  i11i1 = re . compile ( ooOOoooooo ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO in i11i1 :
   try :
    o0iIIIIi ( oOoOOo0O , OOOooo , OooO0OO )
    if 50 - 50: IIII + o0O0 + IIIIII11i1I
   except :
    pass
    if 15 - 15: ooOoO0o
 except :
  pass
  if 13 - 13: Oo0Ooo * I11i / IIII % o0O0 + IiII
  if 41 - 41: iII111i
  if 5 - 5: oO0o
def o0iIIIIi ( thumb , name , url ) :
 if 100 - 100: o00O0oo + Oo0Ooo
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( oo00O00oO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   o0ooO ( name , url , '' , i1ii1iIII , O0oOO0o0 )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 59 - 59: o0o0OOO0o0
  if 'tvg-logo' in thumb :
   thumb = re . compile ( oo00O00oO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 89 - 89: I11i % Oo0Ooo
   III11I1 ( name , url , 4 , OoooO0o , O0oOO0o0 )
   if 61 - 61: I11i - OOooOOo + I1ii11iIi11i * I1Ii111 % OOooOOo
  else :
   if 24 - 24: o0O0 - ooOoO0o * IiII
   III11I1 ( name , url , 4 , OoooO0o , O0oOO0o0 )
   if 87 - 87: o00O0oo - iII111i % iII111i . IiII / iII111i
   if 6 - 6: I11i / Oo0Ooo * OoO0O00 * II111iiii
def iI ( name , url , thumb , id , trailer ) :
 if 79 - 79: o0o0OOO0o0 % OOooOOo
 if 81 - 81: II111iiii + II111iiii * OOooOOo + o0o0OOO0o0
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 32 - 32: I1IiiI . OoO0O00
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( oo00O00oO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   o0ooO ( name , url , '' , i1ii1iIII , O0oOO0o0 )
 else :
  ooOooo000oOO = oo000 . getSetting ( 'Fontcolor' )
  if 15 - 15: I1ii11iIi11i . OOooOOo
  name = '[COLOR %s]' % ooOooo000oOO + name + '[/COLOR]'
  if 17 - 17: II111iiii / oO0o . OOooOOo / I1ii11iIi11i
  if 'tvg-logo' in thumb :
   thumb = re . compile ( oo00O00oO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   OO00Oo = oo000 . getSetting ( 'selecton' )
   if OO00Oo == 'true' :
    if 38 - 38: OoOoOO00 . iII111i % o00O0oo + Oo0Ooo + I1IiiI
    iIi1i11 ( name , url , 1 , thumb , thumb , id , trailer )
    if 25 - 25: I1ii11iIi11i % I1IiiI + OoOoOO00 - o0O0
   else :
    if 38 - 38: Ii1I % IIII + II111iiii + IIIIII11i1I + o0O0 / II111iiii
    iIi1i11 ( name , url , 130 , thumb , thumb , id , trailer )
    if 94 - 94: IIIIII11i1I - oO0o + IiII
  else :
   if 59 - 59: ooOoO0o . I1ii11iIi11i - Oo0Ooo + Oo0Ooo
   if OO00Oo == 'true' :
    if 56 - 56: IiII + o0O0
    iIi1i11 ( name , url , 1 , thumb , thumb , id , trailer )
    if 32 - 32: o0oOOo0O0Ooo + I11i % o0O0 / I11i + iII111i
   else :
    if 2 - 2: II111iiii - IIII + OOooOOo % ooOoO0o * o00O0oo
    iIi1i11 ( name , url , 130 , thumb , thumb , id , trailer )
    if 54 - 54: I1IiiI - IIIIII11i1I . I1Ii111 % IIIIII11i1I + IIIIII11i1I
def i1iI1Iiii1I ( name , trailer ) :
 if 9 - 9: ooOoO0o / I11i / o0oOOo0O0Ooo + IIII
 if 71 - 71: IIIIII11i1I / oO0o
 OooO0OO = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
 OOOO0Oo = OooO0OO
 iIiI1 = xbmcgui . ListItem ( name , trailer , path = OOOO0Oo )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iIiI1 )
 return
 if 20 - 20: I1Ii111 * o0oOOo0O0Ooo - I11i - IiII * IIII
 if 6 - 6: o0O0 + I1Ii111 / oO0o + o0o0OOO0o0 % o0oOOo0O0Ooo / OOooOOo
def iiIi ( name , url ) :
 import urlresolver
 from urlresolver import common
 if 74 - 74: I1IiiI + OoO0O00 / IiII / I11i . iII111i % IiII
 iii11II1I = urlresolver . HostedMediaFile ( url )
 if 34 - 34: OoOoOO00 . I1ii11iIi11i
 if not iii11II1I :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
  if 6 - 6: IIII % IiII % o00O0oo
  return False
  if 63 - 63: I1IiiI . I1ii11iIi11i . I1IiiI * Oo0Ooo
  if 92 - 92: IiII / I1Ii111 . iII111i
 try :
  IIi1I1 = iii11II1I . resolve ( )
  if not IIi1I1 or not isinstance ( IIi1I1 , basestring ) :
   try : iIi = IIi1I1 . msg
   except : iIi = url
   raise Exception ( iIi )
 except Exception as i11iiI1111 :
  try : iIi = str ( i11iiI1111 )
  except : iIi = url
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,5000)" )
  if 30 - 30: o00O0oo . iII111i / I1Ii111
  return False
  if 2 - 2: o0o0OOO0o0 % I1ii11iIi11i - IIII
 Oo0O0O0ooO0O = oo000 . getSetting ( 'notificar' )
 if Oo0O0O0ooO0O == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
 iii1III1i = xbmcgui . ListItem ( path = IIi1I1 )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iii1III1i )
 if 79 - 79: OoO0O00 / iII111i . I1IiiI
def oOoO0Oo0 ( name , url ) :
 if 7 - 7: o0O0 + o00O0oo
 if 32 - 32: Oo0Ooo % I1ii11iIi11i / II111iiii + I1Ii111 - Ii1I . IIIIII11i1I
 if 'https://www.rapidvideo.com/v/' in url :
  if 86 - 86: OoOoOO00 / o00O0oo * I1ii11iIi11i
  OoOO0o = i1II1 ( url )
  i11i1 = re . compile ( 'rapidvideo' ) . findall ( OoOO0o )
  for url in i11i1 :
   if 67 - 67: iII111i * iII111i / IiII * OoO0O00 + I11i
   if 79 - 79: OoOoOO00
   try :
    Oo0O0O0ooO0O = oo000 . getSetting ( 'notificar' )
    if Oo0O0O0ooO0O == 'true' :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    iii1III1i = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iii1III1i )
    if 1 - 1: IiII / OoOoOO00
   except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 74 - 74: ooOoO0o / OoO0O00 / oO0o * II111iiii . o0oOOo0O0Ooo . OoO0O00
   if 59 - 59: II111iiii . OoO0O00 / ooOoO0o * iII111i + OoO0O00
 else :
  if 3 - 3: II111iiii * oO0o % Oo0Ooo % I1ii11iIi11i * IIIIII11i1I / I1Ii111
  import urlresolver
  from urlresolver import common
  if 95 - 95: o0o0OOO0o0 * I1IiiI * IIII . OoO0O00 % oO0o + iII111i
  iii11II1I = urlresolver . HostedMediaFile ( url )
  if 98 - 98: IiII . OoO0O00
  if not iii11II1I :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 54 - 54: I1IiiI / o0o0OOO0o0 % o0O0 * OoOoOO00 * I1IiiI
   if 48 - 48: Ii1I . IiII % I11i - I11i
  try :
   IIi1I1 = iii11II1I . resolve ( )
   if not IIi1I1 or not isinstance ( IIi1I1 , basestring ) :
    try : iIi = IIi1I1 . msg
    except : iIi = url
    raise Exception ( iIi )
  except Exception as i11iiI1111 :
   try : iIi = str ( i11iiI1111 )
   except : iIi = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 33 - 33: ooOoO0o % o0oOOo0O0Ooo + OOooOOo
  Oo0O0O0ooO0O = oo000 . getSetting ( 'notificar' )
  if Oo0O0O0ooO0O == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  iii1III1i = xbmcgui . ListItem ( path = IIi1I1 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iii1III1i )
  if 93 - 93: OoOoOO00 . o0o0OOO0o0 / I1ii11iIi11i + o0o0OOO0o0
 return
 if 58 - 58: iII111i + I1IiiI . oO0o + I11i - OOooOOo - I11i
 if 41 - 41: oO0o / OoOoOO00 / oO0o - IIIIII11i1I . Ii1I
 if 65 - 65: I1IiiI * II111iiii . OoO0O00 / I1ii11iIi11i / IIIIII11i1I
def o00000oo00 ( name , url ) :
 if 41 - 41: I1Ii111 - Ii1I + o00O0oo
 IIi1I1 = url
 Oo0O0O0ooO0O = oo000 . getSetting ( 'notificar' )
 if Oo0O0O0ooO0O == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  iii1III1i = xbmcgui . ListItem ( path = IIi1I1 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iii1III1i )
 else :
  iii1III1i = xbmcgui . ListItem ( path = IIi1I1 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iii1III1i )
 return
 if 15 - 15: ooOoO0o / Ii1I + o00O0oo
def O0oo00o ( name , url ) :
 if 45 - 45: iII111i + IIII . IIIIII11i1I . IIIIII11i1I
 if 34 - 34: OOooOOo % Ii1I % I1ii11iIi11i
 if '[Youtube]' in name :
  if 3 - 3: OoO0O00 * I1ii11iIi11i * IiII - o0o0OOO0o0 - o0O0
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 21 - 21: OoO0O00 - iII111i . I11i
  try :
   Oo0O0O0ooO0O = oo000 . getSetting ( 'notificar' )
   if Oo0O0O0ooO0O == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    iii1III1i = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iii1III1i )
    if 90 - 90: Oo0Ooo
    if 56 - 56: I1Ii111
    if 49 - 49: o0O0 . o0oOOo0O0Ooo
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 24 - 24: I1IiiI . OoO0O00 - OOooOOo * OoO0O00
  if 12 - 12: I1IiiI + o0o0OOO0o0 * OoOoOO00 . OOooOOo
 else :
  if 71 - 71: IIII - Ii1I - I1Ii111
  import xbmcgui
  import urlresolver
  from urlresolver import common
  if 28 - 28: Oo0Ooo
  iii11II1I = urlresolver . HostedMediaFile ( url )
  if 7 - 7: Ii1I % o0o0OOO0o0 * I11i
  if not iii11II1I :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 58 - 58: o0o0OOO0o0 / ooOoO0o + o0oOOo0O0Ooo % IIIIII11i1I - OoO0O00
  import resolveurl as urlresolver
  if 25 - 25: I11i % OoO0O00 * oO0o - OoOoOO00 * o0oOOo0O0Ooo * IiII
  iii11II1I = urlresolver . HostedMediaFile ( url )
  if 30 - 30: ooOoO0o % I11i / iII111i * I1IiiI * o00O0oo . I1ii11iIi11i
  if 46 - 46: I11i - I1IiiI
  if not iii11II1I :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 70 - 70: ooOoO0o + oO0o * Oo0Ooo . I1ii11iIi11i * ooOoO0o
  try :
   IIi1I1 = iii11II1I . resolve ( )
   if not IIi1I1 or not isinstance ( IIi1I1 , basestring ) :
    try : iIi = IIi1I1 . msg
    except : iIi = url
    raise Exception ( iIi )
  except Exception as i11iiI1111 :
   try : iIi = str ( i11iiI1111 )
   except : iIi = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 49 - 49: Ii1I
   if 25 - 25: IIIIII11i1I . OoO0O00 * Oo0Ooo . Ii1I / I1IiiI + o00O0oo
   if 68 - 68: oO0o
  Oo0O0O0ooO0O = oo000 . getSetting ( 'notificar' )
  if Oo0O0O0ooO0O == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 22 - 22: I1Ii111
   if '[Realstream]' in name :
    if 22 - 22: IIIIII11i1I * ooOoO0o - oO0o * I1IiiI / II111iiii
    O0o0 = oo000 . getSetting ( 'restante' )
    if O0o0 == 'true' :
     oO0o0O0Ooo0o = xbmcgui . Dialog ( )
     oOOo00O0OOOo = oO0o0O0Ooo0o . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 78 - 78: oO0o * I1IiiI / o0O0 + OoO0O00 + I1Ii111
   iii1III1i = xbmcgui . ListItem ( path = IIi1I1 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iii1III1i )
   if 23 - 23: IIIIII11i1I % OoO0O00 / Oo0Ooo + iII111i / OoOoOO00 / Ii1I
   if 94 - 94: OoOoOO00
   if 36 - 36: I1ii11iIi11i + oO0o
 return
 if 46 - 46: IIIIII11i1I
 if 65 - 65: OoOoOO00 . iII111i / o0O0
 if 11 - 11: o0o0OOO0o0 * o0O0 / o0O0 - I1Ii111
def OoO0o0OOOO ( name , url ) :
 if 39 - 39: iII111i / OoOoOO00 * o0o0OOO0o0 - I1ii11iIi11i
 if 74 - 74: I1IiiI - o0oOOo0O0Ooo + OoOoOO00 . IIII . iII111i
 if '[Youtube]' in name :
  if 95 - 95: o0oOOo0O0Ooo / o00O0oo - o0O0 - o0oOOo0O0Ooo - II111iiii
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 85 - 85: Ii1I / IIII
  try :
   Oo0O0O0ooO0O = oo000 . getSetting ( 'notificar' )
   if Oo0O0O0ooO0O == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    iii1III1i = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iii1III1i )
    if 67 - 67: ooOoO0o % IiII
    if 39 - 39: II111iiii + o0o0OOO0o0
    if 7 - 7: Oo0Ooo - OoOoOO00
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 10 - 10: IIII % I1IiiI / I1ii11iIi11i % ooOoO0o
 else :
  if 25 - 25: o0oOOo0O0Ooo / OOooOOo
  import resolveurl
  if 64 - 64: I1IiiI % o0O0
  iii11II1I = urlresolver . HostedMediaFile ( url )
  if 40 - 40: Ii1I + ooOoO0o
  if 77 - 77: II111iiii % o0o0OOO0o0 + IIII % OoO0O00 - ooOoO0o
  if not iii11II1I :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 26 - 26: oO0o + I1IiiI - Oo0Ooo
  try :
   IIi1I1 = iii11II1I . resolve ( )
   if not IIi1I1 or not isinstance ( IIi1I1 , basestring ) :
    try : iIi = IIi1I1 . msg
    except : iIi = url
    raise Exception ( iIi )
  except Exception as i11iiI1111 :
   try : iIi = str ( i11iiI1111 )
   except : iIi = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 47 - 47: OoO0O00
   if 2 - 2: I11i % IIII * oO0o * I11i
   if 65 - 65: II111iiii + oO0o * OoO0O00 - OOooOOo
  Oo0O0O0ooO0O = oo000 . getSetting ( 'notificar' )
  if Oo0O0O0ooO0O == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 26 - 26: Ii1I % I1Ii111 + I1Ii111 % ooOoO0o * II111iiii / IIIIII11i1I
   if '[Realstream]' in name :
    if 64 - 64: IiII % I11i / o0oOOo0O0Ooo % o0O0 - IIIIII11i1I
    O0o0 = oo000 . getSetting ( 'restante' )
    if O0o0 == 'true' :
     oO0o0O0Ooo0o = xbmcgui . Dialog ( )
     oOOo00O0OOOo = oO0o0O0Ooo0o . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 2 - 2: IIII - iII111i + Ii1I * OOooOOo / IIIIII11i1I
   iii1III1i = xbmcgui . ListItem ( path = IIi1I1 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iii1III1i )
   if 26 - 26: I1Ii111 * oO0o
   if 31 - 31: ooOoO0o * IiII . o00O0oo
   if 35 - 35: ooOoO0o
 return
 if 94 - 94: o0O0 / II111iiii % I1IiiI
 if 70 - 70: ooOoO0o - oO0o / OoO0O00 % OoO0O00
 if 95 - 95: OoO0O00 % OoO0O00 . o00O0oo
def III1ii ( name , url ) :
 if 38 - 38: iII111i + I11i
 if 68 - 68: I1IiiI
 if '[Youtube]' in name :
  if 76 - 76: iII111i
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 99 - 99: Ii1I
  try :
   Oo0O0O0ooO0O = oo000 . getSetting ( 'notificar' )
   if Oo0O0O0ooO0O == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    iii1III1i = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iii1III1i )
    if 1 - 1: o00O0oo * I11i * OOooOOo + oO0o
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 90 - 90: IIII % oO0o - oO0o . Oo0Ooo / I1Ii111 + ooOoO0o
 else :
  if 89 - 89: IiII
  if 'https://team.com' in url :
   if 87 - 87: IIIIII11i1I % oO0o
   url = url . replace ( 'https://team.com' , 'https://verystream.com' )
   if 62 - 62: OOooOOo + o0O0 / IIIIII11i1I * II111iiii
  if 'https://mybox.com' in url :
   if 37 - 37: IIIIII11i1I
   url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
   if 33 - 33: OOooOOo - I1IiiI - OOooOOo
  if 'https://drive.com' in url :
   if 94 - 94: o0o0OOO0o0 * ooOoO0o * OoO0O00 / Ii1I . o0o0OOO0o0 - Ii1I
   url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
   if 13 - 13: I1Ii111 / o0o0OOO0o0 - OOooOOo / I1Ii111 . OoOoOO00
  if 'https://https://vidcloud.co/' in url :
   if 22 - 22: I1IiiI - ooOoO0o + IIII . o00O0oo * OoOoOO00
   url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
   if 26 - 26: Oo0Ooo * Ii1I . ooOoO0o
  if 'https://gounlimited.to' in url :
   if 10 - 10: IIII * IiII % oO0o - ooOoO0o % oO0o
   url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
   if 65 - 65: IIIIII11i1I * Oo0Ooo / I1IiiI . ooOoO0o
  import resolveurl
  if 94 - 94: oO0o . o0O0 * II111iiii - Ii1I . IIIIII11i1I
  iii11II1I = urlresolver . HostedMediaFile ( url )
  if 98 - 98: I1Ii111 + o00O0oo
  if 52 - 52: oO0o / I11i - IIII . IIIIII11i1I
  if not iii11II1I :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 50 - 50: Oo0Ooo - IIIIII11i1I - ooOoO0o
  try :
   IIi1I1 = iii11II1I . resolve ( )
   if not IIi1I1 or not isinstance ( IIi1I1 , basestring ) :
    try : iIi = IIi1I1 . msg
    except : iIi = url
    raise Exception ( iIi )
  except Exception as i11iiI1111 :
   try : iIi = str ( i11iiI1111 )
   except : iIi = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace borrado, reportalo en nuesto grupo de telegram [/COLOR][COLOR ligthblue] https://t.me/OficialNetai [/COLOR]  ,5000)" )
   return False
   if 60 - 60: Oo0Ooo * o0O0
   if 71 - 71: I11i % oO0o % o0O0
   if 34 - 34: ooOoO0o / ooOoO0o % o0o0OOO0o0 . I11i / oO0o
   Oo0O0O0ooO0O = oo000 . getSetting ( 'notificar' )
   if Oo0O0O0ooO0O == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
    if 99 - 99: o0O0 * I1ii11iIi11i - o0O0 % o00O0oo
    if '[Realstream]' or '[Mybox]' in name :
     O0o0 = oo000 . getSetting ( 'restante' )
    elif O0o0 == 'true' :
     oO0o0O0Ooo0o = xbmcgui . Dialog ( )
     oOOo00O0OOOo = oO0o0O0Ooo0o . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 40 - 40: I1Ii111 / o0o0OOO0o0 / Oo0Ooo + o00O0oo
  iii1III1i = xbmcgui . ListItem ( path = IIi1I1 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iii1III1i )
  if 59 - 59: ooOoO0o * OoO0O00 + I1Ii111 . Oo0Ooo / OoOoOO00
 return
 if 75 - 75: ooOoO0o . I1Ii111 - Oo0Ooo * OOooOOo * IIIIII11i1I
 if 93 - 93: o0O0
 if 18 - 18: o0O0
def OOOooO00OO00O ( ) :
 if 78 - 78: o0oOOo0O0Ooo - oO0o - I1IiiI . I1Ii111 + II111iiii - iII111i
 if 58 - 58: o00O0oo % OoO0O00
 IIii11i = [ ]
 oO0OOO00 = sys . argv [ 2 ]
 if len ( oO0OOO00 ) >= 2 :
  I1iIiI1iiiiI1 = sys . argv [ 2 ]
  IIII1ii1 = I1iIiI1iiiiI1 . replace ( '?' , '' )
  if ( I1iIiI1iiiiI1 [ len ( I1iIiI1iiiiI1 ) - 1 ] == '/' ) :
   I1iIiI1iiiiI1 = I1iIiI1iiiiI1 [ 0 : len ( I1iIiI1iiiiI1 ) - 2 ]
  OOO0O0OOo = IIII1ii1 . split ( '&' )
  IIii11i = { }
  for Iii1 in range ( len ( OOO0O0OOo ) ) :
   OOoOi1IiiI = { }
   OOoOi1IiiI = OOO0O0OOo [ Iii1 ] . split ( '=' )
   if ( len ( OOoOi1IiiI ) ) == 2 :
    IIii11i [ OOoOi1IiiI [ 0 ] ] = OOoOi1IiiI [ 1 ]
 return IIii11i
 if 70 - 70: ooOoO0o . I1Ii111 * oO0o / I1Ii111
 if 83 - 83: OoO0O00 + OOooOOo * IiII . I1IiiI
def iiIIIi1i ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  import urlresolver
  xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
  if 1 - 1: oO0o * IIII . OoO0O00
def oOO00OO0o0O ( ) :
 oO0o0O0Ooo0o = xbmcgui . Dialog ( )
 list = (
 III1IiiIiiI1i ,
 OoO0o00OoO
 )
 if 95 - 95: I1ii11iIi11i % IIII * I1ii11iIi11i + I1IiiI . IIII % OoO0O00
 oOo0OoOOo0 = oO0o0O0Ooo0o . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=%s]Accede a themoviedb.com[/COLOR]' % Oo0oOOo ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 6 - 6: I11i - o0O0 * Ii1I + I11i % Ii1I
 if oOo0OoOOo0 :
  if 100 - 100: OOooOOo % IIII - ooOoO0o % ooOoO0o % ooOoO0o / o0O0
  if oOo0OoOOo0 < 0 :
   return
  oOo0oO = list [ oOo0OoOOo0 - 2 ]
  return oOo0oO ( )
 else :
  oOo0oO = list [ oOo0OoOOo0 ]
  return oOo0oO ( )
 return
 if 83 - 83: IiII - o0O0 - o0o0OOO0o0 % OoOoOO00 - IIIIII11i1I . Ii1I
def IiIi1i1ii ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 96 - 96: oO0o + IIII . OoOoOO00
IiIi1 = IiIi1i1ii ( )
if 54 - 54: o0oOOo0O0Ooo . OoOoOO00 / iII111i % I1ii11iIi11i / IIII
def III1IiiIiiI1i ( ) :
 if IiIi1 == 'android' :
  OooO0ooo0o = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  OooO0ooo0o = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 65 - 65: I11i . I11i - IiII + oO0o / II111iiii
  if 90 - 90: Oo0Ooo + I11i
def OoO0o00OoO ( ) :
 if 9 - 9: Oo0Ooo . OoO0O00 + OoOoOO00 - oO0o
 main ( )
 if 30 - 30: IIIIII11i1I / OOooOOo . IIIIII11i1I
 if 17 - 17: oO0o + OoO0O00 * OoO0O00
 if 5 - 5: IIII % OoO0O00 . I11i
def oO00o00 ( ) :
 oO0o0O0Ooo0o = xbmcgui . Dialog ( )
 i1Ii11II = (
 OOooooO0o0O0 ,
 oO0ooo00o0o000Oo
 )
 if 100 - 100: OoOoOO00 - II111iiii . IIII * OOooOOo
 oOo0OoOOo0 = oO0o0O0Ooo0o . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 62 - 62: I1IiiI
 if oOo0OoOOo0 :
  if 41 - 41: OoOoOO00 - I1ii11iIi11i
  if oOo0OoOOo0 < 0 :
   return
  oOo0oO = i1Ii11II [ oOo0OoOOo0 - 2 ]
  return oOo0oO ( )
 else :
  oOo0oO = i1Ii11II [ oOo0OoOOo0 ]
  return oOo0oO ( )
 return
 if 48 - 48: I1ii11iIi11i - o0oOOo0O0Ooo / OOooOOo + I1ii11iIi11i
def IiIi1i1ii ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 5 - 5: I1IiiI
IiIi1 = IiIi1i1ii ( )
if 75 - 75: IIII + Oo0Ooo
def OOooooO0o0O0 ( ) :
 if IiIi1 == 'android' :
  OooO0ooo0o = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  OooO0ooo0o = webbrowser . open ( 'https://olpair.com/' )
  if 19 - 19: I1ii11iIi11i + II111iiii . o0o0OOO0o0 - ooOoO0o / o00O0oo + Ii1I
  if 38 - 38: oO0o / Oo0Ooo * Oo0Ooo % iII111i
def oO0ooo00o0o000Oo ( ) :
 if 92 - 92: ooOoO0o / I1IiiI * I1ii11iIi11i - ooOoO0o
 main ( )
 if 99 - 99: II111iiii % OoO0O00
 if 56 - 56: o0o0OOO0o0 * IIII
def O00oO0O ( name , url , id , trailer ) :
 oO0o0O0Ooo0o = xbmcgui . Dialog ( )
 i1Ii11II = (
 IiiI111I11 ,
 oO0Ooooo000 ,
 Iii1Iiii ,
 oOO00OO0o0O ,
 i1i1Ii1IiIII
 )
 if 9 - 9: ooOoO0o - IiII + I1IiiI / IIIIII11i1I % OoOoOO00
 oOo0OoOOo0 = oO0o0O0Ooo0o . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % Oo0oOOo ,

 '[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % Oo0oOOo ,

 '[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % Oo0oOOo ,

 '[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % Oo0oOOo ,

 '[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % Oo0oOOo ] )
 if 97 - 97: Ii1I * o0O0
 if oOo0OoOOo0 :
  if 78 - 78: ooOoO0o . I1Ii111 + IiII * IIIIII11i1I - OoOoOO00
  if oOo0OoOOo0 < 0 :
   return
  oOo0oO = i1Ii11II [ oOo0OoOOo0 - 5 ]
  return oOo0oO ( )
 else :
  oOo0oO = i1Ii11II [ oOo0OoOOo0 ]
  return oOo0oO ( )
 return
 if 27 - 27: o00O0oo % OoOoOO00 . oO0o % IIII
 if 10 - 10: o0o0OOO0o0 / OoO0O00
 if 50 - 50: II111iiii - OoO0O00 . IiII + I1IiiI . OoOoOO00
def IiiI111I11 ( ) :
 if 91 - 91: Ii1I . IIIIII11i1I % oO0o - IIIIII11i1I . IiII % II111iiii
 III1ii ( OOOooo , OooO0OO )
 if 25 - 25: Oo0Ooo
def oO0Ooooo000 ( ) :
 if 63 - 63: o0O0
 i1iI1Iiii1I ( OOOooo , o0OOo0o0O0O )
 if 96 - 96: ooOoO0o
def Iii1Iiii ( ) :
 if 34 - 34: I11i / OOooOOo - I1ii11iIi11i . I1IiiI . I1Ii111
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  oooO0o0oOoO = id
  if 23 - 23: o0o0OOO0o0 + Oo0Ooo % Oo0Ooo / o0O0 . IiII + Oo0Ooo
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % oooO0o0oOoO )
  if 93 - 93: IiII * Ii1I / I1Ii111 - I1Ii111 . IIIIII11i1I / I1ii11iIi11i
 if Oo0O0O0ooO0O == 'true' :
  if 11 - 11: IIII - ooOoO0o % II111iiii . Oo0Ooo * I1ii11iIi11i - oO0o
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + OOOooo + "[/COLOR] ,5000)" )
  if 73 - 73: I1IiiI + o0O0 - I1IiiI / OoO0O00 * oO0o
def iI1I1IiIII ( ) :
 if 54 - 54: iII111i + iII111i + ooOoO0o % OoOoOO00 % II111iiii
 oOO00OO0o0O ( )
 if 100 - 100: iII111i
def i1i1Ii1IiIII ( ) :
 if 96 - 96: I1ii11iIi11i . o0o0OOO0o0 * o0oOOo0O0Ooo % o0o0OOO0o0 . IIII * OoOoOO00
 ooo0OOO ( )
def o0ooO ( name , url , mode , iconimage , fanart ) :
 if 83 - 83: Oo0Ooo
 O0ooOo0o0Oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 oOOo00O0OOOo = True
 OooO0oOo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 OooO0oOo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 OooO0oOo . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  O0ooOo0o0Oo = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  oOOo00O0OOOo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0ooOo0o0Oo , listitem = OooO0oOo , isFolder = True )
  return oOOo00O0OOOo
 oOOo00O0OOOo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0ooOo0o0Oo , listitem = OooO0oOo , isFolder = True )
 return oOOo00O0OOOo
 if 97 - 97: II111iiii + oO0o * I1Ii111 % IIIIII11i1I . o0o0OOO0o0
def iIi1i11 ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 4 - 4: I1IiiI . IIIIII11i1I - Oo0Ooo
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 I1iII11ii1 = [ ]
 O0ooOo0o0Oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 OooO0oOo = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 OooO0oOo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 OooO0oOo . setProperty ( 'fanart_image' , fanart )
 OooO0oOo . setProperty ( 'IsPlayable' , 'true' )
 if 4 - 4: II111iiii - I1Ii111 % iII111i * IIII % Ii1I
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  I1iII11ii1 . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  OooO0oOo . addContextMenuItems ( I1iII11ii1 , replaceItems = True )
 oOOo00O0OOOo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0ooOo0o0Oo , listitem = OooO0oOo )
 return oOOo00O0OOOo
 if 71 - 71: o0O0 . o0O0 - Oo0Ooo
def III11I1 ( name , url , mode , iconimage , fanart ) :
 if 22 - 22: OoO0O00 / iII111i % IIIIII11i1I * I11i
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 32 - 32: OoO0O00 % IiII % Oo0Ooo / I1IiiI
 O0ooOo0o0Oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 OooO0oOo = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 OooO0oOo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 OooO0oOo . setProperty ( 'fanart_image' , fanart )
 OooO0oOo . setProperty ( 'IsPlayable' , 'true' )
 oOOo00O0OOOo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0ooOo0o0Oo , listitem = OooO0oOo )
 return oOOo00O0OOOo
 if 61 - 61: o0oOOo0O0Ooo . I1IiiI - o00O0oo - iII111i / II111iiii - o0oOOo0O0Ooo
def O0oo0oOo ( name , url , mode ) :
 if 40 - 40: ooOoO0o % o0O0
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 71 - 71: OOooOOo
 O0ooOo0o0Oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 OooO0oOo = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = OoooO0o )
 OooO0oOo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 OooO0oOo . setProperty ( 'fanart_image' , O0oOO0o0 )
 OooO0oOo . setProperty ( 'IsPlayable' , 'true' )
 oOOo00O0OOOo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0ooOo0o0Oo , listitem = OooO0oOo )
 return oOOo00O0OOOo
 if 75 - 75: IIIIII11i1I
def II1iiI ( name , url , mode , iconimage ) :
 O0ooOo0o0Oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 oOOo00O0OOOo = True
 OooO0oOo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 oOOo00O0OOOo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0ooOo0o0Oo , listitem = OooO0oOo , isFolder = True )
 return oOOo00O0OOOo
 if 89 - 89: ooOoO0o
def O0o0O0O0O ( ) :
 if 79 - 79: o0o0OOO0o0 + o0o0OOO0o0 + o00O0oo
 if 39 - 39: I1IiiI - OoO0O00
 if 63 - 63: Oo0Ooo % Ii1I * o0O0
 i11III1111iIi = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 i11III1111iIi . doModal ( )
 if ( i11III1111iIi . isConfirmed ( ) ) :
  if 79 - 79: I1IiiI
  iI11 = urllib . quote_plus ( i11III1111iIi . getText ( ) ) . replace ( '+' , ' ' )
  if 32 - 32: o0oOOo0O0Ooo . I1IiiI + o00O0oo / I11i / o0o0OOO0o0 / I1Ii111
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 15 - 15: iII111i
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % iI11 )
    if 4 - 4: o0o0OOO0o0 + Oo0Ooo * IIIIII11i1I + oO0o * Ii1I % o0oOOo0O0Ooo
    if Oo0O0O0ooO0O == 'true' :
     if 88 - 88: IiII - OoOoOO00 % II111iiii % o0oOOo0O0Ooo * OoO0O00
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + OOOooo + "[/COLOR] ,10000)" )
     if 40 - 40: oO0o
   except :
    if 47 - 47: I11i
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 65 - 65: I1IiiI + IIII % o00O0oo * I1ii11iIi11i / o0O0 / I11i
    if 71 - 71: II111iiii / I11i . IiII
    if 33 - 33: IiII
I1iIiI1iiiiI1 = OOOooO00OO00O ( )
OooO0OO = None
OOOooo = None
IIIi11 = None
OoooO0o = None
id = None
o0OOo0o0O0O = None
if 69 - 69: I1IiiI - I1IiiI
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 41 - 41: o0o0OOO0o0 % Ii1I
try :
 OooO0OO = urllib . unquote_plus ( I1iIiI1iiiiI1 [ "url" ] )
except :
 pass
try :
 OOOooo = urllib . unquote_plus ( I1iIiI1iiiiI1 [ "name" ] )
except :
 pass
try :
 IIIi11 = int ( I1iIiI1iiiiI1 [ "mode" ] )
except :
 pass
try :
 OoooO0o = urllib . unquote_plus ( I1iIiI1iiiiI1 [ "iconimage" ] )
except :
 pass
try :
 id = int ( I1iIiI1iiiiI1 [ "id" ] )
except :
 pass
try :
 o0OOo0o0O0O = urllib . unquote_plus ( I1iIiI1iiiiI1 [ "trailer" ] )
except :
 pass
 if 67 - 67: I1IiiI % IIII
 if 35 - 35: I1ii11iIi11i . I11i + OoO0O00 % oO0o % I1Ii111
print "Mode: " + str ( IIIi11 )
print "URL: " + str ( OooO0OO )
print "Name: " + str ( OOOooo )
print "iconimage: " + str ( OoooO0o )
print "id: " + str ( id )
print "trailer: " + str ( o0OOo0o0O0O )
if 39 - 39: o00O0oo
if IIIi11 == None or OooO0OO == None or len ( OooO0OO ) < 1 :
 if O0o0O00Oo0o0 == O00O0oOO00O00 :
  if 60 - 60: I1Ii111
  IiIIII1i11I ( )
  O0OOO0OOoO0O = oo000 . getSetting ( 'aviso' )
  if O0OOO0OOoO0O == 'true' :
   Oo0 ( )
   if 62 - 62: IIII * ooOoO0o
   if 74 - 74: I11i . Oo0Ooo
  Ii11iII1 = oo000 . getSetting ( 'licencia_addon' )
  i1Iii1i1I = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  if 87 - 87: o0O0
  OOoO00 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  IIo0oo0OO = oo000 . getSetting ( 'key_ext' )
  OoOO0o = i1II1 ( OOoO00 )
  i11i1 = re . compile ( OOO00O0O ) . findall ( OoOO0o )
  for i11Ii1 in i11i1 :
   try :
    if 2 - 2: o0o0OOO0o0 - IiII % OOooOOo + Ii1I + o00O0oo - Oo0Ooo
    if 18 - 18: iII111i / oO0o - IIIIII11i1I
    Ii11iII1 = oo000 . getSetting ( 'licencia_addon' )
    if 69 - 69: IiII / o0o0OOO0o0 * o0O0
    if 81 - 81: IiII
    if Ii11iII1 == i11Ii1 :
     if 62 - 62: o00O0oo + I1IiiI * OOooOOo
     xbmcgui . Dialog ( ) . ok ( "Realstream Licencia:" , "[COLOR lime]Su llave es correcta![/COLOR] [COLOR gold]Sientese y disfrute de Realstream.[/COLOR]" )
     if 59 - 59: o0oOOo0O0Ooo
     ooo0OOO ( )
     if 43 - 43: oO0o + OoO0O00
    else :
     if 47 - 47: o0O0
     xbmcgui . Dialog ( ) . ok ( "Realstream Licencia:" , "[COLOR red]Ha introducido una llave erronea.[/COLOR] [COLOR gold]Ponganse en contacto con nosotros en nuestro grupo de telegram.[/COLOR]" )
     if 92 - 92: ooOoO0o % II111iiii % oO0o
     if 23 - 23: o0oOOo0O0Ooo * IIIIII11i1I
   except :
    pass
    if 80 - 80: IIII / II111iiii + OoO0O00
 else :
  xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red][B]Error, de inicio. ¿Tienes Instalado Realstream?[/B][/COLOR]" )
  if 38 - 38: iII111i % o0O0 + OoOoOO00 * OoO0O00 * IiII
  if 83 - 83: Oo0Ooo - o0O0 - IIII / OOooOOo - I1IiiI
elif IIIi11 == 1 :
 O00oO0O ( OOOooo , OooO0OO , id , o0OOo0o0O0O )
elif IIIi11 == 2 :
 OOoOIiIIII ( )
elif IIIi11 == 3 :
 IiiIiI ( )
elif IIIi11 == 4 :
 iiIi ( OOOooo , OooO0OO )
elif IIIi11 == 5 :
 Oooo00oOo ( )
elif IIIi11 == 6 :
 iIIIiIi1I1i ( )
elif IIIi11 == 7 :
 III1I ( )
elif IIIi11 == 8 :
 i11IiIIi11I ( )
elif IIIi11 == 9 :
 O000O ( )
elif IIIi11 == 10 :
 oOoo0OooOOo00 ( )
elif IIIi11 == 11 :
 i1iii1ii ( )
elif IIIi11 == 12 :
 i1i1IiIi1 ( )
elif IIIi11 == 13 :
 O0Oo0 ( )
elif IIIi11 == 14 :
 oOO0 ( )
elif IIIi11 == 15 :
 OOOii1i1iiI ( )
elif IIIi11 == 16 :
 oOo00o ( )
elif IIIi11 == 17 :
 II11ii ( )
elif IIIi11 == 18 :
 oo0ooooo00o ( )
elif IIIi11 == 19 :
 IiIo0o0OO0o00o0O ( )
elif IIIi11 == 20 :
 I1Iii1Ii1i1 ( )
elif IIIi11 == 21 :
 ooOoo0OoOO ( )
elif IIIi11 == 22 :
 ooooO0 ( )
elif IIIi11 == 23 :
 ii1II1II ( )
elif IIIi11 == 24 :
 OO0Oo ( )
elif IIIi11 == 25 :
 i1I1IiI1ii ( )
elif IIIi11 == 26 :
 o00oo0000 ( )
elif IIIi11 == 28 :
 IiI ( OOOooo , OooO0OO )
elif IIIi11 == 98 :
 busqueda_global ( )
elif IIIi11 == 97 :
 oO00o00 ( )
elif IIIi11 == 99 :
 IIo0OoO00 ( )
elif IIIi11 == 100 :
 menu_player ( OOOooo , OooO0OO )
elif IIIi11 == 111 :
 OOOoO00 ( )
elif IIIi11 == 115 :
 i1iI1Iiii1I ( OooO0OO )
elif IIIi11 == 116 :
 I1II ( )
elif IIIi11 == 117 :
 I11I1IIiiII1 ( )
elif IIIi11 == 119 :
 IiI1iII1II111 ( )
elif IIIi11 == 120 :
 O0O0ooOOOo0o00Ooo0o ( )
elif IIIi11 == 121 :
 I11oo0ooOO ( )
elif IIIi11 == 125 :
 OOoooO00o0o ( )
elif IIIi11 == 112 :
 I1iii ( )
elif IIIi11 == 127 :
 O0o0O0O0O ( )
elif IIIi11 == 128 :
 TESTLINKS ( )
elif IIIi11 == 130 :
 III1ii ( OOOooo , OooO0OO )
elif IIIi11 == 140 :
 IiI1I11iIii ( )
elif IIIi11 == 141 :
 iI111II1ii ( )
elif IIIi11 == 142 :
 oOoOOOo ( )
elif IIIi11 == 143 :
 iIIIi1i1I11i ( OOOooo , OooO0OO )
elif IIIi11 == 144 :
 IiI ( OOOooo , OooO0OO )
elif IIIi11 == 145 :
 IIiiii ( )
xbmcplugin . endOfDirectory ( oOOo ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
