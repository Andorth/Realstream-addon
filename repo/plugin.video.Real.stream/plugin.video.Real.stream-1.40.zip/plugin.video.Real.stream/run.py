# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 1.2.6
#
############################################
# Dependencias 
# Script ExtendedInfo
# Script Urlresolver de TVAddons
# Script ResolveURL Por Jsergio.
#
############################################
#
# Agregar sinopsis a Peliculas y series.
# Supresion de Licencia
# Novedades en episodios agregados en series.
#
############################################
if 64 - 64: i11iIiiIii
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import urlresolver
import cookielib , base64
import requests
import plugintools
import config
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
IiII1IiiIiI1 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
o0OoOoOO00 = int ( sys . argv [ 1 ] )
I11i = 'gruponetai/'
O0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
Oo = O0O . getAddonInfo ( 'profile' )
I1ii11iIi11i = O0O . getAddonInfo ( 'path' )
I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
if 73 - 73: OOooOOo / ii11ii1ii
if 94 - 94: OoOO + OoOO0ooOOoo0O + o0000oOoOoO0o * o00O0oo
if I1IiI == 'true' :
 if 97 - 97: oO0o0ooO0 - IIII / O0oO - o0oO0
 oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.png' ) )
 o00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 Oo0oO0ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.png' ) )
 i1111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.png' ) )
 i11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'estrenos.png' ) )
 I11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.png' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.png' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.png' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.png' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.png' ) )
 oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.png' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.png' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.png' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.png' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.png' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.png' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.png' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'marvel.png' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.png' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.png' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.png' ) )
 II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.png' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.png' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.png' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.png' ) )
 OO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.png' ) )
 Ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.png' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.png' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.png' ) )
 O0OO00o0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.png' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.png' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_series.png' ) )
 OOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_Episodios.png' ) )
 if 87 - 87: O0ooOooooO / i1I111II1I - Oooo0Ooo000 - iI - II111iiii / O0
else :
 if 97 - 97: iI - IIII * i11iIiiIii / OoOO0ooOOoo0O % Oooo0Ooo000 - OoooooooOO
 if 59 - 59: O0 + OOooOOo + i1I111II1I % OOooOOo
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
 oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.jpg' ) )
 o00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 Oo0oO0ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.jpg' ) )
 i1111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.jpg' ) )
 i11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'encines.jpg' ) )
 I11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.jpg' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.jpg' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.jpg' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.jpg' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.jpg' ) )
 oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.jpg' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.jpg' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.jpg' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.jpg' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.jpg' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.jpg' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.jpg' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'superheroes.jpg' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.jpg' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.jpg' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.jpg' ) )
 II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.jpg' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.jpg' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.jpg' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.jpg' ) )
 OO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.jpg' ) )
 Ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.jpg' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.jpg' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.jpg' ) )
 O0OO00o0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.png' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.png' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.png' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favoritos.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_series.png' ) )
 OOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_Episodios.png' ) )
 if 70 - 70: O0ooOooooO * o00O0oo
 if 46 - 46: iI / OoOO
 if 52 - 52: o0000oOoOoO0o - OoooooooOO + o0oO0 + o0oO0 - o0000oOoOoO0o / Oooo0Ooo000
I1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'peliculas.png' ) )
iIi11Ii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series.png' ) )
Ii11iII1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ajustes.png' ) )
Oo0O0O0ooO0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'videoteca.png' ) )
IIIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
O0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'resolver.png' ) )
OO00Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'test.png' ) )
O0OOO0OOoO0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'video-tutoriales.png' ) )
O00Oo000ooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'proxy.png' ) )
if 100 - 100: O0 + i1I111II1I - IIII + i11iIiiIii * o0oO0
if 30 - 30: o0000oOoOoO0o . o0oO0 - OoooooooOO
if 8 - 8: i1IIi - iIii1I11I1II1 * II111iiii + i11iIiiIii / Oooo0Ooo000 % IIII
iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
OOoOO0oo0ooO = IiII1IiiIiI1 . getSetting ( 'mostrar_cat' )
O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'sel_tobox' )
O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'videos' )
i1Oo00 = IiII1IiiIiI1 . getSetting ( 'activar' )
i1i = IiII1IiiIiI1 . getSetting ( 'favcopy' )
iiI111I1iIiI = IiII1IiiIiI1 . getSetting ( 'anticopia' )
IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
oooooOoo0ooo = IiII1IiiIiI1 . getSetting ( 'mostrar_bus' )
I1I1IiI1 = IiII1IiiIiI1 . getSetting ( 'restante' )
III1iII1I1ii = IiII1IiiIiI1 . getSetting ( 'selecton' )
oOOo0 = IiII1IiiIiI1 . getSetting ( 'aviso' )
oo00O00oO = IiII1IiiIiI1 . getSetting ( 'RealStream_Settings' )
iIiIIIi = IiII1IiiIiI1 . getSetting ( 'Resolver_Settings' )
I1I1IiI1 = IiII1IiiIiI1 . getSetting ( 'restante' )
ooo00OOOooO = IiII1IiiIiI1 . getSetting ( 'fav' )
O00OOOoOoo0O = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
O000OOo00oo = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
oo0OOo = 'bienvenida'
ooOOO00Ooo = 'bienvenida'
copyright = IiII1IiiIiI1 . getSetting ( 'copyright' )
IiIIIi1iIi = 'cGx1Z2luLnZpZGVvLg==' . decode ( 'base64' ) + copyright
ooOOoooooo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
II1I = IiII1IiiIiI1 . getSetting ( 'Forceupdate' )
if II1I == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
O0i1II1Iiii1I11 = 'LnR4dA==' . decode ( 'base64' )
IIIIiiIiI = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1NQOUpRZExS' . decode ( 'base64' )
if 91 - 91: O0ooOooooO % i1IIi % iIii1I11I1II1
if 20 - 20: IIII % o0oO0 / o0oO0 + o0oO0
III1IiiI = 'aHR0cDovL2JpdC5seS8yU1FOSnlP' . decode ( 'base64' )
iIi1 = O000OOo00oo + oo0OOo + O0i1II1Iiii1I11
IIIII11I1IiI = 'http://www.youtube.com'
i1I = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
OoOOooOOO0 = 'http://bit.ly/2ImelUx'
o0o = '.xsl.pt'
O0OOoO00OO0o = 'L21hc3Rlci8=' . decode ( 'base64' )
I1111IIIIIi = i1I + o0o
Iiii1i1 = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*'
OO = 'tvg-logo=[\'"](.*?)[\'"]'
if 77 - 77: ii11ii1ii
I1iII1iIi1I = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.*)'
oO0O00OoOO0 = '(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)'
OoO = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
O00 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
I1iI1 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
iiiIi1 = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
i1I1ii11i1Iii = '#(.+?),(.+)\s*(.+)'
I1IiiiiI = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
o0O = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
IiII = '[\'"](.*?)[\'"]'
ii1iII1II = r'066">\s*(.+)</f'
Iii1I1I11iiI1 = '[\'"](.*?)[\'"]'
I1I1i1I = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
ii1I = '[\'"](.*?)[\'"]'
O0oO0 = 'src":"(.*?)"label":"(.*?)"lang":"(.*?)"'
oO0 = 'https://pastebin.com/raw/SP9JQdLR'
O0OO0O = '[\'"](.*?)[\'"]'
OOOoOoO = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( 'base64' )
Ii1I1i = OOOoOoO + I11i
OOI1iI1ii1II = '(.+),(.+),(.*)\s*'
O0O0OOOOoo = '[\'"](.*?)[\'"]'
oOooO0 = 'UmVhbHN0cmVhbQ==' . decode ( 'base64' )
Ii1I1Ii = 'video=[\'"](.*?)[\'"]'
OOoO0 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
OO0Oooo0oOO0O = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( 'base64' ) + OOoO0
o00O0 = '0101ahn' . replace ( '0101ahn' , 'sZn' )
oOO0O00Oo0O0o = 'aHR0cDovL2JpdC5seS8yTnpB' . decode ( 'base64' ) + o00O0
ii1 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
I1iIIiiIIi1i = '0110R0N' . replace ( '0110R0N' , 'R0N' )
O0O0ooOOO = 'aHR0cDovL2JpdC5seS8yWEIx' . decode ( 'base64' ) + I1iIIiiIIi1i
oOOo0O00o = '0110pEJ' . replace ( '0110pEJ' , 'pEJ' )
iIiIi11 = 'aHR0cDovL2JpdC5seS8yd1Nh' . decode ( 'base64' ) + oOOo0O00o
OOO = 'ABBAOb5' . replace ( 'ABBAOb5' , 'Ob5' )
iiiiI = 'aHR0cDovL2JpdC5seS8yRVhV' . decode ( 'base64' ) + OOO
oooOo0OOOoo0 = '0110jaw' . replace ( '0110jaw' , 'jaw' )
OOoO = 'aHR0cDovL2JpdC5seS8yd01M' . decode ( 'base64' ) + oooOo0OOOoo0
OO0O000 = '01109DI' . replace ( '01109DI' , '9DI' )
iiIiI1i1 = 'aHR0cDovL2JpdC5seS8ySXgz' . decode ( 'base64' ) + OO0O000
oO0O00oOOoooO = '01103hs' . replace ( '01103hs' , '3hs' )
IiIi11iI = 'aHR0cDovL2JpdC5seS8zMW1U' . decode ( 'base64' ) + oO0O00oOOoooO
Oo0O00O000 = '01107DW' . replace ( '01107DW' , '7DW' )
i11I1IiII1i1i = 'aHR0cDovL2JpdC5seS8yV1ln' . decode ( 'base64' ) + Oo0O00O000
oo = '0110mLl' . replace ( '0110mLl' , 'mLl' )
I1111i = 'aHR0cDovL2JpdC5seS8yS0cw' . decode ( 'base64' ) + oo
iIIii = '01102Hj' . replace ( '01102Hj' , '2Hj' )
o00O0O = 'aHR0cDovL2JpdC5seS8yWEJo' . decode ( 'base64' ) + iIIii
ii1iii1i = '0110fXg' . replace ( '0110fXg' , 'fXg' )
Iii1I1111ii = 'aHR0cDovL2JpdC5seS8ySTVy' . decode ( 'base64' ) + ii1iii1i
ooOoO00 = '0110NMH' . replace ( '0110NMH' , 'NMH' )
Ii1IIiI1i = 'aHR0cDovL2JpdC5seS8yd0t6' . decode ( 'base64' ) + ooOoO00
o0O00Oo0 = '0110bwQ' . replace ( '0110bwQ' , 'bwQ' )
IiII111i1i11 = 'aHR0cDovL2JpdC5seS8yd01V' . decode ( 'base64' ) + o0O00Oo0
i111iIi1i1II1 = '0110xzG' . replace ( '0110xzG' , 'xzG' )
oooO = 'aHR0cDovL2JpdC5seS8yWHhz' . decode ( 'base64' ) + i111iIi1i1II1
i1I1i111Ii = '0110x64' . replace ( '0110x64' , 'x64' )
ooo = 'aHR0cDovL2JpdC5seS8yRVlF' . decode ( 'base64' ) + i1I1i111Ii
i1i1iI1iiiI = '0110vUE' . replace ( '0110vUE' , 'vUE' )
Ooo0oOooo0 = 'aHR0cDovL2JpdC5seS8yWmhW' . decode ( 'base64' ) + i1i1iI1iiiI
oOOOoo00 = '01107ZL' . replace ( '01107ZL' , '7ZL' )
iiIiIIIiiI = 'aHR0cDovL2JpdC5seS8yWm4w' . decode ( 'base64' ) + oOOOoo00
iiI1IIIi = '01106cf' . replace ( '01106cf' , '6cf' )
II11IiIi11 = 'aHR0cDovL2JpdC5seS8yRVlk' . decode ( 'base64' ) + iiI1IIIi
IIOOO0O00O0OOOO = '0110Jtp' . replace ( '0110Jtp' , 'Jtp' )
I1iiii1I = 'aHR0cDovL2JpdC5seS8yV3Nq' . decode ( 'base64' ) + IIOOO0O00O0OOOO
OOo0 = '0110a5b' . replace ( '0110a5b' , 'a5b' )
oO00ooooO0o = 'aHR0cDovL2JpdC5seS8yV3dj' . decode ( 'base64' ) + OOo0
oo0o = '0110Q7u' . replace ( '0110Q7u' , 'Q7u' )
o0oO0oooOoo = 'aHR0cDovL2JpdC5seS8yV3NL' . decode ( 'base64' ) + oo0o
I1III1111iIi = '0110rsq' . replace ( '0110rsq' , 'rsq' )
I1i111I = 'aHR0cDovL2JpdC5seS8ySzhE' . decode ( 'base64' ) + I1III1111iIi
OooOo0oo0O0o00O = '0110DDR' . replace ( '0110DDR' , 'DDR' )
I1i11 = 'aHR0cDovL2JpdC5seS8ySzd5' . decode ( 'base64' ) + OooOo0oo0O0o00O
IiIi1I1 = '0110feQ' . replace ( '0110feQ' , 'feQ' )
IiIIi1 = 'aHR0cDovL2JpdC5seS8yS0cz' . decode ( 'base64' ) + IiIi1I1
IIIIiii1IIii = '0110MHY' . replace ( '0110MHY' , 'MHY' )
II1i11I = 'aHR0cDovL2JpdC5seS8ySXVo' . decode ( 'base64' ) + IIIIiii1IIii
ii1I1IIii11 = '0110xdb' . replace ( '0110xdb' , 'xdb' )
O0o0oO = 'aHR0cDovL2JpdC5seS8yWEJu' . decode ( 'base64' ) + ii1I1IIii11
IIIIiIiIi1 = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( 'base64' )
I11iiiiI1i = 'aHR0cHM6Ly9uZXRhaS5ldS92aXNpdGFzL2luZGV4LnBocA==' . decode ( 'base64' )
IiIIIi1iIi = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
iI1i11 = '0110lxu' . replace ( '0110lxu' , 'lxu' )
OoOOoooOO0O = 'aHR0cDovL2JpdC5seS8yV1Bj' . decode ( 'base64' ) + iI1i11
ooo00Ooo = '0110pzp' . replace ( '0110pzp' , 'pzp' )
Oo0o0O00 = 'aHR0cDovL2JpdC5seS8yVHpB' . decode ( 'base64' ) + ooo00Ooo
ii1I1i11 = '01105yt' . replace ( '01105yt' , '5yt' )
OOo0O0oo0OO0O = 'aHR0cDovL2JpdC5seS8yTVpp' . decode ( 'base64' ) + ii1I1i11
if 68 - 68: oO0o0ooO0 . O0oO % OoooooooOO . O0oO
if 64 - 64: iIii1I11I1II1 / OOooOOo . II111iiii + OoooooooOO . OoOO
oOIIiIi = '1001DTs' . replace ( '1001DTs' , 'DTs' )
OOoOooOoOOOoo = 'aHR0cDovL2JpdC5seS8ySzhP' . decode ( 'base64' ) + oOIIiIi
Iiii1iI1i = '1001Hky' . replace ( '1001Hky' , 'Hky' )
I1ii1ii11i1I = 'aHR0cDovL2JpdC5seS8yTGVL' . decode ( 'base64' ) + Iiii1iI1i
o0OoOO = '1001VFU' . replace ( '1001VFU' , 'VFU' )
O0O0Oo00 = 'aHR0cDovL2JpdC5seS8zMERx' . decode ( 'base64' ) + o0OoOO
oOoO00o = '3545OMZ' . replace ( '3545OMZ' , 'OMZ' )
oO00O0 = 'aHR0cDovL2JpdC5seS8yazhk' . decode ( 'base64' ) + oOoO00o
IIi1IIIi = '4224tZO' . replace ( '4224tZO' , 'tZO' )
O00Ooo = 'aHR0cDovL2JpdC5seS8zNXd4' . decode ( 'base64' ) + IIi1IIIi
if 52 - 52: o00O0oo - ii11ii1ii + o00O0oo % o0000oOoOoO0o
try :
 if 35 - 35: iIii1I11I1II1
 iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
 o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
 OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
 if 42 - 42: Oooo0Ooo000 . OOooOOo . i1IIi + OoOO0ooOOoo0O + IIII + OOooOOo
 I1IooooO0oOoOOoO = I1i11i ( oOO0O00Oo0O0o )
 IiIi = re . compile ( OOI1iI1ii1II ) . findall ( I1IooooO0oOoOOoO )
 for OOOOO0O00 , Iii , iIIiIiI1I1 in IiIi :
  if re . search ( OOO00O , iIIiIiI1I1 ) :
   if 56 - 56: OOooOOo . O0 + ii11ii1ii
   if iiII1i1 == OOOOO0O00 and o00oOO0o == Iii and OOO00O == iIIiIiI1I1 :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR orange]Bienvenido![/COLOR][COLOR white] " + OOOOO0O00 + "[/COLOR] ,3000)" )
    if 1 - 1: O0ooOooooO
    login == 'true'
    if 97 - 97: IIII + O0ooOooooO + O0 + i11iIiiIii
   else :
    if 77 - 77: o0000oOoOoO0o / OoooooooOO
    login == 'false'
    if 46 - 46: o0000oOoOoO0o % iIii1I11I1II1 . O0ooOooooO % O0ooOooooO + i11iIiiIii
    if 72 - 72: iIii1I11I1II1 * o0oO0 % iI / OoOO
except :
 pass
 if 35 - 35: iI + i1IIi % o00O0oo % O0oO + oO0o0ooO0
 if 17 - 17: i1IIi
def iiIi1i ( ) :
 if 27 - 27: IIII * iI . Oooo0Ooo000 % i1I111II1I * i1I111II1I . i1IIi
 if 72 - 72: IIII % o00O0oo + OoOO / oO0o0ooO0 + i1I111II1I
 try :
  I1I1i = I1i11i ( O0O0ooOOO )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
  for I1IIIiIiIi in IiIi :
   try :
    if 27 - 27: o00O0oo + OoOO0ooOOoo0O - IIII + O0 . o0oO0
    iIiIi11 = I1IIIiIiIi
    if 46 - 46: i1I111II1I
    ii1iIi1iIiI1i = xbmc . Keyboard ( '' , 'Busqueda por titulo' )
    ii1iIi1iIiI1i . doModal ( )
    if ( ii1iIi1iIiI1i . isConfirmed ( ) ) :
     iiI1iIii1i = xbmcgui . DialogProgress ( )
     iiI1iIii1i . create ( 'Realstream:' , 'Buscando ...' )
     OOooO0oo0o00o = range ( 0 , 76 )
     for ooOO0OoO in OOooO0oo0o00o :
      ooOO0OoO = ooOO0OoO + 1
      if 69 - 69: iIii1I11I1II1 . o00O0oo % iI + iIii1I11I1II1 / O0 / o00O0oo
     O00OoOO0oo0 = urllib . quote_plus ( ii1iIi1iIiI1i . getText ( ) ) . replace ( '+' , ' ' )
     oOO = I1i11i ( iIiIi11 )
     IiIi = re . compile ( I1iII1iIi1I ) . findall ( oOO )
     for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
      if 7 - 7: O0 - ii11ii1ii + o00O0oo + II111iiii + iIii1I11I1II1
      iiI1iIii1i . update ( ooOO0OoO , '[COLOR orange]Realstream: Buscando ...[/COLOR]' , ' [COLOR yellow] %s [/COLOR]' % iIIII1iIIii )
      xbmc . sleep ( 1 )
      if iiI1iIii1i . iscanceled ( ) : break ;
      if re . search ( O00OoOO0oo0 , OOo0ii11I1 ( iIIII1iIIii . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       if 75 - 75: OoOO / II111iiii % O0
       iiI1iIii1i . update ( 80 , ' [COLOR orange]Busqueda finalizada[/COLOR] ' )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR gold]Generando listado ...  [/COLOR][COLOR orange] Por favor espere ![/COLOR] ,1000)" )
       iiI1iIii1i . update ( 100 , '[COLOR orange]Realstream: [/COLOR]' , '[COLOR gold] Busqueda finalizada ...[/COLOR]' )
       iiI1iIii1i . close ( )
       Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
       if 21 - 21: oO0o0ooO0 / o00O0oo + o0oO0 + OoooooooOO
       if 91 - 91: i11iIiiIii / i1IIi + O0ooOooooO + iI * i11iIiiIii
     OoOoOo00o0 ( '[COLOR %s]Buscar Pelicula[/COLOR]' % iIIIi1 , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Resultados para: [COLOR orange]" + O00OoOO0oo0 + "[/COLOR] ,2000)" )
     if 90 - 90: ii11ii1ii % O0 * iIii1I11I1II1 . O0ooOooooO
   except : OoOoOo00o0 ( '[COLOR %s]Buscar Pelicula[/COLOR]' % iIIIi1 , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
   if 8 - 8: iI + II111iiii / O0ooOooooO / O0oO
 except :
  pass
  if 74 - 74: O0 / i1IIi
def OoOIiiiii111i1ii ( ) :
 if 25 - 25: IIII - iI / i11iIiiIii
 oOOo0 = IiII1IiiIiI1 . getSetting ( 'aviso' )
 if 41 - 41: i1IIi % O0ooOooooO + iIii1I11I1II1
 if oOOo0 == 'true' :
  if 2 - 2: iIii1I11I1II1 * ii11ii1ii % oO0o0ooO0 - II111iiii - O0ooOooooO
  try :
   I1I1i = I1i11i ( iIi1 )
   IiIi = re . compile ( Iiii1i1 ) . findall ( I1I1i )
   for iIi11iiIiI1I , Iiii in IiIi :
    try :
     if 89 - 89: oO0o0ooO0
     if 25 - 25: o00O0oo + O0
     i1II = iIi11iiIiI1I
     O0OOO0OOooo00 = Iiii
     if 6 - 6: o0oO0 - iI * IIII . O0ooOooooO / O0 * iI
     if 22 - 22: ii11ii1ii % O0ooOooooO * o00O0oo / IIII % i11iIiiIii * O0oO
     from datetime import datetime
     if 95 - 95: OoooooooOO - i1I111II1I * OOooOOo + OoOO0ooOOoo0O
     iIi1i11iiI1111 = datetime . now ( )
     oOoooo000Oo00 = iIi1i11iiI1111 . strftime ( '%d/%m/%Y' )
     if 93 - 93: o00O0oo / OOooOOo / iIii1I11I1II1 % Oooo0Ooo000 % Oooo0Ooo000
     IiI11iI1i1i1i = I1i11i ( I11iiiiI1i )
     IiIi = re . compile ( ii1iII1II ) . findall ( IiI11iI1i1i1i )
     for oO0Ooooooo in IiIi :
      if 39 - 39: i1I111II1I * ii11ii1ii + iIii1I11I1II1 - i1I111II1I + IIII
      o0iiiI1I1iIIIi1 = "[B]" + i1II + "[/B]"
      IiiI1iiiiI1iI = "" + O0OOO0OOooo00 + ""
      iIiiiii1i = "[COLOR white]Hoy: " + oOoooo000Oo00 + ", Es usted el visitante numero: [B][COLOR gold]" + oO0Ooooooo + "[/B][/COLOR]"
      if 40 - 40: O0 - OoooooooOO - i1I111II1I
      xbmcgui . Dialog ( ) . ok ( "Real Stream" , o0iiiI1I1iIIIi1 , IiiI1iiiiI1iI , iIiiiii1i )
    except :
     pass
     if 37 - 37: OoOO0ooOOoo0O / II111iiii / O0
  except :
   pass
   if 76 - 76: OOooOOo . iI - o00O0oo - O0ooOooooO * OoOO
  try :
   oOO = I1i11i ( IIIIiIiIi1 )
   IiIi = re . compile ( IiII ) . findall ( oOO )
   for O0Oo00O in IiIi :
    if 91 - 91: oO0o0ooO0 % o0oO0 . iI / O0ooOooooO * iIii1I11I1II1
    import xbmc
    import xbmcaddon
    if 43 - 43: iI + O0ooOooooO - Oooo0Ooo000 / O0 * ii11ii1ii + OOooOOo
    __addon__ = xbmcaddon . Addon ( )
    __addonname__ = __addon__ . getAddonInfo ( 'name' )
    __icon__ = __addon__ . getAddonInfo ( 'icon' )
    if 28 - 28: o0oO0 * o0000oOoOoO0o - OoOO
    iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
    i111IiiII = O0Oo00O
    if 42 - 42: oO0o0ooO0 + II111iiii . iIii1I11I1II1
    o0iiiI1I1iIIIi1 = "[COLOR orange]Version instalada: [COLOR gold][B] " + iIiiiI1IiI1I1 + "[/B] [/COLOR][/COLOR][COLOR white] Disponible: [B]" + O0Oo00O + " [/B][/COLOR]"
    O0i11i1iiI1i = 4000
    xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , o0iiiI1I1iIIIi1 , O0i11i1iiI1i , __icon__ ) )
    if 87 - 87: iI
    if iIiiiI1IiI1I1 < O0Oo00O :
     if 45 - 45: OoOO / OoooooooOO - O0ooOooooO / o0oO0 % i1I111II1I
     xbmcgui . Dialog ( ) . ok ( "Real Stream" , "[COLOR white] Existe una nueva version de [/COLOR][COLOR fuchsia]Realstream[/COLOR]" , "[COLOR orange]Actualimete tiene instalada la version[/COLOR] [COLOR white][B] %s [/B][/COLOR]" % iIiiiI1IiI1I1 , " [COLOR white]Ya esta disponible la[/COLOR] [COLOR gold][B] %s [/B][/COLOR]" % O0Oo00O )
     if 83 - 83: OOooOOo . iIii1I11I1II1 - i1I111II1I * i11iIiiIii
     if 20 - 20: i1IIi * Oooo0Ooo000 + II111iiii % o0000oOoOoO0o % oO0o0ooO0
  except :
   pass
   if 13 - 13: ii11ii1ii
   if 60 - 60: o00O0oo * OOooOOo
   if 17 - 17: IIII % ii11ii1ii / o00O0oo . i1I111II1I * IIII - II111iiii
   if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 41 - 41: o0oO0
    if 77 - 77: Oooo0Ooo000
    if 65 - 65: II111iiii . OOooOOo % oO0o0ooO0 * OoOO
def OOo0ii11I1 ( s ) :
 if 38 - 38: OoOO0ooOOoo0O / O0ooOooooO % ii11ii1ii
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 11 - 11: O0ooOooooO - oO0o0ooO0 + II111iiii - iIii1I11I1II1
def I1i11ii11 ( file ) :
 if 81 - 81: IIII - O0oO % iI - OoOO / ii11ii1ii
 try :
  Ii1iI111 = open ( file , 'r' )
  I1I1i = Ii1iI111 . read ( )
  Ii1iI111 . close ( )
  return I1I1i
 except :
  pass
  if 51 - 51: i1I111II1I * O0 / II111iiii . o0oO0 % IIII / OOooOOo
def I1i11i ( url ) :
 if 9 - 9: OOooOOo % OOooOOo % II111iiii
 try :
  I1I1i1Ioo0oo = urllib2 . Request ( url )
  I1I1i1Ioo0oo . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  IIi11IIiIii1 = urllib2 . urlopen ( I1I1i1Ioo0oo )
  I1iIII1 = IIi11IIiIii1 . read ( )
  IIi11IIiIii1 . close ( )
  return I1iIII1
 except urllib2 . URLError , iIii :
  print 'We failed to open "%s".' % url
  if hasattr ( iIii , 'code' ) :
   print 'We failed with error code - %s.' % iIii . code
  if hasattr ( iIii , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , iIii . reason
   if 84 - 84: oO0o0ooO0 % i1IIi
def oOOIi1II ( url ) :
 I1I1i1Ioo0oo = urllib2 . Request ( url )
 I1I1i1Ioo0oo . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 I1I1i1Ioo0oo . add_header ( 'Referer' , '%s' % url )
 I1I1i1Ioo0oo . add_header ( 'Connection' , 'keep-alive' )
 IIi11IIiIii1 = urllib2 . urlopen ( I1I1i1Ioo0oo )
 I1iIII1 = IIi11IIiIii1 . read ( )
 IIi11IIiIii1 . close ( )
 return I1iIII1
 if 89 - 89: Oooo0Ooo000 + OoooooooOO + Oooo0Ooo000 * i1IIi + iIii1I11I1II1 % O0oO
 if 59 - 59: IIII + i11iIiiIii
 if 88 - 88: i11iIiiIii - iI
def O0iIi1IiII ( ) :
 if 27 - 27: O0ooOooooO . O0oO . iIii1I11I1II1 . iIii1I11I1II1
 iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 if 20 - 20: o0000oOoOoO0o / i1IIi
 if i1Oo00 == 'true' :
  if 71 - 71: OoOO0ooOOoo0O . i1IIi
  if 94 - 94: IIII . Oooo0Ooo000
  try :
   if 84 - 84: O0 . O0oO - II111iiii . iI / II111iiii
   iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
   o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
   OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
   if 47 - 47: OoooooooOO
   I1IooooO0oOoOOoO = I1i11i ( oOO0O00Oo0O0o )
   IiIi = re . compile ( OOI1iI1ii1II ) . findall ( I1IooooO0oOoOOoO )
   for OOOOO0O00 , Iii , iIIiIiI1I1 in IiIi :
    if re . search ( OOO00O , iIIiIiI1I1 ) :
     if 4 - 4: OOooOOo % O0oO
     if iiII1i1 == OOOOO0O00 and o00oOO0o == Iii and OOO00O == iIIiIiI1I1 :
      if 10 - 10: i1I111II1I . OoooooooOO - OoOO + i1I111II1I - O0
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR orange]Bienvenido![/COLOR][COLOR white] " + OOOOO0O00 + "[/COLOR] ,3000)" )
      OoOoOo00o0 ( '[COLOR %s]Buscar Serie[/COLOR]' % iIIIi1 , 'search' , 145 , I1IIIii , oo00 )
      OoOoOo00o0 ( '[COLOR %s]Series[/COLOR] ' % iIIIi1 , 'movieDB' , 117 , iIi11Ii1 , oo00 )
      OoOoOo00o0 ( '[COLOR %s]Buscar Pelicula[/COLOR]' % iIIIi1 , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
      OoOoOo00o0 ( '[COLOR %s]Peliculas[/COLOR] ' % iIIIi1 , 'movieDB' , 116 , I1I , oo00 )
      if 82 - 82: iI + II111iiii
     if iiII1i1 == 'Invitado' :
      if 39 - 39: oO0o0ooO0 % iIii1I11I1II1 % O0 % OoooooooOO * o00O0oo + O0ooOooooO
      xbmc . sleep ( 3000 )
      if 68 - 68: ii11ii1ii + i11iIiiIii
      xbmcgui . Dialog ( ) . ok ( "[COLOR white]Hola [/COLOR][COLOR blue]" + iiII1i1 + "  [/COLOR][COLOR gold]," , "Visita nuestro Telegram o create una cuenta en nuestra web.[/COLOR][COLOR white]" , "https://netai.eu[ /COLOR]" )
      if 69 - 69: iIii1I11I1II1 * iIii1I11I1II1 * i11iIiiIii + OOooOOo / IIII % o0oO0
      if 58 - 58: IIII * o0000oOoOoO0o + O0 % IIII
      if 25 - 25: ii11ii1ii % o00O0oo * iI
  except :
   pass
   if 6 - 6: O0ooOooooO . i1I111II1I * OoOO0ooOOoo0O . i1IIi
 if oo00O00oO == 'true' :
  OoOoOo00o0 ( '[COLOR %s]Ajustes[/COLOR]' % iIIIi1 , 'Settings' , 119 , Ii11iII1 , oo00 )
  if 98 - 98: i1IIi
  if 65 - 65: OoOO0ooOOoo0O / OoOO % i1I111II1I
  if OOoOO0oo0ooO == 'true' :
   try :
    if 45 - 45: OoOO0ooOOoo0O
    iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
    o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
    OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
    if 66 - 66: OoOO
    I1IooooO0oOoOOoO = I1i11i ( oOO0O00Oo0O0o )
    IiIi = re . compile ( OOI1iI1ii1II ) . findall ( I1IooooO0oOoOOoO )
    for Iii , OOOOO0O00 , iIIiIiI1I1 in IiIi :
     if re . search ( OOO00O , iIIiIiI1I1 ) :
      if 56 - 56: O0
      if iiII1i1 == OOOOO0O00 and o00oOO0o == Iii and OOO00O == iIIiIiI1I1 :
       if 61 - 61: o0000oOoOoO0o / IIII / ii11ii1ii * O0
       iIII1i1i ( )
   except :
    pass
    if 35 - 35: II111iiii * O0oO - OoooooooOO . O0oO . O0oO
  if iIiIIIi == 'true' :
   I1II ( )
   OO0 ( )
   if 84 - 84: OoOO0ooOOoo0O % iI - OoOO0ooOOoo0O . o0000oOoOoO0o
  if iiI111I1iIiI == 'false' :
   if 5 - 5: OoOO0ooOOoo0O * Oooo0Ooo000 - o00O0oo / iIii1I11I1II1 % oO0o0ooO0 + i1I111II1I
   o0iiiI1I1iIIIi1 = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   IiiI1iiiiI1iI = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Script.ResolveURL para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   iIiiiii1i = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 51 - 51: Oooo0Ooo000 * II111iiii % iI
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , o0iiiI1I1iIIIi1 , IiiI1iiiiI1iI , iIiiiii1i )
   if 98 - 98: OoOO . O0oO % II111iiii
def O0OoOoO00O ( ) :
 OoOoOo00o0 ( '[COLOR orange]Buscador por id[/COLOR]' , IIIII11I1IiI , 127 , oOOoo00O0O , oo00 )
 if 96 - 96: OOooOOo % ii11ii1ii . o00O0oo + IIII
def Ii11Iii1i1ii ( ) :
 iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 OoOoOo00o0 ( '[COLOR %s]The movie DB[/COLOR]' % iIIIi1 , 'movieDB' , 99 , oOOoo00O0O , oo00 )
 if 26 - 26: II111iiii % i11iIiiIii % iIii1I11I1II1 % O0oO * O0oO * o00O0oo
 OoOoOo00o0 ( '[COLOR %s]Video tutoriales[/COLOR]' % iIIIi1 , IIIII11I1IiI , 125 , O0OOO0OOoO0O , oo00 )
 if 24 - 24: II111iiii % Oooo0Ooo000 - iI + OOooOOo * o00O0oo
 if 2 - 2: o0oO0 - i1I111II1I
 if 83 - 83: oO0o0ooO0 % o0000oOoOoO0o % o0oO0 - II111iiii * IIII / OoooooooOO
def IIIiIi ( ) :
 if 34 - 34: OoooooooOO . O0 / oO0o0ooO0 * OoOO0ooOOoo0O - o00O0oo
 O0iIi1IiII ( )
 Ii11Iii1i1ii ( )
 if 36 - 36: i1IIi / O0 / OoOO - O0 - i1IIi
def ii1I11 ( ) :
 if 99 - 99: IIII
 IIIiIi ( )
 if 45 - 45: oO0o0ooO0 - IIII * Oooo0Ooo000 / ii11ii1ii * II111iiii - Oooo0Ooo000
def oOo0oO0o0Oo ( ) :
 if xbmc . getCondVisibility ( 'System.HasAddon(script.favourites)' ) :
  try :
   xbmc . executebuiltin ( "RunScript(script.favourites)" )
  except :
   pass
def I1IiI111I11 ( ) :
 IiII1IiiIiI1 . openSettings ( )
 if 16 - 16: O0 / o0oO0 . o00O0oo
 if 58 - 58: ii11ii1ii / oO0o0ooO0
def iIII1I1i1i ( ) :
 urlresolver . display_settings ( )
 if 79 - 79: o0oO0 . OoOO
def I1II ( ) :
 OoOoOo00o0 ( '[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % iIIIi1 , 'resolve' , 120 , O0o0 , oo00 )
 if 40 - 40: o0000oOoOoO0o + ii11ii1ii . o0000oOoOoO0o % iI
def I11I1IIiiII1 ( ) :
 if 31 - 31: OOooOOo * oO0o0ooO0 + OoooooooOO - O0ooOooooO / OoooooooOO
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 19 - 19: i1I111II1I * iI * o0000oOoOoO0o + O0 / O0
def OO0 ( ) :
 OoOoOo00o0 ( '[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % iIIIi1 , 'resolve' , 140 , O0o0 , oo00 )
 if 73 - 73: iIii1I11I1II1 / iIii1I11I1II1 - oO0o0ooO0
def iIII1i1i ( ) :
 if 91 - 91: oO0o0ooO0 + OOooOOo
 try :
  if 59 - 59: OOooOOo + i11iIiiIii + i1IIi / O0oO
  iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
  OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 44 - 44: O0oO . OoOO0ooOOoo0O * OOooOOo + OoooooooOO - O0ooOooooO - i1I111II1I
  I1IooooO0oOoOOoO = I1i11i ( oOO0O00Oo0O0o )
  IiIi = re . compile ( OOI1iI1ii1II ) . findall ( I1IooooO0oOoOOoO )
  for OOOOO0O00 , Iii , iIIiIiI1I1 in IiIi :
   if re . search ( OOO00O , iIIiIiI1I1 ) :
    if 15 - 15: i1I111II1I / O0 . o0000oOoOoO0o . i11iIiiIii
    if iiII1i1 == OOOOO0O00 and o00oOO0o == Iii and OOO00O == iIIiIiI1I1 :
     if 59 - 59: Oooo0Ooo000 - o0000oOoOoO0o - iI
     OoOoOo00o0 ( '[COLOR %s]Buscador[/COLOR]' % iIIIi1 , 'search' , 111 , o0oOoO00o , oo00 )
     OoOoOo00o0 ( '[COLOR %s]Estrenos[/COLOR]' % iIIIi1 , IIIII11I1IiI , 3 , i11 , oo00 )
     OoOoOo00o0 ( '[COLOR %s]Todas[/COLOR]' % iIIIi1 , IIIII11I1IiI , 26 , I11 , oo00 )
     OoOoOo00o0 ( '[COLOR %s]4K[/COLOR]' % iIIIi1 , IIIII11I1IiI , 141 , O0o0Oo , oo00 )
     OoOoOo00o0 ( '[COLOR %s]Novedades[/COLOR]' % iIIIi1 , IIIII11I1IiI , 2 , i1111 , oo00 )
     if 48 - 48: i1IIi + O0oO % OoOO0ooOOoo0O / ii11ii1ii - o0000oOoOoO0o
     if 67 - 67: oO0o0ooO0 % o0000oOoOoO0o . OoooooooOO + IIII * O0oO * OoOO0ooOOoo0O
     if 36 - 36: O0 + ii11ii1ii
     if 5 - 5: ii11ii1ii * OoOO0ooOOoo0O
     if 46 - 46: iI
     if 33 - 33: O0ooOooooO - II111iiii * OoooooooOO - ii11ii1ii - IIII
     if 84 - 84: Oooo0Ooo000 + ii11ii1ii - OoOO0ooOOoo0O * OoOO0ooOOoo0O
     if 61 - 61: OoooooooOO . oO0o0ooO0 . OoooooooOO / ii11ii1ii
     if 72 - 72: i1IIi
     if 82 - 82: OoOO0ooOOoo0O + OoooooooOO / i11iIiiIii * o00O0oo . OoooooooOO
     if 63 - 63: o00O0oo
     if 6 - 6: iI / o00O0oo
     if 57 - 57: O0oO
     if 67 - 67: OoOO . iI
     if 87 - 87: oO0o0ooO0 % o0oO0
     if 83 - 83: II111iiii - O0oO
     if 35 - 35: i1IIi - iIii1I11I1II1 + i1IIi
     if 86 - 86: iIii1I11I1II1 + OoOO0ooOOoo0O . i11iIiiIii - o0oO0
     if 51 - 51: OoOO0ooOOoo0O
     if 14 - 14: i1I111II1I % oO0o0ooO0 % ii11ii1ii - i11iIiiIii
     if 53 - 53: o0oO0 % ii11ii1ii
     if 59 - 59: IIII % iIii1I11I1II1 . i1IIi + II111iiii * i1I111II1I
     if 41 - 41: o0oO0 % o00O0oo
     if 12 - 12: IIII
     if 69 - 69: OoooooooOO + IIII
    else :
     if 26 - 26: ii11ii1ii + IIII / OoOO % OoOO0ooOOoo0O % o00O0oo + II111iiii
     xbmcgui . Dialog ( ) . ok ( "[COLOR white]Hola [/COLOR][COLOR blue]" + iiII1i1 + "  [/COLOR][COLOR gold]," , "Visita nuestro Telegram o create una cuenta en nuestra web.[/COLOR][COLOR white]" , "https://netai.eu[ /COLOR]" )
     if 31 - 31: O0oO % IIII * O0oO
     return False
     if 45 - 45: i1IIi . OOooOOo + IIII - OoooooooOO % iI
 except :
  pass
  if 1 - 1: iIii1I11I1II1
  if 93 - 93: i1IIi . i11iIiiIii . ii11ii1ii
def O0O00OOo ( ) :
 if 66 - 66: i11iIiiIii / o0000oOoOoO0o - OoooooooOO / i1IIi . i11iIiiIii
 try :
  if 16 - 16: ii11ii1ii % o00O0oo + O0oO - O0 . O0ooOooooO / Oooo0Ooo000
  iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
  OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 35 - 35: oO0o0ooO0 / Oooo0Ooo000 / II111iiii - iIii1I11I1II1 + II111iiii . Oooo0Ooo000
  I1IooooO0oOoOOoO = I1i11i ( oOO0O00Oo0O0o )
  IiIi = re . compile ( OOI1iI1ii1II ) . findall ( I1IooooO0oOoOOoO )
  for OOOOO0O00 , Iii , iIIiIiI1I1 in IiIi :
   if re . search ( OOO00O , iIIiIiI1I1 ) :
    if 81 - 81: O0ooOooooO * IIII - o00O0oo * o0oO0 % OoOO0ooOOoo0O * OoOO0ooOOoo0O
    if iiII1i1 == OOOOO0O00 and o00oOO0o == Iii and OOO00O == iIIiIiI1I1 :
     if 59 - 59: iIii1I11I1II1
     OoOoOo00o0 ( '[COLOR %s]Buscar Serie[/COLOR]' % iIIIi1 , 'search' , 145 , O0OO00o0OO , oo00 )
     if 7 - 7: IIII * OOooOOo / o0000oOoOoO0o * i11iIiiIii
     o00II1i111 ( )
     if 50 - 50: i1I111II1I % i1IIi
     OoOoOo00o0 ( '[COLOR %s]En emision[/COLOR]' % iIIIi1 , IIIII11I1IiI , 150 , I11II1i , oo00 )
     OoOoOo00o0 ( '[COLOR %s]Mejor valoradas[/COLOR]' % iIIIi1 , IIIII11I1IiI , 151 , IIIII , oo00 )
     OoOoOo00o0 ( '[COLOR %s]Series Retro[/COLOR]' % iIIIi1 , IIIII11I1IiI , 152 , ooooooO0oo , oo00 )
     OoOoOo00o0 ( '[COLOR %s]Todas[/COLOR]' % iIIIi1 , IIIII11I1IiI , 142 , I11i1 , oo00 )
     if 21 - 21: OoooooooOO - iIii1I11I1II1
    else :
     if 93 - 93: oO0o0ooO0 - o0000oOoOoO0o % OoOO0ooOOoo0O . OoOO0ooOOoo0O - iI
     xbmcgui . Dialog ( ) . ok ( "[COLOR white]Hola [/COLOR][COLOR blue]" + iiII1i1 + "  [/COLOR][COLOR gold]," , "Visita nuestro Telegram o create una cuenta en nuestra web.[/COLOR][COLOR white]" , "https://netai.eu[ /COLOR]" )
     if 90 - 90: iI + II111iiii * o00O0oo / o0oO0 . o0000oOoOoO0o + o0000oOoOoO0o
     return False
     if 40 - 40: iI / OoOO0ooOOoo0O % i11iIiiIii % o00O0oo / OOooOOo
 except :
  pass
  if 62 - 62: i1IIi - OoOO0ooOOoo0O
  if 62 - 62: i1IIi + ii11ii1ii % i1I111II1I
  if 28 - 28: o00O0oo . i1IIi
def o00II1i111 ( ) :
 if 10 - 10: OoOO / ii11ii1ii
 I1i = 'aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtLw==' . decode ( 'base64' )
 II11iIII1i1I = 'Y29uZGljaW9uLnR4dA==' . decode ( 'base64' )
 I1iIII1 = I1i + II11iIII1i1I
 oOO0oo = '[\'"](.*?)[\'"]'
 O0O00OOo = I1i11i ( I1iIII1 )
 IiIi = re . compile ( oOO0oo ) . findall ( O0O00OOo )
 for IiIIi1I1I11Ii in IiIi :
  try :
   if 64 - 64: OoooooooOO
   if IiIIi1I1I11Ii == 'si' :
    if 81 - 81: o00O0oo - O0 * OoooooooOO
    OoOoOo00o0 ( '[COLOR %s]Hay Nuevos Episodios[/COLOR]' % iIIIi1 , IIIII11I1IiI , 155 , OOOO , oo00 )
    if 23 - 23: II111iiii / oO0o0ooO0
   elif IiIIi1I1I11Ii == 'no' :
    if 28 - 28: ii11ii1ii * iI - OoOO
    OoOoOo00o0 ( '[COLOR %s]No hay Nuevos Episodios[/COLOR]' % iIIIi1 , IIIII11I1IiI , 155 , oOoOooOo0o0 , oo00 )
    if 19 - 19: O0oO
   return
   if 67 - 67: O0 % iIii1I11I1II1 / i1I111II1I . i11iIiiIii - o0oO0 + O0
  except :
   pass
   if 27 - 27: IIII
def ooOo ( ) :
 if 84 - 84: IIII
 if 87 - 87: iI + o0000oOoOoO0o
 try :
  if 28 - 28: IIII * o00O0oo / oO0o0ooO0
  OOoOO0OO = I1i11i ( OOoOooOoOOOoo )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( OOoOO0OO )
  for I1IIIiIiIi in IiIi :
   if 26 - 26: O0ooOooooO . O0ooOooooO
   try :
    if 35 - 35: Oooo0Ooo000 . OoOO0ooOOoo0O * i11iIiiIii
    iiII = I1IIIiIiIi
    ii1iIi1iIiI1i = xbmc . Keyboard ( '' , 'Buscar' )
    ii1iIi1iIiI1i . doModal ( )
    if ( ii1iIi1iIiI1i . isConfirmed ( ) ) :
     iiI1iIii1i = xbmcgui . DialogProgress ( )
     iiI1iIii1i . create ( 'Realstream:' , 'Buscando ...' )
     OOooO0oo0o00o = range ( 0 , 69 )
     for ooOO0OoO in OOooO0oo0o00o :
      ooOO0OoO = ooOO0OoO + 1
     O00OoOO0oo0 = urllib . quote_plus ( ii1iIi1iIiI1i . getText ( ) ) . replace ( '+' , ' ' )
     oOO = I1i11i ( iiII )
     IiIi = re . compile ( OoO ) . findall ( oOO )
     for o0Oii1111i , iIIII1iIIii , oo00 , oOOO00o000o , oO00oo0o00o0o in IiIi :
      iiI1iIii1i . update ( ooOO0OoO , '[COLOR orange]Realstream: Buscando ...[/COLOR]' , '[COLOR gold] %s [/COLOR]' % iIIII1iIIii )
      xbmc . sleep ( 5 )
      if iiI1iIii1i . iscanceled ( ) : break ;
      if re . search ( O00OoOO0oo0 , OOo0ii11I1 ( iIIII1iIIii . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       if 75 - 75: i1I111II1I + II111iiii / oO0o0ooO0 - oO0o0ooO0 / OoooooooOO
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Generando listado ...  [COLOR orange] Por favor espere ![/COLOR] , 4000)" )
       iiii11ii ( iIIII1iIIii , oOOO00o000o , 143 , o0Oii1111i , oo00 , oO00oo0o00o0o )
       iiI1iIii1i . update ( 100 , '[COLOR orange]Realstream: [/COLOR]' , '[COLOR gold] Busqueda finalizada ...[/COLOR]' )
       xbmc . sleep ( 2000 )
       iiI1iIii1i . close ( )
     OoOoOo00o0 ( '[COLOR %s]Buscar Serie[/COLOR]' % iIIIi1 , 'search' , 145 , O0OO00o0OO , oo00 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Sin Resultados para: [COLOR orange]" + O00OoOO0oo0 + "[/COLOR] , 2000)" )
     if 50 - 50: o0oO0 / OoOO0ooOOoo0O * o0oO0
     if 34 - 34: O0 * O0 % OoooooooOO + O0ooOooooO * iIii1I11I1II1 % o0oO0
   except : OoOoOo00o0 ( '[COLOR %s]Buscar Serie[/COLOR]' % iIIIi1 , 'search' , 145 , O0OO00o0OO , oo00 )
   if 25 - 25: O0oO + OoOO0ooOOoo0O . o0000oOoOoO0o % OoOO0ooOOoo0O * IIII
 except :
  pass
  if 32 - 32: i11iIiiIii - Oooo0Ooo000
def oo00ooOoo ( ) :
 if 28 - 28: o0oO0
 try :
  if 1 - 1: o0oO0
  OOoOO0OO = I1i11i ( O00Ooo )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( OOoOO0OO )
  for I1IIIiIiIi in IiIi :
   if 48 - 48: O0 + O0 . Oooo0Ooo000 - iI
   try :
    if 63 - 63: oO0o0ooO0
    iiII = I1IIIiIiIi
    if 71 - 71: i1IIi . o0oO0 * O0ooOooooO % OoooooooOO + IIII
   except :
    pass
    if 36 - 36: i1I111II1I
  oOO = I1i11i ( iiII )
  IiIi = re . compile ( OoO ) . findall ( oOO )
  for o0Oii1111i , iIIII1iIIii , oo00 , oOOO00o000o , oO00oo0o00o0o in IiIi :
   try :
    if 49 - 49: IIII / OoooooooOO / OOooOOo
    iiii11ii ( iIIII1iIIii , oOOO00o000o , 143 , o0Oii1111i , oo00 , oO00oo0o00o0o )
    if 74 - 74: Oooo0Ooo000 % o00O0oo
   except :
    pass
 except :
  pass
  if 7 - 7: II111iiii
def iIi1oOOOOOOOoO ( ) :
 if 12 - 12: O0ooOooooO . i1I111II1I . OoOO0ooOOoo0O / O0
 try :
  if 58 - 58: o0000oOoOoO0o - II111iiii % oO0o0ooO0 + Oooo0Ooo000 . OoOO0ooOOoo0O / i1I111II1I
  OOoOO0OO = I1i11i ( oO00O0 )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( OOoOO0OO )
  for I1IIIiIiIi in IiIi :
   if 8 - 8: o00O0oo . OoOO * O0oO + II111iiii % i11iIiiIii
   try :
    if 8 - 8: iI * O0
    iiII = I1IIIiIiIi
    if 73 - 73: o0000oOoOoO0o / oO0o0ooO0 / O0oO / OoOO
   except :
    pass
    if 11 - 11: OoOO0ooOOoo0O + i1I111II1I - OoooooooOO / OoOO
  oOO = I1i11i ( iiII )
  IiIi = re . compile ( OoO ) . findall ( oOO )
  for o0Oii1111i , iIIII1iIIii , oo00 , oOOO00o000o , oO00oo0o00o0o in IiIi :
   try :
    if 34 - 34: iI
    iiii11ii ( iIIII1iIIii , oOOO00o000o , 143 , o0Oii1111i , oo00 , oO00oo0o00o0o )
    if 45 - 45: iI / ii11ii1ii / o0oO0
   except :
    pass
 except :
  pass
  if 44 - 44: o00O0oo - o0oO0 / II111iiii * OoOO * ii11ii1ii
  if 73 - 73: o0000oOoOoO0o - OOooOOo * i1IIi / i11iIiiIii * IIII % II111iiii
def OooOoOOo0oO00 ( ) :
 if 73 - 73: O0ooOooooO / o00O0oo % o00O0oo * O0oO / o00O0oo
 try :
  if 8 - 8: o0oO0
  OOoOO0OO = I1i11i ( O0O0Oo00 )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( OOoOO0OO )
  for I1IIIiIiIi in IiIi :
   if 35 - 35: i1I111II1I + i1IIi * oO0o0ooO0 - o0oO0 . ii11ii1ii
   try :
    if 31 - 31: o0000oOoOoO0o
    iiII = I1IIIiIiIi
    if 15 - 15: O0 / ii11ii1ii % o00O0oo + o0000oOoOoO0o
   except :
    pass
    if 23 - 23: iIii1I11I1II1 + O0
  oOO = I1i11i ( iiII )
  IiIi = re . compile ( OoO ) . findall ( oOO )
  for o0Oii1111i , iIIII1iIIii , oo00 , oOOO00o000o , oO00oo0o00o0o in IiIi :
   try :
    if 58 - 58: ii11ii1ii
    iiii11ii ( iIIII1iIIii , oOOO00o000o , 143 , o0Oii1111i , oo00 , oO00oo0o00o0o )
    if 9 - 9: iIii1I11I1II1 % o00O0oo . IIII + OoooooooOO
   except :
    pass
 except :
  pass
  if 62 - 62: O0 / OOooOOo % O0 * OoOO % OOooOOo
def Ii ( ) :
 if 99 - 99: OoOO * i11iIiiIii . OoooooooOO % ii11ii1ii
 try :
  if 76 - 76: O0 . Oooo0Ooo000 * O0ooOooooO * IIII . OoOO0ooOOoo0O . i11iIiiIii
  OOoOO0OO = I1i11i ( I1ii1ii11i1I )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( OOoOO0OO )
  for I1IIIiIiIi in IiIi :
   if 21 - 21: o0000oOoOoO0o / OoOO0ooOOoo0O / iIii1I11I1II1 % IIII
   try :
    if 2 - 2: i11iIiiIii - II111iiii / oO0o0ooO0 % O0
    iiII = I1IIIiIiIi
    if 66 - 66: ii11ii1ii
   except :
    pass
    if 28 - 28: i1I111II1I - i1I111II1I . i1IIi - iI + OOooOOo . i1I111II1I
  oOO = I1i11i ( iiII )
  IiIi = re . compile ( OoO ) . findall ( oOO )
  for o0Oii1111i , iIIII1iIIii , oo00 , oOOO00o000o , oO00oo0o00o0o in IiIi :
   try :
    if 54 - 54: OoOO0ooOOoo0O - Oooo0Ooo000
    iiii11ii ( iIIII1iIIii , oOOO00o000o , 143 , o0Oii1111i , oo00 , oO00oo0o00o0o )
    if 3 - 3: OOooOOo - ii11ii1ii
   except :
    pass
 except :
  pass
  if 16 - 16: oO0o0ooO0 + iI / o0000oOoOoO0o
def O00oOoo0OoO0 ( ) :
 if 62 - 62: i1IIi / iI . OOooOOo * o0000oOoOoO0o
 try :
  if 21 - 21: o0000oOoOoO0o
  OOoOO0OO = I1i11i ( OOoOooOoOOOoo )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( OOoOO0OO )
  for I1IIIiIiIi in IiIi :
   if 81 - 81: O0oO / iIii1I11I1II1 - iI * Oooo0Ooo000 . OOooOOo * o00O0oo
   try :
    if 95 - 95: OOooOOo
    iiII = I1IIIiIiIi
    if 88 - 88: i1I111II1I % OoOO + Oooo0Ooo000 + Oooo0Ooo000 * II111iiii
   except :
    pass
    if 78 - 78: OoooooooOO
  oOO = I1i11i ( iiII )
  IiIi = re . compile ( OoO ) . findall ( oOO )
  for o0Oii1111i , iIIII1iIIii , oo00 , oOOO00o000o , oO00oo0o00o0o in IiIi :
   try :
    if 77 - 77: o00O0oo / i1IIi / ii11ii1ii % IIII
    iiii11ii ( iIIII1iIIii , oOOO00o000o , 143 , o0Oii1111i , oo00 , oO00oo0o00o0o )
    if 48 - 48: O0oO - i1I111II1I + iIii1I11I1II1 + OoooooooOO
   except :
    pass
 except :
  pass
  if 4 - 4: II111iiii . O0oO + o0oO0 * Oooo0Ooo000 . iI
def oOoOo ( name , url ) :
 if 74 - 74: oO0o0ooO0 / o00O0oo % o0000oOoOoO0o
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 88 - 88: OoOO0ooOOoo0O - i11iIiiIii % o0000oOoOoO0o * O0oO + o00O0oo
 OoiIIIiIi1I1i = I1i11i ( url )
 IiIi = re . compile ( I1iI1 ) . findall ( OoiIIIiIi1I1i )
 for o0Oii1111i , name , oo00 , url in IiIi :
  try :
   if 78 - 78: iIii1I11I1II1 % OoOO0ooOOoo0O + o00O0oo / i1IIi % II111iiii + IIII
   if 91 - 91: iIii1I11I1II1 % OoOO . o0000oOoOoO0o + o0oO0 + o0000oOoOoO0o
   O00OOOoOoo0O = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % O00OOOoOoo0O + name + '[/COLOR]'
   o00OOo ( name , url , 144 , o0Oii1111i , oo00 )
   if 87 - 87: OoOO % OOooOOo
   if 77 - 77: iIii1I11I1II1 - i1IIi . oO0o0ooO0
  except :
   pass
   if 26 - 26: o0000oOoOoO0o * i1I111II1I . i1IIi
   if 59 - 59: O0 + i1IIi - o0000oOoOoO0o
   if 62 - 62: i11iIiiIii % IIII . i1I111II1I . IIII
def o00OOo ( name , url , mode , iconimage , fanart ) :
 if 84 - 84: i11iIiiIii * OoOO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 18 - 18: IIII - o0oO0 - OoOO0ooOOoo0O / Oooo0Ooo000 - O0
 iiIIii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage="
 oO0Oo0O0 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 oO0Oo0O0 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 oO0Oo0O0 . setProperty ( 'fanart_image' , fanart )
 oO0Oo0O0 . setProperty ( 'IsPlayable' , 'true' )
 I1iIiI1IiIIII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiIIii , listitem = oO0Oo0O0 )
 return I1iIiI1IiIIII
 if 18 - 18: iI % i11iIiiIii . iIii1I11I1II1 - O0ooOooooO
 if 80 - 80: OOooOOo + oO0o0ooO0 - i1IIi . o0oO0 / o0000oOoOoO0o / OOooOOo
def I1Iiii ( name , url ) :
 if 34 - 34: o0oO0 * OoOO0ooOOoo0O - i1I111II1I - OOooOOo - o0oO0
 if 42 - 42: II111iiii * OOooOOo % i1IIi - o0oO0 % i1I111II1I
 IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 OOoO0 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 OO0Oooo0oOO0O = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 Ii1I1 = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 I1I1i = I1i11i ( OO0Oooo0oOO0O )
 IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
 for o000ooOOo in IiIi :
  if 46 - 46: OOooOOo / o0oO0 . Oooo0Ooo000 % i11iIiiIii + o0000oOoOoO0o + OoooooooOO
  try :
   if 93 - 93: o0oO0 - i1I111II1I . Oooo0Ooo000 % iIii1I11I1II1 % O0oO
   if 46 - 46: i11iIiiIii - IIII * O0 - i11iIiiIii + o0000oOoOoO0o
   IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 66 - 66: OOooOOo - i1I111II1I
   if 33 - 33: OOooOOo / OoOO
   if IIIi1I1IIii1II == o000ooOOo :
    if 12 - 12: II111iiii
    if 2 - 2: i1IIi - OOooOOo + O0oO . II111iiii
    if 'https://team.com' in url :
     if 25 - 25: oO0o0ooO0
     url = url . replace ( 'https://team.com' , 'https://verystream.com' )
     if 34 - 34: OoOO0ooOOoo0O . iIii1I11I1II1 % O0
    if 'https://mybox.com' in url :
     if 43 - 43: o00O0oo - O0ooOooooO
     url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
     if 70 - 70: O0ooOooooO / IIII % iI - o0oO0
     if 47 - 47: O0ooOooooO
    if 'https://vidcloud.co/' in url :
     if 92 - 92: IIII + OoOO0ooOOoo0O % i1IIi
     url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
     if 23 - 23: Oooo0Ooo000 - IIII + o0oO0 - OoOO0ooOOoo0O * OoOO0ooOOoo0O . ii11ii1ii
    if 'https://gounlimited.to' in url :
     if 47 - 47: oO0o0ooO0 % iIii1I11I1II1
     url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
     if 11 - 11: OOooOOo % o0oO0 - OoOO - oO0o0ooO0 + o0000oOoOoO0o
    if 'https://drive.com' in url :
     if 98 - 98: O0ooOooooO + o0oO0 - OoOO
     url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
     if 79 - 79: IIII / Oooo0Ooo000 . OoOO0ooOOoo0O - o00O0oo
     if 47 - 47: OoooooooOO % O0 * O0ooOooooO . o0oO0
    import resolveurl
    if 38 - 38: O0 - i1I111II1I % Oooo0Ooo000
    ooO = urlresolver . HostedMediaFile ( url )
    if 39 - 39: IIII / o00O0oo / OOooOOo * Oooo0Ooo000
    if not ooO :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
     return False
     if 44 - 44: O0 + iI . iIii1I11I1II1 + ii11ii1ii / O0 - O0oO
    try :
     iiI1iIii1i = xbmcgui . DialogProgress ( )
     iiI1iIii1i . create ( 'Realstream:' , 'Iniciando ...' )
     iiI1iIii1i . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
     xbmc . sleep ( 1000 )
     o0o0OoOOOOOo = ooO . resolve ( )
     if not o0o0OoOOOOOo or not isinstance ( o0o0OoOOOOOo , basestring ) :
      try : Ii11iii1II1i = o0o0OoOOOOOo . msg
      except : Ii11iii1II1i = url
      raise Exception ( Ii11iii1II1i )
      if 65 - 65: o0oO0 + OoOO - OoooooooOO
    except Exception as iIii :
     try : Ii11iii1II1i = str ( iIii )
     except : Ii11iii1II1i = url
     iiI1iIii1i . update ( 45 , 'RESOLVEURL:' , 'Reiniciando ... ' )
     xbmc . sleep ( 1000 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Episodio no disponible.  ,3000)" )
     iiI1iIii1i . close ( )
     if 51 - 51: ii11ii1ii + oO0o0ooO0 / O0ooOooooO - i1IIi
    iiI1iIii1i . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    iiI1iIii1i . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
    xbmc . sleep ( 500 )
    iiI1iIii1i . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
    xbmc . sleep ( 500 )
    iiI1iIii1i . update ( 100 , 'RESOLVEURL:' , 'Disfrute de este capitulo!' )
    iiI1iIii1i . close ( )
    O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
    oO0O0oO0 = xbmcgui . ListItem ( path = o0o0OoOOOOOo )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO0O0oO0 )
    if 15 - 15: iI * OoOO0ooOOoo0O % i1I111II1I . OoOO0ooOOoo0O . O0oO
    if 97 - 97: oO0o0ooO0
   else :
    if 80 - 80: OOooOOo . o0oO0
    O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
    if O0ii1ii1ii == 'true' :
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Por favor compruebe los ajustes de realstream.[/COLOR]" , "[COLOR white] Desde la seccion Tutoriales puede sacarle mayor partido a su Realstream, tambien puede configurarlo a su gusto. [/COLOR]" , "[COLOR gold]El addon no esta activado o bien configurado.[/COLOR]" )
     if 47 - 47: O0oO + iI + II111iiii % i11iIiiIii
     iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
     OoOoOo00o0 ( '[COLOR %s]Video tutoriales[/COLOR]' % iIIIi1 , IIIII11I1IiI , 125 , O0OOO0OOoO0O , oo00 )
  except :
   pass
   if 93 - 93: o00O0oo % OoOO0ooOOoo0O . O0 / O0ooOooooO * oO0o0ooO0
   if 29 - 29: o0000oOoOoO0o
   if 86 - 86: II111iiii . i1I111II1I
   if 2 - 2: OoooooooOO
   if 60 - 60: OoOO
def oO00Ooo0oO ( ) :
 if 100 - 100: OoOO / i1IIi - OOooOOo % o0oO0 - iIii1I11I1II1
 if 17 - 17: O0oO / o0000oOoOoO0o % ii11ii1ii
 o0oo00o0O0O00 = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 o0oo00o0O0O00 . doModal ( )
 if not o0oo00o0O0O00 . isConfirmed ( ) :
  return None ;
 iIIII1iIIii = o0oo00o0O0O00 . getText ( ) . strip ( )
 if 34 - 34: IIII . ii11ii1ii
 if 78 - 78: o00O0oo % OOooOOo / OoooooooOO % IIII - O0ooOooooO
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 2 - 2: iIii1I11I1II1
  iiii1 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + iIIII1iIIii + '&language=es-ES' ) )
  if 66 - 66: oO0o0ooO0 * iIii1I11I1II1 % iIii1I11I1II1 * i1I111II1I - iI - i1I111II1I
  if 70 - 70: Oooo0Ooo000 + oO0o0ooO0
  return 'android'
  if 93 - 93: Oooo0Ooo000 + o0oO0
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 33 - 33: O0
  iiii1 = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + iIIII1iIIii + '&language=es-ES' )
  if 78 - 78: O0 / II111iiii * OoOO
  if 50 - 50: OoooooooOO - iIii1I11I1II1 + i1IIi % Oooo0Ooo000 - iIii1I11I1II1 % O0
  return 'windows'
  if 58 - 58: i1I111II1I + iIii1I11I1II1
  if 65 - 65: II111iiii - Oooo0Ooo000 % o0000oOoOoO0o - OoOO0ooOOoo0O * O0ooOooooO + o0oO0
def O0o0O0OO0o ( ) :
 if 54 - 54: OoOO0ooOOoo0O . oO0o0ooO0 % i11iIiiIii / OoooooooOO + i1I111II1I % oO0o0ooO0
 try :
  if 36 - 36: oO0o0ooO0
  I1I1i = I1i11i ( O0O0ooOOO )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
  for I1IIIiIiIi in IiIi :
   if 74 - 74: OoooooooOO
   try :
    if 72 - 72: O0 + OOooOOo - O0ooOooooO - OoOO
    all = I1IIIiIiIi
    if 100 - 100: O0
   except :
    pass
    if 79 - 79: iIii1I11I1II1
  OoiIIIiIi1I1i = I1i11i ( all )
  IiIi = re . compile ( I1iII1iIi1I ) . findall ( OoiIIIiIi1I1i )
  for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
   try :
    if 81 - 81: IIII + iIii1I11I1II1 * Oooo0Ooo000 - iIii1I11I1II1 . IIII
    Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
    if 48 - 48: O0oO . OoooooooOO . OOooOOo . OoOO0ooOOoo0O % o00O0oo / O0ooOooooO
   except :
    pass
 except :
  pass
  if 11 - 11: i1IIi % OoOO % O0ooOooooO
def O0Oo0 ( ) :
 if 80 - 80: OOooOOo - iIii1I11I1II1 . IIII + OoOO - Oooo0Ooo000
 try :
  if 5 - 5: O0ooOooooO
  iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
  OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 62 - 62: OoOO0ooOOoo0O . OoooooooOO . IIII . OoOO * O0ooOooooO
  I1IooooO0oOoOOoO = I1i11i ( oOO0O00Oo0O0o )
  IiIi = re . compile ( OOI1iI1ii1II ) . findall ( I1IooooO0oOoOOoO )
  for Iii , OOOOO0O00 , iIIiIiI1I1 in IiIi :
   if re . search ( OOO00O , iIIiIiI1I1 ) :
    if 78 - 78: oO0o0ooO0 / OoOO - oO0o0ooO0 * OoooooooOO . OoOO0ooOOoo0O
    if iiII1i1 == OOOOO0O00 and o00oOO0o == Iii and OOO00O == iIIiIiI1I1 :
     if 96 - 96: OOooOOo % i1IIi . o0000oOoOoO0o . O0
     i1111 = I1i11i ( iIiIi11 )
     IiIi = re . compile ( O0O0OOOOoo ) . findall ( i1111 )
     for I1IIIiIiIi in IiIi :
      if 37 - 37: i1IIi - IIII % OoooooooOO / IIII % iI
      try :
       if 48 - 48: i11iIiiIii % oO0o0ooO0
       iiII = I1IIIiIiIi
       if 29 - 29: O0ooOooooO + i11iIiiIii % O0oO
      except :
       pass
       if 93 - 93: OoOO0ooOOoo0O % iIii1I11I1II1
     oOO = I1i11i ( iiII )
     IiIi = re . compile ( I1iII1iIi1I ) . findall ( oOO )
     for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
      try :
       if 90 - 90: OOooOOo - IIII / o0oO0 / O0 / O0oO
       Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
       if 87 - 87: OoOO0ooOOoo0O / i1I111II1I + iIii1I11I1II1
      except :
       pass
       if 93 - 93: iIii1I11I1II1 + oO0o0ooO0 % iI
    else :
     if 21 - 21: IIII
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Esta seccion ha sido cerrada![COLOR orange] Lo sentimos ...[/COLOR] ,5000)" )
     if 6 - 6: i1I111II1I
     return False
     if 46 - 46: i1I111II1I + oO0o0ooO0
 except :
  pass
  if 79 - 79: OoooooooOO - i1I111II1I * i1I111II1I . OoOO0ooOOoo0O
def Oo00ooO0OoOo ( ) :
 if 99 - 99: OoOO0ooOOoo0O
 try :
  if 77 - 77: o0000oOoOoO0o
  iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
  OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 48 - 48: OoOO0ooOOoo0O % o00O0oo / O0oO . iIii1I11I1II1 * II111iiii
  I1IooooO0oOoOOoO = I1i11i ( oOO0O00Oo0O0o )
  IiIi = re . compile ( OOI1iI1ii1II ) . findall ( I1IooooO0oOoOOoO )
  for OOOOO0O00 , Iii , iIIiIiI1I1 in IiIi :
   if re . search ( OOO00O , iIIiIiI1I1 ) :
    if 65 - 65: OoOO0ooOOoo0O
    if iiII1i1 == OOOOO0O00 and o00oOO0o == Iii and OOO00O == iIIiIiI1I1 :
     if 31 - 31: O0oO * OoOO0ooOOoo0O . i1I111II1I % o0oO0 + ii11ii1ii
     i11 = I1i11i ( iiiiI )
     IiIi = re . compile ( O0O0OOOOoo ) . findall ( i11 )
     for I1IIIiIiIi in IiIi :
      if 47 - 47: O0 * OOooOOo * OoOO . II111iiii
      try :
       O0o00o000oO = I1IIIiIiIi
      except :
       pass
       if 62 - 62: o00O0oo / O0oO . i1IIi
     I1I1i = I1i11i ( O0o00o000oO )
     IiIi = re . compile ( I1iII1iIi1I ) . findall ( I1I1i )
     for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
      try :
       if 99 - 99: OoOO0ooOOoo0O . Oooo0Ooo000
       Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
       if 59 - 59: O0oO / ii11ii1ii / IIII / O0 / OoOO0ooOOoo0O + o0000oOoOoO0o
      except :
       pass
       if 13 - 13: o0000oOoOoO0o % oO0o0ooO0 / Oooo0Ooo000 % Oooo0Ooo000 % O0
    else :
     if 90 - 90: i1I111II1I . iI / iIii1I11I1II1
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Esta seccion ha sido cerrada![COLOR orange] Lo sentimos ...[/COLOR] ,5000)" )
     if 28 - 28: i1I111II1I + oO0o0ooO0 - iI / iIii1I11I1II1 - OOooOOo
     return False
 except :
  pass
  if 45 - 45: O0 / i1IIi * oO0o0ooO0 * OoOO
def II11I ( ) :
 if 31 - 31: o0oO0
 try :
  if 18 - 18: iI + o0oO0
  iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
  OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 5 - 5: OoooooooOO + O0oO * II111iiii
  I1IooooO0oOoOOoO = I1i11i ( oOO0O00Oo0O0o )
  IiIi = re . compile ( OOI1iI1ii1II ) . findall ( I1IooooO0oOoOOoO )
  for Iii , OOOOO0O00 , iIIiIiI1I1 in IiIi :
   if re . search ( OOO00O , iIIiIiI1I1 ) :
    if 98 - 98: IIII % i1IIi . OOooOOo . II111iiii . o00O0oo / i11iIiiIii
    if iiII1i1 == OOOOO0O00 and o00oOO0o == Iii and OOO00O == iIIiIiI1I1 :
     if 32 - 32: o0000oOoOoO0o + OOooOOo . Oooo0Ooo000
     I1I1i = I1i11i ( db2 )
     IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
     for I1IIIiIiIi in IiIi :
      if 41 - 41: OoOO0ooOOoo0O . i11iIiiIii / O0oO
      try :
       if 98 - 98: OoOO0ooOOoo0O % II111iiii
       OoO0O000 = I1IIIiIiIi
       if 14 - 14: OoOO / OoOO * O0 . oO0o0ooO0
      except :
       pass
       if 59 - 59: II111iiii * i11iIiiIii
       if 54 - 54: O0 % OoooooooOO - OOooOOo
     I1I1i = I1i11i ( OoO0O000 )
     IiIi = re . compile ( I1iII1iIi1I ) . findall ( I1I1i )
     for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
      try :
       Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
       if 61 - 61: ii11ii1ii * i1I111II1I . ii11ii1ii + ii11ii1ii / i1I111II1I * O0
      except :
       pass
    else :
     if 73 - 73: O0ooOooooO * O0ooOooooO / iI
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Esta seccion ha sido cerrada![COLOR orange] Lo sentimos ...[/COLOR] ,5000)" )
     if 43 - 43: o00O0oo . i1IIi . i1I111II1I + O0 * o0oO0 * O0
     return False
     if 41 - 41: o00O0oo + o0oO0 % OoooooooOO . o00O0oo + O0ooOooooO . O0ooOooooO
 except :
  pass
  if 31 - 31: i11iIiiIii + II111iiii . O0ooOooooO * OoOO0ooOOoo0O
def OO0ooo0 ( ) :
 if 7 - 7: o00O0oo - oO0o0ooO0 * IIII + o0000oOoOoO0o . o00O0oo
 try :
  if 85 - 85: O0
  IiiIiI1I1 = I1i11i ( Oo0o0O00 )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( IiiIiI1I1 )
  for I1IIIiIiIi in IiIi :
   if 19 - 19: o0oO0
   try :
    if 55 - 55: IIII % IIII / O0 % O0ooOooooO - o0000oOoOoO0o . ii11ii1ii
    iiiii1I1III1 = I1IIIiIiIi
    if 12 - 12: O0ooOooooO . OoOO0ooOOoo0O * OOooOOo
   except :
    pass
    if 37 - 37: o00O0oo * OOooOOo % i11iIiiIii % i1IIi % i1I111II1I
    if 15 - 15: iIii1I11I1II1 . O0
  I1I1i = I1i11i ( iiiii1I1III1 )
  IiIi = re . compile ( I1iII1iIi1I ) . findall ( I1I1i )
  for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
   try :
    if 70 - 70: o0oO0 . i11iIiiIii % o0oO0 . O0 - iIii1I11I1II1
    Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
    if 26 - 26: IIII
   except :
    pass
 except :
  pass
  if 76 - 76: i1IIi * OoooooooOO * O0 + Oooo0Ooo000 * Oooo0Ooo000
def i1iIiIii ( ) :
 if 20 - 20: o0000oOoOoO0o * iI
 try :
  if 10 - 10: O0oO - ii11ii1ii
  I1I1i = I1i11i ( OOoO )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
  for I1IIIiIiIi in IiIi :
   if 59 - 59: OoooooooOO * ii11ii1ii + i1IIi
   try :
    if 23 - 23: iI
    i11oooOo = I1IIIiIiIi
    if 98 - 98: II111iiii - OoooooooOO * O0
   except :
    pass
    if 85 - 85: OoooooooOO % OoOO0ooOOoo0O * iIii1I11I1II1
    if 44 - 44: iIii1I11I1II1 . o00O0oo + Oooo0Ooo000 . iI
  I1I1i = I1i11i ( i11oooOo )
  IiIi = re . compile ( I1iII1iIi1I ) . findall ( I1I1i )
  for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
   try :
    Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
    if 7 - 7: o00O0oo + iIii1I11I1II1 * O0oO * O0oO / II111iiii - o0oO0
   except :
    pass
 except :
  pass
  if 65 - 65: oO0o0ooO0 + OoOO0ooOOoo0O + II111iiii
def oOOoo ( ) :
 if 6 - 6: IIII
 try :
  if 98 - 98: OoooooooOO % O0 - O0
  I1I1i = I1i11i ( iiIiI1i1 )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
  for I1IIIiIiIi in IiIi :
   if 76 - 76: i1IIi % OoOO0ooOOoo0O - OOooOOo / o0000oOoOoO0o * iI
   try :
    if 4 - 4: ii11ii1ii * ii11ii1ii / OoOO0ooOOoo0O
    Ii1Ii1Ii1I1I = I1IIIiIiIi
    if 48 - 48: ii11ii1ii - iI + ii11ii1ii - OOooOOo * i11iIiiIii . O0ooOooooO
   except :
    pass
    if 35 - 35: i1I111II1I . O0 + ii11ii1ii + IIII + i1IIi
  I1I1i = I1i11i ( Ii1Ii1Ii1I1I )
  IiIi = re . compile ( I1iII1iIi1I ) . findall ( I1I1i )
  for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
   try :
    Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
    if 65 - 65: O0 * OOooOOo / OOooOOo . OoOO0ooOOoo0O
   except :
    pass
 except :
  pass
  if 87 - 87: II111iiii * o00O0oo % ii11ii1ii * ii11ii1ii
def O0OOOOOO0 ( ) :
 if 79 - 79: II111iiii - iI . i1IIi + O0 % O0 * OOooOOo
 try :
  if 7 - 7: i1IIi + IIII % O0ooOooooO / o0000oOoOoO0o + i1IIi
  I1I1i = I1i11i ( IiIi11iI )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
  for I1IIIiIiIi in IiIi :
   if 41 - 41: o0oO0 + i11iIiiIii / i1I111II1I % o00O0oo
   try :
    if 22 - 22: OoOO0ooOOoo0O % o0000oOoOoO0o * o0oO0 - o00O0oo + o0000oOoOoO0o - ii11ii1ii
    iiIi1iiI1I = I1IIIiIiIi
    if 26 - 26: iIii1I11I1II1 + i1IIi / OoOO0ooOOoo0O % o00O0oo
   except :
    pass
    if 44 - 44: OoooooooOO . II111iiii . IIII % OoooooooOO
    if 86 - 86: i11iIiiIii + O0 * i1I111II1I - OoOO * IIII + O0
  I1I1i = I1i11i ( iiIi1iiI1I )
  IiIi = re . compile ( I1iII1iIi1I ) . findall ( I1I1i )
  for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
   try :
    Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
    if 95 - 95: iIii1I11I1II1 . Oooo0Ooo000 % O0ooOooooO - Oooo0Ooo000 * II111iiii
   except :
    pass
 except :
  pass
  if 89 - 89: O0ooOooooO . OOooOOo
def ooOoo0OoOO ( ) :
 if 38 - 38: OoOO / iI % Oooo0Ooo000 * O0oO + i11iIiiIii % iI
 try :
  if 61 - 61: Oooo0Ooo000 - o0oO0 % o00O0oo / iI / O0ooOooooO + iIii1I11I1II1
  I1I1i = I1i11i ( i11I1IiII1i1i )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
  for I1IIIiIiIi in IiIi :
   if 87 - 87: Oooo0Ooo000 + iI + O0 / i1IIi % i1I111II1I / Oooo0Ooo000
   try :
    if 64 - 64: OoOO % i1I111II1I . Oooo0Ooo000 % OoOO + O0oO * i1I111II1I
    OOOO00OooO = I1IIIiIiIi
    if 64 - 64: OoOO . OOooOOo - OoooooooOO . iI - O0ooOooooO
   except :
    pass
    if 77 - 77: o0oO0 % OoOO0ooOOoo0O / II111iiii % O0ooOooooO % OoooooooOO % OoOO
    if 19 - 19: i1I111II1I * Oooo0Ooo000 / oO0o0ooO0 * Oooo0Ooo000 - OoooooooOO * O0oO
  I1I1i = I1i11i ( OOOO00OooO )
  IiIi = re . compile ( I1iII1iIi1I ) . findall ( I1I1i )
  for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
   try :
    Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
    if 17 - 17: II111iiii + ii11ii1ii . Oooo0Ooo000
   except :
    pass
 except :
  pass
  if 12 - 12: Oooo0Ooo000 + IIII + O0oO . i1I111II1I / o0oO0
def i1IoOOoooO0O0 ( ) :
 if 46 - 46: iIii1I11I1II1
 try :
  if 33 - 33: O0oO % O0oO % O0 / OOooOOo . i1IIi
  I1I1i = I1i11i ( I1111i )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
  for I1IIIiIiIi in IiIi :
   if 91 - 91: iI * O0oO - II111iiii . OOooOOo - ii11ii1ii + iI
   try :
    if 56 - 56: o0000oOoOoO0o / i1I111II1I * OOooOOo . o0000oOoOoO0o
    ii = I1IIIiIiIi
    if 88 - 88: Oooo0Ooo000 % i1I111II1I / o0oO0 - OOooOOo / OOooOOo * iI
   except :
    pass
    if 77 - 77: i1I111II1I
    if 66 - 66: iIii1I11I1II1 . i11iIiiIii / O0oO / iI + Oooo0Ooo000
  I1I1i = I1i11i ( ii )
  IiIi = re . compile ( I1iII1iIi1I ) . findall ( I1I1i )
  for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
   try :
    Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
    if 5 - 5: OoOO0ooOOoo0O % O0ooOooooO + i1I111II1I
   except :
    pass
 except :
  pass
  if 13 - 13: i1I111II1I
def ii1II1II ( ) :
 if 42 - 42: o0oO0
 try :
  if 68 - 68: IIII . ii11ii1ii % iI - OoooooooOO * O0ooOooooO . IIII
  I1I1i = I1i11i ( OOo0O0oo0OO0O )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
  for I1IIIiIiIi in IiIi :
   if 46 - 46: i11iIiiIii - IIII * OOooOOo * O0oO % o00O0oo * i1IIi
   try :
    if 5 - 5: O0 / iI . ii11ii1ii + OoooooooOO
    O0o = I1IIIiIiIi
    if 78 - 78: IIII % iIii1I11I1II1
   except :
    pass
    if 50 - 50: OOooOOo % iIii1I11I1II1 % IIII
    if 84 - 84: i1I111II1I + o00O0oo + o0oO0 + O0ooOooooO
  I1I1i = I1i11i ( O0o )
  IiIi = re . compile ( I1iII1iIi1I ) . findall ( I1I1i )
  for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
   try :
    Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
    if 62 - 62: i11iIiiIii + OoOO0ooOOoo0O + i1IIi
   except :
    pass
 except :
  pass
  if 69 - 69: OoOO0ooOOoo0O
  if 63 - 63: OoOO / OoOO0ooOOoo0O * iIii1I11I1II1 . Oooo0Ooo000
def Ooooo ( ) :
 if 43 - 43: IIII
 try :
  if 57 - 57: O0 / o0000oOoOoO0o
  I1I1i = I1i11i ( o00O0O )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
  for I1IIIiIiIi in IiIi :
   if 12 - 12: OoooooooOO / O0 + II111iiii * o00O0oo
   try :
    if 46 - 46: II111iiii - i1I111II1I * OoooooooOO / oO0o0ooO0 % i1I111II1I
    Iii11III1I11 = I1IIIiIiIi
    if 40 - 40: i11iIiiIii . iIii1I11I1II1
   except :
    pass
    if 2 - 2: i1IIi * oO0o0ooO0 - oO0o0ooO0 + OoooooooOO % OoOO0ooOOoo0O / OoOO0ooOOoo0O
    if 3 - 3: OoooooooOO
  I1I1i = I1i11i ( Iii11III1I11 )
  IiIi = re . compile ( I1iII1iIi1I ) . findall ( I1I1i )
  for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
   try :
    Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
    if 71 - 71: i1I111II1I + i1IIi - O0ooOooooO - i11iIiiIii . O0oO - iI
   except :
    pass
 except :
  pass
  if 85 - 85: o00O0oo - OoOO0ooOOoo0O / o00O0oo + IIII - O0ooOooooO
  if 49 - 49: OoOO - O0 / OoOO * OoOO0ooOOoo0O + Oooo0Ooo000
def Iiii1I ( ) :
 if 61 - 61: iIii1I11I1II1 - O0oO / O0ooOooooO * O0oO % o0oO0 % O0ooOooooO
 try :
  if 63 - 63: IIII % iIii1I11I1II1
  I1I1i = I1i11i ( Iii1I1111ii )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
  for I1IIIiIiIi in IiIi :
   if 20 - 20: OoOO . OOooOOo * i11iIiiIii / i11iIiiIii
   try :
    if 89 - 89: O0ooOooooO . i11iIiiIii * O0
    Iiii1 = I1IIIiIiIi
    if 27 - 27: IIII
   except :
    pass
    if 52 - 52: Oooo0Ooo000 % OoOO0ooOOoo0O + iIii1I11I1II1 * oO0o0ooO0 . o0oO0
    if 95 - 95: iIii1I11I1II1 . i1I111II1I - OoooooooOO * OoOO / o0000oOoOoO0o
  I1I1i = I1i11i ( Iiii1 )
  IiIi = re . compile ( I1iII1iIi1I ) . findall ( I1I1i )
  for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
   try :
    Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
    if 74 - 74: oO0o0ooO0
   except :
    pass
    if 34 - 34: O0ooOooooO
 except :
  pass
  if 44 - 44: i1IIi % OOooOOo % o0000oOoOoO0o
  if 9 - 9: ii11ii1ii % OoooooooOO - o0oO0
def iIII11Iiii1 ( ) :
 if 95 - 95: OOooOOo
 try :
  if 99 - 99: O0
  I1I1i = I1i11i ( Ii1IIiI1i )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
  for I1IIIiIiIi in IiIi :
   if 76 - 76: Oooo0Ooo000 - oO0o0ooO0 . IIII % o0000oOoOoO0o
   try :
    if 30 - 30: o00O0oo % O0oO / Oooo0Ooo000
    i11IiI1I = I1IIIiIiIi
    if 70 - 70: OoOO % OOooOOo / OOooOOo . O0oO % iI . II111iiii
   except :
    pass
    if 10 - 10: o0oO0 - i11iIiiIii . o00O0oo % i1IIi
    if 78 - 78: iIii1I11I1II1 * ii11ii1ii . ii11ii1ii - IIII . iIii1I11I1II1
  I1I1i = I1i11i ( i11IiI1I )
  IiIi = re . compile ( I1iII1iIi1I ) . findall ( I1I1i )
  for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
   try :
    Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
    if 30 - 30: iI + iI % i1I111II1I - o0000oOoOoO0o - o00O0oo
   except :
    pass
    if 36 - 36: O0oO % IIII
 except :
  pass
  if 72 - 72: OOooOOo / O0ooOooooO - O0 + O0oO
def o0iIIIIi ( ) :
 if 50 - 50: Oooo0Ooo000 + iI + O0ooOooooO
 try :
  if 15 - 15: O0oO
  I1I1i = I1i11i ( IiII111i1i11 )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
  for I1IIIiIiIi in IiIi :
   if 13 - 13: iIii1I11I1II1 * OoOO0ooOOoo0O / Oooo0Ooo000 % iI + oO0o0ooO0
   try :
    if 41 - 41: o00O0oo
    i1iI1i = I1IIIiIiIi
    if 59 - 59: i1I111II1I
   except :
    pass
    if 89 - 89: OoOO0ooOOoo0O % iIii1I11I1II1
  I1I1i = I1i11i ( i1iI1i )
  IiIi = re . compile ( I1iII1iIi1I ) . findall ( I1I1i )
  for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
   try :
    Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
    if 35 - 35: o00O0oo + Oooo0Ooo000 - OoOO0ooOOoo0O % oO0o0ooO0 % o0000oOoOoO0o % OoOO0ooOOoo0O
   except :
    pass
 except :
  pass
  if 45 - 45: OOooOOo * IIII % OoOO
  if 24 - 24: iI - O0oO * oO0o0ooO0
def O00OoOoO ( ) :
 if 58 - 58: o00O0oo
 try :
  if 19 - 19: iIii1I11I1II1 * OoooooooOO * i11iIiiIii
  I1I1i = I1i11i ( oooO )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
  for I1IIIiIiIi in IiIi :
   if 79 - 79: i1I111II1I % OoOO
   try :
    if 81 - 81: i11iIiiIii + i11iIiiIii * OoOO + i1I111II1I
    iii = I1IIIiIiIi
    if 15 - 15: OOooOOo . OoOO
   except :
    pass
    if 17 - 17: i11iIiiIii / ii11ii1ii . OoOO / OOooOOo
    if 38 - 38: i1IIi . o00O0oo % o0oO0 + iIii1I11I1II1 + O0
  I1I1i = I1i11i ( iii )
  IiIi = re . compile ( I1iII1iIi1I ) . findall ( I1I1i )
  for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
   try :
    Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
    if 47 - 47: OoOO + i1I111II1I / II111iiii
   except :
    pass
 except :
  pass
  if 97 - 97: o00O0oo / OOooOOo % O0 + i1IIi - iI
  if 38 - 38: o0000oOoOoO0o % Oooo0Ooo000 + i11iIiiIii + O0ooOooooO + iI / i11iIiiIii
def o0OOOOOo0 ( ) :
 if 57 - 57: iIii1I11I1II1 + iIii1I11I1II1
 try :
  if 56 - 56: oO0o0ooO0 + iI
  I1I1i = I1i11i ( ooo )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
  for I1IIIiIiIi in IiIi :
   if 32 - 32: II111iiii + OoOO0ooOOoo0O % iI / OoOO0ooOOoo0O + o00O0oo
   try :
    if 2 - 2: i11iIiiIii - Oooo0Ooo000 + OoOO % O0oO * o0oO0
    Ooo000O00 = I1IIIiIiIi
    if 36 - 36: IIII % i11iIiiIii
   except :
    pass
  I1I1i = I1i11i ( Ooo000O00 )
  IiIi = re . compile ( I1iII1iIi1I ) . findall ( I1I1i )
  for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
   try :
    Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
    if 47 - 47: i1IIi + II111iiii . ii11ii1ii * oO0o0ooO0 . O0oO / i1IIi
   except :
    pass
 except :
  pass
  if 50 - 50: Oooo0Ooo000 / i1IIi % OoooooooOO
def oOOOOO0Ooooo ( ) :
 if 57 - 57: o0oO0 - OoooooooOO
 try :
  if 68 - 68: o0000oOoOoO0o % o00O0oo / Oooo0Ooo000 + Oooo0Ooo000 - Oooo0Ooo000 . OoOO
  I1I1i = I1i11i ( Ooo0oOooo0 )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
  for I1IIIiIiIi in IiIi :
   if 100 - 100: OoOO0ooOOoo0O % ii11ii1ii
   try :
    if 76 - 76: II111iiii / OoOO + OoooooooOO . o00O0oo . O0oO . iI
    iiiI = I1IIIiIiIi
    if 10 - 10: o00O0oo % OOooOOo - II111iiii
   except :
    pass
    if 11 - 11: O0 + OOooOOo
    if 80 - 80: oO0o0ooO0 % oO0o0ooO0 % O0 - i11iIiiIii . O0ooOooooO / O0
  I1I1i = I1i11i ( iiiI )
  IiIi = re . compile ( I1iII1iIi1I ) . findall ( I1I1i )
  for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
   try :
    Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
    if 13 - 13: OOooOOo + O0 - o00O0oo % ii11ii1ii / o0oO0 . i1IIi
   except :
    pass
 except :
  pass
  if 60 - 60: ii11ii1ii . i1I111II1I % OOooOOo - Oooo0Ooo000
  if 79 - 79: OoooooooOO / o00O0oo . O0
def oOoO0Oo0 ( ) :
 if 7 - 7: iI + o0oO0
 try :
  if 32 - 32: iIii1I11I1II1 % OOooOOo / i11iIiiIii + IIII - o0000oOoOoO0o . O0ooOooooO
  I1I1i = I1i11i ( iiIiIIIiiI )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
  for I1IIIiIiIi in IiIi :
   if 86 - 86: i1IIi / o0oO0 * OOooOOo
   try :
    if 67 - 67: o00O0oo * o00O0oo / oO0o0ooO0 * OoooooooOO + OoOO0ooOOoo0O
    oooo = I1IIIiIiIi
    if 63 - 63: iI % OOooOOo
   except :
    pass
    if 75 - 75: iI / ii11ii1ii
    if 8 - 8: iIii1I11I1II1
  I1I1i = I1i11i ( oooo )
  IiIi = re . compile ( I1iII1iIi1I ) . findall ( I1I1i )
  for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
   try :
    Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
    if 30 - 30: o0oO0 - i11iIiiIii
   except :
    pass
 except :
  pass
  if 3 - 3: i1I111II1I / O0oO
def Ii11 ( ) :
 if 3 - 3: o0oO0 + Oooo0Ooo000 . i1IIi / IIII % Oooo0Ooo000
 try :
  if 98 - 98: i1I111II1I * iIii1I11I1II1 . o0oO0 * ii11ii1ii / o00O0oo + iI
  I1I1i = I1i11i ( II11IiIi11 )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
  for I1IIIiIiIi in IiIi :
   if 25 - 25: oO0o0ooO0
   try :
    if 19 - 19: OOooOOo % o0oO0 . i1I111II1I * iI
    oOo0OOOOoO = I1IIIiIiIi
    if 70 - 70: II111iiii + Oooo0Ooo000 + i11iIiiIii - i1IIi / i1I111II1I
   except :
    pass
    if 40 - 40: o00O0oo * Oooo0Ooo000
    if 38 - 38: O0 . ii11ii1ii + OoOO0ooOOoo0O - oO0o0ooO0
  I1I1i = I1i11i ( oOo0OOOOoO )
  IiIi = re . compile ( I1iII1iIi1I ) . findall ( I1I1i )
  for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
   try :
    Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
    if 43 - 43: O0ooOooooO + ii11ii1ii / OoooooooOO
   except :
    pass
 except :
  pass
  if 24 - 24: O0 + o0000oOoOoO0o * o0oO0 - Oooo0Ooo000
  if 10 - 10: i11iIiiIii
def ii11i ( ) :
 if 71 - 71: o0oO0 * Oooo0Ooo000 % II111iiii . o0oO0 % OoOO + o00O0oo
 try :
  if 66 - 66: o0oO0 - ii11ii1ii . i1IIi
  I1I1i = I1i11i ( I1iiii1I )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
  for I1IIIiIiIi in IiIi :
   if 75 - 75: o0oO0 - O0oO % OoOO0ooOOoo0O
   try :
    if 80 - 80: o0oO0 / IIII
    iIIi1i11 = I1IIIiIiIi
    if 34 - 34: OoOO % o0000oOoOoO0o % OOooOOo
   except :
    pass
    if 3 - 3: OoooooooOO * OOooOOo * oO0o0ooO0 - i1I111II1I - iI
    if 21 - 21: OoooooooOO - o00O0oo . OoOO0ooOOoo0O
  I1I1i = I1i11i ( iIIi1i11 )
  IiIi = re . compile ( I1iII1iIi1I ) . findall ( I1I1i )
  for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
   try :
    Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
    if 90 - 90: iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 56 - 56: IIII
  if 49 - 49: iI . II111iiii
def IioOooOOo00ooO ( ) :
 if 71 - 71: Oooo0Ooo000 - o0000oOoOoO0o - IIII
 try :
  if 28 - 28: iIii1I11I1II1
  I1I1i = I1i11i ( oO00ooooO0o )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
  for I1IIIiIiIi in IiIi :
   if 7 - 7: o0000oOoOoO0o % i1I111II1I * OoOO0ooOOoo0O
   try :
    if 58 - 58: i1I111II1I / O0oO + II111iiii % O0ooOooooO - OoooooooOO
    II1iII1i1i = I1IIIiIiIi
    if 63 - 63: IIII * O0oO
   except :
    pass
    if 22 - 22: o00O0oo * O0 * iIii1I11I1II1
    if 77 - 77: II111iiii + o0000oOoOoO0o
  I1I1i = I1i11i ( II1iII1i1i )
  IiIi = re . compile ( I1iII1iIi1I ) . findall ( I1I1i )
  for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
   try :
    Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
    if 47 - 47: IIII
   except :
    pass
 except :
  pass
  if 75 - 75: i1I111II1I % i11iIiiIii + iIii1I11I1II1
  if 92 - 92: OoOO0ooOOoo0O % O0
def oo00ooooOOo00 ( ) :
 if 16 - 16: i11iIiiIii / i1IIi % IIII
 try :
  if 84 - 84: O0oO - ii11ii1ii * O0 / o0oO0 . o0oO0
  I1I1i = I1i11i ( o0oO0oooOoo )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
  for I1IIIiIiIi in IiIi :
   if 93 - 93: O0 / iI + OOooOOo
   try :
    if 20 - 20: i1I111II1I / O0ooOooooO % OoooooooOO / iIii1I11I1II1 + OOooOOo
    oO0o = I1IIIiIiIi
    if 22 - 22: OoOO / ii11ii1ii / OoOO0ooOOoo0O
   except :
    pass
    if 7 - 7: ii11ii1ii - i1IIi . o00O0oo / iIii1I11I1II1 * o0000oOoOoO0o
    if 100 - 100: iI / iI - IIII % IIII * oO0o0ooO0 / i1I111II1I
  I1I1i = I1i11i ( oO0o )
  IiIi = re . compile ( I1iII1iIi1I ) . findall ( I1I1i )
  for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
   try :
    Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
    if 32 - 32: OOooOOo + o00O0oo - oO0o0ooO0 + o00O0oo / i1IIi * oO0o0ooO0
   except :
    pass
 except :
  pass
  if 90 - 90: o0oO0 % oO0o0ooO0
  if 6 - 6: OoooooooOO / i11iIiiIii / Oooo0Ooo000
def OooO0O0Ooo ( ) :
 if 85 - 85: o0000oOoOoO0o / Oooo0Ooo000
 try :
  if 67 - 67: O0oO % oO0o0ooO0
  I1I1i = I1i11i ( I1i111I )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
  for I1IIIiIiIi in IiIi :
   if 39 - 39: i11iIiiIii + i1I111II1I
   try :
    if 7 - 7: iIii1I11I1II1 - i1IIi
    I1ii1i1iiii = I1IIIiIiIi
    if 45 - 45: o0oO0 / iI . OoooooooOO + OoOO
   except :
    pass
    if 51 - 51: O0ooOooooO % i11iIiiIii % i1I111II1I + Oooo0Ooo000 % o00O0oo
  I1I1i = I1i11i ( I1ii1i1iiii )
  IiIi = re . compile ( I1iII1iIi1I ) . findall ( I1I1i )
  for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
   try :
    Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
    if 16 - 16: OoOO0ooOOoo0O / ii11ii1ii + O0 - OoOO0ooOOoo0O . OoooooooOO
   except :
    pass
 except :
  pass
  if 19 - 19: o0000oOoOoO0o
  if 73 - 73: Oooo0Ooo000 * ii11ii1ii * OoOO0ooOOoo0O
def Oo0OOo ( ) :
 if 44 - 44: O0oO * o0000oOoOoO0o
 try :
  if 49 - 49: IIII % O0oO * i11iIiiIii / oO0o0ooO0 % IIII
  I1I1i = I1i11i ( I1i11 )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
  for I1IIIiIiIi in IiIi :
   if 70 - 70: OoOO0ooOOoo0O / II111iiii % iI - O0ooOooooO
   try :
    if 2 - 2: Oooo0Ooo000 - o00O0oo + o0000oOoOoO0o * OoOO / O0ooOooooO
    iIIiI11iI1Ii1 = I1IIIiIiIi
    if 94 - 94: iI / i11iIiiIii % O0
   except :
    pass
    if 70 - 70: O0oO - ii11ii1ii / OoooooooOO % OoooooooOO
    if 95 - 95: OoooooooOO % OoooooooOO . o0oO0
  I1I1i = I1i11i ( iIIiI11iI1Ii1 )
  IiIi = re . compile ( I1iII1iIi1I ) . findall ( I1I1i )
  for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
   try :
    Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
    if 26 - 26: oO0o0ooO0 + i1I111II1I - II111iiii . II111iiii + o00O0oo + OoOO0ooOOoo0O
   except :
    pass
 except :
  pass
  if 68 - 68: O0
def o0oOoO00 ( ) :
 if 94 - 94: OoOO + i1I111II1I + iI
 try :
  if 82 - 82: ii11ii1ii - ii11ii1ii . iIii1I11I1II1 / IIII + i1I111II1I % iIii1I11I1II1
  I1I1i = I1i11i ( IiIIi1 )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
  for I1IIIiIiIi in IiIi :
   if 61 - 61: IIII / ii11ii1ii % IIII - OoOO + iI / iI
   try :
    if 82 - 82: ii11ii1ii
    IIIIIi11111iiiII1I = I1IIIiIiIi
    if 13 - 13: IIII / i1I111II1I - OoOO / IIII . i1IIi
   except :
    pass
  I1I1i = I1i11i ( IIIIIi11111iiiII1I )
  IiIi = re . compile ( I1iII1iIi1I ) . findall ( I1I1i )
  for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
   try :
    Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
    if 22 - 22: O0 - O0oO + Oooo0Ooo000 . o0oO0 * i1IIi
   except :
    pass
 except :
  pass
  if 26 - 26: iIii1I11I1II1 * o0000oOoOoO0o . O0oO
def I11III11III1 ( ) :
 if 81 - 81: O0 . O0
 try :
  if 75 - 75: iIii1I11I1II1 % i1I111II1I + o00O0oo * O0 . O0ooOooooO - iI
  I1I1i = I1i11i ( II1i11I )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
  for I1IIIiIiIi in IiIi :
   if 32 - 32: o0oO0 % oO0o0ooO0 - i1IIi
   try :
    if 40 - 40: iIii1I11I1II1 + O0ooOooooO * OoOO0ooOOoo0O + oO0o0ooO0
    I1Ii1i11I1I = I1IIIiIiIi
    if 71 - 71: OOooOOo * i1IIi % O0oO
   except :
    pass
  I1I1i = I1i11i ( I1Ii1i11I1I )
  IiIi = re . compile ( I1iII1iIi1I ) . findall ( I1I1i )
  for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
   try :
    Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
    if 82 - 82: i1I111II1I . OoOO0ooOOoo0O / iI + O0ooOooooO - iI
   except :
    pass
 except :
  pass
  if 55 - 55: iI % ii11ii1ii % o0000oOoOoO0o
def I1Ii ( ) :
 if 76 - 76: O0ooOooooO % OoOO0ooOOoo0O % iIii1I11I1II1 . IIII
 try :
  if 30 - 30: i1IIi
  I1I1i = I1i11i ( OoOOoooOO0O )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
  for I1IIIiIiIi in IiIi :
   if 75 - 75: O0oO . IIII - iIii1I11I1II1 * OoOO * O0ooOooooO
   try :
    if 93 - 93: iI
    iII1IIiiI11II = I1IIIiIiIi
    if 70 - 70: o0oO0 - IIII * IIII / iIii1I11I1II1 + O0
   except :
    pass
  I1I1i = I1i11i ( iII1IIiiI11II )
  IiIi = re . compile ( I1iII1iIi1I ) . findall ( I1I1i )
  for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o , id , iIi11i1 , oO00oo0o00o0o , oo00 in IiIi :
   try :
    Ii111iIi1iIi ( iIIII1iIIii , oOOO00o000o , O0o0OO0000ooo , id , iIi11i1 , oO00oo0o00o0o , oo00 )
    if 49 - 49: i11iIiiIii - o00O0oo - O0oO / OoooooooOO % OoOO0ooOOoo0O
   except :
    pass
 except :
  pass
  if 65 - 65: O0 - Oooo0Ooo000 . o0oO0
def IIOOO00o0 ( ) :
 if 97 - 97: o00O0oo / o00O0oo / iIii1I11I1II1 % i1IIi . o00O0oo . i1I111II1I
 try :
  if 4 - 4: ii11ii1ii - OoOO - i11iIiiIii * Oooo0Ooo000 / o0oO0 - IIII
  I1I1i = I1i11i ( O0o0oO )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
  for I1IIIiIiIi in IiIi :
   if 45 - 45: o0000oOoOoO0o % ii11ii1ii * i1IIi - O0
   try :
    if 82 - 82: II111iiii / O0ooOooooO
    OOoOi1IiiI = I1IIIiIiIi
    if 70 - 70: O0oO . IIII * ii11ii1ii / IIII
   except :
    pass
  I1I1i = I1i11i ( OOoOi1IiiI )
  IiIi = re . compile ( i1I1ii11i1Iii ) . findall ( I1I1i )
  for O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o in IiIi :
   try :
    Oo0OoOo ( O0o0OO0000ooo , iIIII1iIIii , oOOO00o000o )
    if 13 - 13: o0000oOoOoO0o
   except :
    pass
    if 7 - 7: OOooOOo + i1I111II1I / i11iIiiIii / ii11ii1ii
 except :
  pass
  if 97 - 97: Oooo0Ooo000 . O0oO / OOooOOo
  if 83 - 83: O0oO - o00O0oo * oO0o0ooO0
  if 90 - 90: ii11ii1ii * OOooOOo
def Oo0OoOo ( thumb , name , url ) :
 if 75 - 75: o00O0oo - OoOO0ooOOoo0O * i11iIiiIii . OoooooooOO - ii11ii1ii . O0oO
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 if 6 - 6: O0oO * oO0o0ooO0 / OoooooooOO % o0oO0 * o0000oOoOoO0o
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   OoOoOo00o0 ( name , url , '' , o00 , oo00 )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 28 - 28: i1I111II1I * OOooOOo % i1I111II1I
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 95 - 95: O0 / O0oO . Oooo0Ooo000
   iII11II1II ( name , url , 4 , o0Oii1111i , oo00 )
   if 100 - 100: OoOO % Oooo0Ooo000 - O0oO % O0oO % O0oO / iI
  else :
   if 83 - 83: oO0o0ooO0 - iI - i1I111II1I % i1IIi - O0ooOooooO . o0000oOoOoO0o
   iII11II1II ( name , url , 4 , o0Oii1111i , oo00 )
   if 96 - 96: ii11ii1ii + Oooo0Ooo000 . i1IIi
def OooIii1I1iI ( name , url , thumb , id , trailer ) :
 if 62 - 62: oO0o0ooO0 + ii11ii1ii / i11iIiiIii
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 90 - 90: iIii1I11I1II1 + OoOO0ooOOoo0O
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   OoOoOo00o0 ( name , url , '' , o00 , oo00 )
 else :
  O00OOOoOoo0O = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
  if 9 - 9: iIii1I11I1II1 . OoooooooOO + i1IIi - ii11ii1ii
  name = '[COLOR %s]' % O00OOOoOoo0O + name + '[/COLOR]'
  if 30 - 30: O0ooOooooO / OoOO . O0ooOooooO
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   III1iII1I1ii = IiII1IiiIiI1 . getSetting ( 'selecton' )
   if III1iII1I1ii == 'true' :
    if 17 - 17: ii11ii1ii + OoooooooOO * OoooooooOO
    i1iiIIiII1 ( name , url , 1 , thumb , thumb , id , trailer )
    if 72 - 72: i1I111II1I % o0000oOoOoO0o
   else :
    if 93 - 93: iIii1I11I1II1 + i11iIiiIii . o0000oOoOoO0o . i1IIi % OOooOOo % iI
    i1iiIIiII1 ( name , url , 130 , thumb , thumb , id , trailer )
    if 74 - 74: OoOO0ooOOoo0O / i1IIi % OoooooooOO
  else :
   if 52 - 52: i1I111II1I % iI
   if III1iII1I1ii == 'true' :
    if 25 - 25: O0oO / O0oO % OoooooooOO - o00O0oo * oO0o0ooO0
    i1iiIIiII1 ( name , url , 1 , thumb , thumb , id , trailer )
    if 23 - 23: i11iIiiIii
   else :
    if 100 - 100: oO0o0ooO0 + O0 . OOooOOo + i1IIi - OoOO0ooOOoo0O + o0000oOoOoO0o
    i1iiIIiII1 ( name , url , 130 , thumb , thumb , id , trailer )
    if 65 - 65: II111iiii / ii11ii1ii
def Ii111iIi1iIi ( name , url , thumb , id , trailer , description , fanart ) :
 if 42 - 42: i11iIiiIii . O0
 if 75 - 75: Oooo0Ooo000 + iIii1I11I1II1
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . strip ( )
 O00OOOoOoo0O = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
 fanart = fanart . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 name = '[COLOR %s]' % O00OOOoOoo0O + name + '[/COLOR]'
 if 19 - 19: OOooOOo + i11iIiiIii . i1I111II1I - O0oO / o0oO0 + o0000oOoOoO0o
 if 38 - 38: ii11ii1ii / iIii1I11I1II1 * iIii1I11I1II1 % o00O0oo
 if 'tvg-logo' in thumb :
  thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  if III1iII1I1ii == 'true' :
   O00o ( name , url , 1 , thumb , fanart , id , trailer , description )
  else :
   if 55 - 55: iI % O0oO / i11iIiiIii
   O00o ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 20 - 20: i1I111II1I / Oooo0Ooo000 * i1I111II1I * OoOO
 else :
  if 72 - 72: OoOO . o0000oOoOoO0o * o00O0oo . iIii1I11I1II1 % o00O0oo . o0oO0
  if III1iII1I1ii == 'true' :
   if 70 - 70: IIII + iI * o0oO0 . o0oO0 + OoOO
   O00o ( name , url , 1 , thumb , fanart , id , trailer , description )
   if 28 - 28: i1IIi . IIII
  else :
   if 88 - 88: O0oO + OOooOOo - O0oO / OoooooooOO - i11iIiiIii
   O00o ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 24 - 24: iIii1I11I1II1
   if 89 - 89: o0oO0 / i1IIi - o0000oOoOoO0o % OOooOOo . ii11ii1ii - O0
def OOOoo00o0o ( name , trailer ) :
 if 98 - 98: o0oO0 * iIii1I11I1II1 % ii11ii1ii % IIII
 if O0ii1ii1ii == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Realstream, Reproduciendo Trailer de: [COLOR green]" + name + "[/COLOR] ,5000)" )
  if 88 - 88: O0ooOooooO - II111iiii / O0ooOooooO - o0oO0
  oOOO00o000o = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  iI1iii1iI1 = oOOO00o000o
  ooOoo = xbmcgui . ListItem ( name , trailer , path = iI1iii1iI1 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooOoo )
 else :
  oOOO00o000o = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  iI1iii1iI1 = oOOO00o000o
  ooOoo = xbmcgui . ListItem ( name , trailer , path = iI1iii1iI1 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooOoo )
  if 91 - 91: o0000oOoOoO0o . O0ooOooooO % ii11ii1ii - O0ooOooooO . oO0o0ooO0 % i11iIiiIii
  if 25 - 25: iIii1I11I1II1
def o0o0O0oOOOooo ( name , url ) :
 if 6 - 6: iIii1I11I1II1 - iIii1I11I1II1 % o0000oOoOoO0o / iIii1I11I1II1 * Oooo0Ooo000
 if O0ii1ii1ii == 'true' :
  if 3 - 3: IIII . i1I111II1I / ii11ii1ii
  try :
   if 89 - 89: OoooooooOO . iIii1I11I1II1 . ii11ii1ii * iIii1I11I1II1 - Oooo0Ooo000
   iiI1iIii1i = xbmcgui . DialogProgress ( )
   iiI1iIii1i . create ( 'Realstream:' , 'Iniciando ...' )
   iiI1iIii1i . update ( 30 , 'Realstream:' , 'Conectando al servidor ...' )
   xbmc . sleep ( 1000 )
   iiI1iIii1i . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   iiI1iIii1i . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   iiI1iIii1i . close ( )
   if 92 - 92: OoooooooOO - o00O0oo - OoooooooOO % OOooOOo % OOooOOo % iIii1I11I1II1
   iI1iii1iI1 = url
   ooOoo = xbmcgui . ListItem ( name , iIi11i1 , path = iI1iii1iI1 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooOoo )
   if 92 - 92: O0ooOooooO * O0 % Oooo0Ooo000 . iIii1I11I1II1
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. ,3000)" )
  if 66 - 66: O0oO + o0oO0
 else :
  if 48 - 48: o00O0oo
  try :
   if 96 - 96: iI . OoooooooOO
   iiI1iIii1i = xbmcgui . DialogProgress ( )
   iiI1iIii1i . create ( 'Realstream:' , 'Iniciando ...' )
   iiI1iIii1i . update ( 30 , 'Realstream:' , 'Conectando al servidor ...' )
   xbmc . sleep ( 1000 )
   iiI1iIii1i . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   iiI1iIii1i . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   iiI1iIii1i . close ( )
   if 39 - 39: IIII + OoOO
   iI1iii1iI1 = url
   ooOoo = xbmcgui . ListItem ( name , iIi11i1 , path = iI1iii1iI1 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooOoo )
   if 80 - 80: IIII % OoOO / OoOO0ooOOoo0O
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. ,3000)" )
  if 54 - 54: ii11ii1ii % OoOO - IIII - O0oO
 return
 if 71 - 71: iI . i11iIiiIii
 if 56 - 56: O0 * O0ooOooooO + O0ooOooooO * iIii1I11I1II1 / iI * Oooo0Ooo000
def IiOo0O0O ( trailer ) :
 if 8 - 8: i11iIiiIii * O0 + o00O0oo . iIii1I11I1II1 % O0oO / O0oO
 if 'https://www.youtube.com' in trailer :
  if 70 - 70: OOooOOo + o0oO0
  try :
   if 70 - 70: i1I111II1I . i11iIiiIii
   import resolveurl
   if 76 - 76: O0ooOooooO . i1I111II1I % O0ooOooooO - Oooo0Ooo000
   ooO = urlresolver . HostedMediaFile ( oOOO00o000o )
   iiI1iIii1i = xbmcgui . DialogProgress ( )
   iiI1iIii1i . create ( 'Realstream:' , 'Conectando al servidor ... ' )
   iiI1iIii1i . update ( 20 , 'Por favor, espere ...' )
   xbmc . sleep ( 500 )
   if 51 - 51: OoooooooOO + o0000oOoOoO0o * iIii1I11I1II1 * oO0o0ooO0 / i1IIi
   if not ooO :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    return False
    if 19 - 19: O0ooOooooO - OoOO0ooOOoo0O % oO0o0ooO0 / OoooooooOO % O0ooOooooO
   try :
    if 65 - 65: O0 . oO0o0ooO0
    iiI1iIii1i . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    o0o0OoOOOOOo = ooO . resolve ( )
    if not o0o0OoOOOOOo or not isinstance ( o0o0OoOOOOOo , basestring ) :
     try : Ii11iii1II1i = o0o0OoOOOOOo . msg
     except : Ii11iii1II1i = o0o0OoOOOOOo
     raise Exception ( Ii11iii1II1i )
   except Exception as iIii :
    try : Ii11iii1II1i = str ( iIii )
    except : Ii11iii1II1i = o0o0OoOOOOOo
    iiI1iIii1i . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
    iiI1iIii1i . close ( )
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    if 85 - 85: II111iiii
   iiI1iIii1i . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
   xbmc . sleep ( 500 )
   iiI1iIii1i . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   iiI1iIii1i . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
   xbmc . sleep ( 500 )
   iiI1iIii1i . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   iiI1iIii1i . close ( )
   if 55 - 55: o00O0oo
   oO0O0oO0 = xbmcgui . ListItem ( path = o0o0OoOOOOOo )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO0O0oO0 )
   if 76 - 76: oO0o0ooO0 - i11iIiiIii
  except :
   pass
   if 27 - 27: o00O0oo - i11iIiiIii % Oooo0Ooo000 / ii11ii1ii . ii11ii1ii / OoooooooOO
  else :
   if 76 - 76: O0oO * OoOO . iIii1I11I1II1 % OoooooooOO % o00O0oo
   oOOO00o000o = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
   iI1iii1iI1 = oOOO00o000o
   ooOoo = xbmcgui . ListItem ( trailer , path = iI1iii1iI1 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooOoo )
   return
   if 39 - 39: II111iiii * OoOO0ooOOoo0O . O0 * O0oO
def O0o0O0O0O ( name , url ) :
 if 79 - 79: i1I111II1I + i1I111II1I + o0oO0
 if '[Youtube]' in name :
  if 39 - 39: O0 - OoooooooOO
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  iI1iii1iI1 = url
  ooOoo = xbmcgui . ListItem ( iIi11i1 , path = iI1iii1iI1 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooOoo )
  if 63 - 63: iIii1I11I1II1 % o0000oOoOoO0o * iI
  if 79 - 79: O0
 else :
  if 32 - 32: II111iiii . O0 + o0oO0 / OoOO0ooOOoo0O / i1I111II1I / IIII
  import urlresolver
  from urlresolver import common
  if 15 - 15: o00O0oo
  ooO = urlresolver . HostedMediaFile ( url )
  if 4 - 4: i1I111II1I + iIii1I11I1II1 * O0ooOooooO + ii11ii1ii * o0000oOoOoO0o % II111iiii
  if not ooO :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 88 - 88: oO0o0ooO0 - i1IIi % i11iIiiIii % II111iiii * OoooooooOO
   if 40 - 40: ii11ii1ii
  try :
   o0o0OoOOOOOo = ooO . resolve ( )
   if not o0o0OoOOOOOo or not isinstance ( o0o0OoOOOOOo , basestring ) :
    try : Ii11iii1II1i = o0o0OoOOOOOo . msg
    except : Ii11iii1II1i = url
    raise Exception ( Ii11iii1II1i )
  except Exception as iIii :
   try : Ii11iii1II1i = str ( iIii )
   except : Ii11iii1II1i = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 47 - 47: OoOO0ooOOoo0O
  O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if O0ii1ii1ii == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  oO0O0oO0 = xbmcgui . ListItem ( path = o0o0OoOOOOOo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO0O0oO0 )
  if 65 - 65: O0 + Oooo0Ooo000 % o0oO0 * OOooOOo / iI / OoOO0ooOOoo0O
  if 71 - 71: i11iIiiIii / OoOO0ooOOoo0O . oO0o0ooO0
 return
 if 33 - 33: oO0o0ooO0
 if 39 - 39: OoOO + O0 + iI * II111iiii % O0 - O0
def i1I1i1i1I1 ( name , url ) :
 if 17 - 17: OoOO0ooOOoo0O + OoooooooOO % IIII
 if 'mybox.com' in url :
  if 36 - 36: i11iIiiIii + o00O0oo % IIII . OOooOOo - iI
  url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
  if 94 - 94: OOooOOo % OoOO0ooOOoo0O . i1I111II1I . iI . OoOO
  try :
   if 53 - 53: OoOO0ooOOoo0O
   I1I1i = I1i11i ( url )
   IiIi = re . compile ( O0oO0 ) . findall ( I1I1i )
   for url , o0oo0OO , i11Ii1 in IiIi :
    if 2 - 2: i1I111II1I - oO0o0ooO0 % OoOO + o0000oOoOoO0o + o0oO0 - iIii1I11I1II1
    o0oo0OO = o0oo0OO . replace ( '","res":"1080",' , '' ) . replace ( '","res":"720",' , '' ) . replace ( '","res":"480",' , '' ) . replace ( '","res":"360",' , '' )
    url = url . replace ( '\/' , '/' )
    url = url . replace ( ',"type":"video/mp4",' , ' ' )
    name = '[COLOR white]' + o0oo0OO + '[/COLOR] - [COLOR gold]' + i11Ii1 + '[/COLOR]'
    if 18 - 18: o00O0oo / ii11ii1ii - O0ooOooooO
    oO000 = [ ]
    oO000 . append ( '[COLOR orange]Real Stream: [/COLOR][COLOR gold]1. Mostrar mas info. [Reiniciar][/COLOR]' )
    oO000 . append ( '[COLOR gold]2. Mostar otras calidades disponibles [/COLOR]' )
    oO000 . append ( '[COLOR gold]3. Ver en: %s [/COLOR]' % name )
    if 81 - 81: oO0o0ooO0
    if 62 - 62: o0oO0 + O0 * OoOO
    oOoOO = 'Seleccione una calidad e idioma:'
    i11I1iIii1i11 = xbmcgui . Dialog ( )
    iIiiI11II11i = i11I1iIii1i11 . select ( oOoOO , oO000 )
    if 98 - 98: O0ooOooooO - O0ooOooooO
    if 58 - 58: oO0o0ooO0
    if 98 - 98: o0000oOoOoO0o * OoOO
    if iIiiI11II11i == 0 :
     if 10 - 10: oO0o0ooO0 - O0ooOooooO % II111iiii - Oooo0Ooo000 - i1IIi
     I1iIiI1IiIIII = i11I1iIii1i11 . ok ( "[COLOR darkpink]REALSTREAM:[/COLOR] " , "[COLOR gold]  Reiniciadas las opciones.  [/COLOR]" , "" )
     del i11I1iIii1i11
     return
     if 10 - 10: o00O0oo - O0oO . Oooo0Ooo000
    elif iIiiI11II11i == 1 :
     if 8 - 8: iIii1I11I1II1 % oO0o0ooO0 + ii11ii1ii
     pass
     if 24 - 24: o0000oOoOoO0o / o0oO0 / o0oO0 % II111iiii - oO0o0ooO0 * oO0o0ooO0
     del i11I1iIii1i11
     if 58 - 58: OoOO0ooOOoo0O
     if 60 - 60: II111iiii
    elif iIiiI11II11i == 2 :
     if 90 - 90: OoOO0ooOOoo0O
     o0o0O0oOOOooo ( name , url )
     if 37 - 37: OoOO0ooOOoo0O + O0 . O0 * ii11ii1ii % Oooo0Ooo000 / O0ooOooooO
     return
     if 18 - 18: OoooooooOO
  except :
   pass
   if 57 - 57: iI . OoOO0ooOOoo0O * o0000oOoOoO0o - OoooooooOO
 elif 'uptostream.com' in url :
  if 75 - 75: i11iIiiIii / o0000oOoOoO0o . i1I111II1I . i1IIi . i1IIi / O0oO
  try :
   if 94 - 94: iI + OOooOOo
   I1I1i = I1i11i ( url )
   IiIi = re . compile ( O0oO0 ) . findall ( I1I1i )
   for url , o0oo0OO , i11Ii1 in IiIi :
    if 56 - 56: OoOO0ooOOoo0O % o0000oOoOoO0o
    o0oo0OO = o0oo0OO . replace ( '","res":"1080",' , '' ) . replace ( '","res":"720",' , '' ) . replace ( '","res":"480",' , '' ) . replace ( '","res":"360",' , '' )
    url = url . replace ( '\/' , '/' )
    url = url . replace ( ',"type":"video/mp4",' , ' ' )
    name = '[COLOR white]Calidad: ' + o0oo0OO + '[/COLOR] [COLOR gold]Idioma: ' + i11Ii1 + '[/COLOR]'
    if 40 - 40: IIII / i1I111II1I
    oO000 = [ ]
    oO000 . append ( '[COLOR white]Reiniciar calidades disponibles[/COLOR]' )
    oO000 . append ( '[COLOR white]Otras calidades e idiomas[/COLOR]' )
    oO000 . append ( '[COLOR white]Ver en: %s ' % name )
    if 29 - 29: o0oO0 - o0oO0 / iI
    if 49 - 49: O0oO + oO0o0ooO0 % OoOO - ii11ii1ii - O0 - OoooooooOO
    oOoOO = 'Seleccione una calidad e idioma:'
    i11I1iIii1i11 = xbmcgui . Dialog ( )
    iIiiI11II11i = i11I1iIii1i11 . select ( oOoOO , oO000 )
    if 4 - 4: II111iiii - oO0o0ooO0 % ii11ii1ii * i11iIiiIii
    if 18 - 18: ii11ii1ii % O0
    if iIiiI11II11i == 0 :
     if 66 - 66: iIii1I11I1II1 % i11iIiiIii / OOooOOo
     I1iIiI1IiIIII = i11I1iIii1i11 . ok ( "[COLOR darkpink]REALSTREAM:[/COLOR] " , "[COLOR gold]  Reiniciadas las opciones.  [/COLOR]" , "" )
     del i11I1iIii1i11
     return
     if 47 - 47: o00O0oo * oO0o0ooO0 + iIii1I11I1II1 - oO0o0ooO0 / i1I111II1I
    elif iIiiI11II11i == 1 :
     if 86 - 86: i1I111II1I
     pass
     if 43 - 43: OOooOOo / O0ooOooooO / iI + iIii1I11I1II1 + OoooooooOO
     del i11I1iIii1i11
     if 33 - 33: II111iiii - i1I111II1I - iI
     if 92 - 92: OoOO * i1I111II1I
     if 92 - 92: oO0o0ooO0
     if 7 - 7: O0ooOooooO
    elif iIiiI11II11i == 2 :
     if 73 - 73: OoOO % o00O0oo
     o0o0O0oOOOooo ( name , url )
     if 32 - 32: IIII + O0ooOooooO + iIii1I11I1II1 * ii11ii1ii
     return
     if 62 - 62: i11iIiiIii
  except :
   pass
 else :
  if 2 - 2: OOooOOo
  IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
  OOoO0 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  OO0Oooo0oOO0O = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  Ii1I1 = IiII1IiiIiI1 . getSetting ( 'key_ext' )
  I1I1i = I1i11i ( OO0Oooo0oOO0O )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
  for o000ooOOo in IiIi :
   if 69 - 69: OoooooooOO / ii11ii1ii * Oooo0Ooo000
   try :
    if 99 - 99: II111iiii * iIii1I11I1II1 % O0 * oO0o0ooO0 / II111iiii % OoooooooOO
    if 14 - 14: i1I111II1I . i1I111II1I % iI
    IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
    if 42 - 42: o0000oOoOoO0o . IIII - iI
    if 33 - 33: II111iiii / O0 / i1I111II1I - O0oO - i1IIi
    if IIIi1I1IIii1II == o000ooOOo :
     if 8 - 8: i11iIiiIii . O0ooOooooO / iIii1I11I1II1 / o00O0oo / i1I111II1I - o0oO0
     if 32 - 32: o0000oOoOoO0o . i1IIi * ii11ii1ii
     if 'https://team.com' in url :
      if 98 - 98: o0oO0 - II111iiii / OOooOOo . oO0o0ooO0 * i1I111II1I . O0oO
      url = url . replace ( 'https://team.com' , 'https://verystream.com' )
      if 25 - 25: i11iIiiIii / OoOO0ooOOoo0O - Oooo0Ooo000 / OoOO . o0000oOoOoO0o . o0000oOoOoO0o
     if 'https://mybox.com' in url :
      if 6 - 6: oO0o0ooO0 . O0oO
      url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
      if 43 - 43: o00O0oo + o0000oOoOoO0o
      if 50 - 50: oO0o0ooO0 % i1IIi * O0
     if 'https://vidcloud.co/' in url :
      if 4 - 4: iIii1I11I1II1 . i1IIi
      url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
      if 63 - 63: iIii1I11I1II1 + i1I111II1I % i1IIi / OOooOOo % II111iiii
     if 'https://gounlimited.to' in url :
      if 60 - 60: o0000oOoOoO0o . OoOO0ooOOoo0O % Oooo0Ooo000 / OOooOOo / O0
      url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
      if 19 - 19: i11iIiiIii . OOooOOo + II111iiii / IIII . o00O0oo * iI
     if 'https://drive.com' in url :
      if 59 - 59: iIii1I11I1II1 / o00O0oo % iI
      url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
      if 84 - 84: iIii1I11I1II1 / OOooOOo . OoOO0ooOOoo0O % O0oO
      if 99 - 99: ii11ii1ii + i11iIiiIii
     import resolveurl
     if 36 - 36: o0oO0 * Oooo0Ooo000 * iIii1I11I1II1 - O0oO % i11iIiiIii
     ooO = urlresolver . HostedMediaFile ( url )
     if 98 - 98: iIii1I11I1II1 - i1IIi + iI % O0oO + iI / oO0o0ooO0
     if not ooO :
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
      return False
      if 97 - 97: i1I111II1I % iI + II111iiii - i1I111II1I % OoOO + iI
     try :
      if 31 - 31: o0000oOoOoO0o
      iiI1iIii1i = xbmcgui . DialogProgress ( )
      iiI1iIii1i . create ( 'Realstream:' , 'Iniciando ...' )
      iiI1iIii1i . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
      xbmc . sleep ( 1000 )
      if 35 - 35: OoOO0ooOOoo0O + o0oO0 * iI / OoOO0ooOOoo0O
      o0o0OoOOOOOo = ooO . resolve ( )
      if not o0o0OoOOOOOo or not isinstance ( o0o0OoOOOOOo , basestring ) :
       if 69 - 69: iI . IIII - OOooOOo
       try : Ii11iii1II1i = o0o0OoOOOOOo . msg
       except : Ii11iii1II1i = url
       raise Exception ( Ii11iii1II1i )
       if 29 - 29: i11iIiiIii . o00O0oo / OOooOOo . IIII + i11iIiiIii
     except Exception as iIii :
      try : Ii11iii1II1i = str ( iIii )
      except : Ii11iii1II1i = url
      if 26 - 26: i1I111II1I / o0oO0 - OoooooooOO
      if 9 - 9: OoooooooOO * o00O0oo
      if 9 - 9: ii11ii1ii + O0ooOooooO
      for oooooO0oO0ooO in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       iIII1IiI = 1
       iiI1iIii1i . update ( 45 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % oooooO0oO0ooO )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5  Puede cancelar cuando desee o esperar...,  1000)" % iIII1IiI )
       iiI1iIii1i . close ( )
       if 32 - 32: OoOO0ooOOoo0O % OoOO + i11iIiiIii + iI - o0oO0 + oO0o0ooO0
      for oooooO0oO0ooO in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       iIII1IiI = 2
       iiI1iIii1i . update ( 48 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % oooooO0oO0ooO )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % iIII1IiI )
       iiI1iIii1i . close ( )
      for oooooO0oO0ooO in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       iIII1IiI = 3
       iiI1iIii1i . update ( 50 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % oooooO0oO0ooO )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % iIII1IiI )
       iiI1iIii1i . close ( )
      for oooooO0oO0ooO in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       iIII1IiI = 4
       iiI1iIii1i . update ( 53 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % oooooO0oO0ooO )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % iIII1IiI )
       iiI1iIii1i . close ( )
      for oooooO0oO0ooO in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       iIII1IiI = 5
       iiI1iIii1i . update ( 55 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % oooooO0oO0ooO )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % iIII1IiI )
       iiI1iIii1i . close ( )
       if 31 - 31: iIii1I11I1II1 - o0000oOoOoO0o
      if iiI1iIii1i . iscanceled ( ) :
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Cancelando !! , 2000)" )
       iiI1iIii1i . close ( )
       break
       if 57 - 57: ii11ii1ii % OoOO
       if 1 - 1: OoOO0ooOOoo0O * O0 . oO0o0ooO0 % O0 + II111iiii
       if 49 - 49: O0oO . IIII
     iiI1iIii1i . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
     xbmc . sleep ( 500 )
     iiI1iIii1i . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
     xbmc . sleep ( 1000 )
     iiI1iIii1i . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
     iiI1iIii1i . close ( )
     O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
     oO0O0oO0 = xbmcgui . ListItem ( path = o0o0OoOOOOOo )
     xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oO0O0oO0 )
     if 74 - 74: i1IIi
     if 15 - 15: i1IIi + i1I111II1I % OOooOOo / i11iIiiIii * OoOO0ooOOoo0O
    else :
     if 69 - 69: i11iIiiIii
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold] El addon no ha podido conectar al servidor.[/COLOR]" )
     return False
     if 61 - 61: O0
   except :
    pass
    if 21 - 21: OoOO % iIii1I11I1II1 . OoOO
 return
 if 99 - 99: o0000oOoOoO0o * IIII % oO0o0ooO0 * oO0o0ooO0 + OoooooooOO
 if 82 - 82: O0oO / OoOO0ooOOoo0O - IIII / iI
def I1iIIi ( ) :
 if 46 - 46: OOooOOo . i1I111II1I - i11iIiiIii - Oooo0Ooo000
 oo0O0OO0Oo = [ ]
 oO00o0oO0O = sys . argv [ 2 ]
 if len ( oO00o0oO0O ) >= 2 :
  iI11Iii1I = sys . argv [ 2 ]
  o0i1I = iI11Iii1I . replace ( '?' , '' )
  if ( iI11Iii1I [ len ( iI11Iii1I ) - 1 ] == '/' ) :
   iI11Iii1I = iI11Iii1I [ 0 : len ( iI11Iii1I ) - 2 ]
  O0o0o00OoOo = o0i1I . split ( '&' )
  oo0O0OO0Oo = { }
  for oooooO0oO0ooO in range ( len ( O0o0o00OoOo ) ) :
   oO00o0O0Ooo = { }
   oO00o0O0Ooo = O0o0o00OoOo [ oooooO0oO0ooO ] . split ( '=' )
   if ( len ( oO00o0O0Ooo ) ) == 2 :
    oo0O0OO0Oo [ oO00o0O0Ooo [ 0 ] ] = oO00o0O0Ooo [ 1 ]
 return oo0O0OO0Oo
 if 44 - 44: OoooooooOO / O0ooOooooO
 if 81 - 81: oO0o0ooO0 - IIII
def IIIIii11II1I ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  import urlresolver
  xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
  if 48 - 48: o00O0oo - O0 . OoOO
def i1iIii ( ) :
 i11I1iIii1i11 = xbmcgui . Dialog ( )
 list = (
 O0o00 ,
 I1IIi1iI1iiI
 )
 if 27 - 27: iIii1I11I1II1 % O0oO - Oooo0Ooo000
 Oo00 = i11I1iIii1i11 . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=%s]Accede a themoviedb.com[/COLOR]' % iIIIi1 ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 71 - 71: iI . o00O0oo * O0 - Oooo0Ooo000 - II111iiii
 if Oo00 :
  if 5 - 5: o0000oOoOoO0o
  if Oo00 < 0 :
   return
  o00oo = list [ Oo00 - 2 ]
  return o00oo ( )
 else :
  o00oo = list [ Oo00 ]
  return o00oo ( )
 return
 if 78 - 78: i1I111II1I - O0oO % O0 - IIII % OoOO
def i11IiIi ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 24 - 24: O0oO / o0oO0 * iI - i11iIiiIii
OoiIiiII = i11IiIi ( )
if 13 - 13: II111iiii
def O0o00 ( ) :
 if OoiIiiII == 'android' :
  iiii1 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  iiii1 = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 55 - 55: ii11ii1ii % i1IIi * O0oO
  if 95 - 95: IIII / II111iiii - o0000oOoOoO0o % Oooo0Ooo000 . O0oO
def I1IIi1iI1iiI ( ) :
 if 63 - 63: iIii1I11I1II1 / iI
 main ( )
 if 24 - 24: ii11ii1ii / iIii1I11I1II1 % IIII * OoOO0ooOOoo0O - iIii1I11I1II1
 if 50 - 50: II111iiii
 if 39 - 39: II111iiii . OoOO0ooOOoo0O - ii11ii1ii * i1IIi . OoooooooOO
def iIIiI ( ) :
 i11I1iIii1i11 = xbmcgui . Dialog ( )
 O0O0O0OO00oo = (
 I11IIIIiI1 ,
 o0oOOO
 )
 if 62 - 62: o0oO0 - oO0o0ooO0 % iIii1I11I1II1
 Oo00 = i11I1iIii1i11 . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 57 - 57: OoooooooOO / OoOO0ooOOoo0O
 if Oo00 :
  if 44 - 44: OoOO0ooOOoo0O * i1IIi * O0
  if Oo00 < 0 :
   return
  o00oo = O0O0O0OO00oo [ Oo00 - 2 ]
  return o00oo ( )
 else :
  o00oo = O0O0O0OO00oo [ Oo00 ]
  return o00oo ( )
 return
 if 94 - 94: OOooOOo - O0
def i11IiIi ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 18 - 18: i1I111II1I / oO0o0ooO0 . oO0o0ooO0 . iIii1I11I1II1 . i11iIiiIii
OoiIiiII = i11IiIi ( )
if 69 - 69: i11iIiiIii - O0 % II111iiii % IIII / ii11ii1ii * O0oO
def I11IIIIiI1 ( ) :
 if OoiIiiII == 'android' :
  iiii1 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  iiii1 = webbrowser . open ( 'https://olpair.com/' )
  if 61 - 61: OoOO . i1IIi - OOooOOo
  if 38 - 38: oO0o0ooO0 + iIii1I11I1II1 * o0oO0 / OoOO + IIII
def o0oOOO ( ) :
 if 48 - 48: OoooooooOO - Oooo0Ooo000 . i11iIiiIii * O0ooOooooO - o0oO0 - o0000oOoOoO0o
 main ( )
 if 59 - 59: O0ooOooooO / O0oO . ii11ii1ii
 if 100 - 100: O0
def oOOO00Oo ( name , url , id , trailer ) :
 i11I1iIii1i11 = xbmcgui . Dialog ( )
 O0O0O0OO00oo = (
 Ii1iii1 ,
 iii11III1I ,
 oO0oO0O ,
 i1iIii ,
 ooooO
 )
 if 99 - 99: o0oO0 - i1I111II1I * iIii1I11I1II1 . II111iiii
 Oo00 = i11I1iIii1i11 . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % iIIIi1 ,

 '[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % iIIIi1 ,

 '[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % iIIIi1 ,

 '[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % iIIIi1 ,

 '[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % iIIIi1 ] )
 if 56 - 56: iIii1I11I1II1 % OoOO . iI % i1I111II1I . Oooo0Ooo000 * ii11ii1ii
 if Oo00 :
  if 41 - 41: iIii1I11I1II1 % i1I111II1I * oO0o0ooO0 - iI
  if Oo00 < 0 :
   return
  o00oo = O0O0O0OO00oo [ Oo00 - 5 ]
  return o00oo ( )
 else :
  o00oo = O0O0O0OO00oo [ Oo00 ]
  return o00oo ( )
 return
 if 5 - 5: OoOO + OoOO + II111iiii * iIii1I11I1II1 + OoooooooOO
 if 77 - 77: O0 * o00O0oo * oO0o0ooO0 + OoOO + o00O0oo - Oooo0Ooo000
 if 10 - 10: o00O0oo + i1I111II1I
def Ii1iii1 ( ) :
 if 58 - 58: OOooOOo + OoooooooOO / O0ooOooooO . iI % o0000oOoOoO0o / o00O0oo
 i1I1i1i1I1 ( iIIII1iIIii , oOOO00o000o )
 if 62 - 62: II111iiii
def iii11III1I ( ) :
 if 12 - 12: i1I111II1I + II111iiii
 OOOoo00o0o ( iIIII1iIIii , iIi11i1 )
 if 92 - 92: Oooo0Ooo000 % iIii1I11I1II1 - O0ooOooooO / i11iIiiIii % iI * o0000oOoOoO0o
def oO0oO0O ( ) :
 if 80 - 80: O0ooOooooO
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  iI1I1ii11IIi1 = id
  if 100 - 100: ii11ii1ii . o0oO0 . OOooOOo % II111iiii - oO0o0ooO0
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % iI1I1ii11IIi1 )
  if 52 - 52: OOooOOo % OoOO * o0oO0 * O0ooOooooO / IIII
 if O0ii1ii1ii == 'true' :
  if 88 - 88: oO0o0ooO0
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + iIIII1iIIii + "[/COLOR] ,5000)" )
  if 1 - 1: ii11ii1ii
def Oo00o ( ) :
 if 20 - 20: i1I111II1I * i11iIiiIii % o00O0oo . OoooooooOO / II111iiii + ii11ii1ii
 i1iIii ( )
 if 59 - 59: IIII + OOooOOo / II111iiii / OoOO0ooOOoo0O
def ooooO ( ) :
 if 80 - 80: OoOO0ooOOoo0O + iIii1I11I1II1 . i1I111II1I
 IIIiIi ( )
def OoOoOo00o0 ( name , url , mode , iconimage , fanart ) :
 if 76 - 76: OOooOOo * IIII
 iiIIii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 I1iIiI1IiIIII = True
 oO0Oo0O0 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 oO0Oo0O0 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 oO0Oo0O0 . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  iiIIii = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  I1iIiI1IiIIII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiIIii , listitem = oO0Oo0O0 , isFolder = True )
  return I1iIiI1IiIIII
 I1iIiI1IiIIII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiIIii , listitem = oO0Oo0O0 , isFolder = True )
 return I1iIiI1IiIIII
 if 12 - 12: iIii1I11I1II1 / O0oO % o0oO0
def iiii11ii ( name , url , mode , iconimage , fanart , description ) :
 if 49 - 49: OoOO + II111iiii / i1I111II1I - O0 % o0oO0
 iiIIii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 I1iIiI1IiIIII = True
 oO0Oo0O0 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 oO0Oo0O0 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 oO0Oo0O0 . setProperty ( 'fanart_image' , fanart )
 I1iIiI1IiIIII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiIIii , listitem = oO0Oo0O0 , isFolder = True )
 return I1iIiI1IiIIII
 if 27 - 27: OoOO + ii11ii1ii
def oO0oOOooO0 ( name , url , mode , iconimage ) :
 if 62 - 62: i11iIiiIii - O0oO
 iiIIii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 I1iIiI1IiIIII = True
 oO0Oo0O0 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 oO0Oo0O0 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 oO0Oo0O0 . setProperty ( 'fanart_image' , oo00 )
 I1iIiI1IiIIII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiIIii , listitem = oO0Oo0O0 , isFolder = True )
 return I1iIiI1IiIIII
 if 81 - 81: O0oO
 if 92 - 92: IIII - ii11ii1ii - OoooooooOO / i1I111II1I - i1IIi
def i1iiIIiII1 ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 81 - 81: i1IIi / Oooo0Ooo000 % i11iIiiIii . iIii1I11I1II1 * OoOO0ooOOoo0O + OoooooooOO
 ooOOoooooo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 31 - 31: i1IIi % II111iiii
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 Ii1iii11I = [ ]
 if 2 - 2: OoooooooOO - o0oO0 % oO0o0ooO0 / OOooOOo / o0000oOoOoO0o
 Ii1iii11I . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 iiIIii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 oO0Oo0O0 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 oO0Oo0O0 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 oO0Oo0O0 . setProperty ( 'fanart_image' , fanart )
 oO0Oo0O0 . setProperty ( 'IsPlayable' , 'true' )
 if 3 - 3: II111iiii / IIII
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  Ii1iii11I . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 48 - 48: iI . o00O0oo
  oO0Oo0O0 . addContextMenuItems ( Ii1iii11I , replaceItems = True )
 I1iIiI1IiIIII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiIIii , listitem = oO0Oo0O0 )
 return I1iIiI1IiIIII
 if 49 - 49: i1IIi - OoOO0ooOOoo0O . ii11ii1ii + iIii1I11I1II1 - iI / ii11ii1ii
 if 24 - 24: oO0o0ooO0 - O0ooOooooO / iI
def O00o ( name , url , mode , iconimage , fanart , id , trailer , description ) :
 if 10 - 10: OoOO0ooOOoo0O * i1IIi
 ooOOoooooo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 15 - 15: O0oO + i1IIi - II111iiii % OOooOOo
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 Ii1iii11I = [ ]
 if 34 - 34: OOooOOo
 Ii1iii11I . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 iiIIii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 oO0Oo0O0 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 oO0Oo0O0 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 oO0Oo0O0 . setProperty ( 'fanart_image' , fanart )
 oO0Oo0O0 . setProperty ( 'IsPlayable' , 'true' )
 if 57 - 57: IIII . o0oO0 % o0000oOoOoO0o
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  Ii1iii11I . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 32 - 32: O0oO / i1I111II1I - O0 * iIii1I11I1II1
  oO0Oo0O0 . addContextMenuItems ( Ii1iii11I , replaceItems = True )
 I1iIiI1IiIIII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiIIii , listitem = oO0Oo0O0 )
 return I1iIiI1IiIIII
 if 70 - 70: OoooooooOO % OoooooooOO % OoOO
def iII11II1II ( name , url , mode , iconimage , fanart ) :
 if 98 - 98: OoOO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 18 - 18: O0oO + ii11ii1ii - OoOO / Oooo0Ooo000 / IIII
 iiIIii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 oO0Oo0O0 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 oO0Oo0O0 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 oO0Oo0O0 . setProperty ( 'fanart_image' , fanart )
 oO0Oo0O0 . setProperty ( 'IsPlayable' , 'true' )
 I1iIiI1IiIIII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiIIii , listitem = oO0Oo0O0 )
 return I1iIiI1IiIIII
 if 53 - 53: IIII + o0000oOoOoO0o . oO0o0ooO0 / O0oO
def o0000oO ( name , url , mode , iconimage ) :
 if 83 - 83: OoOO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 16 - 16: iI
 iiIIii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 oO0Oo0O0 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 oO0Oo0O0 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 oO0Oo0O0 . setProperty ( 'fanart_image' , oo00 )
 oO0Oo0O0 . setProperty ( 'IsPlayable' , 'true' )
 I1iIiI1IiIIII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiIIii , listitem = oO0Oo0O0 )
 return I1iIiI1IiIIII
 if 32 - 32: o0000oOoOoO0o % OOooOOo
def iII ( name , url , mode , iconimage ) :
 iiIIii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 I1iIiI1IiIIII = True
 oO0Oo0O0 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 I1iIiI1IiIIII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiIIii , listitem = oO0Oo0O0 , isFolder = True )
 return I1iIiI1IiIIII
 if 23 - 23: II111iiii * i1I111II1I % OOooOOo - oO0o0ooO0
def iIii1iii ( ) :
 if 80 - 80: OOooOOo % o00O0oo % O0ooOooooO / i1I111II1I
 if 67 - 67: o0oO0 / O0 * O0ooOooooO
 if 15 - 15: i1I111II1I
 ii1iIi1iIiI1i = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 ii1iIi1iIiI1i . doModal ( )
 if ( ii1iIi1iIiI1i . isConfirmed ( ) ) :
  if 33 - 33: o0000oOoOoO0o . IIII + o0000oOoOoO0o / o00O0oo . ii11ii1ii + OoOO0ooOOoo0O
  O00OoOO0oo0 = urllib . quote_plus ( ii1iIi1iIiI1i . getText ( ) ) . replace ( '+' , ' ' )
  if 32 - 32: i1I111II1I - iI * O0ooOooooO * O0oO
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 84 - 84: o0oO0 + o00O0oo % OOooOOo + i11iIiiIii
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % O00OoOO0oo0 )
    if 37 - 37: O0oO % o00O0oo / iI
    if O0ii1ii1ii == 'true' :
     if 94 - 94: O0oO / OoOO . o0000oOoOoO0o
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + iIIII1iIIii + "[/COLOR] ,10000)" )
     if 1 - 1: ii11ii1ii . II111iiii
   except :
    if 93 - 93: II111iiii . i11iIiiIii + II111iiii % oO0o0ooO0
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 98 - 98: Oooo0Ooo000 * oO0o0ooO0 * OoOO0ooOOoo0O + o0oO0 * O0ooOooooO
    if 4 - 4: i1I111II1I
iI11Iii1I = I1iIIi ( )
oOOO00o000o = None
iIIII1iIIii = None
IiI1iIiiI1iI = None
o0Oii1111i = None
id = None
iIi11i1 = None
if 2 - 2: OOooOOo * Oooo0Ooo000 % Oooo0Ooo000 - Oooo0Ooo000 - O0ooOooooO + IIII
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 7 - 7: O0oO - OoOO . OoooooooOO / OoooooooOO - O0oO
try :
 oOOO00o000o = urllib . unquote_plus ( iI11Iii1I [ "url" ] )
except :
 pass
try :
 iIIII1iIIii = urllib . unquote_plus ( iI11Iii1I [ "name" ] )
except :
 pass
try :
 IiI1iIiiI1iI = int ( iI11Iii1I [ "mode" ] )
except :
 pass
try :
 o0Oii1111i = urllib . unquote_plus ( iI11Iii1I [ "iconimage" ] )
except :
 pass
try :
 id = int ( iI11Iii1I [ "id" ] )
except :
 pass
try :
 iIi11i1 = urllib . unquote_plus ( iI11Iii1I [ "trailer" ] )
except :
 pass
 if 84 - 84: II111iiii
 if 36 - 36: IIII - OoOO0ooOOoo0O - iIii1I11I1II1
print "Mode: " + str ( IiI1iIiiI1iI )
print "URL: " + str ( oOOO00o000o )
print "Name: " + str ( iIIII1iIIii )
print "iconimage: " + str ( o0Oii1111i )
print "id: " + str ( id )
print "trailer: " + str ( iIi11i1 )
if 10 - 10: o00O0oo / o0oO0 * i1IIi % O0 + O0oO
if 25 - 25: Oooo0Ooo000 - o0oO0 / O0 . OoooooooOO % OOooOOo . i1IIi
def oO0 ( ) :
 if 19 - 19: II111iiii / II111iiii % o00O0oo + oO0o0ooO0 + oO0o0ooO0 + O0ooOooooO
 try :
  if 4 - 4: o0000oOoOoO0o + O0oO / O0ooOooooO + i1IIi % o0000oOoOoO0o % O0ooOooooO
  ooOooOooOOO = I1i11i ( oO0 )
  IiIi = re . compile ( O0O0OOOOoo ) . findall ( ooOooOooOOO )
  for IiIIi1I1I11Ii in IiIi :
   if 59 - 59: O0oO
   if IiIIi1I1I11Ii == 'si' :
    if 63 - 63: OoOO . oO0o0ooO0 + Oooo0Ooo000 . OoOO0ooOOoo0O / i11iIiiIii / O0ooOooooO
    import urlresolver
    from urlresolver import common
    import random
    from random import choice
    II1iII1 = xbmc . Player ( )
    Oo0O0O0ooO0O = [ 'gtG1Y3_34ug' , '3d_ACcf0rDc' , 'AKpPeLAMY9I' , 'sVBa5hNZFHM' , '5ZCVhFmbAY0' ]
    I11II11IiI11 = random . choice ( Oo0O0O0ooO0O )
    oOOO00o000o = 'https://www.youtube.com/watch?v=%s' % I11II11IiI11
    oOOO00o000o = urlresolver . HostedMediaFile ( oOOO00o000o ) . resolve ( )
    II1iII1 . play ( oOOO00o000o )
    if 97 - 97: iI / iIii1I11I1II1 % iI / OOooOOo * O0ooOooooO % OoOO0ooOOoo0O
    i1iiii1 == 'false'
    if 85 - 85: OOooOOo + IIII + IIII
   else :
    if 92 - 92: O0oO % O0 % o0oO0 . o0oO0 . i1I111II1I
    i1iiii1 == 'false'
    if 82 - 82: ii11ii1ii + OoOO0ooOOoo0O . o00O0oo % oO0o0ooO0 / o0oO0
    return False
    if 37 - 37: oO0o0ooO0 % Oooo0Ooo000 % oO0o0ooO0
 except :
  pass
  if 14 - 14: OoOO / OOooOOo
  if 66 - 66: ii11ii1ii / i11iIiiIii % iI
  if 43 - 43: IIII
if IiI1iIiiI1iI == None or oOOO00o000o == None or len ( oOOO00o000o ) < 1 :
 if 84 - 84: IIII . i1I111II1I . O0ooOooooO
 if 2 - 2: ii11ii1ii - OoOO0ooOOoo0O
 IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 OOoO0 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 OO0Oooo0oOO0O = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 Ii1I1 = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 I1I1i = I1i11i ( OO0Oooo0oOO0O )
 IiIi = re . compile ( O0O0OOOOoo ) . findall ( I1I1i )
 for o000ooOOo in IiIi :
  if 49 - 49: o0oO0 + II111iiii / oO0o0ooO0 - OoOO0ooOOoo0O % OoOO0ooOOoo0O + OOooOOo
  try :
   if 54 - 54: iI % ii11ii1ii - IIII
   if 16 - 16: o00O0oo * O0ooOooooO / O0oO
   IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 46 - 46: II111iiii
   if 13 - 13: i1I111II1I + II111iiii % OOooOOo
   if IIIi1I1IIii1II == o000ooOOo :
    if 30 - 30: OoooooooOO - i11iIiiIii + oO0o0ooO0 / ii11ii1ii - i11iIiiIii
    IIIiIi ( )
    OoOIiiiii111i1ii ( )
    if 74 - 74: O0 . O0oO
    i1iiii1 = IiII1IiiIiI1 . getSetting ( 'videos_event' )
    if i1iiii1 == 'true' :
     xbmc . sleep ( 3000 )
     oO0 ( )
     if 64 - 64: iI / i1IIi % O0ooOooooO
   else :
    if 84 - 84: OoOO0ooOOoo0O - ii11ii1ii . iI . i1I111II1I - ii11ii1ii
    iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
    OoOoOo00o0 ( '[COLOR %s]Video tutoriales[/COLOR]' % iIIIi1 , IIIII11I1IiI , 125 , O0OOO0OOoO0O , oo00 )
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Por favor compruebe los ajustes de realstream.[/COLOR]" , "[COLOR white] Desde la seccion Tutoriales puede sacarle mayor partido a su Realstream, tambien puede configurarlo a su gusto. [/COLOR]" , "[COLOR gold]El addon no esta activado o bien configurado.[/COLOR]" )
    if 99 - 99: Oooo0Ooo000
  except :
   pass
   if 75 - 75: iI . IIII / i1I111II1I
elif IiI1iIiiI1iI == 1 :
 oOOO00Oo ( iIIII1iIIii , oOOO00o000o , id , iIi11i1 )
elif IiI1iIiiI1iI == 2 :
 O0Oo0 ( )
elif IiI1iIiiI1iI == 3 :
 Oo00ooO0OoOo ( )
elif IiI1iIiiI1iI == 4 :
 O0o0O0O0O ( iIIII1iIIii , oOOO00o000o )
elif IiI1iIiiI1iI == 5 :
 i1iIiIii ( )
elif IiI1iIiiI1iI == 6 :
 oOOoo ( )
elif IiI1iIiiI1iI == 7 :
 O0OOOOOO0 ( )
elif IiI1iIiiI1iI == 8 :
 ooOoo0OoOO ( )
elif IiI1iIiiI1iI == 9 :
 i1IoOOoooO0O0 ( )
elif IiI1iIiiI1iI == 10 :
 Ooooo ( )
elif IiI1iIiiI1iI == 11 :
 Iiii1I ( )
elif IiI1iIiiI1iI == 12 :
 iIII11Iiii1 ( )
elif IiI1iIiiI1iI == 13 :
 o0iIIIIi ( )
elif IiI1iIiiI1iI == 14 :
 O00OoOoO ( )
elif IiI1iIiiI1iI == 15 :
 o0OOOOOo0 ( )
elif IiI1iIiiI1iI == 16 :
 oOOOOO0Ooooo ( )
elif IiI1iIiiI1iI == 17 :
 oOoO0Oo0 ( )
elif IiI1iIiiI1iI == 18 :
 Ii11 ( )
elif IiI1iIiiI1iI == 19 :
 ii11i ( )
elif IiI1iIiiI1iI == 20 :
 IioOooOOo00ooO ( )
elif IiI1iIiiI1iI == 21 :
 oo00ooooOOo00 ( )
elif IiI1iIiiI1iI == 22 :
 OooO0O0Ooo ( )
elif IiI1iIiiI1iI == 23 :
 Oo0OOo ( )
elif IiI1iIiiI1iI == 24 :
 o0oOoO00 ( )
elif IiI1iIiiI1iI == 25 :
 I11III11III1 ( )
elif IiI1iIiiI1iI == 26 :
 O0o0O0OO0o ( )
elif IiI1iIiiI1iI == 28 :
 I1Iiii ( iIIII1iIIii , oOOO00o000o )
elif IiI1iIiiI1iI == 29 :
 OO0ooo0 ( )
elif IiI1iIiiI1iI == 30 :
 ii1II1II ( )
elif IiI1iIiiI1iI == 31 :
 prueba ( )
elif IiI1iIiiI1iI == 98 :
 busqueda_global ( )
elif IiI1iIiiI1iI == 97 :
 iIIiI ( )
elif IiI1iIiiI1iI == 99 :
 oO00Ooo0oO ( )
elif IiI1iIiiI1iI == 100 :
 menu_player ( iIIII1iIIii , oOOO00o000o )
elif IiI1iIiiI1iI == 111 :
 iiIi1i ( )
elif IiI1iIiiI1iI == 115 :
 OOOoo00o0o ( oOOO00o000o )
elif IiI1iIiiI1iI == 116 :
 iIII1i1i ( )
elif IiI1iIiiI1iI == 117 :
 O0O00OOo ( )
elif IiI1iIiiI1iI == 119 :
 I1IiI111I11 ( )
elif IiI1iIiiI1iI == 120 :
 iIII1I1i1i ( )
elif IiI1iIiiI1iI == 121 :
 oOo0oO0o0Oo ( )
elif IiI1iIiiI1iI == 125 :
 IIOOO00o0 ( )
elif IiI1iIiiI1iI == 112 :
 list_proxy ( )
elif IiI1iIiiI1iI == 127 :
 iIii1iii ( )
elif IiI1iIiiI1iI == 128 :
 TESTLINKS ( )
elif IiI1iIiiI1iI == 130 :
 i1I1i1i1I1 ( iIIII1iIIii , oOOO00o000o )
elif IiI1iIiiI1iI == 140 :
 I11I1IIiiII1 ( )
elif IiI1iIiiI1iI == 141 :
 I1Ii ( )
elif IiI1iIiiI1iI == 142 :
 O00oOoo0OoO0 ( )
elif IiI1iIiiI1iI == 143 :
 oOoOo ( iIIII1iIIii , oOOO00o000o )
elif IiI1iIiiI1iI == 144 :
 I1Iiii ( iIIII1iIIii , oOOO00o000o )
elif IiI1iIiiI1iI == 145 :
 ooOo ( )
elif IiI1iIiiI1iI == 150 :
 OooOoOOo0oO00 ( )
elif IiI1iIiiI1iI == 151 :
 Ii ( )
elif IiI1iIiiI1iI == 152 :
 iIi1oOOOOOOOoO ( )
elif IiI1iIiiI1iI == 155 :
 oo00ooOoo ( )
 if 84 - 84: OoooooooOO . OOooOOo / o0000oOoOoO0o
 if 86 - 86: ii11ii1ii % OoOO0ooOOoo0O
xbmcplugin . endOfDirectory ( o0OoOoOO00 ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
