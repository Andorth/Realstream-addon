# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 1.0.3
#
############################################
# Dependencias 
# Script ExtendedInfo
# Script Urlresolver de TVAddons
# Script ResolveURL Por Jsergio.
#
############################################
#
# Agregar sinopsis a Peliculas y series.
#
############################################
if 64 - 64: i11iIiiIii
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import urlresolver
import cookielib , base64
import requests
import plugintools
import config
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
IiII1IiiIiI1 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
o0OoOoOO00 = int ( sys . argv [ 1 ] )
I11i = 'gruponetai/'
O0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
Oo = O0O . getAddonInfo ( 'profile' )
I1ii11iIi11i = O0O . getAddonInfo ( 'path' )
I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
if 73 - 73: OOooOOo / ii11ii1ii
def O00ooOO ( ) :
 if 47 - 47: oO0ooO % iI1Ii11111iIi + ii1II11I1ii1I + oO0o0ooO0 - iiIIIII1i1iI
 o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 oo00 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 o00 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 Oo0oO0ooo = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 o0oOoO00o = i1 ( o00 )
 oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
 for i11 in oOOoo00O0O :
  try :
   if 41 - 41: O00o0o0000o0o . oOo0oooo00o * I1i1i1ii - IIIII
   if 26 - 26: O00OoOoo00 . iiiI11 / oooOOOOO * iI1Ii11111iIi / iiiI11
   o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 80 - 80: ii1II11I1ii1I . iiIIIII1i1iI
   if 34 - 34: O00o0o0000o0o % OoooooooOO / i1IIi . IIIII + O0
   if o0oO0 == i11 :
    if 42 - 42: O00o0o0000o0o / i1IIi + i11iIiiIii - I1i1i1ii
    if 78 - 78: oO0ooO
    if 18 - 18: O0 - IIIII / IIIII + oooOOOOO % oooOOOOO - O00OoOoo00
    O0O00Ooo ( )
    if 64 - 64: iiIIIII1i1iI - O0 / II111iiii / ii1II11I1ii1I / iIii1I11I1II1
   else :
    if 24 - 24: O0 % ii1II11I1ii1I + i1IIi + iiiI11 + oO0o0ooO0
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold]>El addon esta desactivado.[/COLOR]" )
    if 70 - 70: ii11ii1ii % ii11ii1ii . O00OoOoo00 % oO0ooO * ii1II11I1ii1I % iiIIIII1i1iI
    if 23 - 23: i11iIiiIii + OOooOOo
  except :
   pass
   if 68 - 68: iI1Ii11111iIi . iiIIIII1i1iI . i11iIiiIii
   if 40 - 40: iiIIIII1i1iI . iI1Ii11111iIi . ii11ii1ii . i1IIi
   if 33 - 33: I1i1i1ii + II111iiii % i11iIiiIii . oooOOOOO - OOooOOo
   if 66 - 66: I1i1i1ii - OoooooooOO * OoooooooOO . O00o0o0000o0o . oO0o0ooO0
if I1IiI == 'true' :
 if 22 - 22: OoooooooOO % oOo0oooo00o - IIIII . iIii1I11I1II1 * i11iIiiIii
 II1i1Ii11Ii11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.png' ) )
 iII11i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 O0O00o0OOO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 Ii1iIIIi1ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 o0oo0o0O00OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 o0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.png' ) )
 I1i1iii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.png' ) )
 i1iiI11I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'estrenos.png' ) )
 iiii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.png' ) )
 oO0o0O0OOOoo0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.png' ) )
 IiIiiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.png' ) )
 I1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.png' ) )
 oOO00oOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.png' ) )
 OoOo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.png' ) )
 iI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 o00O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.png' ) )
 OOO0OOO00oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.png' ) )
 Iii111II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.png' ) )
 iiii11I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.png' ) )
 Ooo0OO0oOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.png' ) )
 ii11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.png' ) )
 IIIii1II1II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'marvel.png' ) )
 i1I1iI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.png' ) )
 oo0OooOOo0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.png' ) )
 o0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.png' ) )
 O00oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.png' ) )
 I11i1I1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.png' ) )
 oO0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.png' ) )
 oOOoo0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.png' ) )
 o00OO00OoO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.png' ) )
 OOOO0OOoO0O0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.png' ) )
 O0Oo000ooO00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.png' ) )
 oO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.png' ) )
 Ii1iIiII1ii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.jpg' ) )
 ooOooo000oOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.jpg' ) )
 Oo0oOOo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
 Oo0OoO00oOO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 OOO00O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 OOoOO0oo0ooO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.png' ) )
 O0o0O00Oo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 O00O0oOO00O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 i1Oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
else :
 if 31 - 31: iiiI11 . iI1Ii11111iIi / O0
 if 89 - 89: iI1Ii11111iIi
 Oo0OoO00oOO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 O0o0O00Oo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
 II1i1Ii11Ii11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.jpg' ) )
 iII11i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 O0O00o0OOO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 Ii1iIIIi1ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 o0oo0o0O00OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 o0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.jpg' ) )
 I1i1iii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.jpg' ) )
 i1iiI11I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'encines.jpg' ) )
 iiii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.jpg' ) )
 oO0o0O0OOOoo0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.jpg' ) )
 IiIiiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.jpg' ) )
 I1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.jpg' ) )
 oOO00oOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.jpg' ) )
 OoOo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.jpg' ) )
 iI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 o00O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.jpg' ) )
 OOO0OOO00oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.jpg' ) )
 Iii111II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.jpg' ) )
 iiii11I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.jpg' ) )
 Ooo0OO0oOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.jpg' ) )
 ii11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.jpg' ) )
 IIIii1II1II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'superheroes.jpg' ) )
 i1I1iI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.jpg' ) )
 oo0OooOOo0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.jpg' ) )
 o0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.jpg' ) )
 O00oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.jpg' ) )
 I11i1I1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.jpg' ) )
 oO0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.jpg' ) )
 oOOoo0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.jpg' ) )
 o00OO00OoO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.jpg' ) )
 OOOO0OOoO0O0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.jpg' ) )
 O0Oo000ooO00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.jpg' ) )
 oO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.jpg' ) )
 Ii1iIiII1ii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.jpg' ) )
 ooOooo000oOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.jpg' ) )
 OOO00O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 OOoOO0oo0ooO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.jpg' ) )
 Oo0oOOo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favoritos.png' ) )
 O00O0oOO00O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 i1Oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
 if 68 - 68: oO0ooO * OoooooooOO % O0 + oO0ooO + oooOOOOO
 if 4 - 4: oooOOOOO + O0 * O00o0o0000o0o
 if 55 - 55: ii11ii1ii + iIii1I11I1II1 / iI1Ii11111iIi * iiIIIII1i1iI - i11iIiiIii - I1i1i1ii
 if 25 - 25: oO0o0ooO0
 if 7 - 7: i1IIi / OOooOOo * iiiI11 . O00OoOoo00 . iIii1I11I1II1
iIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'peliculas.png' ) )
ooo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series.png' ) )
oOoO0o00OO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ajustes.png' ) )
i1I1ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'videoteca.png' ) )
oOOo0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
oo00O00oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'resolver.png' ) )
iIiIIIi = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'test.png' ) )
ooo00OOOooO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'video-tutoriales.png' ) )
O00OOOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'proxy.png' ) )
if 77 - 77: IIIII % IIIII * iiIIIII1i1iI - i11iIiiIii
Oo0oO = IiII1IiiIiI1 . getSetting ( 'mostrar_cat' )
IIiIi1iI = IiII1IiiIiI1 . getSetting ( 'videos' )
i1IiiiI1iI = IiII1IiiIiI1 . getSetting ( 'activar' )
i1iIi = IiII1IiiIiI1 . getSetting ( 'favcopy' )
ooOOoooooo = IiII1IiiIiI1 . getSetting ( 'anticopia' )
o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
O0i1II1Iiii1I11 = IiII1IiiIiI1 . getSetting ( 'mostrar_bus' )
IIII = IiII1IiiIiI1 . getSetting ( 'restante' )
iiIiI = IiII1IiiIiI1 . getSetting ( 'selecton' )
o00oooO0Oo = IiII1IiiIiI1 . getSetting ( 'aviso' )
o0O0OOO0Ooo = IiII1IiiIiI1 . getSetting ( 'RealStream_Settings' )
iiIiII1 = IiII1IiiIiI1 . getSetting ( 'Resolver_Settings' )
IIII = IiII1IiiIiI1 . getSetting ( 'restante' )
OOO00O0O = IiII1IiiIiI1 . getSetting ( 'fav' )
iii = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
oOooOOOoOo = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
i1Iii1i1I = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
OOoO00 = 'bienvenida'
IiI111111IIII = 'bienvenida'
copyright = IiII1IiiIiI1 . getSetting ( 'copyright' )
i1Ii = 'cGx1Z2luLnZpZGVvLg==' . decode ( 'base64' ) + copyright
ii111iI1iIi1 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
OOO = IiII1IiiIiI1 . getSetting ( 'Forceupdate' )
if OOO == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
oo0OOo0 = 'LnR4dA==' . decode ( 'base64' )
if 47 - 47: iiiI11 + iI1Ii11111iIi * ii11ii1ii / oooOOOOO - IIIII % iIii1I11I1II1
IIi11i1i1iI1 = 'aHR0cDovL2JpdC5seS8yU1FOSnlP' . decode ( 'base64' )
iiiIi1 = i1Iii1i1I + OOoO00 + oo0OOo0
i1I1ii11i1Iii = 'http://www.youtube.com'
I1IiiiiI = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
o0OIiII = '.xsl.pt'
ii1iII1II = 'L21hc3Rlci8=' . decode ( 'base64' )
Iii1I1I11iiI1 = I1IiiiiI + o0OIiII
I1I1i1I = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*texto3=[\'"](.*?)[\'"]\s*'
ii1I = 'tvg-logo=[\'"](.*?)[\'"]'
if 99 - 99: I1i1i1ii / ii11ii1ii / O00OoOoo00 % OOooOOo
i11I1II1I11i = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)'
OooOoOO0 = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.*)'
iI1i11iII111 = '(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)'
Iii1IIII11I = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
OOOoo0OO = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
oO0o0 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
iI1Ii11iIiI1 = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
OO0Oooo0oOO0O = '#(.+?),(.+)\s*(.+)'
o00O0 = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
if 83 - 83: oooOOOOO
oO00Oo0O0o = 'source src=[\'"](.*?)[\'"]\s*title=[\'"](.*?)[\'"]'
ii1 = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
I1iIIiiIIi1i = '[\'"](.*?)[\'"]'
O0O0ooOOO = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
oOOo0O00o = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( 'base64' )
iIiIi11 = oOOo0O00o + I11i
i1111 = '[\'"](.*?)[\'"]'
OOOiiiiI = 'UmVhbHN0cmVhbQ==' . decode ( 'base64' )
oooOo0OOOoo0 = 'video=[\'"](.*?)[\'"]'
oo00 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
o00 = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( 'base64' ) + oo00
OOoO = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
OO0O000 = '0110R0N' . replace ( '0110R0N' , 'R0N' )
iiIiI1i1 = 'aHR0cDovL2JpdC5seS8yWEIx' . decode ( 'base64' ) + OO0O000
oO0O00oOOoooO = '0110pEJ' . replace ( '0110pEJ' , 'pEJ' )
IiIi11iI = 'aHR0cDovL2JpdC5seS8yd1Nh' . decode ( 'base64' ) + oO0O00oOOoooO
Oo0O00O000 = 'ABBAOb5' . replace ( 'ABBAOb5' , 'Ob5' )
i11I1IiII1i1i = 'aHR0cDovL2JpdC5seS8yRVhV' . decode ( 'base64' ) + Oo0O00O000
oo = '0110jaw' . replace ( '0110jaw' , 'jaw' )
I1111i = 'aHR0cDovL2JpdC5seS8yd01M' . decode ( 'base64' ) + oo
iIIii = '01109DI' . replace ( '01109DI' , '9DI' )
o00O0O = 'aHR0cDovL2JpdC5seS8ySXgz' . decode ( 'base64' ) + iIIii
ii1iii1i = '01103hs' . replace ( '01103hs' , '3hs' )
Iii1I1111ii = 'aHR0cDovL2JpdC5seS8zMW1U' . decode ( 'base64' ) + ii1iii1i
ooOoO00 = '01107DW' . replace ( '01107DW' , '7DW' )
Ii1IIiI1i = 'aHR0cDovL2JpdC5seS8yV1ln' . decode ( 'base64' ) + ooOoO00
o0O00Oo0 = '0110mLl' . replace ( '0110mLl' , 'mLl' )
IiII111i1i11 = 'aHR0cDovL2JpdC5seS8yS0cw' . decode ( 'base64' ) + o0O00Oo0
i111iIi1i1II1 = '01102Hj' . replace ( '01102Hj' , '2Hj' )
oooO = 'aHR0cDovL2JpdC5seS8yWEJo' . decode ( 'base64' ) + i111iIi1i1II1
i1I1i111Ii = '0110fXg' . replace ( '0110fXg' , 'fXg' )
ooo = 'aHR0cDovL2JpdC5seS8ySTVy' . decode ( 'base64' ) + i1I1i111Ii
i1i1iI1iiiI = '0110NMH' . replace ( '0110NMH' , 'NMH' )
Ooo0oOooo0 = 'aHR0cDovL2JpdC5seS8yd0t6' . decode ( 'base64' ) + i1i1iI1iiiI
oOOOoo00 = '0110bwQ' . replace ( '0110bwQ' , 'bwQ' )
iiIiIIIiiI = 'aHR0cDovL2JpdC5seS8yd01V' . decode ( 'base64' ) + oOOOoo00
iiI1IIIi = '0110xzG' . replace ( '0110xzG' , 'xzG' )
II11IiIi11 = 'aHR0cDovL2JpdC5seS8yWHhz' . decode ( 'base64' ) + iiI1IIIi
II = '0110x64' . replace ( '0110x64' , 'x64' )
OOO0O00O0OOOO = 'aHR0cDovL2JpdC5seS8yRVlF' . decode ( 'base64' ) + II
I1iiii1I = '0110vUE' . replace ( '0110vUE' , 'vUE' )
OOo0 = 'aHR0cDovL2JpdC5seS8yWmhW' . decode ( 'base64' ) + I1iiii1I
oO00ooooO0o = '01107ZL' . replace ( '01107ZL' , '7ZL' )
oo0o = 'aHR0cDovL2JpdC5seS8yWm4w' . decode ( 'base64' ) + oO00ooooO0o
o0oO0oooOoo = '01106cf' . replace ( '01106cf' , '6cf' )
I1III1111iIi = 'aHR0cDovL2JpdC5seS8yRVlk' . decode ( 'base64' ) + o0oO0oooOoo
I1i111I = '0110Jtp' . replace ( '0110Jtp' , 'Jtp' )
Ooo = 'aHR0cDovL2JpdC5seS8yV3Nq' . decode ( 'base64' ) + I1i111I
Oo0oo0O0o00O = '0110a5b' . replace ( '0110a5b' , 'a5b' )
I1i11 = 'aHR0cDovL2JpdC5seS8yV3dj' . decode ( 'base64' ) + Oo0oo0O0o00O
IiIi1I1 = '0110Q7u' . replace ( '0110Q7u' , 'Q7u' )
IiIIi1 = 'aHR0cDovL2JpdC5seS8yV3NL' . decode ( 'base64' ) + IiIi1I1
IIIIiii1IIii = '0110rsq' . replace ( '0110rsq' , 'rsq' )
II1i11I = 'aHR0cDovL2JpdC5seS8ySzhE' . decode ( 'base64' ) + IIIIiii1IIii
ii1I1IIii11 = '0110DDR' . replace ( '0110DDR' , 'DDR' )
O0o0oO = 'aHR0cDovL2JpdC5seS8ySzd5' . decode ( 'base64' ) + ii1I1IIii11
IIIIiIiIi1 = '0110feQ' . replace ( '0110feQ' , 'feQ' )
I11iiiiI1i = 'aHR0cDovL2JpdC5seS8yS0cz' . decode ( 'base64' ) + IIIIiIiIi1
iI1i11 = '0110MHY' . replace ( '0110MHY' , 'MHY' )
OoOOoooOO0O = 'aHR0cDovL2JpdC5seS8ySXVo' . decode ( 'base64' ) + iI1i11
ooo00Ooo = '0110xdb' . replace ( '0110xdb' , 'xdb' )
Oo0o0O00 = 'aHR0cDovL2JpdC5seS8yWEJu' . decode ( 'base64' ) + ooo00Ooo
ii1I1i11 = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( 'base64' )
i1Ii = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
OO = '0110lxu' . replace ( '0110lxu' , 'lxu' )
o0O0oo0OO0O = 'aHR0cDovL2JpdC5seS8yV1Bj' . decode ( 'base64' ) + OO
OO0 = '0110pzp' . replace ( '0110pzp' , 'pzp' )
o0Oooo = 'aHR0cDovL2JpdC5seS8yVHpB' . decode ( 'base64' ) + OO0
iiI = '01105yt' . replace ( '01105yt' , '5yt' )
oO = 'aHR0cDovL2JpdC5seS8yTVpp' . decode ( 'base64' ) + iiI
if 10 - 10: ii11ii1ii / ii11ii1ii / iiiI11 . iiiI11
if 98 - 98: ii11ii1ii / OOooOOo . O0 + oO0ooO
ii = '1001DTs' . replace ( '1001DTs' , 'DTs' )
Iiii1iI1i = 'aHR0cDovL2JpdC5seS8ySzhP' . decode ( 'base64' ) + ii
I1ii1ii11i1I = '1001Hky' . replace ( '1001Hky' , 'Hky' )
o0OoOO = 'aHR0cDovL2JpdC5seS8yTGVL' . decode ( 'base64' ) + I1ii1ii11i1I
O0O0Oo00 = '1001VFU' . replace ( '1001VFU' , 'VFU' )
oOoO00o = 'aHR0cDovL2JpdC5seS8zMERx' . decode ( 'base64' ) + O0O0Oo00
oO00O0 = '3545OMZ' . replace ( '3545OMZ' , 'OMZ' )
IIi1IIIi = 'aHR0cDovL2JpdC5seS8yazhk' . decode ( 'base64' ) + oO00O0
if 99 - 99: I1i1i1ii + oO0ooO * II111iiii . ii1II11I1ii1I - oO0o0ooO0
def o0OOOo ( ) :
 if 11 - 11: iIii1I11I1II1 * iIii1I11I1II1 * OOooOOo
 if 46 - 46: iI1Ii11111iIi + oO0ooO
 try :
  if 70 - 70: IIIII / iIii1I11I1II1
  o0oOoO00o = i1 ( iiIiI1i1 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   try :
    if 19 - 19: i11iIiiIii + OoooooooOO - ii11ii1ii - oOo0oooo00o
    IiIi11iI = Oo0oooO0oO
    if 21 - 21: O0 % O00OoOoo00 . OOooOOo / II111iiii + O00OoOoo00
    OOOO0O00o = xbmc . Keyboard ( '' , 'Busqueda por titulo' )
    OOOO0O00o . doModal ( )
    if ( OOOO0O00o . isConfirmed ( ) ) :
     if 62 - 62: iIii1I11I1II1
     i1II = urllib . quote_plus ( OOOO0O00o . getText ( ) ) . replace ( '+' , ' ' )
     iI1I = i1 ( IiIi11iI )
     oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( iI1I )
     if 100 - 100: iIii1I11I1II1 + iI1Ii11111iIi / ii11ii1ii . i11iIiiIii
     for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
      if re . search ( i1II , iiIi1i ( i1Iii11I1i . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
       if 77 - 77: oO0o0ooO0 + oO0ooO / iiIIIII1i1iI + O0 * ii1II11I1ii1I
   except :
    pass
 except :
  pass
  if 28 - 28: oooOOOOO + i11iIiiIii / oOo0oooo00o % iI1Ii11111iIi % ii11ii1ii - O0
  if 54 - 54: i1IIi + II111iiii
  if 83 - 83: oO0o0ooO0 - OOooOOo + O00o0o0000o0o
def iIi1Ii1i1iI ( ) :
 if 16 - 16: O00o0o0000o0o / ii11ii1ii / OoooooooOO * OOooOOo + i1IIi % O00o0o0000o0o
 o00oooO0Oo = IiII1IiiIiI1 . getSetting ( 'aviso' )
 if o00oooO0Oo == 'true' :
  o0oOoO00o = i1 ( iiiIi1 )
  oOOoo00O0O = re . compile ( I1I1i1I ) . findall ( o0oOoO00o )
  for ooo0o00 , ooO , o0o00 in oOOoo00O0O :
   try :
    if 14 - 14: ii1II11I1ii1I . O00o0o0000o0o . oOo0oooo00o + OoooooooOO - O00o0o0000o0o + O00OoOoo00
    if 9 - 9: I1i1i1ii
    oooooOOO000Oo = ooo0o00
    Ooo00OoOOO = ooO
    Oo0OO0000oooo = o0o00
    if 7 - 7: iiIIIII1i1iI - oO0ooO - O0 % iiIIIII1i1iI - II111iiii
    if 31 - 31: IIIII / ii11ii1ii - IIIII - O00o0o0000o0o
    I1iiIIIi11 = "[B]" + oooooOOO000Oo + "[/B]"
    Ii1I11ii1i = "" + Ooo00OoOOO + ""
    O0iIiIIIIIii = "" + Oo0OO0000oooo + ""
    if 58 - 58: ii1II11I1ii1I / O00OoOoo00 . iI1Ii11111iIi / OoooooooOO + iiiI11
    xbmcgui . Dialog ( ) . ok ( "Real Stream" , I1iiIIIi11 , Ii1I11ii1i , O0iIiIIIIIii )
    if 86 - 86: oOo0oooo00o * OOooOOo + oOo0oooo00o + II111iiii
   except :
    pass
    if 8 - 8: iiiI11 - IIIII / oooOOOOO
    if 96 - 96: iI1Ii11111iIi
 IIiiI = i1 ( ii1I1i11 )
 oOOoo00O0O = re . compile ( I1iIIiiIIi1i ) . findall ( IIiiI )
 for III1i11 in oOOoo00O0O :
  try :
   if 25 - 25: oO0ooO
   import xbmc
   import xbmcaddon
   if 24 - 24: O00OoOoo00 * i11iIiiIii * O00o0o0000o0o
   __addon__ = xbmcaddon . Addon ( )
   __addonname__ = __addon__ . getAddonInfo ( 'name' )
   __icon__ = __addon__ . getAddonInfo ( 'icon' )
   if 85 - 85: ii1II11I1ii1I . iI1Ii11111iIi / oooOOOOO . O0 % iiiI11
   iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
   OO0ooo0oOO = III1i11
   if 97 - 97: OOooOOo / IIIII
   I1iiIIIi11 = "[COLOR orange]Version instalada: [COLOR gold] " + iIiiiI1IiI1I1 + " [/COLOR][/COLOR]"
   Oooo0 = 5000
   if 59 - 59: OoooooooOO
   xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , I1iiIIIi11 , Oooo0 , __icon__ ) )
   if 47 - 47: oooOOOOO - OOooOOo / II111iiii
   if 12 - 12: O00o0o0000o0o
   if iIiiiI1IiI1I1 < OO0ooo0oOO :
    if 83 - 83: IIIII . O0 / ii11ii1ii / O00o0o0000o0o - II111iiii
    xbmcgui . Dialog ( ) . ok ( "[B][COLOR fuchsia]Realstream:[/COLOR][/B]" , "[COLOR orange]Ya esta disponible la nueva version  [B][/COLOR][COLOR lime]" + III1i11 + "[/B][/COLOR][COLOR orange] Puedes actualizarla desde el repositorio Realstream, sino se actualiza sola.[/COLOR]" )
    xbmcgui . Dialog ( ) . ok ( "[B][COLOR fuchsia]Realstream: " + iIiiiI1IiI1I1 + "[/COLOR][/B]" , "[COLOR gold]Actualmente tiene instalada la version:  [/COLOR][COLOR lime][B]" + iIiiiI1IiI1I1 + "[/B][/COLOR]" , "[COLOR orange]Por favor actualiza desde el repositorio o bien configuralo para que se actualize automaticamente.[/COLOR]" )
  except :
   pass
 if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
  if 100 - 100: oO0ooO
  if 46 - 46: iI1Ii11111iIi / iIii1I11I1II1 % IIIII . iIii1I11I1II1 * IIIII
  if 38 - 38: oO0o0ooO0 - IIIII / O0 . iiiI11
def iiIi1i ( s ) :
 if 45 - 45: iiiI11
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 83 - 83: iI1Ii11111iIi . OoooooooOO
def Oo0ooo ( file ) :
 if 28 - 28: iiIIIII1i1iI . II111iiii / oO0o0ooO0 + II111iiii . OoooooooOO . O00OoOoo00
 try :
  O000OOO0OOo = open ( file , 'r' )
  o0oOoO00o = O000OOO0OOo . read ( )
  O000OOO0OOo . close ( )
  return o0oOoO00o
 except :
  pass
  if 32 - 32: I1i1i1ii * O0
def i1 ( url ) :
 if 100 - 100: oooOOOOO % iIii1I11I1II1 * II111iiii - IIIII
 try :
  oo00O00oO000o = urllib2 . Request ( url )
  oo00O00oO000o . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  OOo00OoO = urllib2 . urlopen ( oo00O00oO000o )
  iIi1 = OOo00OoO . read ( )
  OOo00OoO . close ( )
  return iIi1
 except urllib2 . URLError , i11iiI1111 :
  print 'We failed to open "%s".' % url
  if hasattr ( i11iiI1111 , 'code' ) :
   print 'We failed with error code - %s.' % i11iiI1111 . code
  if hasattr ( i11iiI1111 , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , i11iiI1111 . reason
   if 97 - 97: ii11ii1ii * OOooOOo . iIii1I11I1II1
def I1Ii1111iIi ( url ) :
 oo00O00oO000o = urllib2 . Request ( url )
 oo00O00oO000o . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 oo00O00oO000o . add_header ( 'Referer' , '%s' % url )
 oo00O00oO000o . add_header ( 'Connection' , 'keep-alive' )
 OOo00OoO = urllib2 . urlopen ( oo00O00oO000o )
 iIi1 = OOo00OoO . read ( )
 OOo00OoO . close ( )
 return iIi1
 if 31 - 31: oOo0oooo00o . iiiI11 * oooOOOOO + i11iIiiIii * iiIIIII1i1iI
 if 93 - 93: oO0o0ooO0 / iIii1I11I1II1 * i1IIi % OoooooooOO * O0 * oOo0oooo00o
def Ooooooo ( ) :
 if 39 - 39: O00OoOoo00 * ii11ii1ii + iIii1I11I1II1 - O00OoOoo00 + O00o0o0000o0o
 oOooOOOoOo = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 if 69 - 69: O0
 if i1IiiiI1iI == 'true' :
  if 85 - 85: oooOOOOO / O0
  iI1iIIIi1i ( '[COLOR %s]Buscar Pelicula[/COLOR]' % oOooOOOoOo , 'search' , 111 , O00O0oOO00O00 , II1i1Ii11Ii11 )
  iI1iIIIi1i ( '[COLOR %s]Buscar Serie[/COLOR]' % oOooOOOoOo , 'search' , 145 , i1Oo00 , II1i1Ii11Ii11 )
  iI1iIIIi1i ( '[COLOR %s]Peliculas[/COLOR] ' % oOooOOOoOo , 'movieDB' , 116 , iIii , II1i1Ii11Ii11 )
  iI1iIIIi1i ( '[COLOR %s]Series[/COLOR] ' % oOooOOOoOo , 'movieDB' , 117 , ooo0O , II1i1Ii11Ii11 )
  if 89 - 89: iIii1I11I1II1
  if 21 - 21: oOo0oooo00o % oOo0oooo00o
 if o0O0OOO0Ooo == 'true' :
  iI1iIIIi1i ( '[COLOR %s]Ajustes[/COLOR]' % oOooOOOoOo , 'Settings' , 119 , oOoO0o00OO0 , II1i1Ii11Ii11 )
  if 27 - 27: i11iIiiIii / oO0o0ooO0
  if 84 - 84: ii11ii1ii
  if Oo0oO == 'true' :
   iIiiiii1i ( )
   if 40 - 40: O0 - OoooooooOO - O00OoOoo00
  if iiIiII1 == 'true' :
   iIiii ( )
   OOOO00OO0O0 ( )
   if 48 - 48: iiiI11
  if ooOOoooooo == 'false' :
   if 72 - 72: IIIII * iiIIIII1i1iI % I1i1i1ii . OoooooooOO
   I1iiIIIi11 = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   Ii1I11ii1i = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Script.ResolveURL para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   O0iIiIIIIIii = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 99 - 99: iIii1I11I1II1 % oooOOOOO + oooOOOOO + IIIII - iiiI11 / iiiI11
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , I1iiIIIi11 , Ii1I11ii1i , O0iIiIIIIIii )
   if 7 - 7: OOooOOo + iI1Ii11111iIi / O00OoOoo00
def OOOoO000 ( ) :
 iI1iIIIi1i ( '[COLOR orange]Buscador por id[/COLOR]' , i1I1ii11i1Iii , 127 , o0oO , II1i1Ii11Ii11 )
 if 57 - 57: II111iiii
def oOOOoo ( ) :
 oOooOOOoOo = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 iI1iIIIi1i ( '[COLOR %s]The movie DB[/COLOR]' % oOooOOOoOo , 'movieDB' , 99 , o0oO , II1i1Ii11Ii11 )
 if 15 - 15: i11iIiiIii % OOooOOo * oOo0oooo00o / iiiI11
 iI1iIIIi1i ( '[COLOR %s]Video tutoriales[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 125 , ooo00OOOooO , II1i1Ii11Ii11 )
 if 90 - 90: IIIII
 if 31 - 31: O00o0o0000o0o + O0
def O0O00Ooo ( ) :
 if 87 - 87: oooOOOOO
 Ooooooo ( )
 oOOOoo ( )
 if 45 - 45: oO0ooO / OoooooooOO - IIIII / I1i1i1ii % O00OoOoo00
 if 83 - 83: OOooOOo . iIii1I11I1II1 - O00OoOoo00 * i11iIiiIii
 if 20 - 20: i1IIi * iiiI11 + II111iiii % ii1II11I1ii1I % iiIIIII1i1iI
 if 13 - 13: ii11ii1ii
 if 60 - 60: oO0o0ooO0 * OOooOOo
 if 17 - 17: O00o0o0000o0o % ii11ii1ii / oO0o0ooO0 . O00OoOoo00 * O00o0o0000o0o - II111iiii
 if 41 - 41: I1i1i1ii
 if 77 - 77: iiiI11
 if 65 - 65: II111iiii . OOooOOo % iiIIIII1i1iI * oO0ooO
 if 38 - 38: iI1Ii11111iIi / IIIII % ii11ii1ii
 if 11 - 11: IIIII - iiIIIII1i1iI + II111iiii - iIii1I11I1II1
def I1i11ii11 ( ) :
 OO00O0oOO = xbmcgui . Dialog ( )
 Ii1iI111 = (
 O0oooo00o0Oo ,
 I1iii ,
 )
 if 86 - 86: oO0o0ooO0 * O0 * O00OoOoo00
 Ooo0oo = OO00O0oOO . select ( '[B][COLOR=yellow]Listado de Proxys Gratuitos:[/COLOR][/B]' , [
 '[COLOR=orange]                      Accede a la web[/COLOR]' ,

 '[B][COLOR=gold]                      Volver al Menu [/COLOR][/B]' , ] )
 if 41 - 41: iI1Ii11111iIi * oOo0oooo00o / iI1Ii11111iIi % iiIIIII1i1iI
 if Ooo0oo :
  if 18 - 18: II111iiii . OoooooooOO % iI1Ii11111iIi % I1i1i1ii
  if Ooo0oo < 0 :
   return
  II1IiiIii = Ii1iI111 [ Ooo0oo - 2 ]
  return II1IiiIii ( )
 else :
  II1IiiIii = Ii1iI111 [ Ooo0oo ]
  return II1IiiIii ( )
 return
 if 84 - 84: iiIIIII1i1iI % i1IIi
def oOO ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 17 - 17: II111iiii / oO0o0ooO0 % O00OoOoo00 + OOooOOo * iiiI11
i1Ii1i1IiIIi1 = oOO ( )
if 26 - 26: oooOOOOO . O00o0o0000o0o - O00o0o0000o0o . oO0ooO
def O0oooo00o0Oo ( ) :
 if i1Ii1i1IiIIi1 == 'android' :
  Ii1IiII = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://hidemyna.me/es/proxy-list/?country=ES&type=hs#list' ) )
  if 27 - 27: IIIII . oOo0oooo00o . iIii1I11I1II1 . iIii1I11I1II1
 else :
  Ii1IiII = webbrowser . open ( 'https://hidemyna.me/es/proxy-list/?country=ES&type=hs#list' )
  if 20 - 20: ii1II11I1ii1I / i1IIi
  if 71 - 71: iI1Ii11111iIi . i1IIi
def I1iii ( ) :
 if 94 - 94: O00o0o0000o0o . iiiI11
 O0O00Ooo ( )
 if 84 - 84: O0 . oOo0oooo00o - II111iiii . oooOOOOO / II111iiii
 if 47 - 47: OoooooooOO
def ii1i1i1IiII ( ) :
 if xbmc . getCondVisibility ( 'System.HasAddon(script.favourites)' ) :
  try :
   xbmc . executebuiltin ( "RunScript(script.favourites)" )
  except :
   pass
def O0o ( ) :
 IiII1IiiIiI1 . openSettings ( )
 if 41 - 41: ii11ii1ii / I1i1i1ii * I1i1i1ii - O00o0o0000o0o . iiiI11 . OoooooooOO
 if 42 - 42: O00o0o0000o0o % ii11ii1ii / i11iIiiIii + O00o0o0000o0o
def O0oii111 ( ) :
 urlresolver . display_settings ( )
 if 58 - 58: O00o0o0000o0o * ii1II11I1ii1I + O0 % O00o0o0000o0o
def iIiii ( ) :
 iI1iIIIi1i ( '[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % oOooOOOoOo , 'resolve' , 120 , oo00O00oO , II1i1Ii11Ii11 )
 if 25 - 25: ii11ii1ii % oO0o0ooO0 * oooOOOOO
def I11 ( ) :
 if 87 - 87: iI1Ii11111iIi
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 25 - 25: i1IIi . oO0ooO - iI1Ii11111iIi / oO0ooO % oO0ooO * iIii1I11I1II1
def OOOO00OO0O0 ( ) :
 iI1iIIIi1i ( '[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % oOooOOOoOo , 'resolve' , 140 , oo00O00oO , II1i1Ii11Ii11 )
 if 50 - 50: oO0ooO . i11iIiiIii - iiIIIII1i1iI . iiIIIII1i1iI
def iIiiiii1i ( ) :
 if 31 - 31: O00o0o0000o0o / ii11ii1ii * i1IIi . iI1Ii11111iIi
 oOooOOOoOo = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 iI1iIIIi1i ( '[COLOR %s]Buscador[/COLOR]' % oOooOOOoOo , 'search' , 111 , Ii1iIIIi1ii , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Estrenos[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 3 , i1iiI11I , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Todas[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 26 , iiii , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]4K[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 141 , O0Oo000ooO00 , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Novedades[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 2 , I1i1iii , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Accion[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 5 , oO0o0O0OOOoo0 , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Animacion[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 6 , IiIiiI , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Artes Marciales[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 29 , Oo0OoO00oOO0o , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Aventuras[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 7 , I1I , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Belico[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 8 , oOO00oOO , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Ciencia Ficcion[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 9 , OoOo , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Cine Clasico[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 30 , iI , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Comedia[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 10 , o00O , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Crimen[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 11 , OOO0OOO00oo , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Drama[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 12 , Iii111II , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Familiar[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 13 , iiii11I , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Fantasia[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 14 , Ooo0OO0oOO , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Historia[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 15 , ii11i1 , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Misterio[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 16 , i1I1iI , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Musical[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 17 , oo0OooOOo0 , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Romance[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 18 , o0O , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Thriller[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 19 , oOOoo0Oo , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Suspense[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 20 , I11i1I1I , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Terror[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 21 , oO0Oo , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Western[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 22 , o00OO00OoO , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Spain[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 23 , O00oO , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Super heroes[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 24 , IIIii1II1II , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Sagas[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 25 , OOOO0OOoO0O0 , II1i1Ii11Ii11 )
 if 57 - 57: O00o0o0000o0o + iIii1I11I1II1 % i1IIi % OOooOOo
def OO0oo ( ) :
 if 15 - 15: iIii1I11I1II1 % OoooooooOO - ii11ii1ii * I1i1i1ii + oOo0oooo00o
 iI1iIIIi1i ( '[COLOR %s]Buscar Serie[/COLOR]' % oOooOOOoOo , 'search' , 145 , Ii1iIiII1ii1 , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]En emision[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 150 , OOO00O , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Mejor valoradas[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 151 , OOoOO0oo0ooO , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Series Retro[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 152 , O0o0O00Oo0o0 , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Todas[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 142 , ooOooo000oOO , II1i1Ii11Ii11 )
 if 11 - 11: IIIII * I1i1i1ii - iI1Ii11111iIi
def OOOIII1iI1iII1I ( ) :
 if 39 - 39: I1i1i1ii * oooOOOOO / iI1Ii11111iIi * oO0ooO . oOo0oooo00o % II111iiii
 if 71 - 71: iiiI11 % i1IIi - II111iiii - O00o0o0000o0o + O00o0o0000o0o * oooOOOOO
 try :
  if 51 - 51: iIii1I11I1II1 / iI1Ii11111iIi + O00o0o0000o0o - oOo0oooo00o + IIIII
  IIii1i1iii1 = i1 ( Iiii1iI1i )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( IIii1i1iii1 )
  for Oo0oooO0oO in oOOoo00O0O :
   if 70 - 70: i11iIiiIii % IIIII
   try :
    if 11 - 11: O00OoOoo00 % oO0o0ooO0 % I1i1i1ii / II111iiii % iiiI11 - ii11ii1ii
    OOooO = Oo0oooO0oO
    OOOO0O00o = xbmc . Keyboard ( '' , 'Buscar' )
    OOOO0O00o . doModal ( )
    if ( OOOO0O00o . isConfirmed ( ) ) :
     if 79 - 79: iiiI11 % iiIIIII1i1iI % ii1II11I1ii1I % I1i1i1ii - II111iiii * OoooooooOO
     i1II = urllib . quote_plus ( OOOO0O00o . getText ( ) ) . replace ( '+' , ' ' )
     IIiiI = i1 ( OOooO )
     oOOoo00O0O = re . compile ( Iii1IIII11I ) . findall ( IIiiI )
     for iII11i , i1Iii11I1i , II1i1Ii11Ii11 , Oo00o0OO0O00o in oOOoo00O0O :
      if re . search ( i1II , iiIi1i ( i1Iii11I1i . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       iI1iIIIi1i ( i1Iii11I1i , Oo00o0OO0O00o , 143 , iII11i , II1i1Ii11Ii11 )
       if 69 - 69: ii1II11I1ii1I / ii11ii1ii
   except :
    pass
 except :
  pass
  if 43 - 43: oO0o0ooO0 . OOooOOo / OoooooooOO % OoooooooOO
def iIIIII1iiiiII ( ) :
 if 54 - 54: i1IIi
 try :
  if 22 - 22: i1IIi + I1i1i1ii
  IIii1i1iii1 = i1 ( IIi1IIIi )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( IIii1i1iii1 )
  for Oo0oooO0oO in oOOoo00O0O :
   if 54 - 54: oooOOOOO % O00o0o0000o0o . iiiI11 + iiIIIII1i1iI - O00o0o0000o0o * OOooOOo
   try :
    if 92 - 92: ii1II11I1ii1I + iiiI11 / ii11ii1ii % oO0ooO % O00OoOoo00 . OoooooooOO
    OOooO = Oo0oooO0oO
    if 52 - 52: oooOOOOO / i11iIiiIii - O00o0o0000o0o . O00OoOoo00 % iIii1I11I1II1 + ii1II11I1ii1I
   except :
    pass
    if 71 - 71: iiIIIII1i1iI % oOo0oooo00o * iI1Ii11111iIi . O0 / I1i1i1ii . oO0o0ooO0
  IIiiI = i1 ( OOooO )
  oOOoo00O0O = re . compile ( Iii1IIII11I ) . findall ( IIiiI )
  for iII11i , i1Iii11I1i , II1i1Ii11Ii11 , Oo00o0OO0O00o in oOOoo00O0O :
   try :
    if 58 - 58: ii11ii1ii / iiIIIII1i1iI
    iI1iIIIi1i ( i1Iii11I1i , Oo00o0OO0O00o , 143 , iII11i , II1i1Ii11Ii11 )
    if 44 - 44: O00o0o0000o0o
   except :
    pass
 except :
  pass
  if 54 - 54: I1i1i1ii - oOo0oooo00o - iiiI11 . iIii1I11I1II1
  if 79 - 79: I1i1i1ii . oO0ooO
def IIiI1I1 ( ) :
 if 15 - 15: I1i1i1ii * ii11ii1ii % oO0o0ooO0 * iIii1I11I1II1 - i11iIiiIii
 try :
  if 60 - 60: OOooOOo * iiiI11 % oO0ooO + iiIIIII1i1iI
  IIii1i1iii1 = i1 ( oOoO00o )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( IIii1i1iii1 )
  for Oo0oooO0oO in oOOoo00O0O :
   if 52 - 52: i1IIi
   try :
    if 84 - 84: I1i1i1ii / O00OoOoo00
    OOooO = Oo0oooO0oO
    if 86 - 86: iI1Ii11111iIi * II111iiii - O0 . iI1Ii11111iIi % iIii1I11I1II1 / O00o0o0000o0o
   except :
    pass
    if 11 - 11: OOooOOo * iiIIIII1i1iI + oO0o0ooO0 / oO0o0ooO0
  IIiiI = i1 ( OOooO )
  oOOoo00O0O = re . compile ( Iii1IIII11I ) . findall ( IIiiI )
  for iII11i , i1Iii11I1i , II1i1Ii11Ii11 , Oo00o0OO0O00o in oOOoo00O0O :
   try :
    if 37 - 37: i11iIiiIii + i1IIi
    iI1iIIIi1i ( i1Iii11I1i , Oo00o0OO0O00o , 143 , iII11i , II1i1Ii11Ii11 )
    if 23 - 23: IIIII + oOo0oooo00o . iI1Ii11111iIi * OOooOOo + oO0o0ooO0
   except :
    pass
 except :
  pass
  if 18 - 18: O00OoOoo00 * ii1II11I1ii1I . O00OoOoo00 / O0
def iiIII1II ( ) :
 if 100 - 100: ii11ii1ii % I1i1i1ii / oOo0oooo00o
 try :
  if 30 - 30: ii11ii1ii - O00o0o0000o0o - IIIII
  IIii1i1iii1 = i1 ( o0OoOO )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( IIii1i1iii1 )
  for Oo0oooO0oO in oOOoo00O0O :
   if 81 - 81: ii1II11I1ii1I . OoooooooOO + O00o0o0000o0o * oooOOOOO
   try :
    if 74 - 74: i1IIi + O0 + ii11ii1ii
    OOooO = Oo0oooO0oO
    if 5 - 5: ii11ii1ii * iI1Ii11111iIi
   except :
    pass
    if 46 - 46: oooOOOOO
  IIiiI = i1 ( OOooO )
  oOOoo00O0O = re . compile ( Iii1IIII11I ) . findall ( IIiiI )
  for iII11i , i1Iii11I1i , II1i1Ii11Ii11 , Oo00o0OO0O00o in oOOoo00O0O :
   try :
    if 33 - 33: IIIII - II111iiii * OoooooooOO - ii11ii1ii - O00o0o0000o0o
    iI1iIIIi1i ( i1Iii11I1i , Oo00o0OO0O00o , 143 , iII11i , II1i1Ii11Ii11 )
    if 84 - 84: iiiI11 + ii11ii1ii - iI1Ii11111iIi * iI1Ii11111iIi
   except :
    pass
 except :
  pass
  if 61 - 61: OoooooooOO . iiIIIII1i1iI . OoooooooOO / ii11ii1ii
def o00Oi1i ( ) :
 if 5 - 5: iiIIIII1i1iI . oO0o0ooO0 . II111iiii . OoooooooOO
 try :
  if 96 - 96: i11iIiiIii - O00o0o0000o0o % O0 / oO0ooO
  IIii1i1iii1 = i1 ( Iiii1iI1i )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( IIii1i1iii1 )
  for Oo0oooO0oO in oOOoo00O0O :
   if 100 - 100: IIIII / I1i1i1ii - OoooooooOO % II111iiii - OOooOOo % iI1Ii11111iIi
   try :
    if 60 - 60: iIii1I11I1II1 + i1IIi
    OOooO = Oo0oooO0oO
    if 86 - 86: iIii1I11I1II1 + iI1Ii11111iIi . i11iIiiIii - I1i1i1ii
   except :
    pass
    if 51 - 51: iI1Ii11111iIi
  IIiiI = i1 ( OOooO )
  oOOoo00O0O = re . compile ( Iii1IIII11I ) . findall ( IIiiI )
  for iII11i , i1Iii11I1i , II1i1Ii11Ii11 , Oo00o0OO0O00o in oOOoo00O0O :
   try :
    if 14 - 14: O00OoOoo00 % iiIIIII1i1iI % ii11ii1ii - i11iIiiIii
    iI1iIIIi1i ( i1Iii11I1i , Oo00o0OO0O00o , 143 , iII11i , II1i1Ii11Ii11 )
    if 53 - 53: I1i1i1ii % ii11ii1ii
   except :
    pass
 except :
  pass
  if 59 - 59: O00o0o0000o0o % iIii1I11I1II1 . i1IIi + II111iiii * O00OoOoo00
def i1IiiI1iIi ( name , url ) :
 if 66 - 66: oO0ooO * ii11ii1ii
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 28 - 28: oO0ooO % iI1Ii11111iIi % oO0o0ooO0 + OOooOOo / OOooOOo
 iI1I = i1 ( url )
 oOOoo00O0O = re . compile ( oO0o0 ) . findall ( iI1I )
 for OO0O0ooOOO00 , name , II1i1Ii11Ii11 , url in oOOoo00O0O :
  try :
   if 17 - 17: O0 . iiiI11 . O0 + O0 / ii11ii1ii . oooOOOOO
   if 62 - 62: oO0o0ooO0 % IIIII * oO0ooO - i1IIi
   iii = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % iii + name + '[/COLOR]'
   OoOOo ( name , url , 144 , OO0O0ooOOO00 , II1i1Ii11Ii11 )
   if 17 - 17: i1IIi
   if 1 - 1: oooOOOOO
  except :
   pass
   if 78 - 78: oO0o0ooO0 + oOo0oooo00o - O0
   if 10 - 10: iiiI11 % OOooOOo
   if 97 - 97: OoooooooOO - iiiI11
def OoOOo ( name , url , mode , iconimage , fanart ) :
 if 58 - 58: iIii1I11I1II1 + O0
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 30 - 30: oooOOOOO % IIIII * O00o0o0000o0o - oO0o0ooO0 * I1i1i1ii % oooOOOOO
 iiiiI11ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage="
 O0i1i1II1i11 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 O0i1i1II1i11 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 O0i1i1II1i11 . setProperty ( 'fanart_image' , fanart )
 O0i1i1II1i11 . setProperty ( 'IsPlayable' , 'true' )
 o00o = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiiiI11ii , listitem = O0i1i1II1i11 )
 return o00o
 if 21 - 21: OoooooooOO - iIii1I11I1II1
 if 93 - 93: iiIIIII1i1iI - ii1II11I1ii1I % iI1Ii11111iIi . iI1Ii11111iIi - oooOOOOO
def O00ooOo ( name , url ) :
 if 80 - 80: ii1II11I1ii1I - O00o0o0000o0o + OoooooooOO
 if 98 - 98: O00o0o0000o0o + i1IIi . OOooOOo - II111iiii - ii1II11I1ii1I
 o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 oo00 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 o00 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 Oo0oO0ooo = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 o0oOoO00o = i1 ( o00 )
 oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
 for i11 in oOOoo00O0O :
  if 24 - 24: ii11ii1ii - i1IIi + oOo0oooo00o
  try :
   if 38 - 38: OoooooooOO / oO0o0ooO0 . O0 / i1IIi / ii11ii1ii + iIii1I11I1II1
   if 96 - 96: IIIII
   o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 18 - 18: IIIII * oOo0oooo00o - I1i1i1ii
   if 31 - 31: ii11ii1ii - O0 % iI1Ii11111iIi % iiIIIII1i1iI
   if o0oO0 == i11 :
    if 45 - 45: oO0o0ooO0 + II111iiii * i11iIiiIii
    if 13 - 13: OoooooooOO * iiIIIII1i1iI - I1i1i1ii / O00o0o0000o0o + oOo0oooo00o + O00OoOoo00
    if 'https://team.com' in url :
     if 39 - 39: iIii1I11I1II1 - OoooooooOO
     url = url . replace ( 'https://team.com' , 'https://verystream.com' )
     if 81 - 81: oO0o0ooO0 - O0 * OoooooooOO
    if 'https://mybox.com' in url :
     if 23 - 23: II111iiii / iiIIIII1i1iI
     url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
     if 28 - 28: ii11ii1ii * oooOOOOO - oO0ooO
     if 19 - 19: oOo0oooo00o
    if 'https://vidcloud.co/' in url :
     if 67 - 67: O0 % iIii1I11I1II1 / O00OoOoo00 . i11iIiiIii - I1i1i1ii + O0
     url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
     if 27 - 27: O00o0o0000o0o
    if 'https://gounlimited.to' in url :
     if 89 - 89: II111iiii / iiIIIII1i1iI
     url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
     if 14 - 14: O00o0o0000o0o . OOooOOo * oooOOOOO + II111iiii - oooOOOOO + O00o0o0000o0o
    if 'https://drive.com' in url :
     if 18 - 18: iiIIIII1i1iI - ii1II11I1ii1I - OOooOOo - OOooOOo
     url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
     if 54 - 54: ii11ii1ii + OOooOOo / IIIII . OOooOOo * iI1Ii11111iIi
     if 1 - 1: iI1Ii11111iIi * oO0ooO . i1IIi / ii11ii1ii . oO0o0ooO0 + ii11ii1ii
    import resolveurl
    if 17 - 17: ii11ii1ii + oO0ooO / I1i1i1ii / IIIII * O00o0o0000o0o
    II1iiIIiIii = urlresolver . HostedMediaFile ( url )
    if 5 - 5: iIii1I11I1II1 / oOo0oooo00o / i1IIi % OoooooooOO
    if not II1iiIIiIii :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
     return False
     if 50 - 50: I1i1i1ii / iI1Ii11111iIi * I1i1i1ii
    try :
     Ii1iIi111i1i1 = xbmcgui . DialogProgress ( )
     Ii1iIi111i1i1 . create ( 'Realstream:' , 'Iniciando ...' )
     Ii1iIi111i1i1 . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
     xbmc . sleep ( 1000 )
     IIOO0ooOo0OoOo0 = II1iiIIiIii . resolve ( )
     if not IIOO0ooOo0OoOo0 or not isinstance ( IIOO0ooOo0OoOo0 , basestring ) :
      try : oOo = IIOO0ooOo0OoOo0 . msg
      except : oOo = url
      raise Exception ( oOo )
      if 17 - 17: I1i1i1ii . i11iIiiIii
    except Exception as i11iiI1111 :
     try : oOo = str ( i11iiI1111 )
     except : oOo = url
     Ii1iIi111i1i1 . update ( 45 , 'RESOLVEURL:' , 'Reiniciando ... ' )
     xbmc . sleep ( 1000 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Episodio no disponible.  ,3000)" )
     Ii1iIi111i1i1 . close ( )
     if 5 - 5: oO0o0ooO0 + O0 + O0 . iiiI11 - oooOOOOO
    Ii1iIi111i1i1 . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    Ii1iIi111i1i1 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
    xbmc . sleep ( 500 )
    Ii1iIi111i1i1 . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
    xbmc . sleep ( 500 )
    Ii1iIi111i1i1 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de este capitulo!' )
    Ii1iIi111i1i1 . close ( )
    II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
    o00oo0000 = xbmcgui . ListItem ( path = IIOO0ooOo0OoOo0 )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o00oo0000 )
    if 44 - 44: ii11ii1ii % iIii1I11I1II1
    if 90 - 90: II111iiii + OoooooooOO % OoooooooOO
   else :
    if 35 - 35: IIIII / oO0o0ooO0 * OoooooooOO . II111iiii / ii11ii1ii
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold]>El addon esta desactivado.[/COLOR]" )
    if 1 - 1: OoooooooOO + O00OoOoo00 . i1IIi % oOo0oooo00o
    if 66 - 66: ii1II11I1ii1I + oO0o0ooO0 + OOooOOo - iiIIIII1i1iI
  except :
   pass
   if 12 - 12: IIIII . O00OoOoo00 . iI1Ii11111iIi / O0
   if 58 - 58: ii1II11I1ii1I - II111iiii % iiIIIII1i1iI + iiiI11 . iI1Ii11111iIi / O00OoOoo00
   if 8 - 8: oO0o0ooO0 . oO0ooO * oOo0oooo00o + II111iiii % i11iIiiIii
   if 8 - 8: oooOOOOO * O0
   if 73 - 73: ii1II11I1ii1I / iiIIIII1i1iI / oOo0oooo00o / oO0ooO
   if 11 - 11: iI1Ii11111iIi + O00OoOoo00 - OoooooooOO / oO0ooO
def iIIi1iI1I1IIi ( ) :
 if 77 - 77: oooOOOOO / ii11ii1ii + oooOOOOO % ii1II11I1ii1I - OOooOOo * OOooOOo
 if 23 - 23: IIIII . II111iiii % oO0o0ooO0 - OoooooooOO * ii11ii1ii . iIii1I11I1II1
 I1iI = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 I1iI . doModal ( )
 if not I1iI . isConfirmed ( ) :
  return None ;
 i1Iii11I1i = I1iI . getText ( ) . strip ( )
 if 92 - 92: I1i1i1ii % IIIII / oO0o0ooO0 % oO0o0ooO0 * OOooOOo
 if 74 - 74: O0 . OOooOOo % oO0ooO % O00OoOoo00
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 87 - 87: iiIIIII1i1iI - i11iIiiIii
  Ii1IiII = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + i1Iii11I1i + '&language=es-ES' ) )
  if 78 - 78: i11iIiiIii / iIii1I11I1II1 - ii1II11I1ii1I
  if 23 - 23: oOo0oooo00o
  return 'android'
  if 40 - 40: ii1II11I1ii1I - II111iiii / ii11ii1ii
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 14 - 14: oO0o0ooO0
  Ii1IiII = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + i1Iii11I1i + '&language=es-ES' )
  if 5 - 5: ii1II11I1ii1I . iIii1I11I1II1 % iIii1I11I1II1
  if 56 - 56: OoooooooOO - oOo0oooo00o - i1IIi
  return 'windows'
  if 8 - 8: iiiI11 / O00o0o0000o0o . OOooOOo + oO0o0ooO0 / i11iIiiIii
  if 31 - 31: oooOOOOO - iIii1I11I1II1 + IIIII . ii11ii1ii / O00OoOoo00 % iIii1I11I1II1
def I11i1iIiiIiIi ( ) :
 if 49 - 49: O00o0o0000o0o . oO0o0ooO0 . i11iIiiIii - II111iiii / I1i1i1ii
 ooOo0O0o0 = 'https://netai.eu/realstream/prueba.m3u'
 iI1I = i1 ( ooOo0O0o0 )
 oOOoo00O0O = re . compile ( OooOoOO0 ) . findall ( iI1I )
 for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo , o0oo0O , II1i1Ii11Ii11 in oOOoo00O0O :
  try :
   if 19 - 19: iiiI11 + i1IIi . OOooOOo - ii11ii1ii
   iIi1I1 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo , o0oo0O , II1i1Ii11Ii11 )
   if 63 - 63: IIIII * oO0o0ooO0 . OoooooooOO / O00o0o0000o0o * ii11ii1ii . oooOOOOO
  except :
   pass
   if 62 - 62: i1IIi / oooOOOOO . OOooOOo * ii1II11I1ii1I
   if 21 - 21: ii1II11I1ii1I
   if 81 - 81: oOo0oooo00o / iIii1I11I1II1 - oooOOOOO * iiiI11 . OOooOOo * oO0o0ooO0
def o0000 ( ) :
 if 42 - 42: iiiI11 + iiiI11 * II111iiii
 try :
  if 78 - 78: OoooooooOO
  o0oOoO00o = i1 ( iiIiI1i1 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 77 - 77: oO0o0ooO0 / i1IIi / ii11ii1ii % O00o0o0000o0o
   try :
    if 48 - 48: oOo0oooo00o - O00OoOoo00 + iIii1I11I1II1 + OoooooooOO
    all = Oo0oooO0oO
    if 4 - 4: II111iiii . oOo0oooo00o + I1i1i1ii * iiiI11 . oooOOOOO
   except :
    pass
    if 87 - 87: iI1Ii11111iIi / oO0ooO / i11iIiiIii
  iI1I = i1 ( all )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( iI1I )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    if 74 - 74: iiIIIII1i1iI / oO0o0ooO0 % ii1II11I1ii1I
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 88 - 88: iI1Ii11111iIi - i11iIiiIii % ii1II11I1ii1I * oOo0oooo00o + oO0o0ooO0
   except :
    pass
 except :
  pass
  if 52 - 52: II111iiii . OOooOOo + iI1Ii11111iIi % oO0ooO
def oo0O0o00 ( ) :
 if 70 - 70: oO0ooO
 try :
  if 46 - 46: oOo0oooo00o - i1IIi
  I1i1iii = i1 ( IiIi11iI )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( I1i1iii )
  for Oo0oooO0oO in oOOoo00O0O :
   if 46 - 46: iiiI11 % I1i1i1ii
   try :
    if 72 - 72: iIii1I11I1II1
    OOooO = Oo0oooO0oO
    if 45 - 45: ii11ii1ii - ii1II11I1ii1I % iiiI11
   except :
    pass
    if 38 - 38: iiiI11 % O00o0o0000o0o - OoooooooOO
  IIiiI = i1 ( OOooO )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( IIiiI )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    if 87 - 87: oO0ooO % OOooOOo
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 77 - 77: iIii1I11I1II1 - i1IIi . iiIIIII1i1iI
   except :
    pass
 except :
  pass
  if 26 - 26: ii1II11I1ii1I * O00OoOoo00 . i1IIi
def ooOoOO ( ) :
 if 56 - 56: iIii1I11I1II1 . i11iIiiIii - O00o0o0000o0o * II111iiii * iiiI11
 try :
  if 5 - 5: O00o0o0000o0o / O00o0o0000o0o - oO0o0ooO0
  i1iiI11I = i1 ( i11I1IiII1i1i )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( i1iiI11I )
  for Oo0oooO0oO in oOOoo00O0O :
   if 79 - 79: oO0o0ooO0 + iiiI11
   try :
    iIiIIi = Oo0oooO0oO
   except :
    pass
    if 14 - 14: ii1II11I1ii1I / O00o0o0000o0o - iIii1I11I1II1 - iiIIIII1i1iI % oooOOOOO
  o0oOoO00o = i1 ( iIiIIi )
  oOOoo00O0O = re . compile ( OooOoOO0 ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo , o0oo0O , II1i1Ii11Ii11 in oOOoo00O0O :
   try :
    if 49 - 49: oooOOOOO * iiIIIII1i1iI / ii1II11I1ii1I / ii11ii1ii * iIii1I11I1II1
    if 57 - 57: iI1Ii11111iIi - iiIIIII1i1iI / oooOOOOO % i11iIiiIii
    iIi1I1 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo , o0oo0O , II1i1Ii11Ii11 )
    if 3 - 3: IIIII . oooOOOOO % OOooOOo + oO0o0ooO0
   except :
    pass
 except :
  pass
  if 64 - 64: i1IIi
def IIii1 ( ) :
 if 35 - 35: i11iIiiIii - OOooOOo / O00o0o0000o0o + I1i1i1ii * iiIIIII1i1iI
 try :
  if 49 - 49: ii1II11I1ii1I * I1i1i1ii + oOo0oooo00o + IIIII
  o0oOoO00o = i1 ( db2 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 30 - 30: ii1II11I1ii1I / O00o0o0000o0o / O00OoOoo00 % oooOOOOO + II111iiii
   try :
    if 4 - 4: IIIII - ii11ii1ii - O00OoOoo00 - oOo0oooo00o % i11iIiiIii / oO0ooO
    i1iii11 = Oo0oooO0oO
    if 92 - 92: iI1Ii11111iIi . OoooooooOO - iiiI11
   except :
    pass
    if 74 - 74: iIii1I11I1II1 % IIIII * O00o0o0000o0o * iIii1I11I1II1
    if 73 - 73: ii1II11I1ii1I % iiiI11 . O00o0o0000o0o
  o0oOoO00o = i1 ( i1iii11 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 60 - 60: iI1Ii11111iIi
   except :
    pass
 except :
  pass
  if 5 - 5: OOooOOo - OOooOOo - OOooOOo * OoooooooOO
def iiiiiII ( ) :
 if 21 - 21: iIii1I11I1II1 / II111iiii % i1IIi
 try :
  if 8 - 8: oO0ooO + iI1Ii11111iIi . iIii1I11I1II1 % O0
  iI11Ii111 = i1 ( o0Oooo )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( iI11Ii111 )
  for Oo0oooO0oO in oOOoo00O0O :
   if 54 - 54: iI1Ii11111iIi % IIIII . iI1Ii11111iIi * O00o0o0000o0o + iI1Ii11111iIi % i1IIi
   try :
    if 23 - 23: iiiI11 - O00o0o0000o0o + I1i1i1ii - iI1Ii11111iIi * iI1Ii11111iIi . ii11ii1ii
    iIii11iI1II = Oo0oooO0oO
    if 42 - 42: oooOOOOO - OOooOOo + oO0o0ooO0 % I1i1i1ii
   except :
    pass
    if 44 - 44: i1IIi - O0 - oO0o0ooO0 * oO0o0ooO0 + iI1Ii11111iIi
    if 56 - 56: oooOOOOO / iIii1I11I1II1 . I1i1i1ii % iI1Ii11111iIi + O00o0o0000o0o
  o0oOoO00o = i1 ( iIii11iI1II )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 10 - 10: iiiI11 * i11iIiiIii - iIii1I11I1II1 . ii11ii1ii - oO0o0ooO0
   except :
    pass
 except :
  pass
  if 20 - 20: oO0o0ooO0 / OOooOOo * oO0ooO * OOooOOo * O0
def IiiIIi ( ) :
 if 71 - 71: O00OoOoo00 + i1IIi * ii11ii1ii % ii11ii1ii / ii11ii1ii
 try :
  if 55 - 55: OoooooooOO + iiiI11 + OoooooooOO * oooOOOOO
  o0oOoO00o = i1 ( I1111i )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 68 - 68: O0
   try :
    if 2 - 2: oO0ooO + O0 * oO0ooO - I1i1i1ii + iiIIIII1i1iI
    iIIIiII1 = Oo0oooO0oO
    if 24 - 24: ii1II11I1ii1I + oooOOOOO + oOo0oooo00o - iIii1I11I1II1
   except :
    pass
    if 49 - 49: oOo0oooo00o . oooOOOOO * iI1Ii11111iIi % O00OoOoo00 . O0
    if 48 - 48: O0 * I1i1i1ii - O0 / I1i1i1ii + iI1Ii11111iIi
  o0oOoO00o = i1 ( iIIIiII1 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 52 - 52: oO0ooO % I1i1i1ii * II111iiii
   except :
    pass
 except :
  pass
  if 4 - 4: oOo0oooo00o % O0 - OoooooooOO + oooOOOOO . iiIIIII1i1iI % II111iiii
def Iiii1iiiIiI1 ( ) :
 if 27 - 27: I1i1i1ii + OOooOOo * iIii1I11I1II1 . OoooooooOO * iI1Ii11111iIi
 try :
  if 100 - 100: oO0ooO / i1IIi - OOooOOo % I1i1i1ii - iIii1I11I1II1
  o0oOoO00o = i1 ( o00O0O )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 17 - 17: oOo0oooo00o / ii1II11I1ii1I % ii11ii1ii
   try :
    if 71 - 71: O00OoOoo00 . iiiI11 . oO0ooO
    Oo0O0O00Oo = Oo0oooO0oO
    if 10 - 10: I1i1i1ii + oOo0oooo00o % OoooooooOO - OOooOOo
   except :
    pass
    if 70 - 70: O00o0o0000o0o - IIIII
  o0oOoO00o = i1 ( Oo0O0O00Oo )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 2 - 2: iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 45 - 45: OoooooooOO / i11iIiiIii
def I11I1i1iI ( ) :
 if 90 - 90: O00OoOoo00 * II111iiii % iiiI11 + iiIIIII1i1iI
 try :
  if 93 - 93: iiiI11 + I1i1i1ii
  o0oOoO00o = i1 ( Iii1I1111ii )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 33 - 33: O0
   try :
    if 78 - 78: O0 / II111iiii * oO0ooO
    IiIi1iI11 = Oo0oooO0oO
    if 11 - 11: oO0o0ooO0
   except :
    pass
    if 26 - 26: iIii1I11I1II1 * iiiI11 - O00o0o0000o0o
    if 27 - 27: oO0o0ooO0 * iiiI11 - oO0ooO + I1i1i1ii * I1i1i1ii
  o0oOoO00o = i1 ( IiIi1iI11 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 55 - 55: oooOOOOO
   except :
    pass
 except :
  pass
  if 82 - 82: iiiI11 - O00o0o0000o0o + oO0ooO
def OO0iIiiIi11IIi ( ) :
 if 64 - 64: OoooooooOO . oO0o0ooO0 % O0 + OOooOOo - ii1II11I1ii1I
 try :
  if 84 - 84: i11iIiiIii * I1i1i1ii . i11iIiiIii
  o0oOoO00o = i1 ( Ii1IIiI1i )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 12 - 12: iI1Ii11111iIi % O00OoOoo00 % oO0o0ooO0 . i11iIiiIii * iIii1I11I1II1
   try :
    if 66 - 66: i11iIiiIii * iIii1I11I1II1 % OoooooooOO
    iIiI1iI1i1I = Oo0oooO0oO
    if 82 - 82: OOooOOo % oO0o0ooO0 * IIIII . I1i1i1ii % OOooOOo - iIii1I11I1II1
   except :
    pass
    if 15 - 15: oO0o0ooO0 % iiiI11 + i11iIiiIii
    if 10 - 10: I1i1i1ii - iI1Ii11111iIi . OoooooooOO . O00o0o0000o0o . oO0ooO * IIIII
  o0oOoO00o = i1 ( iIiI1iI1i1I )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 78 - 78: iiIIIII1i1iI / oO0ooO - iiIIIII1i1iI * OoooooooOO . iI1Ii11111iIi
   except :
    pass
 except :
  pass
  if 96 - 96: OOooOOo % i1IIi . ii1II11I1ii1I . O0
def Ii1Iii11 ( ) :
 if 97 - 97: O00o0o0000o0o / iiIIIII1i1iI . II111iiii
 try :
  if 44 - 44: I1i1i1ii % oOo0oooo00o . iiiI11
  o0oOoO00o = i1 ( IiII111i1i11 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 18 - 18: iIii1I11I1II1 + oOo0oooo00o * OOooOOo - O00o0o0000o0o / OOooOOo
   try :
    if 78 - 78: oOo0oooo00o . O00OoOoo00
    iI1i1II = Oo0oooO0oO
    if 14 - 14: oooOOOOO - iIii1I11I1II1 / O0 % O00OoOoo00 . iI1Ii11111iIi
   except :
    pass
    if 18 - 18: iiIIIII1i1iI * iiIIIII1i1iI % iiIIIII1i1iI
    if 17 - 17: O0 * iI1Ii11111iIi * oO0o0ooO0 * II111iiii * oOo0oooo00o % i1IIi
  o0oOoO00o = i1 ( iI1i1II )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 33 - 33: oO0o0ooO0 * oO0o0ooO0 . oooOOOOO . i11iIiiIii
   except :
    pass
 except :
  pass
  if 48 - 48: ii1II11I1ii1I . I1i1i1ii + iI1Ii11111iIi % oO0o0ooO0 / i11iIiiIii
def OoO ( ) :
 if 10 - 10: oOo0oooo00o / oOo0oooo00o * i11iIiiIii
 try :
  if 46 - 46: oO0ooO * ii11ii1ii % iiIIIII1i1iI + O0 * O00OoOoo00
  o0oOoO00o = i1 ( oO )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 34 - 34: oO0ooO
   try :
    if 27 - 27: I1i1i1ii - O0 % oOo0oooo00o * iiiI11 . O00OoOoo00 % iIii1I11I1II1
    IiIi1i = Oo0oooO0oO
    if 99 - 99: iI1Ii11111iIi . iiiI11
   except :
    pass
    if 59 - 59: oOo0oooo00o / ii11ii1ii / O00o0o0000o0o / O0 / iI1Ii11111iIi + ii1II11I1ii1I
    if 13 - 13: ii1II11I1ii1I % iiIIIII1i1iI / iiiI11 % iiiI11 % O0
  o0oOoO00o = i1 ( IiIi1i )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 90 - 90: O00OoOoo00 . oooOOOOO / iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 28 - 28: O00OoOoo00 + iiIIIII1i1iI - oooOOOOO / iIii1I11I1II1 - OOooOOo
  if 45 - 45: O0 / i1IIi * iiIIIII1i1iI * oO0ooO
def II11I ( ) :
 if 31 - 31: I1i1i1ii
 try :
  if 18 - 18: oooOOOOO + I1i1i1ii
  o0oOoO00o = i1 ( oooO )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 5 - 5: OoooooooOO + oOo0oooo00o * II111iiii
   try :
    if 98 - 98: O00o0o0000o0o % i1IIi . OOooOOo . II111iiii . oO0o0ooO0 / i11iIiiIii
    iIii1I = Oo0oooO0oO
    if 50 - 50: iI1Ii11111iIi
   except :
    pass
    if 33 - 33: oOo0oooo00o
    if 98 - 98: iI1Ii11111iIi % II111iiii
  o0oOoO00o = i1 ( iIii1I )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 95 - 95: iIii1I11I1II1 - iiiI11 - O00o0o0000o0o + iiiI11 % oO0o0ooO0 . OOooOOo
   except :
    pass
 except :
  pass
  if 41 - 41: O0 + iiIIIII1i1iI . i1IIi - II111iiii * ii1II11I1ii1I . oO0ooO
  if 68 - 68: ii1II11I1ii1I
def i11Ii1IIi ( ) :
 if 36 - 36: O0 * oO0ooO % IIIII * IIIII / oO0ooO * O00OoOoo00
 try :
  if 14 - 14: i1IIi . O00OoOoo00 + O0 * oooOOOOO
  o0oOoO00o = i1 ( ooo )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 76 - 76: oO0ooO
   try :
    if 92 - 92: oOo0oooo00o - iIii1I11I1II1 % OoooooooOO
    I1 = Oo0oooO0oO
    if 84 - 84: iI1Ii11111iIi - i11iIiiIii
   except :
    pass
    if 1 - 1: IIIII * iI1Ii11111iIi
    if 66 - 66: iI1Ii11111iIi + i1IIi % II111iiii . O0 * oO0o0ooO0 % oO0o0ooO0
  o0oOoO00o = i1 ( I1 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 87 - 87: O00o0o0000o0o + ii1II11I1ii1I . IIIII - OoooooooOO
   except :
    pass
    if 6 - 6: iIii1I11I1II1 * OoooooooOO
 except :
  pass
  if 28 - 28: ii11ii1ii * ii1II11I1ii1I / iiiI11
  if 52 - 52: O0 / ii1II11I1ii1I % IIIII * OOooOOo % O00o0o0000o0o
def o0oOOOO0 ( ) :
 if 11 - 11: i1IIi
 try :
  if 19 - 19: IIIII - ii1II11I1ii1I - I1i1i1ii - iI1Ii11111iIi . IIIII . iiiI11
  o0oOoO00o = i1 ( Ooo0oOooo0 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 48 - 48: IIIII + O00OoOoo00
   try :
    if 60 - 60: oOo0oooo00o + IIIII . O00OoOoo00 / i1IIi . iIii1I11I1II1
    i1i11ii1Ii = Oo0oooO0oO
    if 12 - 12: O00o0o0000o0o . I1i1i1ii
   except :
    pass
    if 79 - 79: iiiI11 / ii11ii1ii / IIIII . iiiI11 * OoooooooOO + ii1II11I1ii1I
    if 73 - 73: O0 - oO0o0ooO0
  o0oOoO00o = i1 ( i1i11ii1Ii )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 2 - 2: II111iiii / iiiI11
   except :
    pass
    if 54 - 54: i1IIi . oOo0oooo00o - oO0o0ooO0 + oooOOOOO + ii11ii1ii / ii11ii1ii
 except :
  pass
  if 22 - 22: oooOOOOO . iIii1I11I1II1
def i1IiiiiIi1I ( ) :
 if 56 - 56: OoooooooOO * O0
 try :
  if 85 - 85: OoooooooOO % iI1Ii11111iIi * iIii1I11I1II1
  o0oOoO00o = i1 ( iiIiIIIiiI )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 44 - 44: iIii1I11I1II1 . oO0o0ooO0 + iiiI11 . oooOOOOO
   try :
    if 7 - 7: oO0o0ooO0 + iIii1I11I1II1 * oOo0oooo00o * oOo0oooo00o / II111iiii - I1i1i1ii
    oOOOo0o = Oo0oooO0oO
    if 26 - 26: iIii1I11I1II1 - O0 . O0
   except :
    pass
    if 68 - 68: O00o0o0000o0o + iiIIIII1i1iI . O0 . I1i1i1ii % i1IIi % O00o0o0000o0o
  o0oOoO00o = i1 ( oOOOo0o )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 50 - 50: O00OoOoo00 + ii1II11I1ii1I
   except :
    pass
 except :
  pass
  if 96 - 96: oO0ooO
  if 92 - 92: ii11ii1ii / i11iIiiIii + oO0o0ooO0
def oOo0Oo0O0O ( ) :
 if 48 - 48: ii11ii1ii - oooOOOOO + ii11ii1ii - OOooOOo * i11iIiiIii . IIIII
 try :
  if 35 - 35: O00OoOoo00 . O0 + ii11ii1ii + O00o0o0000o0o + i1IIi
  o0oOoO00o = i1 ( II11IiIi11 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 65 - 65: O0 * OOooOOo / OOooOOo . iI1Ii11111iIi
   try :
    if 87 - 87: II111iiii * oO0o0ooO0 % ii11ii1ii * ii11ii1ii
    O0OOOOOO0 = Oo0oooO0oO
    if 79 - 79: II111iiii - oooOOOOO . i1IIi + O0 % O0 * OOooOOo
   except :
    pass
    if 7 - 7: i1IIi + O00o0o0000o0o % IIIII / ii1II11I1ii1I + i1IIi
    if 41 - 41: I1i1i1ii + i11iIiiIii / O00OoOoo00 % oO0o0ooO0
  o0oOoO00o = i1 ( O0OOOOOO0 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 22 - 22: iI1Ii11111iIi % ii1II11I1ii1I * I1i1i1ii - oO0o0ooO0 + ii1II11I1ii1I - ii11ii1ii
   except :
    pass
 except :
  pass
  if 15 - 15: O00o0o0000o0o
  if 31 - 31: IIIII / i1IIi . oO0ooO
def OOOoo ( ) :
 if 25 - 25: oO0o0ooO0 + iiIIIII1i1iI + OoooooooOO . II111iiii . IIIII
 try :
  if 66 - 66: oooOOOOO * iI1Ii11111iIi
  o0oOoO00o = i1 ( OOO0O00O0OOOO )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 2 - 2: iiIIIII1i1iI . iiiI11 * ii11ii1ii + O0 - oOo0oooo00o * iIii1I11I1II1
   try :
    if 12 - 12: ii1II11I1ii1I * iiiI11 % II111iiii * i1IIi * iIii1I11I1II1
    oO0oOoo0O = Oo0oooO0oO
    if 26 - 26: ii11ii1ii + OOooOOo * O00o0o0000o0o + oooOOOOO
   except :
    pass
  o0oOoO00o = i1 ( oO0oOoo0O )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 88 - 88: oOo0oooo00o + i11iIiiIii % iiIIIII1i1iI * O00o0o0000o0o * O00o0o0000o0o * I1i1i1ii
   except :
    pass
 except :
  pass
  if 24 - 24: oooOOOOO / IIIII + O00OoOoo00 . O00OoOoo00
def I1ii1i ( ) :
 if 22 - 22: iiIIIII1i1iI * I1i1i1ii * i11iIiiIii + IIIII * iI1Ii11111iIi * oO0ooO
 try :
  if 85 - 85: IIIII * O00o0o0000o0o % ii11ii1ii - IIIII - oOo0oooo00o
  o0oOoO00o = i1 ( OOo0 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 46 - 46: O0
   try :
    if 65 - 65: iIii1I11I1II1 % iiIIIII1i1iI + O0 / OoooooooOO
    O0000oO0o00 = Oo0oooO0oO
    if 80 - 80: OoooooooOO + O00OoOoo00
   except :
    pass
    if 95 - 95: iiiI11 / iiIIIII1i1iI * iiiI11 - OoooooooOO * OoooooooOO % oO0ooO
    if 43 - 43: ii11ii1ii . iiiI11
  o0oOoO00o = i1 ( O0000oO0o00 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 12 - 12: iiiI11 + O00o0o0000o0o + oOo0oooo00o . O00OoOoo00 / I1i1i1ii
   except :
    pass
 except :
  pass
  if 29 - 29: O00OoOoo00 . oooOOOOO - II111iiii
  if 68 - 68: iIii1I11I1II1 + II111iiii / iiIIIII1i1iI
def oOooo00000 ( ) :
 if 26 - 26: O0
 try :
  if 34 - 34: oooOOOOO * iiiI11
  o0oOoO00o = i1 ( oo0o )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 97 - 97: i11iIiiIii % iiIIIII1i1iI / ii11ii1ii / ii11ii1ii
   try :
    if 97 - 97: II111iiii - iiiI11 - iIii1I11I1II1 * OOooOOo
    oooO0o0O0oo0o = Oo0oooO0oO
    if 100 - 100: O00OoOoo00 . I1i1i1ii - iIii1I11I1II1 . i11iIiiIii / II111iiii
   except :
    pass
    if 71 - 71: iiiI11 * ii11ii1ii . oOo0oooo00o
    if 49 - 49: O00OoOoo00 * O0 . O00OoOoo00
  o0oOoO00o = i1 ( oooO0o0O0oo0o )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 19 - 19: II111iiii - O00OoOoo00
   except :
    pass
 except :
  pass
  if 59 - 59: ii1II11I1ii1I * oO0ooO - I1i1i1ii . O00o0o0000o0o
def o0OO00oo0O ( ) :
 if 46 - 46: i11iIiiIii - O00o0o0000o0o * OOooOOo * oOo0oooo00o % oO0o0ooO0 * i1IIi
 try :
  if 5 - 5: O0 / oooOOOOO . ii11ii1ii + OoooooooOO
  o0oOoO00o = i1 ( I1III1111iIi )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 97 - 97: O00OoOoo00 . I1i1i1ii . I1i1i1ii / iIii1I11I1II1 - oO0ooO + IIIII
   try :
    if 32 - 32: O00o0o0000o0o . ii1II11I1ii1I % O00OoOoo00 + oO0o0ooO0 + oO0ooO
    OOOoOOo0o = Oo0oooO0oO
    if 50 - 50: II111iiii - iiiI11 + iIii1I11I1II1 + iIii1I11I1II1
   except :
    pass
    if 91 - 91: II111iiii - O0 . iIii1I11I1II1 . O0 + oO0o0ooO0 - II111iiii
    if 26 - 26: ii1II11I1ii1I
  o0oOoO00o = i1 ( OOOoOOo0o )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 12 - 12: OoooooooOO / O0 + II111iiii * oO0o0ooO0
   except :
    pass
 except :
  pass
  if 46 - 46: II111iiii - O00OoOoo00 * OoooooooOO / iiIIIII1i1iI % O00OoOoo00
  if 11 - 11: iIii1I11I1II1 . iI1Ii11111iIi / O00OoOoo00 % oooOOOOO
def o0O00Oooo ( ) :
 if 12 - 12: oooOOOOO
 try :
  if 86 - 86: iiIIIII1i1iI - oO0ooO
  o0oOoO00o = i1 ( Ooo )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 63 - 63: OOooOOo / iI1Ii11111iIi + OoooooooOO . oOo0oooo00o . oooOOOOO
   try :
    if 48 - 48: i1IIi - IIIII - i11iIiiIii . oOo0oooo00o - IIIII * oOo0oooo00o
    OOOOO = Oo0oooO0oO
    if 68 - 68: oOo0oooo00o + oO0ooO - O0 / oO0ooO * iI1Ii11111iIi
   except :
    pass
    if 50 - 50: O00o0o0000o0o + II111iiii . OOooOOo / i1IIi / OOooOOo * iiIIIII1i1iI
    if 85 - 85: II111iiii . oooOOOOO % O00o0o0000o0o % oOo0oooo00o
  o0oOoO00o = i1 ( OOOOO )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 80 - 80: iiIIIII1i1iI * oOo0oooo00o / iIii1I11I1II1 % iiIIIII1i1iI / iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 42 - 42: i1IIi / i11iIiiIii . ii11ii1ii * IIIII . i11iIiiIii * O0
  if 44 - 44: i1IIi . OOooOOo / i11iIiiIii + O00OoOoo00
def iI111II1ii ( ) :
 if 62 - 62: IIIII * iIii1I11I1II1 . O00OoOoo00 - OoooooooOO * II111iiii
 try :
  if 45 - 45: O0 % OOooOOo - IIIII . oO0ooO
  o0oOoO00o = i1 ( I1i11 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 42 - 42: IIIII / ii1II11I1ii1I + ii11ii1ii . ii11ii1ii % O00o0o0000o0o
   try :
    if 16 - 16: i1IIi + oO0ooO % iI1Ii11111iIi + I1i1i1ii * ii11ii1ii
    i1o0oo0 = Oo0oooO0oO
    if 67 - 67: O0 * oOo0oooo00o - ii1II11I1ii1I - II111iiii
   except :
    pass
    if 41 - 41: OOooOOo - iiiI11 % II111iiii . iiiI11 - oOo0oooo00o
    if 45 - 45: I1i1i1ii - O00o0o0000o0o
  o0oOoO00o = i1 ( i1o0oo0 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 70 - 70: oO0ooO % OOooOOo / OOooOOo . oOo0oooo00o % oooOOOOO . II111iiii
   except :
    pass
 except :
  pass
  if 10 - 10: I1i1i1ii - i11iIiiIii . oO0o0ooO0 % i1IIi
  if 78 - 78: iIii1I11I1II1 * ii11ii1ii . ii11ii1ii - O00o0o0000o0o . iIii1I11I1II1
def I111I1I ( ) :
 if 54 - 54: II111iiii + oOo0oooo00o % oOo0oooo00o % ii1II11I1ii1I
 try :
  if 25 - 25: IIIII - ii11ii1ii
  o0oOoO00o = i1 ( IiIIi1 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 10 - 10: O0 % O00OoOoo00 . oO0ooO + ii1II11I1ii1I + oO0o0ooO0
   try :
    if 52 - 52: iI1Ii11111iIi / oO0ooO + iiiI11
    Iii1i11iiI1 = Oo0oooO0oO
    if 95 - 95: iiIIIII1i1iI * iIii1I11I1II1 + oO0o0ooO0
   except :
    pass
    if 5 - 5: ii11ii1ii
    if 100 - 100: I1i1i1ii + iIii1I11I1II1
  o0oOoO00o = i1 ( Iii1i11iiI1 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 59 - 59: O00OoOoo00
   except :
    pass
 except :
  pass
  if 89 - 89: iI1Ii11111iIi % iIii1I11I1II1
  if 35 - 35: oO0o0ooO0 + iiiI11 - iI1Ii11111iIi % iiIIIII1i1iI % ii1II11I1ii1I % iI1Ii11111iIi
def ii1IIiII111I ( ) :
 if 87 - 87: I1i1i1ii - oO0o0ooO0 % oO0o0ooO0 . iiIIIII1i1iI / oO0o0ooO0
 try :
  if 6 - 6: iI1Ii11111iIi / iIii1I11I1II1 * OoooooooOO * i11iIiiIii
  o0oOoO00o = i1 ( II1i11I )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 79 - 79: O00OoOoo00 % oO0ooO
   try :
    if 81 - 81: i11iIiiIii + i11iIiiIii * oO0ooO + O00OoOoo00
    iiiiiI = Oo0oooO0oO
    if 17 - 17: i11iIiiIii / ii11ii1ii . oO0ooO / OOooOOo
   except :
    pass
    if 38 - 38: i1IIi . oO0o0ooO0 % I1i1i1ii + iIii1I11I1II1 + O0
  o0oOoO00o = i1 ( iiiiiI )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 47 - 47: oO0ooO + O00OoOoo00 / II111iiii
   except :
    pass
 except :
  pass
  if 97 - 97: oO0o0ooO0 / OOooOOo % O0 + i1IIi - oooOOOOO
  if 38 - 38: ii1II11I1ii1I % iiiI11 + i11iIiiIii + IIIII + oooOOOOO / i11iIiiIii
def o0OOOOOo0 ( ) :
 if 57 - 57: iIii1I11I1II1 + iIii1I11I1II1
 try :
  if 56 - 56: iiIIIII1i1iI + oooOOOOO
  o0oOoO00o = i1 ( O0o0oO )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 32 - 32: II111iiii + iI1Ii11111iIi % oooOOOOO / iI1Ii11111iIi + oO0o0ooO0
   try :
    if 2 - 2: i11iIiiIii - iiiI11 + oO0ooO % oOo0oooo00o * I1i1i1ii
    Ooo000O00 = Oo0oooO0oO
    if 36 - 36: O00o0o0000o0o % i11iIiiIii
   except :
    pass
    if 47 - 47: i1IIi + II111iiii . ii11ii1ii * iiIIIII1i1iI . oOo0oooo00o / i1IIi
    if 50 - 50: iiiI11 / i1IIi % OoooooooOO
  o0oOoO00o = i1 ( Ooo000O00 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 83 - 83: oO0o0ooO0 * oO0o0ooO0 + O00o0o0000o0o
   except :
    pass
 except :
  pass
  if 57 - 57: O0 - O0 . oO0o0ooO0 / ii1II11I1ii1I / I1i1i1ii
def I1IiII1I1i1I1 ( ) :
 if 28 - 28: ii11ii1ii + O00OoOoo00 % II111iiii / oO0ooO + i11iIiiIii
 try :
  if 20 - 20: oO0o0ooO0
  o0oOoO00o = i1 ( I11iiiiI1i )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 3 - 3: oO0ooO * i1IIi . OOooOOo . O0 - iI1Ii11111iIi
   try :
    if 81 - 81: OOooOOo - iIii1I11I1II1 / OOooOOo / O0
    I1I1IIiiii1ii = Oo0oooO0oO
    if 92 - 92: iiIIIII1i1iI / O00o0o0000o0o . oO0o0ooO0
   except :
    pass
  o0oOoO00o = i1 ( I1I1IIiiii1ii )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 30 - 30: I1i1i1ii . oO0o0ooO0 / O00o0o0000o0o
   except :
    pass
 except :
  pass
  if 2 - 2: O00OoOoo00 % OOooOOo - iiiI11
def oooOo ( ) :
 if 79 - 79: iiIIIII1i1iI - II111iiii
 try :
  if 43 - 43: i1IIi + O0 % oO0ooO / I1i1i1ii * OOooOOo
  o0oOoO00o = i1 ( OoOOoooOO0O )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 89 - 89: OOooOOo . ii11ii1ii + oO0o0ooO0 . O0 % ii1II11I1ii1I
   try :
    if 84 - 84: OoooooooOO + iiiI11 / OOooOOo % O00o0o0000o0o % oO0o0ooO0 * OOooOOo
    OOoO0oooo = Oo0oooO0oO
    if 24 - 24: oOo0oooo00o / OOooOOo * i1IIi % OoooooooOO
   except :
    pass
  o0oOoO00o = i1 ( OOoO0oooo )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 99 - 99: i11iIiiIii . II111iiii . OoooooooOO
   except :
    pass
 except :
  pass
  if 59 - 59: i11iIiiIii . OoooooooOO / oOo0oooo00o * oO0o0ooO0 + OoooooooOO
def Ii1I1i1ii1I1 ( ) :
 if 98 - 98: O00OoOoo00 * iIii1I11I1II1 . I1i1i1ii * ii11ii1ii / oO0o0ooO0 + oooOOOOO
 try :
  if 25 - 25: iiIIIII1i1iI
  o0oOoO00o = i1 ( o0O0oo0OO0O )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 19 - 19: OOooOOo % I1i1i1ii . O00OoOoo00 * oooOOOOO
   try :
    if 89 - 89: iI1Ii11111iIi . O00o0o0000o0o
    IIIIIiI11Ii = Oo0oooO0oO
    if 41 - 41: i11iIiiIii - i1IIi / ii11ii1ii * O00OoOoo00 / iiiI11 - ii11ii1ii
   except :
    pass
  o0oOoO00o = i1 ( IIIIIiI11Ii )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 56 - 56: O0
   except :
    pass
 except :
  pass
  if 45 - 45: iI1Ii11111iIi - oO0ooO - iI1Ii11111iIi
def IIiiIiII11iiiiiii ( ) :
 if 82 - 82: oOo0oooo00o / oooOOOOO * oOo0oooo00o % i11iIiiIii * II111iiii
 try :
  if 83 - 83: oO0ooO + O00o0o0000o0o - ii1II11I1ii1I + iIii1I11I1II1 % ii11ii1ii
  o0oOoO00o = i1 ( Oo0o0O00 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 23 - 23: ii1II11I1ii1I + I1i1i1ii % iI1Ii11111iIi % OOooOOo % OoooooooOO
   try :
    if 78 - 78: oO0ooO / ii11ii1ii - iIii1I11I1II1 - i11iIiiIii * IIIII
    o0O0Ooo = Oo0oooO0oO
    if 79 - 79: oooOOOOO . iiIIIII1i1iI / iiIIIII1i1iI - oooOOOOO * ii11ii1ii / ii1II11I1ii1I
   except :
    pass
  o0oOoO00o = i1 ( o0O0Ooo )
  oOOoo00O0O = re . compile ( OO0Oooo0oOO0O ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o in oOOoo00O0O :
   try :
    iI1iiIi1 ( III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o )
    if 49 - 49: oooOOOOO . II111iiii
   except :
    pass
    if 24 - 24: O0 . OoooooooOO - oO0ooO * OoooooooOO
 except :
  pass
  if 12 - 12: O0 + O00OoOoo00 * i1IIi . oO0ooO
  if 71 - 71: iiiI11 - ii1II11I1ii1I - O00o0o0000o0o
  if 28 - 28: iIii1I11I1II1
def iI1iiIi1 ( thumb , name , url ) :
 if 7 - 7: ii1II11I1ii1I % O00OoOoo00 * iI1Ii11111iIi
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( ii1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   iI1iIIIi1i ( name , url , '' , iII11i , II1i1Ii11Ii11 )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 58 - 58: O00OoOoo00 / oOo0oooo00o + II111iiii % IIIII - OoooooooOO
  if 'tvg-logo' in thumb :
   thumb = re . compile ( ii1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 25 - 25: iI1Ii11111iIi % OoooooooOO * ii11ii1ii - i1IIi * II111iiii * iiIIIII1i1iI
   I1iI1I1ii1 ( name , url , 4 , OO0O0ooOOO00 , II1i1Ii11Ii11 )
   if 33 - 33: ii1II11I1ii1I / O0 + O00o0o0000o0o
  else :
   if 75 - 75: O00OoOoo00 % i11iIiiIii + iIii1I11I1II1
   I1iI1I1ii1 ( name , url , 4 , OO0O0ooOOO00 , II1i1Ii11Ii11 )
   if 92 - 92: iI1Ii11111iIi % O0
def I1i11111i1i11 ( name , url , thumb , id , trailer ) :
 if 55 - 55: iIii1I11I1II1 * IIIII
 if 85 - 85: iIii1I11I1II1 . II111iiii
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 54 - 54: I1i1i1ii . OoooooooOO % ii11ii1ii
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( ii1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   iI1iIIIi1i ( name , url , '' , iII11i , II1i1Ii11Ii11 )
 else :
  iii = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
  if 22 - 22: O00o0o0000o0o
  name = '[COLOR %s]' % iii + name + '[/COLOR]'
  if 22 - 22: IIIII * oOo0oooo00o - ii11ii1ii * O0 / i11iIiiIii
  if 'tvg-logo' in thumb :
   thumb = re . compile ( ii1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   iiIiI = IiII1IiiIiI1 . getSetting ( 'selecton' )
   if iiIiI == 'true' :
    if 78 - 78: ii11ii1ii * O0 / oooOOOOO + OoooooooOO + O00o0o0000o0o
    I1iiIiiIiiI ( name , url , 1 , thumb , thumb , id , trailer )
    if 94 - 94: i1IIi
   else :
    if 36 - 36: OOooOOo + ii11ii1ii
    I1iiIiiIiiI ( name , url , 130 , thumb , thumb , id , trailer )
    if 46 - 46: IIIII
  else :
   if 65 - 65: i1IIi . oO0o0ooO0 / oooOOOOO
   if iiIiI == 'true' :
    if 11 - 11: O00OoOoo00 * oooOOOOO / oooOOOOO - O00o0o0000o0o
    I1iiIiiIiiI ( name , url , 1 , thumb , thumb , id , trailer )
    if 68 - 68: OOooOOo % O00OoOoo00 - O00OoOoo00 / OOooOOo + oO0o0ooO0 - ii11ii1ii
   else :
    if 65 - 65: oooOOOOO - i1IIi
    I1iiIiiIiiI ( name , url , 130 , thumb , thumb , id , trailer )
    if 62 - 62: oOo0oooo00o / iiIIIII1i1iI % ii11ii1ii . OoooooooOO / i11iIiiIii / iiiI11
    if 60 - 60: OOooOOo % iiIIIII1i1iI / ii1II11I1ii1I % iiIIIII1i1iI * i11iIiiIii / IIIII
def iIi1I1 ( name , url , thumb , id , trailer , description , fanart ) :
 if 34 - 34: iiiI11 - O00o0o0000o0o
 if 25 - 25: iiIIIII1i1iI % OOooOOo + i11iIiiIii + O0 * OoooooooOO
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 iii = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
 fanart = fanart . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 name = '[COLOR %s]' % iii + name + '[/COLOR]'
 if 64 - 64: i1IIi
 if 'tvg-logo' in thumb :
  thumb = re . compile ( ii1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  iiIiI = IiII1IiiIiI1 . getSetting ( 'selecton' )
  if iiIiI == 'true' :
   if 10 - 10: iiiI11 % O0 / OOooOOo % oOo0oooo00o
   iiII ( name , url , 1 , thumb , fanart , id , trailer , description )
   if 28 - 28: oooOOOOO . OoooooooOO + ii1II11I1ii1I + I1i1i1ii % IIIII
  else :
   if 80 - 80: ii11ii1ii
   iiII ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 86 - 86: oO0o0ooO0 * oOo0oooo00o . iI1Ii11111iIi / ii11ii1ii + iiIIIII1i1iI
 else :
  if 8 - 8: iI1Ii11111iIi
  if iiIiI == 'true' :
   if 16 - 16: ii1II11I1ii1I . oOo0oooo00o
   iiII ( name , url , 1 , thumb , fanart , id , trailer , description )
   if 50 - 50: oooOOOOO * iI1Ii11111iIi + oO0o0ooO0 - i11iIiiIii + ii11ii1ii * oO0o0ooO0
  else :
   if 20 - 20: iiiI11 / ii1II11I1ii1I % iI1Ii11111iIi
   iiII ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 69 - 69: iiiI11 - i1IIi % IIIII . O00o0o0000o0o - O00o0o0000o0o
def o0oO00o ( name , trailer ) :
 if 78 - 78: ii11ii1ii * iiiI11 - OoooooooOO - oO0ooO
 if II1I == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Realstream, Reproduciendo Trailer de: [COLOR green]" + name + "[/COLOR] ,5000)" )
  if 83 - 83: oooOOOOO / O00o0o0000o0o
  Oo00o0OO0O00o = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  i11iI1 = Oo00o0OO0O00o
  i1Ii11ii1I = xbmcgui . ListItem ( name , trailer , path = i11iI1 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , i1Ii11ii1I )
 else :
  Oo00o0OO0O00o = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  i11iI1 = Oo00o0OO0O00o
  i1Ii11ii1I = xbmcgui . ListItem ( name , trailer , path = i11iI1 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , i1Ii11ii1I )
  if 66 - 66: ii11ii1ii / OoooooooOO % iiiI11 / IIIII + OoooooooOO
  if 6 - 6: II111iiii % iiiI11
def I1iiIiIII ( trailer ) :
 if 68 - 68: O0
 if 'https://www.youtube.com' in trailer :
  if 76 - 76: oO0o0ooO0
  try :
   if 99 - 99: ii1II11I1ii1I
   import resolveurl
   if 1 - 1: I1i1i1ii * iI1Ii11111iIi * oO0ooO + ii11ii1ii
   II1iiIIiIii = urlresolver . HostedMediaFile ( Oo00o0OO0O00o )
   Ii1iIi111i1i1 = xbmcgui . DialogProgress ( )
   Ii1iIi111i1i1 . create ( 'Realstream:' , 'Conectando al servidor ... ' )
   Ii1iIi111i1i1 . update ( 20 , 'Por favor, espere ...' )
   xbmc . sleep ( 500 )
   if 90 - 90: iiiI11 % ii11ii1ii - ii11ii1ii . iIii1I11I1II1 / O00o0o0000o0o + oOo0oooo00o
   if not II1iiIIiIii :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    return False
    if 89 - 89: iiIIIII1i1iI
   try :
    if 87 - 87: IIIII % ii11ii1ii
    Ii1iIi111i1i1 . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    IIOO0ooOo0OoOo0 = II1iiIIiIii . resolve ( )
    if not IIOO0ooOo0OoOo0 or not isinstance ( IIOO0ooOo0OoOo0 , basestring ) :
     try : oOo = IIOO0ooOo0OoOo0 . msg
     except : oOo = IIOO0ooOo0OoOo0
     raise Exception ( oOo )
   except Exception as i11iiI1111 :
    try : oOo = str ( i11iiI1111 )
    except : oOo = IIOO0ooOo0OoOo0
    Ii1iIi111i1i1 . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
    Ii1iIi111i1i1 . close ( )
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    if 62 - 62: oO0ooO + oooOOOOO / IIIII * i11iIiiIii
   Ii1iIi111i1i1 . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
   xbmc . sleep ( 500 )
   Ii1iIi111i1i1 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   Ii1iIi111i1i1 . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
   xbmc . sleep ( 500 )
   Ii1iIi111i1i1 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   Ii1iIi111i1i1 . close ( )
   if 37 - 37: IIIII
   o00oo0000 = xbmcgui . ListItem ( path = IIOO0ooOo0OoOo0 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o00oo0000 )
   if 33 - 33: oO0ooO - O0 - oO0ooO
  except :
   pass
   if 94 - 94: O00OoOoo00 * oOo0oooo00o * OoooooooOO / ii1II11I1ii1I . O00OoOoo00 - ii1II11I1ii1I
  else :
   if 13 - 13: O00o0o0000o0o / O00OoOoo00 - oO0ooO / O00o0o0000o0o . i1IIi
   Oo00o0OO0O00o = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
   i11iI1 = Oo00o0OO0O00o
   i1Ii11ii1I = xbmcgui . ListItem ( trailer , path = i11iI1 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , i1Ii11ii1I )
   return
   if 22 - 22: O0 - oOo0oooo00o + iiiI11 . I1i1i1ii * i1IIi
def iiiI1i1111II ( name , url ) :
 if 38 - 38: ii11ii1ii % oO0o0ooO0 - IIIII * iIii1I11I1II1 / O0
 if '[Youtube]' in name :
  if 9 - 9: oOo0oooo00o * ii11ii1ii . oooOOOOO * i11iIiiIii - O0
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  i11iI1 = url
  i1Ii11ii1I = xbmcgui . ListItem ( O0Oooo , path = i11iI1 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , i1Ii11ii1I )
  if 54 - 54: OOooOOo * O00o0o0000o0o + ii1II11I1ii1I % i1IIi - ii1II11I1ii1I + iI1Ii11111iIi
  if 15 - 15: iI1Ii11111iIi * iiIIIII1i1iI + O00o0o0000o0o . oOo0oooo00o % OOooOOo - oooOOOOO
 else :
  if 13 - 13: iI1Ii11111iIi % iI1Ii11111iIi % ii11ii1ii % OOooOOo * i1IIi % oOo0oooo00o
  import urlresolver
  from urlresolver import common
  if 82 - 82: O00OoOoo00 . iI1Ii11111iIi / oooOOOOO + IIIII - oooOOOOO
  II1iiIIiIii = urlresolver . HostedMediaFile ( url )
  if 55 - 55: oooOOOOO % ii11ii1ii % ii1II11I1ii1I
  if not II1iiIIiIii :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 29 - 29: O00OoOoo00 / iIii1I11I1II1 + oO0o0ooO0 % IIIII % oOo0oooo00o
   if 46 - 46: iIii1I11I1II1
  try :
   IIOO0ooOo0OoOo0 = II1iiIIiIii . resolve ( )
   if not IIOO0ooOo0OoOo0 or not isinstance ( IIOO0ooOo0OoOo0 , basestring ) :
    try : oOo = IIOO0ooOo0OoOo0 . msg
    except : oOo = url
    raise Exception ( oOo )
  except Exception as i11iiI1111 :
   try : oOo = str ( i11iiI1111 )
   except : oOo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 70 - 70: i1IIi . oOo0oooo00o
  II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if II1I == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  o00oo0000 = xbmcgui . ListItem ( path = IIOO0ooOo0OoOo0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o00oo0000 )
  if 74 - 74: oOo0oooo00o
  if 58 - 58: iIii1I11I1II1 * oO0ooO * iiiI11 * oooOOOOO . OoooooooOO
 return
 if 6 - 6: oO0o0ooO0 - iiIIIII1i1iI * i11iIiiIii + iI1Ii11111iIi / oooOOOOO % O00o0o0000o0o
def II11IiIIiiI ( name , url ) :
 if 67 - 67: oO0o0ooO0 . II111iiii - I1i1i1ii % OoooooooOO
 import resolveurl
 if 49 - 49: oO0o0ooO0 + O0 . I1i1i1ii * OoooooooOO
 II1iiIIiIii = urlresolver . HostedMediaFile ( url )
 dp = xbmcgui . DialogProgress ( )
 dp . create ( 'Realstream:' , 'Conectando al servidor ... ' )
 dp . update ( 20 , 'Por favor, espere ...' )
 xbmc . sleep ( 500 )
 if 82 - 82: oO0o0ooO0
 if not II1iiIIiIii :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  return False
  if 54 - 54: ii1II11I1ii1I + oOo0oooo00o - iIii1I11I1II1 % oooOOOOO % O00OoOoo00
 try :
  if 19 - 19: oO0o0ooO0 / iIii1I11I1II1 % i1IIi . OoooooooOO
  dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
  xbmc . sleep ( 500 )
  IIOO0ooOo0OoOo0 = II1iiIIiIii . resolve ( )
  if not IIOO0ooOo0OoOo0 or not isinstance ( IIOO0ooOo0OoOo0 , basestring ) :
   try : oOo = IIOO0ooOo0OoOo0 . msg
   except : oOo = IIOO0ooOo0OoOo0
   raise Exception ( oOo )
 except Exception as i11iiI1111 :
  try : oOo = str ( i11iiI1111 )
  except : oOo = IIOO0ooOo0OoOo0
  dp . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
  dp . close ( )
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  if 57 - 57: oooOOOOO . ii11ii1ii - oO0ooO - i11iIiiIii * iiiI11 / ii1II11I1ii1I
 dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
 xbmc . sleep ( 500 )
 dp . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
 xbmc . sleep ( 500 )
 dp . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
 xbmc . sleep ( 500 )
 dp . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
 dp . close ( )
 II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
 if 79 - 79: oO0o0ooO0 + ii1II11I1ii1I % ii11ii1ii * ii1II11I1ii1I
 if 21 - 21: IIIII
 if '[Realstream]' or '[Mybox]' in name :
  restante = IiII1IiiIiI1 . getSetting ( 'restante' )
 elif restante == 'true' :
  dialog = xbmcgui . Dialog ( )
  ok = dialog . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
 o00oo0000 = xbmcgui . ListItem ( path = IIOO0ooOo0OoOo0 )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o00oo0000 )
 if 24 - 24: IIIII / oooOOOOO
def II11IiIIiiI ( name , url ) :
 if 61 - 61: iIii1I11I1II1 + iiIIIII1i1iI
 if 8 - 8: iiiI11 + oO0ooO
 if 'https://www.rapidvideo.com/v/' in url :
  if 9 - 9: O00o0o0000o0o + ii1II11I1ii1I
  o0oOoO00o = i1 ( url )
  oOOoo00O0O = re . compile ( 'rapidvideo' ) . findall ( o0oOoO00o )
  for url in oOOoo00O0O :
   if 8 - 8: O00o0o0000o0o * ii11ii1ii / IIIII - oO0ooO - OoooooooOO
   if 100 - 100: iiIIIII1i1iI . iIii1I11I1II1 . iIii1I11I1II1
   try :
    II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
    if II1I == 'true' :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    o00oo0000 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o00oo0000 )
    if 55 - 55: iiIIIII1i1iI
   except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 37 - 37: O00OoOoo00 / i11iIiiIii / ii11ii1ii
   if 97 - 97: iiiI11 . oOo0oooo00o / OOooOOo
 else :
  if 83 - 83: oOo0oooo00o - oO0o0ooO0 * iiIIIII1i1iI
  import urlresolver
  from urlresolver import common
  if 90 - 90: ii11ii1ii * OOooOOo
  II1iiIIiIii = urlresolver . HostedMediaFile ( url )
  if 75 - 75: oO0o0ooO0 - iI1Ii11111iIi * i11iIiiIii . OoooooooOO - ii11ii1ii . oOo0oooo00o
  if not II1iiIIiIii :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 6 - 6: oOo0oooo00o * iiIIIII1i1iI / OoooooooOO % I1i1i1ii * ii1II11I1ii1I
   if 28 - 28: O00OoOoo00 * OOooOOo % O00OoOoo00
  try :
   IIOO0ooOo0OoOo0 = II1iiIIiIii . resolve ( )
   if not IIOO0ooOo0OoOo0 or not isinstance ( IIOO0ooOo0OoOo0 , basestring ) :
    try : oOo = IIOO0ooOo0OoOo0 . msg
    except : oOo = url
    raise Exception ( oOo )
  except Exception as i11iiI1111 :
   try : oOo = str ( i11iiI1111 )
   except : oOo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 95 - 95: O0 / oOo0oooo00o . iiiI11
  II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if II1I == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  o00oo0000 = xbmcgui . ListItem ( path = IIOO0ooOo0OoOo0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o00oo0000 )
  if 17 - 17: oOo0oooo00o
 return
 if 56 - 56: oooOOOOO * ii1II11I1ii1I + oOo0oooo00o
 if 48 - 48: O00OoOoo00 * oO0ooO % iiiI11 - oOo0oooo00o
 if 72 - 72: i1IIi % oooOOOOO % O00OoOoo00 % iiIIIII1i1iI - iiIIIII1i1iI
def OOoo0O0OOOo0 ( name , url ) :
 if 25 - 25: iIii1I11I1II1 % II111iiii / oOo0oooo00o / oO0o0ooO0
 IIOO0ooOo0OoOo0 = url
 II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
 if II1I == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  o00oo0000 = xbmcgui . ListItem ( path = IIOO0ooOo0OoOo0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o00oo0000 )
 else :
  o00oo0000 = xbmcgui . ListItem ( path = IIOO0ooOo0OoOo0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o00oo0000 )
 return
 if 22 - 22: iiIIIII1i1iI * IIIII
def iIIIiIi1i ( name , url ) :
 if 36 - 36: iI1Ii11111iIi
 if 9 - 9: iIii1I11I1II1 . OoooooooOO + i1IIi - ii11ii1ii
 if '[Youtube]' in name :
  if 30 - 30: IIIII / oO0ooO . IIIII
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 17 - 17: ii11ii1ii + OoooooooOO * OoooooooOO
  try :
   II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if II1I == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    o00oo0000 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o00oo0000 )
    if 5 - 5: iiiI11 % OoooooooOO . iI1Ii11111iIi
    if 67 - 67: oO0o0ooO0 + I1i1i1ii
    if 72 - 72: O00OoOoo00 % ii1II11I1ii1I
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 93 - 93: iIii1I11I1II1 + i11iIiiIii . ii1II11I1ii1I . i1IIi % OOooOOo % oooOOOOO
  if 74 - 74: iI1Ii11111iIi / i1IIi % OoooooooOO
 else :
  if 52 - 52: O00OoOoo00 % oooOOOOO
  import xbmcgui
  import urlresolver
  from urlresolver import common
  if 25 - 25: oOo0oooo00o / oOo0oooo00o % OoooooooOO - oO0o0ooO0 * iiIIIII1i1iI
  II1iiIIiIii = urlresolver . HostedMediaFile ( url )
  if 23 - 23: i11iIiiIii
  if not II1iiIIiIii :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 100 - 100: iiIIIII1i1iI + O0 . OOooOOo + i1IIi - iI1Ii11111iIi + ii1II11I1ii1I
  import resolveurl as urlresolver
  if 65 - 65: II111iiii / ii11ii1ii
  II1iiIIiIii = urlresolver . HostedMediaFile ( url )
  if 42 - 42: i11iIiiIii . O0
  if 75 - 75: iiiI11 + iIii1I11I1II1
  if not II1iiIIiIii :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 19 - 19: OOooOOo + i11iIiiIii . O00OoOoo00 - oOo0oooo00o / I1i1i1ii + ii1II11I1ii1I
  try :
   IIOO0ooOo0OoOo0 = II1iiIIiIii . resolve ( )
   if not IIOO0ooOo0OoOo0 or not isinstance ( IIOO0ooOo0OoOo0 , basestring ) :
    try : oOo = IIOO0ooOo0OoOo0 . msg
    except : oOo = url
    raise Exception ( oOo )
  except Exception as i11iiI1111 :
   try : oOo = str ( i11iiI1111 )
   except : oOo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 38 - 38: ii11ii1ii / iIii1I11I1II1 * iIii1I11I1II1 % oO0o0ooO0
   if 92 - 92: oOo0oooo00o / O0 * OOooOOo - oOo0oooo00o
   if 99 - 99: i11iIiiIii % OoooooooOO
  II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if II1I == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 56 - 56: O00OoOoo00 * iiiI11
   if '[Realstream]' in name :
    if 98 - 98: oOo0oooo00o + O0 * iiiI11 + i11iIiiIii - O00o0o0000o0o - iIii1I11I1II1
    IIII = IiII1IiiIiI1 . getSetting ( 'restante' )
    if IIII == 'true' :
     OO00O0oOO = xbmcgui . Dialog ( )
     o00o = OO00O0oOO . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 5 - 5: O00o0o0000o0o % ii11ii1ii % O00OoOoo00 % oooOOOOO
   o00oo0000 = xbmcgui . ListItem ( path = IIOO0ooOo0OoOo0 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o00oo0000 )
   if 17 - 17: I1i1i1ii + II111iiii + OoooooooOO / O00o0o0000o0o / O00OoOoo00
   if 80 - 80: ii1II11I1ii1I % i1IIi / oOo0oooo00o
   if 56 - 56: i1IIi . i11iIiiIii
 return
 if 15 - 15: II111iiii * iiIIIII1i1iI % IIIII / i11iIiiIii - iiIIIII1i1iI + ii11ii1ii
 if 9 - 9: oOo0oooo00o - iiIIIII1i1iI + O0 / IIIII % i1IIi
 if 97 - 97: ii1II11I1ii1I * oooOOOOO
def O0OOO0ooO00o ( name , url ) :
 if 24 - 24: iiiI11 + OoooooooOO . O00OoOoo00 / iI1Ii11111iIi / oOo0oooo00o
 if 65 - 65: OoooooooOO
 if '[Youtube]' in name :
  if 18 - 18: O0 - i1IIi . iiiI11
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 98 - 98: ii1II11I1ii1I
  try :
   II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if II1I == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    o00oo0000 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o00oo0000 )
    if 73 - 73: ii11ii1ii - IIIII . iiIIIII1i1iI % i1IIi . O0
    if 15 - 15: oooOOOOO . iIii1I11I1II1 * OOooOOo % oOo0oooo00o
    if 21 - 21: oO0ooO - OOooOOo . OoooooooOO
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 6 - 6: iIii1I11I1II1 - iIii1I11I1II1 % ii1II11I1ii1I / iIii1I11I1II1 * iiiI11
 else :
  if 3 - 3: O00o0o0000o0o . O00OoOoo00 / ii11ii1ii
  import resolveurl
  if 89 - 89: OoooooooOO . iIii1I11I1II1 . ii11ii1ii * iIii1I11I1II1 - iiiI11
  II1iiIIiIii = urlresolver . HostedMediaFile ( url )
  if 92 - 92: OoooooooOO - oO0o0ooO0 - OoooooooOO % OOooOOo % OOooOOo % iIii1I11I1II1
  if 92 - 92: IIIII * O0 % iiiI11 . iIii1I11I1II1
  if not II1iiIIiIii :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 66 - 66: oOo0oooo00o + I1i1i1ii
  try :
   IIOO0ooOo0OoOo0 = II1iiIIiIii . resolve ( )
   if not IIOO0ooOo0OoOo0 or not isinstance ( IIOO0ooOo0OoOo0 , basestring ) :
    try : oOo = IIOO0ooOo0OoOo0 . msg
    except : oOo = url
    raise Exception ( oOo )
  except Exception as i11iiI1111 :
   try : oOo = str ( i11iiI1111 )
   except : oOo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 48 - 48: oO0o0ooO0
   if 96 - 96: oooOOOOO . OoooooooOO
   if 39 - 39: O00o0o0000o0o + oO0ooO
  II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if II1I == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 80 - 80: O00o0o0000o0o % oO0ooO / iI1Ii11111iIi
   if '[Realstream]' in name :
    if 54 - 54: ii11ii1ii % oO0ooO - O00o0o0000o0o - oOo0oooo00o
    IIII = IiII1IiiIiI1 . getSetting ( 'restante' )
    if IIII == 'true' :
     OO00O0oOO = xbmcgui . Dialog ( )
     o00o = OO00O0oOO . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 71 - 71: oooOOOOO . i11iIiiIii
   o00oo0000 = xbmcgui . ListItem ( path = IIOO0ooOo0OoOo0 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o00oo0000 )
   if 56 - 56: O0 * IIIII + IIIII * iIii1I11I1II1 / oooOOOOO * iiiI11
   if 25 - 25: iIii1I11I1II1 . oOo0oooo00o * i11iIiiIii + ii11ii1ii * oOo0oooo00o
   if 67 - 67: IIIII
 return
 if 88 - 88: ii11ii1ii
def i1ii111i ( name , url ) :
 if 42 - 42: O00o0o0000o0o % OoooooooOO / O00OoOoo00
 if 4 - 4: i11iIiiIii - O00o0o0000o0o % oO0o0ooO0 * iiiI11 % ii1II11I1ii1I
 if '[Youtube]' in name :
  if 71 - 71: oooOOOOO . oooOOOOO - iIii1I11I1II1
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 22 - 22: OoooooooOO / oO0o0ooO0 % IIIII * iI1Ii11111iIi
  try :
   II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if II1I == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    o00oo0000 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o00oo0000 )
    if 32 - 32: OoooooooOO % iiIIIII1i1iI % iIii1I11I1II1 / O0
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 61 - 61: II111iiii . O0 - I1i1i1ii - oO0o0ooO0 / i11iIiiIii - II111iiii
 else :
  if 98 - 98: I1i1i1ii - OOooOOo . i11iIiiIii * ii11ii1ii
  if 'https://team.com' in url :
   if 29 - 29: I1i1i1ii / oooOOOOO % oOo0oooo00o
   url = url . replace ( 'https://team.com' , 'https://verystream.com' )
   if 10 - 10: iIii1I11I1II1 % OoooooooOO % oO0o0ooO0
  if 'https://mybox.com' in url :
   if 39 - 39: II111iiii * iI1Ii11111iIi . O0 * oOo0oooo00o
   url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
   if 89 - 89: I1i1i1ii - oooOOOOO . oOo0oooo00o - iiiI11 - OOooOOo
  if 'https://drive.com' in url :
   if 79 - 79: O00OoOoo00 + O00OoOoo00 + I1i1i1ii
   url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
   if 39 - 39: O0 - OoooooooOO
  if 'https://vid.co' in url :
   if 63 - 63: iIii1I11I1II1 % ii1II11I1ii1I * oooOOOOO
   url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
   if 79 - 79: O0
  if 'https://limited.to' in url :
   if 32 - 32: II111iiii . O0 + I1i1i1ii / iI1Ii11111iIi / O00OoOoo00 / O00o0o0000o0o
   url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
   if 15 - 15: oO0o0ooO0
  import resolveurl
  if 4 - 4: O00OoOoo00 + iIii1I11I1II1 * IIIII + ii11ii1ii * ii1II11I1ii1I % II111iiii
  II1iiIIiIii = urlresolver . HostedMediaFile ( url )
  if 88 - 88: iiIIIII1i1iI - i1IIi % i11iIiiIii % II111iiii * OoooooooOO
  if 40 - 40: ii11ii1ii
  if not II1iiIIiIii :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no encontrado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 47 - 47: iI1Ii11111iIi
  try :
   IIOO0ooOo0OoOo0 = II1iiIIiIii . resolve ( )
   if not IIOO0ooOo0OoOo0 or not isinstance ( IIOO0ooOo0OoOo0 , basestring ) :
    try : oOo = IIOO0ooOo0OoOo0 . msg
    except : oOo = url
    raise Exception ( oOo )
  except Exception as i11iiI1111 :
   try : oOo = str ( i11iiI1111 )
   except : oOo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace borrado, o no encontrado. Prueba a reiniciar el router o poner una VPN.[/COLOR]  ,5000)" )
   return False
   if 65 - 65: O0 + iiiI11 % I1i1i1ii * OOooOOo / oooOOOOO / iI1Ii11111iIi
   if 71 - 71: i11iIiiIii / iI1Ii11111iIi . iiIIIII1i1iI
   if 33 - 33: iiIIIII1i1iI
   II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if II1I == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
    if 39 - 39: oO0ooO + O0 + oooOOOOO * II111iiii % O0 - O0
    if '[Realstream]' or '[Mybox]' in name :
     IIII = IiII1IiiIiI1 . getSetting ( 'restante' )
    elif IIII == 'true' :
     OO00O0oOO = xbmcgui . Dialog ( )
     o00o = OO00O0oOO . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 41 - 41: O00OoOoo00 % ii1II11I1ii1I
  o00oo0000 = xbmcgui . ListItem ( path = IIOO0ooOo0OoOo0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o00oo0000 )
  if 67 - 67: O0 % iiiI11
 return
 if 35 - 35: OOooOOo . iI1Ii11111iIi + OoooooooOO % ii11ii1ii % O00o0o0000o0o
def iIi1Ii1111i ( name , url ) :
 if 16 - 16: O00OoOoo00 . oooOOOOO . oO0ooO
 if 53 - 53: iI1Ii11111iIi
 if '[Youtube]' in name :
  if 84 - 84: oO0ooO
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 97 - 97: i1IIi
  try :
   II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if II1I == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    o00oo0000 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o00oo0000 )
    if 98 - 98: OoooooooOO - OOooOOo + oooOOOOO
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 98 - 98: IIIII . O00OoOoo00 . O00OoOoo00 - O00o0o0000o0o
 else :
  if 65 - 65: ii11ii1ii + ii1II11I1ii1I - I1i1i1ii
  o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
  oo00 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  o00 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  Oo0oO0ooo = IiII1IiiIiI1 . getSetting ( 'key_ext' )
  o0oOoO00o = i1 ( o00 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for i11 in oOOoo00O0O :
   if 12 - 12: OoooooooOO + oO0o0ooO0
   try :
    if 55 - 55: O00o0o0000o0o * II111iiii + iiIIIII1i1iI
    if 93 - 93: IIIII * iiIIIII1i1iI . oO0ooO - I1i1i1ii + O0 * oO0ooO
    o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
    if 59 - 59: II111iiii
    if 43 - 43: ii11ii1ii + OoooooooOO
    if o0oO0 == i11 :
     if 47 - 47: oooOOOOO
     if 92 - 92: oOo0oooo00o % i11iIiiIii % ii11ii1ii
     if 'https://team.com' in url :
      if 23 - 23: II111iiii * IIIII
      url = url . replace ( 'https://team.com' , 'https://verystream.com' )
      if 80 - 80: iiiI11 / i11iIiiIii + OoooooooOO
     if 'https://mybox.com' in url :
      if 38 - 38: oO0o0ooO0 % oooOOOOO + i1IIi * OoooooooOO * iiIIIII1i1iI
      url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
      if 83 - 83: iIii1I11I1II1 - oooOOOOO - iiiI11 / oO0ooO - O0
      if 81 - 81: I1i1i1ii - iiIIIII1i1iI * oO0o0ooO0 / iiiI11
     if 'https://vidcloud.co/' in url :
      if 21 - 21: oO0ooO
      url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
      if 63 - 63: oOo0oooo00o . O0 * oOo0oooo00o + iIii1I11I1II1
     if 'https://gounlimited.to' in url :
      if 46 - 46: i1IIi + II111iiii * i1IIi - I1i1i1ii
      url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
      if 79 - 79: II111iiii - iiIIIII1i1iI * oO0o0ooO0 - iI1Ii11111iIi . oO0o0ooO0
     if 'https://drive.com' in url :
      if 11 - 11: O0 * iI1Ii11111iIi
      url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
      if 37 - 37: iI1Ii11111iIi + O0 . O0 * ii11ii1ii % iiiI11 / IIIII
      if 18 - 18: OoooooooOO
     import resolveurl
     if 57 - 57: oooOOOOO . iI1Ii11111iIi * ii1II11I1ii1I - OoooooooOO
     II1iiIIiIii = urlresolver . HostedMediaFile ( url )
     if 75 - 75: i11iIiiIii / ii1II11I1ii1I . O00OoOoo00 . i1IIi . i1IIi / oOo0oooo00o
     if not II1iiIIiIii :
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
      return False
      if 94 - 94: oooOOOOO + OOooOOo
     try :
      Ii1iIi111i1i1 = xbmcgui . DialogProgress ( )
      Ii1iIi111i1i1 . create ( 'Realstream:' , 'Iniciando ...' )
      Ii1iIi111i1i1 . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
      xbmc . sleep ( 1000 )
      if 56 - 56: iI1Ii11111iIi % ii1II11I1ii1I
      IIOO0ooOo0OoOo0 = II1iiIIiIii . resolve ( )
      if not IIOO0ooOo0OoOo0 or not isinstance ( IIOO0ooOo0OoOo0 , basestring ) :
       if 40 - 40: O00o0o0000o0o / O00OoOoo00
       try : oOo = IIOO0ooOo0OoOo0 . msg
       except : oOo = url
       raise Exception ( oOo )
       if 29 - 29: I1i1i1ii - I1i1i1ii / oooOOOOO
     except Exception as i11iiI1111 :
      try : oOo = str ( i11iiI1111 )
      except : oOo = url
      Ii1iIi111i1i1 . update ( 45 , 'RESOLVEURL:' , 'Reiniciando ... ' )
      xbmc . sleep ( 1000 )
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no disponible.  ,3000)" )
      Ii1iIi111i1i1 . close ( )
      if 49 - 49: oOo0oooo00o + iiIIIII1i1iI % oO0ooO - ii11ii1ii - O0 - OoooooooOO
     Ii1iIi111i1i1 . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
     xbmc . sleep ( 500 )
     Ii1iIi111i1i1 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
     xbmc . sleep ( 1000 )
     Ii1iIi111i1i1 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
     Ii1iIi111i1i1 . close ( )
     II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
     o00oo0000 = xbmcgui . ListItem ( path = IIOO0ooOo0OoOo0 )
     xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o00oo0000 )
     if 4 - 4: II111iiii - iiIIIII1i1iI % ii11ii1ii * i11iIiiIii
     if 18 - 18: ii11ii1ii % O0
    else :
     if 66 - 66: iIii1I11I1II1 % i11iIiiIii / OOooOOo
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold]>El addon esta desactivado.[/COLOR]" )
     return False
     if 47 - 47: oO0o0ooO0 * iiIIIII1i1iI + iIii1I11I1II1 - iiIIIII1i1iI / O00OoOoo00
   except :
    pass
    if 86 - 86: O00OoOoo00
 return
 if 43 - 43: OOooOOo / IIIII / oooOOOOO + iIii1I11I1II1 + OoooooooOO
def iiI111i1 ( ) :
 if 41 - 41: i11iIiiIii * O0 - IIIII . II111iiii % oO0ooO % oO0o0ooO0
 if 32 - 32: O00o0o0000o0o + IIIII + iIii1I11I1II1 * ii11ii1ii
 ooiIii1I1111 = [ ]
 I1i = sys . argv [ 2 ]
 if len ( I1i ) >= 2 :
  IiiiIi1111I = sys . argv [ 2 ]
  iII1i1ii = IiiiIi1111I . replace ( '?' , '' )
  if ( IiiiIi1111I [ len ( IiiiIi1111I ) - 1 ] == '/' ) :
   IiiiIi1111I = IiiiIi1111I [ 0 : len ( IiiiIi1111I ) - 2 ]
  i1I1ii1i = iII1i1ii . split ( '&' )
  ooiIii1I1111 = { }
  for iiiiII11iIi in range ( len ( i1I1ii1i ) ) :
   OO00 = { }
   OO00 = i1I1ii1i [ iiiiII11iIi ] . split ( '=' )
   if ( len ( OO00 ) ) == 2 :
    ooiIii1I1111 [ OO00 [ 0 ] ] = OO00 [ 1 ]
 return ooiIii1I1111
 if 52 - 52: II111iiii / OOooOOo . iiIIIII1i1iI * O00OoOoo00 . oOo0oooo00o
 if 25 - 25: i11iIiiIii / iI1Ii11111iIi - iiiI11 / oO0ooO . ii1II11I1ii1I . ii1II11I1ii1I
def iI1 ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  import urlresolver
  xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
  if 43 - 43: oO0o0ooO0 + ii1II11I1ii1I
def iI1iiiiiii ( ) :
 OO00O0oOO = xbmcgui . Dialog ( )
 list = (
 Oo00oo ,
 oO0oO
 )
 if 71 - 71: iiiI11 / OOooOOo / O0
 Ooo0oo = OO00O0oOO . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=%s]Accede a themoviedb.com[/COLOR]' % oOooOOOoOo ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 19 - 19: i11iIiiIii . OOooOOo + II111iiii / O00o0o0000o0o . oO0o0ooO0 * oooOOOOO
 if Ooo0oo :
  if 59 - 59: iIii1I11I1II1 / oO0o0ooO0 % oooOOOOO
  if Ooo0oo < 0 :
   return
  II1IiiIii = list [ Ooo0oo - 2 ]
  return II1IiiIii ( )
 else :
  II1IiiIii = list [ Ooo0oo ]
  return II1IiiIii ( )
 return
 if 84 - 84: iIii1I11I1II1 / OOooOOo . iI1Ii11111iIi % oOo0oooo00o
def oOO ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 99 - 99: ii11ii1ii + i11iIiiIii
i1Ii1i1IiIIi1 = oOO ( )
if 36 - 36: I1i1i1ii * iiiI11 * iIii1I11I1II1 - oOo0oooo00o % i11iIiiIii
def Oo00oo ( ) :
 if i1Ii1i1IiIIi1 == 'android' :
  Ii1IiII = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  Ii1IiII = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 98 - 98: iIii1I11I1II1 - i1IIi + oooOOOOO % oOo0oooo00o + oooOOOOO / iiIIIII1i1iI
  if 97 - 97: O00OoOoo00 % oooOOOOO + II111iiii - O00OoOoo00 % oO0ooO + oooOOOOO
def oO0oO ( ) :
 if 31 - 31: ii1II11I1ii1I
 main ( )
 if 35 - 35: iI1Ii11111iIi + I1i1i1ii * oooOOOOO / iI1Ii11111iIi
 if 69 - 69: oooOOOOO . O00o0o0000o0o - OOooOOo
 if 29 - 29: i11iIiiIii . oO0o0ooO0 / OOooOOo . O00o0o0000o0o + i11iIiiIii
def i1I1i ( ) :
 OO00O0oOO = xbmcgui . Dialog ( )
 Ii1iI111 = (
 iiIiiII1II1ii ,
 i1iI1iiI
 )
 if 31 - 31: oO0o0ooO0
 Ooo0oo = OO00O0oOO . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 63 - 63: O00OoOoo00 + iIii1I11I1II1 + OOooOOo + iiiI11
 if Ooo0oo :
  if 72 - 72: oO0ooO + i11iIiiIii + oO0o0ooO0
  if Ooo0oo < 0 :
   return
  II1IiiIii = Ii1iI111 [ Ooo0oo - 2 ]
  return II1IiiIii ( )
 else :
  II1IiiIii = Ii1iI111 [ Ooo0oo ]
  return II1IiiIii ( )
 return
 if 96 - 96: iiIIIII1i1iI % i1IIi / ii1II11I1ii1I
def oOO ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 13 - 13: II111iiii - ii11ii1ii % i11iIiiIii + IIIII
i1Ii1i1IiIIi1 = oOO ( )
if 88 - 88: O0 . iiIIIII1i1iI % OOooOOo
def iiIiiII1II1ii ( ) :
 if i1Ii1i1IiIIi1 == 'android' :
  Ii1IiII = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  Ii1IiII = webbrowser . open ( 'https://olpair.com/' )
  if 10 - 10: OOooOOo + O0
  if 75 - 75: O0 % iIii1I11I1II1 / iI1Ii11111iIi % O00o0o0000o0o / O00OoOoo00
def i1iI1iiI ( ) :
 if 31 - 31: i11iIiiIii * iI1Ii11111iIi
 main ( )
 if 69 - 69: i11iIiiIii
 if 61 - 61: O0
def iIiiI111I11 ( name , url , id , trailer ) :
 OO00O0oOO = xbmcgui . Dialog ( )
 Ii1iI111 = (
 OOo0Oo0 ,
 o00O0III ,
 iiiI1Ii1 ,
 iI1iiiiiii ,
 oo0O0OO0Oo
 )
 if 66 - 66: OOooOOo % I1i1i1ii % II111iiii
 Ooo0oo = OO00O0oOO . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % oOooOOOoOo ,

 '[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % oOooOOOoOo ,

 '[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % oOooOOOoOo ,

 '[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % oOooOOOoOo ,

 '[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % oOooOOOoOo ] )
 if 77 - 77: iiiI11 + iiIIIII1i1iI
 if Ooo0oo :
  if 38 - 38: oO0o0ooO0 - I1i1i1ii * ii1II11I1ii1I
  if Ooo0oo < 0 :
   return
  II1IiiIii = Ii1iI111 [ Ooo0oo - 5 ]
  return II1IiiIii ( )
 else :
  II1IiiIii = Ii1iI111 [ Ooo0oo ]
  return II1IiiIii ( )
 return
 if 13 - 13: OOooOOo * iiIIIII1i1iI
 if 41 - 41: O00OoOoo00
 if 16 - 16: iIii1I11I1II1
def OOo0Oo0 ( ) :
 if 94 - 94: oooOOOOO % oOo0oooo00o % i1IIi
 iIi1Ii1111i ( i1Iii11I1i , Oo00o0OO0O00o )
 if 90 - 90: I1i1i1ii * oO0ooO
def o00O0III ( ) :
 if 7 - 7: IIIII . I1i1i1ii . IIIII - iiiI11
 o0oO00o ( i1Iii11I1i , O0Oooo )
 if 33 - 33: oooOOOOO + OoooooooOO - oO0ooO / i1IIi / OoooooooOO
def iiiI1Ii1 ( ) :
 if 82 - 82: oO0o0ooO0 / O00o0o0000o0o - IIIII / ii11ii1ii * oO0ooO
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  o00OIIIIIiiI = id
  if 38 - 38: O0
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % o00OIIIIIiiI )
  if 79 - 79: i1IIi . iiIIIII1i1iI
 if II1I == 'true' :
  if 34 - 34: iiiI11 * II111iiii
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + i1Iii11I1i + "[/COLOR] ,5000)" )
  if 71 - 71: O00OoOoo00
def o00OOo0o ( ) :
 if 48 - 48: i11iIiiIii / II111iiii + I1i1i1ii + ii1II11I1ii1I . iiiI11 % O00o0o0000o0o
 iI1iiiiiii ( )
 if 88 - 88: iiiI11 . iiiI11
def oo0O0OO0Oo ( ) :
 if 71 - 71: oooOOOOO . oO0o0ooO0 * O0 - iiiI11 - II111iiii
 O0O00Ooo ( )
def iI1iIIIi1i ( name , url , mode , iconimage , fanart ) :
 if 5 - 5: ii1II11I1ii1I
 iiiiI11ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 o00o = True
 O0i1i1II1i11 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 O0i1i1II1i11 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 O0i1i1II1i11 . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  iiiiI11ii = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  o00o = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiiiI11ii , listitem = O0i1i1II1i11 , isFolder = True )
  return o00o
 o00o = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiiiI11ii , listitem = O0i1i1II1i11 , isFolder = True )
 return o00o
 if 66 - 66: IIIII / i11iIiiIii * O0
def I1iiIiiIiiI ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 78 - 78: O00OoOoo00 - oOo0oooo00o % O0 - O00o0o0000o0o % oO0ooO
 ii111iI1iIi1 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 43 - 43: oO0ooO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 OoOooO = [ ]
 if 23 - 23: I1i1i1ii * oooOOOOO - oOo0oooo00o . O0 % iIii1I11I1II1
 OoOooO . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 iiiiI11ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 O0i1i1II1i11 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 O0i1i1II1i11 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 O0i1i1II1i11 . setProperty ( 'fanart_image' , fanart )
 O0i1i1II1i11 . setProperty ( 'IsPlayable' , 'true' )
 if 19 - 19: OOooOOo
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  OoOooO . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 66 - 66: iiIIIII1i1iI / iI1Ii11111iIi
  O0i1i1II1i11 . addContextMenuItems ( OoOooO , replaceItems = True )
 o00o = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiiiI11ii , listitem = O0i1i1II1i11 )
 return o00o
 if 13 - 13: II111iiii
 if 55 - 55: ii11ii1ii % i1IIi * oOo0oooo00o
def iiII ( name , url , mode , iconimage , fanart , id , trailer , description ) :
 if 95 - 95: O00o0o0000o0o / II111iiii - ii1II11I1ii1I % iiiI11 . oOo0oooo00o
 ii111iI1iIi1 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 63 - 63: iIii1I11I1II1 / oooOOOOO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 OoOooO = [ ]
 if 24 - 24: ii11ii1ii / iIii1I11I1II1 % O00o0o0000o0o * iI1Ii11111iIi - iIii1I11I1II1
 OoOooO . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 iiiiI11ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 O0i1i1II1i11 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 O0i1i1II1i11 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 O0i1i1II1i11 . setProperty ( 'fanart_image' , fanart )
 O0i1i1II1i11 . setProperty ( 'IsPlayable' , 'true' )
 if 50 - 50: II111iiii
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  OoOooO . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 39 - 39: II111iiii . iI1Ii11111iIi - ii11ii1ii * i1IIi . OoooooooOO
  O0i1i1II1i11 . addContextMenuItems ( OoOooO , replaceItems = True )
 o00o = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiiiI11ii , listitem = O0i1i1II1i11 )
 return o00o
 if 44 - 44: OOooOOo
def I1iI1I1ii1 ( name , url , mode , iconimage , fanart ) :
 if 55 - 55: iiIIIII1i1iI . iiiI11 * iiiI11
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 82 - 82: OOooOOo % oO0ooO % oOo0oooo00o + oOo0oooo00o
 iiiiI11ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 O0i1i1II1i11 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 O0i1i1II1i11 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 O0i1i1II1i11 . setProperty ( 'fanart_image' , fanart )
 O0i1i1II1i11 . setProperty ( 'IsPlayable' , 'true' )
 o00o = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiiiI11ii , listitem = O0i1i1II1i11 )
 return o00o
 if 6 - 6: ii11ii1ii
def O0OOOOoO00oo ( name , url , mode ) :
 if 80 - 80: i1IIi . OOooOOo - iiIIIII1i1iI + O00o0o0000o0o + IIIII % iiIIIII1i1iI
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 13 - 13: II111iiii / iI1Ii11111iIi / iI1Ii11111iIi + oooOOOOO
 iiiiI11ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 O0i1i1II1i11 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = OO0O0ooOOO00 )
 O0i1i1II1i11 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 O0i1i1II1i11 . setProperty ( 'fanart_image' , II1i1Ii11Ii11 )
 O0i1i1II1i11 . setProperty ( 'IsPlayable' , 'true' )
 o00o = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiiiI11ii , listitem = O0i1i1II1i11 )
 return o00o
 if 49 - 49: O0 / II111iiii * OOooOOo - OoooooooOO . II111iiii % O00OoOoo00
def IIi ( name , url , mode , iconimage ) :
 iiiiI11ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 o00o = True
 O0i1i1II1i11 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 o00o = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiiiI11ii , listitem = O0i1i1II1i11 , isFolder = True )
 return o00o
 if 12 - 12: O00o0o0000o0o
def O0Ii11I ( ) :
 if 72 - 72: O0 + ii1II11I1ii1I + OOooOOo / ii11ii1ii
 if 83 - 83: O00OoOoo00 - OOooOOo . I1i1i1ii
 if 34 - 34: iI1Ii11111iIi - iiIIIII1i1iI * OoooooooOO
 OOOO0O00o = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 OOOO0O00o . doModal ( )
 if ( OOOO0O00o . isConfirmed ( ) ) :
  if 5 - 5: i11iIiiIii * IIIII - I1i1i1ii - oO0o0ooO0 - i1IIi + IIIII
  i1II = urllib . quote_plus ( OOOO0O00o . getText ( ) ) . replace ( '+' , ' ' )
  if 4 - 4: oooOOOOO + O0 . i1IIi * oO0o0ooO0 - ii1II11I1ii1I
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 42 - 42: ii1II11I1ii1I * iI1Ii11111iIi . oO0ooO - IIIII / II111iiii
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % i1II )
    if 25 - 25: ii11ii1ii % iI1Ii11111iIi
    if II1I == 'true' :
     if 75 - 75: i1IIi
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + i1Iii11I1i + "[/COLOR] ,10000)" )
     if 74 - 74: ii11ii1ii + iiiI11 - iiIIIII1i1iI - oO0ooO + IIIII - iIii1I11I1II1
   except :
    if 54 - 54: oO0o0ooO0 + II111iiii . OOooOOo / oO0ooO . oooOOOOO
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 58 - 58: O00OoOoo00 % i11iIiiIii * II111iiii . oO0o0ooO0
    if 94 - 94: i11iIiiIii . O00o0o0000o0o + iIii1I11I1II1 * iiiI11 * iiiI11
    if 36 - 36: oOo0oooo00o - O00OoOoo00 . O00OoOoo00
IiiiIi1111I = iiI111i1 ( )
Oo00o0OO0O00o = None
i1Iii11I1i = None
Oo0OOOO0oOoo0 = None
OO0O0ooOOO00 = None
id = None
O0Oooo = None
if 92 - 92: O00OoOoo00 . ii11ii1ii - ii11ii1ii - ii1II11I1ii1I + iiiI11 - O0
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 30 - 30: O00OoOoo00 - IIIII - oO0ooO
try :
 Oo00o0OO0O00o = urllib . unquote_plus ( IiiiIi1111I [ "url" ] )
except :
 pass
try :
 i1Iii11I1i = urllib . unquote_plus ( IiiiIi1111I [ "name" ] )
except :
 pass
try :
 Oo0OOOO0oOoo0 = int ( IiiiIi1111I [ "mode" ] )
except :
 pass
try :
 OO0O0ooOOO00 = urllib . unquote_plus ( IiiiIi1111I [ "iconimage" ] )
except :
 pass
try :
 id = int ( IiiiIi1111I [ "id" ] )
except :
 pass
try :
 O0Oooo = urllib . unquote_plus ( IiiiIi1111I [ "trailer" ] )
except :
 pass
 if 33 - 33: iIii1I11I1II1 / IIIII
 if 74 - 74: ii1II11I1ii1I / iiIIIII1i1iI - II111iiii . II111iiii . O00OoOoo00 + II111iiii
print "Mode: " + str ( Oo0OOOO0oOoo0 )
print "URL: " + str ( Oo00o0OO0O00o )
print "Name: " + str ( i1Iii11I1i )
print "iconimage: " + str ( OO0O0ooOOO00 )
print "id: " + str ( id )
print "trailer: " + str ( O0Oooo )
if 92 - 92: iiiI11 % iIii1I11I1II1 - IIIII / i11iIiiIii % oooOOOOO * ii1II11I1ii1I
if Oo0OOOO0oOoo0 == None or Oo00o0OO0O00o == None or len ( Oo00o0OO0O00o ) < 1 :
 if i1Ii == ii111iI1iIi1 :
  if 80 - 80: IIIII
  if 3 - 3: oO0o0ooO0 * oOo0oooo00o
  iIi1Ii1i1iI ( )
  if 53 - 53: iIii1I11I1II1 / IIIII % oO0ooO + O00OoOoo00 / oooOOOOO
  if 74 - 74: ii11ii1ii
  o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
  oo00 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  o00 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  Oo0oO0ooo = IiII1IiiIiI1 . getSetting ( 'key_ext' )
  o0oOoO00o = i1 ( o00 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for i11 in oOOoo00O0O :
   try :
    if 8 - 8: OOooOOo % II111iiii - ii1II11I1ii1I - oOo0oooo00o % OOooOOo
    if 93 - 93: I1i1i1ii * IIIII / O00o0o0000o0o
    o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
    if 88 - 88: iiIIIII1i1iI
    if 1 - 1: ii11ii1ii
    if o0oO0 == i11 :
     if 95 - 95: OoooooooOO / oOo0oooo00o % OoooooooOO / oooOOOOO * O00OoOoo00
     if 75 - 75: O0
     if 56 - 56: oO0ooO / II111iiii
     O0O00Ooo ( )
     if 39 - 39: iI1Ii11111iIi - OoooooooOO - i1IIi / II111iiii
    else :
     if 49 - 49: ii11ii1ii + O0 + O00OoOoo00 . II111iiii % oooOOOOO
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold]>El addon esta desactivado.[/COLOR]" )
     if 33 - 33: iI1Ii11111iIi . iIii1I11I1II1 / oOo0oooo00o % I1i1i1ii
     if 49 - 49: oO0ooO + II111iiii / O00OoOoo00 - O0 % I1i1i1ii
   except :
    pass
    if 27 - 27: oO0ooO + ii11ii1ii
 else :
  xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red][B]Error, de inicio. ¿Tienes Instalado Realstream?[/B][/COLOR]" )
  if 92 - 92: OOooOOo % IIIII
  if 31 - 31: OoooooooOO - iiIIIII1i1iI / iiiI11
  if 62 - 62: i11iIiiIii - oOo0oooo00o
elif Oo0OOOO0oOoo0 == 1 :
 iIiiI111I11 ( i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo )
elif Oo0OOOO0oOoo0 == 2 :
 oo0O0o00 ( )
elif Oo0OOOO0oOoo0 == 3 :
 ooOoOO ( )
elif Oo0OOOO0oOoo0 == 4 :
 iiiI1i1111II ( i1Iii11I1i , Oo00o0OO0O00o )
elif Oo0OOOO0oOoo0 == 5 :
 IiiIIi ( )
elif Oo0OOOO0oOoo0 == 6 :
 Iiii1iiiIiI1 ( )
elif Oo0OOOO0oOoo0 == 7 :
 I11I1i1iI ( )
elif Oo0OOOO0oOoo0 == 8 :
 OO0iIiiIi11IIi ( )
elif Oo0OOOO0oOoo0 == 9 :
 Ii1Iii11 ( )
elif Oo0OOOO0oOoo0 == 10 :
 II11I ( )
elif Oo0OOOO0oOoo0 == 11 :
 i11Ii1IIi ( )
elif Oo0OOOO0oOoo0 == 12 :
 o0oOOOO0 ( )
elif Oo0OOOO0oOoo0 == 13 :
 i1IiiiiIi1I ( )
elif Oo0OOOO0oOoo0 == 14 :
 oOo0Oo0O0O ( )
elif Oo0OOOO0oOoo0 == 15 :
 OOOoo ( )
elif Oo0OOOO0oOoo0 == 16 :
 I1ii1i ( )
elif Oo0OOOO0oOoo0 == 17 :
 oOooo00000 ( )
elif Oo0OOOO0oOoo0 == 18 :
 o0OO00oo0O ( )
elif Oo0OOOO0oOoo0 == 19 :
 o0O00Oooo ( )
elif Oo0OOOO0oOoo0 == 20 :
 iI111II1ii ( )
elif Oo0OOOO0oOoo0 == 21 :
 I111I1I ( )
elif Oo0OOOO0oOoo0 == 22 :
 ii1IIiII111I ( )
elif Oo0OOOO0oOoo0 == 23 :
 o0OOOOOo0 ( )
elif Oo0OOOO0oOoo0 == 24 :
 I1IiII1I1i1I1 ( )
elif Oo0OOOO0oOoo0 == 25 :
 oooOo ( )
elif Oo0OOOO0oOoo0 == 26 :
 o0000 ( )
elif Oo0OOOO0oOoo0 == 28 :
 O00ooOo ( i1Iii11I1i , Oo00o0OO0O00o )
elif Oo0OOOO0oOoo0 == 29 :
 iiiiiII ( )
elif Oo0OOOO0oOoo0 == 30 :
 OoO ( )
elif Oo0OOOO0oOoo0 == 31 :
 I11i1iIiiIiIi ( )
elif Oo0OOOO0oOoo0 == 98 :
 busqueda_global ( )
elif Oo0OOOO0oOoo0 == 97 :
 i1I1i ( )
elif Oo0OOOO0oOoo0 == 99 :
 iIIi1iI1I1IIi ( )
elif Oo0OOOO0oOoo0 == 100 :
 menu_player ( i1Iii11I1i , Oo00o0OO0O00o )
elif Oo0OOOO0oOoo0 == 111 :
 o0OOOo ( )
elif Oo0OOOO0oOoo0 == 115 :
 o0oO00o ( Oo00o0OO0O00o )
elif Oo0OOOO0oOoo0 == 116 :
 iIiiiii1i ( )
elif Oo0OOOO0oOoo0 == 117 :
 OO0oo ( )
elif Oo0OOOO0oOoo0 == 119 :
 O0o ( )
elif Oo0OOOO0oOoo0 == 120 :
 O0oii111 ( )
elif Oo0OOOO0oOoo0 == 121 :
 ii1i1i1IiII ( )
elif Oo0OOOO0oOoo0 == 125 :
 IIiiIiII11iiiiiii ( )
elif Oo0OOOO0oOoo0 == 112 :
 I1i11ii11 ( )
elif Oo0OOOO0oOoo0 == 127 :
 O0Ii11I ( )
elif Oo0OOOO0oOoo0 == 128 :
 TESTLINKS ( )
elif Oo0OOOO0oOoo0 == 130 :
 iIi1Ii1111i ( i1Iii11I1i , Oo00o0OO0O00o )
elif Oo0OOOO0oOoo0 == 140 :
 I11 ( )
elif Oo0OOOO0oOoo0 == 141 :
 Ii1I1i1ii1I1 ( )
elif Oo0OOOO0oOoo0 == 142 :
 o00Oi1i ( )
elif Oo0OOOO0oOoo0 == 143 :
 i1IiiI1iIi ( i1Iii11I1i , Oo00o0OO0O00o )
elif Oo0OOOO0oOoo0 == 144 :
 O00ooOo ( i1Iii11I1i , Oo00o0OO0O00o )
elif Oo0OOOO0oOoo0 == 145 :
 OOOIII1iI1iII1I ( )
elif Oo0OOOO0oOoo0 == 150 :
 IIiI1I1 ( )
elif Oo0OOOO0oOoo0 == 151 :
 iiIII1II ( )
elif Oo0OOOO0oOoo0 == 152 :
 iIIIII1iiiiII ( )
 if 81 - 81: oOo0oooo00o
xbmcplugin . endOfDirectory ( o0OoOoOO00 ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
