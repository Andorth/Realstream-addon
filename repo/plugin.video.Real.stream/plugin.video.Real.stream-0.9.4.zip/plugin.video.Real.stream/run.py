# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 0.9.4
#
############################################
# Dependencias 
# Script ExtendedInfo
# Script Urlresolver de TVAddons
# Script ResolveURL Por Jsergio.
#
############################################
#
# Ampliado el menu series.
# optimizado el reproductor peliculas y series.
#
############################################
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import urlresolver
import cookielib , base64
import requests
import plugintools
import config
oo000 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
ii = oo000 . getAddonInfo ( 'version' )
oOOo = int ( sys . argv [ 1 ] )
O0 = 'gruponetai/'
o0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
iI11I1II1I1I = o0O . getAddonInfo ( 'profile' )
oooo = o0O . getAddonInfo ( 'path' )
iIIii1IIi = oo000 . getSetting ( 'iconos' )
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if iIIii1IIi == 'true' :
 if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
 O0oOO0o0 = xbmc . translatePath ( os . path . join ( oooo , 'fanart.png' ) )
 i1ii1iIII = xbmc . translatePath ( os . path . join ( oooo , 'icon.png' ) )
 Oo0oO0oo0oO00 = xbmc . translatePath ( os . path . join ( oooo , 'extended_info.png' ) )
 i111I = xbmc . translatePath ( os . path . join ( oooo , 'buscar.png' ) )
 II1Ii1iI1i = xbmc . translatePath ( os . path . join ( oooo , 'pair.png' ) )
 iiI1iIiI = xbmc . translatePath ( os . path . join ( oooo , 'theMovieDB.png' ) )
 OOo = xbmc . translatePath ( os . path . join ( oooo , 'novedades.png' ) )
 Ii1IIii11 = xbmc . translatePath ( os . path . join ( oooo , 'estrenos.png' ) )
 Oooo0000 = xbmc . translatePath ( os . path . join ( oooo , 'recomendadas.png' ) )
 i11 = xbmc . translatePath ( os . path . join ( oooo , 'accion.png' ) )
 I11 = xbmc . translatePath ( os . path . join ( oooo , 'animacion.png' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( oooo , 'aventuras.png' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( oooo , 'belico.png' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( oooo , 'ciencia-ficcion.png' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( oooo , 'clasicos.png' ) )
 oO = xbmc . translatePath ( os . path . join ( oooo , 'comedia.png' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( oooo , 'crimen.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( oooo , 'drama.png' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( oooo , 'familiar.png' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( oooo , 'fantasia.png' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( oooo , 'historia.png' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( oooo , 'marvel.png' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( oooo , 'misterio.png' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( oooo , 'musical.png' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( oooo , 'romance.png' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( oooo , 'spain.png' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( oooo , 'suspense.png' ) )
 II = xbmc . translatePath ( os . path . join ( oooo , 'terror.png' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( oooo , 'thriller.png' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( oooo , 'western.png' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( oooo , 'sagas_cine.png' ) )
 OO0o = xbmc . translatePath ( os . path . join ( oooo , '4k.png' ) )
 Ooo = xbmc . translatePath ( os . path . join ( oooo , 'torrent.png' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( oooo , 'buscar-serie.jpg' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( oooo , 'series-todas.jpg' ) )
 O0O = xbmc . translatePath ( os . path . join ( oooo , 'favorites.png' ) )
 O00o0OO = xbmc . translatePath ( os . path . join ( oooo , 'artesmarciales.png' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( oooo , 'emision.png' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( oooo , 'mejores.png' ) )
 if 71 - 71: oO00OO0oo0 . III1i1i
else :
 if 26 - 26: i1iiI11I
 if 29 - 29: iiIi
 O00o0OO = xbmc . translatePath ( os . path . join ( oooo , 'artesmarciales.png' ) )
 iIIii1IIi = oo000 . getSetting ( 'iconos' )
 O0oOO0o0 = xbmc . translatePath ( os . path . join ( oooo , 'fanart.jpg' ) )
 i1ii1iIII = xbmc . translatePath ( os . path . join ( oooo , 'icon.png' ) )
 Oo0oO0oo0oO00 = xbmc . translatePath ( os . path . join ( oooo , 'extended_info.png' ) )
 i111I = xbmc . translatePath ( os . path . join ( oooo , 'buscar.png' ) )
 II1Ii1iI1i = xbmc . translatePath ( os . path . join ( oooo , 'pair.png' ) )
 iiI1iIiI = xbmc . translatePath ( os . path . join ( oooo , 'theMovieDB.jpg' ) )
 OOo = xbmc . translatePath ( os . path . join ( oooo , 'novedades.jpg' ) )
 Ii1IIii11 = xbmc . translatePath ( os . path . join ( oooo , 'encines.jpg' ) )
 Oooo0000 = xbmc . translatePath ( os . path . join ( oooo , 'recomendadas.jpg' ) )
 i11 = xbmc . translatePath ( os . path . join ( oooo , 'accion.jpg' ) )
 I11 = xbmc . translatePath ( os . path . join ( oooo , 'animacion.jpg' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( oooo , 'aventuras.jpg' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( oooo , 'belico.jpg' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( oooo , 'ciencia-ficcion.jpg' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( oooo , 'clasicos.png' ) )
 oO = xbmc . translatePath ( os . path . join ( oooo , 'comedia.jpg' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( oooo , 'crimen.jpg' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( oooo , 'drama.jpg' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( oooo , 'familiar.jpg' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( oooo , 'fantasia.jpg' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( oooo , 'historia.jpg' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( oooo , 'superheroes.jpg' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( oooo , 'misterio.jpg' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( oooo , 'musical.jpg' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( oooo , 'romance.jpg' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( oooo , 'spain.jpg' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( oooo , 'suspense.jpg' ) )
 II = xbmc . translatePath ( os . path . join ( oooo , 'terror.jpg' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( oooo , 'thriller.jpg' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( oooo , 'western.jpg' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( oooo , 'sagas_cine.jpg' ) )
 OO0o = xbmc . translatePath ( os . path . join ( oooo , '4k.jpg' ) )
 Ooo = xbmc . translatePath ( os . path . join ( oooo , 'torrent.jpg' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( oooo , 'buscar-serie.jpg' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( oooo , 'series-todas.jpg' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( oooo , 'emision.png' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( oooo , 'mejores.png' ) )
 O0O = xbmc . translatePath ( os . path . join ( oooo , 'favoritos.png' ) )
 if 98 - 98: Oo0Ooo % I11i * iII111i * I11i
 if 45 - 45: i1iiI11I . I11i
 if 83 - 83: IiII . Oo0Ooo . iII111i
I1I = xbmc . translatePath ( os . path . join ( oooo , 'peliculas.png' ) )
oOO00oOO = xbmc . translatePath ( os . path . join ( oooo , 'series.png' ) )
OoOo = xbmc . translatePath ( os . path . join ( oooo , 'ajustes.png' ) )
iI = xbmc . translatePath ( os . path . join ( oooo , 'videoteca.png' ) )
o00O = xbmc . translatePath ( os . path . join ( oooo , 'favorites.png' ) )
OOO0OOO00oo = xbmc . translatePath ( os . path . join ( oooo , 'resolver.png' ) )
Iii111II = xbmc . translatePath ( os . path . join ( oooo , 'test.png' ) )
iiii11I = xbmc . translatePath ( os . path . join ( oooo , 'video-tutoriales.png' ) )
Ooo0OO0oOO = xbmc . translatePath ( os . path . join ( oooo , 'proxy.png' ) )
if 50 - 50: I1ii11iIi11i
Ii1i11IIii1I = oo000 . getSetting ( 'mostrar_cat' )
OOOoO0O0o = oo000 . getSetting ( 'videos' )
O0o0Ooo = oo000 . getSetting ( 'activar' )
O00 = oo000 . getSetting ( 'favcopy' )
iI1Ii11iII1 = oo000 . getSetting ( 'anticopia' )
Oo0O0O0ooO0O = oo000 . getSetting ( 'licencia_addon' )
IIIIii = oo000 . getSetting ( 'notificar' )
O0o0 = oo000 . getSetting ( 'mostrar_bus' )
OO00Oo = oo000 . getSetting ( 'restante' )
O0OOO0OOoO0O = oo000 . getSetting ( 'selecton' )
O00Oo000ooO0 = oo000 . getSetting ( 'aviso' )
OoO0O00IIiII = oo000 . getSetting ( 'RealStream_Settings' )
o0 = oo000 . getSetting ( 'Resolver_Settings' )
OO00Oo = oo000 . getSetting ( 'restante' )
ooOooo000oOO = oo000 . getSetting ( 'fav' )
Oo0oOOo = oo000 . getSetting ( 'Fontcolor' )
Oo0OoO00oOO0o = oo000 . getSetting ( 'MenuColor' )
OOO00O = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
OOoOO0oo0ooO = 'bienvenida'
O0o0O00Oo0o0 = 'bienvenida'
copyright = oo000 . getSetting ( 'copyright' )
O00O0oOO00O00 = 'cGx1Z2luLnZpZGVvLg==' . decode ( 'base64' ) + copyright
i1 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
Oo00 = oo000 . getSetting ( 'Forceupdate' )
if Oo00 == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
i1i = 'LnR4dA==' . decode ( 'base64' )
if 50 - 50: III1i1i
i11I1iIiII = 'aHR0cDovL2JpdC5seS8yU1FOSnlP' . decode ( 'base64' )
oO00o0 = OOO00O + OOoOO0oo0ooO + i1i
OOoo0O = 'http://www.youtube.com'
Oo0ooOo0o = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
Ii1i1 = '.xsl.pt'
iiIii = 'L21hc3Rlci8=' . decode ( 'base64' )
ooo0O = Oo0ooOo0o + Ii1i1
oOoO0o00OO0 = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*texto3=[\'"](.*?)[\'"]\s*'
i1I1ii = 'tvg-logo=[\'"](.*?)[\'"]'
if 61 - 61: o0oOOo0O0Ooo
O0OOO = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)'
II11iIiIIIiI = '(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)'
o0o = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
o00 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
OooOO000 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
OOoOoo = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
oO0000OOo00 = '#(.+?),(.+)\s*(.+)'
iiIi1IIiIi = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
if 75 - 75: I1ii11iIi11i + oO0o
OoooO0oO = 'source src=[\'"](.*?)[\'"]\s*title=[\'"](.*?)[\'"]'
i1iIi = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
ooOOoooooo = '[\'"](.*?)[\'"]'
II1I = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
O0i1II1Iiii1I11 = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( 'base64' )
IIII = O0i1II1Iiii1I11 + O0
iiIiI = '[\'"](.*?)[\'"]'
o00oooO0Oo = 'UmVhbHN0cmVhbQ==' . decode ( 'base64' )
o0O0OOO0Ooo = 'video=[\'"](.*?)[\'"]'
iiIiII1 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
OOO00O0O = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( 'base64' ) + iiIiII1
iii = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
oOooOOOoOo = '0110R0N' . replace ( '0110R0N' , 'R0N' )
i1Iii1i1I = 'aHR0cDovL2JpdC5seS8yWEIx' . decode ( 'base64' ) + oOooOOOoOo
OOoO00 = '0110pEJ' . replace ( '0110pEJ' , 'pEJ' )
IiI111111IIII = 'aHR0cDovL2JpdC5seS8yd1Nh' . decode ( 'base64' ) + OOoO00
i1Ii = 'ABBAOb5' . replace ( 'ABBAOb5' , 'Ob5' )
ii111iI1iIi1 = 'aHR0cDovL2JpdC5seS8yRVhV' . decode ( 'base64' ) + i1Ii
OOO = '0110jaw' . replace ( '0110jaw' , 'jaw' )
oo0OOo0 = 'aHR0cDovL2JpdC5seS8yd01M' . decode ( 'base64' ) + OOO
I11IiI = '01109DI' . replace ( '01109DI' , '9DI' )
O0ooO0Oo00o = 'aHR0cDovL2JpdC5seS8ySXgz' . decode ( 'base64' ) + I11IiI
ooO0oOOooOo0 = '01103hs' . replace ( '01103hs' , '3hs' )
i1I1ii11i1Iii = 'aHR0cDovL2JpdC5seS8zMW1U' . decode ( 'base64' ) + ooO0oOOooOo0
I1IiiiiI = '01107DW' . replace ( '01107DW' , '7DW' )
o0OIiII = 'aHR0cDovL2JpdC5seS8yV1ln' . decode ( 'base64' ) + I1IiiiiI
ii1iII1II = '0110mLl' . replace ( '0110mLl' , 'mLl' )
Iii1I1I11iiI1 = 'aHR0cDovL2JpdC5seS8yS0cw' . decode ( 'base64' ) + ii1iII1II
I1I1i1I = '01102Hj' . replace ( '01102Hj' , '2Hj' )
ii1I = 'aHR0cDovL2JpdC5seS8yWEJo' . decode ( 'base64' ) + I1I1i1I
O0oO0 = '0110fXg' . replace ( '0110fXg' , 'fXg' )
oO0 = 'aHR0cDovL2JpdC5seS8ySTVy' . decode ( 'base64' ) + O0oO0
O0OO0O = '0110NMH' . replace ( '0110NMH' , 'NMH' )
OO = 'aHR0cDovL2JpdC5seS8yd0t6' . decode ( 'base64' ) + O0OO0O
OoOoO = '0110bwQ' . replace ( '0110bwQ' , 'bwQ' )
Ii1I1i = 'aHR0cDovL2JpdC5seS8yd01V' . decode ( 'base64' ) + OoOoO
OOI1iI1ii1II = '0110xzG' . replace ( '0110xzG' , 'xzG' )
O0O0OOOOoo = 'aHR0cDovL2JpdC5seS8yWHhz' . decode ( 'base64' ) + OOI1iI1ii1II
oOooO0 = '0110x64' . replace ( '0110x64' , 'x64' )
Ii1I1Ii = 'aHR0cDovL2JpdC5seS8yRVlF' . decode ( 'base64' ) + oOooO0
OOoO0 = '0110vUE' . replace ( '0110vUE' , 'vUE' )
OO0Oooo0oOO0O = 'aHR0cDovL2JpdC5seS8yWmhW' . decode ( 'base64' ) + OOoO0
o00O0 = '01107ZL' . replace ( '01107ZL' , '7ZL' )
oOO0O00Oo0O0o = 'aHR0cDovL2JpdC5seS8yWm4w' . decode ( 'base64' ) + o00O0
ii1 = '01106cf' . replace ( '01106cf' , '6cf' )
I1iIIiiIIi1i = 'aHR0cDovL2JpdC5seS8yRVlk' . decode ( 'base64' ) + ii1
O0O0ooOOO = '0110Jtp' . replace ( '0110Jtp' , 'Jtp' )
oOOo0O00o = 'aHR0cDovL2JpdC5seS8yV3Nq' . decode ( 'base64' ) + O0O0ooOOO
iIiIi11 = '0110a5b' . replace ( '0110a5b' , 'a5b' )
OOOiiiiI = 'aHR0cDovL2JpdC5seS8yV3dj' . decode ( 'base64' ) + iIiIi11
oooOo0OOOoo0 = '0110Q7u' . replace ( '0110Q7u' , 'Q7u' )
OOoO = 'aHR0cDovL2JpdC5seS8yV3NL' . decode ( 'base64' ) + oooOo0OOOoo0
OO0O000 = '0110rsq' . replace ( '0110rsq' , 'rsq' )
iiIiI1i1 = 'aHR0cDovL2JpdC5seS8ySzhE' . decode ( 'base64' ) + OO0O000
oO0O00oOOoooO = '0110DDR' . replace ( '0110DDR' , 'DDR' )
IiIi11iI = 'aHR0cDovL2JpdC5seS8ySzd5' . decode ( 'base64' ) + oO0O00oOOoooO
Oo0O00O000 = '0110feQ' . replace ( '0110feQ' , 'feQ' )
i11I1IiII1i1i = 'aHR0cDovL2JpdC5seS8yS0cz' . decode ( 'base64' ) + Oo0O00O000
oo = '0110MHY' . replace ( '0110MHY' , 'MHY' )
I1111i = 'aHR0cDovL2JpdC5seS8ySXVo' . decode ( 'base64' ) + oo
iIIii = '0110xdb' . replace ( '0110xdb' , 'xdb' )
o00O0O = 'aHR0cDovL2JpdC5seS8yWEJu' . decode ( 'base64' ) + iIIii
ii1iii1i = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( 'base64' )
O00O0oOO00O00 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
Iii1I1111ii = '0110lxu' . replace ( '0110lxu' , 'lxu' )
ooOoO00 = 'aHR0cDovL2JpdC5seS8yV1Bj' . decode ( 'base64' ) + Iii1I1111ii
Ii1IIiI1i = '0110pzp' . replace ( '0110pzp' , 'pzp' )
o0O00Oo0 = 'aHR0cDovL2JpdC5seS8yVHpB' . decode ( 'base64' ) + Ii1IIiI1i
IiII111i1i11 = '01105yt' . replace ( '01105yt' , '5yt' )
i111iIi1i1II1 = 'aHR0cDovL2JpdC5seS8yTVpp' . decode ( 'base64' ) + IiII111i1i11
if 86 - 86: Oo0Ooo / I11i . o0oOOo0O0Ooo
II1i111Ii1i = '1001DTs' . replace ( '1001DTs' , 'DTs' )
iii1 = 'aHR0cDovL2JpdC5seS8ySzhP' . decode ( 'base64' ) + II1i111Ii1i
ooO0oooOO0 = '1001Hky' . replace ( '1001Hky' , 'Hky' )
o0ooo0 = 'aHR0cDovL2JpdC5seS8yTGVL' . decode ( 'base64' ) + ooO0oooOO0
oOOOoo00 = '1001VFU' . replace ( '1001VFU' , 'VFU' )
iiIiIIIiiI = 'aHR0cDovL2JpdC5seS8zMERx' . decode ( 'base64' ) + oOOOoo00
if 12 - 12: I1IiiI - Ii1I
def oOoO00O0 ( ) :
 if 75 - 75: I1ii11iIi11i . iiIi . I1IiiI * i1iiI11I
 if 4 - 4: o00O0oo % IiII * OOooOOo
 try :
  if 100 - 100: i1iiI11I * I1Ii111 + I1Ii111
  OoOO0o = i1II1 ( i1Iii1i1I )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   try :
    if 87 - 87: Ii1I
    IiI111111IIII = IiiiiI1i1Iii
    if 29 - 29: I1ii11iIi11i % I1Ii111 - I1ii11iIi11i / I1Ii111 . OoOoOO00
    i11III1111iIi = xbmc . Keyboard ( '' , 'Busqueda por titulo' )
    i11III1111iIi . doModal ( )
    if ( i11III1111iIi . isConfirmed ( ) ) :
     if 38 - 38: oO00OO0oo0 + ooOoO0o / i1iiI11I % iiIi - iII111i
     iI11 = urllib . quote_plus ( i11III1111iIi . getText ( ) ) . replace ( '+' , ' ' )
     Ii1Io0OO0o0o00o = i1II1 ( IiI111111IIII )
     i11i1 = re . compile ( O0OOO ) . findall ( Ii1Io0OO0o0o00o )
     if 100 - 100: IiII / i1iiI11I / iII111i
     for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
      if re . search ( iI11 , o0OO0o0oOOO0O ( OOOooo . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
       if 81 - 81: I1IiiI . OoO0O00 . oO00OO0oo0 - oO0o / OOooOOo + iII111i
   except :
    pass
 except :
  pass
def o0O00oOOoo ( ) :
 if 18 - 18: o00O0oo + III1i1i - I1IiiI
 if 53 - 53: OoOoOO00
 Ooo00Oo = i1II1 ( ii1iii1i )
 i11i1 = re . compile ( ooOOoooooo ) . findall ( Ooo00Oo )
 for oO00Oooo0O0o0 in i11i1 :
  try :
   if 14 - 14: Ii1I % I1IiiI * oO00OO0oo0 + o00O0oo + oO0o * o00O0oo
   import xbmc
   import xbmcaddon
   if 3 - 3: I11i * oO0o
   __addon__ = xbmcaddon . Addon ( )
   __addonname__ = __addon__ . getAddonInfo ( 'name' )
   __icon__ = __addon__ . getAddonInfo ( 'icon' )
   if 95 - 95: I1Ii111 % IiII . o00O0oo
   ii = oo000 . getAddonInfo ( 'version' )
   if 72 - 72: OoO0O00
   OooooOoooO = "[COLOR gold]Version instalada: " + ii + " [/COLOR]" "[COLOR lime]Ultima Version: " + oO00Oooo0O0o0 + "  [/COLOR]"
   oOIIiIi = 3000
   if 91 - 91: iII111i * oO0o / I1ii11iIi11i . I1IiiI + OOooOOo + I11i
   xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , OooooOoooO , oOIIiIi , __icon__ ) )
   if 8 - 8: IiII / iII111i
   if 20 - 20: I1ii11iIi11i
  except :
   pass
   if 95 - 95: oO00OO0oo0 - I1ii11iIi11i
   if 34 - 34: iiIi * I1ii11iIi11i . OoOoOO00 * iiIi / iiIi
def IIiI1Ii ( ) :
 if 57 - 57: I1Ii111 - iiIi - ooOoO0o + OOooOOo
 O00Oo000ooO0 = oo000 . getSetting ( 'aviso' )
 if O00Oo000ooO0 == 'true' :
  OoOO0o = i1II1 ( oO00o0 )
  i11i1 = re . compile ( oOoO0o00OO0 ) . findall ( OoOO0o )
  for I1IIIiI11i1 , i11I1I1I , oOOOo00O00O in i11i1 :
   try :
    if 2 - 2: Ii1I - iII111i
    if 58 - 58: o00O0oo + Ii1I - I1ii11iIi11i
    i1i1ii = I1IIIiI11i1
    iII1ii1 = i11I1I1I
    I1i1iiiI1 = oOOOo00O00O
    if 24 - 24: IiII / II111iiii + IiII
    if 20 - 20: ooOoO0o + o00O0oo / I1IiiI % Oo0Ooo
    OooooOoooO = "[B]" + i1i1ii + "[/B]"
    oOo0O = "" + iII1ii1 + ""
    OOO0O00oO = "" + I1i1iiiI1 + ""
    if 9 - 9: Oo0Ooo
    xbmcgui . Dialog ( ) . ok ( "Real Stream" , OooooOoooO , oOo0O , OOO0O00oO )
    if 31 - 31: Ii1I % OOooOOo
   except :
    pass
    if 14 - 14: IiII / IiII % iiIi
    if 56 - 56: I1ii11iIi11i . I1IiiI + oO0o
 if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
  if 1 - 1: oO00OO0oo0
  if 97 - 97: I1Ii111 + oO00OO0oo0 + I1IiiI + II111iiii
  if 77 - 77: Ii1I / OoO0O00
def o0OO0o0oOOO0O ( s ) :
 if 46 - 46: Ii1I % Oo0Ooo . oO00OO0oo0 % oO00OO0oo0 + II111iiii
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 72 - 72: Oo0Ooo * o00O0oo % iiIi / OOooOOo
def I11i1II ( file ) :
 if 72 - 72: Oo0Ooo . OoOoOO00 / oO0o . o0oOOo0O0Ooo
 try :
  ooo000o000 = open ( file , 'r' )
  OoOO0o = ooo000o000 . read ( )
  ooo000o000 . close ( )
  return OoOO0o
 except :
  pass
  if 100 - 100: III1i1i . ooOoO0o / o00O0oo % I11i % o0oOOo0O0Ooo - OOooOOo
def i1II1 ( url ) :
 if 46 - 46: I1IiiI * o0oOOo0O0Ooo - oO0o * iiIi
 try :
  i11IIIiIiIi = urllib2 . Request ( url )
  i11IIIiIiIi . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  IIIII1 = urllib2 . urlopen ( i11IIIiIiIi )
  iIi1Ii1i1iI = IIIII1 . read ( )
  IIIII1 . close ( )
  return iIi1Ii1i1iI
 except urllib2 . URLError , IIiI1 :
  print 'We failed to open "%s".' % url
  if hasattr ( IIiI1 , 'code' ) :
   print 'We failed with error code - %s.' % IIiI1 . code
  if hasattr ( IIiI1 , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , IIiI1 . reason
   if 17 - 17: I1Ii111 / I1Ii111 / ooOoO0o
def ii1I1IiiI1ii1i ( url ) :
 i11IIIiIiIi = urllib2 . Request ( url )
 i11IIIiIiIi . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 i11IIIiIiIi . add_header ( 'Referer' , '%s' % url )
 i11IIIiIiIi . add_header ( 'Connection' , 'keep-alive' )
 IIIII1 = urllib2 . urlopen ( i11IIIiIiIi )
 iIi1Ii1i1iI = IIIII1 . read ( )
 IIIII1 . close ( )
 return iIi1Ii1i1iI
 if 78 - 78: iiIi . Ii1I . I1Ii111 . ooOoO0o + IiII
 if 16 - 16: III1i1i % Oo0Ooo . o00O0oo
def oooooOOO000Oo ( ) :
 if 52 - 52: o0oOOo0O0Ooo % III1i1i . I11i * Oo0Ooo
 Oo0OoO00oOO0o = oo000 . getSetting ( 'MenuColor' )
 if 50 - 50: iiIi - i1iiI11I * III1i1i . iII111i
 if O0o0Ooo == 'true' :
  if 37 - 37: iiIi % II111iiii % o0oOOo0O0Ooo . I1IiiI . o00O0oo
  OO0oOOoo ( '[COLOR %s]Peliculas[/COLOR] ' % Oo0OoO00oOO0o , 'movieDB' , 116 , I1I , O0oOO0o0 )
  OO0oOOoo ( '[COLOR %s]Series[/COLOR] ' % Oo0OoO00oOO0o , 'movieDB' , 117 , oOO00oOO , O0oOO0o0 )
  if 52 - 52: Ii1I % oO0o
  if 64 - 64: I1IiiI % ooOoO0o % I1IiiI * OOooOOo . IiII + I1ii11iIi11i
 if OoO0O00IIiII == 'true' :
  OO0oOOoo ( '[COLOR %s]Ajustes[/COLOR]' % Oo0OoO00oOO0o , 'Settings' , 119 , OoOo , O0oOO0o0 )
  if 75 - 75: ooOoO0o . OoO0O00 % Ii1I * ooOoO0o % OoO0O00
  if 13 - 13: III1i1i / II111iiii % o0oOOo0O0Ooo % ooOoO0o . iII111i
  if Ii1i11IIii1I == 'true' :
   iIIIii ( )
   if 58 - 58: Ii1I / III1i1i . I11i / OoO0O00 + i1iiI11I
  if o0 == 'true' :
   O0OoO0ooOO0o ( )
   OoOo0oOooOoOO ( )
   if 60 - 60: OoO0O00 % o00O0oo * OoOoOO00
  if iI1Ii11iII1 == 'false' :
   if 1 - 1: I1ii11iIi11i / III1i1i * iiIi
   OooooOoooO = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   oOo0O = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Script.ResolveURL para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   OOO0O00oO = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 1 - 1: ooOoO0o * Ii1I . I11i / I1IiiI
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , OooooOoooO , oOo0O , OOO0O00oO )
   if 100 - 100: i1iiI11I . Ii1I * oO0o % I1IiiI * I1IiiI
def IIIii1 ( ) :
 OO0oOOoo ( '[COLOR orange]Buscador por id[/COLOR]' , OOoo0O , 127 , iiI1iIiI , O0oOO0o0 )
 if 71 - 71: o0oOOo0O0Ooo / OoOoOO00 . iII111i % OoO0O00 . I11i
def Iiiiii111i1ii ( ) :
 if 25 - 25: I1Ii111 - iiIi / II111iiii
 Oo0OoO00oOO0o = oo000 . getSetting ( 'MenuColor' )
 OO0oOOoo ( '[COLOR %s]The movie DB[/COLOR]' % Oo0OoO00oOO0o , 'movieDB' , 99 , iiI1iIiI , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Buscador por id[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 127 , iiI1iIiI , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Video tutoriales[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 125 , iiii11I , O0oOO0o0 )
 if 41 - 41: OoOoOO00 % oO00OO0oo0 + Oo0Ooo
 if 2 - 2: Oo0Ooo * oO0o % IiII - o0oOOo0O0Ooo - oO00OO0oo0
 if 3 - 3: i1iiI11I
 if 45 - 45: i1iiI11I
 if 83 - 83: I11i . OoO0O00
 if 58 - 58: II111iiii + OoO0O00 % OoO0O00 / III1i1i / II111iiii
 OO0oOOoo ( '[COLOR %s]Autorizar OPENLOAD[/COLOR]' % Oo0OoO00oOO0o , 'movieDB' , 97 , II1Ii1iI1i , O0oOO0o0 )
 if 62 - 62: OOooOOo / iII111i
 if 7 - 7: OoO0O00 . III1i1i
 if 53 - 53: o00O0oo % o00O0oo * Ii1I + I11i
 oooooOOO000Oo ( )
 if 92 - 92: OoO0O00 + OoOoOO00 / o00O0oo * I1IiiI
 if 100 - 100: iiIi % Oo0Ooo * o0oOOo0O0Ooo - oO00OO0oo0
 if 92 - 92: iiIi
 if 22 - 22: oO0o % oO00OO0oo0 * iII111i / I1Ii111 % II111iiii * ooOoO0o
 if 95 - 95: OoO0O00 - III1i1i * I1ii11iIi11i + I11i
 if 10 - 10: Ii1I / II111iiii
 if 92 - 92: ooOoO0o . i1iiI11I
 if 85 - 85: iII111i . i1iiI11I
 if 78 - 78: iiIi * i1iiI11I + Oo0Ooo + Oo0Ooo / i1iiI11I . o00O0oo
 if 97 - 97: iiIi / i1iiI11I % OoOoOO00 % iII111i
 if 18 - 18: Oo0Ooo % ooOoO0o
def O00oO0 ( ) :
 o0o0o0o0 = xbmcgui . Dialog ( )
 I1Iiiiiii = (
 I1IIIiI1I1ii1 ,
 iiiI1I1iIIIi1 ,
 )
 if 17 - 17: Oo0Ooo . OoO0O00 / ooOoO0o % o0oOOo0O0Ooo % OoOoOO00 / II111iiii
 OOOIiiiii1iI = o0o0o0o0 . select ( '[B][COLOR=yellow]Listado de Proxys Gratuitos:[/COLOR][/B]' , [
 '[COLOR=orange]                      Accede a la web[/COLOR]' ,

 '[B][COLOR=gold]                      Volver al Menu [/COLOR][/B]' , ] )
 if 49 - 49: Ii1I . III1i1i / OOooOOo + o0oOOo0O0Ooo
 if OOOIiiiii1iI :
  if 47 - 47: I1IiiI / o00O0oo
  if OOOIiiiii1iI < 0 :
   return
  oO0OO0 = I1Iiiiiii [ OOOIiiiii1iI - 2 ]
  return oO0OO0 ( )
 else :
  oO0OO0 = I1Iiiiiii [ OOOIiiiii1iI ]
  return oO0OO0 ( )
 return
 if 82 - 82: III1i1i - III1i1i + I11i
def II111Ii1i1 ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 98 - 98: OOooOOo . OOooOOo * IiII * o0oOOo0O0Ooo * i1iiI11I
oOooO0OOOoO000 = II111Ii1i1 ( )
if 57 - 57: o0oOOo0O0Ooo
def I1IIIiI1I1ii1 ( ) :
 if oOooO0OOOoO000 == 'android' :
  oOOOoo = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://hidemyna.me/es/proxy-list/?country=ES&type=hs#list' ) )
  if 15 - 15: II111iiii % I1ii11iIi11i * ooOoO0o / i1iiI11I
 else :
  oOOOoo = webbrowser . open ( 'https://hidemyna.me/es/proxy-list/?country=ES&type=hs#list' )
  if 90 - 90: oO00OO0oo0
  if 31 - 31: I1Ii111 + I1IiiI
def iiiI1I1iIIIi1 ( ) :
 if 87 - 87: iiIi
 Iiiiii111i1ii ( )
 if 45 - 45: OOooOOo / OoO0O00 - oO00OO0oo0 / o00O0oo % III1i1i
 if 83 - 83: I1ii11iIi11i . Oo0Ooo - III1i1i * II111iiii
def IiI11i1IIiiI ( ) :
 if xbmc . getCondVisibility ( 'System.HasAddon(script.favourites)' ) :
  try :
   xbmc . executebuiltin ( "RunScript(script.favourites)" )
  except :
   pass
def oOOo000oOoO0 ( ) :
 oo000 . openSettings ( )
 if 86 - 86: o0oOOo0O0Ooo % II111iiii + o00O0oo % II111iiii
 if 92 - 92: II111iiii - oO00OO0oo0 / iiIi / IiII
def iiI11I ( ) :
 urlresolver . display_settings ( )
 if 11 - 11: oO00OO0oo0 - IiII + o0oOOo0O0Ooo - Oo0Ooo
def O0OoO0ooOO0o ( ) :
 OO0oOOoo ( '[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % Oo0OoO00oOO0o , 'resolve' , 120 , OOO0OOO00oo , O0oOO0o0 )
 if 7 - 7: III1i1i - ooOoO0o / o0oOOo0O0Ooo * o00O0oo . oO00OO0oo0 * oO00OO0oo0
def O0O0oOOo0O ( ) :
 if 19 - 19: Ii1I / i1iiI11I % Ii1I % oO00OO0oo0 * III1i1i
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 19 - 19: Oo0Ooo
def OoOo0oOooOoOO ( ) :
 OO0oOOoo ( '[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % Oo0OoO00oOO0o , 'resolve' , 140 , OOO0OOO00oo , O0oOO0o0 )
 if 26 - 26: OoO0O00 % I1ii11iIi11i % oO0o . I1ii11iIi11i % o00O0oo
def iIIIii ( ) :
 if 34 - 34: III1i1i / I11i
 Oo0OoO00oOO0o = oo000 . getSetting ( 'MenuColor' )
 OO0oOOoo ( '[COLOR %s]Buscador[/COLOR]' % Oo0OoO00oOO0o , 'search' , 111 , i111I , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Estrenos[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 3 , Ii1IIii11 , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Todas[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 26 , Oooo0000 , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]4K[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 141 , OO0o , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Novedades[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 2 , OOo , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Accion[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 5 , i11 , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Animacion[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 6 , I11 , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Artes Marciales[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 29 , O00o0OO , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Aventuras[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 7 , Oo0o0000o0o0 , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Belico[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 8 , oOo0oooo00o , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Ciencia Ficcion[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 9 , oO0o0o0ooO0oO , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Cine Clasico[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 30 , oo0o0O00 , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Comedia[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 10 , oO , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Crimen[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 11 , i1iiIIiiI111 , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Drama[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 12 , oooOOOOO , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Familiar[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 13 , i1iiIII111ii , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Fantasia[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 14 , i1iIIi1 , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Historia[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 15 , ii11iIi1I , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Misterio[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 16 , OOooO0OOoo , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Musical[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 17 , iIii1 , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Romance[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 18 , oOOoO0 , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Thriller[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 19 , ooOoOoo0O , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Suspense[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 20 , iiI1IiI , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Terror[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 21 , II , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Western[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 22 , OooO0 , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Spain[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 23 , O0OoO000O0OO , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Super heroes[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 24 , iI111I11I1I1 , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Sagas[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 25 , II11iiii1Ii , O0oOO0o0 )
 if 87 - 87: I1IiiI * Ii1I * oO0o * o0oOOo0O0Ooo
def IiI ( ) :
 if 57 - 57: I1ii11iIi11i + o00O0oo % IiII + IiII / o0oOOo0O0Ooo . o00O0oo
 OO0oOOoo ( '[COLOR %s]Buscar Serie[/COLOR]' % Oo0OoO00oOO0o , 'search' , 145 , O0o0Oo , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]En emision[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 150 , I11i1 , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]15 Mejores[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 151 , iIi1ii1I1 , O0oOO0o0 )
 OO0oOOoo ( '[COLOR %s]Todas[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 142 , Oo00OOOOO , O0oOO0o0 )
 if 17 - 17: o00O0oo + IiII . OOooOOo - oO0o * II111iiii
def iioOo0OoOOo0 ( ) :
 if 30 - 30: iII111i % I1ii11iIi11i
 if 89 - 89: i1iiI11I + OoO0O00 + i1iiI11I * OoOoOO00 + Oo0Ooo % ooOoO0o
 try :
  if 59 - 59: I1Ii111 + II111iiii
  oo0OOo0O = i1II1 ( iii1 )
  i11i1 = re . compile ( iiIiI ) . findall ( oo0OOo0O )
  for IiiiiI1i1Iii in i11i1 :
   if 39 - 39: OoO0O00 + IiII % I1Ii111 / I1Ii111
   try :
    if 27 - 27: oO00OO0oo0 . ooOoO0o . Oo0Ooo . Oo0Ooo
    iIi1i = IiiiiI1i1Iii
    i11III1111iIi = xbmc . Keyboard ( '' , 'Buscar' )
    i11III1111iIi . doModal ( )
    if ( i11III1111iIi . isConfirmed ( ) ) :
     if 4 - 4: i1iiI11I / II111iiii / I1Ii111
     iI11 = urllib . quote_plus ( i11III1111iIi . getText ( ) ) . replace ( '+' , ' ' )
     Ooo00Oo = i1II1 ( iIi1i )
     i11i1 = re . compile ( o0o ) . findall ( Ooo00Oo )
     for i1ii1iIII , OOOooo , O0oOO0o0 , OooO0OO in i11i1 :
      if re . search ( iI11 , o0OO0o0oOOO0O ( OOOooo . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       OO0oOOoo ( OOOooo , OooO0OO , 143 , i1ii1iIII , O0oOO0o0 )
       if 91 - 91: Oo0Ooo % Ii1I . Oo0Ooo % OoOoOO00 / o0oOOo0O0Ooo * I11i
   except :
    pass
 except :
  pass
  if 10 - 10: o0oOOo0O0Ooo . oO00OO0oo0
  if 32 - 32: o00O0oo . III1i1i . OoO0O00 - OOooOOo + IiII
def ooO0oO00O0o ( ) :
 if 70 - 70: i1iiI11I
 try :
  if 16 - 16: oO00OO0oo0 - OoO0O00 % oO0o
  oo0OOo0O = i1II1 ( iiIiIIIiiI )
  i11i1 = re . compile ( iiIiI ) . findall ( oo0OOo0O )
  for IiiiiI1i1Iii in i11i1 :
   if 36 - 36: I1Ii111
   try :
    if 84 - 84: i1iiI11I . OOooOOo . o0oOOo0O0Ooo . ooOoO0o / o00O0oo % iII111i
    iIi1i = IiiiiI1i1Iii
    if 57 - 57: I1ii11iIi11i % ooOoO0o - I1Ii111 . I1ii11iIi11i / oO0o % oO00OO0oo0
   except :
    pass
    if 56 - 56: IiII . oO00OO0oo0 . III1i1i * I11i . iiIi / I1IiiI
  Ooo00Oo = i1II1 ( iIi1i )
  i11i1 = re . compile ( o0o ) . findall ( Ooo00Oo )
  for i1ii1iIII , OOOooo , O0oOO0o0 , OooO0OO in i11i1 :
   try :
    if 23 - 23: OoOoOO00 + oO00OO0oo0 + III1i1i + OOooOOo
    OO0oOOoo ( OOOooo , OooO0OO , 143 , i1ii1iIII , O0oOO0o0 )
    if 12 - 12: Oo0Ooo - iII111i + II111iiii
   except :
    pass
 except :
  pass
  if 10 - 10: I1ii11iIi11i - OoOoOO00 - iiIi % oO0o
def iIIII1i ( ) :
 if 76 - 76: oO00OO0oo0 + iiIi
 try :
  if 30 - 30: II111iiii % Oo0Ooo . ooOoO0o % Oo0Ooo
  oo0OOo0O = i1II1 ( o0ooo0 )
  i11i1 = re . compile ( iiIiI ) . findall ( oo0OOo0O )
  for IiiiiI1i1Iii in i11i1 :
   if 62 - 62: oO0o * I11i
   try :
    if 79 - 79: OOooOOo . oO00OO0oo0 * o00O0oo - I1Ii111 + iiIi
    iIi1i = IiiiiI1i1Iii
    if 14 - 14: II111iiii - oO00OO0oo0 * I11i
   except :
    pass
    if 51 - 51: iII111i / Oo0Ooo % IiII + Ii1I * iiIi + i1iiI11I
  Ooo00Oo = i1II1 ( iIi1i )
  i11i1 = re . compile ( o0o ) . findall ( Ooo00Oo )
  for i1ii1iIII , OOOooo , O0oOO0o0 , OooO0OO in i11i1 :
   try :
    if 77 - 77: iiIi * I11i
    OO0oOOoo ( OOOooo , OooO0OO , 143 , i1ii1iIII , O0oOO0o0 )
    if 14 - 14: ooOoO0o % ooOoO0o / III1i1i
   except :
    pass
 except :
  pass
  if 72 - 72: OoOoOO00 - o0oOOo0O0Ooo - I1Ii111 + I1Ii111 * Ii1I * I1Ii111
def iII1I1 ( ) :
 if 85 - 85: oO00OO0oo0 * Ii1I
 try :
  if 3 - 3: I1Ii111
  oo0OOo0O = i1II1 ( iii1 )
  i11i1 = re . compile ( iiIiI ) . findall ( oo0OOo0O )
  for IiiiiI1i1Iii in i11i1 :
   if 20 - 20: o0oOOo0O0Ooo . oO00OO0oo0 / o0oOOo0O0Ooo % II111iiii % oO00OO0oo0
   try :
    if 11 - 11: III1i1i % iII111i % o00O0oo / o0oOOo0O0Ooo % i1iiI11I - oO0o
    iIi1i = IiiiiI1i1Iii
    if 96 - 96: iII111i / o0oOOo0O0Ooo . o00O0oo - oO00OO0oo0 * ooOoO0o * IiII
   except :
    pass
    if 76 - 76: o00O0oo - o0oOOo0O0Ooo * I1Ii111 / OoO0O00
  Ooo00Oo = i1II1 ( iIi1i )
  i11i1 = re . compile ( o0o ) . findall ( Ooo00Oo )
  for i1ii1iIII , OOOooo , O0oOO0o0 , OooO0OO in i11i1 :
   try :
    if 18 - 18: OOooOOo + Oo0Ooo - o0oOOo0O0Ooo - I1ii11iIi11i
    OO0oOOoo ( OOOooo , OooO0OO , 143 , i1ii1iIII , O0oOO0o0 )
    if 71 - 71: OoO0O00
   except :
    pass
 except :
  pass
  if 33 - 33: i1iiI11I
def OOO0ooo ( name , url ) :
 if 7 - 7: Ii1I + OoOoOO00 . I1ii11iIi11i / oO0o
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 22 - 22: iiIi - iiIi % I1Ii111 . i1iiI11I + IiII
 Ii1Io0OO0o0o00o = i1II1 ( url )
 i11i1 = re . compile ( OooOO000 ) . findall ( Ii1Io0OO0o0o00o )
 for Oo00OOo00O , name , O0oOO0o0 , url in i11i1 :
  try :
   if 81 - 81: III1i1i . Ii1I / i1iiI11I
   if 17 - 17: II111iiii - I1Ii111 . III1i1i % Oo0Ooo + ooOoO0o - iiIi
   Oo0oOOo = oo000 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % Oo0oOOo + name + '[/COLOR]'
   O0oOooo0OOooO ( name , url , 144 , Oo00OOo00O , O0oOO0o0 )
   if 64 - 64: I1Ii111 . IiII - IiII
   if 76 - 76: I1IiiI % Oo0Ooo * I1ii11iIi11i % I1IiiI
  except :
   pass
   if 77 - 77: I1Ii111 + Ii1I + Oo0Ooo
   if 40 - 40: iiIi - I1Ii111 . o00O0oo * oO0o % i1iiI11I
   if 56 - 56: II111iiii . Ii1I - I1ii11iIi11i * ooOoO0o
def O0oOooo0OOooO ( name , url , mode , iconimage , fanart ) :
 if 91 - 91: IiII + OoO0O00 - OoOoOO00
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 84 - 84: o00O0oo / III1i1i
 OOOooo0OooOoO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage="
 oOoOOOo = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 oOoOOOo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 oOoOOOo . setProperty ( 'fanart_image' , fanart )
 oOoOOOo . setProperty ( 'IsPlayable' , 'true' )
 ii1Io0OOoOoO00 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOOooo0OooOoO , listitem = oOoOOOo )
 return ii1Io0OOoOoO00
 if 15 - 15: III1i1i / I1IiiI . Ii1I . II111iiii
def o0OO0O0Oo ( name , url ) :
 if 78 - 78: I11i / oO0o - I1Ii111 - oO00OO0oo0 * IiII
 if 17 - 17: OoO0O00 + I1Ii111 * ooOoO0o * I11i
 if 'https://team.com' in url :
  if 36 - 36: I1IiiI + oO0o
  url = url . replace ( 'https://team.com' , 'https://verystream.com' )
  if 5 - 5: oO0o * I11i
 if 'https://mybox.com' in url :
  if 46 - 46: iiIi
  url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
  if 33 - 33: oO00OO0oo0 - o0oOOo0O0Ooo * OoO0O00 - oO0o - I1Ii111
 if 'https://drive.com' in url :
  if 84 - 84: i1iiI11I + oO0o - I11i * I11i
  url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
  if 61 - 61: OoO0O00 . IiII . OoO0O00 / oO0o
 if 'https://vidcloud.co/' in url :
  if 72 - 72: OoOoOO00
  url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
  if 82 - 82: I11i + OoO0O00 / II111iiii * iII111i . OoO0O00
 if 'https://gounlimited.to' in url :
  if 63 - 63: iII111i
  url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
  if 6 - 6: iiIi / iII111i
  if 57 - 57: ooOoO0o
  if 67 - 67: OOooOOo . iiIi
 import resolveurl
 if 87 - 87: IiII % o00O0oo
 oo0OOOoOo = urlresolver . HostedMediaFile ( url )
 IIiiIIi1 = xbmcgui . DialogProgress ( )
 IIiiIIi1 . create ( 'Realstream:' , 'Conectando al servidor ... ' )
 IIiiIIi1 . update ( 20 , 'Por favor, espere ...' )
 xbmc . sleep ( 500 )
 if 51 - 51: I11i
 if 14 - 14: III1i1i % IiII % oO0o - II111iiii
 if not oo0OOOoOo :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
  return False
  if 53 - 53: o00O0oo % oO0o
 try :
  if 59 - 59: I1Ii111 % Oo0Ooo . OoOoOO00 + o0oOOo0O0Ooo * III1i1i
  IIiiIIi1 . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
  xbmc . sleep ( 500 )
  i1IiiI1iIi = oo0OOOoOo . resolve ( )
  if not i1IiiI1iIi or not isinstance ( i1IiiI1iIi , basestring ) :
   try : oOOo00O0OOOo = i1IiiI1iIi . msg
   except : oOOo00O0OOOo = url
   raise Exception ( oOOo00O0OOOo )
 except Exception as IIiI1 :
  try : oOOo00O0OOOo = str ( IIiI1 )
  except : oOOo00O0OOOo = url
  IIiiIIi1 . update ( 100 , 'RESOLVEURL:' , 'Enlace no encontrado ... abortando.' )
  xbmc . sleep ( 1000 )
  IIiiIIi1 . close ( )
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado, reportalo en nuesto grupo de telegram [COLOR ligthblue] https://t.me/OficialNetai [/COLOR]  ,5000)" )
  return False
  if 31 - 31: ooOoO0o % I1Ii111 * ooOoO0o
 IIiiIIi1 . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
 xbmc . sleep ( 500 )
 IIiiIIi1 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
 xbmc . sleep ( 500 )
 IIiiIIi1 . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
 xbmc . sleep ( 500 )
 IIiiIIi1 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de este capitulo!' )
 IIiiIIi1 . close ( )
 IIIIii = oo000 . getSetting ( 'notificar' )
 if IIIIii == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
  if 45 - 45: OoOoOO00 . I1ii11iIi11i + I1Ii111 - OoO0O00 % iiIi
  if 1 - 1: Oo0Ooo
  ooi1II1I = xbmcgui . ListItem ( path = i1IiiI1iIi )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooi1II1I )
  if 95 - 95: OOooOOo - I1Ii111 / o0oOOo0O0Ooo % iII111i . Ii1I
 else :
  if 24 - 24: OoOoOO00 . II111iiii
  ooi1II1I = xbmcgui . ListItem ( path = i1IiiI1iIi )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooi1II1I )
  if 16 - 16: oO0o % iII111i + ooOoO0o - I1IiiI . oO00OO0oo0 / i1iiI11I
  if 35 - 35: IiII / i1iiI11I / o0oOOo0O0Ooo - Oo0Ooo + o0oOOo0O0Ooo . i1iiI11I
  if 81 - 81: oO00OO0oo0 * I1Ii111 - iII111i * o00O0oo % I11i * I11i
def ooO ( ) :
 if 100 - 100: I1ii11iIi11i / Ii1I * oO00OO0oo0 . I1IiiI / I1Ii111
 if 83 - 83: i1iiI11I
 ii111Ii11iii = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 ii111Ii11iii . doModal ( )
 if not ii111Ii11iii . isConfirmed ( ) :
  return None ;
 OOOooo = ii111Ii11iii . getText ( ) . strip ( )
 if 62 - 62: Oo0Ooo
 if 93 - 93: IiII - Ii1I % I11i . I11i - iiIi
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 90 - 90: iiIi + o0oOOo0O0Ooo * iII111i / o00O0oo . Ii1I + Ii1I
  oOOOoo = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + OOOooo + '&language=es-ES' ) )
  if 40 - 40: iiIi / I11i % II111iiii % iII111i / I1ii11iIi11i
  if 62 - 62: OoOoOO00 - I11i
  return 'android'
  if 62 - 62: OoOoOO00 + oO0o % III1i1i
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 28 - 28: iII111i . OoOoOO00
  oOOOoo = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + OOOooo + '&language=es-ES' )
  if 10 - 10: OOooOOo / oO0o
  if 15 - 15: oO00OO0oo0 . I11i / oO00OO0oo0 * ooOoO0o - I1ii11iIi11i % iII111i
  return 'windows'
  if 57 - 57: I1IiiI % I11i % IiII
  if 45 - 45: iII111i + o0oOOo0O0Ooo * II111iiii
def IiIIi1I1I11Ii ( ) :
 if 64 - 64: OoO0O00
 try :
  if 81 - 81: iII111i - I1IiiI * OoO0O00
  OoOO0o = i1II1 ( i1Iii1i1I )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 23 - 23: o0oOOo0O0Ooo / IiII
   try :
    if 28 - 28: oO0o * iiIi - OOooOOo
    all = IiiiiI1i1Iii
    if 19 - 19: ooOoO0o
   except :
    pass
    if 67 - 67: I1IiiI % Oo0Ooo / III1i1i . II111iiii - o00O0oo + I1IiiI
  Ii1Io0OO0o0o00o = i1II1 ( all )
  i11i1 = re . compile ( O0OOO ) . findall ( Ii1Io0OO0o0o00o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    if 27 - 27: I1Ii111
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 89 - 89: o0oOOo0O0Ooo / IiII
   except :
    pass
 except :
  pass
  if 14 - 14: I1Ii111 . I1ii11iIi11i * iiIi + o0oOOo0O0Ooo - iiIi + I1Ii111
def IIIIIiII1 ( ) :
 if 45 - 45: I1ii11iIi11i / oO00OO0oo0 . oO00OO0oo0
 try :
  if 35 - 35: i1iiI11I . I11i * II111iiii
  OOo = i1II1 ( IiI111111IIII )
  i11i1 = re . compile ( iiIiI ) . findall ( OOo )
  for IiiiiI1i1Iii in i11i1 :
   if 44 - 44: II111iiii / oO0o
   try :
    if 42 - 42: OoO0O00 + oO0o % o0oOOo0O0Ooo + OOooOOo
    iIi1i = IiiiiI1i1Iii
    if 24 - 24: oO00OO0oo0 * o0oOOo0O0Ooo % oO00OO0oo0 % III1i1i + OoO0O00
   except :
    pass
    if 29 - 29: o0oOOo0O0Ooo - OoO0O00 - II111iiii . Ii1I
  Ooo00Oo = i1II1 ( iIi1i )
  i11i1 = re . compile ( O0OOO ) . findall ( Ooo00Oo )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    if 19 - 19: o0oOOo0O0Ooo
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 72 - 72: OoO0O00 / I1ii11iIi11i + o00O0oo / I11i * o00O0oo
   except :
    pass
 except :
  pass
  if 34 - 34: I1IiiI * I1IiiI % OoO0O00 + oO00OO0oo0 * Oo0Ooo % o00O0oo
def I1iI1I1 ( ) :
 if 48 - 48: I1ii11iIi11i / II111iiii - Ii1I * IiII / OoO0O00
 try :
  if 89 - 89: Oo0Ooo / I1ii11iIi11i - o0oOOo0O0Ooo / o00O0oo . II111iiii . o00O0oo
  Ii1IIii11 = i1II1 ( ii111iI1iIi1 )
  i11i1 = re . compile ( iiIiI ) . findall ( Ii1IIii11 )
  for IiiiiI1i1Iii in i11i1 :
   if 48 - 48: I1IiiI + I1IiiI . i1iiI11I - iiIi
   try :
    o00oo0000 = IiiiiI1i1Iii
   except :
    pass
    if 44 - 44: oO0o % Oo0Ooo
  OoOO0o = i1II1 ( o00oo0000 )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 90 - 90: o0oOOo0O0Ooo + OoO0O00 % OoO0O00
   except :
    pass
 except :
  pass
  if 35 - 35: oO00OO0oo0 / iII111i * OoO0O00 . o0oOOo0O0Ooo / oO0o
def Iii11i ( ) :
 if 73 - 73: oO0o - I11i - IiII - I1ii11iIi11i
 try :
  if 65 - 65: Ii1I
  OoOO0o = i1II1 ( db2 )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 7 - 7: III1i1i . I11i / iII111i . I1Ii111 * ooOoO0o - o0oOOo0O0Ooo
   try :
    if 37 - 37: i1iiI11I . I11i / I1IiiI * oO00OO0oo0
    III11iiii11i1 = IiiiiI1i1Iii
    if 54 - 54: OoOoOO00 - IiII
   except :
    pass
    if 18 - 18: Oo0Ooo + oO0o - I1Ii111 + OoO0O00 * OoO0O00
    if 41 - 41: iiIi . oO0o + I1ii11iIi11i
  OoOO0o = i1II1 ( III11iiii11i1 )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 100 - 100: o00O0oo + OOooOOo
   except :
    pass
 except :
  pass
  if 73 - 73: OoOoOO00 - i1iiI11I % iiIi / OOooOOo
def III1iii1i11iI ( ) :
 if 56 - 56: II111iiii . Oo0Ooo + iII111i + oO00OO0oo0 / oO0o . i1iiI11I
 try :
  if 74 - 74: OoO0O00 % I1Ii111 % i1iiI11I - I1ii11iIi11i - ooOoO0o
  o0I11iII = i1II1 ( o0O00Oo0 )
  i11i1 = re . compile ( iiIiI ) . findall ( o0I11iII )
  for IiiiiI1i1Iii in i11i1 :
   if 2 - 2: I1ii11iIi11i + Ii1I . Ii1I . I1IiiI / ooOoO0o
   try :
    if 40 - 40: Ii1I - o0oOOo0O0Ooo / oO0o
    iiIiI1ii = IiiiiI1i1Iii
    if 56 - 56: OoO0O00 - ooOoO0o - OoOoOO00
   except :
    pass
    if 8 - 8: i1iiI11I / I1Ii111 . I1ii11iIi11i + iII111i / II111iiii
    if 31 - 31: iiIi - Oo0Ooo + oO00OO0oo0 . oO0o / III1i1i % Oo0Ooo
  OoOO0o = i1II1 ( iiIiI1ii )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 6 - 6: III1i1i * II111iiii % Oo0Ooo % II111iiii + Ii1I / OoOoOO00
   except :
    pass
 except :
  pass
  if 53 - 53: ooOoO0o + Oo0Ooo
def oOooo0Oo ( ) :
 if 66 - 66: oO0o
 try :
  if 28 - 28: III1i1i - III1i1i . OoOoOO00 - iiIi + I1ii11iIi11i . III1i1i
  OoOO0o = i1II1 ( oo0OOo0 )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 54 - 54: I11i - i1iiI11I
   try :
    if 3 - 3: I1ii11iIi11i - oO0o
    iIi1I1 = IiiiiI1i1Iii
    if 63 - 63: oO00OO0oo0 * iII111i . OoO0O00 / I1Ii111 * oO0o . iiIi
   except :
    pass
    if 62 - 62: OoOoOO00 / iiIi . I1ii11iIi11i * Ii1I
    if 21 - 21: Ii1I
  OoOO0o = i1II1 ( iIi1I1 )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 81 - 81: ooOoO0o / Oo0Ooo - iiIi * i1iiI11I . I1ii11iIi11i * iII111i
   except :
    pass
 except :
  pass
  if 95 - 95: I1ii11iIi11i
def O0OOO000o0o ( ) :
 if 19 - 19: o0oOOo0O0Ooo - OoOoOO00 - I1Ii111 / I1Ii111 + I11i
 try :
  if 51 - 51: oO0o % I11i * OoO0O00 . II111iiii
  OoOO0o = i1II1 ( O0ooO0Oo00o )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 77 - 77: o0oOOo0O0Ooo
   try :
    if 42 - 42: o00O0oo * i1iiI11I . III1i1i * I1ii11iIi11i + I11i
    i1i1II11II1 = IiiiiI1i1Iii
    if 5 - 5: oO0o - iII111i % IiII - o0oOOo0O0Ooo . I1ii11iIi11i + oO00OO0oo0
   except :
    pass
    if 47 - 47: I1IiiI - Oo0Ooo - oO00OO0oo0
  OoOO0o = i1II1 ( i1i1II11II1 )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 46 - 46: o00O0oo . I1Ii111 * OOooOOo . OoO0O00 + iII111i
   except :
    pass
 except :
  pass
  if 72 - 72: o0oOOo0O0Ooo + I1Ii111
def OooOOOO0O0 ( ) :
 if 38 - 38: i1iiI11I % I1Ii111 - OoO0O00
 try :
  if 87 - 87: OOooOOo % I1ii11iIi11i
  OoOO0o = i1II1 ( i1I1ii11i1Iii )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 77 - 77: Oo0Ooo - OoOoOO00 . IiII
   try :
    if 26 - 26: Ii1I * III1i1i . OoOoOO00
    ooOoOO = IiiiiI1i1Iii
    if 56 - 56: Oo0Ooo . II111iiii - I1Ii111 * o0oOOo0O0Ooo * i1iiI11I
   except :
    pass
    if 5 - 5: I1Ii111 / I1Ii111 - iII111i
    if 79 - 79: iII111i + i1iiI11I
  OoOO0o = i1II1 ( ooOoOO )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 10 - 10: oO0o + I1IiiI
   except :
    pass
 except :
  pass
  if 43 - 43: Oo0Ooo / o0oOOo0O0Ooo % Ii1I - I1Ii111
def oO0O000oOo ( ) :
 if 53 - 53: Oo0Ooo + Ii1I - I11i - IiII / iiIi % II111iiii
 try :
  if 3 - 3: oO00OO0oo0 . iiIi % I1ii11iIi11i + iII111i
  OoOO0o = i1II1 ( o0OIiII )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 64 - 64: OoOoOO00
   try :
    if 29 - 29: Ii1I / II111iiii / I1ii11iIi11i % IiII % II111iiii
    i111II = IiiiiI1i1Iii
    if 63 - 63: I1ii11iIi11i - OOooOOo % oO00OO0oo0 % ooOoO0o / Ii1I / OoOoOO00
   except :
    pass
    if 69 - 69: oO0o * o0oOOo0O0Ooo * iiIi . oO00OO0oo0 - iII111i
    if 39 - 39: o00O0oo * I1ii11iIi11i % OOooOOo . I11i
  OoOO0o = i1II1 ( i111II )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 24 - 24: OoOoOO00 * Oo0Ooo / o00O0oo
   except :
    pass
 except :
  pass
  if 78 - 78: II111iiii + Ii1I + i1iiI11I / Ii1I % Oo0Ooo % III1i1i
def Oo0O0Oo00O ( ) :
 if 9 - 9: Ii1I . I1ii11iIi11i - iII111i
 try :
  if 32 - 32: OoO0O00 / I1ii11iIi11i / Oo0Ooo + o0oOOo0O0Ooo . IiII . Ii1I
  OoOO0o = i1II1 ( Iii1I1I11iiI1 )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 21 - 21: Oo0Ooo / o0oOOo0O0Ooo % OoOoOO00
   try :
    if 8 - 8: OOooOOo + I11i . Oo0Ooo % I1IiiI
    iI11Ii111 = IiiiiI1i1Iii
    if 54 - 54: I11i % oO00OO0oo0 . I11i * I1Ii111 + I11i % OoOoOO00
   except :
    pass
    if 23 - 23: i1iiI11I - I1Ii111 + o00O0oo - I11i * I11i . oO0o
    if 47 - 47: IiII % Oo0Ooo
  OoOO0o = i1II1 ( iI11Ii111 )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 11 - 11: I1ii11iIi11i % o00O0oo - OOooOOo - IiII + Ii1I
   except :
    pass
 except :
  pass
  if 98 - 98: oO00OO0oo0 + o00O0oo - OOooOOo
def OOo0 ( ) :
 if 58 - 58: I11i - oO00OO0oo0 - OoO0O00
 try :
  if 96 - 96: Oo0Ooo
  OoOO0o = i1II1 ( i111iIi1i1II1 )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 82 - 82: I11i + I1IiiI - III1i1i % IiII * II111iiii
   try :
    if 15 - 15: Ii1I
    I1iI = IiiiiI1i1Iii
    if 92 - 92: OOooOOo * iiIi
   except :
    pass
    if 35 - 35: II111iiii
    if 99 - 99: o0oOOo0O0Ooo . Ii1I + I1IiiI
  OoOO0o = i1II1 ( I1iI )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 71 - 71: III1i1i + OoOoOO00 * oO0o % oO0o / oO0o
   except :
    pass
 except :
  pass
  if 55 - 55: OoO0O00 + i1iiI11I + OoO0O00 * iiIi
  if 68 - 68: I1IiiI
def II1iIII ( ) :
 if 79 - 79: OoO0O00 + iII111i - oO0o + OoO0O00
 try :
  if 61 - 61: OoOoOO00 * OOooOOo - oO0o - iiIi
  OoOO0o = i1II1 ( ii1I )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 57 - 57: I11i . Oo0Ooo % iiIi % o00O0oo * I11i
   try :
    if 8 - 8: I11i . iiIi % IiII . I1ii11iIi11i % I1ii11iIi11i . o00O0oo
    I1I11ii = IiiiiI1i1Iii
    if 93 - 93: iII111i % I11i . I1IiiI / oO00OO0oo0 * IiII
   except :
    pass
    if 29 - 29: Ii1I
    if 86 - 86: o0oOOo0O0Ooo . III1i1i
  OoOO0o = i1II1 ( I1I11ii )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 2 - 2: OoO0O00
   except :
    pass
 except :
  pass
  if 60 - 60: OOooOOo
  if 81 - 81: I11i % o00O0oo
def oo0 ( ) :
 if 16 - 16: o00O0oo * OOooOOo / IiII
 try :
  if 22 - 22: IiII + Oo0Ooo % oO0o / ooOoO0o / o00O0oo
  OoOO0o = i1II1 ( oO0 )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 54 - 54: I11i % III1i1i . II111iiii
   try :
    if 93 - 93: iiIi % II111iiii % i1iiI11I
    O00OooO = IiiiiI1i1Iii
    if 40 - 40: ooOoO0o % OoO0O00 - I1Ii111 + Ii1I / I1Ii111
   except :
    pass
    if 84 - 84: I1IiiI
    if 11 - 11: o0oOOo0O0Ooo / II111iiii / I1IiiI
  OoOO0o = i1II1 ( O00OooO )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 94 - 94: iiIi * ooOoO0o - III1i1i . Oo0Ooo
   except :
    pass
    if 66 - 66: iiIi - I1Ii111 * I11i / IiII * o0oOOo0O0Ooo * OOooOOo
 except :
  pass
  if 91 - 91: OoO0O00 / o00O0oo . I1ii11iIi11i + iiIi . o0oOOo0O0Ooo
  if 45 - 45: IiII * I11i / Oo0Ooo
def o00ooOoO0 ( ) :
 if 15 - 15: I1Ii111 * ooOoO0o / iII111i * Ii1I
 try :
  if 94 - 94: oO00OO0oo0 + o00O0oo % Ii1I
  OoOO0o = i1II1 ( OO )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 1 - 1: I11i % i1iiI11I - I1Ii111 + IiII + I1IiiI * Ii1I
   try :
    if 97 - 97: I11i
    OoOoOOoO0oo0O = IiiiiI1i1Iii
    if 49 - 49: Ii1I
   except :
    pass
    if 31 - 31: OOooOOo * II111iiii * o00O0oo . II111iiii
    if 12 - 12: I11i % III1i1i % iII111i . II111iiii * Oo0Ooo
  OoOO0o = i1II1 ( OoOoOOoO0oo0O )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 66 - 66: II111iiii * Oo0Ooo % OoO0O00
   except :
    pass
    if 5 - 5: I11i % OoO0O00
 except :
  pass
  if 60 - 60: I11i . OoOoOO00 % OOooOOo % iiIi % I1Ii111
def Ii111IIi ( ) :
 if 15 - 15: iII111i % i1iiI11I + II111iiii
 try :
  if 10 - 10: o00O0oo - I11i . OoO0O00 . I1Ii111 . OOooOOo * oO00OO0oo0
  OoOO0o = i1II1 ( Ii1I1i )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 78 - 78: IiII / OOooOOo - IiII * OoO0O00 . I11i
   try :
    if 96 - 96: I1ii11iIi11i % OoOoOO00 . Ii1I . I1IiiI
    Ii1Iii11 = IiiiiI1i1Iii
    if 97 - 97: I1Ii111 / IiII . o0oOOo0O0Ooo
   except :
    pass
    if 44 - 44: o00O0oo % ooOoO0o . i1iiI11I
  OoOO0o = i1II1 ( Ii1Iii11 )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 18 - 18: Oo0Ooo + ooOoO0o * I1ii11iIi11i - I1Ii111 / I1ii11iIi11i
   except :
    pass
 except :
  pass
  if 78 - 78: ooOoO0o . III1i1i
  if 38 - 38: I11i + III1i1i
def IIi1I1i ( ) :
 if 13 - 13: Oo0Ooo . I11i * I1ii11iIi11i / IiII * o00O0oo
 try :
  if 64 - 64: iiIi / I1IiiI * I11i * iiIi
  OoOO0o = i1II1 ( O0O0OOOOoo )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 60 - 60: ooOoO0o / OoOoOO00 % iII111i / iII111i * iII111i . II111iiii
   try :
    if 99 - 99: I11i
    oO00OoOo = IiiiiI1i1Iii
    if 74 - 74: o0oOOo0O0Ooo . I1IiiI - I1ii11iIi11i + III1i1i % II111iiii % I11i
   except :
    pass
    if 78 - 78: o00O0oo + I11i + III1i1i - III1i1i . II111iiii / OOooOOo
    if 27 - 27: o00O0oo - I1IiiI % ooOoO0o * i1iiI11I . III1i1i % Oo0Ooo
  OoOO0o = i1II1 ( oO00OoOo )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 37 - 37: OoO0O00 + I1IiiI - OoOoOO00 % iiIi
   except :
    pass
 except :
  pass
  if 24 - 24: I11i
  if 94 - 94: OoOoOO00 * OoOoOO00 % o0oOOo0O0Ooo + I1Ii111
def iIIi11 ( ) :
 if 54 - 54: o00O0oo - i1iiI11I
 try :
  if 81 - 81: III1i1i . I1IiiI + o0oOOo0O0Ooo * Oo0Ooo * I1Ii111 / I11i
  OoOO0o = i1II1 ( Ii1I1Ii )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 88 - 88: o0oOOo0O0Ooo - Ii1I * I1ii11iIi11i . OOooOOo
   try :
    if 65 - 65: III1i1i . OoOoOO00
    OOOoO0 = IiiiiI1i1Iii
    if 85 - 85: Oo0Ooo / OoO0O00 % o0oOOo0O0Ooo
   except :
    pass
  OoOO0o = i1II1 ( OOOoO0 )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 49 - 49: II111iiii % I11i + i1iiI11I . o0oOOo0O0Ooo % oO00OO0oo0 * I1Ii111
   except :
    pass
 except :
  pass
  if 67 - 67: OoOoOO00
def iiioOOOo ( ) :
 if 31 - 31: I11i + I11i . II111iiii / iiIi % ooOoO0o / I11i
 try :
  if 29 - 29: iII111i * iII111i . OOooOOo * ooOoO0o % Oo0Ooo * iII111i
  OoOO0o = i1II1 ( OO0Oooo0oOO0O )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 31 - 31: OOooOOo * I1IiiI . IiII
   try :
    if 59 - 59: o0oOOo0O0Ooo * II111iiii
    ooOooO00Oo = IiiiiI1i1Iii
    if 86 - 86: o0oOOo0O0Ooo + iiIi + III1i1i
   except :
    pass
    if 9 - 9: iiIi + o0oOOo0O0Ooo % iiIi % III1i1i + Oo0Ooo
    if 59 - 59: OoOoOO00
  OoOO0o = i1II1 ( ooOooO00Oo )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 48 - 48: I1IiiI * o00O0oo * OOooOOo . OOooOOo * ooOoO0o - o00O0oo
   except :
    pass
 except :
  pass
  if 14 - 14: iII111i + II111iiii
  if 83 - 83: iII111i / II111iiii + o0oOOo0O0Ooo . oO00OO0oo0 * I1Ii111 + III1i1i
def iiii1i1II1 ( ) :
 if 63 - 63: Oo0Ooo % iII111i - oO00OO0oo0
 try :
  if 17 - 17: I1ii11iIi11i
  OoOO0o = i1II1 ( oOO0O00Oo0O0o )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 88 - 88: OoO0O00
   try :
    if 28 - 28: oO0o * Ii1I / i1iiI11I
    Oo0O = IiiiiI1i1Iii
    if 88 - 88: I1ii11iIi11i % I1Ii111 % iII111i . II111iiii % Ii1I
   except :
    pass
    if 38 - 38: i1iiI11I + OoO0O00 . OoOoOO00
    if 19 - 19: oO00OO0oo0 - Ii1I - o00O0oo - I11i . oO00OO0oo0 . i1iiI11I
  OoOO0o = i1II1 ( Oo0O )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 48 - 48: oO00OO0oo0 + III1i1i
   except :
    pass
 except :
  pass
  if 60 - 60: ooOoO0o + oO00OO0oo0 . III1i1i / OoOoOO00 . Oo0Ooo
def i1i11ii1Ii ( ) :
 if 12 - 12: I1Ii111 . o00O0oo
 try :
  if 79 - 79: i1iiI11I / oO0o / oO00OO0oo0 . i1iiI11I * OoO0O00 + Ii1I
  OoOO0o = i1II1 ( I1iIIiiIIi1i )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 73 - 73: I1IiiI - iII111i
   try :
    if 2 - 2: o0oOOo0O0Ooo / i1iiI11I
    OoO = IiiiiI1i1Iii
    if 71 - 71: OOooOOo - OoO0O00 * oO0o
   except :
    pass
    if 38 - 38: Oo0Ooo / iiIi
    if 13 - 13: Oo0Ooo
  OoOO0o = i1II1 ( OoO )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 77 - 77: II111iiii - Oo0Ooo / IiII / iiIi / OOooOOo
   except :
    pass
 except :
  pass
  if 56 - 56: OoO0O00 * I1IiiI
  if 85 - 85: OoO0O00 % I11i * Oo0Ooo
def IiIo0o0OO0o00o0O ( ) :
 if 28 - 28: OOooOOo - IiII + I11i + o00O0oo / Oo0Ooo
 try :
  if 26 - 26: Oo0Ooo - I1IiiI . I1IiiI
  OoOO0o = i1II1 ( oOOo0O00o )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 68 - 68: I1Ii111 + IiII . I1IiiI . o00O0oo % OoOoOO00 % I1Ii111
   try :
    if 50 - 50: III1i1i + Ii1I
    o0OoOOo = IiiiiI1i1Iii
    if 56 - 56: ooOoO0o / Oo0Ooo + I11i % I1Ii111 . I1Ii111 - iII111i
   except :
    pass
    if 48 - 48: oO0o - iiIi + oO0o - I1ii11iIi11i * II111iiii . oO00OO0oo0
    if 35 - 35: III1i1i . I1IiiI + oO0o + I1Ii111 + OoOoOO00
  OoOO0o = i1II1 ( o0OoOOo )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 65 - 65: I1IiiI * I1ii11iIi11i / I1ii11iIi11i . I11i
   except :
    pass
 except :
  pass
  if 87 - 87: o0oOOo0O0Ooo * iII111i % oO0o * oO0o
  if 58 - 58: I1Ii111 . Ii1I + I1ii11iIi11i % oO0o - OOooOOo
def I1Iii1Ii1i1 ( ) :
 if 10 - 10: oO00OO0oo0 . OoOoOO00 + o00O0oo
 try :
  if 66 - 66: OOooOOo % Ii1I
  OoOO0o = i1II1 ( OOOiiiiI )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 21 - 21: I11i - OoO0O00 % II111iiii
   try :
    if 71 - 71: OoOoOO00 - ooOoO0o * i1iiI11I + IiII - OOooOOo % iII111i
    Ooo0oO = IiiiiI1i1Iii
    if 32 - 32: OoOoOO00 . oO00OO0oo0 + o0oOOo0O0Ooo - OOooOOo - Oo0Ooo
   except :
    pass
    if 20 - 20: I11i % iII111i
    if 44 - 44: OoO0O00 . o0oOOo0O0Ooo . I1Ii111 % OoO0O00
  OoOO0o = i1II1 ( Ooo0oO )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 86 - 86: II111iiii + I1IiiI * III1i1i - OOooOOo * I1Ii111 + I1IiiI
   except :
    pass
 except :
  pass
  if 95 - 95: Oo0Ooo . i1iiI11I % oO00OO0oo0 - i1iiI11I * o0oOOo0O0Ooo
  if 89 - 89: oO00OO0oo0 . I1ii11iIi11i
def ooOoo0OoOO ( ) :
 if 38 - 38: OOooOOo / iiIi % i1iiI11I * ooOoO0o + II111iiii % iiIi
 try :
  if 61 - 61: i1iiI11I - o00O0oo % iII111i / iiIi / oO00OO0oo0 + Oo0Ooo
  OoOO0o = i1II1 ( OOoO )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 87 - 87: i1iiI11I + iiIi + I1IiiI / OoOoOO00 % III1i1i / i1iiI11I
   try :
    if 64 - 64: OOooOOo % III1i1i . i1iiI11I % OOooOOo + ooOoO0o * III1i1i
    OOOO00OooO = IiiiiI1i1Iii
    if 64 - 64: OOooOOo . I1ii11iIi11i - OoO0O00 . iiIi - oO00OO0oo0
   except :
    pass
    if 77 - 77: o00O0oo % I11i / o0oOOo0O0Ooo % oO00OO0oo0 % OoO0O00 % OOooOOo
    if 19 - 19: III1i1i * i1iiI11I / IiII * i1iiI11I - OoO0O00 * ooOoO0o
  OoOO0o = i1II1 ( OOOO00OooO )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 17 - 17: o0oOOo0O0Ooo + oO0o . i1iiI11I
   except :
    pass
 except :
  pass
  if 12 - 12: i1iiI11I + I1Ii111 + ooOoO0o . III1i1i / o00O0oo
  if 29 - 29: III1i1i . iiIi - o0oOOo0O0Ooo
def ooooO0 ( ) :
 if 37 - 37: II111iiii + I1ii11iIi11i . I1Ii111 % ooOoO0o % ooOoO0o
 try :
  if 26 - 26: I1IiiI
  OoOO0o = i1II1 ( iiIiI1i1 )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 34 - 34: iiIi * i1iiI11I
   try :
    if 97 - 97: II111iiii % IiII / oO0o / oO0o
    OoO00ooO = IiiiiI1i1Iii
    if 15 - 15: II111iiii
   except :
    pass
    if 13 - 13: ooOoO0o * o0oOOo0O0Ooo * IiII * o0oOOo0O0Ooo % III1i1i / I1ii11iIi11i
  OoOO0o = i1II1 ( OoO00ooO )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 100 - 100: III1i1i . o00O0oo - Oo0Ooo . II111iiii / o0oOOo0O0Ooo
   except :
    pass
 except :
  pass
  if 71 - 71: i1iiI11I * oO0o . ooOoO0o
  if 49 - 49: III1i1i * I1IiiI . III1i1i
def ii1II1II ( ) :
 if 42 - 42: o00O0oo
 try :
  if 68 - 68: I1Ii111 . oO0o % iiIi - OoO0O00 * oO00OO0oo0 . I1Ii111
  OoOO0o = i1II1 ( IiIi11iI )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 46 - 46: II111iiii - I1Ii111 * I1ii11iIi11i * ooOoO0o % iII111i * OoOoOO00
   try :
    if 5 - 5: I1IiiI / iiIi . oO0o + OoO0O00
    O0o = IiiiiI1i1Iii
    if 78 - 78: I1Ii111 % Oo0Ooo
   except :
    pass
    if 50 - 50: I1ii11iIi11i % Oo0Ooo % I1Ii111
    if 84 - 84: III1i1i + iII111i + o00O0oo + oO00OO0oo0
  OoOO0o = i1II1 ( O0o )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 62 - 62: II111iiii + I11i + OoOoOO00
   except :
    pass
 except :
  pass
  if 69 - 69: I11i
def OO0Oo ( ) :
 if 13 - 13: Ii1I * II111iiii / II111iiii . OOooOOo . I1Ii111 . iII111i
 try :
  if 26 - 26: Ii1I . Oo0Ooo
  OoOO0o = i1II1 ( i11I1IiII1i1i )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 67 - 67: oO0o / I1IiiI
   try :
    if 88 - 88: I11i - I1Ii111
    o0oo0O0oOoooO = IiiiiI1i1Iii
    if 70 - 70: IiII * IiII + oO0o * I1Ii111 % I1ii11iIi11i + Oo0Ooo
   except :
    pass
  OoOO0o = i1II1 ( o0oo0O0oOoooO )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 2 - 2: II111iiii
   except :
    pass
 except :
  pass
  if 98 - 98: IiII / OOooOOo - o00O0oo - I1ii11iIi11i / I11i + II111iiii
def i1I1IiI1ii ( ) :
 if 64 - 64: oO00OO0oo0 * iII111i % o0oOOo0O0Ooo - I11i + iII111i
 try :
  if 62 - 62: I11i % Ii1I % I1ii11iIi11i + III1i1i . OOooOOo
  OoOO0o = i1II1 ( I1111i )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 48 - 48: I1ii11iIi11i * II111iiii % o0oOOo0O0Ooo
   try :
    if 20 - 20: OoOoOO00 / I1ii11iIi11i * IiII
    Oo0 = IiiiiI1i1Iii
    if 96 - 96: ooOoO0o % o00O0oo % IiII * ooOoO0o / I1Ii111
   except :
    pass
  OoOO0o = i1II1 ( Oo0 )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 13 - 13: Oo0Ooo - OOooOOo
   except :
    pass
 except :
  pass
  if 100 - 100: II111iiii / II111iiii
def o00iIiiiII ( ) :
 if 5 - 5: OoO0O00 / Ii1I % ooOoO0o % OOooOOo * oO00OO0oo0 + Oo0Ooo
 try :
  if 11 - 11: i1iiI11I % II111iiii % IiII . III1i1i
  OoOO0o = i1II1 ( ooOoO00 )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 92 - 92: o0oOOo0O0Ooo
   try :
    if 45 - 45: I1IiiI % I1ii11iIi11i - oO00OO0oo0 . OOooOOo
    I1II = IiiiiI1i1Iii
    if 9 - 9: oO0o % OoO0O00 - o00O0oo
   except :
    pass
  OoOO0o = i1II1 ( I1II )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 43 - 43: OOooOOo % OOooOOo
   except :
    pass
 except :
  pass
  if 46 - 46: oO0o % Oo0Ooo . oO00OO0oo0 . I1IiiI * iiIi / OoO0O00
def II1iI1IIi ( ) :
 if 41 - 41: I1ii11iIi11i - i1iiI11I % o0oOOo0O0Ooo . i1iiI11I - ooOoO0o
 try :
  if 45 - 45: o00O0oo - I1Ii111
  OoOO0o = i1II1 ( o00O0O )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 70 - 70: OOooOOo % I1ii11iIi11i / I1ii11iIi11i . ooOoO0o % iiIi . o0oOOo0O0Ooo
   try :
    if 10 - 10: o00O0oo - II111iiii . iII111i % OoOoOO00
    OooOOOoOoo0O0 = IiiiiI1i1Iii
    if 81 - 81: III1i1i - Ii1I - oO0o - o00O0oo / I1Ii111 % ooOoO0o
   except :
    pass
  OoOO0o = i1II1 ( OooOOOoOoo0O0 )
  i11i1 = re . compile ( oO0000OOo00 ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO in i11i1 :
   try :
    oO0Oo ( oOoOOo0O , OOOooo , OooO0OO )
    if 72 - 72: I1IiiI . I11i * oO0o + iII111i - Ii1I
   except :
    pass
    if 40 - 40: OOooOOo + OOooOOo
 except :
  pass
  if 94 - 94: oO00OO0oo0 * Oo0Ooo . ooOoO0o
  if 13 - 13: Oo0Ooo * I11i / i1iiI11I % iiIi + IiII
  if 41 - 41: iII111i
def oO0Oo ( thumb , name , url ) :
 if 5 - 5: oO0o
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( i1I1ii ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   OO0oOOoo ( name , url , '' , i1ii1iIII , O0oOO0o0 )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 100 - 100: o00O0oo + Oo0Ooo
  if 'tvg-logo' in thumb :
   thumb = re . compile ( i1I1ii ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 59 - 59: III1i1i
   oOoO0OOO00O ( name , url , 4 , Oo00OOo00O , O0oOO0o0 )
   if 73 - 73: Ii1I % OOooOOo + III1i1i + I1ii11iIi11i
  else :
   if 80 - 80: OoOoOO00 + Ii1I + III1i1i * ooOoO0o
   oOoO0OOO00O ( name , url , 4 , Oo00OOo00O , O0oOO0o0 )
   if 65 - 65: iII111i % ooOoO0o % Oo0Ooo - OoO0O00 - iII111i - I1IiiI
def iII1i11 ( name , url , thumb , id , trailer ) :
 if 58 - 58: III1i1i + Oo0Ooo
 if 94 - 94: o00O0oo . OoOoOO00
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 71 - 71: oO00OO0oo0 + OOooOOo - III1i1i . OOooOOo . III1i1i + I1ii11iIi11i
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( i1I1ii ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   OO0oOOoo ( name , url , '' , i1ii1iIII , O0oOO0o0 )
 else :
  Oo0oOOo = oo000 . getSetting ( 'Fontcolor' )
  if 26 - 26: I1IiiI
  name = '[COLOR %s]' % Oo0oOOo + name + '[/COLOR]'
  if 17 - 17: o0oOOo0O0Ooo
  if 'tvg-logo' in thumb :
   thumb = re . compile ( i1I1ii ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   O0OOO0OOoO0O = oo000 . getSetting ( 'selecton' )
   if O0OOO0OOoO0O == 'true' :
    if 9 - 9: OoO0O00 + IiII
    iIiI1ii ( name , url , 1 , thumb , thumb , id , trailer )
    if 76 - 76: o00O0oo + Oo0Ooo + I11i . OOooOOo
   else :
    if 49 - 49: III1i1i / iiIi / I1Ii111
    iIiI1ii ( name , url , 130 , thumb , thumb , id , trailer )
    if 25 - 25: I1ii11iIi11i % I1IiiI + OoOoOO00 - iiIi
  else :
   if 38 - 38: Ii1I % i1iiI11I + II111iiii + oO00OO0oo0 + iiIi / II111iiii
   if O0OOO0OOoO0O == 'true' :
    if 94 - 94: oO00OO0oo0 - oO0o + IiII
    iIiI1ii ( name , url , 1 , thumb , thumb , id , trailer )
    if 59 - 59: ooOoO0o . I1ii11iIi11i - Oo0Ooo + Oo0Ooo
   else :
    if 56 - 56: IiII + iiIi
    iIiI1ii ( name , url , 130 , thumb , thumb , id , trailer )
    if 32 - 32: o0oOOo0O0Ooo + I11i % iiIi / I11i + iII111i
    if 2 - 2: II111iiii - i1iiI11I + OOooOOo % ooOoO0o * o00O0oo
def Ooo000O00 ( name , trailer ) :
 if 36 - 36: I1Ii111 % II111iiii
 if IIIIii == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Realstream, Reproduciendo Trailer de: [COLOR green]" + name + "[/COLOR] ,5000)" )
  if 47 - 47: OoOoOO00 + o0oOOo0O0Ooo . oO0o * IiII . ooOoO0o / OoOoOO00
  OooO0OO = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  i11ii = OooO0OO
  oOOOOO0Ooooo = xbmcgui . ListItem ( name , trailer , path = i11ii )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOOOOO0Ooooo )
 else :
  OooO0OO = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  i11ii = OooO0OO
  oOOOOO0Ooooo = xbmcgui . ListItem ( name , trailer , path = i11ii )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOOOOO0Ooooo )
  if 57 - 57: o00O0oo - OoO0O00
  if 68 - 68: Ii1I % iII111i / i1iiI11I + i1iiI11I - i1iiI11I . OOooOOo
def oOO00ooOOo ( trailer ) :
 if 20 - 20: iII111i
 OooO0OO = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
 i11ii = OooO0OO
 oOOOOO0Ooooo = xbmcgui . ListItem ( trailer , path = i11ii )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOOOOO0Ooooo )
 return
 if 3 - 3: OOooOOo * OoOoOO00 . I1ii11iIi11i . I1IiiI - I11i
 if 81 - 81: I1ii11iIi11i - Oo0Ooo / I1ii11iIi11i / I1IiiI
def I1I1IIiiii1ii ( name , url ) :
 import urlresolver
 from urlresolver import common
 if 92 - 92: IiII / I1Ii111 . iII111i
 oo0OOOoOo = urlresolver . HostedMediaFile ( url )
 if 30 - 30: o00O0oo . iII111i / I1Ii111
 if not oo0OOOoOo :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
  if 2 - 2: III1i1i % I1ii11iIi11i - i1iiI11I
  return False
  if 79 - 79: OoO0O00 / iII111i . I1IiiI
  if 79 - 79: IiII - o0oOOo0O0Ooo
 try :
  i1IiiI1iIi = oo0OOOoOo . resolve ( )
  if not i1IiiI1iIi or not isinstance ( i1IiiI1iIi , basestring ) :
   try : oOOo00O0OOOo = i1IiiI1iIi . msg
   except : oOOo00O0OOOo = url
   raise Exception ( oOOo00O0OOOo )
 except Exception as IIiI1 :
  try : oOOo00O0OOOo = str ( IIiI1 )
  except : oOOo00O0OOOo = url
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,5000)" )
  if 43 - 43: OoOoOO00 + I1IiiI % OOooOOo / o00O0oo * I1ii11iIi11i
  return False
  if 89 - 89: I1ii11iIi11i . oO0o + iII111i . I1IiiI % Ii1I
 IIIIii = oo000 . getSetting ( 'notificar' )
 if IIIIii == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
 ooi1II1I = xbmcgui . ListItem ( path = i1IiiI1iIi )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooi1II1I )
 if 84 - 84: OoO0O00 + i1iiI11I / I1ii11iIi11i % I1Ii111 % iII111i * I1ii11iIi11i
def OOoO0oooo ( name , url ) :
 if 24 - 24: ooOoO0o / I1ii11iIi11i * OoOoOO00 % OoO0O00
 if 99 - 99: II111iiii . o0oOOo0O0Ooo . OoO0O00
 if 'https://www.rapidvideo.com/v/' in url :
  if 59 - 59: II111iiii . OoO0O00 / ooOoO0o * iII111i + OoO0O00
  OoOO0o = i1II1 ( url )
  i11i1 = re . compile ( 'rapidvideo' ) . findall ( OoOO0o )
  for url in i11i1 :
   if 3 - 3: II111iiii * oO0o % Oo0Ooo % I1ii11iIi11i * oO00OO0oo0 / I1Ii111
   if 95 - 95: III1i1i * I1IiiI * i1iiI11I . OoO0O00 % oO0o + iII111i
   try :
    IIIIii = oo000 . getSetting ( 'notificar' )
    if IIIIii == 'true' :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    ooi1II1I = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooi1II1I )
    if 98 - 98: IiII . OoO0O00
   except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 54 - 54: I1IiiI / III1i1i % iiIi * OoOoOO00 * I1IiiI
   if 48 - 48: Ii1I . IiII % I11i - I11i
 else :
  if 33 - 33: ooOoO0o % o0oOOo0O0Ooo + OOooOOo
  import urlresolver
  from urlresolver import common
  if 93 - 93: OoOoOO00 . III1i1i / I1ii11iIi11i + III1i1i
  oo0OOOoOo = urlresolver . HostedMediaFile ( url )
  if 58 - 58: iII111i + I1IiiI . oO0o + I11i - OOooOOo - I11i
  if not oo0OOOoOo :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 41 - 41: oO0o / OoOoOO00 / oO0o - oO00OO0oo0 . Ii1I
   if 65 - 65: I1IiiI * II111iiii . OoO0O00 / I1ii11iIi11i / oO00OO0oo0
  try :
   i1IiiI1iIi = oo0OOOoOo . resolve ( )
   if not i1IiiI1iIi or not isinstance ( i1IiiI1iIi , basestring ) :
    try : oOOo00O0OOOo = i1IiiI1iIi . msg
    except : oOOo00O0OOOo = url
    raise Exception ( oOOo00O0OOOo )
  except Exception as IIiI1 :
   try : oOOo00O0OOOo = str ( IIiI1 )
   except : oOOo00O0OOOo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 69 - 69: iiIi % iiIi
  IIIIii = oo000 . getSetting ( 'notificar' )
  if IIIIii == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  ooi1II1I = xbmcgui . ListItem ( path = i1IiiI1iIi )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooi1II1I )
  if 76 - 76: II111iiii * oO00OO0oo0 / OOooOOo % iII111i + I1Ii111
 return
 if 48 - 48: Oo0Ooo % OoOoOO00 + I11i % Ii1I
 if 79 - 79: I11i % I1ii11iIi11i % o00O0oo / OoOoOO00 % OOooOOo
 if 56 - 56: Oo0Ooo - II111iiii * oO00OO0oo0
def o0O0Ooo ( name , url ) :
 if 79 - 79: iiIi . IiII / IiII - iiIi * oO0o / Ii1I
 i1IiiI1iIi = url
 IIIIii = oo000 . getSetting ( 'notificar' )
 if IIIIii == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  ooi1II1I = xbmcgui . ListItem ( path = i1IiiI1iIi )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooi1II1I )
 else :
  ooi1II1I = xbmcgui . ListItem ( path = i1IiiI1iIi )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooi1II1I )
 return
 if 19 - 19: iII111i
def IiIIii1iiI ( name , url ) :
 if 7 - 7: Ii1I
 if 18 - 18: OoO0O00 + Ii1I . I1IiiI + III1i1i * OoOoOO00 . OOooOOo
 if '[Youtube]' in name :
  if 71 - 71: i1iiI11I - Ii1I - I1Ii111
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 28 - 28: Oo0Ooo
  try :
   IIIIii = oo000 . getSetting ( 'notificar' )
   if IIIIii == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    ooi1II1I = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooi1II1I )
    if 7 - 7: Ii1I % III1i1i * I11i
    if 58 - 58: III1i1i / ooOoO0o + o0oOOo0O0Ooo % oO00OO0oo0 - OoO0O00
    if 25 - 25: I11i % OoO0O00 * oO0o - OoOoOO00 * o0oOOo0O0Ooo * IiII
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 30 - 30: ooOoO0o % I11i / iII111i * I1IiiI * o00O0oo . I1ii11iIi11i
  if 46 - 46: I11i - I1IiiI
 else :
  if 70 - 70: ooOoO0o + oO0o * Oo0Ooo . I1ii11iIi11i * ooOoO0o
  import xbmcgui
  import urlresolver
  from urlresolver import common
  if 49 - 49: Ii1I
  oo0OOOoOo = urlresolver . HostedMediaFile ( url )
  if 25 - 25: oO00OO0oo0 . OoO0O00 * Oo0Ooo . Ii1I / I1IiiI + o00O0oo
  if not oo0OOOoOo :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 68 - 68: oO0o
  import resolveurl as urlresolver
  if 22 - 22: I1Ii111
  oo0OOOoOo = urlresolver . HostedMediaFile ( url )
  if 22 - 22: oO00OO0oo0 * ooOoO0o - oO0o * I1IiiI / II111iiii
  if 78 - 78: oO0o * I1IiiI / iiIi + OoO0O00 + I1Ii111
  if not oo0OOOoOo :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 23 - 23: oO00OO0oo0 % OoO0O00 / Oo0Ooo + iII111i / OoOoOO00 / Ii1I
  try :
   i1IiiI1iIi = oo0OOOoOo . resolve ( )
   if not i1IiiI1iIi or not isinstance ( i1IiiI1iIi , basestring ) :
    try : oOOo00O0OOOo = i1IiiI1iIi . msg
    except : oOOo00O0OOOo = url
    raise Exception ( oOOo00O0OOOo )
  except Exception as IIiI1 :
   try : oOOo00O0OOOo = str ( IIiI1 )
   except : oOOo00O0OOOo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 94 - 94: OoOoOO00
   if 36 - 36: I1ii11iIi11i + oO0o
   if 46 - 46: oO00OO0oo0
  IIIIii = oo000 . getSetting ( 'notificar' )
  if IIIIii == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 65 - 65: OoOoOO00 . iII111i / iiIi
   if '[Realstream]' in name :
    if 11 - 11: III1i1i * iiIi / iiIi - I1Ii111
    OO00Oo = oo000 . getSetting ( 'restante' )
    if OO00Oo == 'true' :
     o0o0o0o0 = xbmcgui . Dialog ( )
     ii1Io0OOoOoO00 = o0o0o0o0 . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 68 - 68: I1ii11iIi11i % III1i1i - III1i1i / I1ii11iIi11i + iII111i - oO0o
   ooi1II1I = xbmcgui . ListItem ( path = i1IiiI1iIi )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooi1II1I )
   if 65 - 65: iiIi - OoOoOO00
   if 62 - 62: ooOoO0o / IiII % oO0o . OoO0O00 / II111iiii / i1iiI11I
   if 60 - 60: I1ii11iIi11i % IiII / Ii1I % IiII * II111iiii / oO00OO0oo0
 return
 if 34 - 34: i1iiI11I - I1Ii111
 if 25 - 25: IiII % I1ii11iIi11i + II111iiii + I1IiiI * OoO0O00
 if 64 - 64: OoOoOO00
def I1ii1i1iiii ( name , url ) :
 if 45 - 45: o00O0oo / iiIi . OoO0O00 + OOooOOo
 if 51 - 51: oO00OO0oo0 % II111iiii % III1i1i + i1iiI11I % iII111i
 if '[Youtube]' in name :
  if 16 - 16: I11i / oO0o + I1IiiI - I11i . OoO0O00
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 19 - 19: Ii1I
  try :
   IIIIii = oo000 . getSetting ( 'notificar' )
   if IIIIii == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    ooi1II1I = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooi1II1I )
    if 73 - 73: i1iiI11I * oO0o * I11i
    if 65 - 65: II111iiii + oO0o * OoO0O00 - OOooOOo
    if 26 - 26: Ii1I % I1Ii111 + I1Ii111 % ooOoO0o * II111iiii / oO00OO0oo0
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 64 - 64: IiII % I11i / o0oOOo0O0Ooo % iiIi - oO00OO0oo0
 else :
  if 2 - 2: i1iiI11I - iII111i + Ii1I * OOooOOo / oO00OO0oo0
  import resolveurl
  if 26 - 26: I1Ii111 * oO0o
  oo0OOOoOo = urlresolver . HostedMediaFile ( url )
  if 31 - 31: ooOoO0o * IiII . o00O0oo
  if 35 - 35: ooOoO0o
  if not oo0OOOoOo :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 94 - 94: iiIi / II111iiii % I1IiiI
  try :
   i1IiiI1iIi = oo0OOOoOo . resolve ( )
   if not i1IiiI1iIi or not isinstance ( i1IiiI1iIi , basestring ) :
    try : oOOo00O0OOOo = i1IiiI1iIi . msg
    except : oOOo00O0OOOo = url
    raise Exception ( oOOo00O0OOOo )
  except Exception as IIiI1 :
   try : oOOo00O0OOOo = str ( IIiI1 )
   except : oOOo00O0OOOo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 70 - 70: ooOoO0o - oO0o / OoO0O00 % OoO0O00
   if 95 - 95: OoO0O00 % OoO0O00 . o00O0oo
   if 26 - 26: IiII + III1i1i - o0oOOo0O0Ooo . o0oOOo0O0Ooo + iII111i + I11i
  IIIIii = oo000 . getSetting ( 'notificar' )
  if IIIIii == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 68 - 68: I1IiiI
   if '[Realstream]' in name :
    if 76 - 76: iII111i
    OO00Oo = oo000 . getSetting ( 'restante' )
    if OO00Oo == 'true' :
     o0o0o0o0 = xbmcgui . Dialog ( )
     ii1Io0OOoOoO00 = o0o0o0o0 . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 99 - 99: Ii1I
   ooi1II1I = xbmcgui . ListItem ( path = i1IiiI1iIi )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooi1II1I )
   if 1 - 1: o00O0oo * I11i * OOooOOo + oO0o
   if 90 - 90: i1iiI11I % oO0o - oO0o . Oo0Ooo / I1Ii111 + ooOoO0o
   if 89 - 89: IiII
 return
 if 87 - 87: oO00OO0oo0 % oO0o
 if 62 - 62: OOooOOo + iiIi / oO00OO0oo0 * II111iiii
 if 37 - 37: oO00OO0oo0
def iIIiI1111 ( name , url ) :
 if 91 - 91: OoO0O00 / Ii1I . III1i1i - Oo0Ooo - o00O0oo
 if 31 - 31: III1i1i - OOooOOo / I1Ii111 . OoOoOO00 / o00O0oo
 if '[Youtube]' in name :
  if 66 - 66: OOooOOo
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 72 - 72: i1iiI11I
  try :
   IIIIii = oo000 . getSetting ( 'notificar' )
   if IIIIii == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    ooi1II1I = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooi1II1I )
    if 91 - 91: o0oOOo0O0Ooo / III1i1i + Oo0Ooo . ooOoO0o - I1IiiI
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 70 - 70: o00O0oo * IiII - ooOoO0o + oO0o % iII111i - III1i1i
 else :
  if 81 - 81: I1IiiI . I1IiiI
  if 'https://team.com' in url :
   if 75 - 75: Oo0Ooo % III1i1i + iII111i * I1IiiI . oO00OO0oo0 - iiIi
   url = url . replace ( 'https://team.com' , 'https://verystream.com' )
   if 32 - 32: o00O0oo % IiII - OoOoOO00
  if 'https://mybox.com' in url :
   if 40 - 40: Oo0Ooo + oO00OO0oo0 * I11i + IiII
   url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
   if 15 - 15: ooOoO0o % I1ii11iIi11i - Oo0Ooo * iiIi
  if 'https://drive.com' in url :
   if 71 - 71: I11i % oO0o % iiIi
   url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
   if 34 - 34: ooOoO0o / ooOoO0o % III1i1i . I11i / oO0o
  if 'https://vid.co' in url :
   if 99 - 99: iiIi * I1ii11iIi11i - iiIi % o00O0oo
   url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
   if 40 - 40: I1Ii111 / III1i1i / Oo0Ooo + o00O0oo
  if 'https://limited.to' in url :
   if 59 - 59: ooOoO0o * OoO0O00 + I1Ii111 . Oo0Ooo / OoOoOO00
   url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
   if 75 - 75: ooOoO0o . I1Ii111 - Oo0Ooo * OOooOOo * oO00OO0oo0
  import resolveurl
  if 93 - 93: iiIi
  oo0OOOoOo = urlresolver . HostedMediaFile ( url )
  if 18 - 18: iiIi
  if 66 - 66: IiII * II111iiii + I11i / I1Ii111
  if not oo0OOOoOo :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no encontrado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 96 - 96: I1Ii111 + I1Ii111 % III1i1i % I1Ii111
  try :
   i1IiiI1iIi = oo0OOOoOo . resolve ( )
   if not i1IiiI1iIi or not isinstance ( i1IiiI1iIi , basestring ) :
    try : oOOo00O0OOOo = i1IiiI1iIi . msg
    except : oOOo00O0OOOo = url
    raise Exception ( oOOo00O0OOOo )
  except Exception as IIiI1 :
   try : oOOo00O0OOOo = str ( IIiI1 )
   except : oOOo00O0OOOo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace borrado, o no encontrado. Prueba a reiniciar el router o poner una VPN.[/COLOR]  ,5000)" )
   return False
   if 28 - 28: Oo0Ooo + I11i . Ii1I % II111iiii
   if 58 - 58: ooOoO0o / OoO0O00 % IiII + OOooOOo
   if 58 - 58: I1IiiI
   IIIIii = oo000 . getSetting ( 'notificar' )
   if IIIIii == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
    if 91 - 91: oO00OO0oo0 / iII111i . oO00OO0oo0 - Ii1I + iII111i
    if '[Realstream]' or '[Mybox]' in name :
     OO00Oo = oo000 . getSetting ( 'restante' )
    elif OO00Oo == 'true' :
     o0o0o0o0 = xbmcgui . Dialog ( )
     ii1Io0OOoOoO00 = o0o0o0o0 . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 72 - 72: o00O0oo . III1i1i * iII111i / iII111i / oO00OO0oo0
  ooi1II1I = xbmcgui . ListItem ( path = i1IiiI1iIi )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooi1II1I )
  if 13 - 13: OoOoOO00
 return
 if 17 - 17: II111iiii * Ii1I * Ii1I + OOooOOo
def o0O0O ( name , url ) :
 if 45 - 45: Ii1I % oO0o * OoOoOO00 - I1IiiI
 if 82 - 82: o0oOOo0O0Ooo / oO00OO0oo0
 if '[Youtube]' in name :
  if 96 - 96: oO0o / IiII . o0oOOo0O0Ooo . oO0o
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 91 - 91: o0oOOo0O0Ooo . I1Ii111 + Ii1I
  try :
   IIIIii = oo000 . getSetting ( 'notificar' )
   if IIIIii == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    ooi1II1I = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooi1II1I )
    if 8 - 8: I1Ii111 * oO0o / oO00OO0oo0 - OOooOOo - OoO0O00
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 100 - 100: IiII . Oo0Ooo . Oo0Ooo
 else :
  if 55 - 55: IiII
  if 'https://team.com' in url :
   if 37 - 37: III1i1i / II111iiii / oO0o
   url = url . replace ( 'https://team.com' , 'https://verystream.com' )
   if 97 - 97: i1iiI11I . ooOoO0o / I1ii11iIi11i
  if 'https://mybox.com' in url :
   if 83 - 83: ooOoO0o - iII111i * IiII
   url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
   if 90 - 90: oO0o * I1ii11iIi11i
  if 'https://drive.com' in url :
   if 75 - 75: iII111i - I11i * II111iiii . OoO0O00 - oO0o . ooOoO0o
   url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
   if 6 - 6: ooOoO0o * IiII / OoO0O00 % o00O0oo * Ii1I
  if 'https://vid.co' in url :
   if 28 - 28: III1i1i * I1ii11iIi11i % III1i1i
   url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
   if 95 - 95: I1IiiI / ooOoO0o . i1iiI11I
  if 'https://limited.to' in url :
   if 17 - 17: ooOoO0o
   url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
   if 56 - 56: iiIi * Ii1I + ooOoO0o
  import resolveurl
  if 48 - 48: III1i1i * OOooOOo % i1iiI11I - ooOoO0o
  oo0OOOoOo = urlresolver . HostedMediaFile ( url )
  IIiiIIi1 = xbmcgui . DialogProgress ( )
  IIiiIIi1 . create ( 'Realstream:' , 'Conectando al servidor ... ' )
  IIiiIIi1 . update ( 20 , 'Por favor, espere ...' )
  xbmc . sleep ( 500 )
  if 72 - 72: OoOoOO00 % iiIi % III1i1i % IiII - IiII
  if not oo0OOOoOo :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no encontrado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 97 - 97: Ii1I * I1IiiI / Ii1I * OOooOOo * oO0o
  try :
   if 38 - 38: i1iiI11I
   IIiiIIi1 . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
   xbmc . sleep ( 500 )
   i1IiiI1iIi = oo0OOOoOo . resolve ( )
   if not i1IiiI1iIi or not isinstance ( i1IiiI1iIi , basestring ) :
    try : oOOo00O0OOOo = i1IiiI1iIi . msg
    except : oOOo00O0OOOo = url
    raise Exception ( oOOo00O0OOOo )
  except Exception as IIiI1 :
   try : oOOo00O0OOOo = str ( IIiI1 )
   except : oOOo00O0OOOo = url
   IIiiIIi1 . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado, o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
   IIiiIIi1 . close ( )
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace borrado, o no encontrado. Prueba a reiniciar el router o poner una VPN.[/COLOR]  ,5000)" )
   return False
   if 25 - 25: Oo0Ooo % o0oOOo0O0Ooo / ooOoO0o / iII111i
  IIiiIIi1 . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
  xbmc . sleep ( 500 )
  IIiiIIi1 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
  xbmc . sleep ( 500 )
  IIiiIIi1 . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
  xbmc . sleep ( 500 )
  IIiiIIi1 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
  IIiiIIi1 . close ( )
  IIIIii = oo000 . getSetting ( 'notificar' )
  if IIIIii == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
   if 22 - 22: IiII * oO00OO0oo0
  if '[Realstream]' or '[Mybox]' in name :
   OO00Oo = oo000 . getSetting ( 'restante' )
  elif OO00Oo == 'true' :
   o0o0o0o0 = xbmcgui . Dialog ( )
   ii1Io0OOoOoO00 = o0o0o0o0 . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
  ooi1II1I = xbmcgui . ListItem ( path = i1IiiI1iIi )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ooi1II1I )
  if 4 - 4: I11i - IiII + I1ii11iIi11i
 return
 if 36 - 36: III1i1i
def iIi ( ) :
 if 52 - 52: Oo0Ooo
 if 49 - 49: I1Ii111
 iIi1iIII = [ ]
 IiiI = sys . argv [ 2 ]
 if len ( IiiI ) >= 2 :
  OoOoO00o00 = sys . argv [ 2 ]
  OOooooO0o0O0 = OoOoO00o00 . replace ( '?' , '' )
  if ( OoOoO00o00 [ len ( OoOoO00o00 ) - 1 ] == '/' ) :
   OoOoO00o00 = OoOoO00o00 [ 0 : len ( OoOoO00o00 ) - 2 ]
  oO0oo = OOooooO0o0O0 . split ( '&' )
  iIi1iIII = { }
  for o00o0o000Oo in range ( len ( oO0oo ) ) :
   Oooo00OOo = { }
   Oooo00OOo = oO0oo [ o00o0o000Oo ] . split ( '=' )
   if ( len ( Oooo00OOo ) ) == 2 :
    iIi1iIII [ Oooo00OOo [ 0 ] ] = Oooo00OOo [ 1 ]
 return iIi1iIII
 if 6 - 6: IiII / I1ii11iIi11i / I11i
 if 51 - 51: o0oOOo0O0Ooo / oO0o / I1ii11iIi11i + II111iiii
def iiI1ii1Iii ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  import urlresolver
  xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
  if 2 - 2: I1ii11iIi11i * oO0o % Ii1I % oO0o
def o0o0oO ( ) :
 o0o0o0o0 = xbmcgui . Dialog ( )
 list = (
 O00o ,
 o0o0ooOo00
 )
 if 91 - 91: OOooOOo * i1iiI11I % OOooOOo . Ii1I * iII111i . I1Ii111
 OOOIiiiii1iI = o0o0o0o0 . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=%s]Accede a themoviedb.com[/COLOR]' % Oo0OoO00oOO0o ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 13 - 13: iII111i
 if OOOIiiiii1iI :
  if 80 - 80: oO0o % III1i1i % OoO0O00 * oO0o % o00O0oo
  if OOOIiiiii1iI < 0 :
   return
  oO0OO0 = list [ OOOIiiiii1iI - 2 ]
  return oO0OO0 ( )
 else :
  oO0OO0 = list [ OOOIiiiii1iI ]
  return oO0OO0 ( )
 return
 if 41 - 41: OoO0O00 / OoOoOO00
def II111Ii1i1 ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 70 - 70: I11i % Ii1I % OoOoOO00 / iII111i % II111iiii / OoOoOO00
oOooO0OOOoO000 = II111Ii1i1 ( )
if 4 - 4: III1i1i
def O00o ( ) :
 if oOooO0OOOoO000 == 'android' :
  oOOOoo = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  oOOOoo = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 93 - 93: IiII % OoOoOO00
  if 83 - 83: I1ii11iIi11i . oO0o - ooOoO0o . Ii1I
def o0o0ooOo00 ( ) :
 if 73 - 73: I1ii11iIi11i - oO00OO0oo0 . oO00OO0oo0
 main ( )
 if 22 - 22: iiIi / iiIi - o00O0oo % ooOoO0o . I1Ii111 + III1i1i
 if 64 - 64: OoOoOO00 % iII111i / o00O0oo % OoO0O00
 if 24 - 24: i1iiI11I + OoO0O00 . III1i1i / I11i / ooOoO0o
def ooOoo ( ) :
 o0o0o0o0 = xbmcgui . Dialog ( )
 I1Iiiiiii = (
 OO0 ,
 Oo00Oo
 )
 if 25 - 25: Oo0Ooo
 OOOIiiiii1iI = o0o0o0o0 . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 63 - 63: iiIi
 if OOOIiiiii1iI :
  if 96 - 96: ooOoO0o
  if OOOIiiiii1iI < 0 :
   return
  oO0OO0 = I1Iiiiiii [ OOOIiiiii1iI - 2 ]
  return oO0OO0 ( )
 else :
  oO0OO0 = I1Iiiiiii [ OOOIiiiii1iI ]
  return oO0OO0 ( )
 return
 if 34 - 34: I11i / OOooOOo - I1ii11iIi11i . I1IiiI . I1Ii111
def II111Ii1i1 ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 63 - 63: oO00OO0oo0
oOooO0OOOoO000 = II111Ii1i1 ( )
if 11 - 11: oO00OO0oo0 - Oo0Ooo
def OO0 ( ) :
 if oOooO0OOOoO000 == 'android' :
  oOOOoo = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  oOOOoo = webbrowser . open ( 'https://olpair.com/' )
  if 92 - 92: OOooOOo
  if 15 - 15: III1i1i / III1i1i + Oo0Ooo % OoO0O00
def Oo00Oo ( ) :
 if 12 - 12: iiIi
 main ( )
 if 36 - 36: i1iiI11I . III1i1i * OoO0O00 - Ii1I
 if 60 - 60: I1Ii111 . oO00OO0oo0 / Oo0Ooo + I1Ii111 * i1iiI11I
def Oo ( name , url , id , trailer ) :
 o0o0o0o0 = xbmcgui . Dialog ( )
 I1Iiiiiii = (
 ooO00OoO0 ,
 iiIiI1I1I1IiI ,
 I1IIII11 ,
 o0o0oO ,
 o0I1iI111ii111i
 )
 if 83 - 83: Oo0Ooo
 OOOIiiiii1iI = o0o0o0o0 . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % Oo0OoO00oOO0o ,

 '[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % Oo0OoO00oOO0o ,

 '[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % Oo0OoO00oOO0o ,

 '[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % Oo0OoO00oOO0o ,

 '[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % Oo0OoO00oOO0o ] )
 if 97 - 97: II111iiii + oO0o * I1Ii111 % oO00OO0oo0 . III1i1i
 if OOOIiiiii1iI :
  if 4 - 4: I1IiiI . oO00OO0oo0 - Oo0Ooo
  if OOOIiiiii1iI < 0 :
   return
  oO0OO0 = I1Iiiiiii [ OOOIiiiii1iI - 5 ]
  return oO0OO0 ( )
 else :
  oO0OO0 = I1Iiiiiii [ OOOIiiiii1iI ]
  return oO0OO0 ( )
 return
 if 19 - 19: I1Ii111 % OOooOOo / o00O0oo + o0oOOo0O0Ooo % OoO0O00
 if 89 - 89: o00O0oo
 if 51 - 51: oO00OO0oo0
def ooO00OoO0 ( ) :
 if 68 - 68: oO00OO0oo0 - Ii1I * OOooOOo % iiIi . iiIi - Oo0Ooo
 o0O0O ( OOOooo , OooO0OO )
 if 22 - 22: OoO0O00 / iII111i % oO00OO0oo0 * I11i
def iiIiI1I1I1IiI ( ) :
 if 32 - 32: OoO0O00 % IiII % Oo0Ooo / I1IiiI
 Ooo000O00 ( OOOooo , o0OOo0o0O0O )
 if 61 - 61: o0oOOo0O0Ooo . I1IiiI - o00O0oo - iII111i / II111iiii - o0oOOo0O0Ooo
def I1IIII11 ( ) :
 if 98 - 98: o00O0oo - I1ii11iIi11i . II111iiii * oO0o
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  i111 = id
  if 71 - 71: OOooOOo
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % i111 )
  if 75 - 75: oO00OO0oo0
 if IIIIii == 'true' :
  if 16 - 16: iII111i + o0oOOo0O0Ooo * I11i . III1i1i
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + OOOooo + "[/COLOR] ,5000)" )
  if 10 - 10: oO00OO0oo0 * o00O0oo - iiIi . ooOoO0o - I1Ii111
def oOO0O00OoOo ( ) :
 if 16 - 16: oO00OO0oo0 + III1i1i . iiIi - o00O0oo
 o0o0oO ( )
 if 9 - 9: I1ii11iIi11i
def o0I1iI111ii111i ( ) :
 if 94 - 94: o0oOOo0O0Ooo
 Iiiiii111i1ii ( )
def OO0oOOoo ( name , url , mode , iconimage , fanart ) :
 if 37 - 37: OoO0O00
 OOOooo0OooOoO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 ii1Io0OOoOoO00 = True
 oOoOOOo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 oOoOOOo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 oOoOOOo . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  OOOooo0OooOoO = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  ii1Io0OOoOoO00 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOOooo0OooOoO , listitem = oOoOOOo , isFolder = True )
  return ii1Io0OOoOoO00
 ii1Io0OOoOoO00 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOOooo0OooOoO , listitem = oOoOOOo , isFolder = True )
 return ii1Io0OOoOoO00
 if 78 - 78: o0oOOo0O0Ooo + III1i1i
def iIiI1ii ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 66 - 66: Oo0Ooo
 i1 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 57 - 57: III1i1i
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 IiI11I1Ii11II = [ ]
 if 75 - 75: II111iiii % III1i1i
 IiI11I1Ii11II . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 OOOooo0OooOoO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 oOoOOOo = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 oOoOOOo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 oOoOOOo . setProperty ( 'fanart_image' , fanart )
 oOoOOOo . setProperty ( 'IsPlayable' , 'true' )
 if 30 - 30: oO0o
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  IiI11I1Ii11II . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 8 - 8: I1IiiI + IiII + i1iiI11I
  oOoOOOo . addContextMenuItems ( IiI11I1Ii11II , replaceItems = True )
 ii1Io0OOoOoO00 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOOooo0OooOoO , listitem = oOoOOOo )
 return ii1Io0OOoOoO00
 if 47 - 47: ooOoO0o
def oOoO0OOO00O ( name , url , mode , iconimage , fanart ) :
 if 92 - 92: OoO0O00 % I1ii11iIi11i / I11i * I11i % II111iiii / OoO0O00
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 47 - 47: II111iiii / oO0o - oO0o * OOooOOo
 OOOooo0OooOoO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 oOoOOOo = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 oOoOOOo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 oOoOOOo . setProperty ( 'fanart_image' , fanart )
 oOoOOOo . setProperty ( 'IsPlayable' , 'true' )
 ii1Io0OOoOoO00 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOOooo0OooOoO , listitem = oOoOOOo )
 return ii1Io0OOoOoO00
 if 48 - 48: III1i1i
def OOooO ( name , url , mode ) :
 if 30 - 30: Ii1I * o0oOOo0O0Ooo % I1IiiI % I1ii11iIi11i * o00O0oo
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 17 - 17: I11i + OoO0O00 % I1Ii111
 OOOooo0OooOoO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 oOoOOOo = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = Oo00OOo00O )
 oOoOOOo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 oOoOOOo . setProperty ( 'fanart_image' , O0oOO0o0 )
 oOoOOOo . setProperty ( 'IsPlayable' , 'true' )
 ii1Io0OOoOoO00 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOOooo0OooOoO , listitem = oOoOOOo )
 return ii1Io0OOoOoO00
 if 36 - 36: II111iiii + iII111i % I1Ii111 . I1ii11iIi11i - iiIi
def OooOo0o0OO ( name , url , mode , iconimage ) :
 OOOooo0OooOoO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 ii1Io0OOoOoO00 = True
 oOoOOOo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 ii1Io0OOoOoO00 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOOooo0OooOoO , listitem = oOoOOOo , isFolder = True )
 return ii1Io0OOoOoO00
 if 1 - 1: Oo0Ooo % iiIi + I1IiiI
def IIiII11 ( ) :
 if 58 - 58: oO00OO0oo0
 if 2 - 2: III1i1i - IiII % OOooOOo + Ii1I + o00O0oo - Oo0Ooo
 if 18 - 18: iII111i / oO0o - oO00OO0oo0
 i11III1111iIi = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 i11III1111iIi . doModal ( )
 if ( i11III1111iIi . isConfirmed ( ) ) :
  if 69 - 69: IiII / III1i1i * iiIi
  iI11 = urllib . quote_plus ( i11III1111iIi . getText ( ) ) . replace ( '+' , ' ' )
  if 81 - 81: IiII
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 62 - 62: o00O0oo + I1IiiI * OOooOOo
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % iI11 )
    if 59 - 59: o0oOOo0O0Ooo
    if IIIIii == 'true' :
     if 43 - 43: oO0o + OoO0O00
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + OOOooo + "[/COLOR] ,10000)" )
     if 47 - 47: iiIi
   except :
    if 92 - 92: ooOoO0o % II111iiii % oO0o
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 23 - 23: o0oOOo0O0Ooo * oO00OO0oo0
    if 80 - 80: i1iiI11I / II111iiii + OoO0O00
    if 38 - 38: iII111i % iiIi + OoOoOO00 * OoO0O00 * IiII
OoOoO00o00 = iIi ( )
OooO0OO = None
OOOooo = None
OoO0o0OO = None
Oo00OOo00O = None
id = None
o0OOo0o0O0O = None
if 10 - 10: IiII - oO00OO0oo0 % o0oOOo0O0Ooo - i1iiI11I - OoOoOO00
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 10 - 10: iII111i - ooOoO0o . i1iiI11I
try :
 OooO0OO = urllib . unquote_plus ( OoOoO00o00 [ "url" ] )
except :
 pass
try :
 OOOooo = urllib . unquote_plus ( OoOoO00o00 [ "name" ] )
except :
 pass
try :
 OoO0o0OO = int ( OoOoO00o00 [ "mode" ] )
except :
 pass
try :
 Oo00OOo00O = urllib . unquote_plus ( OoOoO00o00 [ "iconimage" ] )
except :
 pass
try :
 id = int ( OoOoO00o00 [ "id" ] )
except :
 pass
try :
 o0OOo0o0O0O = urllib . unquote_plus ( OoOoO00o00 [ "trailer" ] )
except :
 pass
 if 8 - 8: Oo0Ooo % IiII + oO0o
 if 24 - 24: Ii1I / o00O0oo / o00O0oo % o0oOOo0O0Ooo - IiII * IiII
print "Mode: " + str ( OoO0o0OO )
print "URL: " + str ( OooO0OO )
print "Name: " + str ( OOOooo )
print "iconimage: " + str ( Oo00OOo00O )
print "id: " + str ( id )
print "trailer: " + str ( o0OOo0o0O0O )
if 58 - 58: I11i
if OoO0o0OO == None or OooO0OO == None or len ( OooO0OO ) < 1 :
 if O00O0oOO00O00 == i1 :
  if 60 - 60: o0oOOo0O0Ooo
  o0O00oOOoo ( )
  IIiI1Ii ( )
  if 90 - 90: I11i
  if 37 - 37: I11i + I1IiiI . I1IiiI * oO0o % i1iiI11I / oO00OO0oo0
  Oo0O0O0ooO0O = oo000 . getSetting ( 'licencia_addon' )
  iiIiII1 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  if 18 - 18: OoO0O00
  OOO00O0O = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  O0oOo00oooO = oo000 . getSetting ( 'key_ext' )
  OoOO0o = i1II1 ( OOO00O0O )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for Iii in i11i1 :
   try :
    if 22 - 22: o0oOOo0O0Ooo * iiIi + iII111i + ooOoO0o / I11i
    if 52 - 52: OoO0O00 / III1i1i % o0oOOo0O0Ooo
    Oo0O0O0ooO0O = oo000 . getSetting ( 'licencia_addon' )
    if 40 - 40: I1ii11iIi11i % iiIi % III1i1i + OOooOOo
    if 75 - 75: IiII - iII111i + IiII + OoO0O00 . II111iiii
    if Oo0O0O0ooO0O == Iii :
     if 52 - 52: oO00OO0oo0 / iiIi - II111iiii + OoO0O00
     if 33 - 33: I1IiiI + oO0o - Oo0Ooo % II111iiii / I1ii11iIi11i
     if 47 - 47: iII111i * IiII + Oo0Ooo - IiII / III1i1i
     Iiiiii111i1ii ( )
     if 86 - 86: III1i1i
    else :
     if 43 - 43: I1ii11iIi11i / oO00OO0oo0 / iiIi + Oo0Ooo + OoO0O00
     xbmcgui . Dialog ( ) . ok ( "Realstream Licencia:" , "[COLOR red]Ha introducido una llave erronea.[/COLOR] [COLOR gold]Ponganse en contacto con nosotros en nuestro grupo de telegram.[/COLOR]" )
     if 33 - 33: o0oOOo0O0Ooo - III1i1i - iiIi
     if 92 - 92: OOooOOo * III1i1i
   except :
    pass
    if 92 - 92: IiII
 else :
  xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red][B]Error, de inicio. ¿Tienes Instalado Realstream?[/B][/COLOR]" )
  if 7 - 7: oO00OO0oo0
  if 73 - 73: OOooOOo % iII111i
  if 32 - 32: I1Ii111 + oO00OO0oo0 + Oo0Ooo * oO0o
elif OoO0o0OO == 1 :
 Oo ( OOOooo , OooO0OO , id , o0OOo0o0O0O )
elif OoO0o0OO == 2 :
 IIIIIiII1 ( )
elif OoO0o0OO == 3 :
 I1iI1I1 ( )
elif OoO0o0OO == 4 :
 I1I1IIiiii1ii ( OOOooo , OooO0OO )
elif OoO0o0OO == 5 :
 oOooo0Oo ( )
elif OoO0o0OO == 6 :
 O0OOO000o0o ( )
elif OoO0o0OO == 7 :
 OooOOOO0O0 ( )
elif OoO0o0OO == 8 :
 oO0O000oOo ( )
elif OoO0o0OO == 9 :
 Oo0O0Oo00O ( )
elif OoO0o0OO == 10 :
 II1iIII ( )
elif OoO0o0OO == 11 :
 oo0 ( )
elif OoO0o0OO == 12 :
 o00ooOoO0 ( )
elif OoO0o0OO == 13 :
 Ii111IIi ( )
elif OoO0o0OO == 14 :
 IIi1I1i ( )
elif OoO0o0OO == 15 :
 iIIi11 ( )
elif OoO0o0OO == 16 :
 iiioOOOo ( )
elif OoO0o0OO == 17 :
 iiii1i1II1 ( )
elif OoO0o0OO == 18 :
 i1i11ii1Ii ( )
elif OoO0o0OO == 19 :
 IiIo0o0OO0o00o0O ( )
elif OoO0o0OO == 20 :
 I1Iii1Ii1i1 ( )
elif OoO0o0OO == 21 :
 ooOoo0OoOO ( )
elif OoO0o0OO == 22 :
 ooooO0 ( )
elif OoO0o0OO == 23 :
 ii1II1II ( )
elif OoO0o0OO == 24 :
 OO0Oo ( )
elif OoO0o0OO == 25 :
 i1I1IiI1ii ( )
elif OoO0o0OO == 26 :
 IiIIi1I1I11Ii ( )
elif OoO0o0OO == 28 :
 o0OO0O0Oo ( OOOooo , OooO0OO )
elif OoO0o0OO == 29 :
 III1iii1i11iI ( )
elif OoO0o0OO == 30 :
 OOo0 ( )
elif OoO0o0OO == 98 :
 busqueda_global ( )
elif OoO0o0OO == 97 :
 ooOoo ( )
elif OoO0o0OO == 99 :
 ooO ( )
elif OoO0o0OO == 100 :
 menu_player ( OOOooo , OooO0OO )
elif OoO0o0OO == 111 :
 oOoO00O0 ( )
elif OoO0o0OO == 115 :
 Ooo000O00 ( OooO0OO )
elif OoO0o0OO == 116 :
 iIIIii ( )
elif OoO0o0OO == 117 :
 IiI ( )
elif OoO0o0OO == 119 :
 oOOo000oOoO0 ( )
elif OoO0o0OO == 120 :
 iiI11I ( )
elif OoO0o0OO == 121 :
 IiI11i1IIiiI ( )
elif OoO0o0OO == 125 :
 II1iI1IIi ( )
elif OoO0o0OO == 112 :
 O00oO0 ( )
elif OoO0o0OO == 127 :
 IIiII11 ( )
elif OoO0o0OO == 128 :
 TESTLINKS ( )
elif OoO0o0OO == 130 :
 o0O0O ( OOOooo , OooO0OO )
elif OoO0o0OO == 140 :
 O0O0oOOo0O ( )
elif OoO0o0OO == 141 :
 o00iIiiiII ( )
elif OoO0o0OO == 142 :
 iII1I1 ( )
elif OoO0o0OO == 143 :
 OOO0ooo ( OOOooo , OooO0OO )
elif OoO0o0OO == 144 :
 o0OO0O0Oo ( OOOooo , OooO0OO )
elif OoO0o0OO == 145 :
 iioOo0OoOOo0 ( )
elif OoO0o0OO == 150 :
 ooO0oO00O0o ( )
elif OoO0o0OO == 151 :
 iIIII1i ( )
xbmcplugin . endOfDirectory ( oOOo ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
