# -*- coding: utf-8 -*-
# Real stream by Netai 2019
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import urlresolver
import cookielib , base64
import requests
if 64 - 64: i11iIiiIii
OO0o = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
Oo0Ooo = OO0o . getAddonInfo ( 'version' )
O0O0OO0O0O0 = int ( sys . argv [ 1 ] )
iiiii = 'gruponetai/'
ooo0OO = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
II1 = ooo0OO . getAddonInfo ( 'profile' )
O00ooooo00 = ooo0OO . getAddonInfo ( 'path' )
if 32 - 32: ooOoO + iIiiiI1IiI1I1 * IIiIiII11i * o0oOOo0O0Ooo
I1ii11iIi11i = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'fanart.jpg' ) )
I1IiI = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'icon.png' ) )
o0OOO = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'extended_info.png' ) )
iIiiiI = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'buscar.png' ) )
Iii1ii1II11i = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'pair.png' ) )
iI111iI = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'theMovieDB.jpg' ) )
IiII = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'estrenos.png' ) )
iI1Ii11111iIi = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'encines.jpg' ) )
i1i1II = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'recomendadas.jpg' ) )
O0oo0OO0 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'accion.jpg' ) )
I1i1iiI1 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'animacion.jpg' ) )
iiIIIII1i1iI = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'aventuras.jpg' ) )
o0oO0 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'belico.jpg' ) )
oo00 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'ciencia-ficcion.jpg' ) )
o00 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'comedia.jpg' ) )
Oo0oO0ooo = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'crimen.jpg' ) )
o0oOoO00o = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'drama.jpg' ) )
i1 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'familiar.jpg' ) )
oOOoo00O0O = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'fantasia.jpg' ) )
i1111 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'historia.jpg' ) )
i11 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'marvel.png' ) )
I11 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'misterio.jpg' ) )
Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'musical.jpg' ) )
oOo0oooo00o = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'romance.jpg' ) )
oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'spain.jpg' ) )
oo0o0O00 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'suspense.jpg' ) )
oO = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'terror.jpg' ) )
i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'thriller.jpg' ) )
oooOOOOO = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'western.jpg' ) )
i1iiIII111ii = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'sagas_cine.jpg' ) )
i1iIIi1 = xbmc . translatePath ( os . path . join ( O00ooooo00 , '4k.jpg' ) )
ii11iIi1I = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'torrent.jpg' ) )
if 6 - 6: I1I11I1I1I * OooO0OO
iiiIi = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'peliculas.png' ) )
IiIIIiI1I1 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'ajustes.png' ) )
OoO000 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'videoteca.png' ) )
IIiiIiI1 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'favorites.png' ) )
iiIiIIi = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'resolver.png' ) )
if 65 - 65: iii1I1
oo = OO0o . getSetting ( 'mostrar_cat' )
OO0O00 = OO0o . getSetting ( 'videos' )
ii1 = OO0o . getSetting ( 'activar' )
o0oO0o00oo = OO0o . getSetting ( 'favcopy' )
II1i1Ii11Ii11 = OO0o . getSetting ( 'anticopia' )
iII11i = OO0o . getSetting ( 'notificar' )
O0O00o0OOO0 = OO0o . getSetting ( 'mostrar_bus' )
Ii1iIIIi1ii = OO0o . getSetting ( 'aviso' )
o0oo0o0O00OO = OO0o . getSetting ( 'RealStream_Settings' )
o0oO = OO0o . getSetting ( 'Resolver_Settings' )
I1i1iii = OO0o . getSetting ( 'fav' )
i1iiI11I = OO0o . getSetting ( 'ayudamulti' )
iiii = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
oO0o0O0OOOoo0 = 'bienvenida'
IiIiiI = 'bienvenida'
I1I = OO0o . getSetting ( 'Forceupdate' )
if I1I == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
oOO00oOO = '.txt'
if 75 - 75: Iii / Ii11I . OO0OOO00o % Iii111II . iii11 . O0oo0OO0oOOOo
i1i1i11IIi = iiii + oO0o0O0OOOoo0 + oOO00oOO
II1III = 'http://www.youtube.com'
iI1iI1I1i1I = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
iIi11Ii1 = '.xsl.pt'
Ii11iII1 = '/master/'
Oo0O0O0ooO0O = iI1iI1I1i1I + iIi11Ii1
IIIIii = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*texto3=[\'"](.*?)[\'"]\s*'
O0o0 = 'tvg-logo=[\'"](.*?)[\'"]'
if 71 - 71: OOoOO00OOO0OO + I1I111 . I1iiI111IiI + Ii1iIiII1ii1 * ooOooo000oOO
Oo0oOOo = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)'
Oo0OoO00oOO0o = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
OOO00O = 'source src=[\'"](.*?)[\'"]'
OOoOO0oo0ooO = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
O0o0O00Oo0o0 = 'https://raw.githubusercontent.com/' + iiiii
O00O0oOO00O00 = 'Realstream'
if 11 - 11: Ooo00oOo0oOo . Ii1iIiII1ii1
i11I1iIiII = O0o0O00Oo0o0 + O00O0oOO00O00 + Ii11iII1
if 96 - 96: iii1I1
if 45 - 45: ooOoO * OO0OOO00o % iii1I1 * IIiIiII11i + I1iiI111IiI . Ii11I
Oo0ooOo0o = i11I1iIiII + 'todas.m3u'
Ii1i1 = i11I1iIiII + 'novedades.m3u'
iiIii = i11I1iIiII + 'estrenos.m3u'
ooo0O = i11I1iIiII + 'recomendadas.m3u'
oOoO0o00OO0 = i11I1iIiII + 'accion.m3u'
i1I1ii = i11I1iIiII + 'animacion.m3u'
oOOo0 = i11I1iIiII + 'aventuras.m3u'
oo00O00oO = i11I1iIiII + 'belico.m3u'
iIiIIIi = i11I1iIiII + 'cifi.m3u'
ooo00OOOooO = i11I1iIiII + 'comedia.m3u'
O00OOOoOoo0O = i11I1iIiII + 'crimen.m3u'
O000OOo00oo = i11I1iIiII + 'drama.m3u'
oo0OOo = i11I1iIiII + 'familiar.m3u'
ooOOO00Ooo = i11I1iIiII + 'fantasia.m3u'
IiIIIi1iIi = i11I1iIiII + 'historia.m3u'
ooOOoooooo = i11I1iIiII + 'misterio.m3u'
II1I = i11I1iIiII + 'musical.m3u'
O0 = i11I1iIiII + 'romance.m3u'
i1II1Iiii1I11 = i11I1iIiII + 'thriller.m3u'
IIII = i11I1iIiII + 'suspense.m3u'
iiIiI = i11I1iIiII + 'terror.m3u'
o00oooO0Oo = i11I1iIiII + 'western.m3u'
o0O0OOO0Ooo = i11I1iIiII + 'spain.m3u'
iiIiII1 = i11I1iIiII + 'superheroes.m3u'
OOO00O0O = i11I1iIiII + 'sagas.m3u'
iii = i11I1iIiII + '4k.m3u'
if 90 - 90: OO0OOO00o % o0oOOo0O0Ooo / Iii
def IIi ( ) :
 if 41 - 41: I1I111 - ooOoO - ooOoO
 if 68 - 68: O0oo0OO0oOOOo % ooOooo000oOO
 if 88 - 88: iIiiiI1IiI1I1 - Ooo00oOo0oOo + O0oo0OO0oOOOo
 try :
  IiI111111IIII = xbmc . Keyboard ( '' , 'Nombre de la pelicula' )
  IiI111111IIII . doModal ( )
  if ( IiI111111IIII . isConfirmed ( ) ) :
   if 37 - 37: ooOooo000oOO / Ii11I
   i1I1iI1iIi111i = urllib . quote_plus ( IiI111111IIII . getText ( ) ) . replace ( '+' , ' ' )
   iiIi1IIi1I = o0OoOO000ooO0 ( Oo0ooOo0o )
   o0o0o0oO0oOO = re . compile ( Oo0oOOo ) . findall ( iiIi1IIi1I )
   if 3 - 3: OO0OOO00o
   for Ii11I1 , i1i1Iiii1I1 , oooO0 , id , iIiIiiIIiIIi in o0o0o0oO0oOO :
    if re . search ( i1I1iI1iIi111i , oO0OOOO0 ( i1i1Iiii1I1 . replace ( 'Đ' , 'D' ) ) , re . IGNORECASE ) :
     iI1I11iiI1i ( i1i1Iiii1I1 , oooO0 , Ii11I1 , id , iIiIiiIIiIIi )
 except :
  pass
  if 78 - 78: iii11 % ooOoO % I1I111
  if 46 - 46: IIiIiII11i . i11iIiiIii
def OOo0oO00ooO00 ( ) :
 if 90 - 90: Ii11I * ooOooo000oOO + OO0OOO00o
 OO = o0OoOO000ooO0 ( i1i1i11IIi )
 o0o0o0oO0oOO = re . compile ( IIIIii ) . findall ( OO )
 for OoOoO , Ii1I1i , OOI1iI1ii1II in o0o0o0oO0oOO :
  try :
   if 57 - 57: ooOooo000oOO % I1I111 + OO0OOO00o - iii1I1
   o0O = OoOoO
   IiI1i = Ii1I1i
   o0Oo00 = OOI1iI1ii1II
   if 32 - 32: OO0OOO00o . Ii1iIiII1ii1 * OOoOO00OOO0OO
   if 93 - 93: OO0OOO00o % o0oOOo0O0Ooo . I1I111 . i11iIiiIii
   oOOoo00O00o = "[COLOR=red][B]" + o0O + "[/B][/COLOR]"
   O0O00Oo = "[COLOR yellow]" + IiI1i + "[/COLOR]"
   oooooo0O000o = "[COLOR yellow]" + o0Oo00 + "[/COLOR]"
   if 64 - 64: OooO0OO . OO0OOO00o - ooOooo000oOO / IIiIiII11i
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , oOOoo00O00o , O0O00Oo , oooooo0O000o )
   if 66 - 66: I1iiI111IiI - I1iiI111IiI - i11iIiiIii . Iii111II - O0oo0OO0oOOOo
   if 77 - 77: Ii11I - I1I11I1I1I - Ooo00oOo0oOo
   if 49 - 49: I1I11I1I1I % ooOoO . Ii11I + iii11 / OooO0OO
   if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 72 - 72: Ooo00oOo0oOo * iii1I1 . OooO0OO - I1I11I1I1I + o0oOOo0O0Ooo
    if 10 - 10: iii11 + o0oOOo0O0Ooo
  except :
   pass
   if 87 - 87: OooO0OO
def oO0OOOO0 ( s ) :
 if 58 - 58: Ii11I % OO0OOO00o
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 50 - 50: ooOooo000oOO . OO0OOO00o
def ooO0OO ( file ) :
 if 54 - 54: Ii1iIiII1ii1 + I1I111 % Iii + IIiIiII11i - ooOoO - OO0OOO00o
 try :
  o0o0O0O00oOOo = open ( file , 'r' )
  OO = o0o0O0O00oOOo . read ( )
  o0o0O0O00oOOo . close ( )
  return OO
 except :
  pass
  if 14 - 14: Ii11I + iii11
def o0OoOO000ooO0 ( url ) :
 if 52 - 52: IIiIiII11i - Ooo00oOo0oOo
 try :
  o0O0o0 = urllib2 . Request ( url )
  if 37 - 37: Iii111II * OOoOO00OOO0OO % i11iIiiIii % Ooo00oOo0oOo + I1I111
  o0O0o0 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  OOoOO0o0o0 = urllib2 . urlopen ( o0O0o0 )
  ii1I1 = OOoOO0o0o0 . read ( )
  OOoOO0o0o0 . close ( )
  return ii1I1
 except urllib2 . URLError , OooooOOoo0 :
  print 'We failed to open "%s".' % url
  if hasattr ( OooooOOoo0 , 'code' ) :
   print 'We failed with error code - %s.' % OooooOOoo0 . code
  if hasattr ( OooooOOoo0 , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , OooooOOoo0 . reason
   if 35 - 35: OOoOO00OOO0OO % O0oo0OO0oOOOo - iii11
def ii1iii1i ( url ) :
 o0O0o0 = urllib2 . Request ( url )
 o0O0o0 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 o0O0o0 . add_header ( 'Referer' , '%s' % url )
 o0O0o0 . add_header ( 'Connection' , 'keep-alive' )
 OOoOO0o0o0 = urllib2 . urlopen ( o0O0o0 )
 ii1I1 = OOoOO0o0o0 . read ( )
 OOoOO0o0o0 . close ( )
 return ii1I1
 if 35 - 35: I1I11I1I1I % O0oo0OO0oOOOo . Ooo00oOo0oOo + Ooo00oOo0oOo % I1I11I1I1I % I1I11I1I1I
 if 72 - 72: I1I11I1I1I + o0oOOo0O0Ooo + OO0OOO00o
def OOO ( ) :
 if 25 - 25: iii11 - Iii . iIiiiI1IiI1I1 % i11iIiiIii % Iii111II
 if ii1 == 'true' :
  o0Oo0oO0oOO00 ( '[COLOR orange]Menu Peliculas[/COLOR] ' , 'movieDB' , 116 , iiiIi , I1ii11iIi11i )
  if 92 - 92: IIiIiII11i * ooOooo000oOO
  if 100 - 100: ooOooo000oOO + ooOooo000oOO * Ii1iIiII1ii1
  if 1 - 1: Ooo00oOo0oOo . Ooo00oOo0oOo / Ii11I - ooOooo000oOO
  if I1i1iii == 'true' :
   o0Oo0oO0oOO00 ( '[COLOR orange]favoritos Real stream[/COLOR]' , 'movieDB' , 121 , IIiiIiI1 , I1ii11iIi11i )
   if 86 - 86: iIiiiI1IiI1I1 / Ii11I . I1I11I1I1I
 if o0oo0o0O00OO == 'true' :
  o0Oo0oO0oOO00 ( '[COLOR orange]Ajustes[/COLOR]' , 'Settings' , 119 , IiIIIiI1I1 , I1ii11iIi11i )
  if 19 - 19: Iii111II % IIiIiII11i % Ii1iIiII1ii1 * OO0OOO00o % ooOoO
  if 67 - 67: OooO0OO . o0oOOo0O0Ooo
  if oo == 'true' :
   i1i1iI1iiiI ( )
   if 51 - 51: OooO0OO % ooOooo000oOO . iii11 / iIiiiI1IiI1I1 / OOoOO00OOO0OO . iii11
  if o0oO == 'true' :
   IIIii11 ( )
   if 9 - 9: ooOoO % ooOoO - OO0OOO00o
  if II1i1Ii11Ii11 == 'false' :
   if 51 - 51: OooO0OO . iIiiiI1IiI1I1 - Iii111II / ooOoO
   oOOoo00O00o = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   O0O00Oo = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Program.favoritos-realstream para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   oooooo0O000o = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 52 - 52: OO0OOO00o + ooOoO + I1iiI111IiI + iii1I1 % I1iiI111IiI
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , oOOoo00O00o , O0O00Oo , oooooo0O000o )
   if 75 - 75: OooO0OO . Ooo00oOo0oOo . ooOoO * ooOooo000oOO
def i11II1I11I1 ( ) :
 o0Oo0oO0oOO00 ( '[COLOR orange]Buscador por id[/COLOR]' , II1III , 127 , iI111iI , I1ii11iIi11i )
 if 67 - 67: OooO0OO - OO0OOO00o / OOoOO00OOO0OO - o0oOOo0O0Ooo
def i1II1 ( ) :
 o0Oo0oO0oOO00 ( '[COLOR orange]The movie DB[/COLOR]' , 'movieDB' , 99 , iI111iI , I1ii11iIi11i )
 o0Oo0oO0oOO00 ( '[COLOR orange]Buscador por id[/COLOR]' , II1III , 127 , iI111iI , I1ii11iIi11i )
 if 25 - 25: ooOooo000oOO / iIiiiI1IiI1I1 % I1iiI111IiI
 if 42 - 42: i11iIiiIii * iIiiiI1IiI1I1 / Iii111II . i11iIiiIii % OOoOO00OOO0OO
 if 41 - 41: Ii1iIiII1ii1 / ooOoO
 if 51 - 51: OOoOO00OOO0OO % OooO0OO
 if 60 - 60: OooO0OO / O0oo0OO0oOOOo . OooO0OO / ooOooo000oOO . Ii1iIiII1ii1
 if 92 - 92: Ii11I + ooOooo000oOO * I1I111 % OooO0OO
 o0Oo0oO0oOO00 ( '[COLOR orange]Autorizar[/COLOR] [COLOR blue][B]OPENLOAD[/B][/COLOR]' , 'movieDB' , 97 , Iii1ii1II11i , I1ii11iIi11i )
 OOO ( )
 if 42 - 42: iii1I1
 if 76 - 76: OooO0OO * I1iiI111IiI % ooOooo000oOO
def OoooO00o ( ) :
 if 73 - 73: O0oo0OO0oOOOo / iii11
 if xbmc . getCondVisibility ( 'System.HasAddon(plugin.program.favoritos-realstream)' ) :
  if 88 - 88: OOoOO00OOO0OO % Iii111II
  xbmc . executebuiltin ( 'RunAddon(plugin.program.favoritos-realstream)' )
  if 48 - 48: Ooo00oOo0oOo / ooOooo000oOO . iIiiiI1IiI1I1 * Ii11I * iii11 / o0oOOo0O0Ooo
  if o0oO0o00oo == 'true' :
   if 92 - 92: iii1I1 % iii1I1 - OO0OOO00o / Ii11I
   xbmcgui . Dialog ( ) . ok ( "[COLOR orange]Real Stream Agradecimientos[/COLOR]" , "[COLOR gold]Netai quiere agradecer el genial trabajo de [/COLOR][COLOR lime][B]Spoyser[/B][/COLOR][COLOR gold] Autor de este genial script que originalmente se conoce como:[/COLOR]" , "[COLOR lime][B]Program.super.favorites[/B][/COLOR]" , "Usted puede descargar el script original desde el repositorio de Kodi >Addons de programas> program.super.favorites" )
   if 10 - 10: I1iiI111IiI + iii1I1 * Iii111II + iIiiiI1IiI1I1 / ooOooo000oOO / Iii111II
  OO0o . setSetting ( 'Favoritos-anuncio' , 'false' )
 else :
  if 42 - 42: OooO0OO
  xbmcgui . Dialog ( ) . ok ( "El programa Real stream Favoritos No esta instalado" , "[COLOR green]Necesario AddOn externo para agregar tus peliculas a favoritas dentro del addon.[/COLOR]" , "[COLOR yellow]Puedes agregarlo desde http://netai.eu/netai/ agregando la fuente a tu Kodi, instalar desde archivo zip.[/COLOR]" )
  if 38 - 38: O0oo0OO0oOOOo + I1I11I1I1I % Ooo00oOo0oOo % Ii11I - I1I111 / IIiIiII11i
def oOOoo0000O0o0 ( ) :
 if 1 - 1: iii11 + iii11 % Ii11I + i11iIiiIii
 if 56 - 56: OO0OOO00o
 if 28 - 28: I1iiI111IiI . I1iiI111IiI % iIiiiI1IiI1I1 * iIiiiI1IiI1I1 . OO0OOO00o / I1iiI111IiI
 xbmc . executebuiltin ( 'RunAddon(plugin.video.Real-4k.pro)' )
 if 27 - 27: Iii + Ooo00oOo0oOo - o0oOOo0O0Ooo
 if i1iiI11I == 'true' :
  if 69 - 69: Ii1iIiII1ii1 - ooOoO % Iii111II + i11iIiiIii . Ii11I / Iii
  xbmcgui . Dialog ( ) . ok ( "[COLOR orange]Real Stream[/COLOR]" , "[COLOR gold]Vaya al menu principal y entre en configuracion de URLRESOLVER ajustes.[/COLOR]" , "[COLOR gold]En el menu urlresolver, desactive las opciones: Elegir la mejor calidad automaticamente, y usar la funcion de cache. No olvide cada cierto tiempo en el mismo sitio ejecutar borrar la cache de URLRESOLVER.[/COLOR]" )
  if 79 - 79: ooOoO * i11iIiiIii - Ii1iIiII1ii1 / Ii1iIiII1ii1
 OO0o . setSetting ( 'ayudamulti' , 'false' )
 if 48 - 48: ooOoO
 if 93 - 93: i11iIiiIii - OooO0OO * Iii111II * OOoOO00OOO0OO % ooOoO + IIiIiII11i
 if 25 - 25: Ii1iIiII1ii1 + I1I111 / Ooo00oOo0oOo . OO0OOO00o % ooOoO * Iii
 if 84 - 84: Ooo00oOo0oOo % I1I111 + i11iIiiIii
def II1I1Ii ( ) :
 if 62 - 62: ooOoO % OOoOO00OOO0OO . OOoOO00OOO0OO - iIiiiI1IiI1I1 / i11iIiiIii
 if 31 - 31: iIiiiI1IiI1I1 / Iii / Iii111II
 if 41 - 41: iii1I1
 xbmc . executebuiltin ( 'RunAddon(plugin.video.Real-torrent.pro)' )
 if 10 - 10: iii1I1 / iii1I1 / ooOooo000oOO . ooOooo000oOO
 if i1iiI11I == 'true' :
  if 98 - 98: iii1I1 / OooO0OO . ooOoO + Iii
  xbmcgui . Dialog ( ) . ok ( "[COLOR orange]Real Stream[/COLOR]" , "[COLOR gold]Esta opcion funciona con gestores torrent.[/COLOR]" , "[COLOR gold]Por defecto, se instalara el addon externo Torrentin y Gestor torrenter para poder visionar los videos torrent.[/COLOR]" , "Recomendamos utilice el gestor torrentin que le dara ayuda y soporte con Extended Info. O bien la opcion Torrenter sobre todo en Kodi 18." )
  if 43 - 43: I1I11I1I1I . iii11 / Iii111II
 OO0o . setSetting ( 'ayudamulti' , 'false' )
 if 20 - 20: OooO0OO
 if 95 - 95: I1iiI111IiI - OooO0OO
 if 34 - 34: Ooo00oOo0oOo * OooO0OO . o0oOOo0O0Ooo * Ooo00oOo0oOo / Ooo00oOo0oOo
 if 30 - 30: Iii111II + iii1I1 / iii1I1 % Iii111II . Iii111II
 if 55 - 55: Ooo00oOo0oOo - OOoOO00OOO0OO + I1I11I1I1I + I1iiI111IiI % I1I111
def iiI11i1II ( ) :
 OO0o . openSettings ( )
 if 51 - 51: OO0OOO00o % iii1I1 % OO0OOO00o * ooOoO - O0oo0OO0oOOOo % iii1I1
def o0O00OooOOOOO ( ) :
 urlresolver . display_settings ( )
 if 40 - 40: OO0OOO00o - i11iIiiIii + Iii . iIiiiI1IiI1I1 * ooOooo000oOO
def IIIii11 ( ) :
 o0Oo0oO0oOO00 ( '[COLOR orange]Ajustes URL RESOLVER[/COLOR]' , 'resolve' , 120 , iiIiIIi , I1ii11iIi11i )
 if 15 - 15: o0oOOo0O0Ooo + Ii11I
def i1i1iI1iiiI ( ) :
 o0Oo0oO0oOO00 ( '[COLOR yellow]Buscador[/COLOR]' , 'search' , 111 , iIiiiI , I1ii11iIi11i )
 o0Oo0oO0oOO00 ( '[COLOR orange]Novedades[/COLOR]' , II1III , 3 , IiII , I1ii11iIi11i )
 o0Oo0oO0oOO00 ( '[COLOR orange]Estrenos[/COLOR]' , II1III , 2 , iI1Ii11111iIi , I1ii11iIi11i )
 o0Oo0oO0oOO00 ( '[COLOR orange]Recomendadas[/COLOR]' , II1III , 4 , i1i1II , I1ii11iIi11i )
 o0Oo0oO0oOO00 ( '[COLOR orange]Accion[/COLOR]' , II1III , 5 , O0oo0OO0 , I1ii11iIi11i )
 o0Oo0oO0oOO00 ( '[COLOR orange]Animacion[/COLOR]' , II1III , 6 , I1i1iiI1 , I1ii11iIi11i )
 o0Oo0oO0oOO00 ( '[COLOR orange]Aventuras[/COLOR]' , II1III , 7 , iiIIIII1i1iI , I1ii11iIi11i )
 o0Oo0oO0oOO00 ( '[COLOR orange]Belico[/COLOR]' , II1III , 8 , o0oO0 , I1ii11iIi11i )
 o0Oo0oO0oOO00 ( '[COLOR orange]Ciencia Ficcion[/COLOR]' , II1III , 9 , oo00 , I1ii11iIi11i )
 o0Oo0oO0oOO00 ( '[COLOR orange]Comedia[/COLOR]' , II1III , 10 , o00 , I1ii11iIi11i )
 o0Oo0oO0oOO00 ( '[COLOR orange]Crimen[/COLOR]' , II1III , 11 , Oo0oO0ooo , I1ii11iIi11i )
 o0Oo0oO0oOO00 ( '[COLOR orange]Drama[/COLOR]' , II1III , 12 , o0oOoO00o , I1ii11iIi11i )
 o0Oo0oO0oOO00 ( '[COLOR orange]Familiar[/COLOR]' , II1III , 13 , i1 , I1ii11iIi11i )
 o0Oo0oO0oOO00 ( '[COLOR orange]Fantasia[/COLOR]' , II1III , 14 , oOOoo00O0O , I1ii11iIi11i )
 o0Oo0oO0oOO00 ( '[COLOR orange]Historica[/COLOR]' , II1III , 15 , i1111 , I1ii11iIi11i )
 o0Oo0oO0oOO00 ( '[COLOR orange]Misterio[/COLOR]' , II1III , 16 , I11 , I1ii11iIi11i )
 o0Oo0oO0oOO00 ( '[COLOR orange]Musical[/COLOR]' , II1III , 17 , Oo0o0000o0o0 , I1ii11iIi11i )
 o0Oo0oO0oOO00 ( '[COLOR orange]Romance[/COLOR]' , II1III , 18 , oOo0oooo00o , I1ii11iIi11i )
 o0Oo0oO0oOO00 ( '[COLOR orange]Thriller[/COLOR]' , II1III , 19 , i1iiIIiiI111 , I1ii11iIi11i )
 o0Oo0oO0oOO00 ( '[COLOR orange]Suspense[/COLOR]' , II1III , 20 , oo0o0O00 , I1ii11iIi11i )
 o0Oo0oO0oOO00 ( '[COLOR orange]Terror[/COLOR]' , II1III , 21 , oO , I1ii11iIi11i )
 o0Oo0oO0oOO00 ( '[COLOR orange]Western[/COLOR]' , II1III , 22 , oooOOOOO , I1ii11iIi11i )
 o0Oo0oO0oOO00 ( '[COLOR orange]Spain[/COLOR]' , II1III , 23 , oO0o0o0ooO0oO , I1ii11iIi11i )
 o0Oo0oO0oOO00 ( '[COLOR orange]Super heroes[/COLOR]' , II1III , 24 , i11 , I1ii11iIi11i )
 o0Oo0oO0oOO00 ( '[COLOR orange]Sagas[/COLOR]' , II1III , 25 , i1iiIII111ii , I1ii11iIi11i )
 if 48 - 48: OooO0OO % I1iiI111IiI / iIiiiI1IiI1I1
 if 85 - 85: IIiIiII11i % o0oOOo0O0Ooo * IIiIiII11i / Iii111II
 if 96 - 96: IIiIiII11i + iii11
 if 44 - 44: iii11
 if 20 - 20: OOoOO00OOO0OO + I1I111 / ooOoO % iIiiiI1IiI1I1
def oOo0O ( ) :
 if 64 - 64: Iii111II - I1iiI111IiI + I1iiI111IiI - OOoOO00OOO0OO
 if 30 - 30: iIiiiI1IiI1I1 . OooO0OO . O0oo0OO0oOOOo / OO0OOO00o
 iiI1I1 = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 iiI1I1 . doModal ( )
 if not iiI1I1 . isConfirmed ( ) :
  return None ;
 i1i1Iiii1I1 = iiI1I1 . getText ( ) . strip ( )
 if 56 - 56: OooO0OO . ooOoO + iii1I1
 if 1 - 1: I1iiI111IiI
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 97 - 97: O0oo0OO0oOOOo + I1iiI111IiI + ooOoO + i11iIiiIii
  oOoO0 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + i1i1Iiii1I1 + '&language=es-ES' ) )
  if 77 - 77: iIiiiI1IiI1I1 . I1iiI111IiI % I1iiI111IiI + i11iIiiIii
  if 72 - 72: iIiiiI1IiI1I1 * I1I111 % Ooo00oOo0oOo / Iii
  return 'android'
  if 35 - 35: Ooo00oOo0oOo + o0oOOo0O0Ooo % Iii111II % OOoOO00OOO0OO + iii11
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 17 - 17: o0oOOo0O0Ooo
  oOoO0 = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + i1i1Iiii1I1 + '&language=es-ES' )
  if 21 - 21: iii1I1
  if 29 - 29: OOoOO00OOO0OO / I1I11I1I1I / Ooo00oOo0oOo * O0oo0OO0oOOOo
  return 'windows'
  if 10 - 10: ooOooo000oOO % Ii1iIiII1ii1 * Ii1iIiII1ii1 . OOoOO00OOO0OO / I1I111 % O0oo0OO0oOOOo
def IIII1 ( ) :
 if 10 - 10: ooOooo000oOO / Ooo00oOo0oOo + i11iIiiIii / I1I111
 OO = o0OoOO000ooO0 ( Ii1i1 )
 o0o0o0oO0oOO = re . compile ( Oo0oOOo ) . findall ( OO )
 for Ii11I1 , i1i1Iiii1I1 , oooO0 , id , iIiIiiIIiIIi in o0o0o0oO0oOO :
  try :
   iI1I11iiI1i ( i1i1Iiii1I1 , oooO0 , Ii11I1 , id , iIiIiiIIiIIi )
  except :
   pass
   if 74 - 74: O0oo0OO0oOOOo + ooOoO + o0oOOo0O0Ooo - o0oOOo0O0Ooo + I1I11I1I1I
def oOOO0oo0 ( ) :
 if 46 - 46: Ii1iIiII1ii1
 if 45 - 45: Ooo00oOo0oOo
 OO = o0OoOO000ooO0 ( iiIii )
 o0o0o0oO0oOO = re . compile ( Oo0oOOo ) . findall ( OO )
 for Ii11I1 , i1i1Iiii1I1 , oooO0 , id , iIiIiiIIiIIi in o0o0o0oO0oOO :
  try :
   iI1I11iiI1i ( i1i1Iiii1I1 , oooO0 , Ii11I1 , id , iIiIiiIIiIIi )
  except :
   pass
   if 21 - 21: iii11 . ooOooo000oOO . O0oo0OO0oOOOo / iii1I1 / ooOooo000oOO
def i1iI1 ( ) :
 if 1 - 1: o0oOOo0O0Ooo . i11iIiiIii % O0oo0OO0oOOOo
 if 82 - 82: iIiiiI1IiI1I1 + iii1I1 . iIiiiI1IiI1I1 % Ii1iIiII1ii1 / I1I111 . I1I111
 OO = o0OoOO000ooO0 ( ooo0O )
 o0o0o0oO0oOO = re . compile ( Oo0oOOo ) . findall ( OO )
 for Ii11I1 , i1i1Iiii1I1 , oooO0 , id , iIiIiiIIiIIi in o0o0o0oO0oOO :
  try :
   iI1I11iiI1i ( i1i1Iiii1I1 , oooO0 , Ii11I1 , id , iIiIiiIIiIIi )
  except :
   pass
def IIioOoO00oo0O ( ) :
 if 39 - 39: iIiiiI1IiI1I1 / ooOoO / iii11 - I1I111 - I1iiI111IiI % O0oo0OO0oOOOo
 if 31 - 31: OOoOO00OOO0OO - ooOoO / Ooo00oOo0oOo * Ii11I
 OO = o0OoOO000ooO0 ( oOoO0o00OO0 )
 o0o0o0oO0oOO = re . compile ( Oo0oOOo ) . findall ( OO )
 for Ii11I1 , i1i1Iiii1I1 , oooO0 , id , iIiIiiIIiIIi in o0o0o0oO0oOO :
  try :
   iI1I11iiI1i ( i1i1Iiii1I1 , oooO0 , Ii11I1 , id , iIiIiiIIiIIi )
  except :
   pass
   if 12 - 12: OO0OOO00o - Ooo00oOo0oOo * ooOooo000oOO
def II1111ii ( ) :
 if 27 - 27: ooOoO
 if 79 - 79: OO0OOO00o - OOoOO00OOO0OO + OO0OOO00o . iii11
 OO = o0OoOO000ooO0 ( i1I1ii )
 o0o0o0oO0oOO = re . compile ( Oo0oOOo ) . findall ( OO )
 for Ii11I1 , i1i1Iiii1I1 , oooO0 , id , iIiIiiIIiIIi in o0o0o0oO0oOO :
  try :
   iI1I11iiI1i ( i1i1Iiii1I1 , oooO0 , Ii11I1 , id , iIiIiiIIiIIi )
  except :
   pass
   if 28 - 28: o0oOOo0O0Ooo - I1iiI111IiI
def o00o000oo ( ) :
 if 44 - 44: OooO0OO - OOoOO00OOO0OO % iIiiiI1IiI1I1
 if 71 - 71: Ooo00oOo0oOo . I1I111 - IIiIiII11i % I1I111 . I1I11I1I1I
 OO = o0OoOO000ooO0 ( oOOo0 )
 o0o0o0oO0oOO = re . compile ( Oo0oOOo ) . findall ( OO )
 for Ii11I1 , i1i1Iiii1I1 , oooO0 , id , iIiIiiIIiIIi in o0o0o0oO0oOO :
  try :
   iI1I11iiI1i ( i1i1Iiii1I1 , oooO0 , Ii11I1 , id , iIiIiiIIiIIi )
  except :
   pass
   if 89 - 89: I1iiI111IiI . ooOoO / Iii111II % Ii11I . iii1I1
def IiiI1i ( ) :
 if 51 - 51: Ii1iIiII1ii1
 if 25 - 25: IIiIiII11i + Ii1iIiII1ii1 * Iii111II
 OO = o0OoOO000ooO0 ( oo00O00oO )
 o0o0o0oO0oOO = re . compile ( Oo0oOOo ) . findall ( OO )
 for Ii11I1 , i1i1Iiii1I1 , oooO0 , id , iIiIiiIIiIIi in o0o0o0oO0oOO :
  try :
   iI1I11iiI1i ( i1i1Iiii1I1 , oooO0 , Ii11I1 , id , iIiIiiIIiIIi )
  except :
   pass
   if 92 - 92: OooO0OO + OOoOO00OOO0OO + ooOoO / OO0OOO00o + ooOooo000oOO
def I1iIi1iIiiIiI ( ) :
 if 47 - 47: I1I111 + ooOooo000oOO / o0oOOo0O0Ooo % i11iIiiIii
 if 42 - 42: I1iiI111IiI + Ii1iIiII1ii1
 OO = o0OoOO000ooO0 ( iIiIIIi )
 o0o0o0oO0oOO = re . compile ( Oo0oOOo ) . findall ( OO )
 for Ii11I1 , i1i1Iiii1I1 , oooO0 , id , iIiIiiIIiIIi in o0o0o0oO0oOO :
  try :
   iI1I11iiI1i ( i1i1Iiii1I1 , oooO0 , Ii11I1 , id , iIiIiiIIiIIi )
  except :
   pass
   if 96 - 96: O0oo0OO0oOOOo
   if 85 - 85: OO0OOO00o . Ii11I / Ooo00oOo0oOo . ooOoO % ooOooo000oOO
def OO0ooo0oOO ( ) :
 if 97 - 97: OooO0OO / I1iiI111IiI
 if 71 - 71: I1I11I1I1I / o0oOOo0O0Ooo . Iii111II % IIiIiII11i . Ii11I
 OO = o0OoOO000ooO0 ( ooo00OOOooO )
 o0o0o0oO0oOO = re . compile ( Oo0oOOo ) . findall ( OO )
 for Ii11I1 , i1i1Iiii1I1 , oooO0 , id , iIiIiiIIiIIi in o0o0o0oO0oOO :
  try :
   iI1I11iiI1i ( i1i1Iiii1I1 , oooO0 , Ii11I1 , id , iIiIiiIIiIIi )
  except :
   pass
   if 41 - 41: o0oOOo0O0Ooo * I1I11I1I1I / IIiIiII11i . O0oo0OO0oOOOo
   if 83 - 83: I1iiI111IiI . ooOoO / iii1I1 / O0oo0OO0oOOOo - I1I11I1I1I
def oO0oO0 ( ) :
 if 14 - 14: I1iiI111IiI
 if 99 - 99: I1iiI111IiI
 OO = o0OoOO000ooO0 ( O00OOOoOoo0O )
 o0o0o0oO0oOO = re . compile ( Oo0oOOo ) . findall ( OO )
 for Ii11I1 , i1i1Iiii1I1 , oooO0 , id , iIiIiiIIiIIi in o0o0o0oO0oOO :
  try :
   iI1I11iiI1i ( i1i1Iiii1I1 , oooO0 , Ii11I1 , id , iIiIiiIIiIIi )
  except :
   pass
   if 38 - 38: Iii111II - I1iiI111IiI / ooOoO . ooOooo000oOO
   if 45 - 45: ooOooo000oOO
def oOIIi1iiii1iI ( ) :
 if 25 - 25: Iii111II + ooOoO
 if 28 - 28: IIiIiII11i
 OO = o0OoOO000ooO0 ( O000OOo00oo )
 o0o0o0oO0oOO = re . compile ( Oo0oOOo ) . findall ( OO )
 for Ii11I1 , i1i1Iiii1I1 , oooO0 , id , iIiIiiIIiIIi in o0o0o0oO0oOO :
  try :
   iI1I11iiI1i ( i1i1Iiii1I1 , oooO0 , Ii11I1 , id , iIiIiiIIiIIi )
  except :
   pass
   if 89 - 89: I1iiI111IiI - Ooo00oOo0oOo % iii1I1 % OO0OOO00o
def IIiii11i ( ) :
 if 100 - 100: Ooo00oOo0oOo % iIiiiI1IiI1I1 * I1I11I1I1I - I1iiI111IiI
 if 92 - 92: Ooo00oOo0oOo
 OO = o0OoOO000ooO0 ( oo0OOo )
 o0o0o0oO0oOO = re . compile ( Oo0oOOo ) . findall ( OO )
 for Ii11I1 , i1i1Iiii1I1 , oooO0 , id , iIiIiiIIiIIi in o0o0o0oO0oOO :
  try :
   iI1I11iiI1i ( i1i1Iiii1I1 , oooO0 , Ii11I1 , id , iIiIiiIIiIIi )
  except :
   pass
   if 22 - 22: iii1I1 % I1iiI111IiI * Iii111II / O0oo0OO0oOOOo % i11iIiiIii * OOoOO00OOO0OO
   if 95 - 95: IIiIiII11i - Ii1iIiII1ii1 * OooO0OO + Ii11I
def iIi1 ( ) :
 if 21 - 21: OOoOO00OOO0OO
 if 92 - 92: i11iIiiIii / ooOooo000oOO - I1iiI111IiI % Ooo00oOo0oOo * ooOooo000oOO + iii1I1
 OO = o0OoOO000ooO0 ( ooOOO00Ooo )
 o0o0o0oO0oOO = re . compile ( Oo0oOOo ) . findall ( OO )
 for Ii11I1 , i1i1Iiii1I1 , oooO0 , id , iIiIiiIIiIIi in o0o0o0oO0oOO :
  try :
   iI1I11iiI1i ( i1i1Iiii1I1 , oooO0 , Ii11I1 , id , iIiIiiIIiIIi )
  except :
   pass
   if 11 - 11: IIiIiII11i . ooOooo000oOO
   if 80 - 80: IIiIiII11i - O0oo0OO0oOOOo * I1I111 * Iii111II / OooO0OO / O0oo0OO0oOOOo
def I1I11iI11iI1i ( ) :
 if 75 - 75: IIiIiII11i * Ii1iIiII1ii1
 if 9 - 9: Ii1iIiII1ii1 - I1I11I1I1I + ooOoO / iIiiiI1IiI1I1 / i11iIiiIii
 OO = o0OoOO000ooO0 ( IiIIIi1iIi )
 o0o0o0oO0oOO = re . compile ( Oo0oOOo ) . findall ( OO )
 for Ii11I1 , i1i1Iiii1I1 , oooO0 , id , iIiIiiIIiIIi in o0o0o0oO0oOO :
  try :
   iI1I11iiI1i ( i1i1Iiii1I1 , oooO0 , Ii11I1 , id , iIiIiiIIiIIi )
  except :
   pass
   if 39 - 39: Ii1iIiII1ii1 * iii1I1 + iIiiiI1IiI1I1 - Ii1iIiII1ii1 + O0oo0OO0oOOOo
def o0 ( ) :
 if 30 - 30: ooOoO * IIiIiII11i
 if 38 - 38: Ii1iIiII1ii1 - Iii111II . Ii11I - ooOooo000oOO . IIiIiII11i
 OO = o0OoOO000ooO0 ( ooOOoooooo )
 o0o0o0oO0oOO = re . compile ( Oo0oOOo ) . findall ( OO )
 for Ii11I1 , i1i1Iiii1I1 , oooO0 , id , iIiIiiIIiIIi in o0o0o0oO0oOO :
  try :
   iI1I11iiI1i ( i1i1Iiii1I1 , oooO0 , Ii11I1 , id , iIiIiiIIiIIi )
  except :
   pass
   if 89 - 89: iIiiiI1IiI1I1
   if 21 - 21: OOoOO00OOO0OO % OOoOO00OOO0OO
def iiI1 ( ) :
 if 16 - 16: I1I11I1I1I + iii11 - IIiIiII11i
 if 3 - 3: ooOoO / I1iiI111IiI
 OO = o0OoOO000ooO0 ( II1I )
 o0o0o0oO0oOO = re . compile ( Oo0oOOo ) . findall ( OO )
 for Ii11I1 , i1i1Iiii1I1 , oooO0 , id , iIiIiiIIiIIi in o0o0o0oO0oOO :
  try :
   iI1I11iiI1i ( i1i1Iiii1I1 , oooO0 , Ii11I1 , id , iIiIiiIIiIIi )
  except :
   pass
   if 31 - 31: O0oo0OO0oOOOo + OO0OOO00o . IIiIiII11i
def ooOooo0 ( ) :
 if 67 - 67: OooO0OO
 if 55 - 55: Iii111II - I1iiI111IiI * OO0OOO00o + Ii11I * Ii11I * ooOoO
 OO = o0OoOO000ooO0 ( O0 )
 o0o0o0oO0oOO = re . compile ( Oo0oOOo ) . findall ( OO )
 for Ii11I1 , i1i1Iiii1I1 , oooO0 , id , iIiIiiIIiIIi in o0o0o0oO0oOO :
  try :
   iI1I11iiI1i ( i1i1Iiii1I1 , oooO0 , Ii11I1 , id , iIiIiiIIiIIi )
  except :
   pass
   if 91 - 91: ooOooo000oOO - O0oo0OO0oOOOo % iIiiiI1IiI1I1 - IIiIiII11i % Ooo00oOo0oOo
   if 98 - 98: Iii . Iii * iii11 * I1I11I1I1I * ooOooo000oOO
def oOooO0 ( ) :
 if 79 - 79: Iii - iIiiiI1IiI1I1 + I1I111 - ooOooo000oOO
 if 93 - 93: I1I11I1I1I . OooO0OO - iii1I1 + Ii11I
 OO = o0OoOO000ooO0 ( i1II1Iiii1I11 )
 o0o0o0oO0oOO = re . compile ( Oo0oOOo ) . findall ( OO )
 for Ii11I1 , i1i1Iiii1I1 , oooO0 , id , iIiIiiIIiIIi in o0o0o0oO0oOO :
  try :
   iI1I11iiI1i ( i1i1Iiii1I1 , oooO0 , Ii11I1 , id , iIiIiiIIiIIi )
  except :
   pass
   if 61 - 61: I1I11I1I1I
   if 15 - 15: i11iIiiIii % OooO0OO * OOoOO00OOO0OO / ooOooo000oOO
def oooO0o0o0O0 ( ) :
 if 27 - 27: IIiIiII11i - I1iiI111IiI / OOoOO00OOO0OO
 if 76 - 76: OO0OOO00o % OooO0OO . iIiiiI1IiI1I1 - Ii1iIiII1ii1 * IIiIiII11i . I1iiI111IiI
 OO = o0OoOO000ooO0 ( IIII )
 o0o0o0oO0oOO = re . compile ( Oo0oOOo ) . findall ( OO )
 for Ii11I1 , i1i1Iiii1I1 , oooO0 , id , iIiIiiIIiIIi in o0o0o0oO0oOO :
  try :
   iI1I11iiI1i ( i1i1Iiii1I1 , oooO0 , Ii11I1 , id , iIiIiiIIiIIi )
  except :
   pass
   if 84 - 84: ooOooo000oOO + OOoOO00OOO0OO
   if 28 - 28: iii11 - i11iIiiIii . Iii111II + Ii1iIiII1ii1 / Iii111II
def i11iIiI11I1i ( ) :
 if 41 - 41: I1I111
 if 77 - 77: ooOooo000oOO
 OO = o0OoOO000ooO0 ( iiIiI )
 o0o0o0oO0oOO = re . compile ( Oo0oOOo ) . findall ( OO )
 for Ii11I1 , i1i1Iiii1I1 , oooO0 , id , iIiIiiIIiIIi in o0o0o0oO0oOO :
  try :
   iI1I11iiI1i ( i1i1Iiii1I1 , oooO0 , Ii11I1 , id , iIiIiiIIiIIi )
  except :
   pass
   if 65 - 65: I1I11I1I1I . OooO0OO % iii11 * Iii
   if 38 - 38: Ii11I / I1iiI111IiI % iii1I1
def I1IIIiii1 ( ) :
 if 65 - 65: OOoOO00OOO0OO / I1I11I1I1I * I1I111 . I1iiI111IiI * iii11 % O0oo0OO0oOOOo
 if 69 - 69: Ooo00oOo0oOo - Iii / i11iIiiIii + Iii111II % IIiIiII11i
 OO = o0OoOO000ooO0 ( o00oooO0Oo )
 o0o0o0oO0oOO = re . compile ( Oo0oOOo ) . findall ( OO )
 for Ii11I1 , i1i1Iiii1I1 , oooO0 , id , iIiIiiIIiIIi in o0o0o0oO0oOO :
  try :
   iI1I11iiI1i ( i1i1Iiii1I1 , oooO0 , Ii11I1 , id , iIiIiiIIiIIi )
  except :
   pass
   if 73 - 73: I1I111 - ooOooo000oOO
   if 68 - 68: I1iiI111IiI * IIiIiII11i * iIiiiI1IiI1I1 . I1I11I1I1I
def O0Oo ( ) :
 if 36 - 36: I1I111 / I1I11I1I1I / Ii1iIiII1ii1 / Ii1iIiII1ii1 + Iii111II
 if 95 - 95: Ii1iIiII1ii1
 OO = o0OoOO000ooO0 ( o0O0OOO0Ooo )
 o0o0o0oO0oOO = re . compile ( Oo0oOOo ) . findall ( OO )
 for Ii11I1 , i1i1Iiii1I1 , oooO0 , id , iIiIiiIIiIIi in o0o0o0oO0oOO :
  try :
   iI1I11iiI1i ( i1i1Iiii1I1 , oooO0 , Ii11I1 , id , iIiIiiIIiIIi )
  except :
   pass
   if 51 - 51: I1I11I1I1I + Ii1iIiII1ii1 . o0oOOo0O0Ooo . Iii111II + Ii11I * OooO0OO
def OOoOoo0 ( ) :
 if 17 - 17: I1I111 + iii11 . Iii - iii1I1 * i11iIiiIii
 if 20 - 20: OooO0OO . IIiIiII11i % O0oo0OO0oOOOo
 OO = o0OoOO000ooO0 ( iiIiII1 )
 o0o0o0oO0oOO = re . compile ( Oo0oOOo ) . findall ( OO )
 for Ii11I1 , i1i1Iiii1I1 , oooO0 , id , iIiIiiIIiIIi in o0o0o0oO0oOO :
  try :
   iI1I11iiI1i ( i1i1Iiii1I1 , oooO0 , Ii11I1 , id , iIiIiiIIiIIi )
  except :
   pass
def oOoOOo0oo0 ( ) :
 if 60 - 60: Ooo00oOo0oOo * ooOooo000oOO + iii1I1
 if 19 - 19: Iii * OOoOO00OOO0OO / OOoOO00OOO0OO . IIiIiII11i - O0oo0OO0oOOOo + i11iIiiIii
 OO = o0OoOO000ooO0 ( OOO00O0O )
 o0o0o0oO0oOO = re . compile ( Oo0oOOo ) . findall ( OO )
 for Ii11I1 , i1i1Iiii1I1 , oooO0 , id , iIiIiiIIiIIi in o0o0o0oO0oOO :
  try :
   iI1I11iiI1i ( i1i1Iiii1I1 , oooO0 , Ii11I1 , id , iIiIiiIIiIIi )
  except :
   pass
   if 88 - 88: i11iIiiIii - Ooo00oOo0oOo
   if 67 - 67: O0oo0OO0oOOOo . iii1I1 + Ii11I - IIiIiII11i
def OOOoO ( thumb , name , url , id ) :
 if 14 - 14: OOoOO00OOO0OO . iIiiiI1IiI1I1 . IIiIiII11i . I1I11I1I1I / OO0OOO00o
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( O0o0 ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   o0Oo0oO0oOO00 ( name , url , '' , thumb , thumb )
  else :
   o0Oo0oO0oOO00 ( name , url , '' , I1IiI , I1ii11iIi11i )
 else :
  if 'youtube.com/watch?v=' in url :
   url = 'plugin://plugin.video.youtube/play/?video_id=%s' % ( url . split ( '=' ) [ - 1 ] )
  elif 'dailymotion.com/video/' in url :
   url = url . split ( '/' ) [ - 1 ] . split ( '_' ) [ 0 ]
   url = 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=%s' % url
  else :
   url = url
  if 'tvg-logo' in thumb :
   thumb = re . compile ( O0o0 ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   IiIi1 ( name , url , 1 , thumb , thumb )
  else :
   IiIi1 ( name , url , 1 , I1IiI , I1ii11iIi11i )
   if 34 - 34: O0oo0OO0oOOOo
def OooO0ooo0o ( thumb , name , url , id ) :
 if 47 - 47: IIiIiII11i
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( O0o0 ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   o0Oo0oO0oOO00 ( name , url , '' , thumb , thumb )
  else :
   o0Oo0oO0oOO00 ( name , url , '' , I1IiI , I1ii11iIi11i )
 else :
  if 'youtube.com/watch?v=' in url :
   url = 'plugin://plugin.video.youtube/play/?video_id=%s' % ( url . split ( '=' ) [ - 1 ] )
  elif 'dailymotion.com/video/' in url :
   url = url . split ( '/' ) [ - 1 ] . split ( '_' ) [ 0 ]
   url = 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=%s' % url
  else :
   url = url
  if 'tvg-logo' in thumb :
   thumb = re . compile ( O0o0 ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 4 - 4: OooO0OO % OOoOO00OOO0OO
   IiIi1 ( name , url , 1 , thumb , thumb , id )
   if 10 - 10: Ii1iIiII1ii1 . IIiIiII11i - Iii + Ii1iIiII1ii1 - ooOoO
  else :
   if 82 - 82: Ooo00oOo0oOo + I1I11I1I1I
   IiIi1 ( name , url , 1 , I1IiI , I1ii11iIi11i , id )
   if 39 - 39: iii11 % iIiiiI1IiI1I1 % ooOoO % IIiIiII11i * Iii111II + I1iiI111IiI
def iI1I11iiI1i ( name , url , thumb , id , trailer ) :
 if 68 - 68: iii1I1 + i11iIiiIii
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( O0o0 ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   o0Oo0oO0oOO00 ( name , url , '' , thumb , thumb , id , trailer )
  else :
   o0Oo0oO0oOO00 ( name , url , '' , I1IiI , I1ii11iIi11i , id , trailer )
 else :
  if 'youtube.com/watch?v=' in url :
   url = 'plugin://plugin.video.youtube/play/?video_id=%s' % ( url . split ( '=' ) [ - 1 ] )
  elif 'youtube.com/watch?v=' in trailer :
   trailer = 'plugin://plugin.video.youtube/play/?video_id=%s' % ( url . split ( '=' ) [ - 1 ] )
  else :
   url = url
   trailer = trailer
  if 'tvg-logo' in thumb :
   thumb = re . compile ( O0o0 ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 69 - 69: iIiiiI1IiI1I1 * iIiiiI1IiI1I1 * i11iIiiIii + OooO0OO / O0oo0OO0oOOOo % I1I111
   if '[Rapidvideo]' in name :
    if 58 - 58: O0oo0OO0oOOOo * OO0OOO00o + ooOoO % O0oo0OO0oOOOo
    name = '[COLOR yellow]%s[/COLOR]' % name
   if '[rapidvideo]' in name :
    if 25 - 25: iii1I1 % Iii111II * Ooo00oOo0oOo
    name = '[COLOR yellow]%s[/COLOR]' % name
   elif '[streamago]' in name :
    if 6 - 6: I1iiI111IiI . Ii1iIiII1ii1 * Ii11I . o0oOOo0O0Ooo
    name = '[COLOR orange]%s[/COLOR]' % name
   elif '[Streamgo]' in name :
    if 98 - 98: o0oOOo0O0Ooo
    name = '[COLOR orange]%s[/COLOR]' % name
   elif '[Openload]' in name :
    if 65 - 65: Ii11I / Iii % Ii1iIiII1ii1
    name = '[COLOR blue]%s[/COLOR]' % name
   elif '[openload]' in name :
    if 45 - 45: Ii11I
    name = '[COLOR blue]%s[/COLOR]' % name
   elif '[Vidoza]' in name :
    if 66 - 66: Iii
    name = '[COLOR green]%s[/COLOR]' % name
   elif '[vidoza]' in name :
    if 56 - 56: ooOoO
    name = '[COLOR green]%s[/COLOR]' % name
   elif '[Streamcloud]' in name :
    if 61 - 61: OO0OOO00o / O0oo0OO0oOOOo / iii1I1 * ooOoO
    name = '[COLOR skyblue]%s[/COLOR]' % name
   elif '[streamcloud]' in name :
    if 23 - 23: iii11 - O0oo0OO0oOOOo + OOoOO00OOO0OO
    name = '[COLOR skyblue]%s[/COLOR]' % name
    if 12 - 12: OooO0OO / Ooo00oOo0oOo % OO0OOO00o / i11iIiiIii % IIiIiII11i
   elif '[streamcherry]' in name :
    if 15 - 15: iIiiiI1IiI1I1 % IIiIiII11i - iii1I1 * I1I111 + OOoOO00OOO0OO
    name = '[COLOR lime]%s[/COLOR]' % name
    if 11 - 11: I1iiI111IiI * I1I111 - Ii11I
   elif '[Streamcherry]' in name :
    if 66 - 66: Ii11I . i11iIiiIii - I1iiI111IiI * OO0OOO00o + IIiIiII11i * Iii111II
    name = '[COLOR lime]%s[/COLOR]' % name
    if 74 - 74: iii1I1
   elif '[Okru]' in name :
    if 61 - 61: iii1I1 - ooOooo000oOO * I1I11I1I1I % Ooo00oOo0oOo * iIiiiI1IiI1I1 + Iii
    name = '[COLOR deeppink]%s[/COLOR]' % name
   elif '[okru]' in name :
    if 71 - 71: OOoOO00OOO0OO / OOoOO00OOO0OO * iii11 * iii11 / I1I11I1I1I
    name = '[COLOR deeppink]%s[/COLOR]' % name
   elif '[Multi enlace]' in name :
    if 35 - 35: O0oo0OO0oOOOo * OO0OOO00o * OooO0OO % iii1I1 . Ii11I
    name = '[COLOR white]%s[/COLOR]' % name
   elif '[4k]' in name :
    if 58 - 58: OOoOO00OOO0OO + I1I11I1I1I * I1iiI111IiI * i11iIiiIii - iIiiiI1IiI1I1
    name = '[COLOR white]%s[/COLOR]' % name
   elif '[sd]' in name :
    if 68 - 68: IIiIiII11i % I1I11I1I1I
    name = '[COLOR grey]%s[/COLOR]' % name
   elif '[hd]' in name :
    if 26 - 26: I1I11I1I1I % i11iIiiIii % iIiiiI1IiI1I1 % OOoOO00OOO0OO * OOoOO00OOO0OO * Iii111II
    name = '[COLOR white]%s[/COLOR]' % name
   elif '[Realstream]' in name :
    if 24 - 24: I1I11I1I1I % ooOooo000oOO - Ooo00oOo0oOo + OooO0OO * Iii111II
    name = '[COLOR gold]%s[/COLOR]' % name
   else :
    if 2 - 2: I1I111 - Ii1iIiII1ii1
    name = '[COLOR red]%s[/COLOR]' % name
    if 83 - 83: iii11 % OO0OOO00o % I1I111 - I1I11I1I1I * O0oo0OO0oOOOo / IIiIiII11i
   IiIi1 ( name , url , 1 , thumb , thumb , id , trailer )
   if 18 - 18: Iii + iIiiiI1IiI1I1 - I1I11I1I1I - OooO0OO
  else :
   if 71 - 71: IIiIiII11i
   IiIi1 ( name , url , 1 , I1IiI , I1ii11iIi11i , id , trailer )
   if 33 - 33: ooOooo000oOO
def OOO0ooo ( name , trailer ) :
 if 7 - 7: OO0OOO00o + o0oOOo0O0Ooo . OooO0OO / iii1I1
 if 22 - 22: Ooo00oOo0oOo - Ooo00oOo0oOo % O0oo0OO0oOOOo . ooOooo000oOO + iii11
 oooO0 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
 Oo00OOo00O = oooO0
 o0Ii1Iii111IiI1 = xbmcgui . ListItem ( name , trailer , path = Oo00OOo00O )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o0Ii1Iii111IiI1 )
 return
 if 98 - 98: ooOooo000oOO - IIiIiII11i % OooO0OO + ooOoO . I1I111
 if 56 - 56: I1I11I1I1I / iii11 + i11iIiiIii + O0oo0OO0oOOOo
def O0O0o0o0o ( name , url ) :
 import urlresolver
 from urlresolver import common
 if 9 - 9: iii1I1 + Ii11I - iIiiiI1IiI1I1 - I1I111 + OO0OOO00o
 o000O0OOoo = urlresolver . HostedMediaFile ( url )
 if 60 - 60: OooO0OO * ooOooo000oOO % Iii + iii11
 if not o000O0OOoo :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 52 - 52: o0oOOo0O0Ooo
  return False
  if 84 - 84: I1I111 / Ii1iIiII1ii1
  if 86 - 86: Ii11I * I1I11I1I1I - ooOoO . Ii11I % iIiiiI1IiI1I1 / O0oo0OO0oOOOo
 try :
  IiIIiIIIiIii = o000O0OOoo . resolve ( )
  if not IiIIiIIIiIii or not isinstance ( IiIIiIIIiIii , basestring ) :
   try : I1i11II = IiIIiIIIiIii . msg
   except : I1i11II = url
   raise Exception ( I1i11II )
 except Exception as OooooOOoo0 :
  try : I1i11II = str ( OooooOOoo0 )
  except : I1i11II = url
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 31 - 31: iii11 / Ii1iIiII1ii1 * OO0OOO00o . I1I11I1I1I
  return False
  if 89 - 89: ooOoO
 iII11i = OO0o . getSetting ( 'notificar' )
 if iII11i == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
 II = xbmcgui . ListItem ( path = IiIIiIIIiIii )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II )
 if 41 - 41: Iii111II * Ooo00oOo0oOo - I1I111 + iii1I1
def IiIIIII11I ( name , url ) :
 if 17 - 17: IIiIiII11i + O0oo0OO0oOOOo * OOoOO00OOO0OO * Ii11I
 if 36 - 36: ooOoO + iii1I1
 if 'https://www.rapidvideo.com/v/' in url :
  if 5 - 5: iii1I1 * Ii11I
  OO = o0OoOO000ooO0 ( url )
  o0o0o0oO0oOO = re . compile ( 'source src="([^"]+)' ) . findall ( OO )
  for url in o0o0o0oO0oOO :
   if 46 - 46: Ooo00oOo0oOo
   try :
    iII11i = OO0o . getSetting ( 'notificar' )
    if iII11i == 'true' :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    II = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II )
    if 33 - 33: I1iiI111IiI - I1I11I1I1I * IIiIiII11i - iii1I1 - O0oo0OO0oOOOo
   except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 84 - 84: ooOooo000oOO + iii1I1 - Ii11I * Ii11I
   if 61 - 61: IIiIiII11i . iii11 . IIiIiII11i / iii1I1
 else :
  if 72 - 72: o0oOOo0O0Ooo
  import urlresolver
  from urlresolver import common
  if 82 - 82: Ii11I + IIiIiII11i / i11iIiiIii * Iii111II . IIiIiII11i
  o000O0OOoo = urlresolver . HostedMediaFile ( url )
  if 63 - 63: Iii111II
  if not o000O0OOoo :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 6 - 6: Ooo00oOo0oOo / Iii111II
   if 57 - 57: OOoOO00OOO0OO
  try :
   IiIIiIIIiIii = o000O0OOoo . resolve ( )
   if not IiIIiIIIiIii or not isinstance ( IiIIiIIIiIii , basestring ) :
    try : I1i11II = IiIIiIIIiIii . msg
    except : I1i11II = url
    raise Exception ( I1i11II )
  except Exception as OooooOOoo0 :
   try : I1i11II = str ( OooooOOoo0 )
   except : I1i11II = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 67 - 67: Iii . Ooo00oOo0oOo
  iII11i = OO0o . getSetting ( 'notificar' )
  if iII11i == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  II = xbmcgui . ListItem ( path = IiIIiIIIiIii )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II )
  if 87 - 87: iii11 % I1I111
 return
 if 83 - 83: I1I11I1I1I - OOoOO00OOO0OO
 if 35 - 35: o0oOOo0O0Ooo - iIiiiI1IiI1I1 + o0oOOo0O0Ooo
 if 86 - 86: iIiiiI1IiI1I1 + Ii11I . i11iIiiIii - I1I111
 if 51 - 51: Ii11I
def I11IIIiIi11 ( ) :
 if 39 - 39: I1I111 % ooOoO % Ii11I . o0oOOo0O0Ooo
 if 86 - 86: Iii * IIiIiII11i
 OooO0oOo = [ ]
 oOOo00O0OOOo = sys . argv [ 2 ]
 if len ( oOOo00O0OOOo ) >= 2 :
  i11I1I1iiI = sys . argv [ 2 ]
  I1i1iii1Ii = i11I1I1iiI . replace ( '?' , '' )
  if ( i11I1I1iiI [ len ( i11I1I1iiI ) - 1 ] == '/' ) :
   i11I1I1iiI = i11I1I1iiI [ 0 : len ( i11I1I1iiI ) - 2 ]
  iI = I1i1iii1Ii . split ( '&' )
  OooO0oOo = { }
  for O0O00OOo in range ( len ( iI ) ) :
   OoOOo = { }
   OoOOo = iI [ O0O00OOo ] . split ( '=' )
   if ( len ( OoOOo ) ) == 2 :
    OooO0oOo [ OoOOo [ 0 ] ] = OoOOo [ 1 ]
 return OooO0oOo
 if 17 - 17: o0oOOo0O0Ooo
 if 1 - 1: Ooo00oOo0oOo
 if 78 - 78: Iii111II + OOoOO00OOO0OO - ooOoO
def i1I1iIi1IiI ( ) :
 i1111O0O000OOOo = xbmcgui . Dialog ( )
 list = (
 i11ii1Ii1 ,
 i1i1II1i11
 )
 if 91 - 91: OOoOO00OOO0OO / o0oOOo0O0Ooo * o0oOOo0O0Ooo
 Ii1 = i1111O0O000OOOo . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=gold]Accede a themoviedb.com[/COLOR]' ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 68 - 68: I1I111 - i11iIiiIii - iii11 + Ii11I
 if Ii1 :
  if 99 - 99: Ii11I * ooOooo000oOO * o0oOOo0O0Ooo / ooOoO - Ii11I % OO0OOO00o
  if Ii1 < 0 :
   return
  oo00O0ooOo = list [ Ii1 - 2 ]
  return oo00O0ooOo ( )
 else :
  oo00O0ooOo = list [ Ii1 ]
  return oo00O0ooOo ( )
 return
 if 62 - 62: o0oOOo0O0Ooo - Ii11I
def oo0O0oo ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 14 - 14: ooOoO / o0oOOo0O0Ooo / iii1I1 + iIiiiI1IiI1I1
ooO00O00oOO = oo0O0oo ( )
if 40 - 40: I1iiI111IiI . iii11 + OooO0OO + Iii111II + ooOooo000oOO
def i11ii1Ii1 ( ) :
 if ooO00O00oOO == 'android' :
  oOoO0 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  oOoO0 = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 26 - 26: iIiiiI1IiI1I1
  if 87 - 87: Iii111II / IIiIiII11i - iii1I1 % Ii11I % Ii1iIiII1ii1 % iii1I1
def i1i1II1i11 ( ) :
 if 29 - 29: IIiIiII11i . OooO0OO % Iii111II - I1iiI111IiI
 main ( )
 if 8 - 8: o0oOOo0O0Ooo
 if 32 - 32: iii11 / I1I11I1I1I
 if 45 - 45: Iii111II + Iii * i11iIiiIii / O0oo0OO0oOOOo % OOoOO00OOO0OO * ooOoO
def i1o0oooO ( ) :
 i1111O0O000OOOo = xbmcgui . Dialog ( )
 ooOo = (
 o0oO0OoO0 ,
 oOOOOOoOO
 )
 if 81 - 81: I1I11I1I1I + i11iIiiIii / I1iiI111IiI
 Ii1 = i1111O0O000OOOo . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 85 - 85: i11iIiiIii + ooOooo000oOO * Ii11I
 if Ii1 :
  if 1 - 1: o0oOOo0O0Ooo / iii1I1 . Iii
  if Ii1 < 0 :
   return
  oo00O0ooOo = ooOo [ Ii1 - 2 ]
  return oo00O0ooOo ( )
 else :
  oo00O0ooOo = ooOo [ Ii1 ]
  return oo00O0ooOo ( )
 return
 if 57 - 57: OOoOO00OOO0OO . iii1I1 + I1I11I1I1I
def oo0O0oo ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 43 - 43: ooOooo000oOO % I1iiI111IiI
ooO00O00oOO = oo0O0oo ( )
if 69 - 69: I1iiI111IiI % Iii
def o0oO0OoO0 ( ) :
 if ooO00O00oOO == 'android' :
  oOoO0 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  oOoO0 = webbrowser . open ( 'https://olpair.com/' )
  if 86 - 86: iii11 / iii11
  if 28 - 28: i11iIiiIii / OO0OOO00o . iIiiiI1IiI1I1 / I1I11I1I1I
def oOOOOOoOO ( ) :
 if 72 - 72: IIiIiII11i / OooO0OO + I1I111 / Ii11I * I1I111
 main ( )
 if 34 - 34: ooOoO * ooOoO % IIiIiII11i + I1iiI111IiI * iIiiiI1IiI1I1 % I1I111
 if 25 - 25: OOoOO00OOO0OO + Ii11I . OO0OOO00o % Ii11I * O0oo0OO0oOOOo
def ii1IiIi11 ( name , url , id , trailer ) :
 i1111O0O000OOOo = xbmcgui . Dialog ( )
 ooOo = (
 iiiii1ii1 ,
 IiiiI1 ,
 OOOo0 ,
 i1I1iIi1IiI
 )
 if 79 - 79: Iii % O0oo0OO0oOOOo / iIiiiI1IiI1I1 + Ii11I * Iii
 Ii1 = i1111O0O000OOOo . select ( '[COLOR=yellow]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=yellow]Reproducir [/COLOR] [COLOR orange]' + name + '[/COLOR]' ,

 '[COLOR=yellow]Reproducir Trailer de: [/COLOR][COLOR orange]' + name + '[/COLOR]' ,

 '[COLOR=yellow]      Mas Informacion, ver trailers  [/COLOR]' ,

 '[COLOR orange]        Accede a la web MovieDB[/COLOR]' ] )
 if 30 - 30: IIiIiII11i / OOoOO00OOO0OO + I1iiI111IiI / Iii111II * ooOoO
 if Ii1 :
  if 16 - 16: iii1I1 / i11iIiiIii
  if Ii1 < 0 :
   return
  oo00O0ooOo = ooOo [ Ii1 - 4 ]
  return oo00O0ooOo ( )
 else :
  oo00O0ooOo = ooOo [ Ii1 ]
  return oo00O0ooOo ( )
 return
 if 64 - 64: i11iIiiIii / I1I111 * o0oOOo0O0Ooo
 if 73 - 73: iii1I1 - Ii11I - iii11 - OooO0OO
def iiiii1ii1 ( ) :
 if 65 - 65: OO0OOO00o
 IiIIIII11I ( i1i1Iiii1I1 , oooO0 )
 if 7 - 7: Ii1iIiII1ii1 . Ii11I / Iii111II . O0oo0OO0oOOOo * OOoOO00OOO0OO - I1I11I1I1I
def IiiiI1 ( ) :
 if 37 - 37: ooOooo000oOO . Ii11I / ooOoO * I1iiI111IiI
 OOO0ooo ( i1i1Iiii1I1 , iIiIiiIIiIIi )
 if 7 - 7: Iii * OOoOO00OOO0OO + I1I11I1I1I % i11iIiiIii
 if 8 - 8: Ooo00oOo0oOo * ooOoO
def OOOo0 ( ) :
 if 73 - 73: OO0OOO00o / iii11 / OOoOO00OOO0OO / Iii
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  III1ii = id
  if 41 - 41: Ooo00oOo0oOo . iii1I1 + OooO0OO
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % III1ii )
  if 100 - 100: I1I111 + Iii
 if iII11i == 'true' :
  if 73 - 73: o0oOOo0O0Ooo - ooOooo000oOO % Ooo00oOo0oOo / Iii
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + i1i1Iiii1I1 + "[/COLOR] ,10000)" )
  if 40 - 40: Iii111II * Ooo00oOo0oOo - OooO0OO / Ii1iIiII1ii1 / i11iIiiIii
  if 83 - 83: Iii111II / ooOooo000oOO - i11iIiiIii . iIiiiI1IiI1I1 + iii1I1
  if 59 - 59: ooOoO % iii1I1
  if 92 - 92: I1I111 % I1iiI111IiI / Iii111II % Iii111II * OooO0OO
  if 74 - 74: ooOoO . OooO0OO % Iii % Ii1iIiII1ii1
  if 87 - 87: iii11 - i11iIiiIii
  if 78 - 78: i11iIiiIii / iIiiiI1IiI1I1 - OO0OOO00o
  if 23 - 23: OOoOO00OOO0OO
  if 40 - 40: OO0OOO00o - I1I11I1I1I / iii1I1
  if 14 - 14: Iii111II
  if 5 - 5: OO0OOO00o . iIiiiI1IiI1I1 % iIiiiI1IiI1I1
def ooO0oo0o0 ( ) :
 if 9 - 9: OooO0OO + Iii111II / OooO0OO . iii11 * Ooo00oOo0oOo
 i1I1iIi1IiI ( )
 if 45 - 45: i11iIiiIii
def o00oo0 ( ) :
 if 93 - 93: i11iIiiIii % iIiiiI1IiI1I1 % i11iIiiIii + OO0OOO00o / OO0OOO00o / I1I11I1I1I
 PLAYVIDEO3 ( i1i1Iiii1I1 , oooO0 )
 if 49 - 49: O0oo0OO0oOOOo . Iii111II . i11iIiiIii - I1I11I1I1I / I1I111
 if 62 - 62: O0oo0OO0oOOOo
def o0Oo0oO0oOO00 ( name , url , mode , iconimage , fanart ) :
 if 1 - 1: Ii1iIiII1ii1 / Ii1iIiII1ii1 - i11iIiiIii
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 iII = True
 oO0O000oOoo0O = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 oO0O000oOoo0O . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 oO0O000oOoo0O . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  OO0oIiII1iiI = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  iII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = oO0O000oOoo0O , isFolder = True )
  return iII
 iII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = oO0O000oOoo0O , isFolder = True )
 return iII
 if 9 - 9: iii11 * o0oOOo0O0Ooo - o0oOOo0O0Ooo
def IiIi1 ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 16 - 16: OooO0OO * o0oOOo0O0Ooo - OO0OOO00o . Ii1iIiII1ii1 % OOoOO00OOO0OO / OO0OOO00o
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 Ii11iI1ii1111 = [ ]
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 oO0O000oOoo0O = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 oO0O000oOoo0O . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 oO0O000oOoo0O . setProperty ( 'fanart_image' , fanart )
 oO0O000oOoo0O . setProperty ( 'IsPlayable' , 'true' )
 if 42 - 42: ooOooo000oOO + ooOooo000oOO * I1I11I1I1I
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  Ii11iI1ii1111 . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  oO0O000oOoo0O . addContextMenuItems ( Ii11iI1ii1111 , replaceItems = True )
 iII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = oO0O000oOoo0O )
 return iII
 if 78 - 78: IIiIiII11i
def OOoo0 ( ) :
 if 36 - 36: OO0OOO00o + OOoOO00OOO0OO - Ii1iIiII1ii1 + iIiiiI1IiI1I1 + IIiIiII11i
 if 4 - 4: I1I11I1I1I . OOoOO00OOO0OO + I1I111 * ooOooo000oOO . Ooo00oOo0oOo
 if 87 - 87: Ii11I / Iii / i11iIiiIii
 IiI111111IIII = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 IiI111111IIII . doModal ( )
 if ( IiI111111IIII . isConfirmed ( ) ) :
  if 74 - 74: iii11 / Iii111II % OO0OOO00o
  i1I1iI1iIi111i = urllib . quote_plus ( IiI111111IIII . getText ( ) ) . replace ( '+' , ' ' )
  if 88 - 88: Ii11I - i11iIiiIii % OO0OOO00o * OOoOO00OOO0OO + Iii111II
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 52 - 52: I1I11I1I1I . OooO0OO + Ii11I % Iii
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % i1I1iI1iIi111i )
    if 62 - 62: OO0OOO00o
    if iII11i == 'true' :
     if 15 - 15: OOoOO00OOO0OO + I1I111 . O0oo0OO0oOOOo * Iii . Ii11I
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + i1i1Iiii1I1 + "[/COLOR] ,10000)" )
     if 18 - 18: o0oOOo0O0Ooo % I1I11I1I1I + ooOooo000oOO % I1I111
   except :
    if 72 - 72: iIiiiI1IiI1I1
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 45 - 45: iii1I1 - OO0OOO00o % ooOooo000oOO
    if 38 - 38: ooOooo000oOO % O0oo0OO0oOOOo - IIiIiII11i
    if 87 - 87: Iii % OooO0OO
i11I1I1iiI = I11IIIiIi11 ( )
oooO0 = None
i1i1Iiii1I1 = None
ooooOoO0O = None
IIIIIIII = None
id = None
iIiIiiIIiIIi = None
if 83 - 83: iIiiiI1IiI1I1
if 66 - 66: Ii1iIiII1ii1
try :
 oooO0 = urllib . unquote_plus ( i11I1I1iiI [ "url" ] )
except :
 pass
try :
 i1i1Iiii1I1 = urllib . unquote_plus ( i11I1I1iiI [ "name" ] )
except :
 pass
try :
 ooooOoO0O = int ( i11I1I1iiI [ "mode" ] )
except :
 pass
try :
 IIIIIIII = urllib . unquote_plus ( i11I1I1iiI [ "iconimage" ] )
except :
 pass
try :
 id = int ( i11I1I1iiI [ "id" ] )
except :
 pass
try :
 iIiIiiIIiIIi = urllib . unquote_plus ( i11I1I1iiI [ "trailer" ] )
except :
 pass
 if 67 - 67: ooOooo000oOO / Iii . O0oo0OO0oOOOo / O0oo0OO0oOOOo - I1I111 - IIiIiII11i
 if 46 - 46: ooOoO * iii1I1 / ooOoO + Iii
print "Mode: " + str ( ooooOoO0O )
print "URL: " + str ( oooO0 )
print "Name: " + str ( i1i1Iiii1I1 )
print "iconimage: " + str ( IIIIIIII )
print "id: " + str ( id )
print "trailer: " + str ( iIiIiiIIiIIi )
if 56 - 56: O0oo0OO0oOOOo . I1I11I1I1I
if ooooOoO0O == None or oooO0 == None or len ( oooO0 ) < 1 :
 i1II1 ( )
 Ii1iIIIi1ii = OO0o . getSetting ( 'aviso' )
 if Ii1iIIIi1ii == 'true' :
  OOo0oO00ooO00 ( )
elif ooooOoO0O == 1 :
 ii1IiIi11 ( i1i1Iiii1I1 , oooO0 , id , iIiIiiIIiIIi )
elif ooooOoO0O == 2 :
 IIII1 ( )
elif ooooOoO0O == 3 :
 oOOO0oo0 ( )
elif ooooOoO0O == 4 :
 i1iI1 ( )
elif ooooOoO0O == 5 :
 IIioOoO00oo0O ( )
elif ooooOoO0O == 6 :
 II1111ii ( )
elif ooooOoO0O == 7 :
 o00o000oo ( )
elif ooooOoO0O == 8 :
 IiiI1i ( )
elif ooooOoO0O == 9 :
 I1iIi1iIiiIiI ( )
elif ooooOoO0O == 10 :
 OO0ooo0oOO ( )
elif ooooOoO0O == 11 :
 oO0oO0 ( )
elif ooooOoO0O == 12 :
 oOIIi1iiii1iI ( )
elif ooooOoO0O == 13 :
 IIiii11i ( )
elif ooooOoO0O == 14 :
 iIi1 ( )
elif ooooOoO0O == 15 :
 I1I11iI11iI1i ( )
elif ooooOoO0O == 16 :
 o0 ( )
elif ooooOoO0O == 17 :
 iiI1 ( )
elif ooooOoO0O == 18 :
 ooOooo0 ( )
elif ooooOoO0O == 19 :
 oOooO0 ( )
elif ooooOoO0O == 20 :
 oooO0o0o0O0 ( )
elif ooooOoO0O == 21 :
 i11iIiI11I1i ( )
elif ooooOoO0O == 22 :
 I1IIIiii1 ( )
elif ooooOoO0O == 23 :
 O0Oo ( )
elif ooooOoO0O == 24 :
 OOoOoo0 ( )
elif ooooOoO0O == 25 :
 oOoOOo0oo0 ( )
elif ooooOoO0O == 27 :
 Calidad4k ( )
elif ooooOoO0O == 98 :
 busqueda_global ( )
elif ooooOoO0O == 97 :
 i1o0oooO ( )
elif ooooOoO0O == 99 :
 oOo0O ( )
elif ooooOoO0O == 100 :
 menu_player ( i1i1Iiii1I1 , oooO0 )
elif ooooOoO0O == 111 :
 IIi ( )
elif ooooOoO0O == 115 :
 OOO0ooo ( oooO0 )
elif ooooOoO0O == 116 :
 i1i1iI1iiiI ( )
elif ooooOoO0O == 119 :
 iiI11i1II ( )
elif ooooOoO0O == 120 :
 o0O00OooOOOOO ( )
elif ooooOoO0O == 121 :
 OoooO00o ( )
elif ooooOoO0O == 125 :
 oOOoo0000O0o0 ( )
elif ooooOoO0O == 126 :
 II1I1Ii ( )
elif ooooOoO0O == 127 :
 OOoo0 ( )
 if 53 - 53: iii11 % OOoOO00OOO0OO . Ooo00oOo0oOo - Ii11I
xbmcplugin . endOfDirectory ( O0O0OO0O0O0 ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
