# -*- coding: utf-8 -*-
# Real stream by Netai 2019
import urllib, urllib2, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import cookielib,webbrowser
import traceback,datetime,HTMLParser,httplib
import urlresolver
import cookielib,base64
import requests
addon = xbmcaddon.Addon('plugin.video.Real.stream')
addon_version = addon.getAddonInfo('version')
plugin_handle = int(sys.argv[1])
mysettings = xbmcaddon.Addon(id = 'plugin.video.Real.stream')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
#Imagenes
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
extended = xbmc.translatePath(os.path.join(home, 'extended_info.png'))
buscar = xbmc.translatePath(os.path.join(home, 'buscar.png'))
pair = xbmc.translatePath(os.path.join(home, 'openload.jpg'))
theMovieDB = xbmc.translatePath(os.path.join(home, 'theMovieDB.jpg'))
novedades = xbmc.translatePath(os.path.join(home, 'estrenos.png'))
estrenos = xbmc.translatePath(os.path.join(home, 'encines.jpg'))
recomendadas = xbmc.translatePath(os.path.join(home, 'recomendadas.jpg'))
p_accion = xbmc.translatePath(os.path.join(home, 'accion.jpg'))
animacion = xbmc.translatePath(os.path.join(home, 'animacion.jpg'))
aventuras = xbmc.translatePath(os.path.join(home, 'aventuras.jpg'))
belico = xbmc.translatePath(os.path.join(home, 'belico.jpg'))
cifi = xbmc.translatePath(os.path.join(home, 'ciencia-ficcion.jpg'))
comedia = xbmc.translatePath(os.path.join(home, 'comedia.jpg'))
crimen = xbmc.translatePath(os.path.join(home, 'crimen.jpg'))
drama = xbmc.translatePath(os.path.join(home, 'drama.jpg'))
familiar = xbmc.translatePath(os.path.join(home, 'familiar.jpg'))
fantasia = xbmc.translatePath(os.path.join(home, 'fantasia.jpg'))
historia = xbmc.translatePath(os.path.join(home, 'historia.jpg'))
superheroes = xbmc.translatePath(os.path.join(home, 'marvel.png'))
misterio = xbmc.translatePath(os.path.join(home, 'misterio.jpg'))
musical = xbmc.translatePath(os.path.join(home, 'musical.jpg'))
romance = xbmc.translatePath(os.path.join(home, 'romance.jpg'))
spain = xbmc.translatePath(os.path.join(home, 'spain.jpg'))
suspense = xbmc.translatePath(os.path.join(home, 'suspense.jpg'))
terror = xbmc.translatePath(os.path.join(home, 'terror.jpg'))
thriller = xbmc.translatePath(os.path.join(home, 'thriller.jpg'))
western = xbmc.translatePath(os.path.join(home, 'western.jpg'))
sagas = xbmc.translatePath(os.path.join(home, 'sagas_cine.jpg'))
calidad4k = xbmc.translatePath(os.path.join(home, '4k.jpg'))
torrent = xbmc.translatePath(os.path.join(home, 'torrent.jpg'))
#Menus
menu_pelis = xbmc.translatePath(os.path.join(home, 'peliculas.png'))
ajustes = xbmc.translatePath(os.path.join(home, 'ajustes.png'))
vid = xbmc.translatePath(os.path.join(home, 'videoteca.png'))
favicon = xbmc.translatePath(os.path.join(home, 'favorites.png'))
resolver = xbmc.translatePath(os.path.join(home, 'resolver.png'))
#Ajustes
mostrar_cat = addon.getSetting('mostrar_cat')
videos = addon.getSetting('videos')
activar = addon.getSetting('activar')
favcopy = addon.getSetting('favcopy')
anticopia = addon.getSetting('anticopia')
notificar = addon.getSetting('notificar')
mostrar_bus = addon.getSetting('mostrar_bus') 
aviso = addon.getSetting('aviso')
RealStream_Settings = addon.getSetting('RealStream_Settings')
Resolver_Settings = addon.getSetting('Resolver_Settings')
fav = addon.getSetting('fav') 
ayudamulti = addon.getSetting('ayudamulti') 
texto = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0vYmllbnZlbmlkYS50eHQ='.decode('base64')
Forceupdate = addon.getSetting('Forceupdate')
if Forceupdate == 'true':  
    xbmc.executebuiltin('UpdateAddonRepos()')
    xbmc.executebuiltin('UpdateLocalAddons()')
	
#regexs
u_tube = 'http://www.youtube.com'
urly = 'aHR0cDovL3kzei5zag=='.decode('base64')
decode32 = '.xsl.pt'
myurl = urly + decode32
texto_regex = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*texto3=[\'"](.*?)[\'"]\s*'
m3u_thumb_regex = 'tvg-logo=[\'"](.*?)[\'"]'
m3u_regex = '#(.+?),(.+)\s*(.+)\s*(.*)'
url_regex = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
reg_url = 'enlace=[\'"](.*?)[\'"]'

#categorias

db = 'http://netai.eu/realstream/todas.m3u'
op = 'https://raw.githubusercontent.com/Andorth/rs/master/accion.m3u'
op1 = 'https://raw.githubusercontent.com/Andorth/rs/master/estrenos.m3u'
op2 = 'https://raw.githubusercontent.com/Andorth/rs/master/recomendadas.m3u'
op3 = 'https://raw.githubusercontent.com/Andorth/rs/master/accion.m3u'
op4 = 'https://raw.githubusercontent.com/Andorth/rs/master/animacion.m3u'
op5 = 'https://raw.githubusercontent.com/Andorth/rs/master/aventuras.m3u'
op6 = 'https://raw.githubusercontent.com/Andorth/rs/master/belico.m3u'
op7 = 'https://raw.githubusercontent.com/Andorth/rs/master/cifi.m3u'
op8 = 'https://raw.githubusercontent.com/Andorth/rs/master/comedia.m3u'
op9 = 'https://raw.githubusercontent.com/Andorth/rs/master/crimen.m3u'
op10 = 'https://raw.githubusercontent.com/Andorth/rs/master/drama.m3u'
op11 = 'https://raw.githubusercontent.com/Andorth/rs/master/familiar.m3u'
op12 = 'https://raw.githubusercontent.com/Andorth/rs/master/fantasia.m3u'
op13 = 'https://raw.githubusercontent.com/Andorth/rs/master/historia.m3u'
op14 = 'https://raw.githubusercontent.com/Andorth/rs/master/misterio.m3u'
op15 = 'https://raw.githubusercontent.com/Andorth/rs/master/musical.m3u'
op16 = 'https://raw.githubusercontent.com/Andorth/rs/master/romance.m3u'
op17 = 'https://raw.githubusercontent.com/Andorth/rs/master/thriller.m3u'
op18 = 'https://raw.githubusercontent.com/Andorth/rs/master/suspense.m3u'
op19 = 'https://raw.githubusercontent.com/Andorth/rs/master/terror.m3u'
op20 = 'https://raw.githubusercontent.com/Andorth/rs/master/western.m3u'
op21 = 'https://raw.githubusercontent.com/Andorth/rs/master/spain.m3u'
op22 = 'https://raw.githubusercontent.com/Andorth/rs/master/superheroes.m3u'
op23 = 'https://raw.githubusercontent.com/Andorth/rs/master/sagas.m3u'
op24 = 'https://raw.githubusercontent.com/Andorth/rs/master/4k.m3u'


def search(): 

## ESTA FUNCION BUSCA EN LAS LISTAS m3u DENTRO DE LAS CATEGORIAS. | Cuantas mas categorias, mas lento ira el buscador a no ser que hagamos buscadores individuales.
	try:
		keyb = xbmc.Keyboard('', 'Nombre de la pelicula')
		keyb.doModal()
		if (keyb.isConfirmed()):
		
			searchText = urllib.quote_plus(keyb.getText()).replace('+', ' ')
			content_db = make_request(db)
			match = re.compile(m3u_regex).findall(content_db)
			
			for thumb, name, url, id in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(thumb, name, url, id)
	except:
		pass

def mensaje(): 

	content = make_request(texto)
	match = re.compile(texto_regex).findall(content)
	for texto1,texto2,texto3 in match:
		try:
		
			msg1 = texto1
			msg2 = texto2
			msg3 = texto3
		

			line1 = "[COLOR=red][B]" + msg1 + "[/B][/COLOR]"
			line2 = "[COLOR yellow]" + msg2 + "[/COLOR]"
			line3 = "[COLOR yellow]" + msg3 + "[/COLOR]"

			xbmcgui.Dialog().ok("Real Stream", line1, line2, line3)
			


			if not xbmc.getCondVisibility('System.HasAddon(script.extendedinfo)'):
				xbmcgui.Dialog().ok("El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]","[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]")

			
		except:
			pass
		
def removeAccents(s):
## Nos cargamos los acentos, phyton no los usa ni los reconoce. 
	return ''.join((c for c in unicodedata.normalize('NFD', s.decode('utf-8')) if unicodedata.category(c) != 'Mn'))
					
def read_file(file):
## FUNCION QUE LEE LOS FICHEROS:
    try:
        f = open(file, 'r')
        content = f.read()
        f.close()
        return content
    except:
        pass

def make_request(url):
##ESTA FUNCION lee las url declaradas donde estan los videos. ||
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0')
		response = urllib2.urlopen(req)	  
		link = response.read()
		response.close()  
		return link
	except urllib2.URLError, e:
		print 'We failed to open "%s".' % url
		if hasattr(e, 'code'):
			print 'We failed with error code - %s.' % e.code	
		if hasattr(e, 'reason'):
			print 'We failed to reach a server.'
			print 'Reason: ', e.reason
			
def OPEN_URL(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36')
        req.add_header('Referer', '%s'%url)
        req.add_header('Connection', 'keep-alive')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link


def conf_menu():

    if activar == 'true':
	add_dir('[COLOR dodgerblue]Menu Peliculas[/COLOR] ', 'movieDB', 116, menu_pelis, fanart)
	buscar_id()
	
	if fav == 'true':
		add_dir('[COLOR orange]favoritos Real stream[/COLOR]', 'movieDB', 121, favicon, fanart)
	
    if RealStream_Settings == 'true':
        add_dir('[COLOR orange]Ajustes[/COLOR]', 'Settings', 119, ajustes, fanart)

    		
	if mostrar_cat == 'true':
		peliculas()
		
	if Resolver_Settings == 'true':
		menu_resolver_set()	    
        
	if anticopia == 'false':

		line1 = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
		line2 = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Program.favoritos-realstream para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
		line3 = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"

		xbmcgui.Dialog().ok("Real Stream", line1, line2, line3)
		
def buscar_id():
    add_dir('[COLOR green]Buscador por id[/COLOR]', u_tube, 127, theMovieDB, fanart)

def menu():
	add_dir('[COLOR lime]The movie DB[/COLOR]', 'movieDB', 99, theMovieDB, fanart)
	
#	add_dir('[COLOR orange]Ajustes[/COLOR]', 'Settings', 119, ajustes, fanart)
#	add_dir('[COLOR orange]Mis enlaces[/COLOR]', 'video', 120, videoteca, fanart)
#   add_dir('[COLOR lime]The movie DB[/COLOR]', 'movieDB', 99, theMovieDB, fanart)
#	add_dir('[COLOR orange]Ajustes[/COLOR]', 'Settings', 119, ajustes, fanart)
#	add_dir('[COLOR red]Autorizar[/COLOR] [COLOR aquamarine][B]OPENLOAD[/B][/COLOR]', 'movieDB', 97, pair, fanart)
#	add_dir('[COLOR orange]Mis enlaces[/COLOR]', 'movieDB', 120, vid, fanart)
	add_dir('[COLOR red]Autorizar[/COLOR] [COLOR aquamarine][B]OPENLOAD[/B][/COLOR]', 'movieDB', 97, pair, fanart)
	conf_menu()

	
def favoritos():

    if xbmc.getCondVisibility('System.HasAddon(plugin.program.favoritos-realstream)'):
	
		xbmc.executebuiltin('RunAddon(plugin.program.favoritos-realstream)')
	
	        if favcopy == 'true':
	
	            xbmcgui.Dialog().ok("[COLOR orange]Real Stream Agradecimientos[/COLOR]" , "[COLOR gold]Netai quiere agradecer el genial trabajo de [/COLOR][COLOR lime][B]Spoyser[/B][/COLOR][COLOR gold] Autor de este genial script que originalmente se conoce como:[/COLOR]" , "[COLOR lime][B]Program.super.favorites[/B][/COLOR]" , "Usted puede descargar el script original desde el repositorio de Kodi >Addons de programas> program.super.favorites")

                addon.setSetting('Favoritos-anuncio', 'false')
    else:
	    
		xbmcgui.Dialog().ok("El programa Real stream Favoritos No esta instalado" , "[COLOR green]Necesario AddOn externo para agregar tus peliculas a favoritas dentro del addon.[/COLOR]","[COLOR yellow]Puedes agregarlo desde http://netai.eu/netai/ agregando la fuente a tu Kodi, instalar desde archivo zip.[/COLOR]")

def miltienlace4k():

#    if xbmc.getCondVisibility('System.HasAddon(plugin.video.Real-4k.pro)'):
	
		xbmc.executebuiltin('RunAddon(plugin.video.Real-4k.pro)')
	
	        if ayudamulti == 'true':
	
	            xbmcgui.Dialog().ok("[COLOR orange]Real Stream[/COLOR]" , "[COLOR gold]Vaya al menu principal y entre en configuracion de URLRESOLVER ajustes.[/COLOR]" , "[COLOR gold]En el menu urlresolver, desactive las opciones: Elegir la mejor calidad automaticamente, y usar la funcion de cache. No olvide cada cierto tiempo en el mismo sitio ejecutar borrar la cache de URLRESOLVER.[/COLOR]")

                addon.setSetting('ayudamulti', 'false')
#    else:
	    
#		xbmcgui.Dialog().ok("El programa Real 4k Pro No esta instalado" , "[COLOR green]Necesario AddOn externo para ver peliculas en resolucion superior a 1080 dentro del addon.[/COLOR]","[COLOR yellow]Puedes agregarlo desde http://netai.eu/netai/ agregando la fuente a tu Kodi, instalar desde archivo zip.[/COLOR]")

def torrentPro():

#    if xbmc.getCondVisibility('System.HasAddon(plugin.video.Real-torrent.pro)'):
	
		xbmc.executebuiltin('RunAddon(plugin.video.Real-torrent.pro)')
	
	        if ayudamulti == 'true':
	
	            xbmcgui.Dialog().ok("[COLOR orange]Real Stream[/COLOR]" , "[COLOR gold]Esta opcion funciona con gestores torrent.[/COLOR]" , "[COLOR gold]Por defecto, se instalara el addon externo Torrentin y Gestor torrenter para poder visionar los videos torrent.[/COLOR]", "Recomendamos utilice el gestor torrentin que le dara ayuda y soporte con Extended Info. O bien la opcion Torrenter sobre todo en Kodi 18.")

                addon.setSetting('ayudamulti', 'false')
#   else:
	    
#		xbmcgui.Dialog().ok("El programa Real stream Favoritos No esta instalado" , "[COLOR green]Necesario AddOn externo para agregar tus peliculas a favoritas dentro del addon.[/COLOR]","[COLOR yellow]Puedes agregarlo desde http://netai.eu/netai/ agregando la fuente a tu Kodi, instalar desde archivo zip.[/COLOR]")


def Real_stream_settings():
    addon.openSettings()
	
def urlresolver_settings():
    urlresolver.display_settings()

def menu_resolver_set():
    add_dir('[COLOR orange]Ajustes URL RESOLVER[/COLOR]', 'resolve', 120, resolver, fanart)	
	
def peliculas():
	add_dir('[COLOR yellow]Buscador[/COLOR]', 'search', 111, buscar, fanart)
	add_dir('[COLOR orange]Novedades[/COLOR]',u_tube,3,novedades,fanart)
	add_dir('[COLOR orange]Estrenos[/COLOR]',u_tube,2,estrenos,fanart)
	add_dir('[COLOR orange]Recomendadas[/COLOR]',u_tube,4,recomendadas,fanart)
	add_dir('[COLOR orange]Accion[/COLOR]',u_tube,5,p_accion,fanart)
	add_dir('[COLOR orange]Animacion[/COLOR]',u_tube,6,animacion,fanart)
	add_dir('[COLOR orange]Aventuras[/COLOR]',u_tube,7,aventuras,fanart)
	add_dir('[COLOR orange]Belico[/COLOR]',u_tube,8,belico,fanart)
	add_dir('[COLOR orange]Ciencia Ficcion[/COLOR]',u_tube,9,cifi,fanart)
	add_dir('[COLOR orange]Comedia[/COLOR]',u_tube,10,comedia,fanart)
	add_dir('[COLOR orange]Crimen[/COLOR]',u_tube,11,crimen,fanart)
	add_dir('[COLOR orange]Drama[/COLOR]',u_tube,12,drama,fanart)
	add_dir('[COLOR orange]Familiar[/COLOR]',u_tube,13,familiar,fanart)
	add_dir('[COLOR orange]Fantasia[/COLOR]',u_tube,14,fantasia,fanart)
	add_dir('[COLOR orange]Historica[/COLOR]',u_tube,15,historia,fanart)
	add_dir('[COLOR orange]Misterio[/COLOR]',u_tube,16,misterio,fanart)
	add_dir('[COLOR orange]Musical[/COLOR]',u_tube,17,musical,fanart)
	add_dir('[COLOR orange]Romance[/COLOR]',u_tube,18,romance,fanart)
	add_dir('[COLOR orange]Thriller[/COLOR]',u_tube,19,thriller,fanart)
	add_dir('[COLOR orange]Suspense[/COLOR]',u_tube,20,suspense,fanart)
	add_dir('[COLOR orange]Terror[/COLOR]',u_tube,21,terror,fanart)
	add_dir('[COLOR orange]Western[/COLOR]',u_tube,22,western,fanart)
	add_dir('[COLOR orange]Spain[/COLOR]',u_tube,23,spain,fanart)
	add_dir('[COLOR orange]Super heroes[/COLOR]',u_tube,24,superheroes,fanart)
	add_dir('[COLOR orange]Saga de Peliculas[/COLOR]',u_tube,25,sagas,fanart)
	add_dir('[COLOR orange]Multi enlaces [4k][/COLOR]',u_tube,125,calidad4k,fanart)
	add_dir('[COLOR orange]Torrents[/COLOR]',u_tube,126,torrent,fanart)


	
def get_info_movie():

    # prompt the user to input search text
    kb = xbmc.Keyboard('', 'Titulo de la pelicula')
    kb.doModal()
    if not kb.isConfirmed():
        return None;
    name = kb.getText().strip()
	

    if xbmc.getCondVisibility('system.platform.android'):
	
	opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' +name+ '&language=es-ES'  ) )
	
        
	return 'android'

    elif xbmc.getCondVisibility('system.platform.windows'):
	
	opensite = webbrowser . open('https://www.themoviedb.org/search?query=' +name+ '&language=es-ES')
  
	
	return 'windows'
	
def Novedades(): 		
## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
def Estrenos():

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op1)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
def Recomendadas(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op2)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
def Accion(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op3)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass

def Animacion(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op4)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
def Aventuras():

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op5)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
def Belico(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op6)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
def Cifi(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op7)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
			
def Comedia(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op8)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
			
def Crimen(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op9)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
			
def Drama(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op10)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
def Familiar():

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op11)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
			
def Fantasia(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op12)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
			
def Historia(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op13)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
def Misterio():

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op14)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
			
def Musical():

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op15)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
def Romance():

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op16)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
			
def Thriller(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op17)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
			
def Suspense():

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op18)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
			
def Terror(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op19)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
			
def Western(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op20)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
			
def Spain():

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op21)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
def Superheroes():

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op22)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
def Sagas(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op23)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass


			
def playlist(thumb, name, url, id):	

	name = re.sub('\s+', ' ', name).strip()			
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		if 'tvg-logo' in thumb:
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')			
			add_dir(name, url, '', thumb, thumb)			
		else:	
			add_dir(name, url, '', icon, fanart)
	else:
		if 'youtube.com/watch?v=' in url:
			url = 'plugin://plugin.video.youtube/play/?video_id=%s' % (url.split('=')[-1])
		elif 'dailymotion.com/video/' in url:
			url = url.split('/')[-1].split('_')[0]
			url = 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=%s' % url	
		else:			
			url = url
		if 'tvg-logo' in thumb:				
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
			add_link(name, url, 1, thumb, thumb)			
		else:				
			add_link(name, url, 1, icon, fanart)	

def m3u_playlist_original(thumb, name, url, id):	
## despues de obtener las url de la lista m3u las muestra.
	name = re.sub('\s+', ' ', name).strip()			
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		if 'tvg-logo' in thumb:
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')			
			add_dir(name, url, '', thumb, thumb)		
		else:	
			add_dir(name, url, '', icon, fanart)
	else:
		if 'youtube.com/watch?v=' in url:
			url = 'plugin://plugin.video.youtube/play/?video_id=%s' % (url.split('=')[-1])
		elif 'dailymotion.com/video/' in url:
			url = url.split('/')[-1].split('_')[0]
			url = 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=%s' % url	
		else:			
			url = url
		if 'tvg-logo' in thumb:				
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
			
			add_link(name, url, 1, thumb, thumb, id)
			
		else:
            	
			add_link(name, url, 1, icon, fanart, id)
			
def m3u_playlist(thumb, name, url, id):	
## despues de obtener las url de la lista m3u las muestra.

	name = re.sub('\s+', ' ', name).strip()	
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	if ('https://www38.uptostream.com/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		if 'tvg-logo' in thumb:
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')			
			add_dir(name, url, '', thumb, thumb)		
		else:	
			add_dir(name, url, '', icon, fanart)
	else:
		if 'https://www38.uptostream.com/' in url:
			url = url.split('/')[-1].split('_')[0]
		elif 'dailymotion.com/video/' in url:
			url = url.split('/')[-1].split('_')[0]
			url = 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=%s' % url	

		else:			
			url = url
		if 'tvg-logo' in thumb:				
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
			
			if '[Rapidvideo]' in name:
                
			    name = '[COLOR yellow]%s[/COLOR]' % name
			if '[rapidvideo]' in name:

			    name = '[COLOR yellow]%s[/COLOR]' % name
			elif '[streamango]' in name:

				name = '[COLOR orange]%s[/COLOR]' % name
			elif '[Streamgo]' in name:

				name = '[COLOR orange]%s[/COLOR]' % name
			elif '[Openload]' in name:

				name = '[COLOR deepskyblue]%s[/COLOR]' % name
			elif '[openload]' in name:

				name = '[COLOR deepskyblue]%s[/COLOR]' % name
			elif '[Vidoza]' in name:

				name = '[COLOR darkgreen]%s[/COLOR]' % name
			elif '[vidoza]' in name:
 
				name = '[COLOR darkgreen]%s[/COLOR]' % name
			elif '[Streamcloud]' in name:

				name = '[COLOR steelblue]%s[/COLOR]' % name
			elif '[streamcloud]' in name:

				name = '[COLOR steelblue]%s[/COLOR]' % name
			elif '[Okru]' in name:

				name = '[COLOR deeppink]%s[/COLOR]' % name
			elif '[okru]' in name:

				name = '[COLOR deeppink]%s[/COLOR]' % name
			
			else:

				name = '[COLOR white]%s[/COLOR]' % name
			
			add_link(name, url, 1, thumb, thumb, id)

		else:
		
		    add_link(name, url, 1, icon, fanart, id)
			
            
def play_video(name,url):
## Cuando se clica en el enlace de la url obtenida, si la lista es .m3u hara 'if' y si es texto plano hara else.
	if '.m3u8' in url:
		url = url.replace("http://","plugin://plugin.video.f4mTester/?url=http://").replace(".m3u8",".ts")
		url = url + "&amp;streamtype=TSDOWNLOADER"
		media_url = url
		item = xbmcgui.ListItem(name, path = media_url)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
		return
	else:
		media_url = url
		item = xbmcgui.ListItem(name, path = media_url)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
		return



def PLAYVIDEO1(name,url):
    import urlresolver
    from urlresolver import common
    url=urlresolver.HostedMediaFile(url).resolve()
    media_url = url	
    item = xbmcgui.ListItem(name, path = media_url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)



def PLAYVIDEO(name,url):
    import urlresolver
    from urlresolver import common

    hmf = urlresolver.HostedMediaFile(url)

    if not hmf:
            xbmc.executebuiltin("XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" +name+ "[/COLOR] ,7500)")

            return False


    try:
        stream_url = hmf.resolve()
        if not stream_url or not isinstance(stream_url, basestring):
            try: msg = stream_url.msg
            except: msg = url
            raise Exception(msg)
    except Exception as e:
        try: msg = str(e)
        except: msg = url
        xbmc.executebuiltin("XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" +name+ "[/COLOR] ,7500)")            

        return False
   
    notificar = addon.getSetting('notificar') 	
    if notificar == 'true':
        xbmc.executebuiltin("XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" +name+ "[/COLOR] ,7500)")	
    listitem = xbmcgui.ListItem(path=stream_url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)

	

def get_params():
## Codigo de shani de Live Stream Pro Con este script se obtienen los parametros. Sino sabes ... dejalo como lo puso Shani que asi funciona.

	param = []
	paramstring = sys.argv[2]
	if len(paramstring)>= 2:
		params = sys.argv[2]
		cleanedparams = params.replace('?', '')
		if (params[len(params)-1] == '/'):
			params = params[0:len(params)-2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams = {}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0]] = splitparams[1]
	return param
	


def ThemovieDB():
    dialog = xbmcgui.Dialog()
    list = (
        opc1,
        opc2
        )
        
    call = dialog.select('[B][COLOR=orange]The Movie db[/COLOR][/B]', [
	'[COLOR=gold]Accede a themoviedb.com[/COLOR]', 
    
	'[B][COLOR=white]                           Volver al Menu [/COLOR][/B]',])

    if call:
        # esc is not pressed
        if call < 0:
            return
        func = list[call-2]
        return func()
    else:
        func = list[call]
        return func()
    return 

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()

def opc1():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
    else:
        opensite = webbrowser . open('https://www.themoviedb.org/movie/')

        
def opc2():

    main()
	
	
	
def PAIR():
    dialog = xbmcgui.Dialog()
    funcs = (
        functionA,
        functionB
        )
        
    call = dialog.select('[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]', [
	'[COLOR=orange]                       Pair OpenLoad [/COLOR]', 
    
	'[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]',])

    if call:
        # esc is not pressed
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()

def functionA():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
    else:
        opensite = webbrowser . open('https://olpair.com/')

        
def functionB():

    main()
	

def selector(name,url,id):
    dialog = xbmcgui.Dialog()
    funcs = (
        function1,
		function2,
		goThemovieDB,
        )
        
    call = dialog.select('[COLOR=yellow]REAL STREAM MENU:[/COLOR]', [
	'[COLOR=yellow]Reproductor [/COLOR][COLOR red][4K no soportado][/COLOR] [COLOR orange]' +name+ '[/COLOR]', 
    
	'[COLOR=yellow]                    Mas Informacion, ver trailers  [/COLOR]',
	
	'[COLOR orange]                       Accede a la web MovieDB[/COLOR]',])

    if call:
        # esc is not pressed
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def function1():
    
	PLAYVIDEO(name,url)
	
	
def function2():
    
    if xbmc.getCondVisibility('System.HasAddon(script.extendedinfo)'):
	movie_id = id
	
	xbmc.executebuiltin( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % movie_id )

    if notificar == 'true':	
	
		xbmc.executebuiltin("XBMC.Notification(Extended Info,Abriendo: [COLOR green]" +name+ "[/COLOR] ,10000)")
#    __addon__ = xbmcaddon.Addon()
#    __addonname__ = __addon__.getAddonInfo('name')

#    line1 = "[COLOR=blue]                [B]     Extended info script[/COLOR][COLOR gold] by Phil65 dev Kodi.[/B][/COLOR]"
#    line2 = "[COLOR gold]Real stream: Nosotros no alojamos peliculas en nuestro script, solo enlazamos a contenido externo, libre en servidores publicos de internet. Por lo tanto no somos responsables de dicho contenido. Este contenido es propiedad de sus respectivos dueños.[/COLOR]"
#    line3 = "[COLOR lime]Agradecimientos a Ciberus de Torrentin por ayudarme con su adaptacion en Real Stream. Disfrute de su pelicula.[/COLOR]"

#    xbmcgui.Dialog().ok(__addonname__, line1, line2, line3)
	

	
def goThemovieDB():

    ThemovieDB()
		
def add_dir(name, url, mode, iconimage, fanart, showcontext=False):

	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
	ok = True
	liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		u = 'plugin://plugin.video.youtube/%s/%s/' % (url.split( '/' )[-2], url.split( '/' )[-1])
		ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
		return ok		
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
	return ok
	
def add_link(name, url, mode, iconimage, fanart, id):

	try:
            name = name.encode('utf-8')
        except: pass
	commands=[]
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&id=" + str(id)	
	liz = xbmcgui.ListItem(name, id, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'true') 
	
	if xbmc.getCondVisibility('System.HasAddon(script.extendedinfo)'):
		commands.append(("[B][COLOR yellow]ExtendedInfo[/COLOR][/B]","XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % (name,id) ))	
		liz.addContextMenuItems(commands, replaceItems=True)
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz)
	return ok
	
def buscar_themovieid(): 

## ESTA FUNCION BUSCA EN LAS LISTAS m3u DENTRO DE LAS CATEGORIAS. | Cuantas mas categorias, mas lento ira el buscador a no ser que hagamos buscadores individuales.

		keyb = xbmc.Keyboard('', 'Escriba id de la pelicula: Themoviedb.org')
		keyb.doModal()
		if (keyb.isConfirmed()):
		
			searchText = urllib.quote_plus(keyb.getText()).replace('+', ' ')
			
			if xbmc.getCondVisibility('System.HasAddon(script.extendedinfo)'):
			    try:
				    
				xbmc.executebuiltin( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % searchText )

				if notificar == 'true':	
	
					xbmc.executebuiltin("XBMC.Notification(Extended Info,Abriendo: [COLOR green]" +name+ "[/COLOR] ,10000)")
		    
			    except:
				    
					xbmcgui.Dialog().ok("El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]","[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]")     
	
		
   	
params = get_params()
url = None
name = None
mode = None
iconimage = None
id = None


try:
	url = urllib.unquote_plus(params["url"])
except:
	pass
try:
	name = urllib.unquote_plus(params["name"])
except:
	pass
try:
	mode = int(params["mode"])
except:
	pass
try:
	iconimage = urllib.unquote_plus(params["iconimage"])
except:
	pass 
try:
	id = int(params["id"])
except:
	pass 
	

print "Mode: " + str(mode)
print "URL: " + str(url)
print "Name: " + str(name)
print "iconimage: " + str(iconimage)

if mode == None or url == None or len(url) < 1:
	menu()
	aviso = addon.getSetting('aviso')
	if aviso == 'true':
		mensaje()
elif mode == 1:
    selector(name,url,id)
elif mode == 2:
    Novedades()
elif mode == 3:
	Estrenos()
elif mode == 4:
    Recomendadas()
elif mode == 5:
    Accion()
elif mode == 6:
    Animacion()
elif mode == 7:
    Aventuras()
elif mode == 8:
    Belico()
elif mode == 9:
    Cifi()
elif mode == 10:
    Comedia()
elif mode == 11:
    Crimen()
elif mode == 12:
    Drama()
elif mode == 13:
    Familiar()
elif mode == 14:
    Fantasia()
elif mode == 15:
    Historia()
elif mode == 16:
    Misterio()
elif mode == 17:
    Musical()
elif mode == 18:
    Romance()
elif mode == 19:
    Thriller()
elif mode == 20:
    Suspense()
elif mode == 21:
    Terror()
elif mode == 22:
    Western()
elif mode == 23:
    Spain()
elif mode == 24:
    Superheroes()
elif mode == 25:
    Sagas()
elif mode == 27:
    Calidad4k()
elif mode == 98:
    busqueda_global()
elif mode == 97:
    PAIR()
elif mode == 99:
    get_info_movie()
elif mode == 100:
    menu_player(name,url)
elif mode == 111:
    search()
elif mode == 115:
    play_video(url) 
elif mode == 116:
    peliculas()	
elif mode == 119:
    Real_stream_settings()
elif mode == 120:
    urlresolver_settings()    
elif mode == 121:
    favoritos() 
elif mode == 125:
    miltienlace4k()
elif mode == 126:
    torrentPro()
elif mode == 127:
    buscar_themovieid()
    
xbmcplugin.endOfDirectory(plugin_handle)			