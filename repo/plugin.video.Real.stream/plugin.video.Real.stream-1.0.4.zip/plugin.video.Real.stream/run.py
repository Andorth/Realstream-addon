# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 1.0.4
#
############################################
# Dependencias 
# Script ExtendedInfo
# Script Urlresolver de TVAddons
# Script ResolveURL Por Jsergio.
#
############################################
#
# Agregar sinopsis a Peliculas y series.
# Supresion de Licencia
#
#
############################################
if 64 - 64: i11iIiiIii
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import urlresolver
import cookielib , base64
import requests
import plugintools
import config
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
IiII1IiiIiI1 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
o0OoOoOO00 = int ( sys . argv [ 1 ] )
I11i = 'gruponetai/'
O0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
Oo = O0O . getAddonInfo ( 'profile' )
I1ii11iIi11i = O0O . getAddonInfo ( 'path' )
I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
if 73 - 73: OOooOOo / ii11ii1ii
def O00ooOO ( ) :
 if 47 - 47: oO0ooO % iI1Ii11111iIi + ii1II11I1ii1I + oO0o0ooO0 - iiIIIII1i1iI
 o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 oo00 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 o00 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 Oo0oO0ooo = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 o0oOoO00o = i1 ( o00 )
 oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
 for i11 in oOOoo00O0O :
  try :
   if 41 - 41: O00o0o0000o0o . oOo0oooo00o * I1i1i1ii - IIIII
   if 26 - 26: O00OoOoo00 . iiiI11 / oooOOOOO * iI1Ii11111iIi / iiiI11
   o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 80 - 80: ii1II11I1ii1I . iiIIIII1i1iI
   if 34 - 34: O00o0o0000o0o % OoooooooOO / i1IIi . IIIII + O0
   if o0oO0 == i11 :
    if 42 - 42: O00o0o0000o0o / i1IIi + i11iIiiIii - I1i1i1ii
    if 78 - 78: oO0ooO
    Iii1I111 ( )
    if 60 - 60: iiIIIII1i1iI * ii1II11I1ii1I % ii1II11I1ii1I % oOo0oooo00o * II111iiii + i1IIi
   else :
    if 64 - 64: iiIIIII1i1iI - O0 / II111iiii / ii1II11I1ii1I / iIii1I11I1II1
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold]>El addon esta desactivado.[/COLOR]" )
    if 24 - 24: O0 % ii1II11I1ii1I + i1IIi + iiiI11 + oO0o0ooO0
    if 70 - 70: ii11ii1ii % ii11ii1ii . O00OoOoo00 % oO0ooO * ii1II11I1ii1I % iiIIIII1i1iI
  except :
   pass
   if 23 - 23: i11iIiiIii + OOooOOo
   if 68 - 68: iI1Ii11111iIi . iiIIIII1i1iI . i11iIiiIii
   if 40 - 40: iiIIIII1i1iI . iI1Ii11111iIi . ii11ii1ii . i1IIi
   if 33 - 33: I1i1i1ii + II111iiii % i11iIiiIii . oooOOOOO - OOooOOo
if I1IiI == 'true' :
 if 66 - 66: I1i1i1ii - OoooooooOO * OoooooooOO . O00o0o0000o0o . oO0o0ooO0
 IiI1i11iii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.png' ) )
 oo0Oo00Oo0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 oOOO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 O0O00o0OOO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 Ii1iIIIi1ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 o0oo0o0O00OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.png' ) )
 o0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.png' ) )
 I1i1iii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'estrenos.png' ) )
 i1iiI11I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.png' ) )
 iiii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.png' ) )
 oO0o0O0OOOoo0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.png' ) )
 IiIiiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.png' ) )
 I1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.png' ) )
 oOO00oOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.png' ) )
 OoOo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 iI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.png' ) )
 o00O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.png' ) )
 OOO0OOO00oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.png' ) )
 Iii111II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.png' ) )
 iiii11I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.png' ) )
 Ooo0OO0oOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.png' ) )
 ii11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'marvel.png' ) )
 IIIii1II1II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.png' ) )
 i1I1iI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.png' ) )
 oo0OooOOo0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.png' ) )
 o0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.png' ) )
 O00oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.png' ) )
 I11i1I1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.png' ) )
 oO0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.png' ) )
 oOOoo0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.png' ) )
 o00OO00OoO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.png' ) )
 OOOO0OOoO0O0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.png' ) )
 O0Oo000ooO00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.png' ) )
 oO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.jpg' ) )
 Ii1iIiII1ii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.jpg' ) )
 ooOooo000oOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
 Oo0oOOo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 Oo0OoO00oOO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 OOO00O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.png' ) )
 OOoOO0oo0ooO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 O0o0O00Oo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 O00O0oOO00O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
else :
 if 11 - 11: O00OoOoo00 . oO0o0ooO0
 if 92 - 92: IIIII . iiiI11
 Oo0oOOo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 OOoOO0oo0ooO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
 IiI1i11iii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.jpg' ) )
 oo0Oo00Oo0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 oOOO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 O0O00o0OOO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 Ii1iIIIi1ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 o0oo0o0O00OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.jpg' ) )
 o0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.jpg' ) )
 I1i1iii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'encines.jpg' ) )
 i1iiI11I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.jpg' ) )
 iiii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.jpg' ) )
 oO0o0O0OOOoo0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.jpg' ) )
 IiIiiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.jpg' ) )
 I1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.jpg' ) )
 oOO00oOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.jpg' ) )
 OoOo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 iI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.jpg' ) )
 o00O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.jpg' ) )
 OOO0OOO00oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.jpg' ) )
 Iii111II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.jpg' ) )
 iiii11I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.jpg' ) )
 Ooo0OO0oOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.jpg' ) )
 ii11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'superheroes.jpg' ) )
 IIIii1II1II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.jpg' ) )
 i1I1iI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.jpg' ) )
 oo0OooOOo0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.jpg' ) )
 o0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.jpg' ) )
 O00oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.jpg' ) )
 I11i1I1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.jpg' ) )
 oO0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.jpg' ) )
 oOOoo0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.jpg' ) )
 o00OO00OoO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.jpg' ) )
 OOOO0OOoO0O0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.jpg' ) )
 O0Oo000ooO00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.jpg' ) )
 oO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.jpg' ) )
 Ii1iIiII1ii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.jpg' ) )
 Oo0OoO00oOO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 OOO00O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.jpg' ) )
 ooOooo000oOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favoritos.png' ) )
 O0o0O00Oo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 O00O0oOO00O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
 if 31 - 31: iiiI11 . iI1Ii11111iIi / O0
 if 89 - 89: iI1Ii11111iIi
 if 68 - 68: oO0ooO * OoooooooOO % O0 + oO0ooO + oooOOOOO
 if 4 - 4: oooOOOOO + O0 * O00o0o0000o0o
 if 55 - 55: ii11ii1ii + iIii1I11I1II1 / iI1Ii11111iIi * iiIIIII1i1iI - i11iIiiIii - I1i1i1ii
ii1ii1ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'peliculas.png' ) )
oooooOoo0ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series.png' ) )
I1I1IiI1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ajustes.png' ) )
III1iII1I1ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'videoteca.png' ) )
oOOo0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
oo00O00oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'resolver.png' ) )
iIiIIIi = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'test.png' ) )
ooo00OOOooO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'video-tutoriales.png' ) )
O00OOOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'proxy.png' ) )
if 77 - 77: IIIII % IIIII * iiIIIII1i1iI - i11iIiiIii
Oo0oO = IiII1IiiIiI1 . getSetting ( 'mostrar_cat' )
IIiIi1iI = IiII1IiiIiI1 . getSetting ( 'videos' )
i1IiiiI1iI = IiII1IiiIiI1 . getSetting ( 'activar' )
i1iIi = IiII1IiiIiI1 . getSetting ( 'favcopy' )
ooOOoooooo = IiII1IiiIiI1 . getSetting ( 'anticopia' )
o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
O0i1II1Iiii1I11 = IiII1IiiIiI1 . getSetting ( 'mostrar_bus' )
IIII = IiII1IiiIiI1 . getSetting ( 'restante' )
iiIiI = IiII1IiiIiI1 . getSetting ( 'selecton' )
o00oooO0Oo = IiII1IiiIiI1 . getSetting ( 'aviso' )
o0O0OOO0Ooo = IiII1IiiIiI1 . getSetting ( 'RealStream_Settings' )
iiIiII1 = IiII1IiiIiI1 . getSetting ( 'Resolver_Settings' )
IIII = IiII1IiiIiI1 . getSetting ( 'restante' )
OOO00O0O = IiII1IiiIiI1 . getSetting ( 'fav' )
iii = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
oOooOOOoOo = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
i1Iii1i1I = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
OOoO00 = 'bienvenida'
IiI111111IIII = 'bienvenida'
copyright = IiII1IiiIiI1 . getSetting ( 'copyright' )
i1Ii = 'cGx1Z2luLnZpZGVvLg==' . decode ( 'base64' ) + copyright
ii111iI1iIi1 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
OOO = IiII1IiiIiI1 . getSetting ( 'Forceupdate' )
if OOO == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
oo0OOo0 = 'LnR4dA==' . decode ( 'base64' )
if 47 - 47: iiiI11 + iI1Ii11111iIi * ii11ii1ii / oooOOOOO - IIIII % iIii1I11I1II1
IIi11i1i1iI1 = 'aHR0cDovL2JpdC5seS8yU1FOSnlP' . decode ( 'base64' )
iiiIi1 = i1Iii1i1I + OOoO00 + oo0OOo0
i1I1ii11i1Iii = 'http://www.youtube.com'
I1IiiiiI = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
o0OIiII = '.xsl.pt'
ii1iII1II = 'L21hc3Rlci8=' . decode ( 'base64' )
Iii1I1I11iiI1 = I1IiiiiI + o0OIiII
I1I1i1I = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*texto3=[\'"](.*?)[\'"]\s*'
ii1I = 'tvg-logo=[\'"](.*?)[\'"]'
if 99 - 99: I1i1i1ii / ii11ii1ii / O00OoOoo00 % OOooOOo
i11I1II1I11i = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)'
OooOoOO0 = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.*)'
iI1i11iII111 = '(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)'
Iii1IIII11I = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
OOOoo0OO = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
oO0o0 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
iI1Ii11iIiI1 = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
OO0Oooo0oOO0O = '#(.+?),(.+)\s*(.+)'
o00O0 = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
if 83 - 83: oooOOOOO
oO00Oo0O0o = 'source src=[\'"](.*?)[\'"]\s*title=[\'"](.*?)[\'"]'
ii1 = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
I1iIIiiIIi1i = '[\'"](.*?)[\'"]'
O0O0ooOOO = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
oOOo0O00o = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( 'base64' )
iIiIi11 = oOOo0O00o + I11i
i1111 = '[\'"](.*?)[\'"]'
OOOiiiiI = 'UmVhbHN0cmVhbQ==' . decode ( 'base64' )
oooOo0OOOoo0 = 'video=[\'"](.*?)[\'"]'
oo00 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
o00 = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( 'base64' ) + oo00
OOoO = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
OO0O000 = '0110R0N' . replace ( '0110R0N' , 'R0N' )
iiIiI1i1 = 'aHR0cDovL2JpdC5seS8yWEIx' . decode ( 'base64' ) + OO0O000
oO0O00oOOoooO = '0110pEJ' . replace ( '0110pEJ' , 'pEJ' )
IiIi11iI = 'aHR0cDovL2JpdC5seS8yd1Nh' . decode ( 'base64' ) + oO0O00oOOoooO
Oo0O00O000 = 'ABBAOb5' . replace ( 'ABBAOb5' , 'Ob5' )
i11I1IiII1i1i = 'aHR0cDovL2JpdC5seS8yRVhV' . decode ( 'base64' ) + Oo0O00O000
oo = '0110jaw' . replace ( '0110jaw' , 'jaw' )
I1111i = 'aHR0cDovL2JpdC5seS8yd01M' . decode ( 'base64' ) + oo
iIIii = '01109DI' . replace ( '01109DI' , '9DI' )
o00O0O = 'aHR0cDovL2JpdC5seS8ySXgz' . decode ( 'base64' ) + iIIii
ii1iii1i = '01103hs' . replace ( '01103hs' , '3hs' )
Iii1I1111ii = 'aHR0cDovL2JpdC5seS8zMW1U' . decode ( 'base64' ) + ii1iii1i
ooOoO00 = '01107DW' . replace ( '01107DW' , '7DW' )
Ii1IIiI1i = 'aHR0cDovL2JpdC5seS8yV1ln' . decode ( 'base64' ) + ooOoO00
o0O00Oo0 = '0110mLl' . replace ( '0110mLl' , 'mLl' )
IiII111i1i11 = 'aHR0cDovL2JpdC5seS8yS0cw' . decode ( 'base64' ) + o0O00Oo0
i111iIi1i1II1 = '01102Hj' . replace ( '01102Hj' , '2Hj' )
oooO = 'aHR0cDovL2JpdC5seS8yWEJo' . decode ( 'base64' ) + i111iIi1i1II1
i1I1i111Ii = '0110fXg' . replace ( '0110fXg' , 'fXg' )
ooo = 'aHR0cDovL2JpdC5seS8ySTVy' . decode ( 'base64' ) + i1I1i111Ii
i1i1iI1iiiI = '0110NMH' . replace ( '0110NMH' , 'NMH' )
Ooo0oOooo0 = 'aHR0cDovL2JpdC5seS8yd0t6' . decode ( 'base64' ) + i1i1iI1iiiI
oOOOoo00 = '0110bwQ' . replace ( '0110bwQ' , 'bwQ' )
iiIiIIIiiI = 'aHR0cDovL2JpdC5seS8yd01V' . decode ( 'base64' ) + oOOOoo00
iiI1IIIi = '0110xzG' . replace ( '0110xzG' , 'xzG' )
II11IiIi11 = 'aHR0cDovL2JpdC5seS8yWHhz' . decode ( 'base64' ) + iiI1IIIi
II = '0110x64' . replace ( '0110x64' , 'x64' )
OOO0O00O0OOOO = 'aHR0cDovL2JpdC5seS8yRVlF' . decode ( 'base64' ) + II
I1iiii1I = '0110vUE' . replace ( '0110vUE' , 'vUE' )
OOo0 = 'aHR0cDovL2JpdC5seS8yWmhW' . decode ( 'base64' ) + I1iiii1I
oO00ooooO0o = '01107ZL' . replace ( '01107ZL' , '7ZL' )
oo0o = 'aHR0cDovL2JpdC5seS8yWm4w' . decode ( 'base64' ) + oO00ooooO0o
o0oO0oooOoo = '01106cf' . replace ( '01106cf' , '6cf' )
I1III1111iIi = 'aHR0cDovL2JpdC5seS8yRVlk' . decode ( 'base64' ) + o0oO0oooOoo
I1i111I = '0110Jtp' . replace ( '0110Jtp' , 'Jtp' )
Ooo = 'aHR0cDovL2JpdC5seS8yV3Nq' . decode ( 'base64' ) + I1i111I
Oo0oo0O0o00O = '0110a5b' . replace ( '0110a5b' , 'a5b' )
I1i11 = 'aHR0cDovL2JpdC5seS8yV3dj' . decode ( 'base64' ) + Oo0oo0O0o00O
IiIi1I1 = '0110Q7u' . replace ( '0110Q7u' , 'Q7u' )
IiIIi1 = 'aHR0cDovL2JpdC5seS8yV3NL' . decode ( 'base64' ) + IiIi1I1
IIIIiii1IIii = '0110rsq' . replace ( '0110rsq' , 'rsq' )
II1i11I = 'aHR0cDovL2JpdC5seS8ySzhE' . decode ( 'base64' ) + IIIIiii1IIii
ii1I1IIii11 = '0110DDR' . replace ( '0110DDR' , 'DDR' )
O0o0oO = 'aHR0cDovL2JpdC5seS8ySzd5' . decode ( 'base64' ) + ii1I1IIii11
IIIIiIiIi1 = '0110feQ' . replace ( '0110feQ' , 'feQ' )
I11iiiiI1i = 'aHR0cDovL2JpdC5seS8yS0cz' . decode ( 'base64' ) + IIIIiIiIi1
iI1i11 = '0110MHY' . replace ( '0110MHY' , 'MHY' )
OoOOoooOO0O = 'aHR0cDovL2JpdC5seS8ySXVo' . decode ( 'base64' ) + iI1i11
ooo00Ooo = '0110xdb' . replace ( '0110xdb' , 'xdb' )
Oo0o0O00 = 'aHR0cDovL2JpdC5seS8yWEJu' . decode ( 'base64' ) + ooo00Ooo
ii1I1i11 = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( 'base64' )
i1Ii = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
OO = '0110lxu' . replace ( '0110lxu' , 'lxu' )
o0O0oo0OO0O = 'aHR0cDovL2JpdC5seS8yV1Bj' . decode ( 'base64' ) + OO
OO0 = '0110pzp' . replace ( '0110pzp' , 'pzp' )
o0Oooo = 'aHR0cDovL2JpdC5seS8yVHpB' . decode ( 'base64' ) + OO0
iiI = '01105yt' . replace ( '01105yt' , '5yt' )
oO = 'aHR0cDovL2JpdC5seS8yTVpp' . decode ( 'base64' ) + iiI
if 10 - 10: ii11ii1ii / ii11ii1ii / iiiI11 . iiiI11
if 98 - 98: ii11ii1ii / OOooOOo . O0 + oO0ooO
ii = '1001DTs' . replace ( '1001DTs' , 'DTs' )
Iiii1iI1i = 'aHR0cDovL2JpdC5seS8ySzhP' . decode ( 'base64' ) + ii
I1ii1ii11i1I = '1001Hky' . replace ( '1001Hky' , 'Hky' )
o0OoOO = 'aHR0cDovL2JpdC5seS8yTGVL' . decode ( 'base64' ) + I1ii1ii11i1I
O0O0Oo00 = '1001VFU' . replace ( '1001VFU' , 'VFU' )
oOoO00o = 'aHR0cDovL2JpdC5seS8zMERx' . decode ( 'base64' ) + O0O0Oo00
oO00O0 = '3545OMZ' . replace ( '3545OMZ' , 'OMZ' )
IIi1IIIi = 'aHR0cDovL2JpdC5seS8yazhk' . decode ( 'base64' ) + oO00O0
if 99 - 99: I1i1i1ii + oO0ooO * II111iiii . ii1II11I1ii1I - oO0o0ooO0
def o0OOOo ( ) :
 if 11 - 11: iIii1I11I1II1 * iIii1I11I1II1 * OOooOOo
 if 46 - 46: iI1Ii11111iIi + oO0ooO
 try :
  if 70 - 70: IIIII / iIii1I11I1II1
  o0oOoO00o = i1 ( iiIiI1i1 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   try :
    if 19 - 19: i11iIiiIii + OoooooooOO - ii11ii1ii - oOo0oooo00o
    IiIi11iI = Oo0oooO0oO
    if 21 - 21: O0 % O00OoOoo00 . OOooOOo / II111iiii + O00OoOoo00
    OOOO0O00o = xbmc . Keyboard ( '' , 'Busqueda por titulo' )
    OOOO0O00o . doModal ( )
    if ( OOOO0O00o . isConfirmed ( ) ) :
     if 62 - 62: iIii1I11I1II1
     i1II = urllib . quote_plus ( OOOO0O00o . getText ( ) ) . replace ( '+' , ' ' )
     iI1I = i1 ( IiIi11iI )
     oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( iI1I )
     if 100 - 100: iIii1I11I1II1 + iI1Ii11111iIi / ii11ii1ii . i11iIiiIii
     for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
      if re . search ( i1II , iiIi1i ( i1Iii11I1i . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
       if 77 - 77: oO0o0ooO0 + oO0ooO / iiIIIII1i1iI + O0 * ii1II11I1ii1I
   except :
    pass
 except :
  pass
  if 28 - 28: oooOOOOO + i11iIiiIii / oOo0oooo00o % iI1Ii11111iIi % ii11ii1ii - O0
  if 54 - 54: i1IIi + II111iiii
  if 83 - 83: oO0o0ooO0 - OOooOOo + O00o0o0000o0o
def iIi1Ii1i1iI ( ) :
 if 16 - 16: O00o0o0000o0o / ii11ii1ii / OoooooooOO * OOooOOo + i1IIi % O00o0o0000o0o
 o00oooO0Oo = IiII1IiiIiI1 . getSetting ( 'aviso' )
 if o00oooO0Oo == 'true' :
  o0oOoO00o = i1 ( iiiIi1 )
  oOOoo00O0O = re . compile ( I1I1i1I ) . findall ( o0oOoO00o )
  for ooo0o00 , ooO , o0o00 in oOOoo00O0O :
   try :
    if 14 - 14: ii1II11I1ii1I . O00o0o0000o0o . oOo0oooo00o + OoooooooOO - O00o0o0000o0o + O00OoOoo00
    if 9 - 9: I1i1i1ii
    oooooOOO000Oo = ooo0o00
    Ooo00OoOOO = ooO
    Oo0OO0000oooo = o0o00
    if 7 - 7: iiIIIII1i1iI - oO0ooO - O0 % iiIIIII1i1iI - II111iiii
    if 31 - 31: IIIII / ii11ii1ii - IIIII - O00o0o0000o0o
    I1iiIIIi11 = "[B]" + oooooOOO000Oo + "[/B]"
    Ii1I11ii1i = "" + Ooo00OoOOO + ""
    O0iIiIIIIIii = "" + Oo0OO0000oooo + ""
    if 58 - 58: ii1II11I1ii1I / O00OoOoo00 . iI1Ii11111iIi / OoooooooOO + iiiI11
    xbmcgui . Dialog ( ) . ok ( "Real Stream" , I1iiIIIi11 , Ii1I11ii1i , O0iIiIIIIIii )
    if 86 - 86: oOo0oooo00o * OOooOOo + oOo0oooo00o + II111iiii
   except :
    pass
    if 8 - 8: iiiI11 - IIIII / oooOOOOO
    if 96 - 96: iI1Ii11111iIi
 IIiiI = i1 ( ii1I1i11 )
 oOOoo00O0O = re . compile ( I1iIIiiIIi1i ) . findall ( IIiiI )
 for III1i11 in oOOoo00O0O :
  try :
   if 25 - 25: oO0ooO
   import xbmc
   import xbmcaddon
   if 24 - 24: O00OoOoo00 * i11iIiiIii * O00o0o0000o0o
   __addon__ = xbmcaddon . Addon ( )
   __addonname__ = __addon__ . getAddonInfo ( 'name' )
   __icon__ = __addon__ . getAddonInfo ( 'icon' )
   if 85 - 85: ii1II11I1ii1I . iI1Ii11111iIi / oooOOOOO . O0 % iiiI11
   iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
   OO0ooo0oOO = III1i11
   if 97 - 97: OOooOOo / IIIII
   I1iiIIIi11 = "[COLOR orange]Version instalada: [COLOR gold] " + iIiiiI1IiI1I1 + " [/COLOR][/COLOR]"
   Oooo0 = 4000
   if 59 - 59: OoooooooOO
   xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , I1iiIIIi11 , Oooo0 , __icon__ ) )
   if 47 - 47: oooOOOOO - OOooOOo / II111iiii
   if iIiiiI1IiI1I1 < OO0ooo0oOO :
    xbmcgui . Dialog ( ) . ok ( "[B][COLOR fuchsia]Realstream:[/COLOR][/B]" , "[COLOR gold]Actualmente tiene instalada la version:  [/COLOR][COLOR lime][B]" + iIiiiI1IiI1I1 + "[/B][/COLOR]" , "[COLOR orange]Ya esta disponible la nueva version  [B][/COLOR][COLOR lime]" + III1i11 + "[/B][/COLOR][COLOR orange] Puede actualizarla desde el repositorio Realstream.[/COLOR]" )
    if 12 - 12: O00o0o0000o0o
  except :
   pass
 if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
  if 83 - 83: IIIII . O0 / ii11ii1ii / O00o0o0000o0o - II111iiii
  if 100 - 100: oO0ooO
def iiIi1i ( s ) :
 if 46 - 46: iI1Ii11111iIi / iIii1I11I1II1 % IIIII . iIii1I11I1II1 * IIIII
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 38 - 38: oO0o0ooO0 - IIIII / O0 . iiiI11
def i1iiIiI1Ii1i ( file ) :
 if 22 - 22: O00OoOoo00 / i11iIiiIii
 try :
  oOOoo = open ( file , 'r' )
  o0oOoO00o = oOOoo . read ( )
  oOOoo . close ( )
  return o0oOoO00o
 except :
  pass
  if 14 - 14: ii1II11I1ii1I * iiIIIII1i1iI
def i1 ( url ) :
 if 81 - 81: I1i1i1ii * ii1II11I1ii1I + iiiI11 + ii11ii1ii - OoooooooOO
 try :
  i1i1I111iIi1 = urllib2 . Request ( url )
  i1i1I111iIi1 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  oo00O00oO000o = urllib2 . urlopen ( i1i1I111iIi1 )
  OOo00OoO = oo00O00oO000o . read ( )
  oo00O00oO000o . close ( )
  return OOo00OoO
 except urllib2 . URLError , iIi1 :
  print 'We failed to open "%s".' % url
  if hasattr ( iIi1 , 'code' ) :
   print 'We failed with error code - %s.' % iIi1 . code
  if hasattr ( iIi1 , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , iIi1 . reason
   if 21 - 21: oOo0oooo00o
def OoO00 ( url ) :
 i1i1I111iIi1 = urllib2 . Request ( url )
 i1i1I111iIi1 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 i1i1I111iIi1 . add_header ( 'Referer' , '%s' % url )
 i1i1I111iIi1 . add_header ( 'Connection' , 'keep-alive' )
 oo00O00oO000o = urllib2 . urlopen ( i1i1I111iIi1 )
 OOo00OoO = oo00O00oO000o . read ( )
 oo00O00oO000o . close ( )
 return OOo00OoO
 if 85 - 85: ii11ii1ii * ii11ii1ii * OOooOOo . OoooooooOO . I1i1i1ii * oooOOOOO
 if 65 - 65: O00o0o0000o0o * iiiI11
def ooo0o000O ( ) :
 if 100 - 100: iiIIIII1i1iI . oooOOOOO * oO0o0ooO0 / iIii1I11I1II1 * i1IIi % oooOOOOO
 oOooOOOoOo = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 if 17 - 17: oOo0oooo00o . O00OoOoo00 - II111iiii + O0 / iIii1I11I1II1 / i11iIiiIii
 if i1IiiiI1iI == 'true' :
  if 39 - 39: O00OoOoo00 * ii11ii1ii + iIii1I11I1II1 - O00OoOoo00 + O00o0o0000o0o
  o0 ( '[COLOR %s]Buscar Pelicula[/COLOR]' % oOooOOOoOo , 'search' , 111 , O0o0O00Oo0o0 , IiI1i11iii1 )
  o0 ( '[COLOR %s]Buscar Serie[/COLOR]' % oOooOOOoOo , 'search' , 145 , O00O0oOO00O00 , IiI1i11iii1 )
  o0 ( '[COLOR %s]Peliculas[/COLOR] ' % oOooOOOoOo , 'movieDB' , 116 , ii1ii1ii , IiI1i11iii1 )
  o0 ( '[COLOR %s]Series[/COLOR] ' % oOooOOOoOo , 'movieDB' , 117 , oooooOoo0ooo , IiI1i11iii1 )
  if 30 - 30: O0 * OoooooooOO
  if 38 - 38: O00OoOoo00 - oO0o0ooO0 . iI1Ii11111iIi - iiiI11 . OoooooooOO
 if o0O0OOO0Ooo == 'true' :
  o0 ( '[COLOR %s]Ajustes[/COLOR]' % oOooOOOoOo , 'Settings' , 119 , I1I1IiI1 , IiI1i11iii1 )
  if 89 - 89: iIii1I11I1II1
  if 21 - 21: oOo0oooo00o % oOo0oooo00o
  if Oo0oO == 'true' :
   iiI1 ( )
   if 16 - 16: II111iiii + iiIIIII1i1iI - OoooooooOO
  if iiIiII1 == 'true' :
   ii1iI ( )
   IIi ( )
   if 89 - 89: II111iiii + i1IIi + II111iiii
  if ooOOoooooo == 'false' :
   if 7 - 7: O0 % ii1II11I1ii1I + oO0o0ooO0 * IIIII - IIIII
   I1iiIIIi11 = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   Ii1I11ii1i = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Script.ResolveURL para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   O0iIiIIIIIii = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 42 - 42: iI1Ii11111iIi * iI1Ii11111iIi * iiiI11 . oOo0oooo00o
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , I1iiIIIi11 , Ii1I11ii1i , O0iIiIIIIIii )
   if 51 - 51: O00o0o0000o0o % iIii1I11I1II1 - OoooooooOO % oooOOOOO * iIii1I11I1II1 % oO0ooO
def oO0o00oOOooO0 ( ) :
 o0 ( '[COLOR orange]Buscador por id[/COLOR]' , i1I1ii11i1Iii , 127 , o0oo0o0O00OO , IiI1i11iii1 )
 if 79 - 79: oO0ooO - iIii1I11I1II1 + I1i1i1ii - iiiI11
def OoO ( ) :
 oOooOOOoOo = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 o0 ( '[COLOR %s]The movie DB[/COLOR]' % oOooOOOoOo , 'movieDB' , 99 , o0oo0o0O00OO , IiI1i11iii1 )
 if 35 - 35: iI1Ii11111iIi + i11iIiiIii - II111iiii
 o0 ( '[COLOR %s]Video tutoriales[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 125 , ooo00OOOooO , IiI1i11iii1 )
 if 15 - 15: i11iIiiIii % OOooOOo * oOo0oooo00o / iiiI11
 if 90 - 90: IIIII
def Iii1I111 ( ) :
 if 31 - 31: O00o0o0000o0o + O0
 ooo0o000O ( )
 OoO ( )
 if 87 - 87: oooOOOOO
 if 45 - 45: oO0ooO / OoooooooOO - IIIII / I1i1i1ii % O00OoOoo00
def OoOIii11iI11i1I ( ) :
 if 64 - 64: i11iIiiIii
 Iii1I111 ( )
 if 38 - 38: O00OoOoo00 / OOooOOo - O00OoOoo00 . oOo0oooo00o
 if 69 - 69: OoooooooOO + oO0o0ooO0
def O0oOo00o0 ( ) :
 if xbmc . getCondVisibility ( 'System.HasAddon(script.favourites)' ) :
  try :
   xbmc . executebuiltin ( "RunScript(script.favourites)" )
  except :
   pass
def OooOOOOoO00OoOO ( ) :
 IiII1IiiIiI1 . openSettings ( )
 if 85 - 85: iiIIIII1i1iI - iIii1I11I1II1 / O0
 if 99 - 99: II111iiii * O00OoOoo00 % iIii1I11I1II1 / I1i1i1ii
def OOO00O0oOOo ( ) :
 urlresolver . display_settings ( )
 if 71 - 71: oOo0oooo00o / ii1II11I1ii1I / iiiI11 % O00o0o0000o0o
def ii1iI ( ) :
 o0 ( '[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % oOooOOOoOo , 'resolve' , 120 , oo00O00oO , IiI1i11iii1 )
 if 51 - 51: O00OoOoo00 * O0 / II111iiii . I1i1i1ii % O00o0o0000o0o / OOooOOo
def ii1iii1I1I ( ) :
 if 95 - 95: O00OoOoo00
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 51 - 51: II111iiii + O00OoOoo00 . i1IIi . oO0o0ooO0 + iI1Ii11111iIi * OOooOOo
def IIi ( ) :
 o0 ( '[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % oOooOOOoOo , 'resolve' , 140 , oo00O00oO , IiI1i11iii1 )
 if 72 - 72: iiIIIII1i1iI + iiIIIII1i1iI / II111iiii . OoooooooOO % I1i1i1ii
def iiI1 ( ) :
 if 49 - 49: iiIIIII1i1iI . oO0ooO - ii11ii1ii * OoooooooOO . ii11ii1ii
 oOooOOOoOo = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 o0 ( '[COLOR %s]Buscador[/COLOR]' % oOooOOOoOo , 'search' , 111 , O0O00o0OOO0 , IiI1i11iii1 )
 o0 ( '[COLOR %s]Estrenos[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 3 , I1i1iii , IiI1i11iii1 )
 o0 ( '[COLOR %s]Todas[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 26 , i1iiI11I , IiI1i11iii1 )
 o0 ( '[COLOR %s]4K[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 141 , OOOO0OOoO0O0 , IiI1i11iii1 )
 o0 ( '[COLOR %s]Novedades[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 2 , o0oO , IiI1i11iii1 )
 o0 ( '[COLOR %s]Accion[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 5 , iiii , IiI1i11iii1 )
 o0 ( '[COLOR %s]Animacion[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 6 , oO0o0O0OOOoo0 , IiI1i11iii1 )
 o0 ( '[COLOR %s]Artes Marciales[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 29 , Oo0oOOo , IiI1i11iii1 )
 o0 ( '[COLOR %s]Aventuras[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 7 , IiIiiI , IiI1i11iii1 )
 o0 ( '[COLOR %s]Belico[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 8 , I1I , IiI1i11iii1 )
 o0 ( '[COLOR %s]Ciencia Ficcion[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 9 , oOO00oOO , IiI1i11iii1 )
 o0 ( '[COLOR %s]Cine Clasico[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 30 , OoOo , IiI1i11iii1 )
 o0 ( '[COLOR %s]Comedia[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 10 , iI , IiI1i11iii1 )
 o0 ( '[COLOR %s]Crimen[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 11 , o00O , IiI1i11iii1 )
 o0 ( '[COLOR %s]Drama[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 12 , OOO0OOO00oo , IiI1i11iii1 )
 o0 ( '[COLOR %s]Familiar[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 13 , Iii111II , IiI1i11iii1 )
 o0 ( '[COLOR %s]Fantasia[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 14 , iiii11I , IiI1i11iii1 )
 o0 ( '[COLOR %s]Historia[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 15 , Ooo0OO0oOO , IiI1i11iii1 )
 o0 ( '[COLOR %s]Misterio[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 16 , IIIii1II1II , IiI1i11iii1 )
 o0 ( '[COLOR %s]Musical[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 17 , i1I1iI , IiI1i11iii1 )
 o0 ( '[COLOR %s]Romance[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 18 , oo0OooOOo0 , IiI1i11iii1 )
 o0 ( '[COLOR %s]Thriller[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 19 , oO0Oo , IiI1i11iii1 )
 o0 ( '[COLOR %s]Suspense[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 20 , O00oO , IiI1i11iii1 )
 o0 ( '[COLOR %s]Terror[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 21 , I11i1I1I , IiI1i11iii1 )
 o0 ( '[COLOR %s]Western[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 22 , oOOoo0Oo , IiI1i11iii1 )
 o0 ( '[COLOR %s]Spain[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 23 , o0O , IiI1i11iii1 )
 o0 ( '[COLOR %s]Super heroes[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 24 , ii11i1 , IiI1i11iii1 )
 o0 ( '[COLOR %s]Sagas[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 25 , o00OO00OoO , IiI1i11iii1 )
 if 2 - 2: OoooooooOO % O00o0o0000o0o
def oOoOOo0oo0 ( ) :
 if 60 - 60: oooOOOOO * iiiI11 + ii11ii1ii
 o0 ( '[COLOR %s]Buscar Serie[/COLOR]' % oOooOOOoOo , 'search' , 145 , oO0 , IiI1i11iii1 )
 o0 ( '[COLOR %s]En emision[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 150 , Oo0OoO00oOO0o , IiI1i11iii1 )
 o0 ( '[COLOR %s]Mejor valoradas[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 151 , OOO00O , IiI1i11iii1 )
 o0 ( '[COLOR %s]Series Retro[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 152 , OOoOO0oo0ooO , IiI1i11iii1 )
 o0 ( '[COLOR %s]Todas[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 142 , Ii1iIiII1ii1 , IiI1i11iii1 )
 if 19 - 19: oO0ooO * oOo0oooo00o / oOo0oooo00o . OoooooooOO - O00o0o0000o0o + i11iIiiIii
def oo0OOo0O ( ) :
 if 39 - 39: OoooooooOO + iiIIIII1i1iI % O00o0o0000o0o / O00o0o0000o0o
 if 27 - 27: IIIII . oOo0oooo00o . iIii1I11I1II1 . iIii1I11I1II1
 try :
  if 20 - 20: ii1II11I1ii1I / i1IIi
  oOIi111 = i1 ( Iiii1iI1i )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( oOIi111 )
  for Oo0oooO0oO in oOOoo00O0O :
   if 67 - 67: O0
   try :
    if 52 - 52: II111iiii . oooOOOOO / iI1Ii11111iIi / OoooooooOO . i11iIiiIii
    I1i1i = Oo0oooO0oO
    OOOO0O00o = xbmc . Keyboard ( '' , 'Buscar' )
    OOOO0O00o . doModal ( )
    if ( OOOO0O00o . isConfirmed ( ) ) :
     if 86 - 86: ii11ii1ii / iiIIIII1i1iI + O0 * IIIII
     i1II = urllib . quote_plus ( OOOO0O00o . getText ( ) ) . replace ( '+' , ' ' )
     IIiiI = i1 ( I1i1i )
     oOOoo00O0O = re . compile ( Iii1IIII11I ) . findall ( IIiiI )
     for oo0Oo00Oo0 , i1Iii11I1i , IiI1i11iii1 , Oo00o0OO0O00o in oOOoo00O0O :
      if re . search ( i1II , iiIi1i ( i1Iii11I1i . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       o0 ( i1Iii11I1i , Oo00o0OO0O00o , 143 , oo0Oo00Oo0 , IiI1i11iii1 )
       if 19 - 19: II111iiii * O00OoOoo00 + I1i1i1ii
   except :
    pass
 except :
  pass
  if 65 - 65: O00o0o0000o0o . iiiI11 . oO0ooO . IIIII - O00o0o0000o0o
def ii111i ( ) :
 if 93 - 93: oO0ooO
 try :
  if 5 - 5: oOo0oooo00o / O00o0o0000o0o
  oOIi111 = i1 ( IIi1IIIi )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( oOIi111 )
  for Oo0oooO0oO in oOOoo00O0O :
   if 77 - 77: oooOOOOO - OOooOOo % oOo0oooo00o - O0
   try :
    if 67 - 67: O00o0o0000o0o + ii11ii1ii
    I1i1i = Oo0oooO0oO
    if 84 - 84: O0 * OoooooooOO - O00OoOoo00 * O00OoOoo00
   except :
    pass
    if 8 - 8: oooOOOOO / i1IIi . iiIIIII1i1iI
  IIiiI = i1 ( I1i1i )
  oOOoo00O0O = re . compile ( Iii1IIII11I ) . findall ( IIiiI )
  for oo0Oo00Oo0 , i1Iii11I1i , IiI1i11iii1 , Oo00o0OO0O00o in oOOoo00O0O :
   try :
    if 41 - 41: IIIII + oO0ooO
    o0 ( i1Iii11I1i , Oo00o0OO0O00o , 143 , oo0Oo00Oo0 , IiI1i11iii1 )
    if 86 - 86: iI1Ii11111iIi . iIii1I11I1II1 - oO0ooO
   except :
    pass
 except :
  pass
  if 56 - 56: O0
  if 61 - 61: ii1II11I1ii1I / O00o0o0000o0o / ii11ii1ii * O0
def iIII1i1i ( ) :
 if 35 - 35: II111iiii * oOo0oooo00o - OoooooooOO . oOo0oooo00o . oOo0oooo00o
 try :
  if 11 - 11: iiiI11 / iI1Ii11111iIi + oOo0oooo00o % iIii1I11I1II1
  oOIi111 = i1 ( oOoO00o )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( oOIi111 )
  for Oo0oooO0oO in oOOoo00O0O :
   if 42 - 42: oO0o0ooO0 * iI1Ii11111iIi % oooOOOOO - iI1Ii11111iIi . i11iIiiIii - iiiI11
   try :
    if 84 - 84: iiiI11 - oO0o0ooO0 / oOo0oooo00o
    I1i1i = Oo0oooO0oO
    if 13 - 13: O00OoOoo00 - ii11ii1ii - oooOOOOO
   except :
    pass
    if 92 - 92: oooOOOOO / iI1Ii11111iIi * oO0ooO . oOo0oooo00o % II111iiii
  IIiiI = i1 ( I1i1i )
  oOOoo00O0O = re . compile ( Iii1IIII11I ) . findall ( IIiiI )
  for oo0Oo00Oo0 , i1Iii11I1i , IiI1i11iii1 , Oo00o0OO0O00o in oOOoo00O0O :
   try :
    if 71 - 71: iiiI11 % i1IIi - II111iiii - O00o0o0000o0o + O00o0o0000o0o * oooOOOOO
    o0 ( i1Iii11I1i , Oo00o0OO0O00o , 143 , oo0Oo00Oo0 , IiI1i11iii1 )
    if 51 - 51: iIii1I11I1II1 / iI1Ii11111iIi + O00o0o0000o0o - oOo0oooo00o + IIIII
   except :
    pass
 except :
  pass
  if 29 - 29: ii1II11I1ii1I % iIii1I11I1II1 . OoooooooOO % OoooooooOO % II111iiii / IIIII
def oo0o0000Oo0 ( ) :
 if 80 - 80: iiiI11 - ii11ii1ii
 try :
  if 96 - 96: oO0o0ooO0 / II111iiii . I1i1i1ii - IIIII * oOo0oooo00o * iiIIIII1i1iI
  oOIi111 = i1 ( o0OoOO )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( oOIi111 )
  for Oo0oooO0oO in oOOoo00O0O :
   if 76 - 76: I1i1i1ii - II111iiii * O00o0o0000o0o / OoooooooOO
   try :
    if 18 - 18: oO0ooO + iIii1I11I1II1 - II111iiii - OOooOOo
    I1i1i = Oo0oooO0oO
    if 71 - 71: OoooooooOO
   except :
    pass
    if 33 - 33: iiiI11
  IIiiI = i1 ( I1i1i )
  oOOoo00O0O = re . compile ( Iii1IIII11I ) . findall ( IIiiI )
  for oo0Oo00Oo0 , i1Iii11I1i , IiI1i11iii1 , Oo00o0OO0O00o in oOOoo00O0O :
   try :
    if 62 - 62: oO0o0ooO0 + I1i1i1ii + i1IIi / OoooooooOO
    o0 ( i1Iii11I1i , Oo00o0OO0O00o , 143 , oo0Oo00Oo0 , IiI1i11iii1 )
    if 7 - 7: ii1II11I1ii1I + i1IIi . OOooOOo / ii11ii1ii
   except :
    pass
 except :
  pass
  if 22 - 22: oooOOOOO - oooOOOOO % O00o0o0000o0o . iiiI11 + iiIIIII1i1iI
def Oo00OOo00O ( ) :
 if 81 - 81: O00OoOoo00 . ii1II11I1ii1I / iiiI11
 try :
  if 17 - 17: i11iIiiIii - O00o0o0000o0o . O00OoOoo00 % iIii1I11I1II1 + oOo0oooo00o - oooOOOOO
  oOIi111 = i1 ( Iiii1iI1i )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( oOIi111 )
  for Oo0oooO0oO in oOOoo00O0O :
   if 78 - 78: oOo0oooo00o * iI1Ii11111iIi . O0 / O0
   try :
    if 80 - 80: i1IIi - ii11ii1ii / oO0ooO - i11iIiiIii
    I1i1i = Oo0oooO0oO
    if 68 - 68: iiIIIII1i1iI - oO0o0ooO0 % O0 % iiiI11
   except :
    pass
    if 11 - 11: O0 / oO0ooO % O00o0o0000o0o + ii1II11I1ii1I + iIii1I11I1II1
  IIiiI = i1 ( I1i1i )
  oOOoo00O0O = re . compile ( OOOoo0OO ) . findall ( IIiiI )
  for oo0Oo00Oo0 , i1Iii11I1i , IiI1i11iii1 , Oo00o0OO0O00o , I1i1111I in oOOoo00O0O :
   try :
    if 95 - 95: iIii1I11I1II1 - oO0o0ooO0 . iiiI11 - OOooOOo
    if 75 - 75: oO0ooO + ii1II11I1ii1I - i1IIi . OoooooooOO * I1i1i1ii / O00OoOoo00
    OOOooo0OooOoO ( i1Iii11I1i , Oo00o0OO0O00o , oOoOOOo , ii1Io0OOoOoO00 , IiI1i11iii1 , I1i1111I )
    if 15 - 15: O00OoOoo00 / O0 . ii1II11I1ii1I . i11iIiiIii
   except :
    pass
 except :
  pass
  if 59 - 59: iiiI11 - ii1II11I1ii1I - oooOOOOO
def Ii11iI ( name , url ) :
 if 52 - 52: O00o0o0000o0o - IIIII * iiIIIII1i1iI
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 17 - 17: OoooooooOO + O00o0o0000o0o * oOo0oooo00o * iI1Ii11111iIi
 iI1I = i1 ( url )
 oOOoo00O0O = re . compile ( oO0o0 ) . findall ( iI1I )
 for ii1Io0OOoOoO00 , name , IiI1i11iii1 , url in oOOoo00O0O :
  try :
   if 36 - 36: O0 + ii11ii1ii
   if 5 - 5: ii11ii1ii * iI1Ii11111iIi
   iii = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % iii + name + '[/COLOR]'
   ii1I11iIiIII1 ( name , url , 144 , ii1Io0OOoOoO00 , IiI1i11iii1 )
   if 52 - 52: ii1II11I1ii1I * O00OoOoo00 + iI1Ii11111iIi
   if 49 - 49: iIii1I11I1II1 - O0 . i1IIi - OoooooooOO
  except :
   pass
   if 37 - 37: i1IIi . oOo0oooo00o % iI1Ii11111iIi + OoooooooOO / IIIII
   if 3 - 3: oO0o0ooO0
   if 17 - 17: oO0o0ooO0 . II111iiii . oooOOOOO / oO0o0ooO0
def ii1I11iIiIII1 ( name , url , mode , iconimage , fanart ) :
 if 57 - 57: oOo0oooo00o
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 67 - 67: oO0ooO . oooOOOOO
 oO00oOo0OOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage="
 ii1ooO = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 ii1ooO . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 ii1ooO . setProperty ( 'fanart_image' , fanart )
 ii1ooO . setProperty ( 'IsPlayable' , 'true' )
 oOoOoO000OO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO00oOo0OOO , listitem = ii1ooO )
 return oOoOoO000OO
 if 38 - 38: ii1II11I1ii1I
 if 23 - 23: ii11ii1ii % oOo0oooo00o - O00o0o0000o0o % iIii1I11I1II1 . iI1Ii11111iIi
def I1Ii1 ( name , url ) :
 if 79 - 79: i11iIiiIii . O00o0o0000o0o - ii11ii1ii / OoooooooOO
 if 66 - 66: oO0ooO * ii11ii1ii
 o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 oo00 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 o00 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 Oo0oO0ooo = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 o0oOoO00o = i1 ( o00 )
 oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
 for i11 in oOOoo00O0O :
  if 28 - 28: oO0ooO % iI1Ii11111iIi % oO0o0ooO0 + OOooOOo / OOooOOo
  try :
   if 71 - 71: O00o0o0000o0o * oO0ooO % OoooooooOO % oO0ooO / OOooOOo
   if 56 - 56: OoooooooOO % i11iIiiIii * iIii1I11I1II1 . oO0ooO * O0
   o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 23 - 23: i11iIiiIii
   if 39 - 39: ii1II11I1ii1I - oO0o0ooO0 % IIIII * oO0ooO - O00o0o0000o0o / IIIII
   if o0oO0 == i11 :
    if 29 - 29: oO0o0ooO0
    if 52 - 52: i11iIiiIii / i1IIi
    if 'https://team.com' in url :
     if 1 - 1: oooOOOOO
     url = url . replace ( 'https://team.com' , 'https://verystream.com' )
     if 78 - 78: oO0o0ooO0 + oOo0oooo00o - O0
    if 'https://mybox.com' in url :
     if 10 - 10: iiiI11 % OOooOOo
     url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
     if 97 - 97: OoooooooOO - iiiI11
     if 58 - 58: iIii1I11I1II1 + O0
    if 'https://vidcloud.co/' in url :
     if 30 - 30: oooOOOOO % IIIII * O00o0o0000o0o - oO0o0ooO0 * I1i1i1ii % oooOOOOO
     url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
     if 46 - 46: i11iIiiIii - O0 . iiIIIII1i1iI
    if 'https://gounlimited.to' in url :
     if 100 - 100: OOooOOo / ii1II11I1ii1I * IIIII . O0 / O00o0o0000o0o
     url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
     if 83 - 83: iiiI11
    if 'https://drive.com' in url :
     if 48 - 48: II111iiii * O00o0o0000o0o * iiiI11
     url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
     if 50 - 50: O00OoOoo00 % i1IIi
     if 21 - 21: OoooooooOO - iIii1I11I1II1
    import resolveurl
    if 93 - 93: iiIIIII1i1iI - ii1II11I1ii1I % iI1Ii11111iIi . iI1Ii11111iIi - oooOOOOO
    O00ooOo = urlresolver . HostedMediaFile ( url )
    if 80 - 80: ii1II11I1ii1I - O00o0o0000o0o + OoooooooOO
    if not O00ooOo :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
     return False
     if 98 - 98: O00o0o0000o0o + i1IIi . OOooOOo - II111iiii - ii1II11I1ii1I
    try :
     iIIi1I1ii = xbmcgui . DialogProgress ( )
     iIIi1I1ii . create ( 'Realstream:' , 'Iniciando ...' )
     iIIi1I1ii . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
     xbmc . sleep ( 1000 )
     Iiii = O00ooOo . resolve ( )
     if not Iiii or not isinstance ( Iiii , basestring ) :
      try : i1i = Iiii . msg
      except : i1i = url
      raise Exception ( i1i )
      if 81 - 81: oooOOOOO + IIIII
    except Exception as iIi1 :
     try : i1i = str ( iIi1 )
     except : i1i = url
     iIIi1I1ii . update ( 45 , 'RESOLVEURL:' , 'Reiniciando ... ' )
     xbmc . sleep ( 1000 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Episodio no disponible.  ,3000)" )
     iIIi1I1ii . close ( )
     if 52 - 52: OOooOOo % oO0o0ooO0 - O00o0o0000o0o + IIIII . iI1Ii11111iIi
    iIIi1I1ii . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    iIIi1I1ii . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
    xbmc . sleep ( 500 )
    iIIi1I1ii . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
    xbmc . sleep ( 500 )
    iIIi1I1ii . update ( 100 , 'RESOLVEURL:' , 'Disfrute de este capitulo!' )
    iIIi1I1ii . close ( )
    II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
    oOO0oo = xbmcgui . ListItem ( path = Iiii )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO0oo )
    if 13 - 13: OoooooooOO * iiIIIII1i1iI - I1i1i1ii / O00o0o0000o0o + oOo0oooo00o + O00OoOoo00
    if 39 - 39: iIii1I11I1II1 - OoooooooOO
   else :
    if 81 - 81: oO0o0ooO0 - O0 * OoooooooOO
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold]>El addon esta desactivado.[/COLOR]" )
    if 23 - 23: II111iiii / iiIIIII1i1iI
    if 28 - 28: ii11ii1ii * oooOOOOO - oO0ooO
  except :
   pass
   if 19 - 19: oOo0oooo00o
   if 67 - 67: O0 % iIii1I11I1II1 / O00OoOoo00 . i11iIiiIii - I1i1i1ii + O0
   if 27 - 27: O00o0o0000o0o
   if 89 - 89: II111iiii / iiIIIII1i1iI
   if 14 - 14: O00o0o0000o0o . OOooOOo * oooOOOOO + II111iiii - oooOOOOO + O00o0o0000o0o
   if 18 - 18: iiIIIII1i1iI - ii1II11I1ii1I - OOooOOo - OOooOOo
def OOooo00 ( ) :
 if 35 - 35: iiiI11 . iI1Ii11111iIi * i11iIiiIii
 if 44 - 44: i11iIiiIii / ii11ii1ii
 Ii1IIi = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 Ii1IIi . doModal ( )
 if not Ii1IIi . isConfirmed ( ) :
  return None ;
 i1Iii11I1i = Ii1IIi . getText ( ) . strip ( )
 if 43 - 43: iiiI11 % IIIII
 if 69 - 69: IIIII % oO0ooO
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 86 - 86: iiIIIII1i1iI / iiIIIII1i1iI
  IiiI = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + i1Iii11I1i + '&language=es-ES' ) )
  if 19 - 19: II111iiii
  if 72 - 72: OoooooooOO / OOooOOo + I1i1i1ii / iI1Ii11111iIi * I1i1i1ii
  return 'android'
  if 34 - 34: O0 * O0 % OoooooooOO + IIIII * iIii1I11I1II1 % I1i1i1ii
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 25 - 25: oOo0oooo00o + iI1Ii11111iIi . ii1II11I1ii1I % iI1Ii11111iIi * O00o0o0000o0o
  IiiI = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + i1Iii11I1i + '&language=es-ES' )
  if 32 - 32: i11iIiiIii - iiiI11
  if 53 - 53: OoooooooOO - O00OoOoo00
  return 'windows'
  if 87 - 87: iiIIIII1i1iI . OOooOOo
  if 17 - 17: I1i1i1ii . i11iIiiIii
def IIIiiiI ( ) :
 if 94 - 94: O0 - oOo0oooo00o - iIii1I11I1II1 % oooOOOOO / I1i1i1ii % IIIII
 iIi1IIi1ii = 'https://netai.eu/realstream/prueba.m3u'
 iI1I = i1 ( iIi1IIi1ii )
 oOOoo00O0O = re . compile ( OooOoOO0 ) . findall ( iI1I )
 for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo , I1i1111I , IiI1i11iii1 in oOOoo00O0O :
  try :
   if 35 - 35: IIIII / oO0o0ooO0 * OoooooooOO . II111iiii / ii11ii1ii
   Iii11i ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo , I1i1111I , IiI1i11iii1 )
   if 73 - 73: ii11ii1ii - iI1Ii11111iIi - iiIIIII1i1iI - OOooOOo
  except :
   pass
   if 65 - 65: ii1II11I1ii1I
   if 7 - 7: O00OoOoo00 . iI1Ii11111iIi / oO0o0ooO0 . O00o0o0000o0o * oOo0oooo00o - II111iiii
   if 37 - 37: iiiI11 . iI1Ii11111iIi / O0 * IIIII
def III11iiii11i1 ( ) :
 if 54 - 54: i1IIi - iiIIIII1i1iI
 try :
  if 18 - 18: iIii1I11I1II1 + ii11ii1ii - O00o0o0000o0o + OoooooooOO * OoooooooOO
  o0oOoO00o = i1 ( iiIiI1i1 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 41 - 41: oooOOOOO . ii11ii1ii + OOooOOo
   try :
    if 100 - 100: I1i1i1ii + oO0ooO
    all = Oo0oooO0oO
    if 73 - 73: i1IIi - iiiI11 % oooOOOOO / oO0ooO
   except :
    pass
    if 40 - 40: oO0o0ooO0 * oooOOOOO - OOooOOo / O00OoOoo00 / i11iIiiIii
  iI1I = i1 ( all )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( iI1I )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    if 83 - 83: oO0o0ooO0 / iiiI11 - i11iIiiIii . iIii1I11I1II1 + ii11ii1ii
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 59 - 59: O0 % ii11ii1ii
   except :
    pass
 except :
  pass
  if 92 - 92: I1i1i1ii % IIIII / oO0o0ooO0 % oO0o0ooO0 * OOooOOo
def OooO00oOOo0Oo ( ) :
 if 5 - 5: ii1II11I1ii1I . O0 / ii11ii1ii % oO0ooO
 try :
  if 60 - 60: II111iiii / iIii1I11I1II1 + oO0o0ooO0 . i11iIiiIii
  o0oO = i1 ( IiIi11iI )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oO )
  for Oo0oooO0oO in oOOoo00O0O :
   if 40 - 40: ii1II11I1ii1I
   try :
    if 78 - 78: iIii1I11I1II1
    I1i1i = Oo0oooO0oO
    if 56 - 56: OoooooooOO - oOo0oooo00o - i1IIi
   except :
    pass
    if 8 - 8: iiiI11 / O00o0o0000o0o . OOooOOo + oO0o0ooO0 / i11iIiiIii
  IIiiI = i1 ( I1i1i )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( IIiiI )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    if 31 - 31: oooOOOOO - iIii1I11I1II1 + IIIII . ii11ii1ii / O00OoOoo00 % iIii1I11I1II1
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 6 - 6: O00OoOoo00 * i11iIiiIii % iIii1I11I1II1 % i11iIiiIii + ii1II11I1ii1I / i1IIi
   except :
    pass
 except :
  pass
  if 53 - 53: oOo0oooo00o + iIii1I11I1II1
def oOooo0Oo ( ) :
 if 66 - 66: ii11ii1ii
 try :
  if 28 - 28: O00OoOoo00 - O00OoOoo00 . i1IIi - oooOOOOO + OOooOOo . O00OoOoo00
  I1i1iii = i1 ( i11I1IiII1i1i )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( I1i1iii )
  for Oo0oooO0oO in oOOoo00O0O :
   if 54 - 54: iI1Ii11111iIi - iiiI11
   try :
    iIIiIIIi = Oo0oooO0oO
   except :
    pass
    if 98 - 98: iiIIIII1i1iI % O00OoOoo00 * i11iIiiIii % oO0o0ooO0
  o0oOoO00o = i1 ( iIIiIIIi )
  oOOoo00O0O = re . compile ( OooOoOO0 ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo , I1i1111I , IiI1i11iii1 in oOOoo00O0O :
   try :
    if 29 - 29: O00OoOoo00
    if 66 - 66: ii11ii1ii
    Iii11i ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo , I1i1111I , IiI1i11iii1 )
    if 97 - 97: i1IIi - OoooooooOO / iiiI11 * OOooOOo
   except :
    pass
 except :
  pass
  if 55 - 55: ii1II11I1ii1I . IIIII
def oOo00o00oO ( ) :
 if 95 - 95: OOooOOo
 try :
  if 88 - 88: O00OoOoo00 % oO0ooO + iiiI11 + iiiI11 * II111iiii
  o0oOoO00o = i1 ( db2 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 78 - 78: OoooooooOO
   try :
    if 77 - 77: oO0o0ooO0 / i1IIi / ii11ii1ii % O00o0o0000o0o
    I1I1Iiii1 = Oo0oooO0oO
    if 2 - 2: oOo0oooo00o + oooOOOOO
   except :
    pass
    if 76 - 76: iiiI11
    if 99 - 99: OOooOOo + i1IIi + i11iIiiIii + ii11ii1ii % iiIIIII1i1iI / oOo0oooo00o
  o0oOoO00o = i1 ( I1I1Iiii1 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 60 - 60: I1i1i1ii * iI1Ii11111iIi - i11iIiiIii % oooOOOOO
   except :
    pass
 except :
  pass
  if 52 - 52: oO0o0ooO0 % iiIIIII1i1iI - i11iIiiIii
def i1III ( ) :
 if 6 - 6: IIIII . oOo0oooo00o + I1i1i1ii . iiiI11
 try :
  if 70 - 70: oO0ooO
  i1iIi1111 = i1 ( o0Oooo )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( i1iIi1111 )
  for Oo0oooO0oO in oOOoo00O0O :
   if 13 - 13: oO0ooO
   try :
    if 37 - 37: I1i1i1ii + iiiI11 - ii11ii1ii + I1i1i1ii
    Oo0o0Oo0O = Oo0oooO0oO
    if 63 - 63: iIii1I11I1II1
   except :
    pass
    if 21 - 21: iI1Ii11111iIi / ii1II11I1ii1I * O00OoOoo00 . i1IIi
    if 59 - 59: O0 + i1IIi - ii1II11I1ii1I
  o0oOoO00o = i1 ( Oo0o0Oo0O )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 62 - 62: i11iIiiIii % O00o0o0000o0o . O00OoOoo00 . O00o0o0000o0o
   except :
    pass
 except :
  pass
  if 84 - 84: i11iIiiIii * oO0ooO
def I1I1iII1i ( ) :
 if 30 - 30: O0 + oO0o0ooO0 + II111iiii
 try :
  if 14 - 14: ii1II11I1ii1I / O00o0o0000o0o - iIii1I11I1II1 - iiIIIII1i1iI % oooOOOOO
  o0oOoO00o = i1 ( I1111i )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 49 - 49: oooOOOOO * iiIIIII1i1iI / ii1II11I1ii1I / ii11ii1ii * iIii1I11I1II1
   try :
    if 57 - 57: iI1Ii11111iIi - iiIIIII1i1iI / oooOOOOO % i11iIiiIii
    I11 = Oo0oooO0oO
    if 100 - 100: oO0o0ooO0 + i11iIiiIii - i1IIi
   except :
    pass
    if 29 - 29: ii1II11I1ii1I / i11iIiiIii / OOooOOo % iiIIIII1i1iI % i11iIiiIii
    if 18 - 18: O00o0o0000o0o + iiiI11
  o0oOoO00o = i1 ( I11 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 80 - 80: iiIIIII1i1iI + ii1II11I1ii1I * I1i1i1ii + oO0ooO
   except :
    pass
 except :
  pass
  if 75 - 75: oOo0oooo00o / ii1II11I1ii1I / O00o0o0000o0o / O00OoOoo00 % oooOOOOO + II111iiii
def I1III111i ( ) :
 if 4 - 4: i1IIi + oooOOOOO + i1IIi
 try :
  if 31 - 31: I1i1i1ii
  o0oOoO00o = i1 ( o00O0O )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 78 - 78: i11iIiiIii + ii1II11I1ii1I + iiiI11 / ii1II11I1ii1I % iIii1I11I1II1 % O00OoOoo00
   try :
    if 83 - 83: iIii1I11I1II1 % iI1Ii11111iIi % ii1II11I1ii1I % iiiI11 . oO0o0ooO0 % O0
    iIiIi1ii = Oo0oooO0oO
    if 28 - 28: iIii1I11I1II1 + iIii1I11I1II1
   except :
    pass
    if 28 - 28: iiIIIII1i1iI
  o0oOoO00o = i1 ( iIiIi1ii )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 52 - 52: OOooOOo + iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 71 - 71: O0 / iiIIIII1i1iI
def iI1 ( ) :
 if 11 - 11: oO0ooO
 try :
  if 18 - 18: IIIII - iiIIIII1i1iI % IIIII / oOo0oooo00o
  o0oOoO00o = i1 ( Iii1I1111ii )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 68 - 68: I1i1i1ii * iIii1I11I1II1 + iiiI11 % iI1Ii11111iIi
   try :
    if 46 - 46: iI1Ii11111iIi % i1IIi / iiIIIII1i1iI * ii11ii1ii * O00o0o0000o0o
    OOoOOOo0Ooo0 = Oo0oooO0oO
    if 80 - 80: I1i1i1ii - ii1II11I1ii1I
   except :
    pass
    if 41 - 41: ii1II11I1ii1I - ii11ii1ii * OOooOOo
    if 82 - 82: oO0ooO % ii1II11I1ii1I % O00o0o0000o0o / O0
  o0oOoO00o = i1 ( OOoOOOo0Ooo0 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 94 - 94: oO0o0ooO0 + oO0o0ooO0 + OoooooooOO % oooOOOOO
   except :
    pass
 except :
  pass
  if 7 - 7: IIIII
def oOo000O ( ) :
 if 1 - 1: iIii1I11I1II1
 try :
  if 54 - 54: OoooooooOO - OOooOOo % oO0o0ooO0
  o0oOoO00o = i1 ( Ii1IIiI1i )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 92 - 92: oO0ooO * oooOOOOO
   try :
    if 35 - 35: i11iIiiIii
    ooOo0O00o0OoO = Oo0oooO0oO
    if 39 - 39: iI1Ii11111iIi - ii11ii1ii / IIIII * OoooooooOO
   except :
    pass
    if 100 - 100: O0 . oOo0oooo00o . oO0ooO + O0 * iiIIIII1i1iI
    if 42 - 42: iiIIIII1i1iI % OoooooooOO + ii1II11I1ii1I
  o0oOoO00o = i1 ( ooOo0O00o0OoO )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 56 - 56: OoooooooOO + oO0o0ooO0 - IIIII
   except :
    pass
 except :
  pass
  if 24 - 24: ii1II11I1ii1I + oooOOOOO + oOo0oooo00o - iIii1I11I1II1
def I11Oo0oO00 ( ) :
 if 8 - 8: OOooOOo % OOooOOo . iI1Ii11111iIi % ii1II11I1ii1I
 try :
  if 47 - 47: oooOOOOO + II111iiii % iiiI11 . oOo0oooo00o % oO0o0ooO0
  o0oOoO00o = i1 ( IiII111i1i11 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 7 - 7: O0 / IIIII * iiIIIII1i1iI
   try :
    if 29 - 29: ii1II11I1ii1I
    oo0 = Oo0oooO0oO
    if 2 - 2: OoooooooOO
   except :
    pass
    if 60 - 60: oO0ooO
    if 81 - 81: iI1Ii11111iIi % I1i1i1ii
  o0oOoO00o = i1 ( oo0 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 87 - 87: iIii1I11I1II1 . OoooooooOO * iI1Ii11111iIi
   except :
    pass
 except :
  pass
  if 100 - 100: oO0ooO / i1IIi - OOooOOo % I1i1i1ii - iIii1I11I1II1
def i11II ( ) :
 if 71 - 71: O00OoOoo00 . iiiI11 . oO0ooO
 try :
  if 68 - 68: i11iIiiIii % iiIIIII1i1iI * oO0ooO * O00OoOoo00 * II111iiii + O0
  o0oOoO00o = i1 ( oO )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 66 - 66: oOo0oooo00o % oO0o0ooO0 % OoooooooOO
   try :
    if 34 - 34: ii1II11I1ii1I / IIIII % O0 . oO0ooO . i1IIi
    iiO0O0o0oO0O00 = Oo0oooO0oO
    if 70 - 70: iiiI11 + iiIIIII1i1iI
   except :
    pass
    if 93 - 93: iiiI11 + I1i1i1ii
    if 33 - 33: O0
  o0oOoO00o = i1 ( iiO0O0o0oO0O00 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 78 - 78: O0 / II111iiii * oO0ooO
   except :
    pass
 except :
  pass
  if 50 - 50: OoooooooOO - iIii1I11I1II1 + i1IIi % iiiI11 - iIii1I11I1II1 % O0
  if 58 - 58: O00OoOoo00 + iIii1I11I1II1
def Oo00OO0OO ( ) :
 if 85 - 85: ii1II11I1ii1I % oooOOOOO . iI1Ii11111iIi % iiiI11 - ii11ii1ii
 try :
  if 69 - 69: oooOOOOO - ii1II11I1ii1I . oooOOOOO
  o0oOoO00o = i1 ( oooO )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 9 - 9: iiIIIII1i1iI % i11iIiiIii / ii11ii1ii
   try :
    if 20 - 20: iiIIIII1i1iI * O0 + oOo0oooo00o - OoooooooOO . oOo0oooo00o
    oOII1ii1ii11I1 = Oo0oooO0oO
    if 88 - 88: oO0o0ooO0
   except :
    pass
    if 93 - 93: iIii1I11I1II1
    if 66 - 66: i11iIiiIii * iIii1I11I1II1 % OoooooooOO
  o0oOoO00o = i1 ( oOII1ii1ii11I1 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 5 - 5: iI1Ii11111iIi % OoooooooOO
   except :
    pass
 except :
  pass
  if 60 - 60: iI1Ii11111iIi . i1IIi % oO0ooO % oooOOOOO % O00o0o0000o0o
  if 33 - 33: iIii1I11I1II1 - I1i1i1ii * oO0o0ooO0 % iIii1I11I1II1 + oO0ooO . O00o0o0000o0o
def ooo0O0oOoooO0 ( ) :
 if 42 - 42: O00o0o0000o0o % iiIIIII1i1iI / oO0ooO - iiIIIII1i1iI * i11iIiiIii
 try :
  if 19 - 19: iiIIIII1i1iI * OOooOOo % i11iIiiIii
  o0oOoO00o = i1 ( ooo )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 24 - 24: ii1II11I1ii1I
   try :
    if 10 - 10: ii1II11I1ii1I % I1i1i1ii / O00o0o0000o0o
    i11Ii1iIiII = Oo0oooO0oO
    if 81 - 81: oOo0oooo00o . OoooooooOO * iI1Ii11111iIi % O00OoOoo00 . oOo0oooo00o
   except :
    pass
    if 60 - 60: O00o0o0000o0o / OOooOOo
    if 78 - 78: oOo0oooo00o . O00OoOoo00
  o0oOoO00o = i1 ( i11Ii1iIiII )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 38 - 38: iI1Ii11111iIi + O00OoOoo00
   except :
    pass
    if 15 - 15: ii11ii1ii + oOo0oooo00o . oooOOOOO - iIii1I11I1II1 / O0 % iIii1I11I1II1
 except :
  pass
  if 86 - 86: OOooOOo / iiIIIII1i1iI * I1i1i1ii
  if 64 - 64: oooOOOOO / O0 * iI1Ii11111iIi * oooOOOOO
def O00oo ( ) :
 if 58 - 58: iIii1I11I1II1 - i11iIiiIii - i11iIiiIii * I1i1i1ii + ii1II11I1ii1I . iI1Ii11111iIi
 try :
  if 80 - 80: i1IIi + i11iIiiIii - iiiI11 % II111iiii . iiIIIII1i1iI
  o0oOoO00o = i1 ( Ooo0oOooo0 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 10 - 10: oOo0oooo00o / oOo0oooo00o * i11iIiiIii
   try :
    if 46 - 46: oO0ooO * ii11ii1ii % iiIIIII1i1iI + O0 * O00OoOoo00
    ii1I11i = Oo0oooO0oO
    if 89 - 89: iiiI11 . O00OoOoo00 % ii11ii1ii . ii11ii1ii - OoooooooOO
   except :
    pass
    if 56 - 56: oOo0oooo00o
    if 21 - 21: iIii1I11I1II1 / iiiI11 + oooOOOOO - oOo0oooo00o / ii11ii1ii / II111iiii
  o0oOoO00o = i1 ( ii1I11i )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 69 - 69: OOooOOo . iI1Ii11111iIi
   except :
    pass
    if 53 - 53: oOo0oooo00o
 except :
  pass
  if 68 - 68: iiIIIII1i1iI / iiiI11 % iiiI11 % O0
def o0Ii1 ( ) :
 if 50 - 50: iiIIIII1i1iI - oooOOOOO / iIii1I11I1II1 - oO0ooO + II111iiii - O0
 try :
  if 88 - 88: iiIIIII1i1iI * oO0ooO
  o0oOoO00o = i1 ( iiIiIIIiiI )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 35 - 35: oO0o0ooO0 / IIIII % OOooOOo + iIii1I11I1II1
   try :
    if 79 - 79: iI1Ii11111iIi / oooOOOOO
    oOo00o = Oo0oooO0oO
    if 98 - 98: O00o0o0000o0o % i1IIi . OOooOOo . II111iiii . oO0o0ooO0 / i11iIiiIii
   except :
    pass
    if 32 - 32: ii1II11I1ii1I + OOooOOo . iiiI11
  o0oOoO00o = i1 ( oOo00o )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 41 - 41: iI1Ii11111iIi . i11iIiiIii / oOo0oooo00o
   except :
    pass
 except :
  pass
  if 98 - 98: iI1Ii11111iIi % II111iiii
  if 95 - 95: iIii1I11I1II1 - iiiI11 - O00o0o0000o0o + iiiI11 % oO0o0ooO0 . OOooOOo
def IiiIIi1 ( ) :
 if 28 - 28: ii1II11I1ii1I
 try :
  if 45 - 45: ii1II11I1ii1I . OOooOOo / iiiI11 - ii11ii1ii * iIii1I11I1II1
  o0oOoO00o = i1 ( II11IiIi11 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 86 - 86: II111iiii + oooOOOOO + O00OoOoo00
   try :
    if 9 - 9: oooOOOOO + II111iiii % oooOOOOO % O00OoOoo00 + iIii1I11I1II1
    oO00 = Oo0oooO0oO
    if 7 - 7: O0 % iiiI11 + oO0o0ooO0 + I1i1i1ii % OoooooooOO . ii11ii1ii
   except :
    pass
    if 56 - 56: IIIII
    if 84 - 84: iI1Ii11111iIi - i11iIiiIii
  o0oOoO00o = i1 ( oO00 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 1 - 1: IIIII * iI1Ii11111iIi
   except :
    pass
 except :
  pass
  if 66 - 66: iI1Ii11111iIi + i1IIi % II111iiii . O0 * oO0o0ooO0 % oO0o0ooO0
  if 87 - 87: O00o0o0000o0o + ii1II11I1ii1I . IIIII - OoooooooOO
def iiiiI1IiI1I1 ( ) :
 if 19 - 19: I1i1i1ii
 try :
  if 55 - 55: O00o0o0000o0o % O00o0o0000o0o / O0 % IIIII - ii1II11I1ii1I . ii11ii1ii
  o0oOoO00o = i1 ( OOO0O00O0OOOO )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 49 - 49: iIii1I11I1II1 * i1IIi . OoooooooOO
   try :
    if 90 - 90: ii1II11I1ii1I % oO0o0ooO0 - iIii1I11I1II1 % iI1Ii11111iIi
    IIiI11I1I1i1i = Oo0oooO0oO
    if 86 - 86: i1IIi
   except :
    pass
  o0oOoO00o = i1 ( IIiI11I1I1i1i )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 13 - 13: O0
   except :
    pass
 except :
  pass
  if 70 - 70: I1i1i1ii . i11iIiiIii % I1i1i1ii . O0 - iIii1I11I1II1
def i111i1iIi1 ( ) :
 if 95 - 95: OoooooooOO + oOo0oooo00o - oO0o0ooO0 / oO0o0ooO0 . i1IIi . OoooooooOO
 try :
  if 29 - 29: oooOOOOO - i1IIi . oOo0oooo00o - oO0o0ooO0 + oooOOOOO + OoooooooOO
  o0oOoO00o = i1 ( OOo0 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 36 - 36: i1IIi / oooOOOOO . iIii1I11I1II1
   try :
    if 12 - 12: I1i1i1ii
    Ooii1IIi1ii = Oo0oooO0oO
    if 85 - 85: OoooooooOO % iI1Ii11111iIi * iIii1I11I1II1
   except :
    pass
    if 44 - 44: iIii1I11I1II1 . oO0o0ooO0 + iiiI11 . oooOOOOO
    if 7 - 7: oO0o0ooO0 + iIii1I11I1II1 * oOo0oooo00o * oOo0oooo00o / II111iiii - I1i1i1ii
  o0oOoO00o = i1 ( Ooii1IIi1ii )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 65 - 65: iiIIIII1i1iI + iI1Ii11111iIi + II111iiii
   except :
    pass
 except :
  pass
  if 77 - 77: II111iiii
  if 50 - 50: O0 . O0 . oooOOOOO % ii11ii1ii
def ooo000oOO ( ) :
 if 27 - 27: ii1II11I1ii1I * i11iIiiIii * oO0ooO
 try :
  if 92 - 92: ii11ii1ii / i11iIiiIii + oO0o0ooO0
  o0oOoO00o = i1 ( oo0o )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 87 - 87: iI1Ii11111iIi % iIii1I11I1II1
   try :
    if 72 - 72: O00o0o0000o0o . O00o0o0000o0o - oO0o0ooO0
    III1II1i = Oo0oooO0oO
    if 3 - 3: IIIII
   except :
    pass
    if 35 - 35: O00OoOoo00 . O0 + ii11ii1ii + O00o0o0000o0o + i1IIi
    if 65 - 65: O0 * OOooOOo / OOooOOo . iI1Ii11111iIi
  o0oOoO00o = i1 ( III1II1i )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 87 - 87: II111iiii * oO0o0ooO0 % ii11ii1ii * ii11ii1ii
   except :
    pass
 except :
  pass
  if 58 - 58: O00o0o0000o0o . ii1II11I1ii1I + OOooOOo % ii11ii1ii - oO0ooO
def I1Iii1Ii1i1 ( ) :
 if 10 - 10: IIIII . i1IIi + I1i1i1ii
 try :
  if 66 - 66: oO0ooO % ii1II11I1ii1I
  o0oOoO00o = i1 ( I1III1111iIi )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 21 - 21: iI1Ii11111iIi - OoooooooOO % i11iIiiIii
   try :
    if 71 - 71: i1IIi - oOo0oooo00o * iiiI11 + iiIIIII1i1iI - oO0ooO % oO0o0ooO0
    Ooo0oO = Oo0oooO0oO
    if 32 - 32: i1IIi . IIIII + II111iiii - oO0ooO - iIii1I11I1II1
   except :
    pass
    if 20 - 20: iI1Ii11111iIi % oO0o0ooO0
    if 44 - 44: OoooooooOO . II111iiii . O00o0o0000o0o % OoooooooOO
  o0oOoO00o = i1 ( Ooo0oO )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 86 - 86: i11iIiiIii + O0 * O00OoOoo00 - oO0ooO * O00o0o0000o0o + O0
   except :
    pass
 except :
  pass
  if 95 - 95: iIii1I11I1II1 . iiiI11 % IIIII - iiiI11 * II111iiii
  if 89 - 89: IIIII . OOooOOo
def ooOoo0OoOO ( ) :
 if 38 - 38: oO0ooO / oooOOOOO % iiiI11 * oOo0oooo00o + i11iIiiIii % oooOOOOO
 try :
  if 61 - 61: iiiI11 - I1i1i1ii % oO0o0ooO0 / oooOOOOO / IIIII + iIii1I11I1II1
  o0oOoO00o = i1 ( Ooo )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 87 - 87: iiiI11 + oooOOOOO + O0 / i1IIi % O00OoOoo00 / iiiI11
   try :
    if 64 - 64: oO0ooO % O00OoOoo00 . iiiI11 % oO0ooO + oOo0oooo00o * O00OoOoo00
    OOOO00OooO = Oo0oooO0oO
    if 64 - 64: oO0ooO . OOooOOo - OoooooooOO . oooOOOOO - IIIII
   except :
    pass
    if 77 - 77: I1i1i1ii % iI1Ii11111iIi / II111iiii % IIIII % OoooooooOO % oO0ooO
    if 19 - 19: O00OoOoo00 * iiiI11 / iiIIIII1i1iI * iiiI11 - OoooooooOO * oOo0oooo00o
  o0oOoO00o = i1 ( OOOO00OooO )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 17 - 17: II111iiii + ii11ii1ii . iiiI11
   except :
    pass
 except :
  pass
  if 12 - 12: iiiI11 + O00o0o0000o0o + oOo0oooo00o . O00OoOoo00 / I1i1i1ii
  if 29 - 29: O00OoOoo00 . oooOOOOO - II111iiii
def ooooO0 ( ) :
 if 37 - 37: i11iIiiIii + OOooOOo . O00o0o0000o0o % oOo0oooo00o % oOo0oooo00o
 try :
  if 26 - 26: O0
  o0oOoO00o = i1 ( I1i11 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 34 - 34: oooOOOOO * iiiI11
   try :
    if 97 - 97: i11iIiiIii % iiIIIII1i1iI / ii11ii1ii / ii11ii1ii
    OoO00ooO = Oo0oooO0oO
    if 15 - 15: i11iIiiIii
   except :
    pass
    if 13 - 13: oOo0oooo00o * II111iiii * iiIIIII1i1iI * II111iiii % O00OoOoo00 / OOooOOo
    if 100 - 100: O00OoOoo00 . I1i1i1ii - iIii1I11I1II1 . i11iIiiIii / II111iiii
  o0oOoO00o = i1 ( OoO00ooO )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 71 - 71: iiiI11 * ii11ii1ii . oOo0oooo00o
   except :
    pass
 except :
  pass
  if 49 - 49: O00OoOoo00 * O0 . O00OoOoo00
  if 19 - 19: II111iiii - O00OoOoo00
def OOOOo000o00OO ( ) :
 if 96 - 96: O0 . O00o0o0000o0o % oooOOOOO + i11iIiiIii - O00o0o0000o0o * oooOOOOO
 try :
  if 33 - 33: oooOOOOO % i1IIi - iiIIIII1i1iI . O0 / O0
  o0oOoO00o = i1 ( IiIIi1 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 96 - 96: OoooooooOO + O00OoOoo00 * O0
   try :
    if 86 - 86: I1i1i1ii
    IiII1i1iI = Oo0oooO0oO
    if 84 - 84: O00OoOoo00 + oO0o0ooO0 + I1i1i1ii + IIIII
   except :
    pass
    if 62 - 62: i11iIiiIii + iI1Ii11111iIi + i1IIi
    if 69 - 69: iI1Ii11111iIi
  o0oOoO00o = i1 ( IiII1i1iI )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 63 - 63: oO0ooO / iI1Ii11111iIi * iIii1I11I1II1 . iiiI11
   except :
    pass
 except :
  pass
  if 85 - 85: i11iIiiIii / i11iIiiIii . oO0ooO . O0
  if 67 - 67: II111iiii / ii1II11I1ii1I . O00o0o0000o0o . OoooooooOO
def i1I1Ii11i ( ) :
 if 19 - 19: O00OoOoo00 - ii1II11I1ii1I . iIii1I11I1II1 . iI1Ii11111iIi / O00o0o0000o0o
 try :
  if 87 - 87: iI1Ii11111iIi - oooOOOOO - O00o0o0000o0o + ii11ii1ii % iIii1I11I1II1 / i11iIiiIii
  o0oOoO00o = i1 ( II1i11I )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 12 - 12: oooOOOOO
   try :
    if 86 - 86: iiIIIII1i1iI - oO0ooO
    OoOO = Oo0oooO0oO
    if 3 - 3: OoooooooOO
   except :
    pass
    if 71 - 71: O00OoOoo00 + i1IIi - IIIII - i11iIiiIii . oOo0oooo00o - oooOOOOO
  o0oOoO00o = i1 ( OoOO )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 85 - 85: oO0o0ooO0 - iI1Ii11111iIi / oO0o0ooO0 + O00o0o0000o0o - IIIII
   except :
    pass
 except :
  pass
  if 49 - 49: oO0ooO - O0 / oO0ooO * iI1Ii11111iIi + iiiI11
  if 35 - 35: II111iiii . OOooOOo / i1IIi / OOooOOo * iiIIIII1i1iI
def Oo0 ( ) :
 if 96 - 96: oOo0oooo00o % I1i1i1ii % iiIIIII1i1iI * oOo0oooo00o / O00o0o0000o0o
 try :
  if 13 - 13: iIii1I11I1II1 - oO0ooO
  o0oOoO00o = i1 ( O0o0oO )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 100 - 100: i11iIiiIii / i11iIiiIii
   try :
    if 89 - 89: IIIII . i11iIiiIii * O0
    Iii = Oo0oooO0oO
    if 35 - 35: O00OoOoo00 . OoooooooOO / O00o0o0000o0o
   except :
    pass
    if 52 - 52: iiiI11 % iI1Ii11111iIi + iIii1I11I1II1 * iiIIIII1i1iI . I1i1i1ii
    if 95 - 95: iIii1I11I1II1 . O00OoOoo00 - OoooooooOO * oO0ooO / ii1II11I1ii1I
  o0oOoO00o = i1 ( Iii )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 74 - 74: iiIIIII1i1iI
   except :
    pass
 except :
  pass
  if 34 - 34: IIIII
def ii1IIiI1IIi ( ) :
 if 76 - 76: IIIII / oO0ooO + iI1Ii11111iIi
 try :
  if 86 - 86: i11iIiiIii + i11iIiiIii . iiiI11 % OOooOOo . oooOOOOO
  o0oOoO00o = i1 ( I11iiiiI1i )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 17 - 17: I1i1i1ii
   try :
    if 67 - 67: O0 * oOo0oooo00o - ii1II11I1ii1I - II111iiii
    Ii11iiI1 = Oo0oooO0oO
    if 71 - 71: ii1II11I1ii1I / O00o0o0000o0o % O00o0o0000o0o
   except :
    pass
  o0oOoO00o = i1 ( Ii11iiI1 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 89 - 89: OoooooooOO + i11iIiiIii / oOo0oooo00o + iIii1I11I1II1 % oooOOOOO
   except :
    pass
 except :
  pass
  if 29 - 29: oO0o0ooO0
def Oo0o00ooOOOoOo ( ) :
 if 30 - 30: oooOOOOO + oooOOOOO % O00OoOoo00 - ii1II11I1ii1I - oO0o0ooO0
 try :
  if 36 - 36: oOo0oooo00o % O00o0o0000o0o
  o0oOoO00o = i1 ( OoOOoooOO0O )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 72 - 72: OOooOOo / IIIII - O0 + oOo0oooo00o
   try :
    if 83 - 83: O0
    oOOOOOo = Oo0oooO0oO
    if 50 - 50: iiiI11 + oooOOOOO + IIIII
   except :
    pass
  o0oOoO00o = i1 ( oOOOOOo )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 15 - 15: oOo0oooo00o
   except :
    pass
 except :
  pass
  if 13 - 13: iIii1I11I1II1 * iI1Ii11111iIi / iiiI11 % oooOOOOO + iiIIIII1i1iI
def iiiI1iI1 ( ) :
 if 15 - 15: O00OoOoo00 . i1IIi * iI1Ii11111iIi % iIii1I11I1II1
 try :
  if 35 - 35: oO0o0ooO0 + iiiI11 - iI1Ii11111iIi % iiIIIII1i1iI % ii1II11I1ii1I % iI1Ii11111iIi
  o0oOoO00o = i1 ( o0O0oo0OO0O )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 45 - 45: OOooOOo * O00o0o0000o0o % oO0ooO
   try :
    if 24 - 24: oooOOOOO - oOo0oooo00o * iiIIIII1i1iI
    O00OoOoO = Oo0oooO0oO
    if 58 - 58: oO0o0ooO0
   except :
    pass
  o0oOoO00o = i1 ( O00OoOoO )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 19 - 19: iIii1I11I1II1 * OoooooooOO * i11iIiiIii
   except :
    pass
 except :
  pass
  if 79 - 79: O00OoOoo00 % oO0ooO
def Oo0oOO ( ) :
 if 86 - 86: iIii1I11I1II1 / O0
 try :
  if 17 - 17: II111iiii
  o0oOoO00o = i1 ( Oo0o0O00 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 9 - 9: OoooooooOO + iiIIIII1i1iI
   try :
    if 33 - 33: O0
    iiI1ii = Oo0oooO0oO
    if 76 - 76: I1i1i1ii + iIii1I11I1II1 + iI1Ii11111iIi . oO0ooO
   except :
    pass
  o0oOoO00o = i1 ( iiI1ii )
  oOOoo00O0O = re . compile ( OO0Oooo0oOO0O ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o in oOOoo00O0O :
   try :
    i1i1 ( III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o )
    if 68 - 68: I1i1i1ii - OOooOOo
   except :
    pass
    if 41 - 41: iiIIIII1i1iI
 except :
  pass
  if 21 - 21: oooOOOOO + ii1II11I1ii1I % iiiI11 + i11iIiiIii + IIIII + II111iiii
  if 98 - 98: iiiI11
  if 49 - 49: ii11ii1ii * iiIIIII1i1iI + ii1II11I1ii1I - i11iIiiIii
def i1i1 ( thumb , name , url ) :
 if 74 - 74: ii11ii1ii / iIii1I11I1II1 . II111iiii - oO0ooO
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( ii1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   o0 ( name , url , '' , oo0Oo00Oo0 , IiI1i11iii1 )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 62 - 62: O00o0o0000o0o / II111iiii + iI1Ii11111iIi % oooOOOOO / iI1Ii11111iIi + oO0o0ooO0
  if 'tvg-logo' in thumb :
   thumb = re . compile ( ii1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 2 - 2: i11iIiiIii - iiiI11 + oO0ooO % oOo0oooo00o * I1i1i1ii
   Ooo000O00 ( name , url , 4 , ii1Io0OOoOoO00 , IiI1i11iii1 )
   if 36 - 36: O00o0o0000o0o % i11iIiiIii
  else :
   if 47 - 47: i1IIi + II111iiii . ii11ii1ii * iiIIIII1i1iI . oOo0oooo00o / i1IIi
   Ooo000O00 ( name , url , 4 , ii1Io0OOoOoO00 , IiI1i11iii1 )
   if 50 - 50: iiiI11 / i1IIi % OoooooooOO
def I1i11111i1i11 ( name , url , thumb , id , trailer ) :
 if 83 - 83: oO0o0ooO0 * oO0o0ooO0 + O00o0o0000o0o
 if 57 - 57: O0 - O0 . oO0o0ooO0 / ii1II11I1ii1I / I1i1i1ii
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 20 - 20: O00o0o0000o0o * II111iiii - iI1Ii11111iIi - iiIIIII1i1iI * iiiI11
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( ii1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   o0 ( name , url , '' , oo0Oo00Oo0 , IiI1i11iii1 )
 else :
  iii = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
  if 6 - 6: oooOOOOO + O00o0o0000o0o / ii11ii1ii + O00OoOoo00 % II111iiii / oO0ooO
  name = '[COLOR %s]' % iii + name + '[/COLOR]'
  if 45 - 45: OoooooooOO
  if 'tvg-logo' in thumb :
   thumb = re . compile ( ii1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   iiIiI = IiII1IiiIiI1 . getSetting ( 'selecton' )
   if iiIiI == 'true' :
    if 9 - 9: oOo0oooo00o . oO0ooO * i1IIi . OoooooooOO
    II1 ( name , url , 1 , thumb , thumb , id , trailer )
    if 60 - 60: II111iiii + i1IIi . O0 + OOooOOo
   else :
    if 80 - 80: iiIIIII1i1iI % iiIIIII1i1iI % O0 - i11iIiiIii . IIIII / O0
    II1 ( name , url , 130 , thumb , thumb , id , trailer )
    if 13 - 13: OOooOOo + O0 - oO0o0ooO0 % ii11ii1ii / I1i1i1ii . i1IIi
  else :
   if 60 - 60: ii11ii1ii . O00OoOoo00 % OOooOOo - iiiI11
   if iiIiI == 'true' :
    if 79 - 79: OoooooooOO / oO0o0ooO0 . O0
    II1 ( name , url , 1 , thumb , thumb , id , trailer )
    if 79 - 79: iiIIIII1i1iI - II111iiii
   else :
    if 43 - 43: i1IIi + O0 % oO0ooO / I1i1i1ii * OOooOOo
    II1 ( name , url , 130 , thumb , thumb , id , trailer )
    if 89 - 89: OOooOOo . ii11ii1ii + oO0o0ooO0 . O0 % ii1II11I1ii1I
    if 84 - 84: OoooooooOO + iiiI11 / OOooOOo % O00o0o0000o0o % oO0o0ooO0 * OOooOOo
def Iii11i ( name , url , thumb , id , trailer , description , fanart ) :
 if 58 - 58: oO0ooO - iI1Ii11111iIi . i11iIiiIii % i11iIiiIii / i1IIi / iiIIIII1i1iI
 if 24 - 24: OOooOOo * i1IIi % oooOOOOO / O0 + i11iIiiIii
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 iii = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
 fanart = fanart . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 name = '[COLOR %s]' % iii + name + '[/COLOR]'
 if 12 - 12: oO0o0ooO0 / I1i1i1ii
 if 'tvg-logo' in thumb :
  thumb = re . compile ( ii1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  iiIiI = IiII1IiiIiI1 . getSetting ( 'selecton' )
  if iiIiI == 'true' :
   if 5 - 5: OoooooooOO
   IIIii11i1I ( name , url , 1 , thumb , fanart , id , trailer , description )
   if 79 - 79: iiiI11
  else :
   if 31 - 31: O00o0o0000o0o % iiiI11
   IIIii11i1I ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 98 - 98: O00OoOoo00 * iIii1I11I1II1 . I1i1i1ii * ii11ii1ii / oO0o0ooO0 + oooOOOOO
 else :
  if 25 - 25: iiIIIII1i1iI
  if iiIiI == 'true' :
   if 19 - 19: OOooOOo % I1i1i1ii . O00OoOoo00 * oooOOOOO
   IIIii11i1I ( name , url , 1 , thumb , fanart , id , trailer , description )
   if 89 - 89: iI1Ii11111iIi . O00o0o0000o0o
  else :
   if 7 - 7: iiIIIII1i1iI % iI1Ii11111iIi - OOooOOo + ii11ii1ii
   IIIii11i1I ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 70 - 70: II111iiii + iiiI11 + i11iIiiIii - i1IIi / O00OoOoo00
def iI1IIiiIIIII ( name , trailer ) :
 if 43 - 43: IIIII + ii11ii1ii / OoooooooOO
 if II1I == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Realstream, Reproduciendo Trailer de: [COLOR green]" + name + "[/COLOR] ,5000)" )
  if 24 - 24: O0 + ii1II11I1ii1I * I1i1i1ii - iiiI11
  Oo00o0OO0O00o = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  iii11i1 = Oo00o0OO0O00o
  O00oo00OOOO = xbmcgui . ListItem ( name , trailer , path = iii11i1 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O00oo00OOOO )
 else :
  Oo00o0OO0O00o = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  iii11i1 = Oo00o0OO0O00o
  O00oo00OOOO = xbmcgui . ListItem ( name , trailer , path = iii11i1 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O00oo00OOOO )
  if 48 - 48: iIii1I11I1II1 % i1IIi + iI1Ii11111iIi % ii1II11I1ii1I
  if 79 - 79: iI1Ii11111iIi % OOooOOo % I1i1i1ii / i1IIi % oO0ooO
def oo0o00OO ( trailer ) :
 if 69 - 69: ii1II11I1ii1I % i11iIiiIii / I1i1i1ii
 if 'https://www.youtube.com' in trailer :
  if 93 - 93: oooOOOOO
  try :
   if 34 - 34: iiIIIII1i1iI - oooOOOOO * ii11ii1ii / ii1II11I1ii1I
   import resolveurl
   if 19 - 19: oO0o0ooO0
   O00ooOo = urlresolver . HostedMediaFile ( Oo00o0OO0O00o )
   iIIi1I1ii = xbmcgui . DialogProgress ( )
   iIIi1I1ii . create ( 'Realstream:' , 'Conectando al servidor ... ' )
   iIIi1I1ii . update ( 20 , 'Por favor, espere ...' )
   xbmc . sleep ( 500 )
   if 46 - 46: iIii1I11I1II1 . i11iIiiIii - iI1Ii11111iIi % O0 / II111iiii * i1IIi
   if not O00ooOo :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    return False
    if 66 - 66: O0
   try :
    if 52 - 52: oO0ooO * OoooooooOO
    iIIi1I1ii . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    Iiii = O00ooOo . resolve ( )
    if not Iiii or not isinstance ( Iiii , basestring ) :
     try : i1i = Iiii . msg
     except : i1i = Iiii
     raise Exception ( i1i )
   except Exception as iIi1 :
    try : i1i = str ( iIi1 )
    except : i1i = Iiii
    iIIi1I1ii . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
    iIIi1I1ii . close ( )
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    if 12 - 12: O0 + O00OoOoo00 * i1IIi . oO0ooO
   iIIi1I1ii . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
   xbmc . sleep ( 500 )
   iIIi1I1ii . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   iIIi1I1ii . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
   xbmc . sleep ( 500 )
   iIIi1I1ii . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   iIIi1I1ii . close ( )
   if 71 - 71: iiiI11 - ii1II11I1ii1I - O00o0o0000o0o
   oOO0oo = xbmcgui . ListItem ( path = Iiii )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO0oo )
   if 28 - 28: iIii1I11I1II1
  except :
   pass
   if 7 - 7: ii1II11I1ii1I % O00OoOoo00 * iI1Ii11111iIi
  else :
   if 58 - 58: O00OoOoo00 / oOo0oooo00o + II111iiii % IIIII - OoooooooOO
   Oo00o0OO0O00o = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
   iii11i1 = Oo00o0OO0O00o
   O00oo00OOOO = xbmcgui . ListItem ( trailer , path = iii11i1 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O00oo00OOOO )
   return
   if 25 - 25: iI1Ii11111iIi % OoooooooOO * ii11ii1ii - i1IIi * II111iiii * iiIIIII1i1iI
def I1iI1I1ii1 ( name , url ) :
 if 33 - 33: ii1II11I1ii1I / O0 + O00o0o0000o0o
 if '[Youtube]' in name :
  if 75 - 75: O00OoOoo00 % i11iIiiIii + iIii1I11I1II1
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  iii11i1 = url
  O00oo00OOOO = xbmcgui . ListItem ( O0Oooo , path = iii11i1 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O00oo00OOOO )
  if 92 - 92: iI1Ii11111iIi % O0
  if 55 - 55: iIii1I11I1II1 * IIIII
 else :
  if 85 - 85: iIii1I11I1II1 . II111iiii
  import urlresolver
  from urlresolver import common
  if 54 - 54: I1i1i1ii . OoooooooOO % ii11ii1ii
  O00ooOo = urlresolver . HostedMediaFile ( url )
  if 22 - 22: O00o0o0000o0o
  if not O00ooOo :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 22 - 22: IIIII * oOo0oooo00o - ii11ii1ii * O0 / i11iIiiIii
   if 78 - 78: ii11ii1ii * O0 / oooOOOOO + OoooooooOO + O00o0o0000o0o
  try :
   Iiii = O00ooOo . resolve ( )
   if not Iiii or not isinstance ( Iiii , basestring ) :
    try : i1i = Iiii . msg
    except : i1i = url
    raise Exception ( i1i )
  except Exception as iIi1 :
   try : i1i = str ( iIi1 )
   except : i1i = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 23 - 23: IIIII % OoooooooOO / iIii1I11I1II1 + oO0o0ooO0 / i1IIi / ii1II11I1ii1I
  II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if II1I == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  oOO0oo = xbmcgui . ListItem ( path = Iiii )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO0oo )
  if 94 - 94: i1IIi
  if 36 - 36: OOooOOo + ii11ii1ii
 return
 if 46 - 46: IIIII
def ooIiI11i1I11111 ( name , url ) :
 if 34 - 34: OOooOOo * iI1Ii11111iIi * iiIIIII1i1iI + oO0o0ooO0
 import resolveurl
 if 39 - 39: oO0o0ooO0 / i1IIi * O00OoOoo00 - OOooOOo
 O00ooOo = urlresolver . HostedMediaFile ( url )
 dp = xbmcgui . DialogProgress ( )
 dp . create ( 'Realstream:' , 'Conectando al servidor ... ' )
 dp . update ( 20 , 'Por favor, espere ...' )
 xbmc . sleep ( 500 )
 if 74 - 74: O0 - II111iiii + i1IIi . iiiI11 . oO0o0ooO0
 if not O00ooOo :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  return False
  if 95 - 95: II111iiii / I1i1i1ii - oooOOOOO - II111iiii - i11iIiiIii
 try :
  if 85 - 85: ii1II11I1ii1I / iiiI11
  dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
  xbmc . sleep ( 500 )
  Iiii = O00ooOo . resolve ( )
  if not Iiii or not isinstance ( Iiii , basestring ) :
   try : i1i = Iiii . msg
   except : i1i = Iiii
   raise Exception ( i1i )
 except Exception as iIi1 :
  try : i1i = str ( iIi1 )
  except : i1i = Iiii
  dp . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
  dp . close ( )
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  if 67 - 67: oOo0oooo00o % iiIIIII1i1iI
 dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
 xbmc . sleep ( 500 )
 dp . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
 xbmc . sleep ( 500 )
 dp . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
 xbmc . sleep ( 500 )
 dp . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
 dp . close ( )
 II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
 if 39 - 39: i11iIiiIii + O00OoOoo00
 if 7 - 7: iIii1I11I1II1 - i1IIi
 if '[Realstream]' or '[Mybox]' in name :
  restante = IiII1IiiIiI1 . getSetting ( 'restante' )
 elif restante == 'true' :
  dialog = xbmcgui . Dialog ( )
  ok = dialog . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
 oOO0oo = xbmcgui . ListItem ( path = Iiii )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO0oo )
 if 10 - 10: iiiI11 % O0 / OOooOOo % oOo0oooo00o
def ooIiI11i1I11111 ( name , url ) :
 if 25 - 25: II111iiii / oO0ooO
 if 64 - 64: O0 % oooOOOOO
 if 'https://www.rapidvideo.com/v/' in url :
  if 40 - 40: ii1II11I1ii1I + oOo0oooo00o
  o0oOoO00o = i1 ( url )
  oOOoo00O0O = re . compile ( 'rapidvideo' ) . findall ( o0oOoO00o )
  for url in oOOoo00O0O :
   if 77 - 77: i11iIiiIii % O00OoOoo00 + iiiI11 % OoooooooOO - oOo0oooo00o
   if 26 - 26: ii11ii1ii + O0 - iIii1I11I1II1
   try :
    II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
    if II1I == 'true' :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oOO0oo = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO0oo )
    if 47 - 47: OoooooooOO
   except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 2 - 2: iI1Ii11111iIi % iiiI11 * ii11ii1ii * iI1Ii11111iIi
   if 65 - 65: i11iIiiIii + ii11ii1ii * OoooooooOO - oO0ooO
 else :
  if 26 - 26: ii1II11I1ii1I % O00o0o0000o0o + O00o0o0000o0o % oOo0oooo00o * i11iIiiIii / IIIII
  import urlresolver
  from urlresolver import common
  if 64 - 64: iiIIIII1i1iI % iI1Ii11111iIi / II111iiii % oooOOOOO - IIIII
  O00ooOo = urlresolver . HostedMediaFile ( url )
  if 2 - 2: iiiI11 - oO0o0ooO0 + ii1II11I1ii1I * oO0ooO / IIIII
  if not O00ooOo :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 26 - 26: O00o0o0000o0o * ii11ii1ii
   if 31 - 31: oOo0oooo00o * iiIIIII1i1iI . I1i1i1ii
  try :
   Iiii = O00ooOo . resolve ( )
   if not Iiii or not isinstance ( Iiii , basestring ) :
    try : i1i = Iiii . msg
    except : i1i = url
    raise Exception ( i1i )
  except Exception as iIi1 :
   try : i1i = str ( iIi1 )
   except : i1i = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 35 - 35: oOo0oooo00o
  II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if II1I == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  oOO0oo = xbmcgui . ListItem ( path = Iiii )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO0oo )
  if 94 - 94: oooOOOOO / i11iIiiIii % O0
 return
 if 70 - 70: oOo0oooo00o - ii11ii1ii / OoooooooOO % OoooooooOO
 if 95 - 95: OoooooooOO % OoooooooOO . I1i1i1ii
 if 26 - 26: iiIIIII1i1iI + O00OoOoo00 - II111iiii . II111iiii + oO0o0ooO0 + iI1Ii11111iIi
def o0IiIiI111IIII1 ( name , url ) :
 if 100 - 100: O00o0o0000o0o * O0 + OOooOOo + iI1Ii11111iIi . O00o0o0000o0o
 Iiii = url
 II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
 if II1I == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  oOO0oo = xbmcgui . ListItem ( path = Iiii )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO0oo )
 else :
  oOO0oo = xbmcgui . ListItem ( path = Iiii )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO0oo )
 return
 if 73 - 73: iiIIIII1i1iI . II111iiii * IIIII % iiIIIII1i1iI + iI1Ii11111iIi - oO0ooO
def I1iIi1iIIIIiI ( name , url ) :
 if 94 - 94: O00OoOoo00 * oOo0oooo00o * OoooooooOO / ii1II11I1ii1I . O00OoOoo00 - ii1II11I1ii1I
 if 13 - 13: O00o0o0000o0o / O00OoOoo00 - oO0ooO / O00o0o0000o0o . i1IIi
 if '[Youtube]' in name :
  if 22 - 22: O0 - oOo0oooo00o + iiiI11 . I1i1i1ii * i1IIi
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 26 - 26: iIii1I11I1II1 * ii1II11I1ii1I . oOo0oooo00o
  try :
   II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if II1I == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oOO0oo = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO0oo )
    if 10 - 10: iiiI11 * iiIIIII1i1iI % ii11ii1ii - oOo0oooo00o % ii11ii1ii
    if 65 - 65: IIIII * iIii1I11I1II1 / O0 . oOo0oooo00o
    if 94 - 94: ii11ii1ii . oooOOOOO * i11iIiiIii - ii1II11I1ii1I . IIIII
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 98 - 98: O00o0o0000o0o + I1i1i1ii
  if 52 - 52: ii11ii1ii / iI1Ii11111iIi - iiiI11 . IIIII
 else :
  if 50 - 50: iIii1I11I1II1 - IIIII - oOo0oooo00o
  import xbmcgui
  import urlresolver
  from urlresolver import common
  if 60 - 60: iIii1I11I1II1 * oooOOOOO
  O00ooOo = urlresolver . HostedMediaFile ( url )
  if 71 - 71: iI1Ii11111iIi % ii11ii1ii % oooOOOOO
  if not O00ooOo :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 34 - 34: oOo0oooo00o / oOo0oooo00o % O00OoOoo00 . iI1Ii11111iIi / ii11ii1ii
  import resolveurl as urlresolver
  if 99 - 99: oooOOOOO * OOooOOo - oooOOOOO % I1i1i1ii
  O00ooOo = urlresolver . HostedMediaFile ( url )
  if 40 - 40: O00o0o0000o0o / O00OoOoo00 / iIii1I11I1II1 + I1i1i1ii
  if 59 - 59: oOo0oooo00o * OoooooooOO + O00o0o0000o0o . iIii1I11I1II1 / i1IIi
  if not O00ooOo :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 75 - 75: oOo0oooo00o . O00o0o0000o0o - iIii1I11I1II1 * oO0ooO * IIIII
  try :
   Iiii = O00ooOo . resolve ( )
   if not Iiii or not isinstance ( Iiii , basestring ) :
    try : i1i = Iiii . msg
    except : i1i = url
    raise Exception ( i1i )
  except Exception as iIi1 :
   try : i1i = str ( iIi1 )
   except : i1i = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 93 - 93: oooOOOOO
   if 18 - 18: oooOOOOO
   if 66 - 66: iiIIIII1i1iI * i11iIiiIii + iI1Ii11111iIi / O00o0o0000o0o
  II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if II1I == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 96 - 96: O00o0o0000o0o + O00o0o0000o0o % O00OoOoo00 % O00o0o0000o0o
   if '[Realstream]' in name :
    if 28 - 28: iIii1I11I1II1 + iI1Ii11111iIi . ii1II11I1ii1I % i11iIiiIii
    IIII = IiII1IiiIiI1 . getSetting ( 'restante' )
    if IIII == 'true' :
     O00oOooo00o0o = xbmcgui . Dialog ( )
     oOoOoO000OO = O00oOooo00o0o . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 56 - 56: iI1Ii11111iIi % oO0o0ooO0 - I1i1i1ii % iIii1I11I1II1
   oOO0oo = xbmcgui . ListItem ( path = Iiii )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO0oo )
   if 76 - 76: OoooooooOO * OoooooooOO - IIIII - iIii1I11I1II1 . OoooooooOO / oO0o0ooO0
   if 86 - 86: oooOOOOO
   if 51 - 51: oO0ooO - i11iIiiIii * OOooOOo
 return
 if 95 - 95: O00o0o0000o0o % oO0o0ooO0 + ii1II11I1ii1I % oooOOOOO
 if 36 - 36: O0 / i1IIi % II111iiii / IIIII
 if 96 - 96: ii11ii1ii / iiIIIII1i1iI . II111iiii . ii11ii1ii
def ooIi111iII ( name , url ) :
 if 83 - 83: OoooooooOO + oO0ooO * iiIIIII1i1iI . O0
 if 13 - 13: ii1II11I1ii1I
 if '[Youtube]' in name :
  if 7 - 7: OOooOOo + O00OoOoo00 / i11iIiiIii / ii11ii1ii
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 97 - 97: iiiI11 . oOo0oooo00o / OOooOOo
  try :
   II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if II1I == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oOO0oo = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO0oo )
    if 83 - 83: oOo0oooo00o - oO0o0ooO0 * iiIIIII1i1iI
    if 90 - 90: ii11ii1ii * OOooOOo
    if 75 - 75: oO0o0ooO0 - iI1Ii11111iIi * i11iIiiIii . OoooooooOO - ii11ii1ii . oOo0oooo00o
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 6 - 6: oOo0oooo00o * iiIIIII1i1iI / OoooooooOO % I1i1i1ii * ii1II11I1ii1I
 else :
  if 28 - 28: O00OoOoo00 * OOooOOo % O00OoOoo00
  import resolveurl
  if 95 - 95: O0 / oOo0oooo00o . iiiI11
  O00ooOo = urlresolver . HostedMediaFile ( url )
  if 17 - 17: oOo0oooo00o
  if 56 - 56: oooOOOOO * ii1II11I1ii1I + oOo0oooo00o
  if not O00ooOo :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 48 - 48: O00OoOoo00 * oO0ooO % iiiI11 - oOo0oooo00o
  try :
   Iiii = O00ooOo . resolve ( )
   if not Iiii or not isinstance ( Iiii , basestring ) :
    try : i1i = Iiii . msg
    except : i1i = url
    raise Exception ( i1i )
  except Exception as iIi1 :
   try : i1i = str ( iIi1 )
   except : i1i = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 72 - 72: i1IIi % oooOOOOO % O00OoOoo00 % iiIIIII1i1iI - iiIIIII1i1iI
   if 97 - 97: ii1II11I1ii1I * O0 / ii1II11I1ii1I * oO0ooO * ii11ii1ii
   if 38 - 38: iiiI11
  II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if II1I == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 25 - 25: iIii1I11I1II1 % II111iiii / oOo0oooo00o / oO0o0ooO0
   if '[Realstream]' in name :
    if 22 - 22: iiIIIII1i1iI * IIIII
    IIII = IiII1IiiIiI1 . getSetting ( 'restante' )
    if IIII == 'true' :
     O00oOooo00o0o = xbmcgui . Dialog ( )
     oOoOoO000OO = O00oOooo00o0o . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 4 - 4: iI1Ii11111iIi - iiIIIII1i1iI + OOooOOo
   oOO0oo = xbmcgui . ListItem ( path = Iiii )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO0oo )
   if 36 - 36: O00OoOoo00
   if 19 - 19: iI1Ii11111iIi . ii1II11I1ii1I . OoooooooOO
   if 13 - 13: O00o0o0000o0o . ii11ii1ii / II111iiii
 return
 if 43 - 43: iIii1I11I1II1 % oO0ooO
def oOO0ooi1iiIIiII1 ( name , url ) :
 if 72 - 72: O00OoOoo00 % ii1II11I1ii1I
 if 93 - 93: iIii1I11I1II1 + i11iIiiIii . ii1II11I1ii1I . i1IIi % OOooOOo % oooOOOOO
 if '[Youtube]' in name :
  if 74 - 74: iI1Ii11111iIi / i1IIi % OoooooooOO
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 52 - 52: O00OoOoo00 % oooOOOOO
  try :
   II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if II1I == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oOO0oo = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO0oo )
    if 25 - 25: oOo0oooo00o / oOo0oooo00o % OoooooooOO - oO0o0ooO0 * iiIIIII1i1iI
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 23 - 23: i11iIiiIii
 else :
  if 100 - 100: iiIIIII1i1iI + O0 . OOooOOo + i1IIi - iI1Ii11111iIi + ii1II11I1ii1I
  if 'https://team.com' in url :
   if 65 - 65: II111iiii / ii11ii1ii
   url = url . replace ( 'https://team.com' , 'https://verystream.com' )
   if 42 - 42: i11iIiiIii . O0
  if 'https://mybox.com' in url :
   if 75 - 75: iiiI11 + iIii1I11I1II1
   url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
   if 19 - 19: OOooOOo + i11iIiiIii . O00OoOoo00 - oOo0oooo00o / I1i1i1ii + ii1II11I1ii1I
  if 'https://drive.com' in url :
   if 38 - 38: ii11ii1ii / iIii1I11I1II1 * iIii1I11I1II1 % oO0o0ooO0
   url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
   if 92 - 92: oOo0oooo00o / O0 * OOooOOo - oOo0oooo00o
  if 'https://vid.co' in url :
   if 99 - 99: i11iIiiIii % OoooooooOO
   url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
   if 56 - 56: O00OoOoo00 * iiiI11
  if 'https://limited.to' in url :
   if 98 - 98: oOo0oooo00o + O0 * iiiI11 + i11iIiiIii - O00o0o0000o0o - iIii1I11I1II1
   url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
   if 5 - 5: O00o0o0000o0o % ii11ii1ii % O00OoOoo00 % oooOOOOO
  import resolveurl
  if 17 - 17: I1i1i1ii + II111iiii + OoooooooOO / O00o0o0000o0o / O00OoOoo00
  O00ooOo = urlresolver . HostedMediaFile ( url )
  if 80 - 80: ii1II11I1ii1I % i1IIi / oOo0oooo00o
  if 56 - 56: i1IIi . i11iIiiIii
  if not O00ooOo :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no encontrado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 15 - 15: II111iiii * iiIIIII1i1iI % IIIII / i11iIiiIii - iiIIIII1i1iI + ii11ii1ii
  try :
   Iiii = O00ooOo . resolve ( )
   if not Iiii or not isinstance ( Iiii , basestring ) :
    try : i1i = Iiii . msg
    except : i1i = url
    raise Exception ( i1i )
  except Exception as iIi1 :
   try : i1i = str ( iIi1 )
   except : i1i = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace borrado, o no encontrado. Prueba a reiniciar el router o poner una VPN.[/COLOR]  ,5000)" )
   return False
   if 9 - 9: oOo0oooo00o - iiIIIII1i1iI + O0 / IIIII % i1IIi
   if 97 - 97: ii1II11I1ii1I * oooOOOOO
   if 78 - 78: oOo0oooo00o . O00o0o0000o0o + iiIIIII1i1iI * IIIII - i1IIi
   II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if II1I == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
    if 27 - 27: I1i1i1ii % i1IIi . ii11ii1ii % iiiI11
    if '[Realstream]' or '[Mybox]' in name :
     IIII = IiII1IiiIiI1 . getSetting ( 'restante' )
    elif IIII == 'true' :
     O00oOooo00o0o = xbmcgui . Dialog ( )
     oOoOoO000OO = O00oOooo00o0o . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 10 - 10: O00OoOoo00 / OoooooooOO
  oOO0oo = xbmcgui . ListItem ( path = Iiii )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO0oo )
  if 50 - 50: i11iIiiIii - OoooooooOO . iiIIIII1i1iI + O0 . i1IIi
 return
 if 91 - 91: ii1II11I1ii1I . IIIII % ii11ii1ii - IIIII . iiIIIII1i1iI % i11iIiiIii
def iIi ( name , url ) :
 if 97 - 97: oOo0oooo00o . oOo0oooo00o + iI1Ii11111iIi / oO0ooO - OOooOOo . OoooooooOO
 if 6 - 6: iIii1I11I1II1 - iIii1I11I1II1 % ii1II11I1ii1I / iIii1I11I1II1 * iiiI11
 if '[Youtube]' in name :
  if 3 - 3: O00o0o0000o0o . O00OoOoo00 / ii11ii1ii
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 89 - 89: OoooooooOO . iIii1I11I1II1 . ii11ii1ii * iIii1I11I1II1 - iiiI11
  try :
   II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if II1I == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    oOO0oo = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO0oo )
    if 92 - 92: OoooooooOO - oO0o0ooO0 - OoooooooOO % OOooOOo % OOooOOo % iIii1I11I1II1
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 92 - 92: IIIII * O0 % iiiI11 . iIii1I11I1II1
 else :
  if 66 - 66: oOo0oooo00o + I1i1i1ii
  o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
  oo00 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  o00 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  Oo0oO0ooo = IiII1IiiIiI1 . getSetting ( 'key_ext' )
  o0oOoO00o = i1 ( o00 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for i11 in oOOoo00O0O :
   if 48 - 48: oO0o0ooO0
   try :
    if 96 - 96: oooOOOOO . OoooooooOO
    if 39 - 39: O00o0o0000o0o + oO0ooO
    o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
    if 80 - 80: O00o0o0000o0o % oO0ooO / iI1Ii11111iIi
    if 54 - 54: ii11ii1ii % oO0ooO - O00o0o0000o0o - oOo0oooo00o
    if o0oO0 == i11 :
     if 71 - 71: oooOOOOO . i11iIiiIii
     if 56 - 56: O0 * IIIII + IIIII * iIii1I11I1II1 / oooOOOOO * iiiI11
     if 'https://team.com' in url :
      if 25 - 25: iIii1I11I1II1 . oOo0oooo00o * i11iIiiIii + ii11ii1ii * oOo0oooo00o
      url = url . replace ( 'https://team.com' , 'https://verystream.com' )
      if 67 - 67: IIIII
     if 'https://mybox.com' in url :
      if 88 - 88: ii11ii1ii
      url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
      if 8 - 8: oO0o0ooO0
      if 82 - 82: OoooooooOO
     if 'https://vidcloud.co/' in url :
      if 75 - 75: II111iiii % OOooOOo + O00o0o0000o0o % OoooooooOO / O00OoOoo00
      url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
      if 4 - 4: i11iIiiIii - O00o0o0000o0o % oO0o0ooO0 * iiiI11 % ii1II11I1ii1I
     if 'https://gounlimited.to' in url :
      if 71 - 71: oooOOOOO . oooOOOOO - iIii1I11I1II1
      url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
      if 22 - 22: OoooooooOO / oO0o0ooO0 % IIIII * iI1Ii11111iIi
     if 'https://drive.com' in url :
      if 32 - 32: OoooooooOO % iiIIIII1i1iI % iIii1I11I1II1 / O0
      url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
      if 61 - 61: II111iiii . O0 - I1i1i1ii - oO0o0ooO0 / i11iIiiIii - II111iiii
      if 98 - 98: I1i1i1ii - OOooOOo . i11iIiiIii * ii11ii1ii
     import resolveurl
     if 29 - 29: I1i1i1ii / oooOOOOO % oOo0oooo00o
     O00ooOo = urlresolver . HostedMediaFile ( url )
     if 10 - 10: iIii1I11I1II1 % OoooooooOO % oO0o0ooO0
     if not O00ooOo :
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
      return False
      if 39 - 39: II111iiii * iI1Ii11111iIi . O0 * oOo0oooo00o
     try :
      iIIi1I1ii = xbmcgui . DialogProgress ( )
      iIIi1I1ii . create ( 'Realstream:' , 'Iniciando ...' )
      iIIi1I1ii . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
      xbmc . sleep ( 1000 )
      if 89 - 89: I1i1i1ii - oooOOOOO . oOo0oooo00o - iiiI11 - OOooOOo
      Iiii = O00ooOo . resolve ( )
      if not Iiii or not isinstance ( Iiii , basestring ) :
       if 79 - 79: O00OoOoo00 + O00OoOoo00 + I1i1i1ii
       try : i1i = Iiii . msg
       except : i1i = url
       raise Exception ( i1i )
       if 39 - 39: O0 - OoooooooOO
     except Exception as iIi1 :
      try : i1i = str ( iIi1 )
      except : i1i = url
      iIIi1I1ii . update ( 45 , 'RESOLVEURL:' , 'Reiniciando ... ' )
      xbmc . sleep ( 1000 )
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no disponible.  ,3000)" )
      iIIi1I1ii . close ( )
      if 63 - 63: iIii1I11I1II1 % ii1II11I1ii1I * oooOOOOO
     iIIi1I1ii . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
     xbmc . sleep ( 500 )
     iIIi1I1ii . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
     xbmc . sleep ( 1000 )
     iIIi1I1ii . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
     iIIi1I1ii . close ( )
     II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
     oOO0oo = xbmcgui . ListItem ( path = Iiii )
     xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOO0oo )
     if 79 - 79: O0
     if 32 - 32: II111iiii . O0 + I1i1i1ii / iI1Ii11111iIi / O00OoOoo00 / O00o0o0000o0o
    else :
     if 15 - 15: oO0o0ooO0
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold]>El addon esta desactivado.[/COLOR]" )
     return False
     if 4 - 4: O00OoOoo00 + iIii1I11I1II1 * IIIII + ii11ii1ii * ii1II11I1ii1I % II111iiii
   except :
    pass
    if 88 - 88: iiIIIII1i1iI - i1IIi % i11iIiiIii % II111iiii * OoooooooOO
 return
 if 40 - 40: ii11ii1ii
def iI1Ii11 ( ) :
 if 93 - 93: OOooOOo / oooOOOOO / oOo0oooo00o + II111iiii + i11iIiiIii
 iiiII1III = [ ]
 I1iIiiIi11I1i = sys . argv [ 2 ]
 if len ( I1iIiiIi11I1i ) >= 2 :
  oO0oOOO0o0O0 = sys . argv [ 2 ]
  iIi1Ii1111i = oO0oOOO0o0O0 . replace ( '?' , '' )
  if ( oO0oOOO0o0O0 [ len ( oO0oOOO0o0O0 ) - 1 ] == '/' ) :
   oO0oOOO0o0O0 = oO0oOOO0o0O0 [ 0 : len ( oO0oOOO0o0O0 ) - 2 ]
  i1iooO0oO0o = iIi1Ii1111i . split ( '&' )
  iiiII1III = { }
  for IIiII11 in range ( len ( i1iooO0oO0o ) ) :
   oo0O00OOOOO = { }
   oo0O00OOOOO = i1iooO0oO0o [ IIiII11 ] . split ( '=' )
   if ( len ( oo0O00OOOOO ) ) == 2 :
    iiiII1III [ oo0O00OOOOO [ 0 ] ] = oo0O00OOOOO [ 1 ]
 return iiiII1III
 if 53 - 53: OoooooooOO . OoooooooOO + ii1II11I1ii1I - IIIII + O00o0o0000o0o
 if 44 - 44: iiiI11 - O00OoOoo00
def OOOi1iIIiiIiII ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  import urlresolver
  xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
  if 20 - 20: oooOOOOO . oO0ooO * IIIII
def OOii11Ii1IiiI1 ( ) :
 O00oOooo00o0o = xbmcgui . Dialog ( )
 list = (
 O00o0o ,
 OOoO0o0OOo0
 )
 if 51 - 51: IIIII % II111iiii - iiiI11 - i1IIi
 iIi11iI1i = O00oOooo00o0o . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=%s]Accede a themoviedb.com[/COLOR]' % oOooOOOoOo ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 46 - 46: i1IIi + II111iiii * i1IIi - I1i1i1ii
 if iIi11iI1i :
  if 79 - 79: II111iiii - iiIIIII1i1iI * oO0o0ooO0 - iI1Ii11111iIi . oO0o0ooO0
  if iIi11iI1i < 0 :
   return
  iiII1IIii1i1 = list [ iIi11iI1i - 2 ]
  return iiII1IIii1i1 ( )
 else :
  iiII1IIii1i1 = list [ iIi11iI1i ]
  return iiII1IIii1i1 ( )
 return
 if 38 - 38: IIIII * OoooooooOO
def iIi11III ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 16 - 16: OoooooooOO * i11iIiiIii . OoooooooOO - iIii1I11I1II1 * i1IIi
i1iI1IIi1I = iIi11III ( )
if 52 - 52: OoooooooOO / O00OoOoo00 % II111iiii
def O00o0o ( ) :
 if i1iI1IIi1I == 'android' :
  IiiI = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  IiiI = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 40 - 40: OOooOOo % oooOOOOO % O00OoOoo00 + oO0ooO
  if 75 - 75: iiIIIII1i1iI - oO0o0ooO0 + iiIIIII1i1iI + OoooooooOO . i11iIiiIii
def OOoO0o0OOo0 ( ) :
 if 52 - 52: IIIII / oooOOOOO - i11iIiiIii + OoooooooOO
 main ( )
 if 33 - 33: O0 + ii11ii1ii - iIii1I11I1II1 % i11iIiiIii / OOooOOo
 if 47 - 47: oO0o0ooO0 * iiIIIII1i1iI + iIii1I11I1II1 - iiIIIII1i1iI / O00OoOoo00
 if 86 - 86: O00OoOoo00
def Iii1I ( ) :
 O00oOooo00o0o = xbmcgui . Dialog ( )
 oooII111 = (
 I11iIi ,
 Ii1IIiII1I
 )
 if 85 - 85: ii11ii1ii . i11iIiiIii - i11iIiiIii . OOooOOo . oO0ooO % OoooooooOO
 iIi11iI1i = O00oOooo00o0o . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 20 - 20: iiiI11 + iiiI11 * II111iiii * iIii1I11I1II1 % O0 * OOooOOo
 if iIi11iI1i :
  if 62 - 62: OoooooooOO / iI1Ii11111iIi . O00OoOoo00 . O00OoOoo00 % oooOOOOO
  if iIi11iI1i < 0 :
   return
  iiII1IIii1i1 = oooII111 [ iIi11iI1i - 2 ]
  return iiII1IIii1i1 ( )
 else :
  iiII1IIii1i1 = oooII111 [ iIi11iI1i ]
  return iiII1IIii1i1 ( )
 return
 if 42 - 42: ii1II11I1ii1I . O00o0o0000o0o - oooOOOOO
def iIi11III ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 33 - 33: II111iiii / O0 / O00OoOoo00 - oOo0oooo00o - i1IIi
i1iI1IIi1I = iIi11III ( )
if 8 - 8: i11iIiiIii . IIIII / iIii1I11I1II1 / oO0o0ooO0 / O00OoOoo00 - I1i1i1ii
def I11iIi ( ) :
 if i1iI1IIi1I == 'android' :
  IiiI = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  IiiI = webbrowser . open ( 'https://olpair.com/' )
  if 32 - 32: ii1II11I1ii1I . i1IIi * ii11ii1ii
  if 98 - 98: I1i1i1ii - II111iiii / OOooOOo . iiIIIII1i1iI * O00OoOoo00 . oOo0oooo00o
def Ii1IIiII1I ( ) :
 if 25 - 25: i11iIiiIii / iI1Ii11111iIi - iiiI11 / oO0ooO . ii1II11I1ii1I . ii1II11I1ii1I
 main ( )
 if 6 - 6: iiIIIII1i1iI . oOo0oooo00o
 if 43 - 43: oO0o0ooO0 + ii1II11I1ii1I
def iI1iiiiiii ( name , url , id , trailer ) :
 O00oOooo00o0o = xbmcgui . Dialog ( )
 oooII111 = (
 Oo00oo ,
 oO0oO ,
 o0ooo ,
 OOii11Ii1IiiI1 ,
 IiI
 )
 if 34 - 34: O0 / O00o0o0000o0o
 iIi11iI1i = O00oOooo00o0o . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % oOooOOOoOo ,

 '[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % oOooOOOoOo ,

 '[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % oOooOOOoOo ,

 '[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % oOooOOOoOo ,

 '[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % oOooOOOoOo ] )
 if 86 - 86: oO0o0ooO0 * i1IIi + IIIII . oO0o0ooO0
 if iIi11iI1i :
  if 100 - 100: OoooooooOO - O0 . oOo0oooo00o / oOo0oooo00o + II111iiii * iI1Ii11111iIi
  if iIi11iI1i < 0 :
   return
  iiII1IIii1i1 = oooII111 [ iIi11iI1i - 5 ]
  return iiII1IIii1i1 ( )
 else :
  iiII1IIii1i1 = oooII111 [ iIi11iI1i ]
  return iiII1IIii1i1 ( )
 return
 if 37 - 37: ii11ii1ii
 if 72 - 72: O00OoOoo00 % oO0o0ooO0 * O00o0o0000o0o . i11iIiiIii % O00OoOoo00 * O00o0o0000o0o
 if 15 - 15: oOo0oooo00o / ii11ii1ii * oOo0oooo00o
def Oo00oo ( ) :
 if 20 - 20: oooOOOOO - O00o0o0000o0o * oO0ooO * ii1II11I1ii1I * O00o0o0000o0o / O00OoOoo00
 iIi ( i1Iii11I1i , Oo00o0OO0O00o )
 if 40 - 40: OOooOOo * ii1II11I1ii1I . OOooOOo
def oO0oO ( ) :
 if 62 - 62: oooOOOOO + II111iiii % oooOOOOO
 iI1IIiiIIIII ( i1Iii11I1i , O0Oooo )
 if 50 - 50: OoooooooOO + iiIIIII1i1iI * OOooOOo - I1i1i1ii / i11iIiiIii
def o0ooo ( ) :
 if 5 - 5: O0 - OOooOOo
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  Ii = id
  if 36 - 36: O00o0o0000o0o * I1i1i1ii
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % Ii )
  if 16 - 16: II111iiii
 if II1I == 'true' :
  if 100 - 100: O0 - i1IIi
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + i1Iii11I1i + "[/COLOR] ,5000)" )
  if 48 - 48: iiIIIII1i1iI % oooOOOOO + O0
def iI1iI ( ) :
 if 69 - 69: oO0o0ooO0 . OOooOOo
 OOii11Ii1IiiI1 ( )
 if 9 - 9: ii1II11I1ii1I - O00OoOoo00 + iIii1I11I1II1 + oO0ooO
def IiI ( ) :
 if 32 - 32: iI1Ii11111iIi % oO0ooO + i11iIiiIii + oooOOOOO - I1i1i1ii + iiIIIII1i1iI
 Iii1I111 ( )
def o0 ( name , url , mode , iconimage , fanart ) :
 if 31 - 31: iIii1I11I1II1 - ii1II11I1ii1I
 oO00oOo0OOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 oOoOoO000OO = True
 ii1ooO = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 ii1ooO . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 ii1ooO . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  oO00oOo0OOO = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  oOoOoO000OO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO00oOo0OOO , listitem = ii1ooO , isFolder = True )
  return oOoOoO000OO
 oOoOoO000OO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO00oOo0OOO , listitem = ii1ooO , isFolder = True )
 return oOoOoO000OO
 if 57 - 57: ii11ii1ii % oO0ooO
def OOOooo0OooOoO ( name , url , mode , iconimage , fanart , description ) :
 if 1 - 1: iI1Ii11111iIi * O0 . iiIIIII1i1iI % O0 + II111iiii
 oO00oOo0OOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 oOoOoO000OO = True
 ii1ooO = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 ii1ooO . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 ii1ooO . setProperty ( 'fanart_image' , fanart )
 oOoOoO000OO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO00oOo0OOO , listitem = ii1ooO , isFolder = True )
 return oOoOoO000OO
 if 49 - 49: oOo0oooo00o . O00o0o0000o0o
def II1 ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 74 - 74: i1IIi
 ii111iI1iIi1 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 15 - 15: i1IIi + O00OoOoo00 % OOooOOo / i11iIiiIii * iI1Ii11111iIi
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 oOiI1I = [ ]
 if 6 - 6: oO0ooO
 oOiI1I . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 oO00oOo0OOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 ii1ooO = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 ii1ooO . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 ii1ooO . setProperty ( 'fanart_image' , fanart )
 ii1ooO . setProperty ( 'IsPlayable' , 'true' )
 if 99 - 99: ii1II11I1ii1I * O00o0o0000o0o % iiIIIII1i1iI * iiIIIII1i1iI + OoooooooOO
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  oOiI1I . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 82 - 82: oOo0oooo00o / iI1Ii11111iIi - O00o0o0000o0o / oooOOOOO
  ii1ooO . addContextMenuItems ( oOiI1I , replaceItems = True )
 oOoOoO000OO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO00oOo0OOO , listitem = ii1ooO )
 return oOoOoO000OO
 if 50 - 50: O00o0o0000o0o + oO0ooO . i11iIiiIii + oO0o0ooO0 + i11iIiiIii
 if 31 - 31: iiIIIII1i1iI * iiiI11 . iI1Ii11111iIi * oOo0oooo00o
def IIIii11i1I ( name , url , mode , iconimage , fanart , id , trailer , description ) :
 if 28 - 28: O00OoOoo00 + OOooOOo - ii11ii1ii % O00o0o0000o0o . oOo0oooo00o + OOooOOo
 ii111iI1iIi1 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 72 - 72: I1i1i1ii / ii11ii1ii / iiIIIII1i1iI * iI1Ii11111iIi + O00o0o0000o0o
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 oOiI1I = [ ]
 if 58 - 58: ii1II11I1ii1I % OOooOOo . OOooOOo * oO0ooO - O00OoOoo00 . OoooooooOO
 oOiI1I . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 oO00oOo0OOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 ii1ooO = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 ii1ooO . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 ii1ooO . setProperty ( 'fanart_image' , fanart )
 ii1ooO . setProperty ( 'IsPlayable' , 'true' )
 if 10 - 10: iiiI11
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  oOiI1I . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 48 - 48: IIIII * i1IIi % OoooooooOO * I1i1i1ii * oO0ooO
  ii1ooO . addContextMenuItems ( oOiI1I , replaceItems = True )
 oOoOoO000OO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO00oOo0OOO , listitem = ii1ooO )
 return oOoOoO000OO
 if 7 - 7: IIIII . I1i1i1ii . IIIII - iiiI11
def Ooo000O00 ( name , url , mode , iconimage , fanart ) :
 if 33 - 33: oooOOOOO + OoooooooOO - oO0ooO / i1IIi / OoooooooOO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 82 - 82: oO0o0ooO0 / O00o0o0000o0o - IIIII / ii11ii1ii * oO0ooO
 oO00oOo0OOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 ii1ooO = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 ii1ooO . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 ii1ooO . setProperty ( 'fanart_image' , fanart )
 ii1ooO . setProperty ( 'IsPlayable' , 'true' )
 oOoOoO000OO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO00oOo0OOO , listitem = ii1ooO )
 return oOoOoO000OO
 if 55 - 55: OoooooooOO
def OO0OOOOOo ( name , url , mode ) :
 if 7 - 7: O0 + I1i1i1ii . II111iiii
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 12 - 12: OOooOOo - i1IIi
 oO00oOo0OOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 ii1ooO = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = ii1Io0OOoOoO00 )
 ii1ooO . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 ii1ooO . setProperty ( 'fanart_image' , IiI1i11iii1 )
 ii1ooO . setProperty ( 'IsPlayable' , 'true' )
 oOoOoO000OO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO00oOo0OOO , listitem = ii1ooO )
 return oOoOoO000OO
 if 95 - 95: oOo0oooo00o / O00OoOoo00 . O0 * O00OoOoo00 - ii1II11I1ii1I * ii11ii1ii
def II1iiI1iI ( name , url , mode , iconimage ) :
 oO00oOo0OOO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 oOoOoO000OO = True
 ii1ooO = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 oOoOoO000OO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO00oOo0OOO , listitem = ii1ooO , isFolder = True )
 return oOoOoO000OO
 if 74 - 74: O00OoOoo00 - O0 / iiiI11 * I1i1i1ii % oooOOOOO . iiiI11
def OOoo ( ) :
 if 51 - 51: OOooOOo + oooOOOOO * O0 . I1i1i1ii
 if 82 - 82: O00o0o0000o0o * oO0o0ooO0 % I1i1i1ii . O00o0o0000o0o
 if 43 - 43: oO0ooO . oooOOOOO * ii11ii1ii
 OOOO0O00o = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 OOOO0O00o . doModal ( )
 if ( OOOO0O00o . isConfirmed ( ) ) :
  if 20 - 20: i1IIi . i1IIi - oOo0oooo00o
  i1II = urllib . quote_plus ( OOOO0O00o . getText ( ) ) . replace ( '+' , ' ' )
  if 89 - 89: oooOOOOO - oOo0oooo00o . O0 % OoooooooOO . i11iIiiIii
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 35 - 35: II111iiii / iI1Ii11111iIi - O0 . II111iiii
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % i1II )
    if 55 - 55: ii11ii1ii % i1IIi * oOo0oooo00o
    if II1I == 'true' :
     if 95 - 95: O00o0o0000o0o / II111iiii - ii1II11I1ii1I % iiiI11 . oOo0oooo00o
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + i1Iii11I1i + "[/COLOR] ,10000)" )
     if 63 - 63: iIii1I11I1II1 / oooOOOOO
   except :
    if 24 - 24: ii11ii1ii / iIii1I11I1II1 % O00o0o0000o0o * iI1Ii11111iIi - iIii1I11I1II1
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 50 - 50: II111iiii
    if 39 - 39: II111iiii . iI1Ii11111iIi - ii11ii1ii * i1IIi . OoooooooOO
    if 44 - 44: OOooOOo
oO0oOOO0o0O0 = iI1Ii11 ( )
Oo00o0OO0O00o = None
i1Iii11I1i = None
oOoOOOo = None
ii1Io0OOoOoO00 = None
id = None
O0Oooo = None
if 55 - 55: iiIIIII1i1iI . iiiI11 * iiiI11
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 82 - 82: OOooOOo % oO0ooO % oOo0oooo00o + oOo0oooo00o
try :
 Oo00o0OO0O00o = urllib . unquote_plus ( oO0oOOO0o0O0 [ "url" ] )
except :
 pass
try :
 i1Iii11I1i = urllib . unquote_plus ( oO0oOOO0o0O0 [ "name" ] )
except :
 pass
try :
 oOoOOOo = int ( oO0oOOO0o0O0 [ "mode" ] )
except :
 pass
try :
 ii1Io0OOoOoO00 = urllib . unquote_plus ( oO0oOOO0o0O0 [ "iconimage" ] )
except :
 pass
try :
 id = int ( oO0oOOO0o0O0 [ "id" ] )
except :
 pass
try :
 O0Oooo = urllib . unquote_plus ( oO0oOOO0o0O0 [ "trailer" ] )
except :
 pass
 if 6 - 6: ii11ii1ii
 if 73 - 73: iiiI11 * oO0o0ooO0 + ii1II11I1ii1I - ii11ii1ii . oOo0oooo00o
print "Mode: " + str ( oOoOOOo )
print "URL: " + str ( Oo00o0OO0O00o )
print "Name: " + str ( i1Iii11I1i )
print "iconimage: " + str ( ii1Io0OOoOoO00 )
print "id: " + str ( id )
print "trailer: " + str ( O0Oooo )
if 93 - 93: i11iIiiIii
if oOoOOOo == None or Oo00o0OO0O00o == None or len ( Oo00o0OO0O00o ) < 1 :
 if i1Ii == ii111iI1iIi1 :
  if 80 - 80: i1IIi . OOooOOo - iiIIIII1i1iI + O00o0o0000o0o + IIIII % iiIIIII1i1iI
  if 13 - 13: II111iiii / iI1Ii11111iIi / iI1Ii11111iIi + oooOOOOO
  iIi1Ii1i1iI ( )
  if 49 - 49: O0 / II111iiii * OOooOOo - OoooooooOO . II111iiii % O00OoOoo00
  o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
  oo00 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  o00 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  Oo0oO0ooo = IiII1IiiIiI1 . getSetting ( 'key_ext' )
  o0oOoO00o = i1 ( o00 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for i11 in oOOoo00O0O :
   try :
    if 13 - 13: iiIIIII1i1iI . iIii1I11I1II1 . O00o0o0000o0o . O00OoOoo00
    if 58 - 58: oOo0oooo00o
    o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
    if 7 - 7: II111iiii / O00OoOoo00 % oOo0oooo00o + OOooOOo - O0
    if 45 - 45: OOooOOo / IIIII + iiIIIII1i1iI + O00OoOoo00
    if o0oO0 == i11 :
     if 15 - 15: OOooOOo % oO0ooO
     Iii1I111 ( )
     if 66 - 66: iiIIIII1i1iI * i11iIiiIii . iiiI11
    else :
     if 92 - 92: iiIIIII1i1iI
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Estamos de Mantenimiento, Disculpen las molestias. Volveremos pronto! [/COLOR] [COLOR gold]>El addon esta desactivado temporalmente.[/COLOR]" )
     if 81 - 81: ii1II11I1ii1I % OOooOOo - IIIII / i11iIiiIii
     if 73 - 73: O0 * iiiI11 . i1IIi
   except :
    pass
    if 51 - 51: oO0ooO - IIIII % O0 - iI1Ii11111iIi
 else :
  xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red][B]Error, de inicio. ¿Tienes Instalado Realstream?[/B][/COLOR]" )
  if 53 - 53: IIIII / i1IIi / i1IIi
  if 77 - 77: oOo0oooo00o + i1IIi . oOo0oooo00o
  if 89 - 89: ii1II11I1ii1I + O00o0o0000o0o * iiIIIII1i1iI
elif oOoOOOo == 1 :
 iI1iiiiiii ( i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo )
elif oOoOOOo == 2 :
 OooO00oOOo0Oo ( )
elif oOoOOOo == 3 :
 oOooo0Oo ( )
elif oOoOOOo == 4 :
 I1iI1I1ii1 ( i1Iii11I1i , Oo00o0OO0O00o )
elif oOoOOOo == 5 :
 I1I1iII1i ( )
elif oOoOOOo == 6 :
 I1III111i ( )
elif oOoOOOo == 7 :
 iI1 ( )
elif oOoOOOo == 8 :
 oOo000O ( )
elif oOoOOOo == 9 :
 I11Oo0oO00 ( )
elif oOoOOOo == 10 :
 Oo00OO0OO ( )
elif oOoOOOo == 11 :
 ooo0O0oOoooO0 ( )
elif oOoOOOo == 12 :
 O00oo ( )
elif oOoOOOo == 13 :
 o0Ii1 ( )
elif oOoOOOo == 14 :
 IiiIIi1 ( )
elif oOoOOOo == 15 :
 iiiiI1IiI1I1 ( )
elif oOoOOOo == 16 :
 i111i1iIi1 ( )
elif oOoOOOo == 17 :
 ooo000oOO ( )
elif oOoOOOo == 18 :
 I1Iii1Ii1i1 ( )
elif oOoOOOo == 19 :
 ooOoo0OoOO ( )
elif oOoOOOo == 20 :
 ooooO0 ( )
elif oOoOOOo == 21 :
 OOOOo000o00OO ( )
elif oOoOOOo == 22 :
 i1I1Ii11i ( )
elif oOoOOOo == 23 :
 Oo0 ( )
elif oOoOOOo == 24 :
 ii1IIiI1IIi ( )
elif oOoOOOo == 25 :
 Oo0o00ooOOOoOo ( )
elif oOoOOOo == 26 :
 III11iiii11i1 ( )
elif oOoOOOo == 28 :
 I1Ii1 ( i1Iii11I1i , Oo00o0OO0O00o )
elif oOoOOOo == 29 :
 i1III ( )
elif oOoOOOo == 30 :
 i11II ( )
elif oOoOOOo == 31 :
 IIIiiiI ( )
elif oOoOOOo == 98 :
 busqueda_global ( )
elif oOoOOOo == 97 :
 Iii1I ( )
elif oOoOOOo == 99 :
 OOooo00 ( )
elif oOoOOOo == 100 :
 menu_player ( i1Iii11I1i , Oo00o0OO0O00o )
elif oOoOOOo == 111 :
 o0OOOo ( )
elif oOoOOOo == 115 :
 iI1IIiiIIIII ( Oo00o0OO0O00o )
elif oOoOOOo == 116 :
 iiI1 ( )
elif oOoOOOo == 117 :
 oOoOOo0oo0 ( )
elif oOoOOOo == 119 :
 OooOOOOoO00OoOO ( )
elif oOoOOOo == 120 :
 OOO00O0oOOo ( )
elif oOoOOOo == 121 :
 O0oOo00o0 ( )
elif oOoOOOo == 125 :
 Oo0oOO ( )
elif oOoOOOo == 112 :
 list_proxy ( )
elif oOoOOOo == 127 :
 OOoo ( )
elif oOoOOOo == 128 :
 TESTLINKS ( )
elif oOoOOOo == 130 :
 iIi ( i1Iii11I1i , Oo00o0OO0O00o )
elif oOoOOOo == 140 :
 ii1iii1I1I ( )
elif oOoOOOo == 141 :
 iiiI1iI1 ( )
elif oOoOOOo == 142 :
 Oo00OOo00O ( )
elif oOoOOOo == 143 :
 Ii11iI ( i1Iii11I1i , Oo00o0OO0O00o )
elif oOoOOOo == 144 :
 I1Ii1 ( i1Iii11I1i , Oo00o0OO0O00o )
elif oOoOOOo == 145 :
 oo0OOo0O ( )
elif oOoOOOo == 150 :
 iIII1i1i ( )
elif oOoOOOo == 151 :
 oo0o0000Oo0 ( )
elif oOoOOOo == 152 :
 ii111i ( )
 if 45 - 45: IIIII - ii1II11I1ii1I . I1i1i1ii
xbmcplugin . endOfDirectory ( o0OoOoOO00 ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
