# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 0.8.1
#
############################################
# Dependencias 
# Script ExtendedInfo
# Script Urlresolver de TVAddons
# Script ResolveURL Por Jsergio.
#
############################################
#
# Corregido imcompatibilidad con Servidor Team
# Agregados nuevos iconos, ahora se puede el aspecto desde ajustes del addon.
#
############################################
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import urlresolver
import cookielib , base64
import requests
import plugintools
import config
oo000 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
ii = oo000 . getAddonInfo ( 'version' )
oOOo = int ( sys . argv [ 1 ] )
O0 = 'gruponetai/'
o0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
iI11I1II1I1I = o0O . getAddonInfo ( 'profile' )
oooo = o0O . getAddonInfo ( 'path' )
iIIii1IIi = oo000 . getSetting ( 'iconos' )
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if iIIii1IIi == 'true' :
 if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
 O0oOO0o0 = xbmc . translatePath ( os . path . join ( oooo , 'fanart.png' ) )
 i1ii1iIII = xbmc . translatePath ( os . path . join ( oooo , 'icon.png' ) )
 Oo0oO0oo0oO00 = xbmc . translatePath ( os . path . join ( oooo , 'extended_info.png' ) )
 i111I = xbmc . translatePath ( os . path . join ( oooo , 'buscar.png' ) )
 II1Ii1iI1i = xbmc . translatePath ( os . path . join ( oooo , 'pair.png' ) )
 iiI1iIiI = xbmc . translatePath ( os . path . join ( oooo , 'theMovieDB.png' ) )
 OOo = xbmc . translatePath ( os . path . join ( oooo , 'novedades.png' ) )
 Ii1IIii11 = xbmc . translatePath ( os . path . join ( oooo , 'estrenos.png' ) )
 Oooo0000 = xbmc . translatePath ( os . path . join ( oooo , 'recomendadas.png' ) )
 i11 = xbmc . translatePath ( os . path . join ( oooo , 'accion.png' ) )
 I11 = xbmc . translatePath ( os . path . join ( oooo , 'animacion.png' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( oooo , 'aventuras.png' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( oooo , 'belico.png' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( oooo , 'ciencia-ficcion.png' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( oooo , 'comedia.png' ) )
 oO = xbmc . translatePath ( os . path . join ( oooo , 'crimen.png' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( oooo , 'drama.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( oooo , 'familiar.png' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( oooo , 'fantasia.png' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( oooo , 'historia.png' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( oooo , 'marvel.png' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( oooo , 'misterio.png' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( oooo , 'musical.png' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( oooo , 'romance.png' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( oooo , 'spain.png' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( oooo , 'suspense.png' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( oooo , 'terror.png' ) )
 II = xbmc . translatePath ( os . path . join ( oooo , 'thriller.png' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( oooo , 'western.png' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( oooo , 'sagas_cine.png' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( oooo , '4k.png' ) )
 OO0o = xbmc . translatePath ( os . path . join ( oooo , 'torrent.png' ) )
 Ooo = xbmc . translatePath ( os . path . join ( oooo , 'buscar-serie.jpg' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( oooo , 'series-todas.jpg' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( oooo , 'favorites.png' ) )
else :
 if 85 - 85: O0O00o0OOO0 . O0o / o0 + I11ii1 / I1IiiI
 if 73 - 73: I1Ii111 % I11i - o00O0oo
 iIIii1IIi = oo000 . getSetting ( 'iconos' )
 O0oOO0o0 = xbmc . translatePath ( os . path . join ( oooo , 'fanart.jpg' ) )
 i1ii1iIII = xbmc . translatePath ( os . path . join ( oooo , 'icon.png' ) )
 Oo0oO0oo0oO00 = xbmc . translatePath ( os . path . join ( oooo , 'extended_info.png' ) )
 i111I = xbmc . translatePath ( os . path . join ( oooo , 'buscar.png' ) )
 II1Ii1iI1i = xbmc . translatePath ( os . path . join ( oooo , 'pair.png' ) )
 iiI1iIiI = xbmc . translatePath ( os . path . join ( oooo , 'theMovieDB.jpg' ) )
 OOo = xbmc . translatePath ( os . path . join ( oooo , 'novedades.jpg' ) )
 Ii1IIii11 = xbmc . translatePath ( os . path . join ( oooo , 'encines.jpg' ) )
 Oooo0000 = xbmc . translatePath ( os . path . join ( oooo , 'recomendadas.jpg' ) )
 i11 = xbmc . translatePath ( os . path . join ( oooo , 'accion.jpg' ) )
 I11 = xbmc . translatePath ( os . path . join ( oooo , 'animacion.jpg' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( oooo , 'aventuras.jpg' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( oooo , 'belico.jpg' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( oooo , 'ciencia-ficcion.jpg' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( oooo , 'comedia.jpg' ) )
 oO = xbmc . translatePath ( os . path . join ( oooo , 'crimen.jpg' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( oooo , 'drama.jpg' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( oooo , 'familiar.jpg' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( oooo , 'fantasia.jpg' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( oooo , 'historia.jpg' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( oooo , 'superheroes.jpg' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( oooo , 'misterio.jpg' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( oooo , 'musical.jpg' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( oooo , 'romance.jpg' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( oooo , 'spain.jpg' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( oooo , 'suspense.jpg' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( oooo , 'terror.jpg' ) )
 II = xbmc . translatePath ( os . path . join ( oooo , 'thriller.jpg' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( oooo , 'western.jpg' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( oooo , 'sagas_cine.jpg' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( oooo , '4k.jpg' ) )
 OO0o = xbmc . translatePath ( os . path . join ( oooo , 'torrent.jpg' ) )
 Ooo = xbmc . translatePath ( os . path . join ( oooo , 'buscar-serie.jpg' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( oooo , 'series-todas.jpg' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( oooo , 'favoritos.png' ) )
 if 10 - 10: I1ii11iIi11i % iII111i
 if 48 - 48: ooOoO0o + ooOoO0o / o0oOOo0O0Ooo / Oo0Ooo
i1iiI11I = xbmc . translatePath ( os . path . join ( oooo , 'peliculas.png' ) )
iiii = xbmc . translatePath ( os . path . join ( oooo , 'series.png' ) )
oO0o0O0OOOoo0 = xbmc . translatePath ( os . path . join ( oooo , 'ajustes.png' ) )
IiIiiI = xbmc . translatePath ( os . path . join ( oooo , 'videoteca.png' ) )
I1I = xbmc . translatePath ( os . path . join ( oooo , 'favorites.png' ) )
oOO00oOO = xbmc . translatePath ( os . path . join ( oooo , 'resolver.png' ) )
OoOo = xbmc . translatePath ( os . path . join ( oooo , 'test.png' ) )
iI = xbmc . translatePath ( os . path . join ( oooo , 'video-tutoriales.png' ) )
o00O = xbmc . translatePath ( os . path . join ( oooo , 'proxy.png' ) )
if 69 - 69: IiII % o0 - Ii1I + o0 - I1IiiI % OoO0O00
Iii111II = oo000 . getSetting ( 'mostrar_cat' )
iiii11I = oo000 . getSetting ( 'videos' )
Ooo0OO0oOO = oo000 . getSetting ( 'activar' )
ii11i1 = oo000 . getSetting ( 'favcopy' )
IIIii1II1II = oo000 . getSetting ( 'anticopia' )
i1I1iI = oo000 . getSetting ( 'licencia_addon' )
oo0OooOOo0 = oo000 . getSetting ( 'notificar' )
o0OO00oO = oo000 . getSetting ( 'mostrar_bus' )
I11i1I1I = oo000 . getSetting ( 'restante' )
oO0Oo = oo000 . getSetting ( 'selecton' )
oOOoo0Oo = oo000 . getSetting ( 'aviso' )
o00OO00OoO = oo000 . getSetting ( 'RealStream_Settings' )
OOOO0OOoO0O0 = oo000 . getSetting ( 'Resolver_Settings' )
I11i1I1I = oo000 . getSetting ( 'restante' )
O0Oo000ooO00 = oo000 . getSetting ( 'fav' )
oO0 = oo000 . getSetting ( 'Fontcolor' )
Ii1iIiII1ii1 = oo000 . getSetting ( 'MenuColor' )
ooOooo000oOO = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
Oo0oOOo = 'bienvenida'
Oo0OoO00oOO0o = 'bienvenida'
copyright = oo000 . getSetting ( 'copyright' )
OOO00O = 'cGx1Z2luLnZpZGVvLg==' . decode ( 'base64' ) + copyright
OOoOO0oo0ooO = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
O0o0O00Oo0o0 = oo000 . getSetting ( 'Forceupdate' )
if O0o0O00Oo0o0 == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
O00O0oOO00O00 = '.txt'
if 11 - 11: O0o . iII111i
o0oo0oOo = 'aHR0cDovL2JpdC5seS8yU1FOSnlP' . decode ( 'base64' )
o000O0o = ooOooo000oOO + Oo0oOOo + O00O0oOO00O00
iI1iII1 = 'http://www.youtube.com'
oO0OOoo0OO = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
O0ii1ii1ii = '.xsl.pt'
oooooOoo0ooo = 'L21hc3Rlci8=' . decode ( 'base64' )
I1I1IiI1 = oO0OOoo0OO + O0ii1ii1ii
III1iII1I1ii = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*texto3=[\'"](.*?)[\'"]\s*'
oOOo0 = 'tvg-logo=[\'"](.*?)[\'"]'
if 54 - 54: I1IiiI - O0o % I1Ii111
OOoO = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)'
iII = '(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)'
ii1ii11IIIiiI = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
O00OOOoOoo0O = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
O000OOo00oo = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
oo0OOo = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
ooOOO00Ooo = '#(.+?),(.+)\s*(.+)'
IiIIIi1iIi = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
if 68 - 68: II111iiii % iII111i + II111iiii
iii = 'source src=[\'"](.*?)[\'"]\s*title=[\'"](.*?)[\'"]'
II1I = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
O0i1II1Iiii1I11 = '[\'"](.*?)[\'"]'
IIII = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
iiIiI = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( 'base64' )
o00oooO0Oo = iiIiI + O0
o0O0OOO0Ooo = '[\'"](.*?)[\'"]'
iiIiII1 = 'UmVhbHN0cmVhbQ==' . decode ( 'base64' )
OOO00O0O = 'video=[\'"](.*?)[\'"]'
iiioOooOOOoOo = '0110nhu' . replace ( '0110nhu' , 'nhu' )
i1Iii1i1I = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( 'base64' ) + iiioOooOOOoOo
OOoO00 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
IiI111111IIII = '0110R0N' . replace ( '0110R0N' , 'R0N' )
i1Ii = 'aHR0cDovL2JpdC5seS8yWEIx' . decode ( 'base64' ) + IiI111111IIII
ii111iI1iIi1 = '0110pEJ' . replace ( '0110pEJ' , 'pEJ' )
OOO = 'aHR0cDovL2JpdC5seS8yd1Nh' . decode ( 'base64' ) + ii111iI1iIi1
oo0OOo0 = 'ABBAOb5' . replace ( 'ABBAOb5' , 'Ob5' )
I11IiI = 'aHR0cDovL2JpdC5seS8yRVhV' . decode ( 'base64' ) + oo0OOo0
O0ooO0Oo00o = '0110jaw' . replace ( '0110jaw' , 'jaw' )
ooO0oOOooOo0 = 'aHR0cDovL2JpdC5seS8yd01M' . decode ( 'base64' ) + O0ooO0Oo00o
i1I1ii11i1Iii = '01109DI' . replace ( '01109DI' , '9DI' )
I1IiiiiI = 'aHR0cDovL2JpdC5seS8ySXgz' . decode ( 'base64' ) + i1I1ii11i1Iii
o0OIiII = '01103hs' . replace ( '01103hs' , '3hs' )
ii1iII1II = 'aHR0cDovL2JpdC5seS8zMW1U' . decode ( 'base64' ) + o0OIiII
Iii1I1I11iiI1 = '01107DW' . replace ( '01107DW' , '7DW' )
I1I1i1I = 'aHR0cDovL2JpdC5seS8yV1ln' . decode ( 'base64' ) + Iii1I1I11iiI1
ii1I = '0110mLl' . replace ( '0110mLl' , 'mLl' )
O0oO0 = 'aHR0cDovL2JpdC5seS8yS0cw' . decode ( 'base64' ) + ii1I
oO0O0OO0O = '01102Hj' . replace ( '01102Hj' , '2Hj' )
OO = 'aHR0cDovL2JpdC5seS8yWEJo' . decode ( 'base64' ) + oO0O0OO0O
OoOoO = '0110fXg' . replace ( '0110fXg' , 'fXg' )
Ii1I1i = 'aHR0cDovL2JpdC5seS8ySTVy' . decode ( 'base64' ) + OoOoO
OOI1iI1ii1II = '0110NMH' . replace ( '0110NMH' , 'NMH' )
O0O0OOOOoo = 'aHR0cDovL2JpdC5seS8yd0t6' . decode ( 'base64' ) + OOI1iI1ii1II
oOooO0 = '0110bwQ' . replace ( '0110bwQ' , 'bwQ' )
Ii1I1Ii = 'aHR0cDovL2JpdC5seS8yd01V' . decode ( 'base64' ) + oOooO0
OOoO0 = '0110xzG' . replace ( '0110xzG' , 'xzG' )
OO0Oooo0oOO0O = 'aHR0cDovL2JpdC5seS8yWHhz' . decode ( 'base64' ) + OOoO0
o00O0 = '0110x64' . replace ( '0110x64' , 'x64' )
oOO0O00Oo0O0o = 'aHR0cDovL2JpdC5seS8yRVlF' . decode ( 'base64' ) + o00O0
ii1 = '0110vUE' . replace ( '0110vUE' , 'vUE' )
I1iIIiiIIi1i = 'aHR0cDovL2JpdC5seS8yWmhW' . decode ( 'base64' ) + ii1
O0O0ooOOO = '01107ZL' . replace ( '01107ZL' , '7ZL' )
oOOo0O00o = 'aHR0cDovL2JpdC5seS8yWm4w' . decode ( 'base64' ) + O0O0ooOOO
iIiIi11 = '01106cf' . replace ( '01106cf' , '6cf' )
OOOiiiiI = 'aHR0cDovL2JpdC5seS8yRVlk' . decode ( 'base64' ) + iIiIi11
oooOo0OOOoo0 = '0110Jtp' . replace ( '0110Jtp' , 'Jtp' )
OOoOOO0O000 = 'aHR0cDovL2JpdC5seS8yV3Nq' . decode ( 'base64' ) + oooOo0OOOoo0
iiIiI1i1 = '0110a5b' . replace ( '0110a5b' , 'a5b' )
oO0O00oOOoooO = 'aHR0cDovL2JpdC5seS8yV3dj' . decode ( 'base64' ) + iiIiI1i1
IiIi11iI = '0110Q7u' . replace ( '0110Q7u' , 'Q7u' )
Oo0O00O000 = 'aHR0cDovL2JpdC5seS8yV3NL' . decode ( 'base64' ) + IiIi11iI
i11I1IiII1i1i = '0110rsq' . replace ( '0110rsq' , 'rsq' )
oo = 'aHR0cDovL2JpdC5seS8ySzhE' . decode ( 'base64' ) + i11I1IiII1i1i
I1111i = '0110DDR' . replace ( '0110DDR' , 'DDR' )
iIIii = 'aHR0cDovL2JpdC5seS8ySzd5' . decode ( 'base64' ) + I1111i
o00O0O = '0110feQ' . replace ( '0110feQ' , 'feQ' )
ii1iii1i = 'aHR0cDovL2JpdC5seS8yS0cz' . decode ( 'base64' ) + o00O0O
Iii1I1111ii = '0110MHY' . replace ( '0110MHY' , 'MHY' )
ooOoO00 = 'aHR0cDovL2JpdC5seS8ySXVo' . decode ( 'base64' ) + Iii1I1111ii
Ii1IIiI1i = '0110xdb' . replace ( '0110xdb' , 'xdb' )
o0O00Oo0 = 'aHR0cDovL2JpdC5seS8yWEJu' . decode ( 'base64' ) + Ii1IIiI1i
IiII111i1i11 = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( 'base64' )
OOO00O = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
i111iIi1i1II1 = '0110lxu' . replace ( '0110lxu' , 'lxu' )
oooO = 'aHR0cDovL2JpdC5seS8yV1Bj' . decode ( 'base64' ) + i111iIi1i1II1
i1I1i111Ii = '0110pzp' . replace ( '0110pzp' , 'pzp' )
ooo = 'aHR0cDovL2JpdC5seS8yVHpB' . decode ( 'base64' ) + i1I1i111Ii
i1i1iI1iiiI = '01105yt' . replace ( '01105yt' , '5yt' )
Ooo0oOooo0 = 'aHR0cDovL2JpdC5seS8yTVpp' . decode ( 'base64' ) + i1i1iI1iiiI
if 61 - 61: I11i - I1Ii111 - OoOoOO00
IiI1iIiIIIii = '1001DTs' . replace ( '1001DTs' , 'DTs' )
oOoO = 'aHR0cDovL2JpdC5seS8ySzhP' . decode ( 'base64' ) + IiI1iIiIIIii
if 81 - 81: I11i - I11i . O0O00o0OOO0
def o0OoOo00o0o ( ) :
 if 41 - 41: I11ii1 % OOooOOo - oO0o * o0 * oO0o
 if 69 - 69: I1Ii111 - OoO0O00 + Ii1I - ooOoO0o
 try :
  if 23 - 23: II111iiii
  II1iIi11 = I11iiii ( i1Ii )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for IiI1iiiIii in O0i1iI :
   try :
    if 7 - 7: o0 * OOooOOo - I11ii1 + I1Ii111 * I1ii11iIi11i % OOooOOo
    OOO = IiI1iiiIii
    if 15 - 15: I11i % I1ii11iIi11i * ooOoO0o
    O0OoooO0 = xbmc . Keyboard ( '' , 'Busqueda por titulo,actor, director, año, servidor:' )
    O0OoooO0 . doModal ( )
    if ( O0OoooO0 . isConfirmed ( ) ) :
     if 85 - 85: ooOoO0o
     iI1i11II1i = urllib . quote_plus ( O0OoooO0 . getText ( ) ) . replace ( '+' , ' ' )
     o0o0OoOo0O0OO = I11iiii ( OOO )
     O0i1iI = re . compile ( OOoO ) . findall ( o0o0OoOo0O0OO )
     if 36 - 36: I11i - I1IiiI
     for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
      if re . search ( iI1i11II1i , III1 ( iII1i11IIi1i . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
       if 100 - 100: O0O00o0OOO0 % I1Ii111
   except :
    pass
 except :
  pass
def OOOiII1 ( ) :
 if 57 - 57: Ii1I . OoOoOO00 . O0o * II111iiii + o0 . O0o
 if 57 - 57: o0
 I11Iiii1I = I11iiii ( IiII111i1i11 )
 O0i1iI = re . compile ( O0i1II1Iiii1I11 ) . findall ( I11Iiii1I )
 for oo00O0oO0O0 in O0i1iI :
  try :
   if 96 - 96: II111iiii % I11ii1 / I11i
   import xbmc
   import xbmcaddon
   if 36 - 36: I1Ii111 + I1IiiI - o00O0oo - I1IiiI % ooOoO0o . IiII
   __addon__ = xbmcaddon . Addon ( )
   __addonname__ = __addon__ . getAddonInfo ( 'name' )
   __icon__ = __addon__ . getAddonInfo ( 'icon' )
   if 74 - 74: II111iiii . I1ii11iIi11i
   ii = oo000 . getAddonInfo ( 'version' )
   if 36 - 36: OoO0O00 . OOooOOo
   oOIIiIi = "[COLOR gold]Version instalada: " + ii + " [/COLOR]" "[COLOR lime]Ultima Version: " + oo00O0oO0O0 + "  [/COLOR]"
   OOoOooOoOOOoo = 3000
   if 25 - 25: OoO0O00 - I1ii11iIi11i . I1ii11iIi11i * IiII
   xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , oOIIiIi , OOoOooOoOOOoo , __icon__ ) )
   if 81 - 81: O0O00o0OOO0 + O0o
   if 98 - 98: I1ii11iIi11i
  except :
   pass
   if 95 - 95: I11ii1 / I11ii1
   if 30 - 30: iII111i + oO0o / oO0o % iII111i . iII111i
def O0O0Oo00 ( ) :
 if 80 - 80: IiII + I1Ii111 / ooOoO0o
 oOOoo0Oo = oo000 . getSetting ( 'aviso' )
 if oOOoo0Oo == 'true' :
  II1iIi11 = I11iiii ( o000O0o )
  O0i1iI = re . compile ( III1iII1I1ii ) . findall ( II1iIi11 )
  for oOOO00O0O0OOo , OOo00O , OooOOOO in O0i1iI :
   try :
    if 45 - 45: iII111i % I1ii11iIi11i - II111iiii
    if 11 - 11: Oo0Ooo * Oo0Ooo * I1ii11iIi11i
    iII1ii1 = oOOO00O0O0OOo
    I1i1iiiI1 = OOo00O
    iIIi = OooOOOO
    if 62 - 62: oO0o - ooOoO0o
    if 21 - 21: I1IiiI % O0o . I1ii11iIi11i / o0oOOo0O0Ooo + O0o
    oOIIiIi = "[B]" + iII1ii1 + "[/B]"
    OOOO0O00o = "" + I1i1iiiI1 + ""
    oooIIiIiI1I = "" + iIIi + ""
    if 100 - 100: Oo0Ooo + I11i / oO0o . II111iiii
    xbmcgui . Dialog ( ) . ok ( "Real Stream" , oOIIiIi , OOOO0O00o , oooIIiIiI1I )
    if 14 - 14: Ii1I * I1Ii111 + O0O00o0OOO0 + I1IiiI + II111iiii
   except :
    pass
    if 77 - 77: Ii1I / OoO0O00
    if 46 - 46: Ii1I % Oo0Ooo . O0O00o0OOO0 % O0O00o0OOO0 + II111iiii
 if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
  if 72 - 72: Oo0Ooo * o00O0oo % I11ii1 / OOooOOo
  if 35 - 35: I11ii1 + OoOoOO00 % iII111i % ooOoO0o + IiII
  if 17 - 17: OoOoOO00
def III1 ( s ) :
 if 21 - 21: oO0o
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 29 - 29: ooOoO0o / o0oOOo0O0Ooo / I11ii1 * I1Ii111
def I111i1i1111 ( file ) :
 if 49 - 49: OOooOOo / IiII + I1IiiI * Ii1I
 try :
  I1ii11 = open ( file , 'r' )
  II1iIi11 = I1ii11 . read ( )
  I1ii11 . close ( )
  return II1iIi11
 except :
  pass
  if 74 - 74: oO0o - Ii1I . OoOoOO00
def I11iiii ( url ) :
 if 43 - 43: O0O00o0OOO0 / I1ii11iIi11i
 try :
  OO0oo0O = urllib2 . Request ( url )
  OO0oo0O . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  Ii1i1iI = urllib2 . urlopen ( OO0oo0O )
  IIiI1 = Ii1i1iI . read ( )
  Ii1i1iI . close ( )
  return IIiI1
 except urllib2 . URLError , i1iI1 :
  print 'We failed to open "%s".' % url
  if hasattr ( i1iI1 , 'code' ) :
   print 'We failed with error code - %s.' % i1iI1 . code
  if hasattr ( i1iI1 , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , i1iI1 . reason
   if 1 - 1: OoOoOO00 . II111iiii % I1Ii111
def OooO0oo ( url ) :
 OO0oo0O = urllib2 . Request ( url )
 OO0oo0O . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 OO0oo0O . add_header ( 'Referer' , '%s' % url )
 OO0oo0O . add_header ( 'Connection' , 'keep-alive' )
 Ii1i1iI = urllib2 . urlopen ( OO0oo0O )
 IIiI1 = Ii1i1iI . read ( )
 Ii1i1iI . close ( )
 return IIiI1
 if 89 - 89: o00O0oo
 if 76 - 76: I11ii1
def IIIiI11ii1I ( ) :
 if 39 - 39: Oo0Ooo / I1IiiI / IiII - o00O0oo - O0O00o0OOO0 % I1Ii111
 Ii1iIiII1ii1 = oo000 . getSetting ( 'MenuColor' )
 if 31 - 31: ooOoO0o - I1IiiI / I11ii1 * I11i
 if Ooo0OO0oOO == 'true' :
  if 12 - 12: Ii1I - I11ii1 * o0
  II1111ii ( '[COLOR %s]Peliculas[/COLOR] ' % Ii1iIiII1ii1 , 'movieDB' , 116 , i1iiI11I , O0oOO0o0 )
  II1111ii ( '[COLOR %s]Series[/COLOR] ' % Ii1iIiII1ii1 , 'movieDB' , 117 , iiii , O0oOO0o0 )
  if 27 - 27: I1IiiI
  if 79 - 79: Ii1I - ooOoO0o + Ii1I . IiII
 if o00OO00OoO == 'true' :
  II1111ii ( '[COLOR %s]Ajustes[/COLOR]' % Ii1iIiII1ii1 , 'Settings' , 119 , oO0o0O0OOOoo0 , O0oOO0o0 )
  if 28 - 28: OoOoOO00 - O0O00o0OOO0
  if 54 - 54: O0O00o0OOO0 - I1IiiI % I1Ii111
  if Iii111II == 'true' :
   Oo ( )
   if 44 - 44: I1ii11iIi11i - ooOoO0o % Oo0Ooo
  if OOOO0OOoO0O0 == 'true' :
   O0O ( )
   Oo0o ( )
   if 89 - 89: O0O00o0OOO0 . I1IiiI / iII111i % I11i . oO0o
  if IIIii1II1II == 'false' :
   if 50 - 50: o0oOOo0O0Ooo + iII111i . OoOoOO00 % Ii1I
   oOIIiIi = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   OOOO0O00o = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Script.ResolveURL para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   oooIIiIiI1I = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 5 - 5: I11i / OoO0O00 + O0o * o0 - OOooOOo % I1ii11iIi11i
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , oOIIiIi , OOOO0O00o , oooIIiIiI1I )
   if 42 - 42: I1IiiI / Ii1I + OoO0O00 * I11ii1 % I11ii1
def i1iIi ( ) :
 II1111ii ( '[COLOR orange]Buscador por id[/COLOR]' , iI1iII1 , 127 , iiI1iIiI , O0oOO0o0 )
 if 21 - 21: IiII / iII111i + o00O0oo + OoO0O00
def OoOoI1iI11iIiIi1 ( ) :
 if 72 - 72: o0
 Ii1iIiII1ii1 = oo000 . getSetting ( 'MenuColor' )
 II1111ii ( '[COLOR %s]The movie DB[/COLOR]' % Ii1iIiII1ii1 , 'movieDB' , 99 , iiI1iIiI , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Buscador por id[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 127 , iiI1iIiI , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Video tutoriales[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 125 , iI , O0oOO0o0 )
 if 90 - 90: oO0o % I1IiiI * Oo0Ooo . O0O00o0OOO0
 if 8 - 8: I11ii1 + o0oOOo0O0Ooo / O0O00o0OOO0 / ooOoO0o
 if 74 - 74: I1IiiI / OoOoOO00
 if 78 - 78: OoO0O00 . OOooOOo + I11ii1 - OoOoOO00
 if 31 - 31: OoO0O00 . I1Ii111
 if 83 - 83: O0O00o0OOO0 . I1IiiI / oO0o / I1Ii111 - o0oOOo0O0Ooo
 II1111ii ( '[COLOR %s]Autorizar OPENLOAD[/COLOR]' % Ii1iIiII1ii1 , 'movieDB' , 97 , II1Ii1iI1i , O0oOO0o0 )
 if 100 - 100: OOooOOo
 if 46 - 46: I11i / Oo0Ooo % O0O00o0OOO0 . Oo0Ooo * O0O00o0OOO0
 if 38 - 38: iII111i - O0O00o0OOO0 / I1IiiI . o0
 IIIiI11ii1I ( )
 if 45 - 45: o0
 if 83 - 83: I11i . OoO0O00
 if 58 - 58: II111iiii + OoO0O00 % OoO0O00 / O0o / II111iiii
 if 62 - 62: OOooOOo / iII111i
 if 7 - 7: OoO0O00 . O0o
 if 53 - 53: o00O0oo % o00O0oo * Ii1I + I11i
 if 92 - 92: OoO0O00 + OoOoOO00 / o00O0oo * I1IiiI
 if 100 - 100: I11ii1 % Oo0Ooo * o0oOOo0O0Ooo - O0O00o0OOO0
 if 92 - 92: I11ii1
 if 22 - 22: oO0o % O0O00o0OOO0 * iII111i / I1Ii111 % II111iiii * ooOoO0o
 if 95 - 95: OoO0O00 - O0o * I1ii11iIi11i + I11i
def iIi1 ( ) :
 i11iiI1111 = xbmcgui . Dialog ( )
 oOoooo000Oo00 = (
 OOoo ,
 o00O00oO00 ,
 )
 if 23 - 23: Oo0Ooo * OoOoOO00 % OoO0O00 * O0o
 I1Iiiiiii = i11iiI1111 . select ( '[B][COLOR=yellow]Listado de Proxys Gratuitos:[/COLOR][/B]' , [
 '[COLOR=orange]                      Accede a la web[/COLOR]' ,

 '[B][COLOR=gold]                      Volver al Menu [/COLOR][/B]' , ] )
 if 39 - 39: O0o * oO0o + Oo0Ooo - O0o + I1Ii111
 if I1Iiiiiii :
  if 69 - 69: I1IiiI
  if I1Iiiiiii < 0 :
   return
  o0ooO = oOoooo000Oo00 [ I1Iiiiiii - 2 ]
  return o0ooO ( )
 else :
  o0ooO = oOoooo000Oo00 [ I1Iiiiiii ]
  return o0ooO ( )
 return
 if 74 - 74: I1IiiI * IiII - II111iiii + o0
def Iii ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 19 - 19: ooOoO0o % o0oOOo0O0Ooo / II111iiii / O0O00o0OOO0 - OoO0O00
iIIiii1 = Iii ( )
if 31 - 31: I1Ii111 + Ii1I . OoO0O00
def OOoo ( ) :
 if iIIiii1 == 'android' :
  ooOooo0 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://hidemyna.me/es/proxy-list/?country=ES&type=hs#list' ) )
  if 67 - 67: I1ii11iIi11i
 else :
  ooOooo0 = webbrowser . open ( 'https://hidemyna.me/es/proxy-list/?country=ES&type=hs#list' )
  if 55 - 55: iII111i - O0O00o0OOO0 * Ii1I + I11i * I11i * I1IiiI
  if 91 - 91: o0 - I1Ii111 % Oo0Ooo - OoO0O00 % I11ii1
def o00O00oO00 ( ) :
 if 98 - 98: OOooOOo . OOooOOo * IiII * o0oOOo0O0Ooo * o0
 OoOoI1iI11iIiIi1 ( )
 if 92 - 92: oO0o
 if 40 - 40: I11i / O0o
def OOOoO000 ( ) :
 if xbmc . getCondVisibility ( 'System.HasAddon(script.favourites)' ) :
  try :
   xbmc . executebuiltin ( "RunScript(script.favourites)" )
  except :
   pass
def oOOOO ( ) :
 oo000 . openSettings ( )
 if 49 - 49: o0oOOo0O0Ooo . IiII . II111iiii % O0o
 if 34 - 34: o0 % O0o
def IiI1i ( ) :
 urlresolver . display_settings ( )
 if 87 - 87: I11ii1
def O0O ( ) :
 II1111ii ( '[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % Ii1iIiII1ii1 , 'resolve' , 120 , oOO00oOO , O0oOO0o0 )
 if 45 - 45: OOooOOo / OoO0O00 - O0O00o0OOO0 / o00O0oo % O0o
def OoO ( ) :
 if 14 - 14: II111iiii * O0O00o0OOO0 / OoOoOO00 * o0 + o0oOOo0O0Ooo % O0O00o0OOO0
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 51 - 51: II111iiii . iII111i + O0o / iII111i
def Oo0o ( ) :
 II1111ii ( '[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % Ii1iIiII1ii1 , 'resolve' , 140 , oOO00oOO , O0oOO0o0 )
 if 35 - 35: O0o
def Oo ( ) :
 if 75 - 75: oO0o / iII111i . O0o * I1Ii111 - o0oOOo0O0Ooo
 Ii1iIiII1ii1 = oo000 . getSetting ( 'MenuColor' )
 II1111ii ( '[COLOR %s]Buscador[/COLOR]' % Ii1iIiII1ii1 , 'search' , 111 , i111I , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Estrenos[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 3 , Ii1IIii11 , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Todas[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 26 , Oooo0000 , O0oOO0o0 )
 II1111ii ( '[COLOR %s]4K[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 141 , II11iiii1Ii , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Novedades[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 2 , OOo , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Accion[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 5 , i11 , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Animacion[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 6 , I11 , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Artes Marciales[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 29 , I11 , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Aventuras[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 7 , Oo0o0000o0o0 , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Belico[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 8 , oOo0oooo00o , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Ciencia Ficcion[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 9 , oO0o0o0ooO0oO , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Cine Clasico[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 30 , oO0o0o0ooO0oO , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Comedia[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 10 , oo0o0O00 , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Crimen[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 11 , oO , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Drama[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 12 , i1iiIIiiI111 , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Familiar[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 13 , oooOOOOO , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Fantasia[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 14 , i1iiIII111ii , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Historia[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 15 , i1iIIi1 , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Misterio[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 16 , iI111I11I1I1 , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Musical[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 17 , OOooO0OOoo , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Romance[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 18 , iIii1 , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Thriller[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 19 , II , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Suspense[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 20 , O0OoO000O0OO , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Terror[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 21 , iiI1IiI , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Western[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 22 , ooOoOoo0O , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Spain[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 23 , oOOoO0 , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Super heroes[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 24 , ii11iIi1I , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Sagas[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 25 , OooO0 , O0oOO0o0 )
 if 41 - 41: o00O0oo
 if 77 - 77: o0
def OooOOOOoO00OoOO ( ) :
 if 85 - 85: IiII - Oo0Ooo / I1IiiI
 if 99 - 99: o0oOOo0O0Ooo * O0o % Oo0Ooo / o00O0oo
 try :
  if 90 - 90: IiII % I1Ii111 - I1Ii111 % o0oOOo0O0Ooo * OOooOOo
  iIi1iI111I = I11iiii ( oOoO )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( iIi1iI111I )
  for IiI1iiiIii in O0i1iI :
   if 85 - 85: OoO0O00 * Oo0Ooo . O0O00o0OOO0 / OoO0O00 % I1ii11iIi11i % I1IiiI
   try :
    if 36 - 36: o00O0oo / o0oOOo0O0Ooo / O0o / O0o + iII111i
    oO0Ooo0ooOO0 = IiI1iiiIii
    O0OoooO0 = xbmc . Keyboard ( '' , 'Buscar' )
    O0OoooO0 . doModal ( )
    if ( O0OoooO0 . isConfirmed ( ) ) :
     if 46 - 46: o00O0oo % I11i
     iI1i11II1i = urllib . quote_plus ( O0OoooO0 . getText ( ) ) . replace ( '+' , ' ' )
     I11Iiii1I = I11iiii ( oO0Ooo0ooOO0 )
     O0i1iI = re . compile ( ii1ii11IIIiiI ) . findall ( I11Iiii1I )
     for i1ii1iIII , iII1i11IIi1i , O0oOO0o0 , oOOoo0000O0o0 in O0i1iI :
      if re . search ( iI1i11II1i , III1 ( iII1i11IIi1i . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       II1111ii ( iII1i11IIi1i , oOOoo0000O0o0 , 143 , i1ii1iIII , O0oOO0o0 )
       if 64 - 64: II111iiii - o0oOOo0O0Ooo
   except :
    pass
 except :
  pass
  if 77 - 77: I11i % o00O0oo
def II1IiiIii ( ) :
 if 84 - 84: IiII % OoOoOO00
 II1111ii ( '[COLOR %s]Buscar Serie[/COLOR]' % Ii1iIiII1ii1 , 'search' , 145 , Ooo , O0oOO0o0 )
 II1111ii ( '[COLOR %s]Todas[/COLOR]' % Ii1iIiII1ii1 , iI1iII1 , 142 , O0o0Oo , O0oOO0o0 )
 if 70 - 70: oO0o . OoO0O00 - O0O00o0OOO0
 if 30 - 30: iII111i % I1ii11iIi11i
def O0Oo00 ( ) :
 if 41 - 41: Oo0Ooo % ooOoO0o
 try :
  if 59 - 59: I1Ii111 + II111iiii
  iIi1iI111I = I11iiii ( oOoO )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( iIi1iI111I )
  for IiI1iiiIii in O0i1iI :
   if 88 - 88: II111iiii - I11ii1
   try :
    if 67 - 67: I1Ii111 . oO0o + I11i - OoO0O00
    oO0Ooo0ooOO0 = IiI1iiiIii
    if 70 - 70: I1Ii111 / o0oOOo0O0Ooo - Oo0Ooo - O0O00o0OOO0
   except :
    pass
    if 11 - 11: Oo0Ooo . OoO0O00 . o0oOOo0O0Ooo / OoOoOO00 - ooOoO0o
  I11Iiii1I = I11iiii ( oO0Ooo0ooOO0 )
  O0i1iI = re . compile ( ii1ii11IIIiiI ) . findall ( I11Iiii1I )
  for i1ii1iIII , iII1i11IIi1i , O0oOO0o0 , oOOoo0000O0o0 in O0i1iI :
   try :
    if 30 - 30: I11i
    II1111ii ( iII1i11IIi1i , oOOoo0000O0o0 , 143 , i1ii1iIII , O0oOO0o0 )
    if 21 - 21: II111iiii / o0 % I1Ii111 * I1IiiI . ooOoO0o - Oo0Ooo
   except :
    pass
 except :
  pass
  if 26 - 26: o0oOOo0O0Ooo * I11i
def iioo0o0OoOOO ( name , url ) :
 if 88 - 88: O0O00o0OOO0
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 19 - 19: o0oOOo0O0Ooo * O0o + o00O0oo
 o0o0OoOo0O0OO = I11iiii ( url )
 O0i1iI = re . compile ( O000OOo00oo ) . findall ( o0o0OoOo0O0OO )
 for O0ooO00oO , name , O0oOO0o0 , url in O0i1iI :
  try :
   if 36 - 36: I1Ii111
   if 84 - 84: o0 . OOooOOo . o0oOOo0O0Ooo . ooOoO0o / o00O0oo % iII111i
   oO0 = oo000 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % oO0 + name + '[/COLOR]'
   OOO0oOoO0O ( name , url , 144 , O0ooO00oO , O0oOO0o0 )
   if 84 - 84: I1IiiI * OoO0O00 - O0o * O0o
   if 8 - 8: I11ii1 / OoOoOO00 . IiII
  except :
   pass
   if 41 - 41: O0O00o0OOO0 + OOooOOo
   if 86 - 86: I11i . Oo0Ooo - OOooOOo
   if 56 - 56: I1IiiI
def OOO0oOoO0O ( name , url , mode , iconimage , fanart ) :
 if 61 - 61: Ii1I / I1Ii111 / oO0o * I1IiiI
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 23 - 23: IiII - I1Ii111 + ooOoO0o
 II11 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage="
 Iiii11iIi1 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 Iiii11iIi1 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 Iiii11iIi1 . setProperty ( 'fanart_image' , fanart )
 Iiii11iIi1 . setProperty ( 'IsPlayable' , 'true' )
 i1iI11I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II11 , listitem = Iiii11iIi1 )
 return i1iI11I1II1
 if 14 - 14: II111iiii - O0O00o0OOO0 * I11i
def OO0oIII111i11IiI ( name , url ) :
 if 71 - 71: ooOoO0o / ooOoO0o * IiII * IiII / o0oOOo0O0Ooo
 if 35 - 35: I1Ii111 * Ii1I * I1ii11iIi11i % oO0o . I11i
 if 'https://team.com' in url :
  if 58 - 58: ooOoO0o + o0oOOo0O0Ooo * O0O00o0OOO0 * II111iiii - Oo0Ooo
  url = url . replace ( 'https://team.com' , 'https://verystream.com' )
  if 68 - 68: OoO0O00 % o0oOOo0O0Ooo
 if 'https://mybox.com' in url :
  if 26 - 26: o0oOOo0O0Ooo % II111iiii % Oo0Ooo % ooOoO0o * ooOoO0o * iII111i
  url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
  if 24 - 24: o0oOOo0O0Ooo % o0 - I11ii1 + I1ii11iIi11i * iII111i
 if 'https://drive.com' in url :
  if 2 - 2: o00O0oo - O0o
  url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
  if 83 - 83: IiII % Ii1I % o00O0oo - o0oOOo0O0Ooo * I1Ii111 / OoO0O00
 if 'https://vidcloud.co/' in url :
  if 18 - 18: OOooOOo + Oo0Ooo - o0oOOo0O0Ooo - I1ii11iIi11i
  url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
  if 71 - 71: OoO0O00
 if 'https://gounlimited.to' in url :
  if 33 - 33: o0
  url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
  if 62 - 62: iII111i + o00O0oo + OoOoOO00 / OoO0O00
  if 7 - 7: Ii1I + OoOoOO00 . I1ii11iIi11i / oO0o
  if 22 - 22: I11ii1 - I11ii1 % I1Ii111 . o0 + IiII
 import resolveurl
 if 63 - 63: I1ii11iIi11i % o0 * Ii1I + o0 / oO0o % O0O00o0OOO0
 iiI1i1Iii111 = urlresolver . HostedMediaFile ( url )
 if 43 - 43: Ii1I
 if 71 - 71: IiII % ooOoO0o * I11i . I1IiiI / o00O0oo . iII111i
 if not iiI1i1Iii111 :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
  return False
  if 58 - 58: oO0o / IiII
 try :
  iIII1I1i1i = iiI1i1Iii111 . resolve ( )
  if not iIII1I1i1i or not isinstance ( iIII1I1i1i , basestring ) :
   try : o0OIIiI1I1 = iIII1I1i1i . msg
   except : o0OIIiI1I1 = url
   raise Exception ( o0OIIiI1I1 )
 except Exception as i1iI1 :
  try : o0OIIiI1I1 = str ( i1iI1 )
  except : o0OIIiI1I1 = url
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado, reportalo en nuesto grupo de telegram [COLOR ligthblue] https://t.me/OficialNetai [/COLOR]  ,5000)" )
  return False
  if 15 - 15: o00O0oo * oO0o % iII111i * Oo0Ooo - II111iiii
  if 60 - 60: I1ii11iIi11i * o0 % OOooOOo + IiII
  if 52 - 52: OoOoOO00
 oo0OooOOo0 = oo000 . getSetting ( 'notificar' )
 if oo0OooOOo0 == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
  if 84 - 84: o00O0oo / O0o
  if 86 - 86: I11i * o0oOOo0O0Ooo - I1IiiI . I11i % Oo0Ooo / I1Ii111
  IiIIiIIIiIii = xbmcgui . ListItem ( path = iIII1I1i1i )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiIIiIIIiIii )
  if 23 - 23: O0O00o0OOO0 + ooOoO0o . I11i * I1ii11iIi11i + iII111i
 else :
  if 18 - 18: O0o * Ii1I . O0o / I1IiiI
  IiIIiIIIiIii = xbmcgui . ListItem ( path = iIII1I1i1i )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiIIiIIIiIii )
  if 8 - 8: Ii1I
  if 4 - 4: iII111i + iII111i * I11ii1 - I11i
  if 78 - 78: o00O0oo / o0oOOo0O0Ooo % I11i
def oO00OoOO ( ) :
 if 18 - 18: I11ii1 - I11i % OoOoOO00 + I1IiiI + II111iiii + OoOoOO00
 if 91 - 91: I11i + I11ii1 . I1ii11iIi11i
 O0oOoOOO0OO = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 O0oOoOOO0OO . doModal ( )
 if not O0oOoOOO0OO . isConfirmed ( ) :
  return None ;
 iII1i11IIi1i = O0oOoOOO0OO . getText ( ) . strip ( )
 if 91 - 91: O0o + I11i + Ii1I - Oo0Ooo
 if 17 - 17: IiII
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 22 - 22: ooOoO0o + Oo0Ooo
  ooOooo0 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + iII1i11IIi1i + '&language=es-ES' ) )
  if 24 - 24: I11i % OoOoOO00 + O0O00o0OOO0 . II111iiii . iII111i
  if 17 - 17: iII111i . o0oOOo0O0Ooo . I11ii1 / iII111i
  return 'android'
  if 57 - 57: ooOoO0o
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 67 - 67: OOooOOo . I11ii1
  ooOooo0 = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + iII1i11IIi1i + '&language=es-ES' )
  if 87 - 87: IiII % o00O0oo
  if 83 - 83: o0oOOo0O0Ooo - ooOoO0o
  return 'windows'
  if 35 - 35: OoOoOO00 - Oo0Ooo + OoOoOO00
  if 86 - 86: Oo0Ooo + I11i . II111iiii - o00O0oo
def ooO000O ( ) :
 if 53 - 53: Ii1I . O0O00o0OOO0 / o00O0oo
 try :
  if 39 - 39: o00O0oo % I1IiiI % I11i . OoOoOO00
  II1iIi11 = I11iiii ( i1Ii )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for IiI1iiiIii in O0i1iI :
   if 86 - 86: OOooOOo * OoO0O00
   try :
    if 71 - 71: Oo0Ooo - I1Ii111 . I1ii11iIi11i % OoO0O00 + I1Ii111
    all = IiI1iiiIii
    if 26 - 26: oO0o + I1Ii111 / OOooOOo % I11i % iII111i + o0oOOo0O0Ooo
   except :
    pass
    if 31 - 31: ooOoO0o % I1Ii111 * ooOoO0o
  o0o0OoOo0O0OO = I11iiii ( all )
  O0i1iI = re . compile ( OOoO ) . findall ( o0o0OoOo0O0OO )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    if 45 - 45: OoOoOO00 . I1ii11iIi11i + I1Ii111 - OoO0O00 % I11ii1
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 1 - 1: Oo0Ooo
   except :
    pass
 except :
  pass
  if 93 - 93: OoOoOO00 . II111iiii . oO0o
def O0O00OOo ( ) :
 if 66 - 66: II111iiii / Ii1I - OoO0O00 / OoOoOO00 . II111iiii
 try :
  if 16 - 16: oO0o % iII111i + ooOoO0o - I1IiiI . O0O00o0OOO0 / o0
  OOo = I11iiii ( OOO )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( OOo )
  for IiI1iiiIii in O0i1iI :
   if 35 - 35: IiII / o0 / o0oOOo0O0Ooo - Oo0Ooo + o0oOOo0O0Ooo . o0
   try :
    if 81 - 81: O0O00o0OOO0 * I1Ii111 - iII111i * o00O0oo % I11i * I11i
    oO0Ooo0ooOO0 = IiI1iiiIii
    if 59 - 59: Oo0Ooo
   except :
    pass
    if 7 - 7: I1Ii111 * I1ii11iIi11i / Ii1I * II111iiii
  I11Iiii1I = I11iiii ( oO0Ooo0ooOO0 )
  O0i1iI = re . compile ( OOoO ) . findall ( I11Iiii1I )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    if 84 - 84: I1Ii111 . O0O00o0OOO0
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 8 - 8: oO0o + o0oOOo0O0Ooo * I1Ii111 * I11i * ooOoO0o / O0o
   except :
    pass
 except :
  pass
  if 21 - 21: IiII / OoO0O00
def III1IiIII1 ( ) :
 if 90 - 90: I11ii1 + o0oOOo0O0Ooo * iII111i / o00O0oo . Ii1I + Ii1I
 try :
  if 40 - 40: I11ii1 / I11i % II111iiii % iII111i / I1ii11iIi11i
  Ii1IIii11 = I11iiii ( I11IiI )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( Ii1IIii11 )
  for IiI1iiiIii in O0i1iI :
   if 62 - 62: OoOoOO00 - I11i
   try :
    oo0O0oo = IiI1iiiIii
   except :
    pass
    if 14 - 14: I1IiiI / OoOoOO00 / oO0o + Oo0Ooo
  II1iIi11 = I11iiii ( oo0O0oo )
  O0i1iI = re . compile ( OOoO ) . findall ( II1iIi11 )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 96 - 96: O0O00o0OOO0
   except :
    pass
 except :
  pass
  if 18 - 18: O0O00o0OOO0 * ooOoO0o - o00O0oo
def II1i1III ( ) :
 if 34 - 34: o0 - II111iiii / Oo0Ooo
 try :
  if 87 - 87: iII111i / OoO0O00 - oO0o % I11i % O0o % oO0o
  II1iIi11 = I11iiii ( db2 )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for IiI1iiiIii in O0i1iI :
   if 29 - 29: OoO0O00 . I1ii11iIi11i % iII111i - O0O00o0OOO0
   try :
    if 8 - 8: OoOoOO00
    iIiI1 = IiI1iiiIii
    if 37 - 37: OOooOOo * II111iiii / I1Ii111 % o0
   except :
    pass
    if 71 - 71: OoO0O00
    if 11 - 11: O0o
  II1iIi11 = I11iiii ( iIiI1 )
  O0i1iI = re . compile ( OOoO ) . findall ( II1iIi11 )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 55 - 55: oO0o
   except :
    pass
 except :
  pass
  if 77 - 77: o0oOOo0O0Ooo
def IiiiIi1iI1iI ( ) :
 if 98 - 98: OOooOOo / I1Ii111 * iII111i / IiII
 try :
  if 64 - 64: IiII - I1ii11iIi11i / O0O00o0OOO0 - OOooOOo
  ii11I = I11iiii ( ooo )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( ii11I )
  for IiI1iiiIii in O0i1iI :
   if 47 - 47: o0
   try :
    if 95 - 95: OOooOOo . OoOoOO00 / II111iiii
    iIi1IIiI = IiI1iiiIii
    if 24 - 24: O0O00o0OOO0 * o0oOOo0O0Ooo % O0O00o0OOO0 % O0o + OoO0O00
   except :
    pass
    if 29 - 29: o0oOOo0O0Ooo - OoO0O00 - II111iiii . Ii1I
    if 19 - 19: o0oOOo0O0Ooo
  II1iIi11 = I11iiii ( iIi1IIiI )
  O0i1iI = re . compile ( OOoO ) . findall ( II1iIi11 )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 72 - 72: OoO0O00 / I1ii11iIi11i + o00O0oo / I11i * o00O0oo
   except :
    pass
 except :
  pass
  if 34 - 34: I1IiiI * I1IiiI % OoO0O00 + O0O00o0OOO0 * Oo0Ooo % o00O0oo
def I1iI1I1 ( ) :
 if 48 - 48: I1ii11iIi11i / II111iiii - Ii1I * IiII / OoO0O00
 try :
  if 89 - 89: Oo0Ooo / I1ii11iIi11i - o0oOOo0O0Ooo / o00O0oo . II111iiii . o00O0oo
  II1iIi11 = I11iiii ( ooO0oOOooOo0 )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for IiI1iiiIii in O0i1iI :
   if 48 - 48: I1IiiI + I1IiiI . o0 - I11ii1
   try :
    if 63 - 63: IiII
    Oo0 = IiI1iiiIii
    if 79 - 79: OOooOOo % I1Ii111 / Oo0Ooo + I11i * OOooOOo
   except :
    pass
    if 30 - 30: OoO0O00 / ooOoO0o + O0O00o0OOO0 / iII111i * I1IiiI
    if 16 - 16: oO0o / II111iiii
  II1iIi11 = I11iiii ( Oo0 )
  O0i1iI = re . compile ( OOoO ) . findall ( II1iIi11 )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 64 - 64: II111iiii / o00O0oo * OoOoOO00
   except :
    pass
 except :
  pass
  if 73 - 73: oO0o - I11i - IiII - I1ii11iIi11i
def oo0o0oOo ( ) :
 if 58 - 58: Ii1I - o0oOOo0O0Ooo % IiII + o0 . I11i / O0o
 try :
  if 8 - 8: iII111i . OOooOOo * ooOoO0o + o0oOOo0O0Ooo % II111iiii
  II1iIi11 = I11iiii ( I1IiiiiI )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for IiI1iiiIii in O0i1iI :
   if 8 - 8: I11ii1 * I1IiiI
   try :
    if 73 - 73: Ii1I / IiII / ooOoO0o / OOooOOo
    III1ii = IiI1iiiIii
    if 41 - 41: I11ii1 . oO0o + I1ii11iIi11i
   except :
    pass
    if 100 - 100: o00O0oo + OOooOOo
  II1iIi11 = I11iiii ( III1ii )
  O0i1iI = re . compile ( OOoO ) . findall ( II1iIi11 )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 73 - 73: OoOoOO00 - o0 % I11ii1 / OOooOOo
   except :
    pass
 except :
  pass
  if 40 - 40: iII111i * I11ii1 - I1ii11iIi11i / O0o / II111iiii
def OOO0o ( ) :
 if 4 - 4: oO0o . OoOoOO00 - O0O00o0OOO0
 try :
  if 10 - 10: ooOoO0o * o00O0oo % OoO0O00
  II1iIi11 = I11iiii ( ii1iII1II )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for IiI1iiiIii in O0i1iI :
   if 83 - 83: o0 - I1ii11iIi11i - iII111i % I1IiiI . o00O0oo
   try :
    if 35 - 35: O0o + OoOoOO00 * IiII - o00O0oo . oO0o
    iiIii1II = IiI1iiiIii
    if 60 - 60: o0oOOo0O0Ooo / Oo0Ooo + iII111i . II111iiii
   except :
    pass
    if 40 - 40: Ii1I
    if 78 - 78: Oo0Ooo
  II1iIi11 = I11iiii ( iiIii1II )
  O0i1iI = re . compile ( OOoO ) . findall ( II1iIi11 )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 56 - 56: OoO0O00 - ooOoO0o - OoOoOO00
   except :
    pass
 except :
  pass
  if 8 - 8: o0 / I1Ii111 . I1ii11iIi11i + iII111i / II111iiii
def I1Iii1iI1 ( ) :
 if 86 - 86: I1IiiI
 try :
  if 95 - 95: O0O00o0OOO0 * I1Ii111 . I11i . OoOoOO00 . OoOoOO00 - Ii1I
  II1iIi11 = I11iiii ( I1I1i1I )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for IiI1iiiIii in O0i1iI :
   if 26 - 26: Oo0Ooo % II111iiii % iII111i
   try :
    if 67 - 67: OoO0O00
    IiIiIi1I1 = IiI1iiiIii
    if 2 - 2: OoOoOO00 - I11ii1 + I1ii11iIi11i . Ii1I * Ii1I / I11i
   except :
    pass
    if 93 - 93: OoOoOO00
    if 53 - 53: OoO0O00 + oO0o + IiII
  II1iIi11 = I11iiii ( IiIiIi1I1 )
  O0i1iI = re . compile ( OOoO ) . findall ( II1iIi11 )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 24 - 24: O0O00o0OOO0 - O0o - O0O00o0OOO0 * iII111i . OoO0O00 / O0o
   except :
    pass
 except :
  pass
  if 66 - 66: oO0o
def Oooo00oOo ( ) :
 if 14 - 14: O0o % ooOoO0o / Oo0Ooo - I11ii1
 try :
  if 98 - 98: o0
  II1iIi11 = I11iiii ( O0oO0 )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for IiI1iiiIii in O0i1iI :
   if 92 - 92: o0 - Oo0Ooo
   try :
    if 32 - 32: o00O0oo % OOooOOo * OOooOOo + O0o * o0oOOo0O0Ooo * o00O0oo
    iIiIii1I1II = IiI1iiiIii
    if 61 - 61: O0o + Oo0Ooo + II111iiii / II111iiii % o0oOOo0O0Ooo
   except :
    pass
    if 42 - 42: o00O0oo * o0 . O0o * I1ii11iIi11i + I11i
    if 25 - 25: ooOoO0o . I1ii11iIi11i + IiII
  II1iIi11 = I11iiii ( iIiIii1I1II )
  O0i1iI = re . compile ( OOoO ) . findall ( II1iIi11 )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 75 - 75: O0o - Ii1I % O0O00o0OOO0 + II111iiii
   except :
    pass
 except :
  pass
  if 100 - 100: ooOoO0o + Ii1I - II111iiii - o0oOOo0O0Ooo
def iIIIiIi1I1i ( ) :
 if 78 - 78: Oo0Ooo % I11i + iII111i / OoOoOO00 % o0oOOo0O0Ooo + I1Ii111
 try :
  if 91 - 91: Oo0Ooo % OOooOOo . Ii1I + o00O0oo + Ii1I
  II1iIi11 = I11iiii ( Ooo0oOooo0 )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for IiI1iiiIii in O0i1iI :
   if 95 - 95: o00O0oo + iII111i * I1Ii111
   try :
    if 16 - 16: ooOoO0o / I1ii11iIi11i + OOooOOo % Oo0Ooo - OoOoOO00 . IiII
    iIi1iIIIiIiI = IiI1iiiIii
    if 62 - 62: II111iiii % I1Ii111 . O0o . I1Ii111
   except :
    pass
    if 84 - 84: II111iiii * OOooOOo
    if 18 - 18: I1Ii111 - o00O0oo - I11i / o0 - I1IiiI
  II1iIi11 = I11iiii ( iIi1iIIIiIiI )
  O0i1iI = re . compile ( OOoO ) . findall ( II1iIi11 )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 30 - 30: I1IiiI + iII111i + o0oOOo0O0Ooo
   except :
    pass
 except :
  pass
  if 14 - 14: Ii1I / I1Ii111 - Oo0Ooo - IiII % I11ii1
  if 49 - 49: I11ii1 * IiII / Ii1I / oO0o * Oo0Ooo
def OOoO00ooO ( ) :
 if 12 - 12: I11ii1 % I1ii11iIi11i + IiII - OoOoOO00 . o00O0oo / I1ii11iIi11i
 try :
  if 51 - 51: I1Ii111 . I1ii11iIi11i
  II1iIi11 = I11iiii ( OO )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for IiI1iiiIii in O0i1iI :
   if 73 - 73: OoO0O00 . I1ii11iIi11i / o0 % o00O0oo
   try :
    if 65 - 65: O0o - I1ii11iIi11i - o00O0oo
    Ii1iIi111I1i = IiI1iiiIii
    if 4 - 4: O0O00o0OOO0 - oO0o - O0o - ooOoO0o % II111iiii / OOooOOo
   except :
    pass
    if 50 - 50: I11ii1 + OoOoOO00
    if 31 - 31: o00O0oo
  II1iIi11 = I11iiii ( Ii1iIi111I1i )
  O0i1iI = re . compile ( OOoO ) . findall ( II1iIi11 )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 78 - 78: II111iiii + Ii1I + o0 / Ii1I % Oo0Ooo % O0o
   except :
    pass
 except :
  pass
  if 83 - 83: Oo0Ooo % I11i % Ii1I % o0 . iII111i % I1IiiI
  if 47 - 47: Ii1I
def oo0ooooO ( ) :
 if 12 - 12: o0oOOo0O0Ooo
 try :
  if 2 - 2: OoOoOO00 - I1ii11iIi11i + ooOoO0o . o0oOOo0O0Ooo
  II1iIi11 = I11iiii ( Ii1I1i )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for IiI1iiiIii in O0i1iI :
   if 25 - 25: IiII
   try :
    if 34 - 34: I11i . Oo0Ooo % I1IiiI
    iI11Ii111 = IiI1iiiIii
    if 54 - 54: I11i % O0O00o0OOO0 . I11i * I1Ii111 + I11i % OoOoOO00
   except :
    pass
    if 23 - 23: o0 - I1Ii111 + o00O0oo - I11i * I11i . oO0o
    if 47 - 47: IiII % Oo0Ooo
  II1iIi11 = I11iiii ( iI11Ii111 )
  O0i1iI = re . compile ( OOoO ) . findall ( II1iIi11 )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 11 - 11: I1ii11iIi11i % o00O0oo - OOooOOo - IiII + Ii1I
   except :
    pass
    if 98 - 98: O0O00o0OOO0 + o00O0oo - OOooOOo
 except :
  pass
  if 79 - 79: I1Ii111 / o0 . I11i - iII111i
  if 47 - 47: OoO0O00 % I1IiiI * O0O00o0OOO0 . o00O0oo
def ii111Iiii ( ) :
 if 54 - 54: OoO0O00 - I1ii11iIi11i % iII111i
 try :
  if 92 - 92: OOooOOo * I11ii1
  II1iIi11 = I11iiii ( O0O0OOOOoo )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for IiI1iiiIii in O0i1iI :
   if 35 - 35: II111iiii
   try :
    if 99 - 99: o0oOOo0O0Ooo . Ii1I + I1IiiI
    O00o0O = IiI1iiiIii
    if 32 - 32: Ii1I + I11i - OoO0O00
   except :
    pass
    if 39 - 39: OoO0O00 * I1Ii111 * I1IiiI . ooOoO0o . OOooOOo + I11ii1
    if 9 - 9: I11i + IiII % OoO0O00 + Ii1I
  II1iIi11 = I11iiii ( O00o0O )
  O0i1iI = re . compile ( OOoO ) . findall ( II1iIi11 )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 56 - 56: OoO0O00 + iII111i - O0O00o0OOO0
   except :
    pass
    if 24 - 24: Ii1I + I11ii1 + ooOoO0o - Oo0Ooo
 except :
  pass
  if 49 - 49: ooOoO0o . I11ii1 * I11i % O0o . I1IiiI
def IiI1iiI1III1I ( ) :
 if 97 - 97: II111iiii / ooOoO0o * iII111i % I11i . OoO0O00
 try :
  if 6 - 6: IiII % I1IiiI / O0o - Oo0Ooo / O0o / II111iiii
  II1iIi11 = I11iiii ( Ii1I1Ii )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for IiI1iiiIii in O0i1iI :
   if 12 - 12: OoO0O00 - OOooOOo
   try :
    if 81 - 81: I11i % o00O0oo
    oo0 = IiI1iiiIii
    if 16 - 16: o00O0oo * OOooOOo / IiII
   except :
    pass
    if 22 - 22: IiII + Oo0Ooo % oO0o / ooOoO0o / o00O0oo
  II1iIi11 = I11iiii ( oo0 )
  O0i1iI = re . compile ( OOoO ) . findall ( II1iIi11 )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 54 - 54: I11i % O0o . II111iiii
   except :
    pass
 except :
  pass
  if 93 - 93: I11ii1 % II111iiii % o0
  if 64 - 64: o0 + I1ii11iIi11i * I1IiiI / oO0o - ooOoO0o % ooOoO0o
def o0oO00 ( ) :
 if 2 - 2: Oo0Ooo
 try :
  if 45 - 45: OoO0O00 / II111iiii
  II1iIi11 = I11iiii ( OO0Oooo0oOO0O )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for IiI1iiiIii in O0i1iI :
   if 10 - 10: O0O00o0OOO0 - IiII * Oo0Ooo % Oo0Ooo * O0o - iII111i
   try :
    if 97 - 97: o0oOOo0O0Ooo % o0 + o0 - OOooOOo / o00O0oo * I1ii11iIi11i
    iIii1iII1Ii = IiI1iiiIii
    if 50 - 50: o00O0oo
   except :
    pass
    if 22 - 22: ooOoO0o * I1IiiI . o0oOOo0O0Ooo - OOooOOo
    if 90 - 90: IiII
  II1iIi11 = I11iiii ( iIii1iII1Ii )
  O0i1iI = re . compile ( OOoO ) . findall ( II1iIi11 )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 94 - 94: ooOoO0o / iII111i * o0 - I11i
   except :
    pass
 except :
  pass
  if 44 - 44: o00O0oo % II111iiii - O0O00o0OOO0 * iII111i + oO0o * I1Ii111
  if 41 - 41: I1IiiI * I11ii1 - I11i . o00O0oo
def oOIIIiI1ii1IIi ( ) :
 if 55 - 55: O0O00o0OOO0 - OOooOOo
 try :
  if 100 - 100: I1IiiI
  II1iIi11 = I11iiii ( oOO0O00Oo0O0o )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for IiI1iiiIii in O0i1iI :
   if 79 - 79: Oo0Ooo
   try :
    if 81 - 81: I1Ii111 + Oo0Ooo * o0 - Oo0Ooo . I1Ii111
    I1 = IiI1iiiIii
    if 14 - 14: I1ii11iIi11i . o00O0oo
   except :
    pass
  II1iIi11 = I11iiii ( I1 )
  O0i1iI = re . compile ( OOoO ) . findall ( II1iIi11 )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 46 - 46: O0O00o0OOO0 - Oo0Ooo
   except :
    pass
 except :
  pass
  if 50 - 50: O0O00o0OOO0 / O0O00o0OOO0 + I1Ii111 * I11ii1 / iII111i
def I1IIiiI1II1 ( ) :
 if 5 - 5: O0O00o0OOO0
 try :
  if 62 - 62: I11i . OoO0O00 . I1Ii111 . OOooOOo * O0O00o0OOO0
  II1iIi11 = I11iiii ( I1iIIiiIIi1i )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for IiI1iiiIii in O0i1iI :
   if 78 - 78: IiII / OOooOOo - IiII * OoO0O00 . I11i
   try :
    if 96 - 96: I1ii11iIi11i % OoOoOO00 . Ii1I . I1IiiI
    Ii1Iii11 = IiI1iiiIii
    if 97 - 97: I1Ii111 / IiII . o0oOOo0O0Ooo
   except :
    pass
    if 44 - 44: o00O0oo % ooOoO0o . o0
    if 18 - 18: Oo0Ooo + ooOoO0o * I1ii11iIi11i - I1Ii111 / I1ii11iIi11i
  II1iIi11 = I11iiii ( Ii1Iii11 )
  O0i1iI = re . compile ( OOoO ) . findall ( II1iIi11 )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 78 - 78: ooOoO0o . O0o
   except :
    pass
 except :
  pass
  if 38 - 38: I11i + O0o
  if 15 - 15: oO0o + ooOoO0o . I11ii1 - Oo0Ooo / I1IiiI % Oo0Ooo
def oO0O ( ) :
 if 79 - 79: OoO0O00 - O0o * O0o . I11i
 try :
  if 100 - 100: o0oOOo0O0Ooo * ooOoO0o % I1ii11iIi11i / iII111i
  II1iIi11 = I11iiii ( oOOo0O00o )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for IiI1iiiIii in O0i1iI :
   if 90 - 90: iII111i . I11ii1 . I11i . o00O0oo
   try :
    if 4 - 4: o00O0oo + I11i % iII111i / II111iiii
    OoOi111i = IiI1iiiIii
    if 46 - 46: OOooOOo * oO0o % IiII + I1IiiI * O0o
   except :
    pass
    if 34 - 34: OOooOOo
    if 27 - 27: o00O0oo - I1IiiI % ooOoO0o * o0 . O0o % Oo0Ooo
  II1iIi11 = I11iiii ( OoOi111i )
  O0i1iI = re . compile ( OOoO ) . findall ( II1iIi11 )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 37 - 37: OoO0O00 + I1IiiI - OoOoOO00 % I11ii1
   except :
    pass
 except :
  pass
  if 24 - 24: I11i
def Oo0oOo0ooOOOo ( ) :
 if 71 - 71: o0oOOo0O0Ooo - o00O0oo - O0O00o0OOO0 * I1IiiI * O0o
 try :
  if 46 - 46: O0o
  II1iIi11 = I11iiii ( OOOiiiiI )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for IiI1iiiIii in O0i1iI :
   if 29 - 29: o0oOOo0O0Ooo . I11i % Ii1I * o0oOOo0O0Ooo - Ii1I * Oo0Ooo
   try :
    if 35 - 35: o0oOOo0O0Ooo - O0o . OoOoOO00
    OOOoO0 = IiI1iiiIii
    if 85 - 85: Oo0Ooo / OoO0O00 % o0oOOo0O0Ooo
   except :
    pass
    if 49 - 49: II111iiii % I11i + o0 . o0oOOo0O0Ooo % O0O00o0OOO0 * I1Ii111
    if 67 - 67: OoOoOO00
  II1iIi11 = I11iiii ( OOOoO0 )
  O0i1iI = re . compile ( OOoO ) . findall ( II1iIi11 )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 5 - 5: o0oOOo0O0Ooo . OoO0O00
   except :
    pass
 except :
  pass
  if 57 - 57: I1ii11iIi11i
  if 35 - 35: OoO0O00 - o0 / OOooOOo
def iii11i1 ( ) :
 if 48 - 48: I11ii1 * iII111i
 try :
  if 15 - 15: OOooOOo * ooOoO0o % Oo0Ooo * iII111i
  II1iIi11 = I11iiii ( OOoOOO0O000 )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for IiI1iiiIii in O0i1iI :
   if 31 - 31: OOooOOo * I1IiiI . IiII
   try :
    if 59 - 59: o0oOOo0O0Ooo * II111iiii
    ooOooO00Oo = IiI1iiiIii
    if 86 - 86: o0oOOo0O0Ooo + I11ii1 + O0o
   except :
    pass
    if 9 - 9: I11ii1 + o0oOOo0O0Ooo % I11ii1 % O0o + Oo0Ooo
    if 59 - 59: OoOoOO00
  II1iIi11 = I11iiii ( ooOooO00Oo )
  O0i1iI = re . compile ( OOoO ) . findall ( II1iIi11 )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 48 - 48: I1IiiI * o00O0oo * OOooOOo . OOooOOo * ooOoO0o - o00O0oo
   except :
    pass
 except :
  pass
  if 14 - 14: iII111i + II111iiii
  if 83 - 83: iII111i / II111iiii + o0oOOo0O0Ooo . O0O00o0OOO0 * I1Ii111 + O0o
def iiii1i1II1 ( ) :
 if 63 - 63: Oo0Ooo % iII111i - O0O00o0OOO0
 try :
  if 17 - 17: I1ii11iIi11i
  II1iIi11 = I11iiii ( oO0O00oOOoooO )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for IiI1iiiIii in O0i1iI :
   if 88 - 88: OoO0O00
   try :
    if 28 - 28: oO0o * Ii1I / o0
    Oo0O = IiI1iiiIii
    if 88 - 88: I1ii11iIi11i % I1Ii111 % iII111i . II111iiii % Ii1I
   except :
    pass
    if 38 - 38: o0 + OoO0O00 . OoOoOO00
    if 19 - 19: O0O00o0OOO0 - Ii1I - o00O0oo - I11i . O0O00o0OOO0 . o0
  II1iIi11 = I11iiii ( Oo0O )
  O0i1iI = re . compile ( OOoO ) . findall ( II1iIi11 )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 48 - 48: O0O00o0OOO0 + O0o
   except :
    pass
 except :
  pass
  if 60 - 60: ooOoO0o + O0O00o0OOO0 . O0o / OoOoOO00 . Oo0Ooo
  if 14 - 14: I1Ii111
def o0oo0Ooooo0 ( ) :
 if 76 - 76: OoOoOO00 * OoO0O00 * I1IiiI + o0 * o0
 try :
  if 35 - 35: Ii1I
  II1iIi11 = I11iiii ( Oo0O00O000 )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for IiI1iiiIii in O0i1iI :
   if 73 - 73: I1IiiI - iII111i
   try :
    if 2 - 2: o0oOOo0O0Ooo / o0
    OoOoO0oOOooo = IiI1iiiIii
    if 99 - 99: Oo0Ooo
   except :
    pass
    if 14 - 14: iII111i % I1ii11iIi11i . o0oOOo0O0Ooo . I1ii11iIi11i - I11ii1
    if 45 - 45: O0o / I1IiiI / I11i * I1Ii111
  II1iIi11 = I11iiii ( OoOoO0oOOooo )
  O0i1iI = re . compile ( OOoO ) . findall ( II1iIi11 )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 18 - 18: Oo0Ooo + I1Ii111 + Oo0Ooo . iII111i + o0 . I11ii1
   except :
    pass
 except :
  pass
  if 7 - 7: iII111i + Oo0Ooo * ooOoO0o * ooOoO0o / o0oOOo0O0Ooo - o00O0oo
  if 65 - 65: IiII + I11i + o0oOOo0O0Ooo
def oOOoo ( ) :
 if 6 - 6: I1Ii111
 try :
  if 98 - 98: OoO0O00 % I1IiiI - I1IiiI
  II1iIi11 = I11iiii ( oo )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for IiI1iiiIii in O0i1iI :
   if 76 - 76: OoOoOO00 % I11i - I1ii11iIi11i / Ii1I * I11ii1
   try :
    if 4 - 4: oO0o * oO0o / I11i
    Ii1Ii1Ii1I1I = IiI1iiiIii
    if 48 - 48: oO0o - I11ii1 + oO0o - I1ii11iIi11i * II111iiii . O0O00o0OOO0
   except :
    pass
    if 35 - 35: O0o . I1IiiI + oO0o + I1Ii111 + OoOoOO00
  II1iIi11 = I11iiii ( Ii1Ii1Ii1I1I )
  O0i1iI = re . compile ( OOoO ) . findall ( II1iIi11 )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 65 - 65: I1IiiI * I1ii11iIi11i / I1ii11iIi11i . I11i
   except :
    pass
 except :
  pass
  if 87 - 87: o0oOOo0O0Ooo * iII111i % oO0o * oO0o
  if 58 - 58: I1Ii111 . Ii1I + I1ii11iIi11i % oO0o - OOooOOo
def I1Iii1Ii1i1 ( ) :
 if 10 - 10: O0O00o0OOO0 . OoOoOO00 + o00O0oo
 try :
  if 66 - 66: OOooOOo % Ii1I
  II1iIi11 = I11iiii ( iIIii )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for IiI1iiiIii in O0i1iI :
   if 21 - 21: I11i - OoO0O00 % II111iiii
   try :
    if 71 - 71: OoOoOO00 - ooOoO0o * o0 + IiII - OOooOOo % iII111i
    Ooo0oO = IiI1iiiIii
    if 32 - 32: OoOoOO00 . O0O00o0OOO0 + o0oOOo0O0Ooo - OOooOOo - Oo0Ooo
   except :
    pass
    if 20 - 20: I11i % iII111i
    if 44 - 44: OoO0O00 . o0oOOo0O0Ooo . I1Ii111 % OoO0O00
  II1iIi11 = I11iiii ( Ooo0oO )
  O0i1iI = re . compile ( OOoO ) . findall ( II1iIi11 )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 86 - 86: II111iiii + I1IiiI * O0o - OOooOOo * I1Ii111 + I1IiiI
   except :
    pass
 except :
  pass
  if 95 - 95: Oo0Ooo . o0 % O0O00o0OOO0 - o0 * o0oOOo0O0Ooo
def o0o ( ) :
 if 59 - 59: OoOoOO00 % Oo0Ooo + OoO0O00
 try :
  if 97 - 97: iII111i / oO0o + o0
  II1iIi11 = I11iiii ( ii1iii1i )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for IiI1iiiIii in O0i1iI :
   if 32 - 32: I11ii1 % o0 * oO0o
   try :
    if 72 - 72: I11ii1 . O0O00o0OOO0 - o0 - o00O0oo % OoOoOO00
    oO0o00O0O0oo0 = IiI1iiiIii
    if 24 - 24: o0 * IiII
   except :
    pass
  II1iIi11 = I11iiii ( oO0o00O0O0oo0 )
  O0i1iI = re . compile ( OOoO ) . findall ( II1iIi11 )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 88 - 88: II111iiii + O0O00o0OOO0 * I11i * O0O00o0OOO0 + ooOoO0o
   except :
    pass
 except :
  pass
  if 88 - 88: I1Ii111 % oO0o - O0O00o0OOO0 - I11i % II111iiii
def I1iIIiiiI ( ) :
 if 97 - 97: O0O00o0OOO0 % o00O0oo % I11i / o0oOOo0O0Ooo % I1Ii111
 try :
  if 83 - 83: OOooOOo / O0o / O0o * o0 / o0
  II1iIi11 = I11iiii ( ooOoO00 )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for IiI1iiiIii in O0i1iI :
   if 65 - 65: I11ii1 * ooOoO0o / OOooOOo / OOooOOo
   try :
    if 27 - 27: oO0o
    oO0O0o0o00 = IiI1iiiIii
    if 29 - 29: O0o . I11ii1 - o0oOOo0O0Ooo
   except :
    pass
  II1iIi11 = I11iiii ( oO0O0o0o00 )
  O0i1iI = re . compile ( OOoO ) . findall ( II1iIi11 )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 68 - 68: Oo0Ooo + o0oOOo0O0Ooo / IiII
   except :
    pass
 except :
  pass
  if 91 - 91: I11i % Oo0Ooo . I1ii11iIi11i
def O00ooooo00 ( ) :
 if 94 - 94: ooOoO0o - o0oOOo0O0Ooo . I1ii11iIi11i - oO0o + iII111i * iII111i
 try :
  if 27 - 27: O0o * I1ii11iIi11i . Oo0Ooo - Oo0Ooo
  II1iIi11 = I11iiii ( oooO )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for IiI1iiiIii in O0i1iI :
   if 5 - 5: O0o
   try :
    if 84 - 84: o0oOOo0O0Ooo * IiII * o0oOOo0O0Ooo % O0o / I1ii11iIi11i
    O0Oooo = IiI1iiiIii
    if 27 - 27: I11ii1 + II111iiii * ooOoO0o + I11i + O0O00o0OOO0
   except :
    pass
  II1iIi11 = I11iiii ( O0Oooo )
  O0i1iI = re . compile ( OOoO ) . findall ( II1iIi11 )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 , id , II1III in O0i1iI :
   try :
    OooooO0oOOOO ( iII1i11IIi1i , oOOoo0000O0o0 , o0OOOooo0OOo , id , II1III )
    if 87 - 87: I1IiiI
   except :
    pass
 except :
  pass
  if 87 - 87: Ii1I / o0oOOo0O0Ooo
def O0OOOo000 ( ) :
 if 3 - 3: oO0o % I11ii1 - OoO0O00 * O0O00o0OOO0 . I1Ii111
 try :
  if 46 - 46: II111iiii - I1Ii111 * I1ii11iIi11i * ooOoO0o % iII111i * OoOoOO00
  II1iIi11 = I11iiii ( o0O00Oo0 )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for IiI1iiiIii in O0i1iI :
   if 5 - 5: I1IiiI / I11ii1 . oO0o + OoO0O00
   try :
    if 97 - 97: O0o . o00O0oo . o00O0oo / Oo0Ooo - OOooOOo + O0O00o0OOO0
    II1 = IiI1iiiIii
    if 52 - 52: I11i * OOooOOo - o00O0oo
   except :
    pass
  II1iIi11 = I11iiii ( II1 )
  O0i1iI = re . compile ( ooOOO00Ooo ) . findall ( II1iIi11 )
  for o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 in O0i1iI :
   try :
    OOoOOo0 ( o0OOOooo0OOo , iII1i11IIi1i , oOOoo0000O0o0 )
    if 16 - 16: Ii1I - OOooOOo / o0
   except :
    pass
    if 48 - 48: Oo0Ooo
 except :
  pass
  if 91 - 91: o0oOOo0O0Ooo - I1IiiI . Oo0Ooo . I1IiiI + iII111i - o0oOOo0O0Ooo
  if 26 - 26: Ii1I
  if 12 - 12: OoO0O00 / I1IiiI + o0oOOo0O0Ooo * iII111i
def OOoOOo0 ( thumb , name , url ) :
 if 46 - 46: o0oOOo0O0Ooo - O0o * OoO0O00 / IiII % O0o
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( oOOo0 ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   II1111ii ( name , url , '' , i1ii1iIII , O0oOO0o0 )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 11 - 11: Oo0Ooo . I11i / O0o % I11ii1
  if 'tvg-logo' in thumb :
   thumb = re . compile ( oOOo0 ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 61 - 61: I11ii1 - I1Ii111 + I1Ii111
   iiiIiIIII1iiIIi ( name , url , 4 , O0ooO00oO , O0oOO0o0 )
   if 17 - 17: ooOoO0o
  else :
   if 97 - 97: iII111i * iII111i / O0O00o0OOO0
   iiiIiIIII1iiIIi ( name , url , 4 , O0ooO00oO , O0oOO0o0 )
   if 6 - 6: IiII
def OooooO0oOOOO ( name , url , thumb , id , trailer ) :
 if 72 - 72: ooOoO0o * iII111i - I11i / iII111i + I1Ii111 - O0O00o0OOO0
 if 49 - 49: OOooOOo - I1IiiI / OOooOOo * I11i + o0
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 35 - 35: o0oOOo0O0Ooo . I1ii11iIi11i / OoOoOO00 / I1ii11iIi11i * IiII
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( oOOo0 ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   II1111ii ( name , url , '' , i1ii1iIII , O0oOO0o0 )
 else :
  oO0 = oo000 . getSetting ( 'Fontcolor' )
  if 85 - 85: o0oOOo0O0Ooo . I11ii1 % I1Ii111 % ooOoO0o
  name = '[COLOR %s]' % oO0 + name + '[/COLOR]'
  if 80 - 80: IiII * ooOoO0o / Oo0Ooo % IiII / Oo0Ooo
  if 'tvg-logo' in thumb :
   thumb = re . compile ( oOOo0 ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   oO0Oo = oo000 . getSetting ( 'selecton' )
   if oO0Oo == 'true' :
    if 42 - 42: OoOoOO00 / II111iiii . oO0o * O0O00o0OOO0 . II111iiii * I1IiiI
    Iiii1 ( name , url , 1 , thumb , thumb , id , trailer )
    if 27 - 27: I1Ii111
   else :
    if 52 - 52: o0 % I11i + Oo0Ooo * IiII . o00O0oo
    Iiii1 ( name , url , 130 , thumb , thumb , id , trailer )
    if 95 - 95: Oo0Ooo . O0o - OoO0O00 * OOooOOo / Ii1I
  else :
   if 74 - 74: IiII
   if oO0Oo == 'true' :
    if 34 - 34: O0O00o0OOO0
    Iiii1 ( name , url , 1 , thumb , thumb , id , trailer )
    if 44 - 44: OoOoOO00 % I1ii11iIi11i % Ii1I
   else :
    if 9 - 9: oO0o % OoO0O00 - o00O0oo
    Iiii1 ( name , url , 130 , thumb , thumb , id , trailer )
    if 43 - 43: OOooOOo % OOooOOo
    if 46 - 46: oO0o % Oo0Ooo . O0O00o0OOO0 . I1IiiI * I11ii1 / OoO0O00
def II1iI1IIi ( name , trailer ) :
 if 41 - 41: I1ii11iIi11i - o0 % o0oOOo0O0Ooo . o0 - ooOoO0o
 if oo0OooOOo0 == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Realstream, Reproduciendo Trailer de: [COLOR green]" + name + "[/COLOR] ,5000)" )
  if 45 - 45: o00O0oo - I1Ii111
  oOOoo0000O0o0 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  OOoooO00o0o = oOOoo0000O0o0
  I1ii1Ii1 = xbmcgui . ListItem ( name , trailer , path = OOoooO00o0o )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1ii1Ii1 )
 else :
  oOOoo0000O0o0 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  OOoooO00o0o = oOOoo0000O0o0
  I1ii1Ii1 = xbmcgui . ListItem ( name , trailer , path = OOoooO00o0o )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1ii1Ii1 )
  if 73 - 73: I1IiiI . IiII + II111iiii + Oo0Ooo - ooOoO0o / I11i
  if 99 - 99: iII111i * IiII * iII111i - o0oOOo0O0Ooo + o00O0oo
def OOooO0Oo00 ( trailer ) :
 if 9 - 9: O0o
 oOOoo0000O0o0 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
 OOoooO00o0o = oOOoo0000O0o0
 I1ii1Ii1 = xbmcgui . ListItem ( trailer , path = OOoooO00o0o )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1ii1Ii1 )
 return
 if 48 - 48: Ii1I + Ii1I - oO0o
 if 27 - 27: OOooOOo + I11i * I11ii1
def o0oOoO ( name , url ) :
 import urlresolver
 from urlresolver import common
 if 75 - 75: I11ii1 + OOooOOo - iII111i . OoO0O00 . I11ii1 + I1ii11iIi11i
 iiI1i1Iii111 = urlresolver . HostedMediaFile ( url )
 if 49 - 49: iII111i . O0o . OoOoOO00 * I11i % Oo0Ooo
 if not iiI1i1Iii111 :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
  if 35 - 35: iII111i + o0 - I11i % IiII % Ii1I % I11i
  return False
  if 45 - 45: I1ii11iIi11i * I1Ii111 % OOooOOo
  if 24 - 24: I11ii1 - ooOoO0o * IiII
 try :
  iIII1I1i1i = iiI1i1Iii111 . resolve ( )
  if not iIII1I1i1i or not isinstance ( iIII1I1i1i , basestring ) :
   try : o0OIIiI1I1 = iIII1I1i1i . msg
   except : o0OIIiI1I1 = url
   raise Exception ( o0OIIiI1I1 )
 except Exception as i1iI1 :
  try : o0OIIiI1I1 = str ( i1iI1 )
  except : o0OIIiI1I1 = url
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,5000)" )
  if 87 - 87: o00O0oo - iII111i % iII111i . IiII / iII111i
  return False
  if 6 - 6: I11i / Oo0Ooo * OoO0O00 * II111iiii
 oo0OooOOo0 = oo000 . getSetting ( 'notificar' )
 if oo0OooOOo0 == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
 IiIIiIIIiIii = xbmcgui . ListItem ( path = iIII1I1i1i )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiIIiIIIiIii )
 if 79 - 79: O0o % OOooOOo
def Oo0oOO ( name , url ) :
 if 86 - 86: Oo0Ooo / I1IiiI
 if 17 - 17: o0oOOo0O0Ooo
 if 'https://www.rapidvideo.com/v/' in url :
  if 9 - 9: OoO0O00 + IiII
  II1iIi11 = I11iiii ( url )
  O0i1iI = re . compile ( 'rapidvideo' ) . findall ( II1iIi11 )
  for url in O0i1iI :
   if 33 - 33: I1IiiI
   if 39 - 39: I1ii11iIi11i + oO0o
   try :
    oo0OooOOo0 = oo000 . getSetting ( 'notificar' )
    if oo0OooOOo0 == 'true' :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    IiIIiIIIiIii = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiIIiIIIiIii )
    if 83 - 83: OoOoOO00
   except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 76 - 76: o00O0oo + Oo0Ooo + I11i . OOooOOo
   if 49 - 49: O0o / I11ii1 / I1Ii111
 else :
  if 25 - 25: I1ii11iIi11i % I1IiiI + OoOoOO00 - I11ii1
  import urlresolver
  from urlresolver import common
  if 38 - 38: Ii1I % o0 + II111iiii + O0O00o0OOO0 + I11ii1 / II111iiii
  iiI1i1Iii111 = urlresolver . HostedMediaFile ( url )
  if 94 - 94: O0O00o0OOO0 - oO0o + IiII
  if not iiI1i1Iii111 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 59 - 59: ooOoO0o . I1ii11iIi11i - Oo0Ooo + Oo0Ooo
   if 56 - 56: IiII + I11ii1
  try :
   iIII1I1i1i = iiI1i1Iii111 . resolve ( )
   if not iIII1I1i1i or not isinstance ( iIII1I1i1i , basestring ) :
    try : o0OIIiI1I1 = iIII1I1i1i . msg
    except : o0OIIiI1I1 = url
    raise Exception ( o0OIIiI1I1 )
  except Exception as i1iI1 :
   try : o0OIIiI1I1 = str ( i1iI1 )
   except : o0OIIiI1I1 = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 32 - 32: o0oOOo0O0Ooo + I11i % I11ii1 / I11i + iII111i
  oo0OooOOo0 = oo000 . getSetting ( 'notificar' )
  if oo0OooOOo0 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  IiIIiIIIiIii = xbmcgui . ListItem ( path = iIII1I1i1i )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiIIiIIIiIii )
  if 2 - 2: II111iiii - o0 + OOooOOo % ooOoO0o * o00O0oo
 return
 if 54 - 54: I1IiiI - O0O00o0OOO0 . I1Ii111 % O0O00o0OOO0 + O0O00o0OOO0
 if 36 - 36: I1Ii111 % II111iiii
 if 47 - 47: OoOoOO00 + o0oOOo0O0Ooo . oO0o * IiII . ooOoO0o / OoOoOO00
def i11ii ( name , url ) :
 if 83 - 83: iII111i * iII111i + I1Ii111
 iIII1I1i1i = url
 oo0OooOOo0 = oo000 . getSetting ( 'notificar' )
 if oo0OooOOo0 == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  IiIIiIIIiIii = xbmcgui . ListItem ( path = iIII1I1i1i )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiIIiIIIiIii )
 else :
  IiIIiIIIiIii = xbmcgui . ListItem ( path = iIII1I1i1i )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiIIiIIIiIii )
 return
 if 57 - 57: I1IiiI - I1IiiI . iII111i / Ii1I / o00O0oo
def I1IiII1I1i1I1 ( name , url ) :
 if 28 - 28: oO0o + O0o % o0oOOo0O0Ooo / OOooOOo + II111iiii
 if 20 - 20: iII111i
 if '[Youtube]' in name :
  if 3 - 3: OOooOOo * OoOoOO00 . I1ii11iIi11i . I1IiiI - I11i
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 81 - 81: I1ii11iIi11i - Oo0Ooo / I1ii11iIi11i / I1IiiI
  try :
   oo0OooOOo0 = oo000 . getSetting ( 'notificar' )
   if oo0OooOOo0 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    IiIIiIIIiIii = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiIIiIIIiIii )
    if 34 - 34: o00O0oo * o00O0oo - iII111i - I1IiiI . II111iiii
    if 32 - 32: Oo0Ooo . OOooOOo * IiII / I1Ii111 . o0oOOo0O0Ooo - oO0o
    if 10 - 10: iII111i / II111iiii - o00O0oo + IiII * I1ii11iIi11i
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 94 - 94: I1ii11iIi11i + Oo0Ooo / I1IiiI - OoO0O00 % iII111i
  if 64 - 64: ooOoO0o + OOooOOo
 else :
  if 25 - 25: I1ii11iIi11i . I11ii1 + I1ii11iIi11i % o00O0oo * Oo0Ooo
  import xbmcgui
  import urlresolver
  from urlresolver import common
  if 31 - 31: II111iiii + I1Ii111 - I1IiiI
  iiI1i1Iii111 = urlresolver . HostedMediaFile ( url )
  if 51 - 51: OOooOOo * OoOoOO00 / o00O0oo * I1Ii111 + I11ii1 % iII111i
  if not iiI1i1Iii111 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 34 - 34: IiII * OoO0O00 + o00O0oo + II111iiii
  import resolveurl as urlresolver
  if 22 - 22: OoOoOO00
  iiI1i1Iii111 = urlresolver . HostedMediaFile ( url )
  if 24 - 24: ooOoO0o / I1ii11iIi11i * OoOoOO00 % OoO0O00
  if 99 - 99: II111iiii . o0oOOo0O0Ooo . OoO0O00
  if not iiI1i1Iii111 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 59 - 59: II111iiii . OoO0O00 / ooOoO0o * iII111i + OoO0O00
  try :
   iIII1I1i1i = iiI1i1Iii111 . resolve ( )
   if not iIII1I1i1i or not isinstance ( iIII1I1i1i , basestring ) :
    try : o0OIIiI1I1 = iIII1I1i1i . msg
    except : o0OIIiI1I1 = url
    raise Exception ( o0OIIiI1I1 )
  except Exception as i1iI1 :
   try : o0OIIiI1I1 = str ( i1iI1 )
   except : o0OIIiI1I1 = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 3 - 3: II111iiii * oO0o % Oo0Ooo % I1ii11iIi11i * O0O00o0OOO0 / I1Ii111
   if 95 - 95: O0o * I1IiiI * o0 . OoO0O00 % oO0o + iII111i
   if 98 - 98: IiII . OoO0O00
  oo0OooOOo0 = oo000 . getSetting ( 'notificar' )
  if oo0OooOOo0 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 54 - 54: I1IiiI / O0o % I11ii1 * OoOoOO00 * I1IiiI
   if '[Realstream]' in name :
    if 48 - 48: Ii1I . IiII % I11i - I11i
    I11i1I1I = oo000 . getSetting ( 'restante' )
    if I11i1I1I == 'true' :
     i11iiI1111 = xbmcgui . Dialog ( )
     i1iI11I1II1 = i11iiI1111 . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 33 - 33: ooOoO0o % o0oOOo0O0Ooo + OOooOOo
   IiIIiIIIiIii = xbmcgui . ListItem ( path = iIII1I1i1i )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiIIiIIIiIii )
   if 93 - 93: OoOoOO00 . O0o / I1ii11iIi11i + O0o
   if 58 - 58: iII111i + I1IiiI . oO0o + I11i - OOooOOo - I11i
   if 41 - 41: oO0o / OoOoOO00 / oO0o - O0O00o0OOO0 . Ii1I
 return
 if 65 - 65: I1IiiI * II111iiii . OoO0O00 / I1ii11iIi11i / O0O00o0OOO0
 if 69 - 69: I11ii1 % I11ii1
 if 76 - 76: II111iiii * O0O00o0OOO0 / OOooOOo % iII111i + I1Ii111
def IiIi1II111I ( name , url ) :
 if 80 - 80: o00O0oo / I1Ii111
 if 21 - 21: oO0o - Oo0Ooo - o0
 if '[Youtube]' in name :
  if 1 - 1: I1ii11iIi11i * I1Ii111 + o00O0oo + I1ii11iIi11i - II111iiii
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 79 - 79: I11ii1 . IiII / IiII - I11ii1 * oO0o / Ii1I
  try :
   oo0OooOOo0 = oo000 . getSetting ( 'notificar' )
   if oo0OooOOo0 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    IiIIiIIIiIii = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiIIiIIIiIii )
    if 19 - 19: iII111i
    if 46 - 46: Oo0Ooo . II111iiii - I11i % I1IiiI / o0oOOo0O0Ooo * OoOoOO00
    if 66 - 66: I1IiiI
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 52 - 52: OOooOOo * OoO0O00
 else :
  if 12 - 12: I1IiiI + O0o * OoOoOO00 . OOooOOo
  import resolveurl
  if 71 - 71: o0 - Ii1I - I1Ii111
  iiI1i1Iii111 = urlresolver . HostedMediaFile ( url )
  if 28 - 28: Oo0Ooo
  if 7 - 7: Ii1I % O0o * I11i
  if not iiI1i1Iii111 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 58 - 58: O0o / ooOoO0o + o0oOOo0O0Ooo % O0O00o0OOO0 - OoO0O00
  try :
   iIII1I1i1i = iiI1i1Iii111 . resolve ( )
   if not iIII1I1i1i or not isinstance ( iIII1I1i1i , basestring ) :
    try : o0OIIiI1I1 = iIII1I1i1i . msg
    except : o0OIIiI1I1 = url
    raise Exception ( o0OIIiI1I1 )
  except Exception as i1iI1 :
   try : o0OIIiI1I1 = str ( i1iI1 )
   except : o0OIIiI1I1 = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 25 - 25: I11i % OoO0O00 * oO0o - OoOoOO00 * o0oOOo0O0Ooo * IiII
   if 30 - 30: ooOoO0o % I11i / iII111i * I1IiiI * o00O0oo . I1ii11iIi11i
   if 46 - 46: I11i - I1IiiI
  oo0OooOOo0 = oo000 . getSetting ( 'notificar' )
  if oo0OooOOo0 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 70 - 70: ooOoO0o + oO0o * Oo0Ooo . I1ii11iIi11i * ooOoO0o
   if '[Realstream]' in name :
    if 49 - 49: Ii1I
    I11i1I1I = oo000 . getSetting ( 'restante' )
    if I11i1I1I == 'true' :
     i11iiI1111 = xbmcgui . Dialog ( )
     i1iI11I1II1 = i11iiI1111 . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 25 - 25: O0O00o0OOO0 . OoO0O00 * Oo0Ooo . Ii1I / I1IiiI + o00O0oo
   IiIIiIIIiIii = xbmcgui . ListItem ( path = iIII1I1i1i )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiIIiIIIiIii )
   if 68 - 68: oO0o
   if 22 - 22: I1Ii111
   if 22 - 22: O0O00o0OOO0 * ooOoO0o - oO0o * I1IiiI / II111iiii
 return
 if 78 - 78: oO0o * I1IiiI / I11ii1 + OoO0O00 + I1Ii111
 if 23 - 23: O0O00o0OOO0 % OoO0O00 / Oo0Ooo + iII111i / OoOoOO00 / Ii1I
 if 94 - 94: OoOoOO00
def iiIIi1 ( name , url ) :
 if 65 - 65: OoOoOO00 . iII111i / I11ii1
 if 11 - 11: O0o * I11ii1 / I11ii1 - I1Ii111
 if '[Youtube]' in name :
  if 68 - 68: I1ii11iIi11i % O0o - O0o / I1ii11iIi11i + iII111i - oO0o
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 65 - 65: I11ii1 - OoOoOO00
  try :
   oo0OooOOo0 = oo000 . getSetting ( 'notificar' )
   if oo0OooOOo0 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    IiIIiIIIiIii = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiIIiIIIiIii )
    if 62 - 62: ooOoO0o / IiII % oO0o . OoO0O00 / II111iiii / o0
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 60 - 60: I1ii11iIi11i % IiII / Ii1I % IiII * II111iiii / O0O00o0OOO0
 else :
  if 34 - 34: o0 - I1Ii111
  if 'https://team.com' in url :
   if 25 - 25: IiII % I1ii11iIi11i + II111iiii + I1IiiI * OoO0O00
   url = url . replace ( 'https://team.com' , 'https://verystream.com' )
   if 64 - 64: OoOoOO00
  if 'https://mybox.com' in url :
   if 10 - 10: o0 % I1IiiI / I1ii11iIi11i % ooOoO0o
   url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
   if 25 - 25: o0oOOo0O0Ooo / OOooOOo
  if 'https://drive.com' in url :
   if 64 - 64: I1IiiI % I11ii1
   url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
   if 40 - 40: Ii1I + ooOoO0o
  if 'https://vidcloud.co' in url :
   if 77 - 77: II111iiii % O0o + o0 % OoO0O00 - ooOoO0o
   url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
   if 26 - 26: oO0o + I1IiiI - Oo0Ooo
  if 'https://gounlimited.to' in url :
   if 47 - 47: OoO0O00
   url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
   if 2 - 2: I11i % o0 * oO0o * I11i
  import resolveurl
  if 65 - 65: II111iiii + oO0o * OoO0O00 - OOooOOo
  iiI1i1Iii111 = urlresolver . HostedMediaFile ( url )
  if 26 - 26: Ii1I % I1Ii111 + I1Ii111 % ooOoO0o * II111iiii / O0O00o0OOO0
  if 64 - 64: IiII % I11i / o0oOOo0O0Ooo % I11ii1 - O0O00o0OOO0
  if not iiI1i1Iii111 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no encontrado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 2 - 2: o0 - iII111i + Ii1I * OOooOOo / O0O00o0OOO0
  try :
   iIII1I1i1i = iiI1i1Iii111 . resolve ( )
   if not iIII1I1i1i or not isinstance ( iIII1I1i1i , basestring ) :
    try : o0OIIiI1I1 = iIII1I1i1i . msg
    except : o0OIIiI1I1 = url
    raise Exception ( o0OIIiI1I1 )
  except Exception as i1iI1 :
   try : o0OIIiI1I1 = str ( i1iI1 )
   except : o0OIIiI1I1 = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace borrado, o no encontrado. Prueba a reiniciar el router o poner una VPN.[/COLOR]  ,5000)" )
   return False
   if 26 - 26: I1Ii111 * oO0o
   if 31 - 31: ooOoO0o * IiII . o00O0oo
   if 35 - 35: ooOoO0o
   oo0OooOOo0 = oo000 . getSetting ( 'notificar' )
   if oo0OooOOo0 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
    if 94 - 94: I11ii1 / II111iiii % I1IiiI
    if '[Realstream]' or '[Mybox]' in name :
     I11i1I1I = oo000 . getSetting ( 'restante' )
    elif I11i1I1I == 'true' :
     i11iiI1111 = xbmcgui . Dialog ( )
     i1iI11I1II1 = i11iiI1111 . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 70 - 70: ooOoO0o - oO0o / OoO0O00 % OoO0O00
  IiIIiIIIiIii = xbmcgui . ListItem ( path = iIII1I1i1i )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiIIiIIIiIii )
  if 95 - 95: OoO0O00 % OoO0O00 . o00O0oo
 return
 if 26 - 26: IiII + O0o - o0oOOo0O0Ooo . o0oOOo0O0Ooo + iII111i + I11i
def o0IiIiI111IIII1 ( name , url ) :
 if 100 - 100: I1Ii111 * I1IiiI + I1ii11iIi11i + I11i . I1Ii111
 if 73 - 73: IiII . o0oOOo0O0Ooo * O0O00o0OOO0 % IiII + I11i - OOooOOo
 if '[Youtube]' in name :
  if 19 - 19: O0O00o0OOO0 * oO0o . O0O00o0OOO0 . OOooOOo / OOooOOo - IiII
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 9 - 9: o0 * O0o * o0
  try :
   oo0OooOOo0 = oo000 . getSetting ( 'notificar' )
   if oo0OooOOo0 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    IiIIiIIIiIii = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiIIiIIIiIii )
    if 74 - 74: Oo0Ooo / Ii1I
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 58 - 58: Oo0Ooo - I1ii11iIi11i % Ii1I % OoO0O00 * Oo0Ooo + I1Ii111
 else :
  if 25 - 25: I1Ii111 % I1IiiI
  if 'https://team.com' in url :
   if 44 - 44: o0 . o00O0oo * o0oOOo0O0Ooo / O0o + Oo0Ooo
   url = url . replace ( 'https://team.com' , 'https://verystream.com' )
   if 14 - 14: I1IiiI % O0o % o00O0oo * IiII
  if 'https://mybox.com' in url :
   if 65 - 65: ooOoO0o % IiII + iII111i
   url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
   if 86 - 86: Oo0Ooo / I1IiiI . o0 % Oo0Ooo % oO0o
  if 'https://drive.com' in url :
   if 86 - 86: II111iiii - Ii1I . I11ii1 * oO0o / o00O0oo % Ii1I
   url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
   if 61 - 61: Ii1I + I11i
  if 'https://vid.co' in url :
   if 15 - 15: I11i * IiII + I1Ii111 . ooOoO0o % I1ii11iIi11i - I11ii1
   url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
   if 13 - 13: I11i % I11i % oO0o % I1ii11iIi11i * OoOoOO00 % ooOoO0o
  if 'https://limited.to' in url :
   if 82 - 82: O0o . I11i / I11ii1 + O0O00o0OOO0 - I11ii1
   url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
   if 55 - 55: I11ii1 % oO0o % Ii1I
  import resolveurl
  if 29 - 29: O0o / Oo0Ooo + iII111i % O0O00o0OOO0 % ooOoO0o
  iiI1i1Iii111 = urlresolver . HostedMediaFile ( url )
  i1i = xbmcgui . DialogProgress ( )
  i1i . create ( 'RESOLVEURL:' , 'Conectando al servidor ... ' )
  i1i . update ( 20 , 'Por favor, espere ...' )
  xbmc . sleep ( 1000 )
  if 15 - 15: ooOoO0o % II111iiii
  if not iiI1i1Iii111 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no encontrado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 73 - 73: I11ii1 % I11ii1 . O0O00o0OOO0 + o0
  try :
   i1i . update ( 30 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
   i1i . update ( 35 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
   i1i . update ( 40 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
   i1i . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
   i1i . update ( 55 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
   xbmc . sleep ( 1000 )
   iIII1I1i1i = iiI1i1Iii111 . resolve ( )
   if not iIII1I1i1i or not isinstance ( iIII1I1i1i , basestring ) :
    try : o0OIIiI1I1 = iIII1I1i1i . msg
    except : o0OIIiI1I1 = url
    raise Exception ( o0OIIiI1I1 )
  except Exception as i1iI1 :
   try : o0OIIiI1I1 = str ( i1iI1 )
   except : o0OIIiI1I1 = url
   i1i . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado, o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
   i1i . close ( )
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace borrado, o no encontrado. Prueba a reiniciar el router o poner una VPN.[/COLOR]  ,5000)" )
   return False
   if 10 - 10: I1IiiI / I1Ii111 * I11ii1 - OOooOOo - OoOoOO00 . I11i
   if 69 - 69: oO0o - o00O0oo % o00O0oo - I1Ii111 * I1Ii111 / oO0o
  i1i . update ( 30 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
  i1i . update ( 35 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
  i1i . update ( 40 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
  i1i . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
  i1i . update ( 55 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
  i1i . update ( 65 , 'RESOLVEURL:' , 'Por favor, espere ...' )
  xbmc . sleep ( 1000 )
  i1i . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
  xbmc . sleep ( 1000 )
  i1i . update ( 80 , 'RESOLVEURL:' , 'Por favor, espere ...' )
  i1i . update ( 85 , 'RESOLVEURL:' , 'Por favor, espere ...' )
  i1i . update ( 95 , 'RESOLVEURL:' , 'Por favor, espere ...' )
  i1i . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
  i1i . close ( )
  oo0OooOOo0 = oo000 . getSetting ( 'notificar' )
  if oo0OooOOo0 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
   if 13 - 13: I11i
  if '[Realstream]' or '[Mybox]' in name :
   I11i1I1I = oo000 . getSetting ( 'restante' )
  elif I11i1I1I == 'true' :
   i11iiI1111 = xbmcgui . Dialog ( )
   i1iI11I1II1 = i11iiI1111 . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
  IiIIiIIIiIii = xbmcgui . ListItem ( path = iIII1I1i1i )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiIIiIIIiIii )
  if 67 - 67: iII111i . o0oOOo0O0Ooo - o00O0oo % OoO0O00
 return
 if 49 - 49: iII111i + I1IiiI . o00O0oo * OoO0O00
def oO0OOO00 ( ) :
 if 13 - 13: O0o * iII111i / iII111i / Oo0Ooo % Oo0Ooo
 if 21 - 21: iII111i
 oOOOO0oo0O0OO = [ ]
 O0OOoo0o = sys . argv [ 2 ]
 if len ( O0OOoo0o ) >= 2 :
  i1IiIiIiiI1 = sys . argv [ 2 ]
  iI1Ii = i1IiIiIiiI1 . replace ( '?' , '' )
  if ( i1IiIiIiiI1 [ len ( i1IiIiIiiI1 ) - 1 ] == '/' ) :
   i1IiIiIiiI1 = i1IiIiIiiI1 [ 0 : len ( i1IiIiIiiI1 ) - 2 ]
  OoOO0OOo0O = iI1Ii . split ( '&' )
  oOOOO0oo0O0OO = { }
  for Ii in range ( len ( OoOO0OOo0O ) ) :
   IIi1iiI = { }
   IIi1iiI = OoOO0OOo0O [ Ii ] . split ( '=' )
   if ( len ( IIi1iiI ) ) == 2 :
    oOOOO0oo0O0OO [ IIi1iiI [ 0 ] ] = IIi1iiI [ 1 ]
 return oOOOO0oo0O0OO
 if 97 - 97: o0 . ooOoO0o / I1ii11iIi11i
 if 83 - 83: ooOoO0o - iII111i * IiII
def oOO00OO0OooOo ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  import urlresolver
  xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
  if 13 - 13: I1IiiI % I11ii1 % ooOoO0o
def Ii11IiI111 ( ) :
 i11iiI1111 = xbmcgui . Dialog ( )
 list = (
 IIiii11ii1II1 ,
 o0OO000O
 )
 if 62 - 62: ooOoO0o % ooOoO0o % ooOoO0o / O0O00o0OOO0 * Ii1I * IiII
 I1Iiiiiii = i11iiI1111 . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=%s]Accede a themoviedb.com[/COLOR]' % Ii1iIiII1ii1 ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 61 - 61: O0o % OoOoOO00 - O0O00o0OOO0 . I11ii1 - oO0o + oO0o
 if I1Iiiiiii :
  if 12 - 12: Ii1I / Oo0Ooo % o0oOOo0O0Ooo / ooOoO0o / OoOoOO00 - I1ii11iIi11i
  if I1Iiiiiii < 0 :
   return
  o0ooO = list [ I1Iiiiiii - 2 ]
  return o0ooO ( )
 else :
  o0ooO = list [ I1Iiiiiii ]
  return o0ooO ( )
 return
 if 94 - 94: II111iiii % IiII + oO0o + IiII
def Iii ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 33 - 33: O0o . oO0o / Oo0Ooo
iIIiii1 = Iii ( )
if 50 - 50: Ii1I
def IIiii11ii1II1 ( ) :
 if iIIiii1 == 'android' :
  ooOooo0 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  ooOooo0 = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 16 - 16: I11i
  if 16 - 16: oO0o / OOooOOo / O0O00o0OOO0 / Oo0Ooo
def o0OO000O ( ) :
 if 44 - 44: oO0o . oO0o + OoO0O00 * II111iiii / ooOoO0o + o0
 main ( )
 if 17 - 17: I1Ii111 + o0oOOo0O0Ooo
 if 43 - 43: ooOoO0o % o00O0oo / Ii1I * o0
 if 85 - 85: Oo0Ooo . OoO0O00 . Ii1I
def oO00OoO0oo ( ) :
 i11iiI1111 = xbmcgui . Dialog ( )
 oOoooo000Oo00 = (
 o00o0o000Oo ,
 Oooo00OOo
 )
 if 6 - 6: IiII / I1ii11iIi11i / I11i
 I1Iiiiiii = i11iiI1111 . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 51 - 51: o0oOOo0O0Ooo / oO0o / I1ii11iIi11i + II111iiii
 if I1Iiiiiii :
  if 5 - 5: ooOoO0o
  if I1Iiiiiii < 0 :
   return
  o0ooO = oOoooo000Oo00 [ I1Iiiiiii - 2 ]
  return o0ooO ( )
 else :
  o0ooO = oOoooo000Oo00 [ I1Iiiiiii ]
  return o0ooO ( )
 return
 if 22 - 22: Oo0Ooo * o0 / oO0o
def Iii ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 31 - 31: II111iiii
iIIiii1 = Iii ( )
if 56 - 56: ooOoO0o / o00O0oo + oO0o - OoOoOO00 - O0o + Oo0Ooo
def o00o0o000Oo ( ) :
 if iIIiii1 == 'android' :
  ooOooo0 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  ooOooo0 = webbrowser . open ( 'https://olpair.com/' )
  if 75 - 75: iII111i
  if 92 - 92: ooOoO0o / I1IiiI * I1ii11iIi11i - ooOoO0o
def Oooo00OOo ( ) :
 if 99 - 99: II111iiii % OoO0O00
 main ( )
 if 56 - 56: O0o * o0
 if 98 - 98: ooOoO0o + I1IiiI * o0 + II111iiii - I1Ii111 - Oo0Ooo
def I11I111i1I1 ( name , url , id , trailer ) :
 i11iiI1111 = xbmcgui . Dialog ( )
 oOoooo000Oo00 = (
 iii1 ,
 O0Ooo0O ,
 iii1oOo0OoOOOo0 ,
 Ii11IiI111 ,
 OOoo00
 )
 if 22 - 22: I11ii1 / I11ii1 - o00O0oo % ooOoO0o . I1Ii111 + O0o
 I1Iiiiiii = i11iiI1111 . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % Ii1iIiII1ii1 ,

 '[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % Ii1iIiII1ii1 ,

 '[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % Ii1iIiII1ii1 ,

 '[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % Ii1iIiII1ii1 ,

 '[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % Ii1iIiII1ii1 ] )
 if 64 - 64: OoOoOO00 % iII111i / o00O0oo % OoO0O00
 if I1Iiiiiii :
  if 24 - 24: o0 + OoO0O00 . O0o / I11i / ooOoO0o
  if I1Iiiiiii < 0 :
   return
  o0ooO = oOoooo000Oo00 [ I1Iiiiiii - 5 ]
  return o0ooO ( )
 else :
  o0ooO = oOoooo000Oo00 [ I1Iiiiiii ]
  return o0ooO ( )
 return
 if 65 - 65: OoO0O00
 if 18 - 18: I1IiiI - OoOoOO00 . o0
 if 98 - 98: Ii1I
def iii1 ( ) :
 if 73 - 73: oO0o - O0O00o0OOO0 . IiII % OoOoOO00 . I1IiiI
 o0IiIiI111IIII1 ( iII1i11IIi1i , oOOoo0000O0o0 )
 if 15 - 15: I11ii1 . Oo0Ooo * I1ii11iIi11i % ooOoO0o
def O0Ooo0O ( ) :
 if 21 - 21: OOooOOo - I1ii11iIi11i . OoO0O00
 II1iI1IIi ( iII1i11IIi1i , II1III )
 if 6 - 6: Oo0Ooo - Oo0Ooo % Ii1I / Oo0Ooo * o0
def iii1oOo0OoOOOo0 ( ) :
 if 3 - 3: I1Ii111 . O0o / oO0o
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  OooIIi111 = id
  if 61 - 61: iII111i - I1Ii111
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % OooIIi111 )
  if 16 - 16: O0O00o0OOO0 / Oo0Ooo + I1Ii111 * O0O00o0OOO0 * ooOoO0o
 if oo0OooOOo0 == 'true' :
  if 8 - 8: o0
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + iII1i11IIi1i + "[/COLOR] ,5000)" )
  if 15 - 15: oO0o / o00O0oo % I1IiiI + iII111i
def o0oi1I1I1I ( ) :
 if 25 - 25: Ii1I + O0O00o0OOO0 - oO0o
 Ii11IiI111 ( )
 if 59 - 59: I1Ii111 - ooOoO0o % OoOoOO00
def OOoo00 ( ) :
 if 1 - 1: iII111i . o0 * I1ii11iIi11i . O0o * o0oOOo0O0Ooo % Oo0Ooo
 OoOoI1iI11iIiIi1 ( )
def II1111ii ( name , url , mode , iconimage , fanart ) :
 if 86 - 86: OoOoOO00 * I1IiiI % I11ii1 . oO0o % I11ii1 . oO0o
 II11 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 i1iI11I1II1 = True
 Iiii11iIi1 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 Iiii11iIi1 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 Iiii11iIi1 . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  II11 = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  i1iI11I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II11 , listitem = Iiii11iIi1 , isFolder = True )
  return i1iI11I1II1
 i1iI11I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II11 , listitem = Iiii11iIi1 , isFolder = True )
 return i1iI11I1II1
 if 71 - 71: O0O00o0OOO0 . II111iiii * I1IiiI + I1IiiI
def Iiii1 ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 57 - 57: OoO0O00 . ooOoO0o % o0oOOo0O0Ooo % I1ii11iIi11i + o00O0oo
 OOoOO0oo0ooO = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 70 - 70: O0o . II111iiii
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 O0O00O0Oo0 = [ ]
 if 53 - 53: OoOoOO00 . OoOoOO00 - ooOoO0o / O0O00o0OOO0 - I11i % I1ii11iIi11i
 O0O00O0Oo0 . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 II11 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 Iiii11iIi1 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 Iiii11iIi1 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 Iiii11iIi1 . setProperty ( 'fanart_image' , fanart )
 Iiii11iIi1 . setProperty ( 'IsPlayable' , 'true' )
 if 65 - 65: O0O00o0OOO0 . OoO0O00 - I1IiiI . O0O00o0OOO0 - II111iiii
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  O0O00O0Oo0 . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 29 - 29: iII111i . I1ii11iIi11i % IiII - II111iiii
  Iiii11iIi1 . addContextMenuItems ( O0O00O0Oo0 , replaceItems = True )
 i1iI11I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II11 , listitem = Iiii11iIi1 )
 return i1iI11I1II1
 if 27 - 27: iII111i - II111iiii % o0 / oO0o . oO0o / OoO0O00
def iiiIiIIII1iiIIi ( name , url , mode , iconimage , fanart ) :
 if 76 - 76: ooOoO0o * OOooOOo . Oo0Ooo % OoO0O00 % iII111i
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 39 - 39: o0oOOo0O0Ooo * I11i . I1IiiI * ooOoO0o
 II11 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 Iiii11iIi1 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 Iiii11iIi1 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 Iiii11iIi1 . setProperty ( 'fanart_image' , fanart )
 Iiii11iIi1 . setProperty ( 'IsPlayable' , 'true' )
 i1iI11I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II11 , listitem = Iiii11iIi1 )
 return i1iI11I1II1
 if 89 - 89: o00O0oo - I11ii1 . ooOoO0o - o0 - I1ii11iIi11i
def o0O00O ( name , url , mode ) :
 if 21 - 21: OoO0O00 . I11i - Oo0Ooo % O0o
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 55 - 55: I1IiiI % I1ii11iIi11i . OoO0O00 * oO0o / OoO0O00 . o00O0oo
 II11 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 Iiii11iIi1 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = O0ooO00oO )
 Iiii11iIi1 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 Iiii11iIi1 . setProperty ( 'fanart_image' , O0oOO0o0 )
 Iiii11iIi1 . setProperty ( 'IsPlayable' , 'true' )
 i1iI11I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II11 , listitem = Iiii11iIi1 )
 return i1iI11I1II1
 if 26 - 26: O0o / Oo0Ooo - Oo0Ooo
def oO00oO00O0Oo ( name , url , mode , iconimage ) :
 II11 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 i1iI11I1II1 = True
 Iiii11iIi1 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1iI11I1II1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II11 , listitem = Iiii11iIi1 , isFolder = True )
 return i1iI11I1II1
 if 88 - 88: IiII - OoOoOO00 % II111iiii % o0oOOo0O0Ooo * OoO0O00
def iIiII1 ( ) :
 if 47 - 47: ooOoO0o
 if 92 - 92: OoO0O00 % I1ii11iIi11i / I11i * I11i % II111iiii / OoO0O00
 if 47 - 47: II111iiii / oO0o - oO0o * OOooOOo
 O0OoooO0 = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 O0OoooO0 . doModal ( )
 if ( O0OoooO0 . isConfirmed ( ) ) :
  if 48 - 48: O0o
  iI1i11II1i = urllib . quote_plus ( O0OoooO0 . getText ( ) ) . replace ( '+' , ' ' )
  if 96 - 96: IiII / I1IiiI . o0oOOo0O0Ooo + O0o % Ii1I
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 67 - 67: I1IiiI % o0
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % iI1i11II1i )
    if 35 - 35: I1ii11iIi11i . I11i + OoO0O00 % oO0o % I1Ii111
    if oo0OooOOo0 == 'true' :
     if 39 - 39: o00O0oo
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + iII1i11IIi1i + "[/COLOR] ,10000)" )
     if 60 - 60: I1Ii111
   except :
    if 62 - 62: o0 * ooOoO0o
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 74 - 74: I11i . Oo0Ooo
    if 87 - 87: I11ii1
    if 41 - 41: I11i . Oo0Ooo % I11ii1 + I1IiiI
i1IiIiIiiI1 = oO0OOO00 ( )
oOOoo0000O0o0 = None
iII1i11IIi1i = None
IIiII11 = None
O0ooO00oO = None
id = None
II1III = None
if 58 - 58: O0O00o0OOO0
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 2 - 2: O0o - IiII % OOooOOo + Ii1I + o00O0oo - Oo0Ooo
try :
 oOOoo0000O0o0 = urllib . unquote_plus ( i1IiIiIiiI1 [ "url" ] )
except :
 pass
try :
 iII1i11IIi1i = urllib . unquote_plus ( i1IiIiIiiI1 [ "name" ] )
except :
 pass
try :
 IIiII11 = int ( i1IiIiIiiI1 [ "mode" ] )
except :
 pass
try :
 O0ooO00oO = urllib . unquote_plus ( i1IiIiIiiI1 [ "iconimage" ] )
except :
 pass
try :
 id = int ( i1IiIiIiiI1 [ "id" ] )
except :
 pass
try :
 II1III = urllib . unquote_plus ( i1IiIiIiiI1 [ "trailer" ] )
except :
 pass
 if 18 - 18: iII111i / oO0o - O0O00o0OOO0
 if 69 - 69: IiII / O0o * I11ii1
print "Mode: " + str ( IIiII11 )
print "URL: " + str ( oOOoo0000O0o0 )
print "Name: " + str ( iII1i11IIi1i )
print "iconimage: " + str ( O0ooO00oO )
print "id: " + str ( id )
print "trailer: " + str ( II1III )
if 81 - 81: IiII
if IIiII11 == None or oOOoo0000O0o0 == None or len ( oOOoo0000O0o0 ) < 1 :
 if OOO00O == OOoOO0oo0ooO :
  if 62 - 62: o00O0oo + I1IiiI * OOooOOo
  OOOiII1 ( )
  O0O0Oo00 ( )
  if 59 - 59: o0oOOo0O0Ooo
  if 43 - 43: oO0o + OoO0O00
  i1I1iI = oo000 . getSetting ( 'licencia_addon' )
  iiioOooOOOoOo = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  if 47 - 47: I11ii1
  i1Iii1i1I = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  o00oOoo0o00 = oo000 . getSetting ( 'key_ext' )
  II1iIi11 = I11iiii ( i1Iii1i1I )
  O0i1iI = re . compile ( o0O0OOO0Ooo ) . findall ( II1iIi11 )
  for iIiiI11II11i in O0i1iI :
   try :
    if 98 - 98: O0O00o0OOO0 - O0O00o0OOO0
    if 58 - 58: IiII
    i1I1iI = oo000 . getSetting ( 'licencia_addon' )
    if 98 - 98: Ii1I * OOooOOo
    if 10 - 10: IiII - O0O00o0OOO0 % o0oOOo0O0Ooo - o0 - OoOoOO00
    if i1I1iI == iIiiI11II11i :
     if 10 - 10: iII111i - ooOoO0o . o0
     xbmcgui . Dialog ( ) . ok ( "Realstream Licencia:" , "[COLOR lime]Su llave es correcta![/COLOR] [COLOR gold]Sientese y disfrute de Realstream.[/COLOR]" )
     if 8 - 8: Oo0Ooo % IiII + oO0o
     OoOoI1iI11iIiIi1 ( )
     if 24 - 24: Ii1I / o00O0oo / o00O0oo % o0oOOo0O0Ooo - IiII * IiII
    else :
     if 58 - 58: I11i
     xbmcgui . Dialog ( ) . ok ( "Realstream Licencia:" , "[COLOR red]Ha introducido una llave erronea.[/COLOR] [COLOR gold]Ponganse en contacto con nosotros en nuestro grupo de telegram.[/COLOR]" )
     if 60 - 60: o0oOOo0O0Ooo
     if 90 - 90: I11i
   except :
    pass
    if 37 - 37: I11i + I1IiiI . I1IiiI * oO0o % o0 / O0O00o0OOO0
 else :
  xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red][B]Error, de inicio. ¿Tienes Instalado Realstream?[/B][/COLOR]" )
  if 18 - 18: OoO0O00
  if 57 - 57: I11ii1 . I11i * Ii1I - OoO0O00
  if 75 - 75: II111iiii / Ii1I . O0o . OoOoOO00 . OoOoOO00 / ooOoO0o
elif IIiII11 == 1 :
 I11I111i1I1 ( iII1i11IIi1i , oOOoo0000O0o0 , id , II1III )
elif IIiII11 == 2 :
 O0O00OOo ( )
elif IIiII11 == 3 :
 III1IiIII1 ( )
elif IIiII11 == 4 :
 o0oOoO ( iII1i11IIi1i , oOOoo0000O0o0 )
elif IIiII11 == 5 :
 I1iI1I1 ( )
elif IIiII11 == 6 :
 oo0o0oOo ( )
elif IIiII11 == 7 :
 OOO0o ( )
elif IIiII11 == 8 :
 I1Iii1iI1 ( )
elif IIiII11 == 9 :
 Oooo00oOo ( )
elif IIiII11 == 10 :
 OOoO00ooO ( )
elif IIiII11 == 11 :
 oo0ooooO ( )
elif IIiII11 == 12 :
 ii111Iiii ( )
elif IIiII11 == 13 :
 IiI1iiI1III1I ( )
elif IIiII11 == 14 :
 o0oO00 ( )
elif IIiII11 == 15 :
 oOIIIiI1ii1IIi ( )
elif IIiII11 == 16 :
 I1IIiiI1II1 ( )
elif IIiII11 == 17 :
 oO0O ( )
elif IIiII11 == 18 :
 Oo0oOo0ooOOOo ( )
elif IIiII11 == 19 :
 iii11i1 ( )
elif IIiII11 == 20 :
 iiii1i1II1 ( )
elif IIiII11 == 21 :
 o0oo0Ooooo0 ( )
elif IIiII11 == 22 :
 oOOoo ( )
elif IIiII11 == 23 :
 I1Iii1Ii1i1 ( )
elif IIiII11 == 24 :
 o0o ( )
elif IIiII11 == 25 :
 I1iIIiiiI ( )
elif IIiII11 == 26 :
 ooO000O ( )
elif IIiII11 == 28 :
 OO0oIII111i11IiI ( iII1i11IIi1i , oOOoo0000O0o0 )
elif IIiII11 == 29 :
 IiiiIi1iI1iI ( )
elif IIiII11 == 30 :
 iIIIiIi1I1i ( )
elif IIiII11 == 98 :
 busqueda_global ( )
elif IIiII11 == 97 :
 oO00OoO0oo ( )
elif IIiII11 == 99 :
 oO00OoOO ( )
elif IIiII11 == 100 :
 menu_player ( iII1i11IIi1i , oOOoo0000O0o0 )
elif IIiII11 == 111 :
 o0OoOo00o0o ( )
elif IIiII11 == 115 :
 II1iI1IIi ( oOOoo0000O0o0 )
elif IIiII11 == 116 :
 Oo ( )
elif IIiII11 == 117 :
 II1IiiIii ( )
elif IIiII11 == 119 :
 oOOOO ( )
elif IIiII11 == 120 :
 IiI1i ( )
elif IIiII11 == 121 :
 OOOoO000 ( )
elif IIiII11 == 125 :
 O0OOOo000 ( )
elif IIiII11 == 112 :
 iIi1 ( )
elif IIiII11 == 127 :
 iIiII1 ( )
elif IIiII11 == 128 :
 TESTLINKS ( )
elif IIiII11 == 130 :
 o0IiIiI111IIII1 ( iII1i11IIi1i , oOOoo0000O0o0 )
elif IIiII11 == 140 :
 OoO ( )
elif IIiII11 == 141 :
 O00ooooo00 ( )
elif IIiII11 == 142 :
 O0Oo00 ( )
elif IIiII11 == 143 :
 iioo0o0OoOOO ( iII1i11IIi1i , oOOoo0000O0o0 )
elif IIiII11 == 144 :
 OO0oIII111i11IiI ( iII1i11IIi1i , oOOoo0000O0o0 )
elif IIiII11 == 145 :
 OooOOOOoO00OoOO ( )
 if 94 - 94: I11ii1 + I1ii11iIi11i
xbmcplugin . endOfDirectory ( oOOo ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
