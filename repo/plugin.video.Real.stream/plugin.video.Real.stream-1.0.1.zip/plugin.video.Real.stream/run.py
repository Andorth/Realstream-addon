# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 1.0.0
#
############################################
# Dependencias 
# Script ExtendedInfo
# Script Urlresolver de TVAddons
# Script ResolveURL Por Jsergio.
#
############################################
#
# Corregida fallo que producia cuelgue de kodi al realstream no encontrar un enlace.
# Adaptacion del codigo fuente a kodi 18.4
#
############################################
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import urlresolver
import cookielib , base64
import requests
import plugintools
import config
oo000 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
ii = oo000 . getAddonInfo ( 'version' )
oOOo = int ( sys . argv [ 1 ] )
O0 = 'gruponetai/'
o0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
iI11I1II1I1I = o0O . getAddonInfo ( 'profile' )
oooo = o0O . getAddonInfo ( 'path' )
iIIii1IIi = oo000 . getSetting ( 'iconos' )
if 73 - 73: II111iiii
def IiII1IiiIiI1 ( ) :
 if 40 - 40: oo * OoO0O00
 IIiIiII11i = oo000 . getSetting ( 'licencia_addon' )
 o0oOOo0O0Ooo = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 I1ii11iIi11i = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 I1IiI = oo000 . getSetting ( 'key_ext' )
 o0OOO = iIiiiI ( I1ii11iIi11i )
 Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
 for IiII in Iii1ii1II11i :
  try :
   if 28 - 28: Ii11111i * iiI1i1
   if 46 - 46: Ooo0OO0oOO * Ii * Oo0o
   IIiIiII11i = oo000 . getSetting ( 'licencia_addon' )
   if 60 - 60: Oo0oO0oo0oO00 + i11Ii11I1Ii1i . ooO - IiIiI11iIi
   if 1 - 1: IIii11I1 - i1111 - i1IIi11111i / I11i1i11i1I % Iiii
   if IIiIiII11i == IiII :
    if 87 - 87: oO0o0o0ooO0oO / I1i1I - OoOoo0 % Ii % Oo0oO0oo0oO00 / Oo0oO0oo0oO00
    if 30 - 30: Oo0oO0oo0oO00
    if 95 - 95: IIii11I1 * ooO / Ooo0OO0oOO . IiIiI11iIi + i1111
    iI11 ( )
    if 17 - 17: ooO
   else :
    if 64 - 64: I11i1i11i1I % iiI1i1 % Ii11111i
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold]>El addon esta desactivado.[/COLOR]" )
    if 3 - 3: Iiii + oo
    if 42 - 42: i1111 / iiI1i1 + II111iiii - I11i1i11i1I
  except :
   pass
   if 78 - 78: Oo0oO0oo0oO00
   if 18 - 18: oo - Iiii / Iiii + OoOoo0 % OoOoo0 - oO0o0o0ooO0oO
   if 62 - 62: Iiii - oO0o0o0ooO0oO - i11Ii11I1Ii1i % iiI1i1 / IIii11I1
   if 77 - 77: Ooo0OO0oOO - Ooo0OO0oOO . Ii / ooO
if iIIii1IIi == 'true' :
 if 14 - 14: i1IIi11111i % oo
 IiI1I1 = xbmc . translatePath ( os . path . join ( oooo , 'fanart.png' ) )
 OoO000 = xbmc . translatePath ( os . path . join ( oooo , 'icon.png' ) )
 IIiiIiI1 = xbmc . translatePath ( os . path . join ( oooo , 'extended_info.png' ) )
 iiIiIIi = xbmc . translatePath ( os . path . join ( oooo , 'buscar.png' ) )
 ooOoo0O = xbmc . translatePath ( os . path . join ( oooo , 'pair.png' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( oooo , 'theMovieDB.png' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( oooo , 'novedades.png' ) )
 OO0o = xbmc . translatePath ( os . path . join ( oooo , 'estrenos.png' ) )
 Ooo = xbmc . translatePath ( os . path . join ( oooo , 'recomendadas.png' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( oooo , 'accion.png' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( oooo , 'animacion.png' ) )
 O0O = xbmc . translatePath ( os . path . join ( oooo , 'aventuras.png' ) )
 O00o0OO = xbmc . translatePath ( os . path . join ( oooo , 'belico.png' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( oooo , 'ciencia-ficcion.png' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( oooo , 'clasicos.png' ) )
 o0 = xbmc . translatePath ( os . path . join ( oooo , 'comedia.png' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( oooo , 'crimen.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( oooo , 'drama.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( oooo , 'familiar.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( oooo , 'fantasia.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( oooo , 'historia.png' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( oooo , 'marvel.png' ) )
 OOOO = xbmc . translatePath ( os . path . join ( oooo , 'misterio.png' ) )
 OOO00 = xbmc . translatePath ( os . path . join ( oooo , 'musical.png' ) )
 iiiiiIIii = xbmc . translatePath ( os . path . join ( oooo , 'romance.png' ) )
 O000OO0 = xbmc . translatePath ( os . path . join ( oooo , 'spain.png' ) )
 I11iii1Ii = xbmc . translatePath ( os . path . join ( oooo , 'suspense.png' ) )
 I1IIiiIiii = xbmc . translatePath ( os . path . join ( oooo , 'terror.png' ) )
 O000oo0O = xbmc . translatePath ( os . path . join ( oooo , 'thriller.png' ) )
 OOOOi11i1 = xbmc . translatePath ( os . path . join ( oooo , 'western.png' ) )
 IIIii1II1II = xbmc . translatePath ( os . path . join ( oooo , 'sagas_cine.png' ) )
 i1I1iI = xbmc . translatePath ( os . path . join ( oooo , '4k.png' ) )
 oo0OooOOo0 = xbmc . translatePath ( os . path . join ( oooo , 'torrent.png' ) )
 o0OO00oO = xbmc . translatePath ( os . path . join ( oooo , 'buscar-serie.jpg' ) )
 I11i1I1I = xbmc . translatePath ( os . path . join ( oooo , 'series-todas.jpg' ) )
 oO0Oo = xbmc . translatePath ( os . path . join ( oooo , 'favorites.png' ) )
 oOOoo0Oo = xbmc . translatePath ( os . path . join ( oooo , 'artesmarciales.png' ) )
 o00OO00OoO = xbmc . translatePath ( os . path . join ( oooo , 'emision.png' ) )
 OOOO0OOoO0O0 = xbmc . translatePath ( os . path . join ( oooo , 'mejores.png' ) )
 O0Oo000ooO00 = xbmc . translatePath ( os . path . join ( oooo , 'seriesretro.png' ) )
 if 75 - 75: IIii11I1 . Oo0oO0oo0oO00 * i1111
else :
 if 91 - 91: I11i1i11i1I
 if 30 - 30: ooO . I11i1i11i1I - Ii11111i
 oOOoo0Oo = xbmc . translatePath ( os . path . join ( oooo , 'artesmarciales.png' ) )
 O0Oo000ooO00 = xbmc . translatePath ( os . path . join ( oooo , 'seriesretro.png' ) )
 iIIii1IIi = oo000 . getSetting ( 'iconos' )
 IiI1I1 = xbmc . translatePath ( os . path . join ( oooo , 'fanart.jpg' ) )
 OoO000 = xbmc . translatePath ( os . path . join ( oooo , 'icon.png' ) )
 IIiiIiI1 = xbmc . translatePath ( os . path . join ( oooo , 'extended_info.png' ) )
 iiIiIIi = xbmc . translatePath ( os . path . join ( oooo , 'buscar.png' ) )
 ooOoo0O = xbmc . translatePath ( os . path . join ( oooo , 'pair.png' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( oooo , 'theMovieDB.jpg' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( oooo , 'novedades.jpg' ) )
 OO0o = xbmc . translatePath ( os . path . join ( oooo , 'encines.jpg' ) )
 Ooo = xbmc . translatePath ( os . path . join ( oooo , 'recomendadas.jpg' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( oooo , 'accion.jpg' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( oooo , 'animacion.jpg' ) )
 O0O = xbmc . translatePath ( os . path . join ( oooo , 'aventuras.jpg' ) )
 O00o0OO = xbmc . translatePath ( os . path . join ( oooo , 'belico.jpg' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( oooo , 'ciencia-ficcion.jpg' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( oooo , 'clasicos.png' ) )
 o0 = xbmc . translatePath ( os . path . join ( oooo , 'comedia.jpg' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( oooo , 'crimen.jpg' ) )
 IIIII = xbmc . translatePath ( os . path . join ( oooo , 'drama.jpg' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( oooo , 'familiar.jpg' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( oooo , 'fantasia.jpg' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( oooo , 'historia.jpg' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( oooo , 'superheroes.jpg' ) )
 OOOO = xbmc . translatePath ( os . path . join ( oooo , 'misterio.jpg' ) )
 OOO00 = xbmc . translatePath ( os . path . join ( oooo , 'musical.jpg' ) )
 iiiiiIIii = xbmc . translatePath ( os . path . join ( oooo , 'romance.jpg' ) )
 O000OO0 = xbmc . translatePath ( os . path . join ( oooo , 'spain.jpg' ) )
 I11iii1Ii = xbmc . translatePath ( os . path . join ( oooo , 'suspense.jpg' ) )
 I1IIiiIiii = xbmc . translatePath ( os . path . join ( oooo , 'terror.jpg' ) )
 O000oo0O = xbmc . translatePath ( os . path . join ( oooo , 'thriller.jpg' ) )
 OOOOi11i1 = xbmc . translatePath ( os . path . join ( oooo , 'western.jpg' ) )
 IIIii1II1II = xbmc . translatePath ( os . path . join ( oooo , 'sagas_cine.jpg' ) )
 i1I1iI = xbmc . translatePath ( os . path . join ( oooo , '4k.jpg' ) )
 oo0OooOOo0 = xbmc . translatePath ( os . path . join ( oooo , 'torrent.jpg' ) )
 o0OO00oO = xbmc . translatePath ( os . path . join ( oooo , 'buscar-serie.jpg' ) )
 I11i1I1I = xbmc . translatePath ( os . path . join ( oooo , 'series-todas.jpg' ) )
 o00OO00OoO = xbmc . translatePath ( os . path . join ( oooo , 'emision.png' ) )
 OOOO0OOoO0O0 = xbmc . translatePath ( os . path . join ( oooo , 'mejores.jpg' ) )
 oO0Oo = xbmc . translatePath ( os . path . join ( oooo , 'favoritos.png' ) )
 if 8 - 8: iiI1i1 - OoO0O00 * Ooo0OO0oOO + II111iiii / I1i1I % i1111
 if 16 - 16: IiIiI11iIi + Oo0oO0oo0oO00 - Ooo0OO0oOO
oOoOO0 = xbmc . translatePath ( os . path . join ( oooo , 'peliculas.png' ) )
IiI11iII1 = xbmc . translatePath ( os . path . join ( oooo , 'series.png' ) )
IIII11I1I = xbmc . translatePath ( os . path . join ( oooo , 'ajustes.png' ) )
OOO0o = xbmc . translatePath ( os . path . join ( oooo , 'videoteca.png' ) )
IiI1 = xbmc . translatePath ( os . path . join ( oooo , 'favorites.png' ) )
Oo0O00Oo0o0 = xbmc . translatePath ( os . path . join ( oooo , 'resolver.png' ) )
O00O0oOO00O00 = xbmc . translatePath ( os . path . join ( oooo , 'test.png' ) )
i1 = xbmc . translatePath ( os . path . join ( oooo , 'video-tutoriales.png' ) )
Oo00 = xbmc . translatePath ( os . path . join ( oooo , 'proxy.png' ) )
if 31 - 31: I1i1I . i11Ii11I1Ii1i / oo
o000O0o = oo000 . getSetting ( 'mostrar_cat' )
iI1iII1 = oo000 . getSetting ( 'videos' )
oO0OOoo0OO = oo000 . getSetting ( 'activar' )
O0ii1ii1ii = oo000 . getSetting ( 'favcopy' )
oooooOoo0ooo = oo000 . getSetting ( 'anticopia' )
IIiIiII11i = oo000 . getSetting ( 'licencia_addon' )
I1I1IiI1 = oo000 . getSetting ( 'notificar' )
III1iII1I1ii = oo000 . getSetting ( 'mostrar_bus' )
oOOo0 = oo000 . getSetting ( 'restante' )
oo00O00oO = oo000 . getSetting ( 'selecton' )
iIiIIIi = oo000 . getSetting ( 'aviso' )
ooo00OOOooO = oo000 . getSetting ( 'RealStream_Settings' )
O00OOOoOoo0O = oo000 . getSetting ( 'Resolver_Settings' )
oOOo0 = oo000 . getSetting ( 'restante' )
O000OOo00oo = oo000 . getSetting ( 'fav' )
oo0OOo = oo000 . getSetting ( 'Fontcolor' )
ooOOO00Ooo = oo000 . getSetting ( 'MenuColor' )
IiIIIi1iIi = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
ooOOoooooo = 'bienvenida'
II1I = 'bienvenida'
copyright = oo000 . getSetting ( 'copyright' )
O0i1II1Iiii1I11 = 'cGx1Z2luLnZpZGVvLg==' . decode ( 'base64' ) + copyright
IIII = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
iiIiI = oo000 . getSetting ( 'Forceupdate' )
if iiIiI == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
o00oooO0Oo = 'LnR4dA==' . decode ( 'base64' )
if 78 - 78: I11i1i11i1I % I1i1I + IiIiI11iIi
OOooOoooOoOo = 'aHR0cDovL2JpdC5seS8yU1FOSnlP' . decode ( 'base64' )
o0OOOO00O0Oo = IiIIIi1iIi + ooOOoooooo + o00oooO0Oo
iioOooOOOoOo = 'http://www.youtube.com'
i1Iii1i1I = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
OOoO00 = '.xsl.pt'
IiI111111IIII = 'L21hc3Rlci8=' . decode ( 'base64' )
i1Ii = i1Iii1i1I + OOoO00
ii111iI1iIi1 = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*texto3=[\'"](.*?)[\'"]\s*'
OOO = 'tvg-logo=[\'"](.*?)[\'"]'
if 68 - 68: Ooo0OO0oOO + i1IIi11111i
I1I1I = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)'
OoOO000 = '(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)'
i1Ii11i1i = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
o0oOOoo = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
oOo00O0oo00o0 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
iiOOooooO0Oo = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
OO = '#(.+?),(.+)\s*(.+)'
iIiIIi1 = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
if 7 - 7: OoOoo0 - Oo0o - IIii11I1 + OoOoo0
iI1I11iiI1i = 'source src=[\'"](.*?)[\'"]\s*title=[\'"](.*?)[\'"]'
oO0o0Ooooo = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
OOo0oO00ooO00 = '[\'"](.*?)[\'"]'
oOO0O00oO0Ooo = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
oO0Oo0O0o = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( 'base64' )
OOI1iI1ii1II = oO0Oo0O0o + O0
iI111iI = '[\'"](.*?)[\'"]'
O0O0OOOOoo = 'UmVhbHN0cmVhbQ==' . decode ( 'base64' )
oOooO0 = 'video=[\'"](.*?)[\'"]'
o0oOOo0O0Ooo = '0110nhu' . replace ( '0110nhu' , 'nhu' )
I1ii11iIi11i = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( 'base64' ) + o0oOOo0O0Ooo
Ii1I1Ii = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
OOoO0 = '0110R0N' . replace ( '0110R0N' , 'R0N' )
OO0Oooo0oOO0O = 'aHR0cDovL2JpdC5seS8yWEIx' . decode ( 'base64' ) + OOoO0
o00O0 = '0110pEJ' . replace ( '0110pEJ' , 'pEJ' )
oOO0O00Oo0O0o = 'aHR0cDovL2JpdC5seS8yd1Nh' . decode ( 'base64' ) + o00O0
ii1 = 'ABBAOb5' . replace ( 'ABBAOb5' , 'Ob5' )
I1iIIiiIIi1i = 'aHR0cDovL2JpdC5seS8yRVhV' . decode ( 'base64' ) + ii1
O0O0ooOOO = '0110jaw' . replace ( '0110jaw' , 'jaw' )
oOOo0O00o = 'aHR0cDovL2JpdC5seS8yd01M' . decode ( 'base64' ) + O0O0ooOOO
iIiIi11 = '01109DI' . replace ( '01109DI' , '9DI' )
OOOiiiiI = 'aHR0cDovL2JpdC5seS8ySXgz' . decode ( 'base64' ) + iIiIi11
oooOo0OOOoo0 = '01103hs' . replace ( '01103hs' , '3hs' )
OOoO = 'aHR0cDovL2JpdC5seS8zMW1U' . decode ( 'base64' ) + oooOo0OOOoo0
OO0O000 = '01107DW' . replace ( '01107DW' , '7DW' )
iiIiI1i1 = 'aHR0cDovL2JpdC5seS8yV1ln' . decode ( 'base64' ) + OO0O000
oO0O00oOOoooO = '0110mLl' . replace ( '0110mLl' , 'mLl' )
IiIi11iI = 'aHR0cDovL2JpdC5seS8yS0cw' . decode ( 'base64' ) + oO0O00oOOoooO
Oo0O00O000 = '01102Hj' . replace ( '01102Hj' , '2Hj' )
i11I1IiII1i1i = 'aHR0cDovL2JpdC5seS8yWEJo' . decode ( 'base64' ) + Oo0O00O000
ooI1111i = '0110fXg' . replace ( '0110fXg' , 'fXg' )
iIIii = 'aHR0cDovL2JpdC5seS8ySTVy' . decode ( 'base64' ) + ooI1111i
o00O0O = '0110NMH' . replace ( '0110NMH' , 'NMH' )
ii1iii1i = 'aHR0cDovL2JpdC5seS8yd0t6' . decode ( 'base64' ) + o00O0O
Iii1I1111ii = '0110bwQ' . replace ( '0110bwQ' , 'bwQ' )
ooOoO00 = 'aHR0cDovL2JpdC5seS8yd01V' . decode ( 'base64' ) + Iii1I1111ii
Ii1IIiI1i = '0110xzG' . replace ( '0110xzG' , 'xzG' )
o0O00Oo0 = 'aHR0cDovL2JpdC5seS8yWHhz' . decode ( 'base64' ) + Ii1IIiI1i
IiII111i1i11 = '0110x64' . replace ( '0110x64' , 'x64' )
i111iIi1i1II1 = 'aHR0cDovL2JpdC5seS8yRVlF' . decode ( 'base64' ) + IiII111i1i11
oooO = '0110vUE' . replace ( '0110vUE' , 'vUE' )
i1I1i111Ii = 'aHR0cDovL2JpdC5seS8yWmhW' . decode ( 'base64' ) + oooO
ooo = '01107ZL' . replace ( '01107ZL' , '7ZL' )
i1i1iI1iiiI = 'aHR0cDovL2JpdC5seS8yWm4w' . decode ( 'base64' ) + ooo
Ooo0oOooo0 = '01106cf' . replace ( '01106cf' , '6cf' )
oOOOoo00 = 'aHR0cDovL2JpdC5seS8yRVlk' . decode ( 'base64' ) + Ooo0oOooo0
iiIiIIIiiI = '0110Jtp' . replace ( '0110Jtp' , 'Jtp' )
iiI1IIIi = 'aHR0cDovL2JpdC5seS8yV3Nq' . decode ( 'base64' ) + iiIiIIIiiI
II11IiIi11 = '0110a5b' . replace ( '0110a5b' , 'a5b' )
II = 'aHR0cDovL2JpdC5seS8yV3dj' . decode ( 'base64' ) + II11IiIi11
OOO0O00O0OOOO = '0110Q7u' . replace ( '0110Q7u' , 'Q7u' )
I1iiii1I = 'aHR0cDovL2JpdC5seS8yV3NL' . decode ( 'base64' ) + OOO0O00O0OOOO
OOo0 = '0110rsq' . replace ( '0110rsq' , 'rsq' )
oO00ooooO0o = 'aHR0cDovL2JpdC5seS8ySzhE' . decode ( 'base64' ) + OOo0
oo0o = '0110DDR' . replace ( '0110DDR' , 'DDR' )
o0oO0oooOoo = 'aHR0cDovL2JpdC5seS8ySzd5' . decode ( 'base64' ) + oo0o
I1III1111iIi = '0110feQ' . replace ( '0110feQ' , 'feQ' )
I1i111I = 'aHR0cDovL2JpdC5seS8yS0cz' . decode ( 'base64' ) + I1III1111iIi
OooOo0oo0O0o00O = '0110MHY' . replace ( '0110MHY' , 'MHY' )
I1i11 = 'aHR0cDovL2JpdC5seS8ySXVo' . decode ( 'base64' ) + OooOo0oo0O0o00O
IiIi1I1 = '0110xdb' . replace ( '0110xdb' , 'xdb' )
IiIIi1 = 'aHR0cDovL2JpdC5seS8yWEJu' . decode ( 'base64' ) + IiIi1I1
IIIIiii1IIii = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( 'base64' )
O0i1II1Iiii1I11 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
II1i11I = '0110lxu' . replace ( '0110lxu' , 'lxu' )
ii1I1IIii11 = 'aHR0cDovL2JpdC5seS8yV1Bj' . decode ( 'base64' ) + II1i11I
O0o0oO = '0110pzp' . replace ( '0110pzp' , 'pzp' )
IIIIiIiIi1 = 'aHR0cDovL2JpdC5seS8yVHpB' . decode ( 'base64' ) + O0o0oO
I11iiiiI1i = '01105yt' . replace ( '01105yt' , '5yt' )
iI1i11 = 'aHR0cDovL2JpdC5seS8yTVpp' . decode ( 'base64' ) + I11iiiiI1i
if 66 - 66: oo % IiIiI11iIi + II111iiii . i11Ii11I1Ii1i / I11i1i11i1I + IiIiI11iIi
if 86 - 86: ooO
i1Iii11Ii1i1 = '1001DTs' . replace ( '1001DTs' , 'DTs' )
OOooo0O0o0 = 'aHR0cDovL2JpdC5seS8ySzhP' . decode ( 'base64' ) + i1Iii11Ii1i1
II1iI1I11I = '1001Hky' . replace ( '1001Hky' , 'Hky' )
o0OO0 = 'aHR0cDovL2JpdC5seS8yTGVL' . decode ( 'base64' ) + II1iI1I11I
IiI11ii1I = '1001VFU' . replace ( '1001VFU' , 'VFU' )
oooiiI = 'aHR0cDovL2JpdC5seS8zMERx' . decode ( 'base64' ) + IiI11ii1I
oO = '3545OMZ' . replace ( '3545OMZ' , 'OMZ' )
IIiIi = 'aHR0cDovL2JpdC5seS8yazhk' . decode ( 'base64' ) + oO
if 91 - 91: IiIiI11iIi * Oo0o / Ii . oo + Oo0oO0oo0oO00 + i11Ii11I1Ii1i
def iIIi ( ) :
 if 11 - 11: Ii * IIii11I1
 if 81 - 81: Iiii + oO0o0o0ooO0oO
 try :
  if 98 - 98: Ii
  o0OOO = iIiiiI ( OO0Oooo0oOO0O )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for o00o0 in Iii1ii1II11i :
   try :
    if 50 - 50: Oo0o / Oo0o % IiIiI11iIi . IiIiI11iIi
    oOO0O00Oo0O0o = o00o0
    if 55 - 55: OoOoo0 - i1IIi11111i + Ooo0OO0oOO + Iiii % I11i1i11i1I
    iiI11i1II = xbmc . Keyboard ( '' , 'Busqueda por titulo' )
    iiI11i1II . doModal ( )
    if ( iiI11i1II . isConfirmed ( ) ) :
     if 51 - 51: ooO % Oo0o % ooO * oo - i1111 % Oo0o
     o0O00OooOOOOO = urllib . quote_plus ( iiI11i1II . getText ( ) ) . replace ( '+' , ' ' )
     IIIiiI1i1 = iIiiiI ( oOO0O00Oo0O0o )
     Iii1ii1II11i = re . compile ( I1I1I ) . findall ( IIIiiI1i1 )
     if 15 - 15: iiI1i1 + i11Ii11I1Ii1i
     for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
      if re . search ( o0O00OooOOOOO , oO00oOooooo0 ( iI1 . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
       if 64 - 64: OoOoo0 - i11Ii11I1Ii1i - Ii . oo + Oo0o
   except :
    pass
 except :
  pass
  if 1 - 1: Iiii
  if 97 - 97: i1111 + Iiii + oo + II111iiii
  if 77 - 77: ooO / Ii11111i
def IIii11I1i1I ( ) :
 if 99 - 99: Iiii
 iIiIIIi = oo000 . getSetting ( 'aviso' )
 if iIiIIIi == 'true' :
  o0OOO = iIiiiI ( o0OOOO00O0Oo )
  Iii1ii1II11i = re . compile ( ii111iI1iIi1 ) . findall ( o0OOO )
  for oOO0O00o0OO0O , iiiI , I1ii1 in Iii1ii1II11i :
   try :
    if 99 - 99: OoOoo0 . I1i1I % oO0o0o0ooO0oO * oO0o0o0ooO0oO . iiI1i1
    if 72 - 72: i1111 % IiIiI11iIi + Oo0oO0oo0oO00 / IIii11I1 + oO0o0o0ooO0oO
    I1I1i = oOO0O00o0OO0O
    I1IIIiIiIi = iiiI
    IIIII1 = I1ii1
    if 5 - 5: I11i1i11i1I
    if 46 - 46: oO0o0o0ooO0oO
    ii1iIi1iIiI1i = "[B]" + I1I1i + "[/B]"
    iiI1iIii1i = "" + I1IIIiIiIi + ""
    OOooO0oo0o00o = "" + IIIII1 + ""
    if 100 - 100: ooO
    xbmcgui . Dialog ( ) . ok ( "Real Stream" , ii1iIi1iIiI1i , iiI1iIii1i , OOooO0oo0o00o )
    if 1 - 1: i1IIi11111i + Ii11111i - i1111 + oO0o0o0ooO0oO
   except :
    pass
    if 9 - 9: I11i1i11i1I
    if 59 - 59: Ii * Ooo0OO0oOO . oo
 O000OoOO0 = iIiiiI ( IIIIiii1IIii )
 Iii1ii1II11i = re . compile ( OOo0oO00ooO00 ) . findall ( O000OoOO0 )
 for i1IiIII111i1 in Iii1ii1II11i :
  try :
   if 57 - 57: I11i1i11i1I % I11i1i11i1I * II111iiii
   import xbmc
   import xbmcaddon
   if 7 - 7: oo . I11i1i11i1I
   __addon__ = xbmcaddon . Addon ( )
   __addonname__ = __addon__ . getAddonInfo ( 'name' )
   __icon__ = __addon__ . getAddonInfo ( 'icon' )
   if 51 - 51: Oo0oO0oo0oO00 - oo % IIii11I1 - Ooo0OO0oOO
   ii = oo000 . getAddonInfo ( 'version' )
   I1II = i1IiIII111i1
   if 64 - 64: oo % i1IIi11111i % oo * Oo0oO0oo0oO00 . IIii11I1 + Ii
   ii1iIi1iIiI1i = "[COLOR orange]Version instalada Actualmente: [COLOR gold] " + ii + " [/COLOR][/COLOR]" "[COLOR white]Disponible la version: [COLOR lime] " + i1IiIII111i1 + "  [/COLOR][/COLOR]"
   O00 = 5000
   if 17 - 17: I11i1i11i1I - Ii11111i % I11i1i11i1I . oO0o0o0ooO0oO / II111iiii % Iiii
   xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , ii1iIi1iIiI1i , O00 , __icon__ ) )
   if 28 - 28: i1IIi11111i
   if 58 - 58: i11Ii11I1Ii1i
   if ii < I1II :
    if 37 - 37: Oo0o - OoO0O00 / IiIiI11iIi
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR orange]Ya esta disponible la nueva version[/COLOR][COLOR lime]" + i1IiIII111i1 + "[/COLOR][COLOR orange]. Puedes instalarla desde el repositorio Realstream, sino se actualiza sola.[/COLOR]" )
  except :
   pass
 if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
  if 73 - 73: II111iiii - oO0o0o0ooO0oO
  if 25 - 25: Ii11111i + oO0o0o0ooO0oO * IiIiI11iIi
  if 92 - 92: Ii + i1IIi11111i + oo / ooO + I1i1I
def oO00oOooooo0 ( s ) :
 if 18 - 18: OoOoo0 * i11Ii11I1Ii1i . Iiii / IiIiI11iIi / II111iiii
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 21 - 21: IIii11I1 / IiIiI11iIi + I11i1i11i1I + Ii11111i
def OoOo ( file ) :
 if 35 - 35: OoOoo0 * i1111 . i1IIi11111i * ooO . i11Ii11I1Ii1i / oo
 try :
  O00O0ooo0 = open ( file , 'r' )
  o0OOO = O00O0ooo0 . read ( )
  O00O0ooo0 . close ( )
  return o0OOO
 except :
  pass
  if 8 - 8: OoOoo0 + Ooo0OO0oOO / Iiii / i1IIi11111i
def iIiiiI ( url ) :
 if 74 - 74: oo / iiI1i1
 try :
  OoO = urllib2 . Request ( url )
  OoO . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  Iiiiii111i1ii = urllib2 . urlopen ( OoO )
  i1i1iII1 = Iiiiii111i1ii . read ( )
  Iiiiii111i1ii . close ( )
  return i1i1iII1
 except urllib2 . URLError , iii11i1IIII :
  print 'We failed to open "%s".' % url
  if hasattr ( iii11i1IIII , 'code' ) :
   print 'We failed with error code - %s.' % iii11i1IIII . code
  if hasattr ( iii11i1IIII , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , iii11i1IIII . reason
   if 26 - 26: oo . Oo0oO0oo0oO00 * I1i1I . Ii % II111iiii
def i1Ii1iii ( url ) :
 OoO = urllib2 . Request ( url )
 OoO . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 OoO . add_header ( 'Referer' , '%s' % url )
 OoO . add_header ( 'Connection' , 'keep-alive' )
 Iiiiii111i1ii = urllib2 . urlopen ( OoO )
 i1i1iII1 = Iiiiii111i1ii . read ( )
 Iiiiii111i1ii . close ( )
 return i1i1iII1
 if 28 - 28: IIii11I1 . Ooo0OO0oOO / IiIiI11iIi + Ooo0OO0oOO . Ii11111i . oO0o0o0ooO0oO
 if 53 - 53: I11i1i11i1I % I11i1i11i1I * ooO + i11Ii11I1Ii1i
def Oooo00 ( ) :
 if 6 - 6: I11i1i11i1I - OoOoo0 * i1111 . Iiii / oo * OoOoo0
 ooOOO00Ooo = oo000 . getSetting ( 'MenuColor' )
 if 22 - 22: Oo0o % Iiii * IiIiI11iIi / i1111 % II111iiii * i1IIi11111i
 if oO0OOoo0OO == 'true' :
  if 95 - 95: Ii11111i - oO0o0o0ooO0oO * Ii + i11Ii11I1Ii1i
  iIi1 ( '[COLOR %s]Peliculas[/COLOR] ' % ooOOO00Ooo , 'movieDB' , 116 , oOoOO0 , IiI1I1 )
  iIi1 ( '[COLOR %s]Series[/COLOR] ' % ooOOO00Ooo , 'movieDB' , 117 , IiI11iII1 , IiI1I1 )
  if 21 - 21: i1IIi11111i
  if 92 - 92: II111iiii / I1i1I - Iiii % OoOoo0 * I1i1I + Oo0o
 if ooo00OOOooO == 'true' :
  iIi1 ( '[COLOR %s]Ajustes[/COLOR]' % ooOOO00Ooo , 'Settings' , 119 , IIII11I1I , IiI1I1 )
  if 11 - 11: Ii11111i . I1i1I
  if 80 - 80: Ii11111i - i1111 * I11i1i11i1I * IiIiI11iIi / Ii / i1111
  if o000O0o == 'true' :
   I1I11iI11iI1i ( )
   if 75 - 75: Ii11111i * oO0o0o0ooO0oO
  if O00OOOoOoo0O == 'true' :
   I1Iiiiiii ( )
   I1IIIiI1I1ii1 ( )
   if 30 - 30: oo * Ii11111i
  if oooooOoo0ooo == 'false' :
   if 38 - 38: oO0o0o0ooO0oO - IiIiI11iIi . i11Ii11I1Ii1i - I1i1I . Ii11111i
   ii1iIi1iIiI1i = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   iiI1iIii1i = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Script.ResolveURL para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   OOooO0oo0o00o = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 89 - 89: OoO0O00
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , ii1iIi1iIiI1i , iiI1iIii1i , OOooO0oo0o00o )
   if 21 - 21: i1IIi11111i % i1IIi11111i
def iiI1 ( ) :
 iIi1 ( '[COLOR orange]Buscador por id[/COLOR]' , iioOooOOOoOo , 127 , OooO0 , IiI1I1 )
 if 16 - 16: Ooo0OO0oOO + IIii11I1 - Ii11111i
def iI11 ( ) :
 if 3 - 3: oo / Iiii
 ooOOO00Ooo = oo000 . getSetting ( 'MenuColor' )
 iIi1 ( '[COLOR %s]The movie DB[/COLOR]' % ooOOO00Ooo , 'movieDB' , 99 , OooO0 , IiI1I1 )
 iIi1 ( '[COLOR %s]Buscador por id[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 127 , OooO0 , IiI1I1 )
 iIi1 ( '[COLOR %s]Video tutoriales[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 125 , i1 , IiI1I1 )
 if 31 - 31: i1111 + ooO . Ii11111i
 if 89 - 89: Ooo0OO0oOO + iiI1i1 + Ooo0OO0oOO
 if 7 - 7: oo % ooO + IiIiI11iIi * Iiii - Iiii
 if 42 - 42: i11Ii11I1Ii1i * i11Ii11I1Ii1i * I1i1I . i1IIi11111i
 if 51 - 51: i1111 % OoO0O00 - Ii11111i % OoOoo0 * OoO0O00 % Oo0oO0oo0oO00
 if 99 - 99: IIii11I1 * Ooo0OO0oOO * I1i1I
 iIi1 ( '[COLOR %s]Autorizar OPENLOAD[/COLOR]' % ooOOO00Ooo , 'movieDB' , 97 , ooOoo0O , IiI1I1 )
 if 92 - 92: Oo0o
 if 40 - 40: i11Ii11I1Ii1i / oO0o0o0ooO0oO
 if 79 - 79: Oo0oO0oo0oO00 - OoO0O00 + I11i1i11i1I - I1i1I
 Oooo00 ( )
 if 93 - 93: Ooo0OO0oOO . Ii - Oo0o + i11Ii11I1Ii1i
 if 61 - 61: Ooo0OO0oOO
 if 15 - 15: II111iiii % Ii * i1IIi11111i / I1i1I
 if 90 - 90: Iiii
 if 31 - 31: i1111 + oo
 if 87 - 87: OoOoo0
 if 45 - 45: Oo0oO0oo0oO00 / Ii11111i - Iiii / I11i1i11i1I % oO0o0o0ooO0oO
 if 83 - 83: Ii . OoO0O00 - oO0o0o0ooO0oO * II111iiii
 if 20 - 20: iiI1i1 * I1i1I + Ooo0OO0oOO % ooO % IIii11I1
 if 13 - 13: Oo0o
 if 60 - 60: IiIiI11iIi * Ii
def I1iIiI11I1 ( ) :
 i1oOOoo0o0OOOO = xbmcgui . Dialog ( )
 i1IiII1III = (
 i1O00oo ,
 O0OO00O0oOO ,
 )
 if 4 - 4: Ii11111i - iiI1i1 % I11i1i11i1I - i1111 * ooO
 Ooooo00o0OoO = i1oOOoo0o0OOOO . select ( '[B][COLOR=yellow]Listado de Proxys Gratuitos:[/COLOR][/B]' , [
 '[COLOR=orange]                      Accede a la web[/COLOR]' ,

 '[B][COLOR=gold]                      Volver al Menu [/COLOR][/B]' , ] )
 if 75 - 75: Ii % Ooo0OO0oOO
 if Ooooo00o0OoO :
  if 30 - 30: oO0o0o0ooO0oO + I1i1I - oO0o0o0ooO0oO . oO0o0o0ooO0oO - Ooo0OO0oOO + oo
  if Ooooo00o0OoO < 0 :
   return
  oOO0 = i1IiII1III [ Ooooo00o0OoO - 2 ]
  return oOO0 ( )
 else :
  oOO0 = i1IiII1III [ Ooooo00o0OoO ]
  return oOO0 ( )
 return
 if 46 - 46: I11i1i11i1I % i11Ii11I1Ii1i
def ooo0o0O0o ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 62 - 62: OoOoo0 + II111iiii + Oo0o / II111iiii
I1Ii = ooo0o0O0o ( )
if 70 - 70: Oo0o . Ii11111i - Iiii
def i1O00oo ( ) :
 if I1Ii == 'android' :
  iII11I1Ii1 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://hidemyna.me/es/proxy-list/?country=ES&type=hs#list' ) )
  if 92 - 92: i1IIi11111i / i1IIi11111i . IiIiI11iIi
 else :
  iII11I1Ii1 = webbrowser . open ( 'https://hidemyna.me/es/proxy-list/?country=ES&type=hs#list' )
  if 17 - 17: II111iiii - Ooo0OO0oOO * ooO
  if 5 - 5: i1111 - i1111 . Oo0o + i11Ii11I1Ii1i - i1111 . IIii11I1
def O0OO00O0oOO ( ) :
 if 31 - 31: Ooo0OO0oOO - OoO0O00 - OoO0O00 % i1IIi11111i
 iI11 ( )
 if 12 - 12: OoO0O00
 if 20 - 20: ooO / iiI1i1
def oOIi111 ( ) :
 if xbmc . getCondVisibility ( 'System.HasAddon(script.favourites)' ) :
  try :
   xbmc . executebuiltin ( "RunScript(script.favourites)" )
  except :
   pass
def oO0 ( ) :
 oo000 . openSettings ( )
 if 11 - 11: OoOoo0 / Ooo0OO0oOO
 if 47 - 47: Ii11111i
def ii1i1i1IiII ( ) :
 urlresolver . display_settings ( )
 if 63 - 63: Iiii . Oo0oO0oo0oO00 / Ooo0OO0oOO * oO0o0o0ooO0oO + IIii11I1 % I11i1i11i1I
def I1Iiiiiii ( ) :
 iIi1 ( '[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % ooOOO00Ooo , 'resolve' , 120 , Oo0O00Oo0o0 , IiI1I1 )
 if 12 - 12: I1i1I . Oo0oO0oo0oO00 . Iiii - Ii11111i % Oo0o
def i11i1iIiii ( ) :
 if 71 - 71: IiIiI11iIi % OoOoo0 - Ii % i1IIi11111i - oo
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 67 - 67: i1111 + Oo0o
def I1IIIiI1I1ii1 ( ) :
 iIi1 ( '[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % ooOOO00Ooo , 'resolve' , 140 , Oo0O00Oo0o0 , IiI1I1 )
 if 84 - 84: oo * Ii11111i - oO0o0o0ooO0oO * oO0o0o0ooO0oO
def I1I11iI11iI1i ( ) :
 if 8 - 8: OoOoo0 / iiI1i1 . IIii11I1
 ooOOO00Ooo = oo000 . getSetting ( 'MenuColor' )
 iIi1 ( '[COLOR %s]Buscador[/COLOR]' % ooOOO00Ooo , 'search' , 111 , iiIiIIi , IiI1I1 )
 iIi1 ( '[COLOR %s]Estrenos[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 3 , OO0o , IiI1I1 )
 iIi1 ( '[COLOR %s]Todas[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 26 , Ooo , IiI1I1 )
 iIi1 ( '[COLOR %s]4K[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 141 , i1I1iI , IiI1I1 )
 iIi1 ( '[COLOR %s]Novedades[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 2 , II11iiii1Ii , IiI1I1 )
 iIi1 ( '[COLOR %s]Accion[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 5 , O0o0Oo , IiI1I1 )
 iIi1 ( '[COLOR %s]Animacion[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 6 , Oo00OOOOO , IiI1I1 )
 iIi1 ( '[COLOR %s]Artes Marciales[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 29 , oOOoo0Oo , IiI1I1 )
 iIi1 ( '[COLOR %s]Aventuras[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 7 , O0O , IiI1I1 )
 iIi1 ( '[COLOR %s]Belico[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 8 , O00o0OO , IiI1I1 )
 iIi1 ( '[COLOR %s]Ciencia Ficcion[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 9 , I11i1 , IiI1I1 )
 iIi1 ( '[COLOR %s]Cine Clasico[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 30 , iIi1ii1I1 , IiI1I1 )
 iIi1 ( '[COLOR %s]Comedia[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 10 , o0 , IiI1I1 )
 iIi1 ( '[COLOR %s]Crimen[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 11 , I11II1i , IiI1I1 )
 iIi1 ( '[COLOR %s]Drama[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 12 , IIIII , IiI1I1 )
 iIi1 ( '[COLOR %s]Familiar[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 13 , ooooooO0oo , IiI1I1 )
 iIi1 ( '[COLOR %s]Fantasia[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 14 , IIiiiiiiIi1I1 , IiI1I1 )
 iIi1 ( '[COLOR %s]Historia[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 15 , I1IIIii , IiI1I1 )
 iIi1 ( '[COLOR %s]Misterio[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 16 , OOOO , IiI1I1 )
 iIi1 ( '[COLOR %s]Musical[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 17 , OOO00 , IiI1I1 )
 iIi1 ( '[COLOR %s]Romance[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 18 , iiiiiIIii , IiI1I1 )
 iIi1 ( '[COLOR %s]Thriller[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 19 , O000oo0O , IiI1I1 )
 iIi1 ( '[COLOR %s]Suspense[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 20 , I11iii1Ii , IiI1I1 )
 iIi1 ( '[COLOR %s]Terror[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 21 , I1IIiiIiii , IiI1I1 )
 iIi1 ( '[COLOR %s]Western[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 22 , OOOOi11i1 , IiI1I1 )
 iIi1 ( '[COLOR %s]Spain[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 23 , O000OO0 , IiI1I1 )
 iIi1 ( '[COLOR %s]Super heroes[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 24 , oOoOooOo0o0 , IiI1I1 )
 iIi1 ( '[COLOR %s]Sagas[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 25 , IIIii1II1II , IiI1I1 )
 if 41 - 41: Iiii + Oo0oO0oo0oO00
def oOO ( ) :
 if 11 - 11: II111iiii - IIii11I1 . IIii11I1
 iIi1 ( '[COLOR %s]Buscar Serie[/COLOR]' % ooOOO00Ooo , 'search' , 145 , o0OO00oO , IiI1I1 )
 iIi1 ( '[COLOR %s]En emision[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 150 , o00OO00OoO , IiI1I1 )
 iIi1 ( '[COLOR %s]Mejor valoradas[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 151 , OOOO0OOoO0O0 , IiI1I1 )
 iIi1 ( '[COLOR %s]Series Retro[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 152 , O0Oo000ooO00 , IiI1I1 )
 iIi1 ( '[COLOR %s]Todas[/COLOR]' % ooOOO00Ooo , iioOooOOOoOo , 142 , I11i1I1I , IiI1I1 )
 if 31 - 31: i1111 / Oo0o * iiI1i1 . i11Ii11I1Ii1i
def OO0o0oO ( ) :
 if 83 - 83: ooO / II111iiii % OoO0O00 . i1IIi11111i % IIii11I1 . Ii11111i
 if 94 - 94: I11i1i11i1I + OoO0O00 % Oo0oO0oo0oO00
 try :
  if 93 - 93: I11i1i11i1I - i1111 + OoO0O00 * ooO + I1i1I . Iiii
  IiI1iII1II111 = iIiiiI ( OOooo0O0o0 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( IiI1iII1II111 )
  for o00o0 in Iii1ii1II11i :
   if 28 - 28: i11Ii11I1Ii1i * Oo0oO0oo0oO00 . i1IIi11111i % i1IIi11111i / i1IIi11111i * I1i1I
   try :
    if 64 - 64: Ooo0OO0oOO - Ii
    O0O0ooOOOo0o00Ooo0o = o00o0
    iiI11i1II = xbmc . Keyboard ( '' , 'Buscar' )
    iiI11i1II . doModal ( )
    if ( iiI11i1II . isConfirmed ( ) ) :
     if 76 - 76: Ooo0OO0oOO
     o0O00OooOOOOO = urllib . quote_plus ( iiI11i1II . getText ( ) ) . replace ( '+' , ' ' )
     O000OoOO0 = iIiiiI ( O0O0ooOOOo0o00Ooo0o )
     Iii1ii1II11i = re . compile ( i1Ii11i1i ) . findall ( O000OoOO0 )
     for OoO000 , iI1 , IiI1I1 , iIIioO0o00oo0 in Iii1ii1II11i :
      if re . search ( o0O00OooOOOOO , oO00oOooooo0 ( iI1 . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       iIi1 ( iI1 , iIIioO0o00oo0 , 143 , OoO000 , IiI1I1 )
       if 26 - 26: Ooo0OO0oOO % II111iiii % OoO0O00 % i1IIi11111i * i1IIi11111i * IiIiI11iIi
   except :
    pass
 except :
  pass
  if 24 - 24: Ooo0OO0oOO % I1i1I - OoOoo0 + Ii * IiIiI11iIi
def i11111I1I ( ) :
 if 61 - 61: Ooo0OO0oOO * i1111 / Ii11111i / Oo0o - Oo0oO0oo0oO00
 try :
  if 56 - 56: IiIiI11iIi
  IiI1iII1II111 = iIiiiI ( IIiIi )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( IiI1iII1II111 )
  for o00o0 in Iii1ii1II11i :
   if 26 - 26: Ii11111i % Ii11111i
   try :
    if 33 - 33: I1i1I
    O0O0ooOOOo0o00Ooo0o = o00o0
    if 62 - 62: IiIiI11iIi + I11i1i11i1I + iiI1i1 / Ii11111i
   except :
    pass
    if 7 - 7: ooO + iiI1i1 . Ii / Oo0o
  O000OoOO0 = iIiiiI ( O0O0ooOOOo0o00Ooo0o )
  Iii1ii1II11i = re . compile ( i1Ii11i1i ) . findall ( O000OoOO0 )
  for OoO000 , iI1 , IiI1I1 , iIIioO0o00oo0 in Iii1ii1II11i :
   try :
    if 22 - 22: OoOoo0 - OoOoo0 % i1111 . I1i1I + IIii11I1
    iIi1 ( iI1 , iIIioO0o00oo0 , 143 , OoO000 , IiI1I1 )
    if 63 - 63: Ii % I1i1I * ooO + I1i1I / Oo0o % Iiii
   except :
    pass
 except :
  pass
  if 45 - 45: oO0o0o0ooO0oO
  if 20 - 20: Ii11111i * ooO * oo . i1111
def OoO000O ( ) :
 if 94 - 94: i11Ii11I1Ii1i . oo / I11i1i11i1I . IiIiI11iIi - iiI1i1
 try :
  if 26 - 26: Oo0oO0oo0oO00 - i1111 . ooO
  IiI1iII1II111 = iIiiiI ( oooiiI )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( IiI1iII1II111 )
  for o00o0 in Iii1ii1II11i :
   if 65 - 65: IiIiI11iIi % oo % OoO0O00 * I11i1i11i1I
   try :
    if 31 - 31: I11i1i11i1I
    O0O0ooOOOo0o00Ooo0o = o00o0
    if 44 - 44: i11Ii11I1Ii1i - OoO0O00 - Oo0o
   except :
    pass
    if 80 - 80: OoO0O00 * I1i1I % i1IIi11111i % Oo0o
  O000OoOO0 = iIiiiI ( O0O0ooOOOo0o00Ooo0o )
  Iii1ii1II11i = re . compile ( i1Ii11i1i ) . findall ( O000OoOO0 )
  for OoO000 , iI1 , IiI1I1 , iIIioO0o00oo0 in Iii1ii1II11i :
   try :
    if 95 - 95: OoO0O00 - IiIiI11iIi . I1i1I - Ii
    iIi1 ( iI1 , iIIioO0o00oo0 , 143 , OoO000 , IiI1I1 )
    if 75 - 75: Oo0oO0oo0oO00 + ooO - iiI1i1 . Ii11111i * I11i1i11i1I / oO0o0o0ooO0oO
   except :
    pass
 except :
  pass
  if 86 - 86: i11Ii11I1Ii1i * Ooo0OO0oOO - oo . i11Ii11I1Ii1i % OoO0O00 / i1111
def IiIIiIIIiIii ( ) :
 if 23 - 23: Iiii + i1IIi11111i . i11Ii11I1Ii1i * Ii + IiIiI11iIi
 try :
  if 18 - 18: oO0o0o0ooO0oO * ooO . oO0o0o0ooO0oO / oo
  IiI1iII1II111 = iIiiiI ( o0OO0 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( IiI1iII1II111 )
  for o00o0 in Iii1ii1II11i :
   if 8 - 8: ooO
   try :
    if 4 - 4: IiIiI11iIi + IiIiI11iIi * OoOoo0 - i11Ii11I1Ii1i
    O0O0ooOOOo0o00Ooo0o = o00o0
    if 78 - 78: I11i1i11i1I / Ooo0OO0oOO % i11Ii11I1Ii1i
   except :
    pass
    if 52 - 52: i1111 - Iiii * IIii11I1
  O000OoOO0 = iIiiiI ( O0O0ooOOOo0o00Ooo0o )
  Iii1ii1II11i = re . compile ( i1Ii11i1i ) . findall ( O000OoOO0 )
  for OoO000 , iI1 , IiI1I1 , iIIioO0o00oo0 in Iii1ii1II11i :
   try :
    if 17 - 17: Ii11111i + i1111 * i1IIi11111i * i11Ii11I1Ii1i
    iIi1 ( iI1 , iIIioO0o00oo0 , 143 , OoO000 , IiI1I1 )
    if 36 - 36: oo + Oo0o
   except :
    pass
 except :
  pass
  if 5 - 5: Oo0o * i11Ii11I1Ii1i
def ii1I11iIiIII1 ( ) :
 if 52 - 52: ooO * oO0o0o0ooO0oO + i11Ii11I1Ii1i
 try :
  if 49 - 49: OoO0O00 - oo . iiI1i1 - Ii11111i
  IiI1iII1II111 = iIiiiI ( OOooo0O0o0 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( IiI1iII1II111 )
  for o00o0 in Iii1ii1II11i :
   if 37 - 37: iiI1i1 . i1IIi11111i % i11Ii11I1Ii1i + Ii11111i / Iiii
   try :
    if 3 - 3: IiIiI11iIi
    O0O0ooOOOo0o00Ooo0o = o00o0
    if 17 - 17: IiIiI11iIi . Ooo0OO0oOO . OoOoo0 / IiIiI11iIi
   except :
    pass
    if 57 - 57: i1IIi11111i
  O000OoOO0 = iIiiiI ( O0O0ooOOOo0o00Ooo0o )
  Iii1ii1II11i = re . compile ( i1Ii11i1i ) . findall ( O000OoOO0 )
  for OoO000 , iI1 , IiI1I1 , iIIioO0o00oo0 in Iii1ii1II11i :
   try :
    if 67 - 67: Oo0oO0oo0oO00 . OoOoo0
    iIi1 ( iI1 , iIIioO0o00oo0 , 143 , OoO000 , IiI1I1 )
    if 87 - 87: IIii11I1 % I11i1i11i1I
   except :
    pass
 except :
  pass
  if 83 - 83: Ooo0OO0oOO - i1IIi11111i
def iiIii1IIi ( name , url ) :
 if 10 - 10: II111iiii - ooO % OoO0O00
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 49 - 49: IIii11I1
 IIIiiI1i1 = iIiiiI ( url )
 Iii1ii1II11i = re . compile ( oOo00O0oo00o0 ) . findall ( IIIiiI1i1 )
 for OOOOoOo00OO , name , IiI1I1 , url in Iii1ii1II11i :
  try :
   if 75 - 75: oo % i11Ii11I1Ii1i . oO0o0o0ooO0oO / oO0o0o0ooO0oO / Oo0oO0oo0oO00
   if 19 - 19: IiIiI11iIi % II111iiii . i1111 - Oo0o / Ii11111i
   oo0OOo = oo000 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % oo0OOo + name + '[/COLOR]'
   oOOo00O0OOOo ( name , url , 144 , OOOOoOo00OO , IiI1I1 )
   if 31 - 31: i1IIi11111i % i1111 * i1IIi11111i
   if 45 - 45: iiI1i1 . Ii + i1111 - Ii11111i % OoOoo0
  except :
   pass
   if 1 - 1: OoO0O00
   if 93 - 93: iiI1i1 . II111iiii . Oo0o
   if 99 - 99: i1IIi11111i - I1i1I - IIii11I1 % Oo0oO0oo0oO00
def oOOo00O0OOOo ( name , url , mode , iconimage , fanart ) :
 if 21 - 21: Ooo0OO0oOO % IiIiI11iIi . iiI1i1 - Ii11111i
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 4 - 4: Ii11111i . OoOoo0
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage="
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , fanart )
 II1iIi1IiIii . setProperty ( 'IsPlayable' , 'true' )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii )
 return I111I11I111
 if 46 - 46: II111iiii - oo . IIii11I1
 if 100 - 100: Ii / ooO * Iiii . oo / i1111
def oOO0o000Oo00o ( name , url ) :
 if 21 - 21: Ii11111i - OoO0O00
 if 93 - 93: IIii11I1 - ooO % i11Ii11I1Ii1i . i11Ii11I1Ii1i - OoOoo0
 IIiIiII11i = oo000 . getSetting ( 'licencia_addon' )
 o0oOOo0O0Ooo = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 I1ii11iIi11i = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 I1IiI = oo000 . getSetting ( 'key_ext' )
 o0OOO = iIiiiI ( I1ii11iIi11i )
 Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
 for IiII in Iii1ii1II11i :
  if 90 - 90: OoOoo0 + Ooo0OO0oOO * IiIiI11iIi / I11i1i11i1I . ooO + ooO
  try :
   if 40 - 40: OoOoo0 / i11Ii11I1Ii1i % II111iiii % IiIiI11iIi / Ii
   if 62 - 62: iiI1i1 - i11Ii11I1Ii1i
   IIiIiII11i = oo000 . getSetting ( 'licencia_addon' )
   if 62 - 62: iiI1i1 + Oo0o % oO0o0o0ooO0oO
   if 28 - 28: IiIiI11iIi . iiI1i1
   if IIiIiII11i == IiII :
    if 10 - 10: Oo0oO0oo0oO00 / Oo0o
    if 15 - 15: Iiii . i11Ii11I1Ii1i / Iiii * i1IIi11111i - Ii % IiIiI11iIi
    if 'https://team.com' in url :
     if 57 - 57: oo % i11Ii11I1Ii1i % IIii11I1
     url = url . replace ( 'https://team.com' , 'https://verystream.com' )
     if 45 - 45: IiIiI11iIi + Ooo0OO0oOO * II111iiii
    if 'https://mybox.com' in url :
     if 13 - 13: Ii11111i * IIii11I1 - I11i1i11i1I / i1111 + i1IIi11111i + oO0o0o0ooO0oO
     url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
     if 39 - 39: OoO0O00 - Ii11111i
     if 81 - 81: IiIiI11iIi - oo * Ii11111i
    if 'https://vidcloud.co/' in url :
     if 23 - 23: Ooo0OO0oOO / IIii11I1
     url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
     if 28 - 28: Oo0o * OoOoo0 - Oo0oO0oo0oO00
    if 'https://gounlimited.to' in url :
     if 19 - 19: i1IIi11111i
     url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
     if 67 - 67: oo % OoO0O00 / oO0o0o0ooO0oO . II111iiii - I11i1i11i1I + oo
    if 'https://drive.com' in url :
     if 27 - 27: i1111
     url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
     if 89 - 89: Ooo0OO0oOO / IIii11I1
     if 14 - 14: i1111 . Ii * OoOoo0 + Ooo0OO0oOO - OoOoo0 + i1111
    import resolveurl
    if 18 - 18: IIii11I1 - ooO - Ii - Ii
    OOooo00 = urlresolver . HostedMediaFile ( url )
    if 35 - 35: I1i1I . i11Ii11I1Ii1i * II111iiii
    if not OOooo00 :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
     return False
     if 44 - 44: II111iiii / Oo0o
    try :
     Ii1IIi = xbmcgui . DialogProgress ( )
     Ii1IIi . create ( 'Realstream:' , 'Iniciando ...' )
     Ii1IIi . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
     xbmc . sleep ( 1000 )
     i111i11I1ii = OOooo00 . resolve ( )
     if not i111i11I1ii or not isinstance ( i111i11I1ii , basestring ) :
      try : OOooo = i111i11I1ii . msg
      except : OOooo = url
      raise Exception ( OOooo )
      if 54 - 54: Ooo0OO0oOO . i1IIi11111i
    except Exception as iii11i1IIII :
     try : OOooo = str ( iii11i1IIII )
     except : OOooo = url
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,7000)" )
     if 73 - 73: i11Ii11I1Ii1i . Ii
    Ii1IIi . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    Ii1IIi . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
    xbmc . sleep ( 500 )
    Ii1IIi . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
    xbmc . sleep ( 500 )
    Ii1IIi . update ( 100 , 'RESOLVEURL:' , 'Disfrute de este capitulo!' )
    Ii1IIi . close ( )
    I1I1IiI1 = oo000 . getSetting ( 'notificar' )
    II1i11i1iIi11 = xbmcgui . ListItem ( path = i111i11I1ii )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
    if 83 - 83: I11i1i11i1I
    if 25 - 25: i1IIi11111i + i11Ii11I1Ii1i . ooO % i11Ii11I1Ii1i * i1111
   else :
    if 32 - 32: II111iiii - I1i1I
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold]>El addon esta desactivado.[/COLOR]" )
    if 53 - 53: Ii11111i - oO0o0o0ooO0oO
    if 87 - 87: IIii11I1 . Ii
  except :
   pass
   if 17 - 17: I11i1i11i1I . II111iiii
   if 5 - 5: IiIiI11iIi + oo + oo . I1i1I - OoOoo0
   if 63 - 63: IIii11I1
   if 71 - 71: iiI1i1 . I11i1i11i1I * Iiii % Ii11111i + i1111
   if 36 - 36: oO0o0o0ooO0oO
   if 49 - 49: i1111 / Ii11111i / Ii
def o0OooooOoOO ( ) :
 if 19 - 19: oO0o0o0ooO0oO
 if 78 - 78: i1111 % ooO
 IIIiIiI = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 IIIiIiI . doModal ( )
 if not IIIiIiI . isConfirmed ( ) :
  return None ;
 iI1 = IIIiIiI . getText ( ) . strip ( )
 if 7 - 7: oO0o0o0ooO0oO . i11Ii11I1Ii1i / IiIiI11iIi . i1111 * i1IIi11111i - Ooo0OO0oOO
 if 37 - 37: I1i1I . i11Ii11I1Ii1i / oo * Iiii
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 7 - 7: Oo0oO0oo0oO00 * i1IIi11111i + Ooo0OO0oOO % II111iiii
  iII11I1Ii1 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + iI1 + '&language=es-ES' ) )
  if 8 - 8: OoOoo0 * oo
  if 73 - 73: ooO / IIii11I1 / i1IIi11111i / Oo0oO0oo0oO00
  return 'android'
  if 11 - 11: i11Ii11I1Ii1i + oO0o0o0ooO0oO - Ii11111i / Oo0oO0oo0oO00
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 34 - 34: OoOoo0
  iII11I1Ii1 = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + iI1 + '&language=es-ES' )
  if 45 - 45: OoOoo0 / Oo0o / I11i1i11i1I
  if 44 - 44: IiIiI11iIi - I11i1i11i1I / Ooo0OO0oOO * Oo0oO0oo0oO00 * Oo0o
  return 'windows'
  if 73 - 73: ooO - Ii * iiI1i1 / II111iiii * i1111 % Ooo0OO0oOO
  if 56 - 56: Ii11111i * Oo0o . Oo0o . IiIiI11iIi
def II1 ( ) :
 if 74 - 74: Ii11111i % i1111 % I1i1I - Ii - i1IIi11111i
 try :
  if 58 - 58: oo
  o0OOO = iIiiiI ( OO0Oooo0oOO0O )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for o00o0 in Iii1ii1II11i :
   if 78 - 78: Oo0oO0oo0oO00 % oO0o0o0ooO0oO * iiI1i1
   try :
    if 66 - 66: I11i1i11i1I . Ii + ooO . OoO0O00
    all = o00o0
    if 51 - 51: i1IIi11111i . Oo0o
   except :
    pass
    if 45 - 45: iiI1i1 - Oo0o / oo . IiIiI11iIi
  IIIiiI1i1 = iIiiiI ( all )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( IIIiiI1i1 )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    if 5 - 5: ooO . OoO0O00 % OoO0O00
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 56 - 56: Ii11111i - i1IIi11111i - iiI1i1
   except :
    pass
 except :
  pass
  if 8 - 8: I1i1I / i1111 . Ii + IiIiI11iIi / II111iiii
def I1Iii1iI1 ( ) :
 if 86 - 86: oo
 try :
  if 95 - 95: Iiii * i1111 . i11Ii11I1Ii1i . iiI1i1 . iiI1i1 - ooO
  II11iiii1Ii = iIiiiI ( oOO0O00Oo0O0o )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( II11iiii1Ii )
  for o00o0 in Iii1ii1II11i :
   if 26 - 26: OoO0O00 % II111iiii % IiIiI11iIi
   try :
    if 67 - 67: Ii11111i
    O0O0ooOOOo0o00Ooo0o = o00o0
    if 29 - 29: oo - II111iiii - Ooo0OO0oOO + i1111 * oO0o0o0ooO0oO
   except :
    pass
    if 2 - 2: iiI1i1 - OoOoo0 + Ii . ooO * ooO / i11Ii11I1Ii1i
  O000OoOO0 = iIiiiI ( O0O0ooOOOo0o00Ooo0o )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( O000OoOO0 )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    if 93 - 93: iiI1i1
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 53 - 53: Ii11111i + Oo0o + IIii11I1
   except :
    pass
 except :
  pass
  if 24 - 24: Iiii - oO0o0o0ooO0oO - Iiii * IiIiI11iIi . Ii11111i / oO0o0o0ooO0oO
def o0OOoo ( ) :
 if 16 - 16: Ii * iiI1i1 - ooO . oO0o0o0ooO0oO % i1IIi11111i / ooO
 try :
  if 14 - 14: OoO0O00 * I1i1I * IiIiI11iIi / OoO0O00 * oO0o0o0ooO0oO / i1IIi11111i
  OO0o = iIiiiI ( I1iIIiiIIi1i )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( OO0o )
  for o00o0 in Iii1ii1II11i :
   if 77 - 77: Oo0oO0oo0oO00 + I1i1I + I1i1I * I11i1i11i1I / Ii11111i . I11i1i11i1I
   try :
    ooo0O0OO = o00o0
   except :
    pass
    if 61 - 61: oO0o0o0ooO0oO + OoO0O00 + II111iiii / II111iiii % Ooo0OO0oOO
  o0OOO = iIiiiI ( ooo0O0OO )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( o0OOO )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 42 - 42: I11i1i11i1I * I1i1I . oO0o0o0ooO0oO * Ii + i11Ii11I1Ii1i
   except :
    pass
 except :
  pass
  if 25 - 25: i1IIi11111i . Ii + IIii11I1
def O00OO0o0 ( ) :
 if 52 - 52: IiIiI11iIi % IIii11I1 - II111iiii
 try :
  if 30 - 30: Iiii / Oo0oO0oo0oO00 + IIii11I1
  o0OOO = iIiiiI ( db2 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for o00o0 in Iii1ii1II11i :
   if 6 - 6: Iiii . i1IIi11111i + I11i1i11i1I . I1i1I
   try :
    if 70 - 70: Oo0oO0oo0oO00
    i1iIi1111 = o00o0
    if 13 - 13: Oo0oO0oo0oO00
   except :
    pass
    if 37 - 37: I11i1i11i1I + I1i1I - Oo0o + I11i1i11i1I
    if 92 - 92: Ii11111i - Ii11111i * Oo0oO0oo0oO00 % Ii
  o0OOO = iIiiiI ( i1iIi1111 )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( o0OOO )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 77 - 77: OoO0O00 - iiI1i1 . IIii11I1
   except :
    pass
 except :
  pass
  if 26 - 26: ooO * oO0o0o0ooO0oO . iiI1i1
def ooOoOO ( ) :
 if 56 - 56: OoO0O00 . II111iiii - i1111 * Ooo0OO0oOO * I1i1I
 try :
  if 5 - 5: i1111 / i1111 - IiIiI11iIi
  oO0ooOO = iIiiiI ( IIIIiIiIi1 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( oO0ooOO )
  for o00o0 in Iii1ii1II11i :
   if 7 - 7: Ooo0OO0oOO - i1111 . Ooo0OO0oOO
   try :
    if 53 - 53: IIii11I1 % i1IIi11111i . OoOoo0 - i11Ii11I1Ii1i
    OoOoO0OoOOOOo = o00o0
    if 61 - 61: II111iiii * IIii11I1 . Iiii . OoOoo0 % Oo0oO0oo0oO00
   except :
    pass
    if 34 - 34: II111iiii - Ooo0OO0oOO / Ii % ooO
    if 33 - 33: i1111
  o0OOO = iIiiiI ( OoOoO0OoOOOOo )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( o0OOO )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 35 - 35: II111iiii - Ii / i1111 + I11i1i11i1I * IIii11I1
   except :
    pass
 except :
  pass
  if 49 - 49: ooO * I11i1i11i1I + i1IIi11111i + Iiii
def IIi11 ( ) :
 if 89 - 89: Ooo0OO0oOO * OoOoo0 . IIii11I1
 try :
  if 85 - 85: IiIiI11iIi + I11i1i11i1I * Ii % II111iiii
  o0OOO = iIiiiI ( oOOo0O00o )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for o00o0 in Iii1ii1II11i :
   if 42 - 42: i11Ii11I1Ii1i / iiI1i1 * Ii
   try :
    if 12 - 12: I1i1I % II111iiii + ooO + I1i1I / i1IIi11111i
    O00O0O = o00o0
    if 72 - 72: I1i1I . IiIiI11iIi % i11Ii11I1Ii1i . II111iiii
   except :
    pass
    if 53 - 53: IiIiI11iIi / oO0o0o0ooO0oO / Ii11111i / Ooo0OO0oOO
    if 32 - 32: OoO0O00 . II111iiii / IIii11I1
  o0OOO = iIiiiI ( O00O0O )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( o0OOO )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 52 - 52: Ii + OoO0O00
   except :
    pass
 except :
  pass
  if 71 - 71: oo / IIii11I1
def iI1iiII11I ( ) :
 if 32 - 32: i1111 % OoOoo0 - i11Ii11I1Ii1i % Iiii . I1i1I
 try :
  if 47 - 47: i1IIi11111i % iiI1i1 + iiI1i1
  o0OOO = iIiiiI ( OOOiiiiI )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for o00o0 in Iii1ii1II11i :
   if 87 - 87: Oo0o * i1111 % oO0o0o0ooO0oO % i11Ii11I1Ii1i
   try :
    if 4 - 4: i11Ii11I1Ii1i + I11i1i11i1I / IIii11I1
    i1iI1IIIII1 = o00o0
    if 39 - 39: IiIiI11iIi % Oo0oO0oo0oO00 % I11i1i11i1I
   except :
    pass
    if 55 - 55: oo - I1i1I
  o0OOO = iIiiiI ( i1iI1IIIII1 )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( o0OOO )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 58 - 58: i11Ii11I1Ii1i - Iiii - Ii11111i
   except :
    pass
 except :
  pass
  if 96 - 96: OoO0O00
def OOOo00 ( ) :
 if 91 - 91: OoO0O00 . ooO . IiIiI11iIi + Ii11111i
 try :
  if 69 - 69: I1i1I - Ii
  o0OOO = iIiiiI ( OOoO )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for o00o0 in Iii1ii1II11i :
   if 95 - 95: Ii * II111iiii . OoOoo0
   try :
    if 41 - 41: Ooo0OO0oOO
    I1 = o00o0
    if 83 - 83: oO0o0o0ooO0oO * i1IIi11111i / Oo0o
   except :
    pass
    if 32 - 32: ooO + i11Ii11I1Ii1i - Ii11111i
    if 39 - 39: Ii11111i * i1111 * oo . i1IIi11111i . Oo0oO0oo0oO00 + OoOoo0
  o0OOO = iIiiiI ( I1 )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( o0OOO )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 9 - 9: i11Ii11I1Ii1i + IIii11I1 % Ii11111i + ooO
   except :
    pass
 except :
  pass
  if 56 - 56: Ii11111i + IiIiI11iIi - Iiii
def III1I1 ( ) :
 if 12 - 12: OoO0O00 % OoOoo0 % OoOoo0
 try :
  if 78 - 78: oO0o0o0ooO0oO . i11Ii11I1Ii1i . i1IIi11111i
  o0OOO = iIiiiI ( iiIiI1i1 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for o00o0 in Iii1ii1II11i :
   if 97 - 97: IIii11I1
   try :
    if 80 - 80: Ii . I11i1i11i1I
    I1I11ii = o00o0
    if 93 - 93: IiIiI11iIi % i11Ii11I1Ii1i . oo / Iiii * IIii11I1
   except :
    pass
    if 29 - 29: ooO
    if 86 - 86: Ooo0OO0oOO . oO0o0o0ooO0oO
  o0OOO = iIiiiI ( I1I11ii )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( o0OOO )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 2 - 2: Ii11111i
   except :
    pass
 except :
  pass
  if 60 - 60: Oo0oO0oo0oO00
def oO00Ooo0oO ( ) :
 if 100 - 100: Oo0oO0oo0oO00 / iiI1i1 - Ii % I11i1i11i1I - OoO0O00
 try :
  if 17 - 17: i1IIi11111i / ooO % Oo0o
  o0OOO = iIiiiI ( IiIi11iI )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for o00o0 in Iii1ii1II11i :
   if 71 - 71: oO0o0o0ooO0oO . I1i1I . Oo0oO0oo0oO00
   try :
    if 68 - 68: II111iiii % IIii11I1 * Oo0oO0oo0oO00 * oO0o0o0ooO0oO * Ooo0OO0oOO + oo
    o00OoO0oO00 = o00o0
    if 2 - 2: OoO0O00
   except :
    pass
    if 45 - 45: Ii11111i / II111iiii
    if 10 - 10: Iiii - IIii11I1 * OoO0O00 % OoO0O00 * oO0o0o0ooO0oO - IiIiI11iIi
  o0OOO = iIiiiI ( o00OoO0oO00 )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( o0OOO )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 97 - 97: Ooo0OO0oOO % I1i1I + I1i1I - Oo0oO0oo0oO00 / I11i1i11i1I * Ii
   except :
    pass
 except :
  pass
  if 17 - 17: I11i1i11i1I
def i1i1IiIi1 ( ) :
 if 22 - 22: i1IIi11111i * oo . Ooo0OO0oOO - Oo0oO0oo0oO00
 try :
  if 90 - 90: IIii11I1
  o0OOO = iIiiiI ( iI1i11 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for o00o0 in Iii1ii1II11i :
   if 94 - 94: i1IIi11111i / IiIiI11iIi * I1i1I - i11Ii11I1Ii1i
   try :
    if 44 - 44: I11i1i11i1I % II111iiii - Iiii * IiIiI11iIi + Oo0o * i1111
    IiI1iI1IiiIi1 = o00o0
    if 90 - 90: oo + i1IIi11111i - Ii11111i . i1IIi11111i
   except :
    pass
    if 60 - 60: ooO . ooO / Iiii
    if 45 - 45: oo . II111iiii % Iiii . i11Ii11I1Ii1i % oO0o0o0ooO0oO % OoO0O00
  o0OOO = iIiiiI ( IiI1iI1IiiIi1 )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( o0OOO )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 58 - 58: OoO0O00 . i11Ii11I1Ii1i - II111iiii * OoO0O00 % II111iiii / Ii
   except :
    pass
 except :
  pass
  if 80 - 80: IiIiI11iIi / OoO0O00 % i11Ii11I1Ii1i
  if 80 - 80: Oo0oO0oo0oO00 % Iiii
def O0Oo0 ( ) :
 if 80 - 80: Ii - OoO0O00 . i1111 + Oo0oO0oo0oO00 - I1i1I
 try :
  if 5 - 5: Iiii
  o0OOO = iIiiiI ( i11I1IiII1i1i )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for o00o0 in Iii1ii1II11i :
   if 62 - 62: i11Ii11I1Ii1i . Ii11111i . i1111 . Oo0oO0oo0oO00 * Iiii
   try :
    if 78 - 78: IIii11I1 / Oo0oO0oo0oO00 - IIii11I1 * Ii11111i . i11Ii11I1Ii1i
    OOoooOoO0Oo = o00o0
    if 78 - 78: Ii11111i / i1111 % i11Ii11I1Ii1i * Ii11111i
   except :
    pass
    if 68 - 68: IIii11I1
    if 29 - 29: Iiii + II111iiii % i1IIi11111i
  o0OOO = iIiiiI ( OOoooOoO0Oo )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( o0OOO )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 93 - 93: i11Ii11I1Ii1i % OoO0O00
   except :
    pass
 except :
  pass
  if 90 - 90: Ii - i1111 / I11i1i11i1I / oo / i1IIi11111i
  if 87 - 87: i11Ii11I1Ii1i / oO0o0o0ooO0oO + OoO0O00
def oo0O0o ( ) :
 if 13 - 13: OoO0O00 . i11Ii11I1Ii1i * Ii / IIii11I1 * I11i1i11i1I
 try :
  if 64 - 64: OoOoo0 / oo * i11Ii11I1Ii1i * OoOoo0
  o0OOO = iIiiiI ( iIIii )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for o00o0 in Iii1ii1II11i :
   if 60 - 60: i1IIi11111i / iiI1i1 % IiIiI11iIi / IiIiI11iIi * IiIiI11iIi . II111iiii
   try :
    if 99 - 99: i11Ii11I1Ii1i
    oO00OoOo = o00o0
    if 74 - 74: Ooo0OO0oOO . oo - Ii + oO0o0o0ooO0oO % II111iiii % i11Ii11I1Ii1i
   except :
    pass
    if 78 - 78: I11i1i11i1I + i11Ii11I1Ii1i + oO0o0o0ooO0oO - oO0o0o0ooO0oO . II111iiii / Oo0oO0oo0oO00
    if 27 - 27: I11i1i11i1I - oo % i1IIi11111i * I1i1I . oO0o0o0ooO0oO % OoO0O00
  o0OOO = iIiiiI ( oO00OoOo )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( o0OOO )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 37 - 37: Ii11111i + oo - iiI1i1 % OoOoo0
   except :
    pass
    if 24 - 24: i11Ii11I1Ii1i
 except :
  pass
  if 94 - 94: iiI1i1 * iiI1i1 % Ooo0OO0oOO + i1111
  if 28 - 28: Ii
def I11 ( ) :
 if 54 - 54: I11i1i11i1I - I1i1I
 try :
  if 81 - 81: oO0o0o0ooO0oO . oo + Ooo0OO0oOO * OoO0O00 * i1111 / i11Ii11I1Ii1i
  o0OOO = iIiiiI ( ii1iii1i )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for o00o0 in Iii1ii1II11i :
   if 88 - 88: Ooo0OO0oOO - ooO * Ii . Oo0oO0oo0oO00
   try :
    if 65 - 65: oO0o0o0ooO0oO . iiI1i1
    OOOoO0 = o00o0
    if 85 - 85: OoO0O00 / Ii11111i % Ooo0OO0oOO
   except :
    pass
    if 49 - 49: II111iiii % i11Ii11I1Ii1i + I1i1I . Ooo0OO0oOO % Iiii * i1111
    if 67 - 67: iiI1i1
  o0OOO = iIiiiI ( OOOoO0 )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( o0OOO )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 5 - 5: Ooo0OO0oOO . Ii11111i
   except :
    pass
    if 57 - 57: Ii
 except :
  pass
  if 35 - 35: Ii11111i - I1i1I / Oo0oO0oo0oO00
def iii11i1 ( ) :
 if 48 - 48: OoOoo0 * IiIiI11iIi
 try :
  if 15 - 15: Oo0oO0oo0oO00 * i1IIi11111i % OoO0O00 * IiIiI11iIi
  o0OOO = iIiiiI ( ooOoO00 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for o00o0 in Iii1ii1II11i :
   if 31 - 31: Oo0oO0oo0oO00 * oo . IIii11I1
   try :
    if 59 - 59: Ooo0OO0oOO * II111iiii
    ooOooO00Oo = o00o0
    if 86 - 86: Ooo0OO0oOO + OoOoo0 + oO0o0o0ooO0oO
   except :
    pass
    if 9 - 9: OoOoo0 + Ooo0OO0oOO % OoOoo0 % oO0o0o0ooO0oO + OoO0O00
  o0OOO = iIiiiI ( ooOooO00Oo )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( o0OOO )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 59 - 59: iiI1i1
   except :
    pass
 except :
  pass
  if 48 - 48: oo * I11i1i11i1I * Oo0oO0oo0oO00 . Oo0oO0oo0oO00 * i1IIi11111i - I11i1i11i1I
  if 14 - 14: IiIiI11iIi + II111iiii
def OOOoo ( ) :
 if 27 - 27: i11Ii11I1Ii1i * oO0o0o0ooO0oO - i11Ii11I1Ii1i + iiI1i1 % Ooo0OO0oOO . OoOoo0
 try :
  if 7 - 7: IiIiI11iIi - IIii11I1 * i1111 + ooO . IiIiI11iIi
  o0OOO = iIiiiI ( o0O00Oo0 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for o00o0 in Iii1ii1II11i :
   if 85 - 85: oo
   try :
    if 32 - 32: Ii11111i . Oo0oO0oo0oO00 / Oo0o * ooO / ooO * I11i1i11i1I
    iI111i11iI1 = o00o0
    if 2 - 2: i11Ii11I1Ii1i + I1i1I + Ii11111i . iiI1i1
   except :
    pass
    if 19 - 19: Iiii - ooO - I11i1i11i1I - i11Ii11I1Ii1i . Iiii . I1i1I
    if 48 - 48: Iiii + oO0o0o0ooO0oO
  o0OOO = iIiiiI ( iI111i11iI1 )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( o0OOO )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 60 - 60: i1IIi11111i + Iiii . oO0o0o0ooO0oO / iiI1i1 . OoO0O00
   except :
    pass
 except :
  pass
  if 14 - 14: i1111
  if 79 - 79: I11i1i11i1I
def o0Oii111 ( ) :
 if 93 - 93: Ii11111i * Oo0o
 try :
  if 10 - 10: I1i1I * Ii11111i + i1IIi11111i - IiIiI11iIi / IiIiI11iIi . II111iiii
  o0OOO = iIiiiI ( i111iIi1i1II1 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for o00o0 in Iii1ii1II11i :
   if 22 - 22: I1i1I / ooO
   try :
    if 98 - 98: iiI1i1
    OOO0oO = o00o0
    if 38 - 38: OoO0O00 / OoOoo0
   except :
    pass
  o0OOO = iIiiiI ( OOO0oO )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( o0OOO )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 13 - 13: OoO0O00
   except :
    pass
 except :
  pass
  if 77 - 77: II111iiii - OoO0O00 / IIii11I1 / OoOoo0 / Oo0oO0oo0oO00
def ooo0O0o0OoOO ( ) :
 if 9 - 9: Oo0oO0oo0oO00
 try :
  if 60 - 60: I1i1I
  o0OOO = iIiiiI ( i1I1i111Ii )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for o00o0 in Iii1ii1II11i :
   if 98 - 98: OoOoo0
   try :
    if 34 - 34: OoO0O00 * i1IIi11111i * i1IIi11111i / IiIiI11iIi
    IIIIIIi1i = o00o0
    if 26 - 26: OoO0O00 - oo . oo
   except :
    pass
    if 68 - 68: i1111 + IIii11I1 . oo . I11i1i11i1I % iiI1i1 % i1111
    if 50 - 50: oO0o0o0ooO0oO + ooO
  o0OOO = iIiiiI ( IIIIIIi1i )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( o0OOO )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 96 - 96: Oo0oO0oo0oO00
   except :
    pass
 except :
  pass
  if 92 - 92: Oo0o / II111iiii + IiIiI11iIi
  if 87 - 87: i11Ii11I1Ii1i % OoO0O00
def o0OO0OOO0O ( ) :
 if 36 - 36: II111iiii / Iiii . i1IIi11111i + oO0o0o0ooO0oO . oo + Ii
 try :
  if 36 - 36: iiI1i1 - IiIiI11iIi - I1i1I
  o0OOO = iIiiiI ( i1i1iI1iiiI )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for o00o0 in Iii1ii1II11i :
   if 7 - 7: II111iiii + Ii
   try :
    if 47 - 47: I1i1I - i1111 / OoOoo0 - Oo0o + Iiii - OoO0O00
    o0OOOOO0 = o00o0
    if 79 - 79: Ooo0OO0oOO - OoOoo0 . iiI1i1 + oo % oo * Ii
   except :
    pass
    if 7 - 7: iiI1i1 + i1111 % Iiii / ooO + iiI1i1
    if 41 - 41: I11i1i11i1I + II111iiii / oO0o0o0ooO0oO % IiIiI11iIi
  o0OOO = iIiiiI ( o0OOOOO0 )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( o0OOO )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 22 - 22: i11Ii11I1Ii1i % ooO * I11i1i11i1I - IiIiI11iIi + ooO - Oo0o
   except :
    pass
 except :
  pass
  if 15 - 15: i1111
def i1iiI ( ) :
 if 83 - 83: IIii11I1 / OoO0O00 + iiI1i1 / Iiii
 try :
  if 47 - 47: IIii11I1 + Ii11111i . Ooo0OO0oOO . Iiii
  o0OOO = iIiiiI ( oOOOoo00 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for o00o0 in Iii1ii1II11i :
   if 66 - 66: OoOoo0 * i11Ii11I1Ii1i
   try :
    if 2 - 2: IIii11I1 . I1i1I * Oo0o + oo - i1IIi11111i * OoO0O00
    II111i1ii1iII = o00o0
    if 75 - 75: OoO0O00 + Ii11111i
   except :
    pass
    if 97 - 97: IiIiI11iIi / Oo0o + I1i1I
    if 32 - 32: OoOoo0 % I1i1I * Oo0o
  o0OOO = iIiiiI ( II111i1ii1iII )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( o0OOO )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 72 - 72: OoOoo0 . Iiii - I1i1I - I11i1i11i1I % iiI1i1
   except :
    pass
 except :
  pass
  if 56 - 56: Oo0o * Iiii
  if 13 - 13: Oo0o * Oo0o * Ooo0OO0oOO * Iiii . iiI1i1 / oO0o0o0ooO0oO
def O0Oo000OO000 ( ) :
 if 83 - 83: ooO % IIii11I1 + i1IIi11111i % II111iiii + oo
 try :
  if 65 - 65: OoO0O00 % IIii11I1 + oo / Ii11111i
  o0OOO = iIiiiI ( iiI1IIIi )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for o00o0 in Iii1ii1II11i :
   if 52 - 52: I11i1i11i1I % i1111 * Ii % i1IIi11111i + i1111 / Iiii
   try :
    if 80 - 80: Ii11111i + oO0o0o0ooO0oO
    O00O = o00o0
    if 63 - 63: Ii11111i * Ii11111i % Oo0oO0oo0oO00 + oo / I1i1I + OoO0O00
   except :
    pass
    if 72 - 72: i11Ii11I1Ii1i * OoO0O00 % i1IIi11111i
    if 20 - 20: Ooo0OO0oOO % OoO0O00 + IIii11I1 * Ooo0OO0oOO * Oo0oO0oo0oO00 % Oo0oO0oo0oO00
  o0OOO = iIiiiI ( O00O )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( o0OOO )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 15 - 15: IIii11I1 / I1i1I
   except :
    pass
 except :
  pass
  if 37 - 37: II111iiii + Ii . i1111 % i1IIi11111i % i1IIi11111i
  if 26 - 26: oo
def i111I1iiIiII ( ) :
 if 97 - 97: Ooo0OO0oOO - I1i1I - OoO0O00 * Ii
 try :
  if 54 - 54: OoO0O00
  o0OOO = iIiiiI ( II )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for o00o0 in Iii1ii1II11i :
   if 5 - 5: oO0o0o0ooO0oO
   try :
    if 84 - 84: Ooo0OO0oOO * IIii11I1 * Ooo0OO0oOO % oO0o0o0ooO0oO / Ii
    O0Oooo = o00o0
    if 27 - 27: OoOoo0 + II111iiii * i1IIi11111i + i11Ii11I1Ii1i + Iiii
   except :
    pass
    if 87 - 87: oo
    if 87 - 87: ooO / Ooo0OO0oOO
  o0OOO = iIiiiI ( O0Oooo )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( o0OOO )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 90 - 90: OoOoo0 - IiIiI11iIi - oo + I11i1i11i1I
   except :
    pass
 except :
  pass
  if 68 - 68: i1111 . Oo0o % OoOoo0 - Ii11111i * Iiii . i1111
  if 46 - 46: II111iiii - i1111 * Ii * i1IIi11111i % IiIiI11iIi * iiI1i1
def Iii1I ( ) :
 if 40 - 40: oO0o0o0ooO0oO * oo
 try :
  if 86 - 86: I11i1i11i1I
  o0OOO = iIiiiI ( I1iiii1I )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for o00o0 in Iii1ii1II11i :
   if 29 - 29: OoO0O00 - Oo0oO0oo0oO00 + Ii % OoO0O00 % i1111
   try :
    if 84 - 84: oO0o0o0ooO0oO + IiIiI11iIi + I11i1i11i1I + Iiii
    ooOOo0o = o00o0
    if 50 - 50: Ooo0OO0oOO - I1i1I + OoO0O00 + OoO0O00
   except :
    pass
    if 91 - 91: Ooo0OO0oOO - oo . OoO0O00 . oo + IiIiI11iIi - Ooo0OO0oOO
    if 26 - 26: ooO
  o0OOO = iIiiiI ( ooOOo0o )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( o0OOO )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 12 - 12: Ii11111i / oo + Ooo0OO0oOO * IiIiI11iIi
   except :
    pass
 except :
  pass
  if 46 - 46: Ooo0OO0oOO - oO0o0o0ooO0oO * Ii11111i / IIii11I1 % oO0o0o0ooO0oO
  if 11 - 11: OoO0O00 . i11Ii11I1Ii1i / oO0o0o0ooO0oO % OoOoo0
def o0O00Oooo ( ) :
 if 12 - 12: OoOoo0
 try :
  if 86 - 86: IIii11I1 - Oo0oO0oo0oO00
  o0OOO = iIiiiI ( oO00ooooO0o )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for o00o0 in Iii1ii1II11i :
   if 63 - 63: Ii / i11Ii11I1Ii1i + Ii11111i . i1IIi11111i . OoOoo0
   try :
    if 48 - 48: iiI1i1 - Iiii - II111iiii . i1IIi11111i - Iiii * i1IIi11111i
    OOOOO = o00o0
    if 68 - 68: i1IIi11111i + Oo0oO0oo0oO00 - oo / Oo0oO0oo0oO00 * i11Ii11I1Ii1i
   except :
    pass
    if 50 - 50: i1111 + Ooo0OO0oOO . Ii / iiI1i1 / Ii * IIii11I1
  o0OOO = iIiiiI ( OOOOO )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( o0OOO )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 85 - 85: Ooo0OO0oOO . OoOoo0 % i1111 % i1IIi11111i
   except :
    pass
 except :
  pass
  if 80 - 80: IIii11I1 * i1IIi11111i / OoO0O00 % IIii11I1 / OoO0O00
  if 42 - 42: iiI1i1 / II111iiii . Oo0o * Iiii . II111iiii * oo
def Iii ( ) :
 if 35 - 35: oO0o0o0ooO0oO . Ii11111i / i1111
 try :
  if 52 - 52: I1i1I % i11Ii11I1Ii1i + OoO0O00 * IIii11I1 . I11i1i11i1I
  o0OOO = iIiiiI ( o0oO0oooOoo )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for o00o0 in Iii1ii1II11i :
   if 95 - 95: OoO0O00 . oO0o0o0ooO0oO - Ii11111i * Oo0oO0oo0oO00 / ooO
   try :
    if 74 - 74: IIii11I1
    iII1i1IIiI1I = o00o0
    if 67 - 67: I11i1i11i1I
   except :
    pass
    if 43 - 43: Oo0oO0oo0oO00 % Oo0oO0oo0oO00
    if 46 - 46: Oo0o % OoO0O00 . Iiii . oo * OoOoo0 / Ii11111i
  o0OOO = iIiiiI ( iII1i1IIiI1I )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( o0OOO )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 7 - 7: IIii11I1 - oo * i1IIi11111i - ooO - Ooo0OO0oOO
   except :
    pass
 except :
  pass
  if 41 - 41: Ii - I1i1I % Ooo0OO0oOO . I1i1I - i1IIi11111i
def i1I111Ii ( ) :
 if 31 - 31: Ii
 try :
  if 73 - 73: OoOoo0 . oo / ooO - Ii11111i % II111iiii
  o0OOO = iIiiiI ( I1i111I )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for o00o0 in Iii1ii1II11i :
   if 80 - 80: I11i1i11i1I / OoOoo0 % oo . Oo0o
   try :
    if 63 - 63: i1111 . Ooo0OO0oOO . i1IIi11111i
    I1I1IIIIi11 = o00o0
    if 68 - 68: iiI1i1 - IiIiI11iIi / Oo0o % i1IIi11111i . Iiii
   except :
    pass
  o0OOO = iIiiiI ( I1I1IIIIi11 )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( o0OOO )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 9 - 9: oO0o0o0ooO0oO
   except :
    pass
 except :
  pass
  if 48 - 48: ooO + ooO - Oo0o
def iI1I11i ( ) :
 if 13 - 13: i1IIi11111i . OoO0O00 * i11Ii11I1Ii1i / I1i1I % Oo0o
 try :
  if 96 - 96: OoO0O00 + II111iiii - Oo0o . OoOoo0
  o0OOO = iIiiiI ( I1i11 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for o00o0 in Iii1ii1II11i :
   if 31 - 31: OoO0O00 % II111iiii - oO0o0o0ooO0oO
   try :
    if 89 - 89: i11Ii11I1Ii1i % OoO0O00
    III11I1 = o00o0
    if 61 - 61: i11Ii11I1Ii1i - Oo0oO0oo0oO00 + Ii * i1111 % Oo0oO0oo0oO00
   except :
    pass
  o0OOO = iIiiiI ( III11I1 )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( o0OOO )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 24 - 24: OoOoo0 - i1IIi11111i * IIii11I1
   except :
    pass
 except :
  pass
  if 87 - 87: I11i1i11i1I - IiIiI11iIi % IiIiI11iIi . IIii11I1 / IiIiI11iIi
def II1i ( ) :
 if 94 - 94: I11i1i11i1I . iiI1i1
 try :
  if 71 - 71: Iiii + Oo0oO0oo0oO00 - oO0o0o0ooO0oO . Oo0oO0oo0oO00 . oO0o0o0ooO0oO + Ii
  o0OOO = iIiiiI ( ii1I1IIii11 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for o00o0 in Iii1ii1II11i :
   if 26 - 26: oo
   try :
    if 17 - 17: Ooo0OO0oOO
    iiIiii = o00o0
    if 39 - 39: Ii + Oo0o
   except :
    pass
  o0OOO = iIiiiI ( iiIiii )
  Iii1ii1II11i = re . compile ( I1I1I ) . findall ( o0OOO )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 , id , ii1IIII in Iii1ii1II11i :
   try :
    oOo ( iI1 , iIIioO0o00oo0 , iii1i1I1i1 , id , ii1IIII )
    if 83 - 83: iiI1i1
   except :
    pass
 except :
  pass
  if 76 - 76: I11i1i11i1I + OoO0O00 + i11Ii11I1Ii1i . Oo0oO0oo0oO00
def i1i1 ( ) :
 if 68 - 68: I11i1i11i1I - Ii
 try :
  if 41 - 41: IIii11I1
  o0OOO = iIiiiI ( IiIIi1 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for o00o0 in Iii1ii1II11i :
   if 21 - 21: OoOoo0 + ooO % I1i1I + II111iiii + Iiii + Ooo0OO0oOO
   try :
    if 98 - 98: I1i1I
    IIIIIIi1IiIi = o00o0
    if 14 - 14: Oo0oO0oo0oO00 / OoOoo0 - i1111 / Ii
   except :
    pass
  o0OOO = iIiiiI ( IIIIIIi1IiIi )
  Iii1ii1II11i = re . compile ( OO ) . findall ( o0OOO )
  for iii1i1I1i1 , iI1 , iIIioO0o00oo0 in Iii1ii1II11i :
   try :
    Ii1IIIi ( iii1i1I1i1 , iI1 , iIIioO0o00oo0 )
    if 70 - 70: i11Ii11I1Ii1i . i1111 * oO0o0o0ooO0oO + i1IIi11111i
   except :
    pass
    if 77 - 77: IIii11I1 % II111iiii . i1111 % i1111
 except :
  pass
  if 36 - 36: Oo0o % I11i1i11i1I / II111iiii % I1i1I + Oo0oO0oo0oO00
  if 23 - 23: Ooo0OO0oOO
  if 93 - 93: IIii11I1 . i1IIi11111i / iiI1i1
def Ii1IIIi ( thumb , name , url ) :
 if 50 - 50: I1i1I / iiI1i1 % Ii11111i
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OOO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   iIi1 ( name , url , '' , OoO000 , IiI1I1 )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 83 - 83: IiIiI11iIi * IiIiI11iIi + i1111
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OOO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 57 - 57: oo - oo . IiIiI11iIi / ooO / I11i1i11i1I
   I1IiII1I1i1I1 ( name , url , 4 , OOOOoOo00OO , IiI1I1 )
   if 28 - 28: Oo0o + oO0o0o0ooO0oO % Ooo0OO0oOO / Oo0oO0oo0oO00 + II111iiii
  else :
   if 20 - 20: IiIiI11iIi
   I1IiII1I1i1I1 ( name , url , 4 , OOOOoOo00OO , IiI1I1 )
   if 3 - 3: Oo0oO0oo0oO00 * iiI1i1 . Ii . oo - i11Ii11I1Ii1i
def oOo ( name , url , thumb , id , trailer ) :
 if 81 - 81: Ii - OoO0O00 / Ii / oo
 if 34 - 34: I11i1i11i1I * I11i1i11i1I - IiIiI11iIi - oo . II111iiii
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 32 - 32: OoO0O00 . Oo0oO0oo0oO00 * IIii11I1 / i1111 . Ooo0OO0oOO - Oo0o
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OOO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   iIi1 ( name , url , '' , OoO000 , IiI1I1 )
 else :
  oo0OOo = oo000 . getSetting ( 'Fontcolor' )
  if 10 - 10: IiIiI11iIi / II111iiii - I11i1i11i1I + IIii11I1 * Ii
  name = '[COLOR %s]' % oo0OOo + name + '[/COLOR]'
  if 94 - 94: Ii + OoO0O00 / oo - Ii11111i % IiIiI11iIi
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OOO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   oo00O00oO = oo000 . getSetting ( 'selecton' )
   if oo00O00oO == 'true' :
    if 64 - 64: i1IIi11111i + Oo0oO0oo0oO00
    IiIi11iiIIiI1 ( name , url , 1 , thumb , thumb , id , trailer )
    if 6 - 6: oO0o0o0ooO0oO * Ii11111i + I1i1I / I11i1i11i1I
   else :
    if 35 - 35: OoOoo0 % Ii - OoOoo0 - Oo0oO0oo0oO00 - Ii11111i
    IiIi11iiIIiI1 ( name , url , 130 , thumb , thumb , id , trailer )
    if 46 - 46: iiI1i1 . iiI1i1 . IIii11I1 / i1IIi11111i / OoOoo0
  else :
   if 34 - 34: Ii11111i / Oo0o * II111iiii . Ooo0OO0oOO . Ii11111i
   if oo00O00oO == 'true' :
    if 59 - 59: II111iiii . Ii11111i / i1IIi11111i * IiIiI11iIi + Ii11111i
    IiIi11iiIIiI1 ( name , url , 1 , thumb , thumb , id , trailer )
    if 3 - 3: II111iiii * Oo0o % OoO0O00 % Ii * Iiii / i1111
   else :
    if 95 - 95: oO0o0o0ooO0oO * oo * I1i1I . Ii11111i % Oo0o + IiIiI11iIi
    IiIi11iiIIiI1 ( name , url , 130 , thumb , thumb , id , trailer )
    if 98 - 98: IIii11I1 . Ii11111i
    if 54 - 54: oo / oO0o0o0ooO0oO % OoOoo0 * iiI1i1 * oo
def IIOOOoO00O ( name , trailer ) :
 if 27 - 27: IiIiI11iIi * iiI1i1 . iiI1i1
 if I1I1IiI1 == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Realstream, Reproduciendo Trailer de: [COLOR green]" + name + "[/COLOR] ,5000)" )
  if 87 - 87: oO0o0o0ooO0oO / I1i1I - Oo0o
  iIIioO0o00oo0 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  oOOoOOO0oOoo = iIIioO0o00oo0
  o0O0ooooooo00 = xbmcgui . ListItem ( name , trailer , path = oOOoOOO0oOoo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o0O0ooooooo00 )
 else :
  iIIioO0o00oo0 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  oOOoOOO0oOoo = iIIioO0o00oo0
  o0O0ooooooo00 = xbmcgui . ListItem ( name , trailer , path = oOOoOOO0oOoo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o0O0ooooooo00 )
  if 28 - 28: OoOoo0 * i1IIi11111i % II111iiii * Iiii / I11i1i11i1I
  if 41 - 41: i1111 - ooO + I11i1i11i1I
def i1II ( trailer ) :
 if 79 - 79: i11Ii11I1Ii1i % Ii % I11i1i11i1I / iiI1i1 % Oo0oO0oo0oO00
 if 'https://www.youtube.com' in trailer :
  if 56 - 56: OoO0O00 - II111iiii * Iiii
  try :
   if 84 - 84: i1111 + I11i1i11i1I + ooO
   import resolveurl
   if 33 - 33: I11i1i11i1I
   OOooo00 = urlresolver . HostedMediaFile ( iIIioO0o00oo0 )
   Ii1IIi = xbmcgui . DialogProgress ( )
   Ii1IIi . create ( 'Realstream:' , 'Conectando al servidor ... ' )
   Ii1IIi . update ( 20 , 'Por favor, espere ...' )
   xbmc . sleep ( 500 )
   if 93 - 93: OoOoo0
   if not OOooo00 :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    return False
    if 34 - 34: IIii11I1 - OoOoo0 * Oo0o / ooO
   try :
    if 19 - 19: IiIiI11iIi
    Ii1IIi . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    i111i11I1ii = OOooo00 . resolve ( )
    if not i111i11I1ii or not isinstance ( i111i11I1ii , basestring ) :
     try : OOooo = i111i11I1ii . msg
     except : OOooo = i111i11I1ii
     raise Exception ( OOooo )
   except Exception as iii11i1IIII :
    try : OOooo = str ( iii11i1IIII )
    except : OOooo = i111i11I1ii
    Ii1IIi . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
    Ii1IIi . close ( )
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    if 46 - 46: OoO0O00 . II111iiii - i11Ii11I1Ii1i % oo / Ooo0OO0oOO * iiI1i1
   Ii1IIi . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
   xbmc . sleep ( 500 )
   Ii1IIi . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   Ii1IIi . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
   xbmc . sleep ( 500 )
   Ii1IIi . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   Ii1IIi . close ( )
   if 66 - 66: oo
   II1i11i1iIi11 = xbmcgui . ListItem ( path = i111i11I1ii )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
   if 52 - 52: Oo0oO0oo0oO00 * Ii11111i
  except :
   pass
   if 12 - 12: oo + oO0o0o0ooO0oO * iiI1i1 . Oo0oO0oo0oO00
  else :
   if 71 - 71: I1i1I - ooO - i1111
   iIIioO0o00oo0 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
   oOOoOOO0oOoo = iIIioO0o00oo0
   o0O0ooooooo00 = xbmcgui . ListItem ( trailer , path = oOOoOOO0oOoo )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o0O0ooooooo00 )
   return
   if 28 - 28: OoO0O00
def iI11II1i1I1 ( name , url ) :
 if 72 - 72: Iiii - Ii11111i
 if '[Youtube]' in name :
  if 25 - 25: i11Ii11I1Ii1i % Ii11111i * Oo0o - iiI1i1 * Ooo0OO0oOO * IIii11I1
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  oOOoOOO0oOoo = url
  o0O0ooooooo00 = xbmcgui . ListItem ( ii1IIII , path = oOOoOOO0oOoo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , o0O0ooooooo00 )
  if 30 - 30: i1IIi11111i % i11Ii11I1Ii1i / IiIiI11iIi * oo * I11i1i11i1I . Ii
  if 46 - 46: i11Ii11I1Ii1i - oo
 else :
  if 70 - 70: i1IIi11111i + Oo0o * OoO0O00 . Ii * i1IIi11111i
  import urlresolver
  from urlresolver import common
  if 49 - 49: ooO
  OOooo00 = urlresolver . HostedMediaFile ( url )
  if 25 - 25: Iiii . Ii11111i * OoO0O00 . ooO / oo + I11i1i11i1I
  if not OOooo00 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 68 - 68: Oo0o
   if 22 - 22: i1111
  try :
   i111i11I1ii = OOooo00 . resolve ( )
   if not i111i11I1ii or not isinstance ( i111i11I1ii , basestring ) :
    try : OOooo = i111i11I1ii . msg
    except : OOooo = url
    raise Exception ( OOooo )
  except Exception as iii11i1IIII :
   try : OOooo = str ( iii11i1IIII )
   except : OOooo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 22 - 22: Iiii * i1IIi11111i - Oo0o * oo / II111iiii
  I1I1IiI1 = oo000 . getSetting ( 'notificar' )
  if I1I1IiI1 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  II1i11i1iIi11 = xbmcgui . ListItem ( path = i111i11I1ii )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
  if 78 - 78: Oo0o * oo / OoOoo0 + Ii11111i + i1111
  if 23 - 23: Iiii % Ii11111i / OoO0O00 + IiIiI11iIi / iiI1i1 / ooO
 return
 if 94 - 94: iiI1i1
def iiIIi1 ( name , url ) :
 if 65 - 65: iiI1i1 . IiIiI11iIi / OoOoo0
 import resolveurl
 if 11 - 11: oO0o0o0ooO0oO * OoOoo0 / OoOoo0 - i1111
 OOooo00 = urlresolver . HostedMediaFile ( url )
 dp = xbmcgui . DialogProgress ( )
 dp . create ( 'Realstream:' , 'Conectando al servidor ... ' )
 dp . update ( 20 , 'Por favor, espere ...' )
 xbmc . sleep ( 500 )
 if 68 - 68: Ii % oO0o0o0ooO0oO - oO0o0o0ooO0oO / Ii + IiIiI11iIi - Oo0o
 if not OOooo00 :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  return False
  if 65 - 65: OoOoo0 - iiI1i1
 try :
  if 62 - 62: i1IIi11111i / IIii11I1 % Oo0o . Ii11111i / II111iiii / I1i1I
  dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
  xbmc . sleep ( 500 )
  i111i11I1ii = OOooo00 . resolve ( )
  if not i111i11I1ii or not isinstance ( i111i11I1ii , basestring ) :
   try : OOooo = i111i11I1ii . msg
   except : OOooo = i111i11I1ii
   raise Exception ( OOooo )
 except Exception as iii11i1IIII :
  try : OOooo = str ( iii11i1IIII )
  except : OOooo = i111i11I1ii
  dp . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
  dp . close ( )
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  if 60 - 60: Ii % IIii11I1 / ooO % IIii11I1 * II111iiii / Iiii
 dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
 xbmc . sleep ( 500 )
 dp . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
 xbmc . sleep ( 500 )
 dp . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
 xbmc . sleep ( 500 )
 dp . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
 dp . close ( )
 I1I1IiI1 = oo000 . getSetting ( 'notificar' )
 if 34 - 34: I1i1I - i1111
 if 25 - 25: IIii11I1 % Ii + II111iiii + oo * Ii11111i
 if '[Realstream]' or '[Mybox]' in name :
  restante = oo000 . getSetting ( 'restante' )
 elif restante == 'true' :
  dialog = xbmcgui . Dialog ( )
  ok = dialog . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
 II1i11i1iIi11 = xbmcgui . ListItem ( path = i111i11I1ii )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
 if 64 - 64: iiI1i1
def iiIIi1 ( name , url ) :
 if 10 - 10: I1i1I % oo / Ii % i1IIi11111i
 if 25 - 25: Ooo0OO0oOO / Oo0oO0oo0oO00
 if 'https://www.rapidvideo.com/v/' in url :
  if 64 - 64: oo % OoOoo0
  o0OOO = iIiiiI ( url )
  Iii1ii1II11i = re . compile ( 'rapidvideo' ) . findall ( o0OOO )
  for url in Iii1ii1II11i :
   if 40 - 40: ooO + i1IIi11111i
   if 77 - 77: II111iiii % oO0o0o0ooO0oO + I1i1I % Ii11111i - i1IIi11111i
   try :
    I1I1IiI1 = oo000 . getSetting ( 'notificar' )
    if I1I1IiI1 == 'true' :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    II1i11i1iIi11 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
    if 26 - 26: Oo0o + oo - OoO0O00
   except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 47 - 47: Ii11111i
   if 2 - 2: i11Ii11I1Ii1i % I1i1I * Oo0o * i11Ii11I1Ii1i
 else :
  if 65 - 65: II111iiii + Oo0o * Ii11111i - Oo0oO0oo0oO00
  import urlresolver
  from urlresolver import common
  if 26 - 26: ooO % i1111 + i1111 % i1IIi11111i * II111iiii / Iiii
  OOooo00 = urlresolver . HostedMediaFile ( url )
  if 64 - 64: IIii11I1 % i11Ii11I1Ii1i / Ooo0OO0oOO % OoOoo0 - Iiii
  if not OOooo00 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 2 - 2: I1i1I - IiIiI11iIi + ooO * Oo0oO0oo0oO00 / Iiii
   if 26 - 26: i1111 * Oo0o
  try :
   i111i11I1ii = OOooo00 . resolve ( )
   if not i111i11I1ii or not isinstance ( i111i11I1ii , basestring ) :
    try : OOooo = i111i11I1ii . msg
    except : OOooo = url
    raise Exception ( OOooo )
  except Exception as iii11i1IIII :
   try : OOooo = str ( iii11i1IIII )
   except : OOooo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 31 - 31: i1IIi11111i * IIii11I1 . I11i1i11i1I
  I1I1IiI1 = oo000 . getSetting ( 'notificar' )
  if I1I1IiI1 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  II1i11i1iIi11 = xbmcgui . ListItem ( path = i111i11I1ii )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
  if 35 - 35: i1IIi11111i
 return
 if 94 - 94: OoOoo0 / II111iiii % oo
 if 70 - 70: i1IIi11111i - Oo0o / Ii11111i % Ii11111i
 if 95 - 95: Ii11111i % Ii11111i . I11i1i11i1I
def III1ii ( name , url ) :
 if 38 - 38: IiIiI11iIi + i11Ii11I1Ii1i
 i111i11I1ii = url
 I1I1IiI1 = oo000 . getSetting ( 'notificar' )
 if I1I1IiI1 == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  II1i11i1iIi11 = xbmcgui . ListItem ( path = i111i11I1ii )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
 else :
  II1i11i1iIi11 = xbmcgui . ListItem ( path = i111i11I1ii )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
 return
 if 68 - 68: oo
def o0oOoO00 ( name , url ) :
 if 94 - 94: Oo0oO0oo0oO00 + oO0o0o0ooO0oO + OoOoo0
 if 82 - 82: Oo0o - Oo0o . OoO0O00 / i1111 + oO0o0o0ooO0oO % OoO0O00
 if '[Youtube]' in name :
  if 61 - 61: i1111 / Oo0o % i1111 - Oo0oO0oo0oO00 + OoOoo0 / OoOoo0
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 82 - 82: Oo0o
  try :
   I1I1IiI1 = oo000 . getSetting ( 'notificar' )
   if I1I1IiI1 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    II1i11i1iIi11 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
    if 5 - 5: Oo0oO0oo0oO00 / Oo0oO0oo0oO00 - oo - I1i1I + I1i1I
    if 99 - 99: i1IIi11111i * Ii11111i / ooO . oO0o0o0ooO0oO - OoO0O00 - I11i1i11i1I
    if 31 - 31: oO0o0o0ooO0oO - Oo0oO0oo0oO00 / i1111 . iiI1i1 / I11i1i11i1I
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 66 - 66: Oo0oO0oo0oO00
  if 72 - 72: I1i1I
 else :
  if 91 - 91: Ooo0OO0oOO / oO0o0o0ooO0oO + OoO0O00 . i1IIi11111i - oo
  import xbmcgui
  import urlresolver
  from urlresolver import common
  if 70 - 70: I11i1i11i1I * IIii11I1 - i1IIi11111i + Oo0o % IiIiI11iIi - oO0o0o0ooO0oO
  OOooo00 = urlresolver . HostedMediaFile ( url )
  if 81 - 81: oo . oo
  if not OOooo00 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 75 - 75: OoO0O00 % oO0o0o0ooO0oO + IiIiI11iIi * oo . Iiii - OoOoo0
  import resolveurl as urlresolver
  if 32 - 32: I11i1i11i1I % IIii11I1 - iiI1i1
  OOooo00 = urlresolver . HostedMediaFile ( url )
  if 40 - 40: OoO0O00 + Iiii * i11Ii11I1Ii1i + IIii11I1
  if 15 - 15: i1IIi11111i % Ii - OoO0O00 * OoOoo0
  if not OOooo00 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 71 - 71: i11Ii11I1Ii1i % Oo0o % OoOoo0
  try :
   i111i11I1ii = OOooo00 . resolve ( )
   if not i111i11I1ii or not isinstance ( i111i11I1ii , basestring ) :
    try : OOooo = i111i11I1ii . msg
    except : OOooo = url
    raise Exception ( OOooo )
  except Exception as iii11i1IIII :
   try : OOooo = str ( iii11i1IIII )
   except : OOooo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 34 - 34: i1IIi11111i / i1IIi11111i % oO0o0o0ooO0oO . i11Ii11I1Ii1i / Oo0o
   if 99 - 99: OoOoo0 * Ii - OoOoo0 % I11i1i11i1I
   if 40 - 40: i1111 / oO0o0o0ooO0oO / OoO0O00 + I11i1i11i1I
  I1I1IiI1 = oo000 . getSetting ( 'notificar' )
  if I1I1IiI1 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 59 - 59: i1IIi11111i * Ii11111i + i1111 . OoO0O00 / iiI1i1
   if '[Realstream]' in name :
    if 75 - 75: i1IIi11111i . i1111 - OoO0O00 * Oo0oO0oo0oO00 * Iiii
    oOOo0 = oo000 . getSetting ( 'restante' )
    if oOOo0 == 'true' :
     i1oOOoo0o0OOOO = xbmcgui . Dialog ( )
     I111I11I111 = i1oOOoo0o0OOOO . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 93 - 93: OoOoo0
   II1i11i1iIi11 = xbmcgui . ListItem ( path = i111i11I1ii )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
   if 18 - 18: OoOoo0
   if 66 - 66: IIii11I1 * II111iiii + i11Ii11I1Ii1i / i1111
   if 96 - 96: i1111 + i1111 % oO0o0o0ooO0oO % i1111
 return
 if 28 - 28: OoO0O00 + i11Ii11I1Ii1i . ooO % II111iiii
 if 58 - 58: i1IIi11111i / Ii11111i % IIii11I1 + Oo0oO0oo0oO00
 if 58 - 58: oo
def O0oO ( name , url ) :
 if 54 - 54: ooO + i1IIi11111i - OoO0O00 % OoOoo0 % oO0o0o0ooO0oO
 if 19 - 19: IiIiI11iIi / OoO0O00 % iiI1i1 . Ii11111i
 if '[Youtube]' in name :
  if 57 - 57: OoOoo0 . Oo0o - Oo0oO0oo0oO00 - II111iiii * I1i1I / ooO
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 79 - 79: IiIiI11iIi + ooO % Oo0o * ooO
  try :
   I1I1IiI1 = oo000 . getSetting ( 'notificar' )
   if I1I1IiI1 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    II1i11i1iIi11 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
    if 21 - 21: Iiii
    if 24 - 24: Iiii / OoOoo0
    if 61 - 61: OoO0O00 + IIii11I1
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 8 - 8: I1i1I + Oo0oO0oo0oO00
 else :
  if 9 - 9: i1111 + ooO
  import resolveurl
  if 8 - 8: i1111 * Oo0o / Iiii - Oo0oO0oo0oO00 - Ii11111i
  OOooo00 = urlresolver . HostedMediaFile ( url )
  if 100 - 100: IIii11I1 . OoO0O00 . OoO0O00
  if 55 - 55: IIii11I1
  if not OOooo00 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 37 - 37: oO0o0o0ooO0oO / II111iiii / Oo0o
  try :
   i111i11I1ii = OOooo00 . resolve ( )
   if not i111i11I1ii or not isinstance ( i111i11I1ii , basestring ) :
    try : OOooo = i111i11I1ii . msg
    except : OOooo = url
    raise Exception ( OOooo )
  except Exception as iii11i1IIII :
   try : OOooo = str ( iii11i1IIII )
   except : OOooo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 97 - 97: I1i1I . i1IIi11111i / Ii
   if 83 - 83: i1IIi11111i - IiIiI11iIi * IIii11I1
   if 90 - 90: Oo0o * Ii
  I1I1IiI1 = oo000 . getSetting ( 'notificar' )
  if I1I1IiI1 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 75 - 75: IiIiI11iIi - i11Ii11I1Ii1i * II111iiii . Ii11111i - Oo0o . i1IIi11111i
   if '[Realstream]' in name :
    if 6 - 6: i1IIi11111i * IIii11I1 / Ii11111i % I11i1i11i1I * ooO
    oOOo0 = oo000 . getSetting ( 'restante' )
    if oOOo0 == 'true' :
     i1oOOoo0o0OOOO = xbmcgui . Dialog ( )
     I111I11I111 = i1oOOoo0o0OOOO . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 28 - 28: oO0o0o0ooO0oO * Ii % oO0o0o0ooO0oO
   II1i11i1iIi11 = xbmcgui . ListItem ( path = i111i11I1ii )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
   if 95 - 95: oo / i1IIi11111i . I1i1I
   if 17 - 17: i1IIi11111i
   if 56 - 56: OoOoo0 * ooO + i1IIi11111i
 return
 if 48 - 48: oO0o0o0ooO0oO * Oo0oO0oo0oO00 % I1i1I - i1IIi11111i
def Oo0000OOO0 ( name , url ) :
 if 68 - 68: iiI1i1 - Iiii . OoOoo0 - Oo0o + OoO0O00 + I1i1I
 if 25 - 25: OoO0O00 % Ooo0OO0oOO / i1IIi11111i / IiIiI11iIi
 if '[Youtube]' in name :
  if 22 - 22: IIii11I1 * Iiii
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 4 - 4: i11Ii11I1Ii1i - IIii11I1 + Ii
  try :
   I1I1IiI1 = oo000 . getSetting ( 'notificar' )
   if I1I1IiI1 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    II1i11i1iIi11 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
    if 36 - 36: oO0o0o0ooO0oO
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 19 - 19: i11Ii11I1Ii1i . ooO . Ii11111i
 else :
  if 13 - 13: i1111 . Oo0o / Ooo0OO0oOO
  if 'https://team.com' in url :
   if 43 - 43: OoO0O00 % Oo0oO0oo0oO00
   url = url . replace ( 'https://team.com' , 'https://verystream.com' )
   if 84 - 84: Oo0o
  if 'https://mybox.com' in url :
   if 44 - 44: Ii11111i * II111iiii / Oo0o
   url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
   if 75 - 75: Ii11111i . i1111 + Oo0oO0oo0oO00 / I11i1i11i1I - Ii % I11i1i11i1I
  if 'https://drive.com' in url :
   if 89 - 89: Iiii * OoO0O00 + II111iiii . Ii11111i
   url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
   if 51 - 51: i1111 / OoOoo0 + Oo0oO0oo0oO00 % i11Ii11I1Ii1i / I11i1i11i1I
  if 'https://vid.co' in url :
   if 25 - 25: ooO
   url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
   if 25 - 25: OoOoo0 * Iiii / i1IIi11111i / i1IIi11111i % ooO
  if 'https://limited.to' in url :
   if 19 - 19: IIii11I1 - OoO0O00 / OoOoo0 . Oo0oO0oo0oO00 * oo - oo
   url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
   if 41 - 41: iiI1i1 - Ii
  import resolveurl
  if 48 - 48: Ii - Ooo0OO0oOO / Oo0oO0oo0oO00 + Ii
  OOooo00 = urlresolver . HostedMediaFile ( url )
  if 5 - 5: oo
  if 75 - 75: I1i1I + OoO0O00
  if not OOooo00 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no encontrado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 19 - 19: Ii + II111iiii . oO0o0o0ooO0oO - i1IIi11111i / I11i1i11i1I + ooO
  try :
   i111i11I1ii = OOooo00 . resolve ( )
   if not i111i11I1ii or not isinstance ( i111i11I1ii , basestring ) :
    try : OOooo = i111i11I1ii . msg
    except : OOooo = url
    raise Exception ( OOooo )
  except Exception as iii11i1IIII :
   try : OOooo = str ( iii11i1IIII )
   except : OOooo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace borrado, o no encontrado. Prueba a reiniciar el router o poner una VPN.[/COLOR]  ,5000)" )
   return False
   if 38 - 38: Oo0o / OoO0O00 * OoO0O00 % IiIiI11iIi
   if 92 - 92: i1IIi11111i / oo * Ii - i1IIi11111i
   if 99 - 99: II111iiii % Ii11111i
   I1I1IiI1 = oo000 . getSetting ( 'notificar' )
   if I1I1IiI1 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
    if 56 - 56: oO0o0o0ooO0oO * I1i1I
    if '[Realstream]' or '[Mybox]' in name :
     oOOo0 = oo000 . getSetting ( 'restante' )
    elif oOOo0 == 'true' :
     i1oOOoo0o0OOOO = xbmcgui . Dialog ( )
     I111I11I111 = i1oOOoo0o0OOOO . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 98 - 98: i1IIi11111i + oo * I1i1I + II111iiii - i1111 - OoO0O00
  II1i11i1iIi11 = xbmcgui . ListItem ( path = i111i11I1ii )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
  if 5 - 5: i1111 % Oo0o % oO0o0o0ooO0oO % OoOoo0
 return
 if 17 - 17: I11i1i11i1I + Ooo0OO0oOO + Ii11111i / i1111 / oO0o0o0ooO0oO
def oOoo0Ooooo ( name , url ) :
 if 15 - 15: Ooo0OO0oOO * IIii11I1 % Iiii / II111iiii - IIii11I1 + Oo0o
 if 9 - 9: i1IIi11111i - IIii11I1 + oo / Iiii % iiI1i1
 if '[Youtube]' in name :
  if 97 - 97: ooO * OoOoo0
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 78 - 78: i1IIi11111i . i1111 + IIii11I1 * Iiii - iiI1i1
  try :
   I1I1IiI1 = oo000 . getSetting ( 'notificar' )
   if I1I1IiI1 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    II1i11i1iIi11 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
    if 27 - 27: I11i1i11i1I % iiI1i1 . Oo0o % I1i1I
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 10 - 10: oO0o0o0ooO0oO / Ii11111i
 else :
  if 50 - 50: II111iiii - Ii11111i . IIii11I1 + oo . iiI1i1
  IIiIiII11i = oo000 . getSetting ( 'licencia_addon' )
  o0oOOo0O0Ooo = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  I1ii11iIi11i = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  I1IiI = oo000 . getSetting ( 'key_ext' )
  o0OOO = iIiiiI ( I1ii11iIi11i )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for IiII in Iii1ii1II11i :
   if 91 - 91: ooO . Iiii % Oo0o - Iiii . IIii11I1 % II111iiii
   try :
    if 25 - 25: OoO0O00
    if 63 - 63: OoOoo0
    IIiIiII11i = oo000 . getSetting ( 'licencia_addon' )
    if 96 - 96: i1IIi11111i
    if 34 - 34: i11Ii11I1Ii1i / Oo0oO0oo0oO00 - Ii . oo . i1111
    if IIiIiII11i == IiII :
     if 63 - 63: Iiii
     if 11 - 11: Iiii - OoO0O00
     if 'https://team.com' in url :
      if 92 - 92: Oo0oO0oo0oO00
      url = url . replace ( 'https://team.com' , 'https://verystream.com' )
      if 15 - 15: oO0o0o0ooO0oO / oO0o0o0ooO0oO + OoO0O00 % Ii11111i
     if 'https://mybox.com' in url :
      if 12 - 12: OoOoo0
      url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
      if 36 - 36: I1i1I . oO0o0o0ooO0oO * Ii11111i - ooO
      if 60 - 60: i1111 . Iiii / OoO0O00 + i1111 * I1i1I
     if 'https://vidcloud.co/' in url :
      if 82 - 82: II111iiii . OoO0O00 * Ii - i1IIi11111i + I11i1i11i1I
      url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
      if 48 - 48: IiIiI11iIi
     if 'https://gounlimited.to' in url :
      if 96 - 96: OoOoo0 . Ii11111i
      url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
      if 39 - 39: i1111 + Oo0oO0oo0oO00
     if 'https://drive.com' in url :
      if 80 - 80: i1111 % Oo0oO0oo0oO00 / i11Ii11I1Ii1i
      url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
      if 54 - 54: Oo0o % Oo0oO0oo0oO00 - i1111 - i1IIi11111i
      if 71 - 71: OoOoo0 . II111iiii
     import resolveurl
     if 56 - 56: oo * Iiii + Iiii * OoO0O00 / OoOoo0 * I1i1I
     OOooo00 = urlresolver . HostedMediaFile ( url )
     if 25 - 25: OoO0O00 . i1IIi11111i * II111iiii + Oo0o * i1IIi11111i
     if not OOooo00 :
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
      return False
      if 67 - 67: Iiii
     try :
      Ii1IIi = xbmcgui . DialogProgress ( )
      Ii1IIi . create ( 'Realstream:' , 'Iniciando ...' )
      Ii1IIi . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
      xbmc . sleep ( 1000 )
      i111i11I1ii = OOooo00 . resolve ( )
      if not i111i11I1ii or not isinstance ( i111i11I1ii , basestring ) :
       try : OOooo = i111i11I1ii . msg
       except : OOooo = url
       raise Exception ( OOooo )
       if 88 - 88: Oo0o
     except Exception as iii11i1IIII :
      try : OOooo = str ( iii11i1IIII )
      except : OOooo = url
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,7000)" )
      if 8 - 8: IiIiI11iIi
     Ii1IIi . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
     xbmc . sleep ( 500 )
     Ii1IIi . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
     xbmc . sleep ( 500 )
     Ii1IIi . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
     xbmc . sleep ( 500 )
     Ii1IIi . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
     Ii1IIi . close ( )
     I1I1IiI1 = oo000 . getSetting ( 'notificar' )
     II1i11i1iIi11 = xbmcgui . ListItem ( path = i111i11I1ii )
     xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
     if 82 - 82: Ii11111i
     if 75 - 75: Ooo0OO0oOO % Ii + i1111 % Ii11111i / oO0o0o0ooO0oO
    else :
     if 4 - 4: II111iiii - i1111 % IiIiI11iIi * I1i1I % ooO
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold]>El addon esta desactivado.[/COLOR]" )
     if 71 - 71: OoOoo0 . OoOoo0 - OoO0O00
     if 22 - 22: Ii11111i / IiIiI11iIi % Iiii * i11Ii11I1Ii1i
   except :
    pass
    if 32 - 32: Ii11111i % IIii11I1 % OoO0O00 / oo
 return
 if 61 - 61: Ooo0OO0oOO . oo - I11i1i11i1I - IiIiI11iIi / II111iiii - Ooo0OO0oOO
def O0oo0oOo ( ) :
 if 40 - 40: i1IIi11111i % OoOoo0
 if 71 - 71: Oo0oO0oo0oO00
 ooOOO0ooO0o = [ ]
 OO0o0O0O0O0 = sys . argv [ 2 ]
 if len ( OO0o0O0O0O0 ) >= 2 :
  iI11IiIiiII1 = sys . argv [ 2 ]
  I11iii1i = iI11IiIiiII1 . replace ( '?' , '' )
  if ( iI11IiIiiII1 [ len ( iI11IiIiiII1 ) - 1 ] == '/' ) :
   iI11IiIiiII1 = iI11IiIiiII1 [ 0 : len ( iI11IiIiiII1 ) - 2 ]
  ii1i1Iii = I11iii1i . split ( '&' )
  ooOOO0ooO0o = { }
  for oO00oO00O0Oo in range ( len ( ii1i1Iii ) ) :
   OO0o0o0oo = { }
   OO0o0o0oo = ii1i1Iii [ oO00oO00O0Oo ] . split ( '=' )
   if ( len ( OO0o0o0oo ) ) == 2 :
    ooOOO0ooO0o [ OO0o0o0oo [ 0 ] ] = OO0o0o0oo [ 1 ]
 return ooOOO0ooO0o
 if 40 - 40: Oo0o
 if 47 - 47: i11Ii11I1Ii1i
def Oo0000o ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  import urlresolver
  xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
  if 33 - 33: i11Ii11I1Ii1i * i1IIi11111i
def iiIiII1 ( ) :
 i1oOOoo0o0OOOO = xbmcgui . Dialog ( )
 list = (
 ii111iI ,
 ii11I1
 )
 if 26 - 26: I1i1I . I11i1i11i1I + Ii . i11Ii11I1Ii1i + i1111
 Ooooo00o0OoO = i1oOOoo0o0OOOO . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=%s]Accede a themoviedb.com[/COLOR]' % ooOOO00Ooo ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 17 - 17: i1111 + II111iiii + IiIiI11iIi % i1111 . IIii11I1
 if Ooooo00o0OoO :
  if 33 - 33: i1IIi11111i * Ii % i11Ii11I1Ii1i . oO0o0o0ooO0oO . OoOoo0 . Oo0oO0oo0oO00
  if Ooooo00o0OoO < 0 :
   return
  oOO0 = list [ Ooooo00o0OoO - 2 ]
  return oOO0 ( )
 else :
  oOO0 = list [ Ooooo00o0OoO ]
  return oOO0 ( )
 return
 if 53 - 53: i11Ii11I1Ii1i
def ooo0o0O0o ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 84 - 84: Oo0oO0oo0oO00
I1Ii = ooo0o0O0o ( )
if 97 - 97: iiI1i1
def ii111iI ( ) :
 if I1Ii == 'android' :
  iII11I1Ii1 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  iII11I1Ii1 = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 98 - 98: Ii11111i - Ii + OoOoo0
  if 98 - 98: Iiii . oO0o0o0ooO0oO . oO0o0o0ooO0oO - i1111
def ii11I1 ( ) :
 if 65 - 65: Oo0o + ooO - I11i1i11i1I
 main ( )
 if 12 - 12: Ii11111i + IiIiI11iIi
 if 55 - 55: i1111 * Ooo0OO0oOO + IIii11I1
 if 93 - 93: Iiii * IIii11I1 . Oo0oO0oo0oO00 - I11i1i11i1I + oo * Oo0oO0oo0oO00
def oOoOO ( ) :
 i1oOOoo0o0OOOO = xbmcgui . Dialog ( )
 i1IiII1III = (
 i11 ,
 I1iIii1i11
 )
 if 42 - 42: Oo0oO0oo0oO00 * II111iiii
 Ooooo00o0OoO = i1oOOoo0o0OOOO . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 16 - 16: Iiii % Ii - OoOoo0
 if Ooooo00o0OoO :
  if 100 - 100: Ii11111i * IIii11I1
  if Ooooo00o0OoO < 0 :
   return
  oOO0 = i1IiII1III [ Ooooo00o0OoO - 2 ]
  return oOO0 ( )
 else :
  oOO0 = i1IiII1III [ Ooooo00o0OoO ]
  return oOO0 ( )
 return
 if 83 - 83: OoO0O00 - OoOoo0 - I1i1I / Oo0oO0oo0oO00 - oo
def ooo0o0O0o ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 81 - 81: I11i1i11i1I - IIii11I1 * IiIiI11iIi / I1i1I
I1Ii = ooo0o0O0o ( )
if 21 - 21: Oo0oO0oo0oO00
def i11 ( ) :
 if I1Ii == 'android' :
  iII11I1Ii1 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  iII11I1Ii1 = webbrowser . open ( 'https://olpair.com/' )
  if 63 - 63: i1IIi11111i . oo * i1IIi11111i + OoO0O00
  if 46 - 46: iiI1i1 + Ooo0OO0oOO * iiI1i1 - I11i1i11i1I
def I1iIii1i11 ( ) :
 if 79 - 79: Ooo0OO0oOO - IIii11I1 * IiIiI11iIi - i11Ii11I1Ii1i . IiIiI11iIi
 main ( )
 if 11 - 11: oo * i11Ii11I1Ii1i
 if 37 - 37: i11Ii11I1Ii1i + oo . oo * Oo0o % I1i1I / Iiii
def iIIiOOOo00o ( name , url , id , trailer ) :
 i1oOOoo0o0OOOO = xbmcgui . Dialog ( )
 i1IiII1III = (
 ii1iiii1 ,
 o0OOo0O ,
 oo00 ,
 iiIiII1 ,
 i1i11I1I1
 )
 if 82 - 82: Oo0oO0oo0oO00 - Oo0o - oo - Ii11111i
 Ooooo00o0OoO = i1oOOoo0o0OOOO . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % ooOOO00Ooo ,

 '[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % ooOOO00Ooo ,

 '[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % ooOOO00Ooo ,

 '[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % ooOOO00Ooo ,

 '[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % ooOOO00Ooo ] )
 if 4 - 4: Ooo0OO0oOO - IIii11I1 % Oo0o * II111iiii
 if Ooooo00o0OoO :
  if 18 - 18: Oo0o % oo
  if Ooooo00o0OoO < 0 :
   return
  oOO0 = i1IiII1III [ Ooooo00o0OoO - 5 ]
  return oOO0 ( )
 else :
  oOO0 = i1IiII1III [ Ooooo00o0OoO ]
  return oOO0 ( )
 return
 if 66 - 66: OoO0O00 % II111iiii / Ii
 if 47 - 47: IiIiI11iIi * IIii11I1 + OoO0O00 - IIii11I1 / oO0o0o0ooO0oO
 if 86 - 86: oO0o0o0ooO0oO
def ii1iiii1 ( ) :
 if 43 - 43: Ii / Iiii / OoOoo0 + OoO0O00 + Ii11111i
 oOoo0Ooooo ( iI1 , iIIioO0o00oo0 )
 if 33 - 33: Ooo0OO0oOO - oO0o0o0ooO0oO - OoOoo0
def o0OOo0O ( ) :
 if 92 - 92: Oo0oO0oo0oO00 * oO0o0o0ooO0oO
 IIOOOoO00O ( iI1 , ii1IIII )
 if 92 - 92: IIii11I1
def oo00 ( ) :
 if 7 - 7: Iiii
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  oOOoOO0O00o = id
  if 38 - 38: II111iiii . OoO0O00 . i1111 / Oo0oO0oo0oO00
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % oOOoOO0O00o )
  if 18 - 18: Oo0o * I1i1I
 if I1I1IiI1 == 'true' :
  if 99 - 99: Ooo0OO0oOO * OoO0O00 % oo * IIii11I1 / Ooo0OO0oOO % Ii11111i
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + iI1 + "[/COLOR] ,5000)" )
  if 14 - 14: oO0o0o0ooO0oO . oO0o0o0ooO0oO % OoOoo0
def iII ( ) :
 if 67 - 67: i1IIi11111i / Ooo0OO0oOO / oo / oO0o0o0ooO0oO - i1IIi11111i - iiI1i1
 iiIiII1 ( )
 if 8 - 8: II111iiii . Iiii / OoO0O00 / IiIiI11iIi / oO0o0o0ooO0oO - I11i1i11i1I
def i1i11I1I1 ( ) :
 if 32 - 32: ooO . iiI1i1 * Oo0o
 iI11 ( )
def iIi1 ( name , url , mode , iconimage , fanart ) :
 if 98 - 98: I11i1i11i1I - Ooo0OO0oOO / Ii . IIii11I1 * oO0o0o0ooO0oO . i1IIi11111i
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 I111I11I111 = True
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  oOO0oo = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii , isFolder = True )
  return I111I11I111
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii , isFolder = True )
 return I111I11I111
 if 25 - 25: II111iiii / i11Ii11I1Ii1i - I1i1I / Oo0oO0oo0oO00 . ooO . ooO
def IiIi11iiIIiI1 ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 6 - 6: IIii11I1 . i1IIi11111i
 IIII = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 43 - 43: IiIiI11iIi + ooO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 iI1iiiiiii = [ ]
 if 63 - 63: OoO0O00 + oO0o0o0ooO0oO % iiI1i1 / Ii % Ooo0OO0oOO
 iI1iiiiiii . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , fanart )
 II1iIi1IiIii . setProperty ( 'IsPlayable' , 'true' )
 if 60 - 60: ooO . i11Ii11I1Ii1i % I1i1I / Ii / oo
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  iI1iiiiiii . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 19 - 19: II111iiii . Ii + Ooo0OO0oOO / i1111 . IiIiI11iIi * OoOoo0
  II1iIi1IiIii . addContextMenuItems ( iI1iiiiiii , replaceItems = True )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii )
 return I111I11I111
 if 59 - 59: OoO0O00 / IiIiI11iIi % OoOoo0
def I1IiII1I1i1I1 ( name , url , mode , iconimage , fanart ) :
 if 84 - 84: OoO0O00 / Ii . i11Ii11I1Ii1i % i1IIi11111i
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 99 - 99: Oo0o + II111iiii
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , fanart )
 II1iIi1IiIii . setProperty ( 'IsPlayable' , 'true' )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii )
 return I111I11I111
 if 36 - 36: I11i1i11i1I * I1i1I * OoO0O00 - i1IIi11111i % II111iiii
def OoOo00O0o ( name , url , mode ) :
 if 96 - 96: oO0o0o0ooO0oO * oO0o0o0ooO0oO % OoOoo0 + ooO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 27 - 27: Oo0o * OoOoo0 + II111iiii / Ii - IIii11I1
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = OOOOoOo00OO )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , IiI1I1 )
 II1iIi1IiIii . setProperty ( 'IsPlayable' , 'true' )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii )
 return I111I11I111
 if 44 - 44: I11i1i11i1I * OoOoo0 / i11Ii11I1Ii1i
def o0Oo0ooo ( name , url , mode , iconimage ) :
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 I111I11I111 = True
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii , isFolder = True )
 return I111I11I111
 if 60 - 60: Ii
def IiiI1iii1iIiiI ( ) :
 if 36 - 36: Oo0oO0oo0oO00 - oo * Ii / IiIiI11iIi / i1111
 if 33 - 33: Ii11111i % IiIiI11iIi . oo / IiIiI11iIi
 if 63 - 63: oO0o0o0ooO0oO + OoO0O00 + Ii + I1i1I
 iiI11i1II = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 iiI11i1II . doModal ( )
 if ( iiI11i1II . isConfirmed ( ) ) :
  if 72 - 72: Oo0oO0oo0oO00 + II111iiii + IiIiI11iIi
  o0O00OooOOOOO = urllib . quote_plus ( iiI11i1II . getText ( ) ) . replace ( '+' , ' ' )
  if 96 - 96: IIii11I1 % iiI1i1 / ooO
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 13 - 13: Ooo0OO0oOO - Oo0o % II111iiii + Iiii
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % o0O00OooOOOOO )
    if 88 - 88: oo . IIii11I1 % Ii
    if I1I1IiI1 == 'true' :
     if 10 - 10: Ii + oo
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + iI1 + "[/COLOR] ,10000)" )
     if 75 - 75: oo % OoO0O00 / i11Ii11I1Ii1i % i1111 / oO0o0o0ooO0oO
   except :
    if 31 - 31: II111iiii * i11Ii11I1Ii1i
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 69 - 69: II111iiii
    if 61 - 61: oo
    if 21 - 21: Oo0oO0oo0oO00 % OoO0O00 . Oo0oO0oo0oO00
iI11IiIiiII1 = O0oo0oOo ( )
iIIioO0o00oo0 = None
iI1 = None
OO000OOOo0Oo = None
OOOOoOo00OO = None
id = None
ii1IIII = None
if 75 - 75: Ooo0OO0oOO + OoOoo0 % i1111 + Oo0o
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 70 - 70: Oo0oO0oo0oO00
try :
 iIIioO0o00oo0 = urllib . unquote_plus ( iI11IiIiiII1 [ "url" ] )
except :
 pass
try :
 iI1 = urllib . unquote_plus ( iI11IiIiiII1 [ "name" ] )
except :
 pass
try :
 OO000OOOo0Oo = int ( iI11IiIiiII1 [ "mode" ] )
except :
 pass
try :
 OOOOoOo00OO = urllib . unquote_plus ( iI11IiIiiII1 [ "iconimage" ] )
except :
 pass
try :
 id = int ( iI11IiIiiII1 [ "id" ] )
except :
 pass
try :
 ii1IIII = urllib . unquote_plus ( iI11IiIiiII1 [ "trailer" ] )
except :
 pass
 if 43 - 43: i11Ii11I1Ii1i
 if 57 - 57: Ii
print "Mode: " + str ( OO000OOOo0Oo )
print "URL: " + str ( iIIioO0o00oo0 )
print "Name: " + str ( iI1 )
print "iconimage: " + str ( OOOOoOo00OO )
print "id: " + str ( id )
print "trailer: " + str ( ii1IIII )
if 65 - 65: II111iiii - OoOoo0 * i1IIi11111i + OoOoo0 / oO0o0o0ooO0oO + ooO
if OO000OOOo0Oo == None or iIIioO0o00oo0 == None or len ( iIIioO0o00oo0 ) < 1 :
 if O0i1II1Iiii1I11 == IIII :
  if 35 - 35: oo + Oo0o - Ii % I11i1i11i1I % Ooo0OO0oOO
  if 77 - 77: I1i1I + IIii11I1
  IIii11I1i1I ( )
  if 38 - 38: IiIiI11iIi - I11i1i11i1I * ooO
  if 13 - 13: Ii * IIii11I1
  IIiIiII11i = oo000 . getSetting ( 'licencia_addon' )
  o0oOOo0O0Ooo = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  I1ii11iIi11i = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  I1IiI = oo000 . getSetting ( 'key_ext' )
  o0OOO = iIiiiI ( I1ii11iIi11i )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for IiII in Iii1ii1II11i :
   try :
    if 41 - 41: oO0o0o0ooO0oO
    if 16 - 16: OoO0O00
    IIiIiII11i = oo000 . getSetting ( 'licencia_addon' )
    if 94 - 94: OoOoo0 % i1IIi11111i % iiI1i1
    if 90 - 90: I11i1i11i1I * Oo0oO0oo0oO00
    if IIiIiII11i == IiII :
     if 7 - 7: Iiii . I11i1i11i1I . Iiii - I1i1I
     if 33 - 33: OoOoo0 + Ii11111i - Oo0oO0oo0oO00 / iiI1i1 / Ii11111i
     if 82 - 82: IiIiI11iIi / i1111 - Iiii / Oo0o * Oo0oO0oo0oO00
     iI11 ( )
     if 55 - 55: Ii11111i
    else :
     if 73 - 73: i11Ii11I1Ii1i - IiIiI11iIi % Oo0o + IiIiI11iIi - oo . Oo0oO0oo0oO00
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold]>El addon esta desactivado.[/COLOR]" )
     if 38 - 38: oo
     if 79 - 79: iiI1i1 . IIii11I1
   except :
    pass
    if 34 - 34: I1i1I * Ooo0OO0oOO
 else :
  xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red][B]Error, de inicio. ¿Tienes Instalado Realstream?[/B][/COLOR]" )
  if 71 - 71: oO0o0o0ooO0oO
  if 97 - 97: IiIiI11iIi
  if 86 - 86: Oo0o - i1111 . i11Ii11I1Ii1i . Ooo0OO0oOO * Ii . Ooo0OO0oOO
elif OO000OOOo0Oo == 1 :
 iIIiOOOo00o ( iI1 , iIIioO0o00oo0 , id , ii1IIII )
elif OO000OOOo0Oo == 2 :
 I1Iii1iI1 ( )
elif OO000OOOo0Oo == 3 :
 o0OOoo ( )
elif OO000OOOo0Oo == 4 :
 iI11II1i1I1 ( iI1 , iIIioO0o00oo0 )
elif OO000OOOo0Oo == 5 :
 IIi11 ( )
elif OO000OOOo0Oo == 6 :
 iI1iiII11I ( )
elif OO000OOOo0Oo == 7 :
 OOOo00 ( )
elif OO000OOOo0Oo == 8 :
 III1I1 ( )
elif OO000OOOo0Oo == 9 :
 oO00Ooo0oO ( )
elif OO000OOOo0Oo == 10 :
 O0Oo0 ( )
elif OO000OOOo0Oo == 11 :
 oo0O0o ( )
elif OO000OOOo0Oo == 12 :
 I11 ( )
elif OO000OOOo0Oo == 13 :
 iii11i1 ( )
elif OO000OOOo0Oo == 14 :
 OOOoo ( )
elif OO000OOOo0Oo == 15 :
 o0Oii111 ( )
elif OO000OOOo0Oo == 16 :
 ooo0O0o0OoOO ( )
elif OO000OOOo0Oo == 17 :
 o0OO0OOO0O ( )
elif OO000OOOo0Oo == 18 :
 i1iiI ( )
elif OO000OOOo0Oo == 19 :
 O0Oo000OO000 ( )
elif OO000OOOo0Oo == 20 :
 i111I1iiIiII ( )
elif OO000OOOo0Oo == 21 :
 Iii1I ( )
elif OO000OOOo0Oo == 22 :
 o0O00Oooo ( )
elif OO000OOOo0Oo == 23 :
 Iii ( )
elif OO000OOOo0Oo == 24 :
 i1I111Ii ( )
elif OO000OOOo0Oo == 25 :
 iI1I11i ( )
elif OO000OOOo0Oo == 26 :
 II1 ( )
elif OO000OOOo0Oo == 28 :
 oOO0o000Oo00o ( iI1 , iIIioO0o00oo0 )
elif OO000OOOo0Oo == 29 :
 ooOoOO ( )
elif OO000OOOo0Oo == 30 :
 i1i1IiIi1 ( )
elif OO000OOOo0Oo == 98 :
 busqueda_global ( )
elif OO000OOOo0Oo == 97 :
 oOoOO ( )
elif OO000OOOo0Oo == 99 :
 o0OooooOoOO ( )
elif OO000OOOo0Oo == 100 :
 menu_player ( iI1 , iIIioO0o00oo0 )
elif OO000OOOo0Oo == 111 :
 iIIi ( )
elif OO000OOOo0Oo == 115 :
 IIOOOoO00O ( iIIioO0o00oo0 )
elif OO000OOOo0Oo == 116 :
 I1I11iI11iI1i ( )
elif OO000OOOo0Oo == 117 :
 oOO ( )
elif OO000OOOo0Oo == 119 :
 oO0 ( )
elif OO000OOOo0Oo == 120 :
 ii1i1i1IiII ( )
elif OO000OOOo0Oo == 121 :
 oOIi111 ( )
elif OO000OOOo0Oo == 125 :
 i1i1 ( )
elif OO000OOOo0Oo == 112 :
 I1iIiI11I1 ( )
elif OO000OOOo0Oo == 127 :
 IiiI1iii1iIiiI ( )
elif OO000OOOo0Oo == 128 :
 TESTLINKS ( )
elif OO000OOOo0Oo == 130 :
 oOoo0Ooooo ( iI1 , iIIioO0o00oo0 )
elif OO000OOOo0Oo == 140 :
 i11i1iIiii ( )
elif OO000OOOo0Oo == 141 :
 II1i ( )
elif OO000OOOo0Oo == 142 :
 ii1I11iIiIII1 ( )
elif OO000OOOo0Oo == 143 :
 iiIii1IIi ( iI1 , iIIioO0o00oo0 )
elif OO000OOOo0Oo == 144 :
 oOO0o000Oo00o ( iI1 , iIIioO0o00oo0 )
elif OO000OOOo0Oo == 145 :
 OO0o0oO ( )
elif OO000OOOo0Oo == 150 :
 OoO000O ( )
elif OO000OOOo0Oo == 151 :
 IiIIiIIIiIii ( )
elif OO000OOOo0Oo == 152 :
 i11111I1I ( )
 if 34 - 34: ooO . I1i1I % oO0o0o0ooO0oO - oo / I1i1I
xbmcplugin . endOfDirectory ( oOOo ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
