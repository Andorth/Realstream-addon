# -*- coding: utf-8 -*-

if 64 - 64: i11iIiiIii
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import resolveurl
import cookielib , base64
import requests
import codecs
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
IiII1IiiIiI1 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
o0OoOoOO00 = int ( sys . argv [ 1 ] )
I11i = 'gruponetai/'
O0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
Oo = O0O . getAddonInfo ( 'profile' )
I1ii11iIi11i = O0O . getAddonInfo ( 'path' )
I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
if 73 - 73: OOooOOo / ii11ii1ii
if 94 - 94: OoOO + OoOO0ooOOoo0O + o0000oOoOoO0o * o00O0oo
if I1IiI == 'true' :
 if 97 - 97: oO0o0ooO0 - IIII / O0oO - o0oO0
 oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.png' ) )
 o00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 Oo0oO0ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.png' ) )
 i1111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.png' ) )
 i11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'estrenos.png' ) )
 I11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.png' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.png' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.png' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.png' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.png' ) )
 oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.png' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.png' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.png' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.png' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.png' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.png' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.png' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'marvel.png' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.png' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.png' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.png' ) )
 II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.png' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.png' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.png' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.png' ) )
 OO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.png' ) )
 Ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.png' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.png' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.png' ) )
 O0OO00o0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.png' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.png' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_series.png' ) )
 OOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_Episodios.png' ) )
 if 87 - 87: O0ooOooooO / i1I111II1I - Oooo0Ooo000 - iI - II111iiii / O0
else :
 if 97 - 97: iI - IIII * i11iIiiIii / OoOO0ooOOoo0O % Oooo0Ooo000 - OoooooooOO
 if 59 - 59: O0 + OOooOOo + i1I111II1I % OOooOOo
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
 oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.jpg' ) )
 o00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 Oo0oO0ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.jpg' ) )
 i1111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.jpg' ) )
 i11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'encines.jpg' ) )
 I11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.jpg' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.jpg' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.jpg' ) )
O0O0OOOOoo = OOI1iI1ii1II + I11i
oOooO0 = '(.+),(.+),(.*)\s*'
Ii1I1Ii = '[\'"](.*?)[\'"]'
OOoO0 = 'UmVhbHN0cmVhbQ==' . decode ( '\x62\x61\x73\x65\x36\x34' )
OO0Oooo0oOO0O = 'video=[\'"](.*?)[\'"]'
o00O0 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
oOO0O00Oo0O0o = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( '\x62\x61\x73\x65\x36\x34' ) + o00O0
ii1 = codecs . decode ( "5573756172696F732F5564622E747874" , "\x68\x65\x78" ) . decode ( 'utf-8' )
I1iIIiiIIi1i = 'aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtLw==' . decode ( '\x62\x61\x73\x65\x36\x34' ) + ii1
O0O0ooOOO = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( '\x62\x61\x73\x65\x36\x34' )
oOOo0O00o = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( '\x62\x61\x73\x65\x36\x34' )
iIiIi11 = 'aHR0cHM6Ly9uZXRhaS5ldS92aXNpdGFzL2luZGV4LnBocA==' . decode ( '\x62\x61\x73\x65\x36\x34' )
IiIIIi1iIi = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( '\x62\x61\x73\x65\x36\x34' )
if 87 - 87: ii11ii1ii . OOooOOo - II111iiii + O0 / ii11ii1ii / oO0o0ooO0
exec codecs . decode ( "64627365726965203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C304656526C42614D326875272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A6462747365726965203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C315672526E49355247526E272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C78333427290D0A6462657365726965203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C327442566C453355445232272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A6462727365726965203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C314E7A4D584E7752476842272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C783334272920200D0A64626E7365726965203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C30784B533164694D46424C272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C78333427292020" , "\x68\x65\x78" ) . decode ( 'utf-8' )
if 25 - 25: OOooOOo . OOooOOo - OoOO0ooOOoo0O % OoOO0ooOOoo0O - i11iIiiIii / Oooo0Ooo000
'movieDB' , 116 , I1I , oo00 )
      if 69 - 69: iIii1I11I1II1 . o00O0oo % iI + iIii1I11I1II1 / O0 / o00O0oo
  except :
   pass
   if 61 - 61: IIII % IIII * o0000oOoOoO0o / o0000oOoOoO0o
 if oo00O00oO == 'true' :
  II1IIIIiII1i ( '[COLOR %s]Ajustes[/COLOR]' % iIIIi1 , 'Settings' , 119 , Ii11iII1 , oo00 )
  if 75 - 75: i1I111II1I . iI
  if 50 - 50: OoOO0ooOOoo0O
  if OOoOO0oo0ooO == 'true' :
   try :
    if 60 - 60: iI * iIii1I11I1II1 * o00O0oo * ii11ii1ii
    iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
    o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
    OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
    if 69 - 69: o0oO0 * O0 . i11iIiiIii / o0oO0 . o0000oOoOoO0o
    if 63 - 63: O0oO + o0000oOoOoO0o . II111iiii - OOooOOo
    IIi = OO0O0 ( I1iIIiiIIi1i )
    I11I11 = re . compile ( oOooO0 ) . findall ( IIi )
    for OOii111IiiI1 , ooO0oOo0o , ii11i1iIiII1 in I11I11 :
     if re . search ( OOO00O , ii11i1iIiII1 ) :
      if 52 - 52: o0000oOoOoO0o % ii11ii1ii
      if iiII1i1 == ooO0oOo0o and o00oOO0o == OOii111IiiI1 and OOO00O == ii11i1iIiII1 :
       if 64 - 64: O0 % O0oO % O0 * OoOO . oO0o0ooO0 + OOooOOo
       O00I11ii1i1 ( )
   except :
    pass
    if 78 - 78: O0ooOooooO
  if iIiIIIi == 'true' :
   if 28 - 28: O0oO
   oOOOOoo ( )
   if 58 - 58: o0000oOoOoO0o / i1I111II1I . OoOO0ooOOoo0O / OoooooooOO + Oooo0Ooo000
  if iiI111I1iIiI == 'false' :
   if 86 - 86: O0oO * OOooOOo + O0oO + II111iiii
   Ooo00Oo = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   oO00Oooo0O0o0 = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.ResolveURL para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   II1iI1I11I = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, Script.resolveurl instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 8 - 8: Oooo0Ooo000 - O0ooOooooO / iI
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , Ooo00Oo , oO00Oooo0O0o0 , II1iI1I11I )
   if 96 - 96: OoOO0ooOOoo0O
def IIiiI ( ) :
 II1IIIIiII1i ( '[COLOR orange]Buscador por id[/COLOR]' , IIIII11I1IiI , 127 , oOOoo00O0O , oo00 )
 I / OoooooooOO / ii11ii1ii - OoOO
 try :
  if 56 - 56: o00O0oo
  O0ooO00oO = OO0O0 ( dbrserie )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( O0ooO00oO )
  for o000O0O in I11I11 :
   if 26 - 26: OoooooooOO % OoooooooOO
   try :
    if 33 - 33: Oooo0Ooo000
    OOO0oOoO0O = o000O0O
    if 62 - 62: o00O0oo + o0oO0 + i1IIi / OoooooooOO
   except :
    pass
    if 7 - 7: o0000oOoOoO0o + i1IIi . OOooOOo / ii11ii1ii
  i111iIi1i1II1 = OO0O0 ( OOO0oOoO0O )
  I11I11 = re . compile ( OoO ) . findall ( i111iIi1i1II1 )
  for OoOo000oOo0oo , i1I1i111Ii , oo00 , ooo , Ooo0oOooo0 in I11I11 :
   try :
    if 22 - 22: iI - iI % IIII . Oooo0Ooo000 + oO0o0ooO0
    iIiIIii ( i1I1i111Ii , ooo , 143 , OoOo000oOo0oo , oo00 , Ooo0oOooo0 )
    if 63 - 63: OOooOOo % Oooo0Ooo000 * o0000oOoOoO0o + Oooo0Ooo000 / ii11ii1ii % O0ooOooooO
   except :
    pass
 except :
  pass
  if 45 - 45: i1I111II1I
  if 20 - 20: OoooooooOO * o0000oOoOoO0o * O0 . IIII
def OoO000O ( ) :
 if 94 - 94: OoOO0ooOOoo0O . O0 / o0oO0 . o00O0oo - i1IIi
 try :
  if 26 - 26: OoOO - IIII . o0000oOoOoO0o
  O0ooO00oO = OO0O0 ( dbeserie )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( O0ooO00oO )
  for o000O0O in I11I11 :
   if 65 - 65: o00O0oo % O0 % iIii1I11I1II1 * o0oO0
   try :
    if 31 - 31: o0oO0
    OOO0oOoO0O = o000O0O
    if 44 - 44: OoOO0ooOOoo0O - iIii1I11I1II1 - ii11ii1ii
   except :
    pass
    if 80 - 80: iIii1I11I1II1 * Oooo0Ooo000 % O0oO % ii11ii1ii
  i111iIi1i1II1 = OO0O0 ( OOO0oOoO0O )
  I11I11 = re . compile ( OoO ) . findall ( i111iIi1i1II1 )
  for OoOo000oOo0oo , i1I1i111Ii , oo00 , ooo , Ooo0oOooo0 in I11I11 :
   try :
    if 95 - 95: iIii1I11I1II1 - o00O0oo . Oooo0Ooo000 - OOooOOo
    iIiIIii ( i1I1i111Ii , ooo , 143 , OoOo000oOo0oo , oo00 , Ooo0oOooo0 )
    if 75 - 75: OoOO + o0000oOoOoO0o - i1IIi . OoooooooOO * o0oO0 / i1I111II1I
   except :
    pass
 except :
  pass
  if 86 - 86: OoOO0ooOOoo0O * II111iiii - O0 . OoOO0ooOOoo0O % iIii1I11I1II1 / IIII
def IiIIiIIIiIii ( ) :
 if 23 - 23: O0ooOooooO + O0oO . OoOO0ooOOoo0O * OOooOOo + o00O0oo
 try :
  if 18 - 18: i1I111II1I * o0000oOoOoO0o . i1I111II1I / O0
  O0ooO00oO = OO0O0 ( dbtserie )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( O0ooO00oO )
  for o000O0O in I11I11 :
   if 8 - 8: o0000oOoOoO0o
   try :
    if 4 - 4: o00O0oo + o00O0oo * iI - OoOO0ooOOoo0O
    OOO0oOoO0O = o000O0O
    if 78 - 78: o0oO0 / II111iiii % OoOO0ooOOoo0O
   except :
    pass
    if 52 - 52: IIII - O0ooOooooO * oO0o0ooO0
  i111iIi1i1II1 = OO0O0 ( OOO0oOoO0O )
  I11I11 = re . compile ( OoO ) . findall ( i111iIi1i1II1 )
  for OoOo000oOo0oo , i1I1i111Ii , oo00 , ooo , Ooo0oOooo0 in I11I11 :
   try :
    if 17 - 17: OoooooooOO + IIII * O0oO * OoOO0ooOOoo0O
    iIiIIii ( i1I1i111Ii , ooo , 143 , OoOo000oOo0oo , oo00 , Ooo0oOooo0 )
    if 36 - 36: O0 + ii11ii1ii
   except :
    pass
 except :
  pass
  if 5 - 5: ii11ii1ii * OoOO0ooOOoo0O
def ii1I11iIiIII1 ( ) :
 if 52 - 52: o0000oOoOoO0o * i1I111II1I + OoOO0ooOOoo0O
 try :
  if 49 - 49: iIii1I11I1II1 - O0 . i1IIi - OoooooooOO
  O0ooO00oO = OO0O0 ( dbserie )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( O0ooO00oO )
  for o000O0O in I11I11 :
   if 37 - 37: i1IIi . O0oO % OoOO0ooOOoo0O + OoooooooOO / O0ooOooooO
   try :
    if 3 - 3: o00O0oo
    OOO0oOoO0O = o000O0O
    if 17 - 17: o00O0oo . II111iiii . iI / o00O0oo
   except :
    pass
    if 57 - 57: O0oO
  i111iIi1i1II1 = OO0O0 ( OOO0oOoO0O )
  I11I11 = re . compile ( OoO ) . findall ( i111iIi1i1II1 )
  for OoOo000oOo0oo , i1I1i111Ii , oo00 , ooo , Ooo0oOooo0 in I11I11 :
   try :
    if 67 - 67: OoOO . iI
    iIiIIii ( i1I1i111Ii , ooo , 143 , OoOo000oOo0oo , oo00 , Ooo0oOooo0 )
    if 87 - 87: oO0o0ooO0 % o0oO0
   except :
    pass
 except :
  pass
  if 83 - 83: II111iiii - O0oO
def iiIii1IIi ( name , url ) :
 if 10 - 10: i11iIiiIii - o0000oOoOoO0o % iIii1I11I1II1
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 49 - 49: oO0o0ooO0
 OOOOoOo00OO = OO0O0 ( url )
 I11I11 = re . compile ( iiiIi1 ) . findall ( OOOOoOo00OO )
 for OoOo000oOo0oo , name , oo00 , url in I11I11 :
  try :
   if 75 - 75: O0 % OoOO0ooOOoo0O . i1I111II1I / i1I111II1I / OoOO
   if 19 - 19: o00O0oo % i11iIiiIii . IIII - ii11ii1ii / OoooooooOO
   O00OOOoOoo0O = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % O00OOOoOoo0O + name + '[/COLOR]'
   oOOo00O0OOOo ( name , url , 144 , OoOo000oOo0oo , oo00 )
   if 31 - 31: O0oO % IIII * O0oO
   if 45 - 45: i1IIi . OOooOOo + IIII - OoooooooOO % iI
  except :
   pass
   if 1 - 1: iIii1I11I1II1
   if 93 - 93: i1IIi . i11iIiiIii . ii11ii1ii
   if 99 - 99: O0oO - Oooo0Ooo000 - oO0o0ooO0 % OoOO
def oOOo00O0OOOo ( name , url , mode , iconimage , fanart ) :
 if 21 - 21: II111iiii % o00O0oo . i1IIi - OoooooooOO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 4 - 4: OoooooooOO . iI
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage="
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , fanart )
 II1iIi1IiIii . setProperty ( 'IsPlayable' , 'true' )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii )
 return I111I11I111
 if 46 - 46: i11iIiiIii - O0 . oO0o0ooO0
 if 100 - 100: OOooOOo / o0000oOoOoO0o * O0ooOooooO . O0 / IIII
def oOO0o000Oo00o ( name , url ) :
 if 21 - 21: OoooooooOO - iIii1I11I1II1
 if 93 - 93: oO0o0ooO0 - o0000oOoOoO0o % OoOO0ooOOoo0O . OoOO0ooOOoo0O - iI
 IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 o00O0 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 oOO0O00Oo0O0o = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( '\x62\x61\x73\x65\x36\x34' )
 O00ooOo = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 iIIIiIi = OO0O0 ( oOO0O00Oo0O0o )
 I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
 for oOO0o00O in I11I11 :
  if 69 - 69: i1IIi
  try :
   if 59 - 59: II111iiii - o0000oOoOoO0o
   if 24 - 24: ii11ii1ii - i1IIi + O0oO
   IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 38 - 38: OoooooooOO / o00O0oo . O0 / i1IIi / ii11ii1ii + iIii1I11I1II1
   if 96 - 96: O0ooOooooO
   if IIIi1I1IIii1II == oOO0o00O :
    if 18 - 18: O0ooOooooO * O0oO - o0oO0
    if 'https://mybox.com' in url :
     if 31 - 31: ii11ii1ii - O0 % OoOO0ooOOoo0O % oO0o0ooO0
     url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
     if 45 - 45: o00O0oo + II111iiii * i11iIiiIii
    if 'uptostream.com' in url :
     if 13 - 13: OoooooooOO * oO0o0ooO0 - o0oO0 / IIII + O0oO + i1I111II1I
     try :
      if 39 - 39: iIii1I11I1II1 - OoooooooOO
      iIIIiIi = OO0O0 ( url )
      I11I11 = re . compile ( O0OO0O ) . findall ( iIIIiIi )
      for url , oO0oooooo , o0OO0Oo in I11I11 :
       if 3 - 3: Oooo0Ooo000 - O0 % iIii1I11I1II1 / i1I111II1I . o0000oOoOoO0o
       oO0oooooo = oO0oooooo . replace ( '","res":"2160",' , ' ' ) . replace ( '","res":"1080",' , ' ' ) . replace ( '","res":"720",' , ' ' ) . replace ( '","res":"480",' , ' ' ) . replace ( '","res":"360",' , ' ' )
       url = url . replace ( '\/' , '/' )
       url = url . replace ( ',"type":"video/mp4",' , ' ' )
       o0OO0Oo = o0OO0Oo . replace ( 'spa' , 'Castellano:' ) . replace ( 'eng' , 'Ingles:' ) . replace ( 'spa1' , 'Latino:' ) . replace ( 'eng2' , 'Americano:' )
       name = '[COLOR white]' + o0OO0Oo + '[/COLOR] - [COLOR gold]' + oO0oooooo + '[/COLOR]'
       if 3 - 3: O0 % OoooooooOO / IIII
       ooOo = [ ]
       ooOo . append ( '[COLOR orange]Real Stream: [/COLOR][COLOR gold]1. Mostrar mas info. [Reiniciar][/COLOR]' )
       ooOo . append ( '[COLOR gold]2. Mostar otras calidades disponibles [/COLOR]' )
       ooOo . append ( '[COLOR gold]3. Ver en: %s [/COLOR]' % name )
       if 84 - 84: IIII
       if 87 - 87: iI + o0000oOoOoO0o
       i1iIIIIIIiII1 = 'Seleccione una calidad e idioma:'
       iii11 = xbmcgui . Dialog ( )
       i1oO = iii11 . select ( i1iIIIIIIiII1 , ooOo )
       if 30 - 30: ii11ii1ii . OoOO
       if 57 - 57: O0oO . ii11ii1ii + II111iiii
       if i1oO == 0 :
        if 43 - 43: Oooo0Ooo000 % O0ooOooooO
        I111I11I111 = iii11 . ok ( "[COLOR darkpink]REALSTREAM:[/COLOR] " , "[COLOR gold]  Reiniciadas las opciones.  [/COLOR]" , "" )
        del iii11
        return
        if 69 - 69: O0ooOooooO % OoOO
       elif i1oO == 1 :
        if 86 - 86: oO0o0ooO0 / oO0o0ooO0
        pass
        if 28 - 28: i11iIiiIii / o0000oOoOoO0o . iIii1I11I1II1 / II111iiii
        del iii11
        if 72 - 72: OoooooooOO / OOooOOo + o0oO0 / OoOO0ooOOoo0O * o0oO0
        if 34 - 34: O0 * O0 % OoooooooOO + O0ooOooooO * iIii1I11I1II1 % o0oO0
        if 25 - 25: O0oO + OoOO0ooOOoo0O . o0000oOoOoO0o % OoOO0ooOOoo0O * IIII
        if 32 - 32: i11iIiiIii - Oooo0Ooo000
       elif i1oO == 2 :
        if 53 - 53: OoooooooOO - i1I111II1I
        oOo ( name , url )
        if 17 - 17: o0oO0 . i11iIiiIii
        return
        if 5 - 5: o00O0oo + O0 + O0 . Oooo0Ooo000 - iI
     except :
      pass
      if 63 - 63: oO0o0ooO0
      if 71 - 71: i1IIi . o0oO0 * O0ooOooooO % OoooooooOO + IIII
    if 'https://team.com' in url :
     if 36 - 36: i1I111II1I
     url = url . replace ( 'https://team.com' , 'https://verystream.com' )
     if 49 - 49: IIII / OoooooooOO / OOooOOo
     if 74 - 74: Oooo0Ooo000 % o00O0oo
     if 7 - 7: II111iiii
    if 'https://vidcloud.co/' in url :
     if 27 - 27: oO0o0ooO0 . OoooooooOO + i11iIiiIii
     url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
     if 86 - 86: O0oO / o0000oOoOoO0o - o0000oOoOoO0o + o00O0oo + oO0o0ooO0
    if 'https://gounlimited.to' in url :
     if 33 - 33: o0000oOoOoO0o . O0ooOooooO . i1I111II1I . i1IIi
     url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
     if 49 - 49: o00O0oo
    if 'https://drive.com' in url :
     if 84 - 84: O0oO - ii11ii1ii / O0 - Oooo0Ooo000
     url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
     if 21 - 21: O0 * O0 % o00O0oo
     if 94 - 94: O0oO + II111iiii % i11iIiiIii
     if 8 - 8: iI * O0
     if 73 - 73: o0000oOoOoO0o / oO0o0ooO0 / O0oO / OoOO
    import resolveurl
    if 11 - 11: OoOO0ooOOoo0O + i1I111II1I - OoooooooOO / OoOO
    iIIi1iI1I1IIi = resolveurl . HostedMediaFile ( url )
    if 77 - 77: iI / ii11ii1ii + iI % o0000oOoOoO0o - OOooOOo * OOooOOo
    if not iIIi1iI1I1IIi :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
     return False
     if 23 - 23: O0ooOooooO . II111iiii % o00O0oo - OoooooooOO * ii11ii1ii . iIii1I11I1II1
    try :
     Oo0O0 = xbmcgui . DialogProgress ( )
     Oo0O0 . create ( 'Realstream:' , 'Iniciando ...' )
     Oo0O0 . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
     xbmc . sleep ( 1000 )
     I1iI = iIIi1iI1I1IIi . resolve ( )
     if not I1iI or not isinstance ( I1iI , basestring ) :
      try : O0o00O0Oo0 = I1iI . msg
      except : O0o00O0Oo0 = url
      raise Exception ( O0o00O0Oo0 )
      if 58 - 58: O0
    except Exception as oOoO0 :
     try : O0o00O0Oo0 = str ( oOoO0 )
     except : O0o00O0Oo0 = url
     Oo0O0 . update ( 45 , 'RESOLVEURL:' , 'Reiniciando ... ' )
     xbmc . sleep ( 1000 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Episodio no disponible.  ,3000)" )
     Oo0O0 . close ( )
     if 78 - 78: OoOO % i1I111II1I * i1IIi
    Oo0O0 . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    Oo0O0 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
    xbmc . sleep ( 500 )
    Oo0O0 . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
    xbmc . sleep ( 500 )
    Oo0O0 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de este capitulo!' )
    Oo0O0 . close ( )
    O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
    O0iI = xbmcgui . ListItem ( path = I1iI )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0iI )
    if 15 - 15: O0 / ii11ii1ii % o00O0oo + o0000oOoOoO0o
    if 23 - 23: iIii1I11I1II1 + O0
   else :
    if 58 - 58: ii11ii1ii
    O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
    if O0ii1ii1ii == 'true' :
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Por favor compruebe los ajustes de realstream.[/COLOR]" , "[COLOR white] Desde la seccion Tutoriales puede sacarle mayor partido a su Realstream, tambien puede configurarlo a su gusto. [/COLOR]" , "[COLOR gold]El addon no esta activado o bien configurado.[/COLOR]" )
     if 9 - 9: iIii1I11I1II1 % o00O0oo . IIII + OoooooooOO
     iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
     II1IIIIiII1i ( '[COLOR %s]Video tutoriales[/COLOR]' % iIIIi1 , IIIII11I1IiI , 125 , O0OOO0OOoO0O , oo00 )
  except :
   pass
   if 62 - 62: O0 / OOooOOo % O0 * OoOO % OOooOOo
   if 33 - 33: OOooOOo . oO0o0ooO0 * OoOO * iIii1I11I1II1
   if 5 - 5: ii11ii1ii / i1I111II1I % O0 . Oooo0Ooo000 * i1I111II1I
   if 83 - 83: IIII
def iiooO0o0oO ( ) :
 if 67 - 67: OoooooooOO
 if 29 - 29: O0 - i11iIiiIii - II111iiii + IIII * i1I111II1I
 try :
  if 2 - 2: i1IIi - iI + OOooOOo . o0000oOoOoO0o * o0000oOoOoO0o / OoOO0ooOOoo0O
  O0ooO00oO = OO0O0 ( dbpelicula )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( O0ooO00oO )
  for o000O0O in I11I11 :
   if 93 - 93: i1IIi
   try :
    if 53 - 53: OoooooooOO + ii11ii1ii + oO0o0ooO0
    OOO0oOoO0O = o000O0O
    i1iI = xbmc . Keyboard ( '' , 'Buscar' )
    i1iI . doModal ( )
    if ( i1iI . isConfirmed ( ) ) :
     Oo0O0 = xbmcgui . DialogProgress ( )
     Oo0O0 . create ( 'Realstream:' , 'Buscando ...' )
     Ooo0OOoOoO0 = range ( 0 , 69 )
     for oOo0OOoO0 in Ooo0OOoOoO0 :
      oOo0OOoO0 = oOo0OOoO0 + 1
     IiII111i1i11 = urllib . quote_plus ( i1iI . getText ( ) ) . replace ( '+' , ' ' )
     i111iIi1i1II1 = OO0O0 ( OOO0oOoO0O )
     I11I11 = re . compile ( I1iI1 ) . findall ( i111iIi1i1II1 )
     for OoOo000oOo0oo , i1I1i111Ii , oo00 , ooo , Ooo0oOooo0 in I11I11 :
      Oo0O0 . update ( oOo0OOoO0 , '[COLOR orange]Realstream: Buscando ...[/COLOR]' , '[COLOR gold] %s [/COLOR]' % i1I1i111Ii )
      xbmc . sleep ( 5 )
      if Oo0O0 . iscanceled ( ) : break ;
      if re . search ( IiII111i1i11 , IiI1iIiIIIii ( i1I1i111Ii . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       if 24 - 24: O0ooOooooO - i1I111II1I - O0ooOooooO * o00O0oo . OoooooooOO / i1I111II1I
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Generando listado ...  [COLOR orange] Por favor espere ![/COLOR] , 4000)" )
       iIiIIii ( i1I1i111Ii , ooo , 147 , OoOo000oOo0oo , oo00 , Ooo0oOooo0 )
       Oo0O0 . update ( 100 , '[COLOR orange]Realstream: [/COLOR]' , '[COLOR gold] Busqueda finalizada ...[/COLOR]' )
       xbmc . sleep ( 2000 )
       Oo0O0 . close ( )
     II1IIIIiII1i ( '[COLOR %s]Buscar Pelicula[/COLOR]' % iIIIi1 , 'search' , 146 , O0OO00o0OO , oo00 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Sin Resultados para: [COLOR orange]" + IiII111i1i11 + "[/COLOR] , 2000)" )
     if 66 - 66: ii11ii1ii
     if 97 - 97: i1IIi - OoooooooOO / Oooo0Ooo000 * OOooOOo
   except : II1IIIIiII1i ( '[COLOR %s]Buscar Pelicula[/COLOR]' % iIIIi1 , 'search' , 146 , O0OO00o0OO , oo00 )
   if 55 - 55: o0000oOoOoO0o . O0ooOooooO
 except :
  pass
  if 87 - 87: o0000oOoOoO0o % iIii1I11I1II1
def O00Iii1111III111 ( ) :
 if 28 - 28: OoooooooOO . oO0o0ooO0 % o00O0oo / i1IIi / IIII
 try :
  if 36 - 36: o0000oOoOoO0o + O0oO - i1I111II1I + iIii1I11I1II1 + OoooooooOO
  O0ooO00oO = OO0O0 ( dbpelicula )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( O0ooO00oO )
  for o000O0O in I11I11 :
   if 4 - 4: II111iiii . O0oO + o0oO0 * Oooo0Ooo000 . iI
   try :
    if 87 - 87: OoOO0ooOOoo0O / OoOO / i11iIiiIii
    OOO0oOoO0O = o000O0O
    if 74 - 74: oO0o0ooO0 / o00O0oo % o0000oOoOoO0o
   except :
    pass
    if 88 - 88: OoOO0ooOOoo0O - i11iIiiIii % o0000oOoOoO0o * O0oO + o00O0oo
  i111iIi1i1II1 = OO0O0 ( OOO0oOoO0O )
  I11I11 = re . compile ( I1iI1 ) . findall ( i111iIi1i1II1 )
  for OoOo000oOo0oo , i1I1i111Ii , oo00 , ooo , Ooo0oOooo0 in I11I11 :
   try :
    if 52 - 52: II111iiii . OOooOOo + OoOO0ooOOoo0O % OoOO
    iIiIIii ( i1I1i111Ii , ooo , 147 , OoOo000oOo0oo , oo00 , Ooo0oOooo0 )
    if 62 - 62: o0000oOoOoO0o
   except :
    pass
 except :
  pass
  if 15 - 15: O0oO + o0oO0 . IIII * OoOO . OoOO0ooOOoo0O
  if 18 - 18: i1IIi % II111iiii + Oooo0Ooo000 % o0oO0
  if 72 - 72: iIii1I11I1II1
def iI1I1II1 ( ) :
 if 92 - 92: OoooooooOO - OoooooooOO * OoOO % OOooOOo
 try :
  if 77 - 77: iIii1I11I1II1 - i1IIi . oO0o0ooO0
  O0ooO00oO = OO0O0 ( dbnovedades )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( O0ooO00oO )
  for o000O0O in I11I11 :
   if 26 - 26: o0000oOoOoO0o * i1I111II1I . i1IIi
   try :
    if 59 - 59: O0 + i1IIi - o0000oOoOoO0o
    OOO0oOoO0O = o000O0O
    if 62 - 62: i11iIiiIii % IIII . i1I111II1I . IIII
   except :
    pass
    if 84 - 84: i11iIiiIii * OoOO
  i111iIi1i1II1 = OO0O0 ( OOO0oOoO0O )
  I11I11 = re . compile ( I1iI1 ) . findall ( i111iIi1i1II1 )
  for OoOo000oOo0oo , i1I1i111Ii , oo00 , ooo , Ooo0oOooo0 in I11I11 :
   try :
    if 18 - 18: IIII - o0oO0 - OoOO0ooOOoo0O / Oooo0Ooo000 - O0
    iIiIIii ( i1I1i111Ii , ooo , 147 , OoOo000oOo0oo , oo00 , Ooo0oOooo0 )
    if 30 - 30: O0 + o00O0oo + II111iiii
   except :
    pass
 except :
  pass
  if 14 - 14: o0000oOoOoO0o / IIII - iIii1I11I1II1 - oO0o0ooO0 % iI
def I1iIiI1IiIIII ( ) :
 if 18 - 18: iI % i11iIiiIii . iIii1I11I1II1 - O0ooOooooO
 try :
  if 80 - 80: OOooOOo + oO0o0ooO0 - i1IIi . o0oO0 / o0000oOoOoO0o / OOooOOo
  I1Iiii = OO0O0 ( dbfamiliar )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( I1Iiii )
  for o000O0O in I11I11 :
   if 34 - 34: o0oO0 * OoOO0ooOOoo0O - i1I111II1I - OOooOOo - o0oO0
   try :
    if 42 - 42: II111iiii * OOooOOo % i1IIi - o0oO0 % i1I111II1I
    OOO0oOoO0O = o000O0O
    if 36 - 36: i11iIiiIii / oO0o0ooO0 * o00O0oo * o00O0oo + o0oO0 * O0oO
   except :
    pass
    if 32 - 32: OoOO
  i111iIi1i1II1 = OO0O0 ( OOO0oOoO0O )
  I11I11 = re . compile ( I1iI1 ) . findall ( i111iIi1i1II1 )
  for OoOo000oOo0oo , i1I1i111Ii , oo00 , ooo , Ooo0oOooo0 in I11I11 :
   try :
    if 50 - 50: iI + i1IIi
    iIiIIii ( i1I1i111Ii , ooo , 147 , OoOo000oOo0oo , oo00 , Ooo0oOooo0 )
    if 31 - 31: o0oO0
   except :
    pass
 except :
  pass
  if 78 - 78: i11iIiiIii + o0000oOoOoO0o + Oooo0Ooo000 / o0000oOoOoO0o % iIii1I11I1II1 % i1I111II1I
def Oo0O0Oo00O ( ) :
 if 9 - 9: o0000oOoOoO0o . OOooOOo - o00O0oo
 try :
  if 32 - 32: OoooooooOO / OOooOOo / iIii1I11I1II1 + II111iiii . oO0o0ooO0 . o0000oOoOoO0o
  O0ooO00oO = OO0O0 ( dbestrenos )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( O0ooO00oO )
  for o000O0O in I11I11 :
   if 21 - 21: iIii1I11I1II1 / II111iiii % i1IIi
   try :
    if 8 - 8: OoOO + OoOO0ooOOoo0O . iIii1I11I1II1 % O0
    OOO0oOoO0O = o000O0O
    if 43 - 43: o00O0oo - O0ooOooooO
   except :
    pass
    if 70 - 70: O0ooOooooO / IIII % iI - o0oO0
  i111iIi1i1II1 = OO0O0 ( OOO0oOoO0O )
  I11I11 = re . compile ( I1iI1 ) . findall ( i111iIi1i1II1 )
  for OoOo000oOo0oo , i1I1i111Ii , oo00 , ooo , Ooo0oOooo0 in I11I11 :
   try :
    if 47 - 47: O0ooOooooO
    iIiIIii ( i1I1i111Ii , ooo , 147 , OoOo000oOo0oo , oo00 , Ooo0oOooo0 )
    if 92 - 92: IIII + OoOO0ooOOoo0O % i1IIi
   except :
    pass
 except :
  pass
  if 23 - 23: Oooo0Ooo000 - IIII + o0oO0 - OoOO0ooOOoo0O * OoOO0ooOOoo0O . ii11ii1ii
def iIii11iI1II ( ) :
 if 42 - 42: iI - OOooOOo + o00O0oo % o0oO0
 try :
  if 44 - 44: i1IIi - O0 - o00O0oo * o00O0oo + OoOO0ooOOoo0O
  O0oo = OO0O0 ( dbsuperheroes )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( O0oo )
  for o000O0O in I11I11 :
   if 82 - 82: OoOO0ooOOoo0O + O0 - i1I111II1I % oO0o0ooO0 * i11iIiiIii
   try :
    if 15 - 15: o0000oOoOoO0o
    OOO0oOoO0O = o000O0O
    if 39 - 39: IIII / o00O0oo / OOooOOo * Oooo0Ooo000
   except :
    pass
    if 44 - 44: O0 + iI . iIii1I11I1II1 + ii11ii1ii / O0 - O0oO
  i111iIi1i1II1 = OO0O0 ( OOO0oOoO0O )
  I11I11 = re . compile ( I1iI1 ) . findall ( i111iIi1i1II1 )
  for OoOo000oOo0oo , i1I1i111Ii , oo00 , ooo , Ooo0oOooo0 in I11I11 :
   try :
    if 83 - 83: i1I111II1I * O0oO / ii11ii1ii
    iIiIIii ( i1I1i111Ii , ooo , 147 , OoOo000oOo0oo , oo00 , Ooo0oOooo0 )
    if 32 - 32: o0000oOoOoO0o + OoOO0ooOOoo0O - OoooooooOO
   except :
    pass
 except :
  pass
  if 39 - 39: OoooooooOO * IIII * O0 . O0oO . OoOO + iI
def II1IIi ( ) :
 if 51 - 51: ii11ii1ii + oO0o0ooO0 / O0ooOooooO - i1IIi
 try :
  if 51 - 51: ii11ii1ii - o00O0oo * O0oO
  O0ooO00oO = OO0O0 ( dbgpelis )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( O0ooO00oO )
  for o000O0O in I11I11 :
   if 12 - 12: iIii1I11I1II1 % iI % iI
   try :
    if 78 - 78: i1I111II1I . OoOO0ooOOoo0O . O0oO
    OOO0oOoO0O = o000O0O
    if 97 - 97: oO0o0ooO0
   except :
    pass
    if 80 - 80: OOooOOo . o0oO0
  i111iIi1i1II1 = OO0O0 ( OOO0oOoO0O )
  I11I11 = re . compile ( I1iI1 ) . findall ( i111iIi1i1II1 )
  for OoOo000oOo0oo , i1I1i111Ii , oo00 , ooo , Ooo0oOooo0 in I11I11 :
   try :
    if 47 - 47: O0oO + iI + II111iiii % i11iIiiIii
    iIiIIii ( i1I1i111Ii , ooo , 147 , OoOo000oOo0oo , oo00 , Ooo0oOooo0 )
    if 93 - 93: o00O0oo % OoOO0ooOOoo0O . O0 / O0ooOooooO * oO0o0ooO0
   except :
    pass
 except :
  pass
  if 29 - 29: o0000oOoOoO0o
def oo0 ( ) :
 if 2 - 2: OoooooooOO
 try :
  if 60 - 60: OoOO
  O0ooO00oO = OO0O0 ( P4k )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( O0ooO00oO )
  for o000O0O in I11I11 :
   if 81 - 81: OoOO0ooOOoo0O % o0oO0
   try :
    if 87 - 87: iIii1I11I1II1 . OoooooooOO * OoOO0ooOOoo0O
    OOO0oOoO0O = o000O0O
    if 100 - 100: OoOO / i1IIi - OOooOOo % o0oO0 - iIii1I11I1II1
   except :
    pass
    if 17 - 17: O0oO / o0000oOoOoO0o % ii11ii1ii
  i111iIi1i1II1 = OO0O0 ( OOO0oOoO0O )
  I11I11 = re . compile ( I1iI1 ) . findall ( i111iIi1i1II1 )
  for OoOo000oOo0oo , i1I1i111Ii , oo00 , ooo , Ooo0oOooo0 in I11I11 :
   try :
    if 71 - 71: i1I111II1I . Oooo0Ooo000 . OoOO
    iIiIIii ( i1I1i111Ii , ooo , 147 , OoOo000oOo0oo , oo00 , Ooo0oOooo0 )
    if 68 - 68: i11iIiiIii % oO0o0ooO0 * OoOO * i1I111II1I * II111iiii + O0
   except :
    pass
 except :
  pass
  if 66 - 66: O0oO % o00O0oo % OoooooooOO
def II11 ( ) :
 if 2 - 2: iIii1I11I1II1
 try :
  if 45 - 45: OoooooooOO / i11iIiiIii
  I11I1i1iI = OO0O0 ( db23 )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( I11I1i1iI )
  for o000O0O in I11I11 :
   if 90 - 90: i1I111II1I * II111iiii % Oooo0Ooo000 + oO0o0ooO0
   try :
    if 93 - 93: Oooo0Ooo000 + o0oO0
    OOO0oOoO0O = o000O0O
    if 33 - 33: O0
   except :
    pass
    if 78 - 78: O0 / II111iiii * OoOO
  i111iIi1i1II1 = OO0O0 ( OOO0oOoO0O )
  I11I11 = re . compile ( I1iI1 ) . findall ( i111iIi1i1II1 )
  for OoOo000oOo0oo , i1I1i111Ii , oo00 , ooo , Ooo0oOooo0 in I11I11 :
   try :
    if 50 - 50: OoooooooOO - iIii1I11I1II1 + i1IIi % Oooo0Ooo000 - iIii1I11I1II1 % O0
    iIiIIii ( i1I1i111Ii , ooo , 147 , OoOo000oOo0oo , oo00 , Ooo0oOooo0 )
    if 58 - 58: i1I111II1I + iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 65 - 65: II111iiii - Oooo0Ooo000 % o0000oOoOoO0o - OoOO0ooOOoo0O * O0ooOooooO + o0oO0
def O0o0O0OO0o ( ) :
 if 54 - 54: OoOO0ooOOoo0O . oO0o0ooO0 % i11iIiiIii / OoooooooOO + i1I111II1I % oO0o0ooO0
 try :
  if 36 - 36: oO0o0ooO0
  iIIIiIi = OO0O0 ( db4 )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
  for o000O0O in I11I11 :
   if 74 - 74: OoooooooOO
   try :
    if 72 - 72: O0 + OOooOOo - O0ooOooooO - OoOO
    OOO0oOoO0O = o000O0O
    if 100 - 100: O0
   except :
    pass
    if 79 - 79: iIii1I11I1II1
    if 81 - 81: IIII + iIii1I11I1II1 * Oooo0Ooo000 - iIii1I11I1II1 . IIII
    if 48 - 48: O0oO . OoooooooOO . OOooOOo . OoOO0ooOOoo0O % o00O0oo / O0ooOooooO
  i111iIi1i1II1 = OO0O0 ( OOO0oOoO0O )
  I11I11 = re . compile ( I1iI1 ) . findall ( i111iIi1i1II1 )
  for OoOo000oOo0oo , i1I1i111Ii , oo00 , ooo , Ooo0oOooo0 in I11I11 :
   try :
    if 11 - 11: i1IIi % OoOO % O0ooOooooO
    iIiIIii ( i1I1i111Ii , ooo , 147 , OoOo000oOo0oo , oo00 , Ooo0oOooo0 )
    if 99 - 99: iI / iIii1I11I1II1 - o0oO0 * o00O0oo % OOooOOo
   except :
    pass
 except :
  pass
  if 13 - 13: OoOO
def O0oo0O0 ( name , url ) :
 if 2 - 2: OoooooooOO . IIII . i1I111II1I
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 42 - 42: IIII % oO0o0ooO0 / OoOO - oO0o0ooO0 * i11iIiiIii
 OOOOoOo00OO = OO0O0 ( url )
 I11I11 = re . compile ( i1I1ii11i1Iii ) . findall ( OOOOoOo00OO )
 for OoOo000oOo0oo , name , oo00 , url , id in I11I11 :
  try :
   if 19 - 19: oO0o0ooO0 * OOooOOo % i11iIiiIii
   O00OOOoOoo0O = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % O00OOOoOoo0O + name + '[/COLOR]'
   iiI1Ii1I ( name , url , 130 , OoOo000oOo0oo , oo00 , id )
   if 28 - 28: IIII % iI
   if 48 - 48: i11iIiiIii % oO0o0ooO0
  except :
   pass
   if 29 - 29: O0ooOooooO + i11iIiiIii % O0oO
def iiI1Ii1I ( name , url , mode , iconimage , fanart , id ) :
 if 93 - 93: OoOO0ooOOoo0O % iIii1I11I1II1
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 90 - 90: OOooOOo - IIII / o0oO0 / O0 / O0oO
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + "&id=" + str ( id )
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , fanart )
 II1iIi1IiIii . setProperty ( 'IsPlayable' , 'true' )
 oOO0 = [ ]
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  oOO0 . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 15 - 15: ii11ii1ii + O0oO . iI - iIii1I11I1II1 / O0 % iIii1I11I1II1
  II1iIi1IiIii . addContextMenuItems ( oOO0 , replaceItems = True )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii )
 return I111I11I111
 if 86 - 86: OOooOOo / oO0o0ooO0 * o0oO0
def O00o ( ) :
 if 86 - 86: o00O0oo * II111iiii * O0oO
 if 74 - 74: o00O0oo / i1I111II1I
 oo0oO0oO = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 oo0oO0oO . doModal ( )
 if not oo0oO0oO . isConfirmed ( ) :
  return None ;
 i1I1i111Ii = oo0oO0oO . getText ( ) . strip ( )
 if 48 - 48: OoOO0ooOOoo0O % o00O0oo / O0oO . iIii1I11I1II1 * II111iiii
 if 65 - 65: OoOO0ooOOoo0O
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 31 - 31: O0oO * OoOO0ooOOoo0O . i1I111II1I % o0oO0 + ii11ii1ii
  Ii1iiIi1I11i = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + i1I1i111Ii + '&language=es-ES' ) )
  if 89 - 89: Oooo0Ooo000 . i1I111II1I % ii11ii1ii . ii11ii1ii - OoooooooOO
  if 56 - 56: O0oO
  return 'android'
  if 21 - 21: iIii1I11I1II1 / Oooo0Ooo000 + iI - O0oO / ii11ii1ii / II111iiii
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 69 - 69: OOooOOo . OoOO0ooOOoo0O
  Ii1iiIi1I11i = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + i1I1i111Ii + '&language=es-ES' )
  if 53 - 53: O0oO
  if 68 - 68: oO0o0ooO0 / Oooo0Ooo000 % Oooo0Ooo000 % O0
  return 'windows'
  if 90 - 90: i1I111II1I . iI / iIii1I11I1II1
  if 28 - 28: i1I111II1I + oO0o0ooO0 - iI / iIii1I11I1II1 - OOooOOo
def Ii1i1 ( ) :
 if 65 - 65: oO0o0ooO0 + o00O0oo / IIII
 try :
  if 85 - 85: iIii1I11I1II1 / OoooooooOO % II111iiii
  iIIIiIi = OO0O0 ( todas )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
  for o000O0O in I11I11 :
   if 49 - 49: i11iIiiIii % OoOO0ooOOoo0O + Oooo0Ooo000 . II111iiii % O0ooOooooO * IIII
   try :
    if 67 - 67: i1IIi
    all = o000O0O
    if 5 - 5: II111iiii . OoooooooOO
   except :
    pass
    if 57 - 57: OOooOOo
  OOOOoOo00OO = OO0O0 ( all )
  I11I11 = re . compile ( I1iII1iIi1I ) . findall ( OOOOoOo00OO )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
   try :
    if 35 - 35: OoooooooOO - Oooo0Ooo000 / OoOO
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
    if 50 - 50: OoOO0ooOOoo0O
   except :
    pass
 except :
  pass
  if 33 - 33: O0oO
def oOo00OoO0O ( ) :
 if 69 - 69: iIii1I11I1II1 * OOooOOo - O0ooOooooO + O0 + O0
 try :
  if 65 - 65: Oooo0Ooo000 / i11iIiiIii / OoOO - IIII
  iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
  OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 9 - 9: OOooOOo / Oooo0Ooo000 - ii11ii1ii * iIii1I11I1II1
  IIi = OO0O0 ( I1iIIiiIIi1i )
  I11I11 = re . compile ( oOooO0 ) . findall ( IIi )
  for OOii111IiiI1 , ooO0oOo0o , ii11i1iIiII1 in I11I11 :
   if re . search ( OOO00O , ii11i1iIiII1 ) :
    if 86 - 86: II111iiii + iI + i1I111II1I
    if iiII1i1 == ooO0oOo0o and o00oOO0o == OOii111IiiI1 and OOO00O == ii11i1iIiII1 :
     if 9 - 9: iI + II111iiii % iI % i1I111II1I + iIii1I11I1II1
     i1111 = OO0O0 ( db )
     I11I11 = re . compile ( Ii1I1Ii ) . findall ( i1111 )
     for o000O0O in I11I11 :
      if 59 - 59: i1IIi
      try :
       if 48 - 48: O0 * o0oO0 * OoOO . OoOO * O0oO - o0oO0
       OOO0oOoO0O = o000O0O
       if 14 - 14: o00O0oo + i11iIiiIii
      except :
       pass
       if 83 - 83: o00O0oo / i11iIiiIii + II111iiii . O0ooOooooO * IIII + i1I111II1I
     i111iIi1i1II1 = OO0O0 ( OOO0oOoO0O )
     I11I11 = re . compile ( I1iII1iIi1I ) . findall ( i111iIi1i1II1 )
     for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
      try :
       if 42 - 42: i1IIi % II111iiii . iI
       o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
       if 7 - 7: o00O0oo - oO0o0ooO0 * IIII + o0000oOoOoO0o . o00O0oo
      except :
       pass
       if 85 - 85: O0
    else :
     if 32 - 32: OoooooooOO . OoOO / ii11ii1ii * o0000oOoOoO0o / o0000oOoOoO0o * o0oO0
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Esta seccion ha sido cerrada![COLOR orange] Lo sentimos ...[/COLOR] ,5000)" )
     if 19 - 19: o0oO0
     return False
     if 55 - 55: IIII % IIII / O0 % O0ooOooooO - o0000oOoOoO0o . ii11ii1ii
 except :
  pass
  if 49 - 49: iIii1I11I1II1 * i1IIi . OoooooooOO
def OOOO0oOo00O ( ) :
 if 32 - 32: i1I111II1I % o0oO0 - OOooOOo
 try :
  if 71 - 71: O0ooOooooO
  iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
  OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 23 - 23: i1IIi . iIii1I11I1II1 . IIII . O0 % o0oO0 % i11iIiiIii
  IIi = OO0O0 ( I1iIIiiIIi1i )
  I11I11 = re . compile ( oOooO0 ) . findall ( IIi )
  for ooO0oOo0o , OOii111IiiI1 , ii11i1iIiII1 in I11I11 :
   if re . search ( OOO00O , ii11i1iIiII1 ) :
    if 11 - 11: O0 - II111iiii . IIII . o0oO0 % Oooo0Ooo000
    if iiII1i1 == ooO0oOo0o and o00oOO0o == OOii111IiiI1 and OOO00O == ii11i1iIiII1 :
     if 21 - 21: ii11ii1ii / O0ooOooooO . Oooo0Ooo000 * OoooooooOO + O0oO - i1IIi
     i11 = OO0O0 ( db1 )
     I11I11 = re . compile ( Ii1I1Ii ) . findall ( i11 )
     for o000O0O in I11I11 :
      if 58 - 58: o00O0oo
      try :
       ii1IoO0O = o000O0O
      except :
       pass
       if 59 - 59: OoooooooOO * ii11ii1ii + i1IIi
     iIIIiIi = OO0O0 ( ii1IoO0O )
     I11I11 = re . compile ( I1iII1iIi1I ) . findall ( iIIIiIi )
     for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
      try :
       if 23 - 23: iI
       o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
       if 13 - 13: iIii1I11I1II1
      except :
       pass
       if 77 - 77: i11iIiiIii - iIii1I11I1II1 / oO0o0ooO0 / iI / OoOO
    else :
     if 56 - 56: OoooooooOO * O0
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Esta seccion ha sido cerrada![COLOR orange] Lo sentimos ...[/COLOR] ,5000)" )
     if 85 - 85: OoooooooOO % OoOO0ooOOoo0O * iIii1I11I1II1
     return False
 except :
  pass
  if 44 - 44: iIii1I11I1II1 . o00O0oo + Oooo0Ooo000 . iI
  if 7 - 7: o00O0oo + iIii1I11I1II1 * O0oO * O0oO / II111iiii - o0oO0
  if 65 - 65: oO0o0ooO0 + OoOO0ooOOoo0O + II111iiii
def oOOoo ( ) :
 if 6 - 6: IIII
 try :
  if 98 - 98: OoooooooOO % O0 - O0
  iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
  OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 76 - 76: i1IIi % OoOO0ooOOoo0O - OOooOOo / o0000oOoOoO0o * iI
  IIi = OO0O0 ( I1iIIiiIIi1i )
  I11I11 = re . compile ( oOooO0 ) . findall ( IIi )
  for OOii111IiiI1 , ooO0oOo0o , ii11i1iIiII1 in I11I11 :
   if re . search ( OOO00O , ii11i1iIiII1 ) :
    if 4 - 4: ii11ii1ii * ii11ii1ii / OoOO0ooOOoo0O
    if iiII1i1 == ooO0oOo0o and o00oOO0o == OOii111IiiI1 and OOO00O == ii11i1iIiII1 :
     if 4 - 4: OOooOOo * OoOO0ooOOoo0O % O0oO . OoOO0ooOOoo0O
     iIIIiIi = OO0O0 ( db2 )
     I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
     for o000O0O in I11I11 :
      if 11 - 11: IIII - OoOO0ooOOoo0O - o0000oOoOoO0o * OoOO0ooOOoo0O + iI
      try :
       if 62 - 62: OOooOOo * i11iIiiIii . O0ooOooooO
       I1iIIIiI = o000O0O
       if 60 - 60: OOooOOo . i11iIiiIii + OoOO0ooOOoo0O / o00O0oo * II111iiii * IIII
      except :
       pass
       if 59 - 59: ii11ii1ii + O0ooOooooO - IIII . o0000oOoOoO0o + OOooOOo % oO0o0ooO0
       if 37 - 37: O0ooOooooO + O0ooOooooO % o0000oOoOoO0o
     iIIIiIi = OO0O0 ( I1iIIIiI )
     I11I11 = re . compile ( I1iII1iIi1I ) . findall ( iIIIiIi )
     for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
      try :
       o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
       if 29 - 29: iI
      except :
       pass
    else :
     if 41 - 41: O0 % O0ooOooooO
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Esta seccion ha sido cerrada![COLOR orange] Lo sentimos ...[/COLOR] ,5000)" )
     if 10 - 10: O0ooOooooO . i1IIi + o0oO0
     return False
     if 66 - 66: OoOO % o0000oOoOoO0o
 except :
  pass
  if 21 - 21: OoOO0ooOOoo0O - OoooooooOO % i11iIiiIii
def Oo00O0OO ( ) :
 if 77 - 77: oO0o0ooO0 - ii11ii1ii - iIii1I11I1II1
 try :
  if 16 - 16: OoOO / O0ooOooooO / i1IIi . O0ooOooooO + oO0o0ooO0
  Iiii1I = OO0O0 ( db26 )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( Iiii1I )
  for o000O0O in I11I11 :
   if 56 - 56: i11iIiiIii - iIii1I11I1II1 . II111iiii
   try :
    if 81 - 81: i1I111II1I / OoOO0ooOOoo0O * i1I111II1I . O0
    OOOOo00oo00O = o000O0O
    if 83 - 83: II111iiii * i1IIi * O0ooOooooO . o00O0oo / O0oO + i1IIi
   except :
    pass
    if 43 - 43: OoooooooOO
    if 97 - 97: o00O0oo / ii11ii1ii + Oooo0Ooo000
  iIIIiIi = OO0O0 ( OOOOo00oo00O )
  I11I11 = re . compile ( I1iII1iIi1I ) . findall ( iIIIiIi )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
   try :
    if 32 - 32: iI % Oooo0Ooo000 * ii11ii1ii
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
    if 72 - 72: iI . O0ooOooooO - Oooo0Ooo000 - o0oO0 % i1IIi
   except :
    pass
 except :
  pass
  if 56 - 56: ii11ii1ii * O0ooOooooO
def II1I1ii1ii11 ( ) :
 if 64 - 64: OoOO % i1I111II1I . Oooo0Ooo000 % OoOO + O0oO * i1I111II1I
 try :
  if 83 - 83: o0000oOoOoO0o % oO0o0ooO0 + O0oO % i11iIiiIii + O0
  iIIIiIi = OO0O0 ( db3 )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
  for o000O0O in I11I11 :
   if 65 - 65: iIii1I11I1II1 % oO0o0ooO0 + O0 / OoooooooOO
   try :
    if 52 - 52: o0oO0 % IIII * OOooOOo % O0oO + IIII / O0ooOooooO
    oo000o = o000O0O
    if 95 - 95: oO0o0ooO0 - iI * O0oO / OoOO / II111iiii + O0
   except :
    pass
    if 37 - 37: O0oO . Oooo0Ooo000 + IIII + O0oO . i1I111II1I / o0oO0
    if 29 - 29: i1I111II1I . iI - II111iiii
  iIIIiIi = OO0O0 ( oo000o )
  I11I11 = re . compile ( I1iII1iIi1I ) . findall ( iIIIiIi )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
    if 68 - 68: iIii1I11I1II1 + II111iiii / oO0o0ooO0
   except :
    pass
 except :
  pass
  if 91 - 91: OoOO0ooOOoo0O % iIii1I11I1II1 . OOooOOo
def O00ooooo00 ( ) :
 if 94 - 94: O0oO - II111iiii . OOooOOo - ii11ii1ii + o00O0oo * o00O0oo
 try :
  if 27 - 27: i1I111II1I * OOooOOo . iIii1I11I1II1 - iIii1I11I1II1
  iIIIiIi = OO0O0 ( db4 )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
  for o000O0O in I11I11 :
   if 5 - 5: i1I111II1I
   try :
    if 84 - 84: II111iiii * oO0o0ooO0 * II111iiii % i1I111II1I / OOooOOo
    O0Oooo = o000O0O
    if 27 - 27: iI + i11iIiiIii * O0oO + OoOO0ooOOoo0O + O0ooOooooO
   except :
    pass
    if 87 - 87: O0
  iIIIiIi = OO0O0 ( O0Oooo )
  I11I11 = re . compile ( I1iII1iIi1I ) . findall ( iIIIiIi )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
    if 87 - 87: o0000oOoOoO0o / II111iiii
   except :
    pass
 except :
  pass
  if 90 - 90: iI - o00O0oo - O0 + o0oO0
def O0o00oo0OO0 ( ) :
 if 60 - 60: iI
 try :
  if 66 - 66: O0oO / iI % i1IIi - oO0o0ooO0 . O0 / O0
  iIIIiIi = OO0O0 ( db5 )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
  for o000O0O in I11I11 :
   if 96 - 96: OoooooooOO + i1I111II1I * O0
   try :
    if 86 - 86: o0oO0
    IiII1i1iI = o000O0O
    if 84 - 84: i1I111II1I + o00O0oo + o0oO0 + O0ooOooooO
   except :
    pass
    if 62 - 62: i11iIiiIii + OoOO0ooOOoo0O + i1IIi
    if 69 - 69: OoOO0ooOOoo0O
  iIIIiIi = OO0O0 ( IiII1i1iI )
  I11I11 = re . compile ( I1iII1iIi1I ) . findall ( iIIIiIi )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
    if 63 - 63: OoOO / OoOO0ooOOoo0O * iIii1I11I1II1 . Oooo0Ooo000
   except :
    pass
 except :
  pass
  if 85 - 85: i11iIiiIii / i11iIiiIii . OoOO . O0
def OooOo ( ) :
 if 67 - 67: ii11ii1ii / O0
 try :
  if 88 - 88: OoOO0ooOOoo0O - IIII
  iIIIiIi = OO0O0 ( db6 )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
  for o000O0O in I11I11 :
   if 63 - 63: i1I111II1I * OoooooooOO
   try :
    if 19 - 19: i1I111II1I - o0000oOoOoO0o . iIii1I11I1II1 . OoOO0ooOOoo0O / IIII
    OOO0O00Oo = o000O0O
    if 13 - 13: iIii1I11I1II1
   except :
    pass
    if 2 - 2: i1IIi * oO0o0ooO0 - oO0o0ooO0 + OoooooooOO % OoOO0ooOOoo0O / OoOO0ooOOoo0O
    if 3 - 3: OoooooooOO
  iIIIiIi = OO0O0 ( OOO0O00Oo )
  I11I11 = re . compile ( I1iII1iIi1I ) . findall ( iIIIiIi )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
    if 71 - 71: i1I111II1I + i1IIi - O0ooOooooO - i11iIiiIii . O0oO - iI
   except :
    pass
 except :
  pass
  if 85 - 85: o00O0oo - OoOO0ooOOoo0O / o00O0oo + IIII - O0ooOooooO
def IIii1III ( ) :
 if 94 - 94: i11iIiiIii % OoooooooOO / OOooOOo
 try :
  if 24 - 24: OOooOOo * oO0o0ooO0
  iIIIiIi = OO0O0 ( db7 )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
  for o000O0O in I11I11 :
   if 85 - 85: II111iiii . iI % IIII % O0oO
   try :
    if 80 - 80: oO0o0ooO0 * O0oO / iIii1I11I1II1 % oO0o0ooO0 / iIii1I11I1II1
    Iiii1 = o000O0O
    if 36 - 36: O0ooOooooO
   except :
    pass
    if 90 - 90: O0
    if 44 - 44: i1IIi . OOooOOo / i11iIiiIii + i1I111II1I
  iIIIiIi = OO0O0 ( Iiii1 )
  I11I11 = re . compile ( I1iII1iIi1I ) . findall ( iIIIiIi )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
    if 27 - 27: IIII
   except :
    pass
 except :
  pass
  if 52 - 52: Oooo0Ooo000 % OoOO0ooOOoo0O + iIii1I11I1II1 * oO0o0ooO0 . o0oO0
def OoOooOO0oOOo0O ( ) :
 if 42 - 42: O0ooOooooO / o0000oOoOoO0o + ii11ii1ii . ii11ii1ii % IIII
 try :
  if 16 - 16: i1IIi + OoOO % OoOO0ooOOoo0O + o0oO0 * ii11ii1ii
  iIIIiIi = OO0O0 ( db27 )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
  for o000O0O in I11I11 :
   if 3 - 3: i11iIiiIii
   try :
    if 81 - 81: OOooOOo . OoooooooOO * o0oO0 . oO0o0ooO0 - O0 * oO0o0ooO0
    OoO0Oo00 = o000O0O
    if 1 - 1: Oooo0Ooo000 - O0oO
   except :
    pass
    if 45 - 45: o0oO0 - IIII
    if 70 - 70: OoOO % OOooOOo / OOooOOo . O0oO % iI . II111iiii
  iIIIiIi = OO0O0 ( OoO0Oo00 )
  I11I11 = re . compile ( I1iII1iIi1I ) . findall ( iIIIiIi )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
    if 10 - 10: o0oO0 - i11iIiiIii . o00O0oo % i1IIi
   except :
    pass
 except :
  pass
  if 78 - 78: iIii1I11I1II1 * ii11ii1ii . ii11ii1ii - IIII . iIii1I11I1II1
  if 30 - 30: iI + iI % i1I111II1I - o0000oOoOoO0o - o00O0oo
def i111IiiI1Ii ( ) :
 if 72 - 72: O0 . OoOO0ooOOoo0O * ii11ii1ii + o00O0oo - o0000oOoOoO0o
 try :
  if 40 - 40: OoOO + OoOO
  iIIIiIi = OO0O0 ( db8 )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
  for o000O0O in I11I11 :
   if 94 - 94: O0ooOooooO * iIii1I11I1II1 . O0oO
   try :
    if 13 - 13: iIii1I11I1II1 * OoOO0ooOOoo0O / Oooo0Ooo000 % iI + oO0o0ooO0
    iiiI1iI1 = o000O0O
    if 15 - 15: i1I111II1I . i1IIi * OoOO0ooOOoo0O % iIii1I11I1II1
   except :
    pass
    if 35 - 35: o00O0oo + Oooo0Ooo000 - OoOO0ooOOoo0O % oO0o0ooO0 % o0000oOoOoO0o % OoOO0ooOOoo0O
    if 45 - 45: OOooOOo * IIII % OoOO
  iIIIiIi = OO0O0 ( iiiI1iI1 )
  I11I11 = re . compile ( I1iII1iIi1I ) . findall ( iIIIiIi )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
    if 24 - 24: iI - O0oO * oO0o0ooO0
   except :
    pass
 except :
  pass
  if 87 - 87: o0oO0 - o00O0oo % o00O0oo . oO0o0ooO0 / o00O0oo
  if 6 - 6: OoOO0ooOOoo0O / iIii1I11I1II1 * OoooooooOO * i11iIiiIii
def o0O0OOo0oO ( ) :
 if 42 - 42: II111iiii / O0 . iIii1I11I1II1 / O0 / OoOO / OoooooooOO
 try :
  if 62 - 62: O0 . ii11ii1ii
  iIIIiIi = OO0O0 ( db9 )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
  for o000O0O in I11I11 :
   if 33 - 33: ii11ii1ii / iIii1I11I1II1 % i1IIi
   try :
    if 76 - 76: o0oO0 + iIii1I11I1II1 + OoOO0ooOOoo0O . OoOO
    i1i1 = o000O0O
    if 68 - 68: o0oO0 - OOooOOo
   except :
    pass
    if 41 - 41: oO0o0ooO0
    if 21 - 21: iI + o0000oOoOoO0o % Oooo0Ooo000 + i11iIiiIii + O0ooOooooO + II111iiii
  iIIIiIi = OO0O0 ( i1i1 )
  I11I11 = re . compile ( I1iII1iIi1I ) . findall ( iIIIiIi )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
    if 98 - 98: Oooo0Ooo000
   except :
    pass
    if 49 - 49: ii11ii1ii * oO0o0ooO0 + o0000oOoOoO0o - i11iIiiIii
 except :
  pass
  if 74 - 74: ii11ii1ii / iIii1I11I1II1 . II111iiii - OoOO
  if 62 - 62: IIII / II111iiii + OoOO0ooOOoo0O % iI / OoOO0ooOOoo0O + o00O0oo
def IiI11I111 ( ) :
 if 54 - 54: O0 - O0ooOooooO . IIII % O0ooOooooO + O0ooOooooO
 try :
  if 36 - 36: IIII % i11iIiiIii
  iIIIiIi = OO0O0 ( db10 )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
  for o000O0O in I11I11 :
   if 47 - 47: i1IIi + II111iiii . ii11ii1ii * oO0o0ooO0 . O0oO / i1IIi
   try :
    if 50 - 50: Oooo0Ooo000 / i1IIi % OoooooooOO
    oOOOOO0Ooooo = o000O0O
    if 57 - 57: o0oO0 - OoooooooOO
   except :
    pass
    if 68 - 68: o0000oOoOoO0o % o00O0oo / Oooo0Ooo000 + Oooo0Ooo000 - Oooo0Ooo000 . OoOO
    if 100 - 100: OoOO0ooOOoo0O % ii11ii1ii
  iIIIiIi = OO0O0 ( oOOOOO0Ooooo )
  I11I11 = re . compile ( I1iII1iIi1I ) . findall ( iIIIiIi )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
    if 76 - 76: II111iiii / OoOO + OoooooooOO . o00O0oo . O0oO . iI
   except :
    pass
    if 43 - 43: i1IIi
 except :
  pass
  if 17 - 17: O0 - OoOO0ooOOoo0O
def OOoooOoO0 ( ) :
 if 95 - 95: o0oO0 - o00O0oo - O0 . OOooOOo . O0ooOooooO
 try :
  if 7 - 7: Oooo0Ooo000
  iIIIiIi = OO0O0 ( db11 )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
  for o000O0O in I11I11 :
   if 45 - 45: O0 - IIII
   try :
    if 56 - 56: O0 + o0oO0
    IiI11II11 = o000O0O
    if 46 - 46: iIii1I11I1II1 / o00O0oo
   except :
    pass
    if 7 - 7: o00O0oo / II111iiii - O0oO + i1IIi + o0oO0
  iIIIiIi = OO0O0 ( IiI11II11 )
  I11I11 = re . compile ( I1iII1iIi1I ) . findall ( iIIIiIi )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
    if 7 - 7: iI + o0oO0
   except :
    pass
 except :
  pass
  if 32 - 32: iIii1I11I1II1 % OOooOOo / i11iIiiIii + IIII - o0000oOoOoO0o . O0ooOooooO
  if 86 - 86: i1IIi / o0oO0 * OOooOOo
def OOoO0OOoO0ooo ( ) :
 if 23 - 23: i1IIi - O0oO
 try :
  if 96 - 96: i1IIi % OoooooooOO
  iIIIiIi = OO0O0 ( db12 )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
  for o000O0O in I11I11 :
   if 99 - 99: i11iIiiIii . II111iiii . OoooooooOO
   try :
    if 59 - 59: i11iIiiIii . OoooooooOO / O0oO * o00O0oo + OoooooooOO
    Ii1I1i1ii1I1 = o000O0O
    if 98 - 98: i1I111II1I * iIii1I11I1II1 . o0oO0 * ii11ii1ii / o00O0oo + iI
   except :
    pass
    if 25 - 25: oO0o0ooO0
    if 19 - 19: OOooOOo % o0oO0 . i1I111II1I * iI
  iIIIiIi = OO0O0 ( Ii1I1i1ii1I1 )
  I11I11 = re . compile ( I1iII1iIi1I ) . findall ( iIIIiIi )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
    if 89 - 89: OoOO0ooOOoo0O . IIII
   except :
    pass
 except :
  pass
  if 7 - 7: oO0o0ooO0 % OoOO0ooOOoo0O - OOooOOo + ii11ii1ii
  if 70 - 70: II111iiii + Oooo0Ooo000 + i11iIiiIii - i1IIi / i1I111II1I
def iI1IIiiIIIII ( ) :
 if 43 - 43: O0ooOooooO + ii11ii1ii / OoooooooOO
 try :
  if 24 - 24: O0 + o0000oOoOoO0o * o0oO0 - Oooo0Ooo000
  iIIIiIi = OO0O0 ( db13 )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
  for o000O0O in I11I11 :
   if 10 - 10: i11iIiiIii
   try :
    if 21 - 21: OOooOOo / O0ooOooooO
    o00000oo00 = o000O0O
    if 41 - 41: IIII - o0000oOoOoO0o + o0oO0
   except :
    pass
  iIIIiIi = OO0O0 ( o00000oo00 )
  I11I11 = re . compile ( I1iII1iIi1I ) . findall ( iIIIiIi )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
    if 15 - 15: O0oO / o0000oOoOoO0o + o0oO0
   except :
    pass
 except :
  pass
  if 76 - 76: o0oO0 + OoooooooOO / IIII % OoOO / o00O0oo
def I1i ( ) :
 if 82 - 82: OoOO + OoOO % o0000oOoOoO0o % i11iIiiIii / Oooo0Ooo000 % OoooooooOO
 try :
  if 96 - 96: oO0o0ooO0 - oO0o0ooO0
  iIIIiIi = OO0O0 ( db14 )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
  for o000O0O in I11I11 :
   if 87 - 87: ii11ii1ii / OoooooooOO - o00O0oo . i1I111II1I + iIii1I11I1II1 . o00O0oo
   try :
    if 4 - 4: OoooooooOO + iI . i1IIi / O0 - O0
    oOooOOo00ooO = o000O0O
    if 71 - 71: Oooo0Ooo000 - o0000oOoOoO0o - IIII
   except :
    pass
    if 28 - 28: iIii1I11I1II1
    if 7 - 7: o0000oOoOoO0o % i1I111II1I * OoOO0ooOOoo0O
  iIIIiIi = OO0O0 ( oOooOOo00ooO )
  I11I11 = re . compile ( I1iII1iIi1I ) . findall ( iIIIiIi )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
    if 58 - 58: i1I111II1I / O0oO + II111iiii % O0ooOooooO - OoooooooOO
   except :
    pass
 except :
  pass
  if 25 - 25: OoOO0ooOOoo0O % OoooooooOO * ii11ii1ii - i1IIi * II111iiii * oO0o0ooO0
  if 30 - 30: O0oO % OoOO0ooOOoo0O / o00O0oo * O0 * o0oO0 . OOooOOo
def iIi11I11 ( ) :
 if 40 - 40: iIii1I11I1II1
 try :
  if 92 - 92: OoOO0ooOOoo0O % O0
  iIIIiIi = OO0O0 ( db15 )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
  for o000O0O in I11I11 :
   if 55 - 55: iIii1I11I1II1 * O0ooOooooO
   try :
    if 85 - 85: iIii1I11I1II1 . II111iiii
    o0ooo0o0 = o000O0O
    if 84 - 84: O0oO - ii11ii1ii * O0 / o0oO0 . o0oO0
   except :
    pass
    if 93 - 93: O0 / iI + OOooOOo
    if 20 - 20: i1I111II1I / O0ooOooooO % OoooooooOO / iIii1I11I1II1 + OOooOOo
  iIIIiIi = OO0O0 ( o0ooo0o0 )
  I11I11 = re . compile ( I1iII1iIi1I ) . findall ( iIIIiIi )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
    if 57 - 57: o0000oOoOoO0o / Oooo0Ooo000
   except :
    pass
 except :
  pass
  if 13 - 13: OoooooooOO + OoOO
def ii1IIii ( ) :
 if 31 - 31: iIii1I11I1II1 * iI - OoooooooOO * iI
 try :
  if 60 - 60: IIII % IIII * oO0o0ooO0 / OOooOOo * OoOO0ooOOoo0O * OOooOOo
  iIIIiIi = OO0O0 ( db16 )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
  for o000O0O in I11I11 :
   if 61 - 61: oO0o0ooO0 + o00O0oo / i1IIi * oO0o0ooO0
   try :
    if 90 - 90: o0oO0 % oO0o0ooO0
    iiii1 = o000O0O
    if 60 - 60: OOooOOo % oO0o0ooO0 / o0000oOoOoO0o % oO0o0ooO0 * i11iIiiIii / O0ooOooooO
   except :
    pass
    if 34 - 34: Oooo0Ooo000 - IIII
    if 25 - 25: oO0o0ooO0 % OOooOOo + i11iIiiIii + O0 * OoooooooOO
  iIIIiIi = OO0O0 ( iiii1 )
  I11I11 = re . compile ( I1iII1iIi1I ) . findall ( iIIIiIi )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
    if 64 - 64: i1IIi
   except :
    pass
 except :
  pass
  if 10 - 10: Oooo0Ooo000 % O0 / OOooOOo % O0oO
  if 25 - 25: II111iiii / OoOO
def oo0OoOO0000 ( ) :
 if 2 - 2: o0oO0 * o00O0oo * OoooooooOO
 try :
  if 73 - 73: OoOO0ooOOoo0O + ii11ii1ii
  iIIIiIi = OO0O0 ( db17 )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
  for o000O0O in I11I11 :
   if 61 - 61: iIii1I11I1II1
   try :
    if 47 - 47: OoooooooOO
    II111IIIII = o000O0O
    if 4 - 4: o00O0oo + OoOO / Oooo0Ooo000 / o0000oOoOoO0o % IIII + IIII
   except :
    pass
    if 66 - 66: i1IIi % O0ooOooooO . IIII - oO0o0ooO0 % OoOO0ooOOoo0O / IIII
    if 26 - 26: O0ooOooooO * o0oO0 . Oooo0Ooo000 - ii11ii1ii
  iIIIiIi = OO0O0 ( II111IIIII )
  I11I11 = re . compile ( I1iII1iIi1I ) . findall ( iIIIiIi )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
    if 59 - 59: OoooooooOO - O0ooOooooO + OOooOOo / IIII * OOooOOo + OoOO
   except :
    pass
 except :
  pass
  if 88 - 88: oO0o0ooO0 . OOooOOo % O0oO . ii11ii1ii * OOooOOo
  if 99 - 99: O0 . o0000oOoOoO0o % O0oO - ii11ii1ii / O0oO
def iI1iii1i1III1 ( ) :
 if 17 - 17: II111iiii + OOooOOo
 try :
  if 59 - 59: iIii1I11I1II1 % o0oO0 . i11iIiiIii
  iIIIiIi = OO0O0 ( db18 )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
  for o000O0O in I11I11 :
   if 59 - 59: o0000oOoOoO0o . oO0o0ooO0 . o0oO0 * OoOO0ooOOoo0O * OoOO + ii11ii1ii
   try :
    if 90 - 90: Oooo0Ooo000 % ii11ii1ii - ii11ii1ii . iIii1I11I1II1 / IIII + O0oO
    o0o00OOOO = o000O0O
    if 42 - 42: iI * O0ooOooooO
   except :
    pass
    if 2 - 2: O0ooOooooO . OoOO / oO0o0ooO0
    if 41 - 41: OoOO . Oooo0Ooo000 * i1I111II1I * Oooo0Ooo000
  iIIIiIi = OO0O0 ( o0o00OOOO )
  I11I11 = re . compile ( I1iII1iIi1I ) . findall ( iIIIiIi )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
    if 74 - 74: iIii1I11I1II1 / o0000oOoOoO0o
   except :
    pass
 except :
  pass
  if 58 - 58: iIii1I11I1II1 - OOooOOo % o0000oOoOoO0o % OoooooooOO * iIii1I11I1II1 + IIII
  if 25 - 25: IIII % O0
def I11oO0oo ( ) :
 if 54 - 54: IIII . Oooo0Ooo000 * oO0o0ooO0 % ii11ii1ii - O0oO
 try :
  if 74 - 74: o00O0oo - O0ooOooooO * i1IIi
  iIIIiIi = OO0O0 ( db19 )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
  for o000O0O in I11I11 :
   if 12 - 12: O0
   try :
    if 75 - 75: iIii1I11I1II1 % i1I111II1I + o00O0oo * O0 . O0ooOooooO - iI
    i1IIiIIIi1 = o000O0O
    if 84 - 84: oO0o0ooO0 + IIII . O0ooOooooO
   except :
    pass
    if 71 - 71: iI / iI . OoOO0ooOOoo0O % O0ooOooooO
    if 50 - 50: iI + O0ooOooooO / O0oO / O0oO % O0
  iIIIiIi = OO0O0 ( i1IIiIIIi1 )
  I11I11 = re . compile ( I1iII1iIi1I ) . findall ( iIIIiIi )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
    if 87 - 87: ii11ii1ii + iI
   except :
    pass
 except :
  pass
  if 66 - 66: o0000oOoOoO0o * IIII + o0oO0 * o0000oOoOoO0o + IIII / OoooooooOO
  if 86 - 86: o0oO0 . O0ooOooooO - O0ooOooooO
def oo0i11i ( ) :
 if 73 - 73: iI % iI . O0ooOooooO + Oooo0Ooo000
 try :
  if 10 - 10: O0 / IIII * iI - OoOO - i1IIi . OoOO0ooOOoo0O
  iIIIiIi = OO0O0 ( db20 )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
  for o000O0O in I11I11 :
   if 69 - 69: ii11ii1ii - o0oO0 % o0oO0 - IIII * IIII / ii11ii1ii
   try :
    if 13 - 13: OoOO0ooOOoo0O
    OOo0oOOOOoo0 = o000O0O
    if 80 - 80: i11iIiiIii % o00O0oo
   except :
    pass
    if 54 - 54: o0000oOoOoO0o + O0oO - iIii1I11I1II1 % iI % i1I111II1I
  iIIIiIi = OO0O0 ( OOo0oOOOOoo0 )
  I11I11 = re . compile ( I1iII1iIi1I ) . findall ( iIIIiIi )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
    if 19 - 19: o00O0oo / iIii1I11I1II1 % i1IIi . OoooooooOO
   except :
    pass
 except :
  pass
  if 57 - 57: iI . ii11ii1ii - OoOO - i11iIiiIii * Oooo0Ooo000 / o0000oOoOoO0o
  if 79 - 79: o00O0oo + o0000oOoOoO0o % ii11ii1ii * o0000oOoOoO0o
def iiii11IiIiI ( ) :
 if 8 - 8: Oooo0Ooo000 + OoOO
 try :
  if 9 - 9: IIII + o0000oOoOoO0o
  iIIIiIi = OO0O0 ( db21 )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
  for o000O0O in I11I11 :
   if 8 - 8: IIII * ii11ii1ii / O0ooOooooO - OoOO - OoooooooOO
   try :
    if 100 - 100: oO0o0ooO0 . iIii1I11I1II1 . iIii1I11I1II1
    oOOo0ooO0 = o000O0O
    if 38 - 38: Oooo0Ooo000
   except :
    pass
    if 18 - 18: O0ooOooooO / o0000oOoOoO0o + i1I111II1I % oO0o0ooO0 - i1I111II1I
    if 18 - 18: OOooOOo + iI % o00O0oo - OoOO0ooOOoo0O * i11iIiiIii . o0000oOoOoO0o
  iIIIiIi = OO0O0 ( oOOo0ooO0 )
  I11I11 = re . compile ( I1iII1iIi1I ) . findall ( iIIIiIi )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
    if 16 - 16: ii11ii1ii
   except :
    pass
 except :
  pass
  if 74 - 74: O0oO
def OO0oOoO000o0 ( ) :
 if 95 - 95: O0 / O0oO . Oooo0Ooo000
 try :
  if 17 - 17: O0oO
  iIIIiIi = OO0O0 ( db22 )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
  for o000O0O in I11I11 :
   if 56 - 56: iI * o0000oOoOoO0o + O0oO
   try :
    if 48 - 48: i1I111II1I * OoOO % Oooo0Ooo000 - O0oO
    Oo0000OOO0 = o000O0O
    if 68 - 68: i1IIi - O0ooOooooO . iI - ii11ii1ii + iIii1I11I1II1 + Oooo0Ooo000
   except :
    pass
  iIIIiIi = OO0O0 ( Oo0000OOO0 )
  I11I11 = re . compile ( I1iII1iIi1I ) . findall ( iIIIiIi )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
    if 25 - 25: iIii1I11I1II1 % II111iiii / O0oO / o00O0oo
   except :
    pass
 except :
  pass
  if 22 - 22: oO0o0ooO0 * O0ooOooooO
def iIIIiIi1i ( ) :
 if 36 - 36: OoOO0ooOOoo0O
 try :
  if 9 - 9: iIii1I11I1II1 . OoooooooOO + i1IIi - ii11ii1ii
  iIIIiIi = OO0O0 ( db23 )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
  for o000O0O in I11I11 :
   if 30 - 30: O0ooOooooO / OoOO . O0ooOooooO
   try :
    if 17 - 17: ii11ii1ii + OoooooooOO * OoooooooOO
    i1iiIIiII1 = o000O0O
    if 72 - 72: i1I111II1I % o0000oOoOoO0o
   except :
    pass
  iIIIiIi = OO0O0 ( i1iiIIiII1 )
  I11I11 = re . compile ( I1iII1iIi1I ) . findall ( iIIIiIi )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
    if 93 - 93: iIii1I11I1II1 + i11iIiiIii . o0000oOoOoO0o . i1IIi % OOooOOo % iI
   except :
    pass
 except :
  pass
  if 74 - 74: OoOO0ooOOoo0O / i1IIi % OoooooooOO
def o00o0o000Oo ( ) :
 if 100 - 100: i1IIi - i11iIiiIii . Oooo0Ooo000 * OoOO
 try :
  if 62 - 62: O0
  iIIIiIi = OO0O0 ( db25 )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
  for o000O0O in I11I11 :
   if 41 - 41: i1IIi - OOooOOo
   try :
    if 48 - 48: OOooOOo - II111iiii / OoOO + OOooOOo
    i1iii1IiiiI1i1 = o000O0O
    if 37 - 37: ii11ii1ii - i1IIi - i1I111II1I + O0oO . iIii1I11I1II1
   except :
    pass
  iIIIiIi = OO0O0 ( i1iii1IiiiI1i1 )
  I11I11 = re . compile ( I1iII1iIi1I ) . findall ( iIIIiIi )
  for oooO , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 in I11I11 :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , oooO , id , i1i1iI1iiiI , Ooo0oOooo0 , oo00 )
    if 59 - 59: OoooooooOO - Oooo0Ooo000 % o0000oOoOoO0o . O0oO + i1IIi * O0oO
   except :
    pass
 except :
  pass
  if 5 - 5: II111iiii - i1I111II1I
def O0O00oO0OoO0o ( ) :
 if 5 - 5: IIII % ii11ii1ii % i1I111II1I % iI
 try :
  if 17 - 17: o0oO0 + II111iiii + OoooooooOO / IIII / i1I111II1I
  iIIIiIi = OO0O0 ( db24 )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
  for o000O0O in I11I11 :
   if 80 - 80: o0000oOoOoO0o % i1IIi / O0oO
   try :
    if 56 - 56: i1IIi . i11iIiiIii
    Ii1Ii1IiIIIi1 = o000O0O
    if 55 - 55: oO0o0ooO0 + O0 / O0ooOooooO % iI / OoooooooOO
   except :
    pass
  iIIIiIi = OO0O0 ( Ii1Ii1IiIIIi1 )
  I11I11 = re . compile ( o0O ) . findall ( iIIIiIi )
  for oooO , i1I1i111Ii , ooo in I11I11 :
   try :
    O00o0OO0OO0oo ( oooO , i1I1i111Ii , ooo )
    if 59 - 59: OoooooooOO % O0oO / Oooo0Ooo000 + OoooooooOO . OoooooooOO
   except :
    pass
    if 87 - 87: O0oO + oO0o0ooO0
 except :
  pass
  if 3 - 3: OoooooooOO
  if 40 - 40: O0 . Oooo0Ooo000 / iIii1I11I1II1 * o0000oOoOoO0o
  if 73 - 73: ii11ii1ii - O0ooOooooO . oO0o0ooO0 % i1IIi . O0
def O00o0OO0OO0oo ( thumb , name , url ) :
 if 15 - 15: iI . iIii1I11I1II1 * OOooOOo % O0oO
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 if 21 - 21: OoOO - OOooOOo . OoooooooOO
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   II1IIIIiII1i ( name , url , '' , o00 , oo00 )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 6 - 6: iIii1I11I1II1 - iIii1I11I1II1 % o0000oOoOoO0o / iIii1I11I1II1 * Oooo0Ooo000
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 3 - 3: IIII . i1I111II1I / ii11ii1ii
   OooIIi111 ( name , url , 4 , OoOo000oOo0oo , oo00 )
   if 61 - 61: o00O0oo - IIII
  else :
   if 16 - 16: O0ooOooooO / iIii1I11I1II1 + IIII * O0ooOooooO * O0oO
   OooIIi111 ( name , url , 4 , OoOo000oOo0oo , oo00 )
   if 8 - 8: Oooo0Ooo000
def II11I ( name , url , thumb , id , trailer ) :
 if 7 - 7: II111iiii * iI . ii11ii1ii / OOooOOo
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 43 - 43: o0oO0 + O0ooOooooO + i1IIi - OoOO0ooOOoo0O + o0000oOoOoO0o
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   II1IIIIiII1i ( name , url , '' , o00 , oo00 )
 else :
  O00OOOoOoo0O = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
  if 54 - 54: o00O0oo + o00O0oo + O0oO % i1IIi % i11iIiiIii
  name = '[COLOR %s]' % O00OOOoOoo0O + name + '[/COLOR]'
  if 100 - 100: o00O0oo
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   III1iII1I1ii = IiII1IiiIiI1 . getSetting ( 'selecton' )
   if III1iII1I1ii == 'true' :
    if 96 - 96: OOooOOo . i1I111II1I * II111iiii % i1I111II1I . Oooo0Ooo000 * i1IIi
    o00iI1Ii11iIiiI1 ( name , url , 1 , thumb , thumb , id , trailer )
    if 15 - 15: O0oO % IIII
   else :
    if 30 - 30: o0oO0 + II111iiii % OoooooooOO
    o00iI1Ii11iIiiI1 ( name , url , 130 , thumb , thumb , id , trailer )
    if 89 - 89: o0oO0
  else :
   if 51 - 51: O0ooOooooO
   if III1iII1I1ii == 'true' :
    if 68 - 68: O0ooOooooO - o0000oOoOoO0o * OoOO % iI . iI - iIii1I11I1II1
    o00iI1Ii11iIiiI1 ( name , url , 1 , thumb , thumb , id , trailer )
    if 22 - 22: OoooooooOO / o00O0oo % O0ooOooooO * OoOO0ooOOoo0O
   else :
    if 32 - 32: OoooooooOO % oO0o0ooO0 % iIii1I11I1II1 / O0
    o00iI1Ii11iIiiI1 ( name , url , 130 , thumb , thumb , id , trailer )
    if 61 - 61: II111iiii . O0 - o0oO0 - o00O0oo / i11iIiiIii - II111iiii
def o0OOOoO0 ( name , url , thumb , id , trailer , description , fanart ) :
 if 98 - 98: o0oO0 - OOooOOo . i11iIiiIii * ii11ii1ii
 if 29 - 29: o0oO0 / iI % O0oO
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . strip ( )
 O00OOOoOoo0O = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
 fanart = fanart . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 name = '[COLOR %s]' % O00OOOoOoo0O + name + '[/COLOR]'
 if 10 - 10: iIii1I11I1II1 % OoooooooOO % o00O0oo
 if 39 - 39: II111iiii * OoOO0ooOOoo0O . O0 * O0oO
 if 'tvg-logo' in thumb :
  thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  if III1iII1I1ii == 'true' :
   O0o0O0O0O ( name , url , 1 , thumb , fanart , id , trailer , description )
  else :
   if 79 - 79: i1I111II1I + i1I111II1I + o0oO0
   O0o0O0O0O ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 39 - 39: O0 - OoooooooOO
 else :
  if 63 - 63: iIii1I11I1II1 % o0000oOoOoO0o * iI
  if III1iII1I1ii == 'true' :
   if 79 - 79: O0
   O0o0O0O0O ( name , url , 1 , thumb , fanart , id , trailer , description )
   if 32 - 32: II111iiii . O0 + o0oO0 / OoOO0ooOOoo0O / i1I111II1I / IIII
  else :
   if 15 - 15: o00O0oo
   O0o0O0O0O ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 4 - 4: i1I111II1I + iIii1I11I1II1 * O0ooOooooO + ii11ii1ii * o0000oOoOoO0o % II111iiii
   if 88 - 88: oO0o0ooO0 - i1IIi % i11iIiiIii % II111iiii * OoooooooOO
def iIiII1 ( name , trailer ) :
 if 47 - 47: O0oO
 if O0ii1ii1ii == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Realstream, Reproduciendo Trailer de: [COLOR green]" + name + "[/COLOR] ,5000)" )
  if 92 - 92: OoooooooOO % OOooOOo / OoOO0ooOOoo0O * OoOO0ooOOoo0O % i11iIiiIii / OoooooooOO
  ooo = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  IiII1 = ooo
  ii111iI = xbmcgui . ListItem ( name , trailer , path = IiII1 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ii111iI )
 else :
  ooo = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  IiII1 = ooo
  ii111iI = xbmcgui . ListItem ( name , trailer , path = IiII1 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ii111iI )
  if 9 - 9: OoOO
  if 30 - 30: o0000oOoOoO0o * II111iiii % O0 % OOooOOo * o0oO0
def oOo ( name , url ) :
 if 17 - 17: OoOO0ooOOoo0O + OoooooooOO % IIII
 if O0ii1ii1ii == 'true' :
  if 36 - 36: i11iIiiIii + o00O0oo % IIII . OOooOOo - iI
  try :
   if 94 - 94: OOooOOo % OoOO0ooOOoo0O . i1I111II1I . iI . OoOO
   Oo0O0 = xbmcgui . DialogProgress ( )
   Oo0O0 . create ( 'Realstream:' , 'Iniciando ...' )
   Oo0O0 . update ( 30 , 'Realstream:' , 'Conectando al servidor ...' )
   xbmc . sleep ( 1000 )
   Oo0O0 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   Oo0O0 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   Oo0O0 . close ( )
   if 53 - 53: OoOO0ooOOoo0O
   IiII1 = url
   ii111iI = xbmcgui . ListItem ( name , path = IiII1 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ii111iI )
   if 84 - 84: OoOO
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. ,3000)" )
  if 97 - 97: i1IIi
 else :
  if 98 - 98: OoooooooOO - OOooOOo + iI
  try :
   if 98 - 98: O0ooOooooO . i1I111II1I . i1I111II1I - IIII
   Oo0O0 = xbmcgui . DialogProgress ( )
   Oo0O0 . create ( 'Realstream:' , 'Iniciando ...' )
   Oo0O0 . update ( 30 , 'Realstream:' , 'Conectando al servidor ...' )
   xbmc . sleep ( 1000 )
   Oo0O0 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   Oo0O0 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   Oo0O0 . close ( )
   if 65 - 65: ii11ii1ii + o0000oOoOoO0o - o0oO0
   IiII1 = url
   ii111iI = xbmcgui . ListItem ( name , path = IiII1 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ii111iI )
   if 12 - 12: OoooooooOO + o00O0oo
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. ,3000)" )
  if 55 - 55: IIII * II111iiii + oO0o0ooO0
 return
 if 93 - 93: O0ooOooooO * oO0o0ooO0 . OoOO - o0oO0 + O0 * OoOO
 if 59 - 59: II111iiii
def iIiIi11I1iIii1i11 ( trailer ) :
 if 42 - 42: OoOO * i11iIiiIii
 if 'https://www.youtube.com' in trailer :
  if 16 - 16: O0ooOooooO % OOooOOo - iI
  try :
   if 100 - 100: OoooooooOO * oO0o0ooO0
   import resolveurl
   if 83 - 83: iIii1I11I1II1 - iI - Oooo0Ooo000 / OoOO - O0
   iIIi1iI1I1IIi = resolveurl . HostedMediaFile ( ooo )
   Oo0O0 = xbmcgui . DialogProgress ( )
   Oo0O0 . create ( 'Realstream:' , 'Conectando al servidor ... ' )
   Oo0O0 . update ( 20 , 'Por favor, espere ...' )
   xbmc . sleep ( 500 )
   if 81 - 81: o0oO0 - oO0o0ooO0 * o00O0oo / Oooo0Ooo000
   if not iIIi1iI1I1IIi :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    return False
    if 21 - 21: OoOO
   try :
    if 63 - 63: O0oO . O0 * O0oO + iIii1I11I1II1
    Oo0O0 . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    I1iI = iIIi1iI1I1IIi . resolve ( )
    if not I1iI or not isinstance ( I1iI , basestring ) :
     try : O0o00O0Oo0 = I1iI . msg
     except : O0o00O0Oo0 = I1iI
     raise Exception ( O0o00O0Oo0 )
   except Exception as oOoO0 :
    try : O0o00O0Oo0 = str ( oOoO0 )
    except : O0o00O0Oo0 = I1iI
    Oo0O0 . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
    Oo0O0 . close ( )
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    if 46 - 46: i1IIi + II111iiii * i1IIi - o0oO0
   Oo0O0 . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
   xbmc . sleep ( 500 )
   Oo0O0 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   Oo0O0 . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
   xbmc . sleep ( 500 )
   Oo0O0 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   Oo0O0 . close ( )
   if 79 - 79: II111iiii - oO0o0ooO0 * o00O0oo - OoOO0ooOOoo0O . o00O0oo
   O0iI = xbmcgui . ListItem ( path = I1iI )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0iI )
   if 11 - 11: O0 * OoOO0ooOOoo0O
  except :
   pass
   if 37 - 37: OoOO0ooOOoo0O + O0 . O0 * ii11ii1ii % Oooo0Ooo000 / O0ooOooooO
  else :
   if 18 - 18: OoooooooOO
   ooo = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
   IiII1 = ooo
   ii111iI = xbmcgui . ListItem ( trailer , path = IiII1 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ii111iI )
   return
   if 57 - 57: iI . OoOO0ooOOoo0O * o0000oOoOoO0o - OoooooooOO
def OooO ( name , url ) :
 if 16 - 16: i1IIi . i1IIi / Oooo0Ooo000 % OoOO0ooOOoo0O / OOooOOo * o00O0oo
 if '[Youtube]' in name :
  if 30 - 30: o0000oOoOoO0o + OoooooooOO + IIII / II111iiii * ii11ii1ii
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  IiII1 = url
  ii111iI = xbmcgui . ListItem ( i1i1iI1iiiI , path = IiII1 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ii111iI )
  if 59 - 59: o0oO0 / OoOO0ooOOoo0O * OoOO * O0ooOooooO % oO0o0ooO0
  if 61 - 61: ii11ii1ii - O0 - OoooooooOO
 else :
  if 4 - 4: II111iiii - oO0o0ooO0 % ii11ii1ii * i11iIiiIii
  import resolveurl
  if 18 - 18: ii11ii1ii % O0
  iIIi1iI1I1IIi = resolveurl . HostedMediaFile ( url )
  if 66 - 66: iIii1I11I1II1 % i11iIiiIii / OOooOOo
  if not iIIi1iI1I1IIi :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 47 - 47: o00O0oo * oO0o0ooO0 + iIii1I11I1II1 - oO0o0ooO0 / i1I111II1I
   if 86 - 86: i1I111II1I
  try :
   I1iI = iIIi1iI1I1IIi . resolve ( )
   if not I1iI or not isinstance ( I1iI , basestring ) :
    try : O0o00O0Oo0 = I1iI . msg
    except : O0o00O0Oo0 = url
    raise Exception ( O0o00O0Oo0 )
  except Exception as oOoO0 :
   try : O0o00O0Oo0 = str ( oOoO0 )
   except : O0o00O0Oo0 = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 43 - 43: OOooOOo / O0ooOooooO / iI + iIii1I11I1II1 + OoooooooOO
  O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if O0ii1ii1ii == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  O0iI = xbmcgui . ListItem ( path = I1iI )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0iI )
  if 33 - 33: II111iiii - i1I111II1I - iI
  if 92 - 92: OoOO * i1I111II1I
 return
 if 92 - 92: oO0o0ooO0
def i1i1IIiII1I ( name , url ) :
 if 85 - 85: ii11ii1ii . i11iIiiIii - i11iIiiIii . OOooOOo . OoOO % OoooooooOO
 IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 o00O0 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 oOO0O00Oo0O0o = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( '\x62\x61\x73\x65\x36\x34' )
 O00ooOo = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 iIIIiIi = OO0O0 ( oOO0O00Oo0O0o )
 I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
 for oOO0o00O in I11I11 :
  if 20 - 20: Oooo0Ooo000 + Oooo0Ooo000 * II111iiii * iIii1I11I1II1 % O0 * OOooOOo
  try :
   if 62 - 62: OoooooooOO / OoOO0ooOOoo0O . i1I111II1I . i1I111II1I % iI
   if 42 - 42: o0000oOoOoO0o . IIII - iI
   IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 33 - 33: II111iiii / O0 / i1I111II1I - O0oO - i1IIi
   if 8 - 8: i11iIiiIii . O0ooOooooO / iIii1I11I1II1 / o00O0oo / i1I111II1I - o0oO0
   if IIIi1I1IIii1II == oOO0o00O :
    if 32 - 32: o0000oOoOoO0o . i1IIi * ii11ii1ii
    if 98 - 98: o0oO0 - II111iiii / OOooOOo . oO0o0ooO0 * i1I111II1I . O0oO
    if 'https://team.com' in url :
     if 25 - 25: i11iIiiIii / OoOO0ooOOoo0O - Oooo0Ooo000 / OoOO . o0000oOoOoO0o . o0000oOoOoO0o
     url = url . replace ( 'https://team.com' , 'https://verystream.com' )
     if 6 - 6: oO0o0ooO0 . O0oO
    if 'https://mybox.com' in url :
     if 43 - 43: o00O0oo + o0000oOoOoO0o
     url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
     if 50 - 50: oO0o0ooO0 % i1IIi * O0
     if 4 - 4: iIii1I11I1II1 . i1IIi
    if 'https://vidcloud.co/' in url :
     if 63 - 63: iIii1I11I1II1 + i1I111II1I % i1IIi / OOooOOo % II111iiii
     url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
     if 60 - 60: o0000oOoOoO0o . OoOO0ooOOoo0O % Oooo0Ooo000 / OOooOOo / O0
    if 'https://gounlimited.to' in url :
     if 19 - 19: i11iIiiIii . OOooOOo + II111iiii / IIII . o00O0oo * iI
     url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
     if 59 - 59: iIii1I11I1II1 / o00O0oo % iI
    if 'https://drive.com' in url :
     if 84 - 84: iIii1I11I1II1 / OOooOOo . OoOO0ooOOoo0O % O0oO
     url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
     if 99 - 99: ii11ii1ii + i11iIiiIii
     if 36 - 36: o0oO0 * Oooo0Ooo000 * iIii1I11I1II1 - O0oO % i11iIiiIii
    import resolveurl
    if 98 - 98: iIii1I11I1II1 - i1IIi + iI % O0oO + iI / oO0o0ooO0
    iIIi1iI1I1IIi = resolveurl . HostedMediaFile ( url )
    if 97 - 97: i1I111II1I % iI + II111iiii - i1I111II1I % OoOO + iI
    if 31 - 31: o0000oOoOoO0o
    if not iIIi1iI1I1IIi :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
     return False
     if 35 - 35: OoOO0ooOOoo0O + o0oO0 * iI / OoOO0ooOOoo0O
    try :
     if 69 - 69: iI . IIII - OOooOOo
     Oo0O0 = xbmcgui . DialogProgress ( )
     Oo0O0 . create ( 'Realstream:' , 'Iniciando ...' )
     Oo0O0 . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
     if 29 - 29: i11iIiiIii . o00O0oo / OOooOOo . IIII + i11iIiiIii
     for i1I1i in [ 1 , 2 , 3 , 4 , 5 ] :
      if 9 - 9: OoooooooOO * o00O0oo
      if 9 - 9: ii11ii1ii + O0ooOooooO
      Oo0O0 . update ( 35 , 'RESOLVEURL:' , 'Conectando al servidor ... ' )
      xbmc . sleep ( 300 )
      Oo0O0 . close ( )
      if 64 - 64: O0 * OOooOOo / OOooOOo
      break
      if 57 - 57: o00O0oo / OoooooooOO % o00O0oo . O0 / o00O0oo
      if 63 - 63: i1I111II1I + iIii1I11I1II1 + OOooOOo + Oooo0Ooo000
     I1iI = iIIi1iI1I1IIi . resolve ( )
     if not I1iI or not isinstance ( I1iI , basestring ) :
      if 72 - 72: OoOO + i11iIiiIii + o00O0oo
      try : O0o00O0Oo0 = I1iI . msg
      except : O0o00O0Oo0 = url
      raise Exception ( O0o00O0Oo0 )
      if 96 - 96: oO0o0ooO0 % i1IIi / o0000oOoOoO0o
    except Exception as oOoO0 :
     try : O0o00O0Oo0 = str ( oOoO0 )
     if 13 - 13: II111iiii - ii11ii1ii % i11iIiiIii + O0ooOooooO
     except : O0o00O0Oo0 = url
     if 88 - 88: O0 . oO0o0ooO0 % OOooOOo
     if 10 - 10: OOooOOo + O0
     if Oo0O0 . iscanceled ( ) :
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Cancelando !! , 2000)" )
      Oo0O0 . close ( )
      if 75 - 75: O0 % iIii1I11I1II1 / OoOO0ooOOoo0O % IIII / i1I111II1I
      if 31 - 31: i11iIiiIii * OoOO0ooOOoo0O
      if 69 - 69: i11iIiiIii
    Oo0O0 . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    Oo0O0 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
    xbmc . sleep ( 500 )
    Oo0O0 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
    Oo0O0 . close ( )
    O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
    O0iI = xbmcgui . ListItem ( path = I1iI )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0iI )
    if 61 - 61: O0
    if 21 - 21: OoOO % iIii1I11I1II1 . OoOO
   else :
    if 99 - 99: o0000oOoOoO0o * IIII % oO0o0ooO0 * oO0o0ooO0 + OoooooooOO
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold] El addon no ha podido conectar al servidor.[/COLOR]" )
    return False
    if 82 - 82: O0oO / OoOO0ooOOoo0O - IIII / iI
  except :
   pass
   if 50 - 50: IIII + OoOO . i11iIiiIii + o00O0oo + i11iIiiIii
def IIi11I1i1I1I ( ) :
 if 35 - 35: O0 + ii11ii1ii - OOooOOo % o0oO0 % II111iiii
 o0OOOO = [ ]
 OOoo0OOOo0o = sys . argv [ 2 ]
 if len ( OOoo0OOOo0o ) >= 2 :
  iI1111i1i11Ii = sys . argv [ 2 ]
  oo0O00o0O0Oo = iI1111i1i11Ii . replace ( '?' , '' )
  if ( iI1111i1i11Ii [ len ( iI1111i1i11Ii ) - 1 ] == '/' ) :
   iI1111i1i11Ii = iI1111i1i11Ii [ 0 : len ( iI1111i1i11Ii ) - 2 ]
  iii11I1i11IIIi = oo0O00o0O0Oo . split ( '&' )
  o0OOOO = { }
  for i1I1i in range ( len ( iii11I1i11IIIi ) ) :
   III1IIIIIiiI = { }
   III1IIIIIiiI = iii11I1i11IIIi [ i1I1i ] . split ( '=' )
   if ( len ( III1IIIIIiiI ) ) == 2 :
    o0OOOO [ III1IIIIIiiI [ 0 ] ] = III1IIIIIiiI [ 1 ]
 return o0OOOO
 if 38 - 38: O0
 if 79 - 79: i1IIi . oO0o0ooO0
def i1i1i11iI11II ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  pass
  if 6 - 6: OoOO0ooOOoo0O . II111iiii * OOooOOo . OOooOOo / o0oO0
def I1I1ii1111 ( ) :
 iii11 = xbmcgui . Dialog ( )
 list = (
 IIIiI1iiiIIIi ,
 OoO000Oo00
 )
 if 43 - 43: OoOO . iI * ii11ii1ii
 iio00O0o00oo = iii11 . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=%s]Accede a themoviedb.com[/COLOR]' % iIIIi1 ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 19 - 19: OOooOOo
 if iio00O0o00oo :
  if 66 - 66: oO0o0ooO0 / OoOO0ooOOoo0O
  if iio00O0o00oo < 0 :
   return
  iII1I = list [ iio00O0o00oo - 2 ]
  return iII1I ( )
 else :
  iII1I = list [ iio00O0o00oo ]
  return iII1I ( )
 return
 if 92 - 92: Oooo0Ooo000 % o0oO0
def Ii1Ii11I ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 28 - 28: iI . i1IIi
o0o00O = Ii1Ii11I ( )
if 46 - 46: OoOO0ooOOoo0O
def IIIiI1iiiIIIi ( ) :
 if o0o00O == 'android' :
  Ii1iiIi1I11i = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  Ii1iiIi1I11i = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 4 - 4: O0ooOooooO + O0
  if 28 - 28: i1I111II1I + i11iIiiIii + OoooooooOO / OoOO
def OoO000Oo00 ( ) :
 if 6 - 6: OOooOOo - i11iIiiIii
 main ( )
 if 61 - 61: Oooo0Ooo000 * o00O0oo % OOooOOo % OoOO % O0oO + O0oO
 if 6 - 6: ii11ii1ii
 if 73 - 73: Oooo0Ooo000 * o00O0oo + o0000oOoOoO0o - ii11ii1ii . O0oO
def o0oOOO ( ) :
 iii11 = xbmcgui . Dialog ( )
 o00OoOooo = (
 i1I1ii1 ,
 Iii1i
 )
 if 87 - 87: oO0o0ooO0
 iio00O0o00oo = iii11 . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 15 - 15: iIii1I11I1II1 . IIII . o00O0oo * i11iIiiIii
 if iio00O0o00oo :
  if 72 - 72: O0oO
  if iio00O0o00oo < 0 :
   return
  iII1I = o00OoOooo [ iio00O0o00oo - 2 ]
  return iII1I ( )
 else :
  iII1I = o00OoOooo [ iio00O0o00oo ]
  return iII1I ( )
 return
 if 26 - 26: i1I111II1I % ii11ii1ii
def Ii1Ii11I ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 72 - 72: O0 + o0000oOoOoO0o + OOooOOo / ii11ii1ii
o0o00O = Ii1Ii11I ( )
if 83 - 83: i1I111II1I - OOooOOo . o0oO0
def i1I1ii1 ( ) :
 if o0o00O == 'android' :
  Ii1iiIi1I11i = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  Ii1iiIi1I11i = webbrowser . open ( 'https://olpair.com/' )
  if 34 - 34: OoOO0ooOOoo0O - oO0o0ooO0 * OoooooooOO
  if 5 - 5: i11iIiiIii * O0ooOooooO - o0oO0 - o00O0oo - i1IIi + O0ooOooooO
def Iii1i ( ) :
 if 4 - 4: iI + O0 . i1IIi * o00O0oo - o0000oOoOoO0o
 main ( )
 if 42 - 42: o0000oOoOoO0o * OoOO0ooOOoo0O . OoOO - O0ooOooooO / II111iiii
 if 25 - 25: ii11ii1ii % OoOO0ooOOoo0O
def o00O ( name , url , id , trailer ) :
 iii11 = xbmcgui . Dialog ( )
 o00OoOooo = (
 IIIIII1iI1II ,
 iiiI1 ,
 O00oooO00oo ,
 I1I1ii1111 ,
 Ii111III1i11I
 )
 if 62 - 62: O0oO . OoOO + OoOO + II111iiii * iIii1I11I1II1 + OoooooooOO
 iio00O0o00oo = iii11 . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % iIIIi1 ,

 '[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % iIIIi1 ,

 '[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % iIIIi1 ,

 '[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % iIIIi1 ,

 '[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % iIIIi1 ] )
 if 77 - 77: O0 * o00O0oo * oO0o0ooO0 + OoOO + o00O0oo - Oooo0Ooo000
 if iio00O0o00oo :
  if 10 - 10: o00O0oo + i1I111II1I
  if iio00O0o00oo < 0 :
   return
  iII1I = o00OoOooo [ iio00O0o00oo - 5 ]
  return iII1I ( )
 else :
  iII1I = o00OoOooo [ iio00O0o00oo ]
  return iII1I ( )
 return
 if 58 - 58: OOooOOo + OoooooooOO / O0ooOooooO . iI % o0000oOoOoO0o / o00O0oo
 if 62 - 62: II111iiii
 if 12 - 12: i1I111II1I + II111iiii
def IIIIII1iI1II ( ) :
 if 92 - 92: Oooo0Ooo000 % iIii1I11I1II1 - O0ooOooooO / i11iIiiIii % iI * o0000oOoOoO0o
 i1i1IIiII1I ( i1I1i111Ii , ooo )
 if 80 - 80: O0ooOooooO
def iiiI1 ( ) :
 if 3 - 3: o00O0oo * O0oO
 iIiII1 ( i1I1i111Ii , i1i1iI1iiiI )
 if 53 - 53: iIii1I11I1II1 / O0ooOooooO % OoOO + i1I111II1I / iI
def O00oooO00oo ( ) :
 if 74 - 74: ii11ii1ii
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  IiIiII11i1 = id
  if 44 - 44: OOooOOo % IIII * i11iIiiIii * i11iIiiIii - ii11ii1ii . Oooo0Ooo000
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % IiIiII11i1 )
  if 68 - 68: O0ooOooooO . O0oO
 if O0ii1ii1ii == 'true' :
  if 29 - 29: iI * i1I111II1I
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + i1I1i111Ii + "[/COLOR] ,5000)" )
  if 75 - 75: O0
def oOoO ( ) :
 if 59 - 59: IIII + OOooOOo / II111iiii / OoOO0ooOOoo0O
 I1I1ii1111 ( )
 if 80 - 80: OoOO0ooOOoo0O + iIii1I11I1II1 . i1I111II1I
def Ii111III1i11I ( ) :
 if 76 - 76: OOooOOo * IIII
 ii1O0 ( )
def II1IIIIiII1i ( name , url , mode , iconimage , fanart ) :
 if 12 - 12: iIii1I11I1II1 / O0oO % o0oO0
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 I111I11I111 = True
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  oOO0oo = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii , isFolder = True )
  return I111I11I111
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii , isFolder = True )
 return I111I11I111
 if 49 - 49: OoOO + II111iiii / i1I111II1I - O0 % o0oO0
def iIiIIii ( name , url , mode , iconimage , fanart , description ) :
 if 27 - 27: OoOO + ii11ii1ii
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 I111I11I111 = True
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , fanart )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii , isFolder = True )
 return I111I11I111
 if 92 - 92: OOooOOo % O0ooOooooO
def iiiI1IiI ( name , url , mode , iconimage ) :
 if 2 - 2: O0 % Oooo0Ooo000 % o00O0oo % o0000oOoOoO0o - ii11ii1ii
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 I111I11I111 = True
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , oo00 )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii , isFolder = True )
 return I111I11I111
 if 20 - 20: o0000oOoOoO0o
 if 86 - 86: Oooo0Ooo000 % OOooOOo
def o00iI1Ii11iIiiI1 ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 22 - 22: i11iIiiIii * Oooo0Ooo000 . ii11ii1ii . OoooooooOO + OOooOOo
 ooOOoooooo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( '\x62\x61\x73\x65\x36\x34' )
 if 24 - 24: II111iiii / o0oO0 . iIii1I11I1II1 - II111iiii % O0
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 oOO0 = [ ]
 if 8 - 8: OoOO % O0ooOooooO . OoooooooOO - o0oO0 % OoooooooOO
 oOO0 . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , fanart )
 II1iIi1IiIii . setProperty ( 'IsPlayable' , 'true' )
 if 61 - 61: o0000oOoOoO0o / i11iIiiIii
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  oOO0 . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 28 - 28: IIII / OoOO0ooOOoo0O
  II1iIi1IiIii . addContextMenuItems ( oOO0 , replaceItems = True )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii )
 return I111I11I111
 if 30 - 30: iI
 if 57 - 57: o0000oOoOoO0o * i11iIiiIii / OoOO0ooOOoo0O
def O0o0O0O0O ( name , url , mode , iconimage , fanart , id , trailer , description ) :
 if 40 - 40: iIii1I11I1II1 - iI / ii11ii1ii
 ooOOoooooo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( '\x62\x61\x73\x65\x36\x34' )
 if 24 - 24: oO0o0ooO0 - O0ooOooooO / iI
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 oOO0 = [ ]
 if 10 - 10: OoOO0ooOOoo0O * i1IIi
 oOO0 . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , fanart )
 II1iIi1IiIii . setProperty ( 'IsPlayable' , 'true' )
 if 15 - 15: O0oO + i1IIi - II111iiii % OOooOOo
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  oOO0 . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 34 - 34: OOooOOo
  II1iIi1IiIii . addContextMenuItems ( oOO0 , replaceItems = True )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii )
 return I111I11I111
 if 57 - 57: IIII . o0oO0 % o0000oOoOoO0o
def OooIIi111 ( name , url , mode , iconimage , fanart ) :
 if 32 - 32: O0oO / i1I111II1I - O0 * iIii1I11I1II1
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 70 - 70: OoooooooOO % OoooooooOO % OoOO
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , fanart )
 II1iIi1IiIii . setProperty ( 'IsPlayable' , 'true' )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii )
 return I111I11I111
 if 98 - 98: OoOO
def I1IIiIi ( name , url , mode , iconimage ) :
 if 93 - 93: oO0o0ooO0 - IIII + o0000oOoOoO0o . oO0o0ooO0 / O0oO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 52 - 52: Oooo0Ooo000 + Oooo0Ooo000
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , oo00 )
 II1iIi1IiIii . setProperty ( 'IsPlayable' , 'true' )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii )
 return I111I11I111
 if 73 - 73: o0000oOoOoO0o . i11iIiiIii % OoooooooOO + iI . OoooooooOO / IIII
def oOiiI1i11I ( name , url , mode , iconimage ) :
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 I111I11I111 = True
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii , isFolder = True )
 return I111I11I111
 if 31 - 31: II111iiii + IIII - OoooooooOO . O0oO
def i1IoOo000Oo00o ( ) :
 if 81 - 81: OoooooooOO
 if 88 - 88: O0 * o0000oOoOoO0o
 if 44 - 44: o0000oOoOoO0o / o00O0oo . ii11ii1ii + OoOO0ooOOoo0O
 i1iI = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 i1iI . doModal ( )
 if ( i1iI . isConfirmed ( ) ) :
  if 32 - 32: i1I111II1I - iI * O0ooOooooO * O0oO
  IiII111i1i11 = urllib . quote_plus ( i1iI . getText ( ) ) . replace ( '+' , ' ' )
  if 84 - 84: o0oO0 + o00O0oo % OOooOOo + i11iIiiIii
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 37 - 37: O0oO % o00O0oo / iI
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % IiII111i1i11 )
    if 94 - 94: O0oO / OoOO . o0000oOoOoO0o
    if O0ii1ii1ii == 'true' :
     if 1 - 1: ii11ii1ii . II111iiii
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + i1I1i111Ii + "[/COLOR] ,10000)" )
     if 93 - 93: II111iiii . i11iIiiIii + II111iiii % oO0o0ooO0
   except :
    if 98 - 98: Oooo0Ooo000 * oO0o0ooO0 * OoOO0ooOOoo0O + o0oO0 * O0ooOooooO
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 4 - 4: i1I111II1I
    if 16 - 16: iIii1I11I1II1 * O0ooOooooO + oO0o0ooO0 . O0 . o0000oOoOoO0o
iI1111i1i11Ii = IIi11I1i1I1I ( )
ooo = None
i1I1i111Ii = None
oo00o00O0 = None
OoOo000oOo0oo = None
id = None
i1i1iI1iiiI = None
if 52 - 52: O0ooOooooO + O0 % o0000oOoOoO0o % O0 % II111iiii + OoooooooOO
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 51 - 51: O0ooOooooO % i11iIiiIii
try :
 ooo = urllib . unquote_plus ( iI1111i1i11Ii [ "url" ] )
except :
 pass
try :
 i1I1i111Ii = urllib . unquote_plus ( iI1111i1i11Ii [ "name" ] )
except :
 pass
try :
 oo00o00O0 = int ( iI1111i1i11Ii [ "mode" ] )
except :
 pass
try :
 OoOo000oOo0oo = urllib . unquote_plus ( iI1111i1i11Ii [ "iconimage" ] )
except :
 pass
try :
 id = int ( iI1111i1i11Ii [ "id" ] )
except :
 pass
try :
 i1i1iI1iiiI = urllib . unquote_plus ( iI1111i1i11Ii [ "trailer" ] )
except :
 pass
 if 28 - 28: o00O0oo + o00O0oo % OoOO0ooOOoo0O
 if 12 - 12: O0oO
print "Mode: " + str ( oo00o00O0 )
print "URL: " + str ( ooo )
print "Name: " + str ( i1I1i111Ii )
print "iconimage: " + str ( OoOo000oOo0oo )
print "id: " + str ( id )
print "trailer: " + str ( i1i1iI1iiiI )
if 19 - 19: o0oO0 * i1IIi % O0 + O0oO
if 25 - 25: Oooo0Ooo000 - o0oO0 / O0 . OoooooooOO % OOooOOo . i1IIi
def OOOoOoO ( ) :
 if 19 - 19: II111iiii / II111iiii % o00O0oo + oO0o0ooO0 + oO0o0ooO0 + O0ooOooooO
 try :
  if 4 - 4: o0000oOoOoO0o + O0oO / O0ooOooooO + i1IIi % o0000oOoOoO0o % O0ooOooooO
  ooOooOooOOO = OO0O0 ( OOOoOoO )
  I11I11 = re . compile ( Ii1I1Ii ) . findall ( ooOooOooOOO )
  for I1 in I11I11 :
   if 59 - 59: O0oO
   if I1 == 'si' :
    if 63 - 63: OoOO . oO0o0ooO0 + Oooo0Ooo000 . OoOO0ooOOoo0O / i11iIiiIii / O0ooOooooO
    import resoveurl
    from resoveurl import common
    import random
    from random import choice
    II1iII1 = xbmc . Player ( )
    Oo0O0O0ooO0O = [ 'gtG1Y3_34ug' , '3d_ACcf0rDc' , 'AKpPeLAMY9I' , 'sVBa5hNZFHM' , '5ZCVhFmbAY0' ]
    I11II11IiI11 = random . choice ( Oo0O0O0ooO0O )
    ooo = 'https://www.youtube.com/watch?v=%s' % I11II11IiI11
    ooo = resoveurl . HostedMediaFile ( ooo ) . resolve ( )
    II1iII1 . play ( ooo )
    if 97 - 97: iI / iIii1I11I1II1 % iI / OOooOOo * O0ooOooooO % OoOO0ooOOoo0O
    i1iiii1 == 'false'
    if 85 - 85: OOooOOo + IIII + IIII
   else :
    if 92 - 92: O0oO % O0 % o0oO0 . o0oO0 . i1I111II1I
    i1iiii1 == 'false'
    if 82 - 82: ii11ii1ii + OoOO0ooOOoo0O . o00O0oo % oO0o0ooO0 / o0oO0
    return False
    if 37 - 37: oO0o0ooO0 % Oooo0Ooo000 % oO0o0ooO0
 except :
  pass
  if 14 - 14: OoOO / OOooOOo
  if 66 - 66: ii11ii1ii / i11iIiiIii % iI
  if 43 - 43: IIII
if oo00o00O0 == None or ooo == None or len ( ooo ) < 1 :
 if 84 - 84: IIII . i1I111II1I . O0ooOooooO
 if 2 - 2: ii11ii1ii - OoOO0ooOOoo0O
 IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 o00O0 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 oOO0O00Oo0O0o = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( '\x62\x61\x73\x65\x36\x34' )
 O00ooOo = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 iIIIiIi = OO0O0 ( oOO0O00Oo0O0o )
 I11I11 = re . compile ( Ii1I1Ii ) . findall ( iIIIiIi )
 for oOO0o00O in I11I11 :
  if 49 - 49: o0oO0 + II111iiii / oO0o0ooO0 - OoOO0ooOOoo0O % OoOO0ooOOoo0O + OOooOOo
  try :
   if 54 - 54: iI % ii11ii1ii - IIII
   if 16 - 16: o00O0oo * O0ooOooooO / O0oO
   IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 46 - 46: II111iiii
   if 13 - 13: i1I111II1I + II111iiii % OOooOOo
   if IIIi1I1IIii1II == oOO0o00O :
    if 30 - 30: OoooooooOO - i11iIiiIii + oO0o0ooO0 / ii11ii1ii - i11iIiiIii
    ii1O0 ( )
    Iii1iI ( )
    if 74 - 74: O0 . O0oO
    i1iiii1 = IiII1IiiIiI1 . getSetting ( 'videos_event' )
    if i1iiii1 == 'true' :
     xbmc . sleep ( 3000 )
     OOOoOoO ( )
     if 64 - 64: iI / i1IIi % O0ooOooooO
   else :
    if 84 - 84: OoOO0ooOOoo0O - ii11ii1ii . iI . i1I111II1I - ii11ii1ii
    iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
    if 99 - 99: Oooo0Ooo000
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Por favor compruebe los ajustes de realstream.[/COLOR]" , "[COLOR white] Desde la seccion Tutoriales puede sacarle mayor partido a su Realstream, tambien puede configurarlo a su gusto. [/COLOR]" , "[COLOR gold]El addon no esta activado o bien configurado.[/COLOR]" )
    if 75 - 75: iI . IIII / i1I111II1I
  except :
   pass
   if 84 - 84: OoooooooOO . OOooOOo / o0000oOoOoO0o
elif oo00o00O0 == 1 :
 o00O ( i1I1i111Ii , ooo , id , i1i1iI1iiiI )
elif oo00o00O0 == 2 :
 iI1I1II1 ( )
elif oo00o00O0 == 3 :
 Oo0O0Oo00O ( )
elif oo00o00O0 == 4 :
 OooO ( i1I1i111Ii , ooo )
elif oo00o00O0 == 5 :
 II1I1ii1ii11 ( )
elif oo00o00O0 == 6 :
 O0o0O0OO0o ( )
elif oo00o00O0 == 7 :
 O0o00oo0OO0 ( )
elif oo00o00O0 == 8 :
 OooOo ( )
elif oo00o00O0 == 9 :
 IIii1III ( )
elif oo00o00O0 == 10 :
 i111IiiI1Ii ( )
elif oo00o00O0 == 11 :
 o0O0OOo0oO ( )
elif oo00o00O0 == 12 :
 IiI11I111 ( )
elif oo00o00O0 == 13 :
 I1iIiI1IiIIII ( )
elif oo00o00O0 == 14 :
 OOoO0OOoO0ooo ( )
elif oo00o00O0 == 15 :
 iI1IIiiIIIII ( )
elif oo00o00O0 == 16 :
 I1i ( )
elif oo00o00O0 == 17 :
 iIi11I11 ( )
elif oo00o00O0 == 18 :
 ii1IIii ( )
elif oo00o00O0 == 19 :
 oo0OoOO0000 ( )
elif oo00o00O0 == 20 :
 iI1iii1i1III1 ( )
elif oo00o00O0 == 21 :
 I11oO0oo ( )
elif oo00o00O0 == 22 :
 oo0i11i ( )
elif oo00o00O0 == 23 :
 iiii11IiIiI ( )
elif oo00o00O0 == 24 :
 iIii11iI1II ( )
elif oo00o00O0 == 25 :
 II11 ( )
elif oo00o00O0 == 26 :
 O00Iii1111III111 ( )
elif oo00o00O0 == 28 :
 oOO0o000Oo00o ( i1I1i111Ii , ooo )
elif oo00o00O0 == 29 :
 Oo00O0OO ( )
elif oo00o00O0 == 30 :
 II1IIi ( )
elif oo00o00O0 == 31 :
 prueba ( )
elif oo00o00O0 == 98 :
 busqueda_global ( )
elif oo00o00O0 == 97 :
 o0oOOO ( )
elif oo00o00O0 == 99 :
 O00o ( )
elif oo00o00O0 == 100 :
 menu_player ( i1I1i111Ii , ooo )
elif oo00o00O0 == 111 :
 OOOoOo ( )
elif oo00o00O0 == 115 :
 iIiII1 ( ooo )
elif oo00o00O0 == 116 :
 O00I11ii1i1 ( )
elif oo00o00O0 == 117 :
 oOOo000oOoO0 ( )
elif oo00o00O0 == 119 :
 oooOOoooo ( )
elif oo00o00O0 == 120 :
 OOo ( )
elif oo00o00O0 == 121 :
 Iiii ( )
elif oo00o00O0 == 125 :
 O0O00oO0OoO0o ( )
elif oo00o00O0 == 112 :
 list_proxy ( )
elif oo00o00O0 == 127 :
 i1IoOo000Oo00o ( )
elif oo00o00O0 == 128 :
 TESTLINKS ( )
elif oo00o00O0 == 130 :
 i1i1IIiII1I ( i1I1i111Ii , ooo )
elif oo00o00O0 == 140 :
 i11iiI1111 ( )
elif oo00o00O0 == 141 :
 oo0 ( )
elif oo00o00O0 == 142 :
 ii1I11iIiIII1 ( )
elif oo00o00O0 == 143 :
 iiIii1IIi ( i1I1i111Ii , ooo )
elif oo00o00O0 == 144 :
 oOO0o000Oo00o ( i1I1i111Ii , ooo )
elif oo00o00O0 == 145 :
 iii1 ( )
elif oo00o00O0 == 146 :
 iiooO0o0oO ( )
elif oo00o00O0 == 147 :
 O0oo0O0 ( i1I1i111Ii , ooo )
elif oo00o00O0 == 150 :
 OoO000O ( )
elif oo00o00O0 == 151 :
 IiIIiIIIiIii ( )
elif oo00o00O0 == 152 :
 i11111I1I ( )
elif oo00o00O0 == 155 :
 i1I1II1iIIi11 ( )
 if 86 - 86: ii11ii1ii % OoOO0ooOOoo0O
xbmcplugin . endOfDirectory ( o0OoOoOO00 )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
