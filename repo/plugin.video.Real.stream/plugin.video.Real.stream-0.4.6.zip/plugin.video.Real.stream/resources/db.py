# -*- coding: utf-8 -*-
# ------------------------------------------------------------
# Conf-addon
import urllib, urllib2, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
addon = xbmcaddon.Addon('plugin.video.Real.stream')
addon_version = addon.getAddonInfo('version')
plugin_handle = int(sys.argv[1])
mysettings = xbmcaddon.Addon(id = 'plugin.video.Real.stream')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
#Imagenes
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
extended = xbmc.translatePath(os.path.join(home, 'extended_info.png'))
buscar = xbmc.translatePath(os.path.join(home, 'buscar.png'))
pair = xbmc.translatePath(os.path.join(home, 'openload.jpg'))
theMovieDB = xbmc.translatePath(os.path.join(home, 'theMovieDB.jpg'))
novedades = xbmc.translatePath(os.path.join(home, 'estrenos.png'))
estrenos = xbmc.translatePath(os.path.join(home, 'encines.jpg'))
recomendadas = xbmc.translatePath(os.path.join(home, 'recomendadas.jpg'))
p_accion = xbmc.translatePath(os.path.join(home, 'accion.jpg'))
animacion = xbmc.translatePath(os.path.join(home, 'animacion.jpg'))
aventuras = xbmc.translatePath(os.path.join(home, 'aventuras.jpg'))
belico = xbmc.translatePath(os.path.join(home, 'belico.jpg'))
cifi = xbmc.translatePath(os.path.join(home, 'ciencia-ficcion.jpg'))
comedia = xbmc.translatePath(os.path.join(home, 'comedia.jpg'))
crimen = xbmc.translatePath(os.path.join(home, 'crimen.jpg'))
drama = xbmc.translatePath(os.path.join(home, 'drama.jpg'))
familiar = xbmc.translatePath(os.path.join(home, 'familiar.jpg'))
fantasia = xbmc.translatePath(os.path.join(home, 'fantasia.jpg'))
historia = xbmc.translatePath(os.path.join(home, 'historia.jpg'))
superheroes = xbmc.translatePath(os.path.join(home, 'marvel.png'))
misterio = xbmc.translatePath(os.path.join(home, 'misterio.jpg'))
musical = xbmc.translatePath(os.path.join(home, 'musical.jpg'))
romance = xbmc.translatePath(os.path.join(home, 'romance.jpg'))
spain = xbmc.translatePath(os.path.join(home, 'spain.jpg'))
suspense = xbmc.translatePath(os.path.join(home, 'suspense.jpg'))
terror = xbmc.translatePath(os.path.join(home, 'terror.jpg'))
thriller = xbmc.translatePath(os.path.join(home, 'thriller.jpg'))
western = xbmc.translatePath(os.path.join(home, 'western.jpg'))
sagas = xbmc.translatePath(os.path.join(home, 'sagas_cine.jpg'))

#Menus
menu_pelis = xbmc.translatePath(os.path.join(home, 'peliculas.png'))
ajustes = xbmc.translatePath(os.path.join(home, 'ajustes.png'))
vid = xbmc.translatePath(os.path.join(home, 'videoteca.png'))
favicon = xbmc.translatePath(os.path.join(home, 'favorites.png'))

#Ajustes
mostrar_cat = addon.getSetting('mostrar_cat')
videos = addon.getSetting('videos')
activar = addon.getSetting('activar')
favcopy = addon.getSetting('favcopy')
anticopia = addon.getSetting('anticopia')
notificar = addon.getSetting('notificar') 
aviso = addon.getSetting('aviso')
RealStream_Settings = addon.getSetting('notificar')
fav = addon.getSetting('fav') 

Forceupdate = addon.getSetting('Forceupdate')
if Forceupdate == 'true':  
    xbmc.executebuiltin('UpdateAddonRepos()')
    xbmc.executebuiltin('UpdateLocalAddons()')
	
#regexs
u_tube = 'http://www.youtube.com'
texto = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0vYmllbnZlbmlkYS50eHQ='.decode('base64')
urly = 'aHR0cDovL3kzei5zag=='.decode('base64')
decode32 = '.xsl.pt'
myurl = urly + decode32
texto_regex = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*texto3=[\'"](.*?)[\'"]\s*'
m3u_thumb_regex = 'tvg-logo=[\'"](.*?)[\'"]'
m3u_regex = '#(.+?),(.+)\s*(.+)\s*(.*)'
url_regex = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
reg_url = 'enlace=[\'"](.*?)[\'"]'

#categorias
op = 'http://netai.eu/realstream/novedades.m3u'
op1 = 'http://netai.eu/realstream/estrenos.m3u'
op2 = 'http://netai.eu/realstream/recomendadas.m3u'
op3 = 'http://netai.eu/realstream/accion.m3u'
op4 = 'http://netai.eu/realstream/animacion.m3u'
op5 = 'http://netai.eu/realstream/aventuras.m3u'
op6 = 'http://netai.eu/realstream/belico.m3u'
op7 = 'http://netai.eu/realstream/cifi.m3u'
op8 = 'http://netai.eu/realstream/comedia.m3u'
op9 = 'http://netai.eu/realstream/crimen.m3u'
op10 = 'http://netai.eu/realstream/drama.m3u'
op11 = 'http://netai.eu/realstream/familiar.m3u'
op12 = 'http://netai.eu/realstream/fantasia.m3u'
op13 = 'http://netai.eu/realstream/historia.m3u'
op14 = 'http://netai.eu/realstream/misterio.m3u'
op15 = 'http://netai.eu/realstream/musical.m3u'
op16 = 'http://netai.eu/realstream/romance.m3u'
op17 = 'http://netai.eu/realstream/thriller.m3u'
op18 = 'http://netai.eu/realstream/suspense.m3u'
op19 = 'http://netai.eu/realstream/terror.m3u'
op20 = 'http://netai.eu/realstream/western.m3u'
op21 = 'http://netai.eu/realstream/spain.m3u'
op22 = 'http://netai.eu/realstream/superheroes.m3u'
op23 = 'http://netai.eu/realstream/sagas.m3u'




