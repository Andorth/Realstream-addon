# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 1.46
#
############################################
# Dependencias 
# Script ExtendedInfo
# Script ResolveURL Por Jsergio.
############################################
#
# Agregado multi enlace de servidores.
# Agregado sistema individual de usuarios.
# Agregadas categorias de peliculas.
#
############################################
if 64 - 64: i11iIiiIii
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import resolveurl
import cookielib , base64
import requests
import plugintools
import config
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
IiII1IiiIiI1 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
o0OoOoOO00 = int ( sys . argv [ 1 ] )
I11i = 'gruponetai/'
O0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
Oo = O0O . getAddonInfo ( 'profile' )
I1ii11iIi11i = O0O . getAddonInfo ( 'path' )
I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
if 73 - 73: OOooOOo / ii11ii1ii
if 94 - 94: OoOO + OoOO0ooOOoo0O + o0000oOoOoO0o * o00O0oo
if I1IiI == 'true' :
 if 97 - 97: oO0o0ooO0 - IIII / O0oO - o0oO0
 oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.png' ) )
 o00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 Oo0oO0ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.png' ) )
 i1111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.png' ) )
 i11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'estrenos.png' ) )
 I11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.png' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.png' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.png' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.png' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.png' ) )
 oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.png' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.png' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.png' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.png' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.png' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.png' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.png' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'marvel.png' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.png' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.png' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.png' ) )
 II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.png' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.png' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.png' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.png' ) )
 OO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.png' ) )
 Ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.png' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.png' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.png' ) )
 O0OO00o0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.png' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.png' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_series.png' ) )
 OOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_Episodios.png' ) )
 if 87 - 87: O0ooOooooO / i1I111II1I - Oooo0Ooo000 - iI - II111iiii / O0
else :
 if 97 - 97: iI - IIII * i11iIiiIii / OoOO0ooOOoo0O % Oooo0Ooo000 - OoooooooOO
 if 59 - 59: O0 + OOooOOo + i1I111II1I % OOooOOo
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
 oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.jpg' ) )
 o00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 Oo0oO0ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.jpg' ) )
 i1111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.jpg' ) )
 i11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'encines.jpg' ) )
 I11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.jpg' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.jpg' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.jpg' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.jpg' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.jpg' ) )
 oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.jpg' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.jpg' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.jpg' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.jpg' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.jpg' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.jpg' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.jpg' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'superheroes.jpg' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.jpg' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.jpg' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.jpg' ) )
 II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.jpg' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.jpg' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.jpg' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.jpg' ) )
 OO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.jpg' ) )
 Ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.jpg' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.jpg' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.jpg' ) )
 O0OO00o0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.png' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.png' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.png' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favoritos.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_series.png' ) )
 OOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_Episodios.png' ) )
 if 70 - 70: O0ooOooooO * o00O0oo
 if 46 - 46: iI / OoOO
 if 52 - 52: o0000oOoOoO0o - OoooooooOO + o0oO0 + o0oO0 - o0000oOoOoO0o / Oooo0Ooo000
I1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'peliculas.png' ) )
iIi11Ii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series.png' ) )
Ii11iII1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ajustes.png' ) )
Oo0O0O0ooO0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'videoteca.png' ) )
IIIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
O0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'resolver.png' ) )
OO00Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'test.png' ) )
O0OOO0OOoO0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'video-tutoriales.png' ) )
O00Oo000ooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'proxy.png' ) )
if 100 - 100: O0 + i1I111II1I - IIII + i11iIiiIii * o0oO0
if 30 - 30: o0000oOoOoO0o . o0oO0 - OoooooooOO
if 8 - 8: i1IIi - iIii1I11I1II1 * II111iiii + i11iIiiIii / Oooo0Ooo000 % IIII
iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
OOoOO0oo0ooO = IiII1IiiIiI1 . getSetting ( 'mostrar_cat' )
O0o0O00Oo0o0 = IiII1IiiIiI1 . getSetting ( 'sel_tobox' )
O00O0oOO00O00 = IiII1IiiIiI1 . getSetting ( 'videos' )
i1Oo00 = IiII1IiiIiI1 . getSetting ( 'activar' )
i1i = IiII1IiiIiI1 . getSetting ( 'favcopy' )
iiI111I1iIiI = IiII1IiiIiI1 . getSetting ( 'anticopia' )
IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
oooooOoo0ooo = IiII1IiiIiI1 . getSetting ( 'mostrar_bus' )
I1I1IiI1 = IiII1IiiIiI1 . getSetting ( 'restante' )
III1iII1I1ii = IiII1IiiIiI1 . getSetting ( 'selecton' )
oOOo0 = IiII1IiiIiI1 . getSetting ( 'aviso' )
oo00O00oO = IiII1IiiIiI1 . getSetting ( 'RealStream_Settings' )
iIiIIIi = IiII1IiiIiI1 . getSetting ( 'Resolver_Settings' )
I1I1IiI1 = IiII1IiiIiI1 . getSetting ( 'restante' )
ooo00OOOooO = IiII1IiiIiI1 . getSetting ( 'fav' )
O00OOOoOoo0O = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
O000OOo00oo = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
oo0OOo = 'bienvenida'
ooOOO00Ooo = 'bienvenida'
copyright = IiII1IiiIiI1 . getSetting ( 'copyright' )
IiIIIi1iIi = 'cGx1Z2luLnZpZGVvLg==' . decode ( 'base64' ) + copyright
ooOOoooooo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
II1I = IiII1IiiIiI1 . getSetting ( 'Forceupdate' )
if II1I == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
O0i1II1Iiii1I11 = 'LnR4dA==' . decode ( 'base64' )
IIIIiiIiI = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1NQOUpRZExS' . decode ( 'base64' )
if 91 - 91: O0ooOooooO % i1IIi % iIii1I11I1II1
if 20 - 20: IIII % o0oO0 / o0oO0 + o0oO0
III1IiiI = 'aHR0cDovL2JpdC5seS8yU1FOSnlP' . decode ( 'base64' )
iIi1 = O000OOo00oo + oo0OOo + O0i1II1Iiii1I11
IIIII11I1IiI = 'http://www.youtube.com'
i1I = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
OoOOooOOO0 = 'http://bit.ly/2ImelUx'
o0o = '.xsl.pt'
O0OOoO00OO0o = 'L21hc3Rlci8=' . decode ( 'base64' )
I1111IIIIIi = i1I + o0o
Iiii1i1 = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*'
OO = 'tvg-logo=[\'"](.*?)[\'"]'
if 77 - 77: ii11ii1ii
I1iII1iIi1I = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.*)'
oO0O00OoOO0 = '(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)'
OoO = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
O00 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
I1iI1 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
iiiIi1 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
i1I1ii11i1Iii = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.+)\s*'
I1IiiiiI = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
o0O = '#(.+?),(.+)\s*(.+)'
IiII = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
ii1iII1II = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
Iii1I1I11iiI1 = '[\'"](.*?)[\'"]'
I1I1i1I = r'066">\s*(.+)</f'
ii1I = '[\'"](.*?)[\'"]'
O0oO0 = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
oO0 = '[\'"](.*?)[\'"]'
O0OO0O = 'src":"(.*?)"label":"(.*?)"lang":"(.*?)"'
OOOoOoO = 'https://pastebin.com/raw/SP9JQdLR'
Ii1I1i = '[\'"](.*?)[\'"]'
OOI1iI1ii1II = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( 'base64' )
O0O0OOOOoo = OOI1iI1ii1II + I11i
oOooO0 = '(.+),(.+),(.*)\s*'
Ii1I1Ii = '[\'"](.*?)[\'"]'
OOoO0 = 'UmVhbHN0cmVhbQ==' . decode ( 'base64' )
OO0Oooo0oOO0O = 'video=[\'"](.*?)[\'"]'
o00O0 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
oOO0O00Oo0O0o = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( 'base64' ) + o00O0
ii1 = '0101ahn' . replace ( '0101ahn' , 'sZn' )
I1iIIiiIIi1i = 'aHR0cDovL2JpdC5seS8yTnpB' . decode ( 'base64' ) + ii1
O0O0ooOOO = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
oOOo0O00o = '0110R0N' . replace ( '0110R0N' , 'R0N' )
iIiIi11 = 'aHR0cDovL2JpdC5seS8yWEIx' . decode ( 'base64' ) + oOOo0O00o
OOO = '0110pEJ' . replace ( '0110pEJ' , 'pEJ' )
iiiiI = 'aHR0cDovL2JpdC5seS8yd1Nh' . decode ( 'base64' ) + OOO
oooOo0OOOoo0 = 'ABBAOb5' . replace ( 'ABBAOb5' , 'Ob5' )
OOoO = 'aHR0cDovL2JpdC5seS8yRVhV' . decode ( 'base64' ) + oooOo0OOOoo0
OO0O000 = '0110jaw' . replace ( '0110jaw' , 'jaw' )
iiIiI1i1 = 'aHR0cDovL2JpdC5seS8yd01M' . decode ( 'base64' ) + OO0O000
oO0O00oOOoooO = '01109DI' . replace ( '01109DI' , '9DI' )
IiIi11iI = 'aHR0cDovL2JpdC5seS8ySXgz' . decode ( 'base64' ) + oO0O00oOOoooO
Oo0O00O000 = '01103hs' . replace ( '01103hs' , '3hs' )
i11I1IiII1i1i = 'aHR0cDovL2JpdC5seS8zMW1U' . decode ( 'base64' ) + Oo0O00O000
oo = '01107DW' . replace ( '01107DW' , '7DW' )
I1111i = 'aHR0cDovL2JpdC5seS8yV1ln' . decode ( 'base64' ) + oo
iIIii = '0110mLl' . replace ( '0110mLl' , 'mLl' )
o00O0O = 'aHR0cDovL2JpdC5seS8yS0cw' . decode ( 'base64' ) + iIIii
ii1iii1i = '01102Hj' . replace ( '01102Hj' , '2Hj' )
Iii1I1111ii = 'aHR0cDovL2JpdC5seS8yWEJo' . decode ( 'base64' ) + ii1iii1i
ooOoO00 = '0110fXg' . replace ( '0110fXg' , 'fXg' )
Ii1IIiI1i = 'aHR0cDovL2JpdC5seS8ySTVy' . decode ( 'base64' ) + ooOoO00
o0O00Oo0 = '0110NMH' . replace ( '0110NMH' , 'NMH' )
IiII111i1i11 = 'aHR0cDovL2JpdC5seS8yd0t6' . decode ( 'base64' ) + o0O00Oo0
i111iIi1i1II1 = '0110bwQ' . replace ( '0110bwQ' , 'bwQ' )
oooO = 'aHR0cDovL2JpdC5seS8yd01V' . decode ( 'base64' ) + i111iIi1i1II1
i1I1i111Ii = '0110xzG' . replace ( '0110xzG' , 'xzG' )
ooo = 'aHR0cDovL2JpdC5seS8yWHhz' . decode ( 'base64' ) + i1I1i111Ii
i1i1iI1iiiI = '0110x64' . replace ( '0110x64' , 'x64' )
Ooo0oOooo0 = 'aHR0cDovL2JpdC5seS8yRVlF' . decode ( 'base64' ) + i1i1iI1iiiI
oOOOoo00 = '0110vUE' . replace ( '0110vUE' , 'vUE' )
iiIiIIIiiI = 'aHR0cDovL2JpdC5seS8yWmhW' . decode ( 'base64' ) + oOOOoo00
iiI1IIIi = '01107ZL' . replace ( '01107ZL' , '7ZL' )
II11IiIi11 = 'aHR0cDovL2JpdC5seS8yWm4w' . decode ( 'base64' ) + iiI1IIIi
IIOOO0O00O0OOOO = '01106cf' . replace ( '01106cf' , '6cf' )
I1iiii1I = 'aHR0cDovL2JpdC5seS8yRVlk' . decode ( 'base64' ) + IIOOO0O00O0OOOO
OOo0 = '0110Jtp' . replace ( '0110Jtp' , 'Jtp' )
oO00ooooO0o = 'aHR0cDovL2JpdC5seS8yV3Nq' . decode ( 'base64' ) + OOo0
oo0o = '0110a5b' . replace ( '0110a5b' , 'a5b' )
o0oO0oooOoo = 'aHR0cDovL2JpdC5seS8yV3dj' . decode ( 'base64' ) + oo0o
I1III1111iIi = '0110Q7u' . replace ( '0110Q7u' , 'Q7u' )
I1i111I = 'aHR0cDovL2JpdC5seS8yV3NL' . decode ( 'base64' ) + I1III1111iIi
OooOo0oo0O0o00O = '0110rsq' . replace ( '0110rsq' , 'rsq' )
I1i11 = 'aHR0cDovL2JpdC5seS8ySzhE' . decode ( 'base64' ) + OooOo0oo0O0o00O
IiIi1I1 = '0110DDR' . replace ( '0110DDR' , 'DDR' )
IiIIi1 = 'aHR0cDovL2JpdC5seS8ySzd5' . decode ( 'base64' ) + IiIi1I1
IIIIiii1IIii = '0110feQ' . replace ( '0110feQ' , 'feQ' )
II1i11I = 'aHR0cDovL2JpdC5seS8yS0cz' . decode ( 'base64' ) + IIIIiii1IIii
ii1I1IIii11 = '0110MHY' . replace ( '0110MHY' , 'MHY' )
O0o0oO = 'aHR0cDovL2JpdC5seS8ySXVo' . decode ( 'base64' ) + ii1I1IIii11
IIIIiIiIi1 = '0110xdb' . replace ( '0110xdb' , 'xdb' )
I11iiiiI1i = 'aHR0cDovL2JpdC5seS8yWEJu' . decode ( 'base64' ) + IIIIiIiIi1
iI1i11 = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( 'base64' )
OoOOoooOO0O = 'aHR0cHM6Ly9uZXRhaS5ldS92aXNpdGFzL2luZGV4LnBocA==' . decode ( 'base64' )
IiIIIi1iIi = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
ooo00Ooo = '0110lxu' . replace ( '0110lxu' , 'lxu' )
Oo0o0O00 = 'aHR0cDovL2JpdC5seS8yV1Bj' . decode ( 'base64' ) + ooo00Ooo
ii1I1i11 = '0110pzp' . replace ( '0110pzp' , 'pzp' )
OOo0O0oo0OO0O = 'aHR0cDovL2JpdC5seS8yVHpB' . decode ( 'base64' ) + ii1I1i11
OO0 = '01105yt' . replace ( '01105yt' , '5yt' )
o0Oooo = 'aHR0cDovL2JpdC5seS8yTVpp' . decode ( 'base64' ) + OO0
if 36 - 36: OoooooooOO . OoOO
if 56 - 56: ii11ii1ii . o00O0oo . OOooOOo
ii111I = '1001DTs' . replace ( '1001DTs' , 'DTs' )
iiI = 'aHR0cDovL2JpdC5seS8ySzhP' . decode ( 'base64' ) + ii111I
iIiiiII = '1001Hky' . replace ( '1001Hky' , 'Hky' )
i1iI1 = 'aHR0cDovL2JpdC5seS8yTGVL' . decode ( 'base64' ) + iIiiiII
i11ii1ii11i = '1001VFU' . replace ( '1001VFU' , 'VFU' )
ooO0OoOO = 'aHR0cDovL2JpdC5seS8zMERx' . decode ( 'base64' ) + i11ii1ii11i
O0O0Oo00 = '3545OMZ' . replace ( '3545OMZ' , 'OMZ' )
oOoO00o = 'aHR0cDovL2JpdC5seS8yazhk' . decode ( 'base64' ) + O0O0Oo00
oO00O0 = '4224tZO' . replace ( '4224tZO' , 'tZO' )
IIi1IIIi = 'aHR0cDovL2JpdC5seS8zNXd4' . decode ( 'base64' ) + oO00O0
if 99 - 99: o0oO0 + OoOO * II111iiii . o0000oOoOoO0o - o00O0oo
if 58 - 58: o0oO0 + o0000oOoOoO0o - OOooOOo
if 3 - 3: OoOO
def oooOoOOO0oo0o ( ) :
 if 85 - 85: OoooooooOO % i1IIi * OoooooooOO / o00O0oo
 if 96 - 96: OoooooooOO + oO0o0ooO0
 try :
  iiII1i11i = IiIi ( iIiIi11 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   try :
    if 31 - 31: o0000oOoOoO0o % OoOO
    iiiiI = Iii
    if 14 - 14: oO0o0ooO0 / oO0o0ooO0 % iI
    ooO = xbmc . Keyboard ( '' , 'Busqueda por titulo' )
    ooO . doModal ( )
    if ( ooO . isConfirmed ( ) ) :
     ii = xbmcgui . DialogProgress ( )
     ii . create ( 'Realstream:' , 'Buscando ...' )
     OO0O0Ooo = range ( 0 , 76 )
     for oOoO0 in OO0O0Ooo :
      oOoO0 = oOoO0 + 1
      if 77 - 77: iIii1I11I1II1 . O0ooOooooO % O0ooOooooO + i11iIiiIii
     Oo00o0OO0O00o = urllib . quote_plus ( ooO . getText ( ) ) . replace ( '+' , ' ' )
     O0Oooo = IiIi ( iiiiI )
     OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( O0Oooo )
     for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
      if 27 - 27: o00O0oo + OoOO0ooOOoo0O - IIII + O0 . o0oO0
      ii . update ( oOoO0 , '[COLOR orange]Realstream: Buscando ...[/COLOR]' , ' [COLOR yellow] %s [/COLOR]' % I1i11111i1i11 )
      xbmc . sleep ( 1 )
      if ii . iscanceled ( ) : break ;
      if re . search ( Oo00o0OO0O00o , iIi1i1iIi1iI ( I1i11111i1i11 . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       if 26 - 26: OoooooooOO * OOooOOo + IIII
       ii . update ( 80 , ' [COLOR orange]Busqueda finalizada[/COLOR] ' )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR gold]Generando listado ...  [/COLOR][COLOR orange] Por favor espere ![/COLOR] ,1000)" )
       ii . update ( 100 , '[COLOR orange]Realstream: [/COLOR]' , '[COLOR gold] Busqueda finalizada ...[/COLOR]' )
       ii . close ( )
       IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
       if 43 - 43: O0
       if 39 - 39: OOooOOo . iIii1I11I1II1 * o0oO0 % iI . iIii1I11I1II1
     oO0OoO00o ( '[COLOR %s]Buscar Pelicula[/COLOR]' % iIIIi1 , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Resultados para: [COLOR orange]" + Oo00o0OO0O00o + "[/COLOR] ,2000)" )
     if 11 - 11: ii11ii1ii - OOooOOo * II111iiii . o00O0oo . oO0o0ooO0
   except : oO0OoO00o ( '[COLOR %s]Buscar Pelicula[/COLOR]' % iIIIi1 , 'search' , 111 , IIiiiiiiIi1I1 , oo00 )
   if 61 - 61: O0ooOooooO % OOooOOo - o0000oOoOoO0o - II111iiii % O0
 except :
  pass
  if 90 - 90: iIii1I11I1II1 + o00O0oo + iI - Oooo0Ooo000 * i1I111II1I . o00O0oo
def I11iiiii1II ( ) :
 if 51 - 51: O0 % oO0o0ooO0 - II111iiii
 oOOo0 = IiII1IiiIiI1 . getSetting ( 'aviso' )
 if 31 - 31: O0ooOooooO / ii11ii1ii - O0ooOooooO - IIII
 if oOOo0 == 'true' :
  if 7 - 7: O0ooOooooO % O0 . OoOO0ooOOoo0O + OOooOOo - O0oO
  try :
   iiII1i11i = IiIi ( iIi1 )
   OOOOO0O00 = re . compile ( Iiii1i1 ) . findall ( iiII1i11i )
   for o0o0O00oo0 , Ii1ii1IiIII in OOOOO0O00 :
    try :
     if 57 - 57: iIii1I11I1II1 / O0oO - i1IIi
     if 51 - 51: i1I111II1I
     ii11I1 = o0o0O00oo0
     oO0oo = Ii1ii1IiIII
     if 38 - 38: OoooooooOO * iI % O0 * OoOO0ooOOoo0O
     if 29 - 29: o00O0oo / i1IIi . OOooOOo - OoOO0ooOOoo0O - OoOO0ooOOoo0O - o0oO0
     from datetime import datetime
     if 20 - 20: i1IIi % OoOO . OOooOOo / i1I111II1I * i11iIiiIii * IIII
     OOo = datetime . now ( )
     i1i11I1I1iii1 = OOo . strftime ( '%d/%m/%Y' )
     iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
     if 8 - 8: iI + II111iiii / O0ooOooooO / O0oO
     if 74 - 74: O0 / i1IIi
     if 78 - 78: OoooooooOO . OoOO + iI - i1IIi
     if 31 - 31: OoooooooOO . IIII
     if 83 - 83: O0ooOooooO . O0 / ii11ii1ii / IIII - II111iiii
     oO0oO0 = "[B]" + ii11I1 + "[/B]"
     i1i1IIIIi1i = "" + oO0oo + ""
     Ii11iiI = "[COLOR white]Hoy es: " + i1i11I1I1iii1 + ", Su version instalada es:[/COLOR][COLOR gold] " + iIiiiI1IiI1I1 + "[/COLOR]"
     if 17 - 17: ii11ii1ii % IIII . i1IIi / OoooooooOO
     xbmcgui . Dialog ( ) . ok ( "Real Stream" , oO0oO0 , i1i1IIIIi1i , Ii11iiI )
    except :
     pass
     if 28 - 28: oO0o0ooO0 . II111iiii / o00O0oo + II111iiii . OoooooooOO . i1I111II1I
  except :
   pass
   if 53 - 53: o0oO0 % o0oO0 * o0000oOoOoO0o + OoOO0ooOOoo0O
  try :
   O0Oooo = IiIi ( iI1i11 )
   OOOOO0O00 = re . compile ( Iii1I1I11iiI1 ) . findall ( O0Oooo )
   for Oooo00 in OOOOO0O00 :
    if 6 - 6: o0oO0 - iI * IIII . O0ooOooooO / O0 * iI
    import xbmc
    import xbmcaddon
    if 22 - 22: ii11ii1ii % O0ooOooooO * o00O0oo / IIII % i11iIiiIii * O0oO
    __addon__ = xbmcaddon . Addon ( )
    __addonname__ = __addon__ . getAddonInfo ( 'name' )
    __icon__ = __addon__ . getAddonInfo ( 'icon' )
    if 95 - 95: OoooooooOO - i1I111II1I * OOooOOo + OoOO0ooOOoo0O
    iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
    iIi1i11iiI1111 = Oooo00
    if 97 - 97: ii11ii1ii * OOooOOo . iIii1I11I1II1
    oO0oO0 = "[COLOR orange] Ultima version: [/COLOR][COLOR white] [B]" + Oooo00 + " [/B][/COLOR]"
    I1Ii1111iIi = 4000
    xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , oO0oO0 , I1Ii1111iIi , __icon__ ) )
    if 31 - 31: O0oO . Oooo0Ooo000 * iI + i11iIiiIii * oO0o0ooO0
    if iIiiiI1IiI1I1 < Oooo00 :
     if 93 - 93: o00O0oo / iIii1I11I1II1 * i1IIi % OoooooooOO * O0 * O0oO
     xbmcgui . Dialog ( ) . ok ( "Real Stream" , "[COLOR white] Existe una nueva version de [/COLOR][COLOR fuchsia]Realstream[/COLOR]" , "[COLOR orange]Actualimete tiene instalada la version[/COLOR] [COLOR white][B] %s [/B][/COLOR]" % iIiiiI1IiI1I1 , " [COLOR white]Ya esta disponible la[/COLOR] [COLOR gold][B] %s [/B][/COLOR]" % Oooo00 )
     if 64 - 64: II111iiii + O0 / iIii1I11I1II1 / ii11ii1ii . iI % i1I111II1I
     if 50 - 50: iIii1I11I1II1 - i1I111II1I + IIII
  except :
   pass
   if 69 - 69: O0
   if 85 - 85: iI / O0
   if 18 - 18: o0000oOoOoO0o % O0 * o00O0oo
   if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 62 - 62: Oooo0Ooo000 . i1I111II1I . OoooooooOO
    if 11 - 11: IIII / O0oO
    if 73 - 73: i1IIi / i11iIiiIii
def iIi1i1iIi1iI ( s ) :
 if 58 - 58: ii11ii1ii . II111iiii + oO0o0ooO0 - i11iIiiIii / II111iiii / O0
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 85 - 85: OoOO0ooOOoo0O + IIII
def I1II ( file ) :
 if 27 - 27: II111iiii / o0oO0 . IIII
 try :
  i1II11II = open ( file , 'r' )
  iiII1i11i = i1II11II . read ( )
  i1II11II . close ( )
  return iiII1i11i
 except :
  pass
  if 87 - 87: OoOO0ooOOoo0O * Oooo0Ooo000 . O0oO
def IiIi ( url ) :
 if 51 - 51: IIII % iIii1I11I1II1 - OoooooooOO % iI * iIii1I11I1II1 % OoOO
 try :
  oO0o00oOOooO0 = urllib2 . Request ( url )
  oO0o00oOOooO0 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  OOOoO000 = urllib2 . urlopen ( oO0o00oOOooO0 )
  oOOOO = OOOoO000 . read ( )
  OOOoO000 . close ( )
  return oOOOO
 except urllib2 . URLError , Ii :
  print 'We failed to open "%s".' % url
  if hasattr ( Ii , 'code' ) :
   print 'We failed with error code - %s.' % Ii . code
  if hasattr ( Ii , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , Ii . reason
   if 15 - 15: i11iIiiIii % OOooOOo * O0oO / Oooo0Ooo000
def oooO0o0o0O0 ( url ) :
 oO0o00oOOooO0 = urllib2 . Request ( url )
 oO0o00oOOooO0 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 oO0o00oOOooO0 . add_header ( 'Referer' , '%s' % url )
 oO0o00oOOooO0 . add_header ( 'Connection' , 'keep-alive' )
 OOOoO000 = urllib2 . urlopen ( oO0o00oOOooO0 )
 oOOOO = OOOoO000 . read ( )
 OOOoO000 . close ( )
 return oOOOO
 if 27 - 27: OoooooooOO - O0ooOooooO / O0oO
 if 76 - 76: o0000oOoOoO0o % OOooOOo . iIii1I11I1II1 - i1I111II1I * OoooooooOO . O0ooOooooO
 if 84 - 84: Oooo0Ooo000 + O0oO
def IIiiIIi1 ( ) :
 if 59 - 59: i1I111II1I . IIII % II111iiii
 iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 if 39 - 39: o00O0oo
 if i1Oo00 == 'true' :
  if 97 - 97: IIII - OoOO / o0oO0 . i11iIiiIii % oO0o0ooO0 * oO0o0ooO0
  if 1 - 1: OOooOOo % iI
  try :
   if 65 - 65: OOooOOo + OoOO0ooOOoo0O / IIII
   iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
   o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
   OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
   if 83 - 83: o0000oOoOoO0o . O0ooOooooO - ii11ii1ii
   Ooo0O = IiIi ( I1iIIiiIIi1i )
   OOOOO0O00 = re . compile ( oOooO0 ) . findall ( Ooo0O )
   for o0oo0000OO , O0oOOo0Oo , o000O000 in OOOOO0O00 :
    if re . search ( OOO00O , o000O000 ) :
     if 19 - 19: iIii1I11I1II1
     if iiII1i1 == o0oo0000OO and o00oOO0o == O0oOOo0Oo and OOO00O == o000O000 :
      xbmc . sleep ( 3000 )
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR orange]Bienvenido![/COLOR][COLOR white] " + o0oo0000OO + "[/COLOR] ,3000)" )
      oO0OoO00o ( '[COLOR %s]Buscar Serie[/COLOR]' % iIIIi1 , 'search' , 145 , I1IIIii , oo00 )
      oO0OoO00o ( '[COLOR %s]Series[/COLOR] ' % iIIIi1 , 'movieDB' , 117 , iIi11Ii1 , oo00 )
      oO0OoO00o ( '[COLOR %s]Buscar Pelicula[/COLOR]' % iIIIi1 , 'search' , 146 , IIiiiiiiIi1I1 , oo00 )
      oO0OoO00o ( '[COLOR %s]Peliculas[/COLOR] ' % iIIIi1 , 'movieDB' , 116 , I1I , oo00 )
      if 26 - 26: OoooooooOO % OOooOOo % ii11ii1ii . OOooOOo % o0oO0
  except :
   pass
   if 34 - 34: i1I111II1I / OoOO0ooOOoo0O
 if oo00O00oO == 'true' :
  oO0OoO00o ( '[COLOR %s]Ajustes[/COLOR]' % iIIIi1 , 'Settings' , 119 , Ii11iII1 , oo00 )
  if 87 - 87: O0 * o0000oOoOoO0o * ii11ii1ii * II111iiii
  if 6 - 6: i1IIi . o00O0oo + OoOO0ooOOoo0O * O0oO / OoOO0ooOOoo0O % oO0o0ooO0
  if OOoOO0oo0ooO == 'true' :
   try :
    if 18 - 18: II111iiii . OoooooooOO % OoOO0ooOOoo0O % o0oO0
    iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
    o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
    OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
    if 9 - 9: OoOO - ii11ii1ii * OoooooooOO . ii11ii1ii
    if 2 - 2: OoooooooOO % IIII
    Ooo0O = IiIi ( I1iIIiiIIi1i )
    OOOOO0O00 = re . compile ( oOooO0 ) . findall ( Ooo0O )
    for O0oOOo0Oo , o0oo0000OO , o000O000 in OOOOO0O00 :
     if re . search ( OOO00O , o000O000 ) :
      if 63 - 63: OOooOOo % iIii1I11I1II1
      if iiII1i1 == o0oo0000OO and o00oOO0o == O0oOOo0Oo and OOO00O == o000O000 :
       if 39 - 39: O0ooOooooO / II111iiii / o00O0oo % OOooOOo
       O0Oo00 ( )
   except :
    pass
    if 41 - 41: iIii1I11I1II1 % O0oO
  if iIiIIIi == 'true' :
   if 59 - 59: IIII + i11iIiiIii
   oo0OOo0O ( )
   if 39 - 39: OoooooooOO + oO0o0ooO0 % IIII / IIII
  if iiI111I1iIiI == 'false' :
   if 27 - 27: O0ooOooooO . O0oO . iIii1I11I1II1 . iIii1I11I1II1
   oO0oO0 = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   i1i1IIIIi1i = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.ResolveURL para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   Ii11iiI = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, Script.resolveurl instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 20 - 20: o0000oOoOoO0o / i1IIi
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , oO0oO0 , i1i1IIIIi1i , Ii11iiI )
   if 71 - 71: OoOO0ooOOoo0O . i1IIi
def o0OooO0ooo0o ( ) :
 oO0OoO00o ( '[COLOR orange]Buscador por id[/COLOR]' , IIIII11I1IiI , 127 , oOOoo00O0O , oo00 )
 if 47 - 47: OoooooooOO
def ii1i1i1IiII ( ) :
 iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 oO0OoO00o ( '[COLOR %s]The movie DB[/COLOR]' % iIIIi1 , 'movieDB' , 99 , oOOoo00O0O , oo00 )
 if 63 - 63: O0ooOooooO . OoOO / II111iiii * i1I111II1I + oO0o0ooO0 % o0oO0
 if 12 - 12: Oooo0Ooo000 . OoOO . O0ooOooooO - OoooooooOO % ii11ii1ii
 if 36 - 36: IIII
 if 84 - 84: Oooo0Ooo000 . OoOO . II111iiii . O0oO / o0oO0 % o00O0oo
 if 57 - 57: OOooOOo % O0oO - IIII . OOooOOo / ii11ii1ii % O0ooOooooO
def OOI1iIi1iiIIiI ( ) :
 if 81 - 81: OoOO * OoOO0ooOOoo0O . IIII
 IIiiIIi1 ( )
 ii1i1i1IiII ( )
 if 11 - 11: i11iIiiIii - oO0o0ooO0 . oO0o0ooO0
def I11I ( ) :
 if 6 - 6: o00O0oo + oO0o0ooO0
 OOI1iIi1iiIIiI ( )
 if 48 - 48: iIii1I11I1II1 % i1IIi % O0ooOooooO + iI
def Iiii11iIi1 ( ) :
 if xbmc . getCondVisibility ( 'System.HasAddon(script.favourites)' ) :
  try :
   xbmc . executebuiltin ( "RunScript(script.favourites)" )
  except :
   pass
def i1iI11I1II1 ( ) :
 IiII1IiiIiI1 . openSettings ( )
 if 14 - 14: i11iIiiIii - O0ooOooooO * OoOO0ooOOoo0O
 if 51 - 51: o00O0oo / iIii1I11I1II1 % oO0o0ooO0 + o0000oOoOoO0o * iI + Oooo0Ooo000
def o0OoO00o0000O ( ) :
 resoveurl . display_settings ( )
 if 21 - 21: OOooOOo / iI % iI - o0000oOoOoO0o
def oOO ( ) :
 oO0OoO00o ( '[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % iIIIi1 , 'resolve' , 120 , O0o0 , oo00 )
 if 58 - 58: O0oO + II111iiii * O0ooOooooO * i11iIiiIii - iIii1I11I1II1
def oooo00o0o0o ( ) :
 if 87 - 87: O0oO * i1IIi - o0oO0 % IIII / Oooo0Ooo000
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 39 - 39: OOooOOo * i11iIiiIii - oO0o0ooO0 / i1I111II1I % Oooo0Ooo000 % O0oO
def oo0OOo0O ( ) :
 oO0OoO00o ( '[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % iIIIi1 , 'resolve' , 140 , O0o0 , oo00 )
 if 65 - 65: oO0o0ooO0 - iI % OoooooooOO / OoooooooOO % OoooooooOO
def O0Oo00 ( ) :
 if 52 - 52: o00O0oo + o00O0oo . II111iiii
 try :
  if 34 - 34: OoooooooOO . O0 / oO0o0ooO0 * OoOO0ooOOoo0O - o00O0oo
  iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
  OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 36 - 36: i1IIi / O0 / OoOO - O0 - i1IIi
  Ooo0O = IiIi ( I1iIIiiIIi1i )
  OOOOO0O00 = re . compile ( oOooO0 ) . findall ( Ooo0O )
  for o0oo0000OO , O0oOOo0Oo , o000O000 in OOOOO0O00 :
   if re . search ( OOO00O , o000O000 ) :
    if 22 - 22: i1IIi + o0oO0
    if iiII1i1 == o0oo0000OO and o00oOO0o == O0oOOo0Oo and OOO00O == o000O000 :
     if 54 - 54: iI % IIII . Oooo0Ooo000 + oO0o0ooO0 - IIII * OOooOOo
     oO0OoO00o ( '[COLOR %s]Buscador[/COLOR]' % iIIIi1 , 'search' , 146 , o0oOoO00o , oo00 )
     oO0OoO00o ( '[COLOR %s]Estrenos[/COLOR]' % iIIIi1 , IIIII11I1IiI , 3 , i11 , oo00 )
     if 92 - 92: o0000oOoOoO0o + Oooo0Ooo000 / ii11ii1ii % OoOO % i1I111II1I . OoooooooOO
     if 52 - 52: iI / i11iIiiIii - IIII . i1I111II1I % iIii1I11I1II1 + o0000oOoOoO0o
     if 71 - 71: oO0o0ooO0 % O0oO * OoOO0ooOOoo0O . O0 / o0oO0 . o00O0oo
     oO0OoO00o ( '[COLOR %s]Animacion[/COLOR]' % iIIIi1 , IIIII11I1IiI , 6 , oOo0oooo00o , oo00 )
     if 58 - 58: ii11ii1ii / oO0o0ooO0
     if 44 - 44: IIII
     if 54 - 54: o0oO0 - O0oO - Oooo0Ooo000 . iIii1I11I1II1
     if 79 - 79: o0oO0 . OoOO
     oO0OoO00o ( '[COLOR %s]Grandes Peliculas[/COLOR]' % iIIIi1 , IIIII11I1IiI , 30 , i1iiIIiiI111 , oo00 )
     if 40 - 40: o0000oOoOoO0o + ii11ii1ii . o0000oOoOoO0o % iI
     if 15 - 15: o0oO0 * ii11ii1ii % o00O0oo * iIii1I11I1II1 - i11iIiiIii
     if 60 - 60: OOooOOo * Oooo0Ooo000 % OoOO + oO0o0ooO0
     oO0OoO00o ( '[COLOR %s]Familiar[/COLOR]' % iIIIi1 , IIIII11I1IiI , 13 , ii11iIi1I , oo00 )
     if 52 - 52: i1IIi
     if 84 - 84: o0oO0 / i1I111II1I
     if 86 - 86: OoOO0ooOOoo0O * II111iiii - O0 . OoOO0ooOOoo0O % iIii1I11I1II1 / IIII
     if 11 - 11: OOooOOo * oO0o0ooO0 + o00O0oo / o00O0oo
     if 37 - 37: i11iIiiIii + i1IIi
     if 23 - 23: O0ooOooooO + O0oO . OoOO0ooOOoo0O * OOooOOo + o00O0oo
     if 18 - 18: i1I111II1I * o0000oOoOoO0o . i1I111II1I / O0
     if 8 - 8: o0000oOoOoO0o
     if 4 - 4: o00O0oo + o00O0oo * iI - OoOO0ooOOoo0O
     if 78 - 78: o0oO0 / II111iiii % OoOO0ooOOoo0O
     oO0OoO00o ( '[COLOR %s]Super heroes[/COLOR]' % iIIIi1 , IIIII11I1IiI , 24 , iIii1 , oo00 )
     oO0OoO00o ( '[COLOR %s]4k[/COLOR] En pruebas' % iIIIi1 , IIIII11I1IiI , 141 , O0o0Oo , oo00 )
     if 52 - 52: IIII - O0ooOooooO * oO0o0ooO0
     if 17 - 17: OoooooooOO + IIII * O0oO * OoOO0ooOOoo0O
     if 36 - 36: O0 + ii11ii1ii
 except :
  pass
  if 5 - 5: ii11ii1ii * OoOO0ooOOoo0O
  if 46 - 46: iI
def I11iIiII ( ) :
 if 66 - 66: ii11ii1ii - o0000oOoOoO0o * i1I111II1I + OoOO0ooOOoo0O + o0000oOoOoO0o - iIii1I11I1II1
 try :
  if 17 - 17: oO0o0ooO0
  iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
  OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 22 - 22: O0oO + iIii1I11I1II1
  Ooo0O = IiIi ( I1iIIiiIIi1i )
  OOOOO0O00 = re . compile ( oOooO0 ) . findall ( Ooo0O )
  for o0oo0000OO , O0oOOo0Oo , o000O000 in OOOOO0O00 :
   if re . search ( OOO00O , o000O000 ) :
    if 24 - 24: OoOO0ooOOoo0O % i1IIi + O0ooOooooO . i11iIiiIii . o00O0oo
    if iiII1i1 == o0oo0000OO and o00oOO0o == O0oOOo0Oo and OOO00O == o000O000 :
     if 17 - 17: o00O0oo . II111iiii . iI / o00O0oo
     oO0OoO00o ( '[COLOR %s]Buscar Serie[/COLOR]' % iIIIi1 , 'search' , 145 , O0OO00o0OO , oo00 )
     if 57 - 57: O0oO
     oO0oO00oOo0OOO ( )
     if 23 - 23: i1IIi . o0000oOoOoO0o * OoOO
     oO0OoO00o ( '[COLOR %s]En emision[/COLOR]' % iIIIi1 , IIIII11I1IiI , 150 , I11II1i , oo00 )
     oO0OoO00o ( '[COLOR %s]Mejor valoradas[/COLOR]' % iIIIi1 , IIIII11I1IiI , 151 , IIIII , oo00 )
     oO0OoO00o ( '[COLOR %s]Series Retro[/COLOR]' % iIIIi1 , IIIII11I1IiI , 152 , ooooooO0oo , oo00 )
     oO0OoO00o ( '[COLOR %s]Todas[/COLOR]' % iIIIi1 , IIIII11I1IiI , 142 , I11i1 , oo00 )
     if 15 - 15: OoOO0ooOOoo0O
     if 62 - 62: o0oO0
 except :
  pass
  if 51 - 51: OoOO0ooOOoo0O
  if 14 - 14: i1I111II1I % oO0o0ooO0 % ii11ii1ii - i11iIiiIii
  if 53 - 53: o0oO0 % ii11ii1ii
def oO0oO00oOo0OOO ( ) :
 if 59 - 59: IIII % iIii1I11I1II1 . i1IIi + II111iiii * i1I111II1I
 i1IiiI1iIi = 'aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtLw==' . decode ( 'base64' )
 oOOo00O0OOOo = 'Y29uZGljaW9uLnR4dA==' . decode ( 'base64' )
 oOOOO = i1IiiI1iIi + oOOo00O0OOOo
 i11I1I1iiI = '[\'"](.*?)[\'"]'
 I11iIiII = IiIi ( oOOOO )
 OOOOO0O00 = re . compile ( i11I1I1iiI ) . findall ( I11iIiII )
 for I1i1iii1Ii in OOOOO0O00 :
  try :
   if 23 - 23: i11iIiiIii
   if I1i1iii1Ii == 'si' or I1i1iii1Ii == 'Si' :
    if 39 - 39: o0000oOoOoO0o - o00O0oo % O0ooOooooO * OoOO - IIII / O0ooOooooO
    oO0OoO00o ( '[COLOR lime]+[/COLOR][COLOR %s] Hay Nuevos Episodios[/COLOR]' % iIIIi1 , IIIII11I1IiI , 155 , OOOO , oo00 )
    if 29 - 29: o00O0oo
   elif I1i1iii1Ii == 'no' or I1i1iii1Ii == 'No' :
    if 52 - 52: i11iIiiIii / i1IIi
    oO0OoO00o ( '[COLOR red]+[/COLOR][COLOR %s] No hay Nuevos Episodios[/COLOR]' % iIIIi1 , IIIII11I1IiI , 155 , oOoOooOo0o0 , oo00 )
    if 1 - 1: iI
   return
   if 78 - 78: o00O0oo + O0oO - O0
  except :
   pass
   if 10 - 10: Oooo0Ooo000 % OOooOOo
def oo0OoOooo ( ) :
 if 95 - 95: i1I111II1I * o00O0oo % iI % o0oO0 - o0oO0
 if 97 - 97: o00O0oo + iIii1I11I1II1 . O0
 try :
  if 64 - 64: i1IIi % iI / i11iIiiIii - i1IIi % IIII . O0ooOooooO
  II1i111 = IiIi ( iiI )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( II1i111 )
  for Iii in OOOOO0O00 :
   if 50 - 50: i1I111II1I % i1IIi
   try :
    if 21 - 21: OoooooooOO - iIii1I11I1II1
    OO0OoOOO0 = Iii
    ooO = xbmc . Keyboard ( '' , 'Buscar' )
    ooO . doModal ( )
    if ( ooO . isConfirmed ( ) ) :
     ii = xbmcgui . DialogProgress ( )
     ii . create ( 'Realstream:' , 'Buscando ...' )
     OO0O0Ooo = range ( 0 , 69 )
     for oOoO0 in OO0O0Ooo :
      oOoO0 = oOoO0 + 1
     Oo00o0OO0O00o = urllib . quote_plus ( ooO . getText ( ) ) . replace ( '+' , ' ' )
     O0Oooo = IiIi ( OO0OoOOO0 )
     OOOOO0O00 = re . compile ( OoO ) . findall ( O0Oooo )
     for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
      ii . update ( oOoO0 , '[COLOR orange]Realstream: Buscando ...[/COLOR]' , '[COLOR gold] %s [/COLOR]' % I1i11111i1i11 )
      xbmc . sleep ( 5 )
      if ii . iscanceled ( ) : break ;
      if re . search ( Oo00o0OO0O00o , iIi1i1iIi1iI ( I1i11111i1i11 . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       if 80 - 80: o0000oOoOoO0o - IIII + OoooooooOO
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Generando listado ...  [COLOR orange] Por favor espere ![/COLOR] , 4000)" )
       O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 143 , O00ooOo , oo00 , I1IIIiIiIi )
       ii . update ( 100 , '[COLOR orange]Realstream: [/COLOR]' , '[COLOR gold] Busqueda finalizada ...[/COLOR]' )
       xbmc . sleep ( 2000 )
       ii . close ( )
     oO0OoO00o ( '[COLOR %s]Buscar Serie[/COLOR]' % iIIIi1 , 'search' , 145 , O0OO00o0OO , oo00 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Sin Resultados para: [COLOR orange]" + Oo00o0OO0O00o + "[/COLOR] , 2000)" )
     if 26 - 26: OoOO0ooOOoo0O / ii11ii1ii - i1IIi + O0oO
     if 38 - 38: OoooooooOO / o00O0oo . O0 / i1IIi / ii11ii1ii + iIii1I11I1II1
   except : oO0OoO00o ( '[COLOR %s]Buscar Serie[/COLOR]' % iIIIi1 , 'search' , 145 , O0OO00o0OO , oo00 )
   if 96 - 96: O0ooOooooO
 except :
  pass
  if 18 - 18: O0ooOooooO * O0oO - o0oO0
def II1i1III ( ) :
 if 34 - 34: Oooo0Ooo000 - i11iIiiIii / iIii1I11I1II1
 try :
  if 87 - 87: o00O0oo / OoooooooOO - ii11ii1ii % OoOO0ooOOoo0O % i1I111II1I % ii11ii1ii
  II1i111 = IiIi ( IIi1IIIi )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( II1i111 )
  for Iii in OOOOO0O00 :
   if 29 - 29: OoooooooOO . OOooOOo % o00O0oo - O0ooOooooO
   try :
    if 8 - 8: i1IIi
    OO0OoOOO0 = Iii
    if 32 - 32: oO0o0ooO0 / II111iiii
   except :
    pass
    if 45 - 45: o00O0oo + OoOO * i11iIiiIii / IIII % O0oO * O0
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( OoO ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 17 - 17: O0
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 143 , O00ooOo , oo00 , I1IIIiIiIi )
    if 88 - 88: ii11ii1ii . O0 % OoooooooOO / IIII
   except :
    pass
 except :
  pass
  if 89 - 89: II111iiii / oO0o0ooO0
def IIo0OoO00 ( ) :
 if 18 - 18: oO0o0ooO0 - o0000oOoOoO0o - OOooOOo - OOooOOo
 try :
  if 54 - 54: ii11ii1ii + OOooOOo / O0ooOooooO . OOooOOo * OoOO0ooOOoo0O
  II1i111 = IiIi ( oOoO00o )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( II1i111 )
  for Iii in OOOOO0O00 :
   if 1 - 1: OoOO0ooOOoo0O * OoOO . i1IIi / ii11ii1ii . o00O0oo + ii11ii1ii
   try :
    if 17 - 17: ii11ii1ii + OoOO / o0oO0 / O0ooOooooO * IIII
    OO0OoOOO0 = Iii
    if 29 - 29: OoOO % OoooooooOO * oO0o0ooO0 / II111iiii - oO0o0ooO0
   except :
    pass
    if 19 - 19: i11iIiiIii
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( OoO ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 54 - 54: II111iiii . O0oO
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 143 , O00ooOo , oo00 , I1IIIiIiIi )
    if 73 - 73: OoOO0ooOOoo0O . OOooOOo
   except :
    pass
 except :
  pass
  if 32 - 32: OoOO0ooOOoo0O * OOooOOo % iI * o0oO0 . O0
  if 48 - 48: O0ooOooooO * O0ooOooooO
def I1I1 ( ) :
 if 4 - 4: o0000oOoOoO0o % OoOO0ooOOoo0O * IIII
 try :
  if 32 - 32: i11iIiiIii - Oooo0Ooo000
  II1i111 = IiIi ( ooO0OoOO )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( II1i111 )
  for Iii in OOOOO0O00 :
   if 53 - 53: OoooooooOO - i1I111II1I
   try :
    if 87 - 87: oO0o0ooO0 . OOooOOo
    OO0OoOOO0 = Iii
    if 17 - 17: o0oO0 . i11iIiiIii
   except :
    pass
    if 5 - 5: o00O0oo + O0 + O0 . Oooo0Ooo000 - iI
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( OoO ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 63 - 63: oO0o0ooO0
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 143 , O00ooOo , oo00 , I1IIIiIiIi )
    if 71 - 71: i1IIi . o0oO0 * O0ooOooooO % OoooooooOO + IIII
   except :
    pass
 except :
  pass
  if 36 - 36: i1I111II1I
def i1iiI ( ) :
 if 74 - 74: Oooo0Ooo000 % o00O0oo
 try :
  if 7 - 7: II111iiii
  II1i111 = IiIi ( i1iI1 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( II1i111 )
  for Iii in OOOOO0O00 :
   if 27 - 27: oO0o0ooO0 . OoooooooOO + i11iIiiIii
   try :
    if 86 - 86: O0oO / o0000oOoOoO0o - o0000oOoOoO0o + o00O0oo + oO0o0ooO0
    OO0OoOOO0 = Iii
    if 33 - 33: o0000oOoOoO0o . O0ooOooooO . i1I111II1I . i1IIi
   except :
    pass
    if 49 - 49: o00O0oo
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( OoO ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 84 - 84: O0oO - ii11ii1ii / O0 - Oooo0Ooo000
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 143 , O00ooOo , oo00 , I1IIIiIiIi )
    if 21 - 21: O0 * O0 % o00O0oo
   except :
    pass
 except :
  pass
  if 94 - 94: O0oO + II111iiii % i11iIiiIii
def i1i1IiIiIi1Ii ( ) :
 if 64 - 64: IIII + OoooooooOO * OoooooooOO
 try :
  if 41 - 41: iI . ii11ii1ii + OOooOOo
  II1i111 = IiIi ( iiI )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( II1i111 )
  for Iii in OOOOO0O00 :
   if 100 - 100: o0oO0 + OoOO
   try :
    if 73 - 73: i1IIi - Oooo0Ooo000 % iI / OoOO
    OO0OoOOO0 = Iii
    if 40 - 40: o00O0oo * iI - OOooOOo / i1I111II1I / i11iIiiIii
   except :
    pass
    if 83 - 83: o00O0oo / Oooo0Ooo000 - i11iIiiIii . iIii1I11I1II1 + ii11ii1ii
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( OoO ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 59 - 59: O0 % ii11ii1ii
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 143 , O00ooOo , oo00 , I1IIIiIiIi )
    if 92 - 92: o0oO0 % O0ooOooooO / o00O0oo % o00O0oo * OOooOOo
   except :
    pass
 except :
  pass
  if 74 - 74: O0 . OOooOOo % OoOO % i1I111II1I
def oOo0OooOo ( name , url ) :
 if 51 - 51: O0oO . ii11ii1ii
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 45 - 45: i1IIi - ii11ii1ii / O0 . o00O0oo
 iI1 = IiIi ( url )
 OOOOO0O00 = re . compile ( iiiIi1 ) . findall ( iI1 )
 for O00ooOo , name , oo00 , url in OOOOO0O00 :
  try :
   if 14 - 14: o00O0oo
   if 49 - 49: oO0o0ooO0 / i1IIi % o0oO0 . OOooOOo
   O00OOOoOoo0O = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % O00OOOoOoo0O + name + '[/COLOR]'
   oOOoOoo0O0 ( name , url , 144 , O00ooOo , oo00 )
   if 45 - 45: i11iIiiIii
   if 82 - 82: o0oO0 + i1I111II1I
  except :
   pass
   if 12 - 12: Oooo0Ooo000
   if 93 - 93: i11iIiiIii % iIii1I11I1II1 % i11iIiiIii + o0000oOoOoO0o / o0000oOoOoO0o / II111iiii
   if 49 - 49: IIII . o00O0oo . i11iIiiIii - II111iiii / o0oO0
def oOOoOoo0O0 ( name , url , mode , iconimage , fanart ) :
 if 62 - 62: IIII
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 1 - 1: i1I111II1I / i1I111II1I - i11iIiiIii
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage="
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 iII . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 iII . setProperty ( 'fanart_image' , fanart )
 iII . setProperty ( 'IsPlayable' , 'true' )
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII )
 return oO0O000oOoo0O
 if 9 - 9: oO0o0ooO0 * i1IIi - i1IIi
 if 16 - 16: OOooOOo * i1IIi - o0000oOoOoO0o . i1I111II1I % O0oO / o0000oOoOoO0o
def Ii11iI1ii1111 ( name , url ) :
 if 42 - 42: Oooo0Ooo000 + Oooo0Ooo000 * II111iiii
 if 78 - 78: OoooooooOO
 IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 o00O0 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 oOO0O00Oo0O0o = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 OOoo0 = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 iiII1i11i = IiIi ( oOO0O00Oo0O0o )
 OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
 for III1I1I in OOOOO0O00 :
  if 14 - 14: o0oO0 . i11iIiiIii
  try :
   if 27 - 27: iI % O0 % Oooo0Ooo000
   if 99 - 99: OOooOOo + i1IIi + i11iIiiIii + ii11ii1ii % oO0o0ooO0 / O0oO
   IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 60 - 60: o0oO0 * OoOO0ooOOoo0O - i11iIiiIii % iI
   if 52 - 52: o00O0oo % oO0o0ooO0 - i11iIiiIii
   if IIIi1I1IIii1II == III1I1I :
    if 30 - 30: O0ooOooooO / OoOO + oO0o0ooO0
    if 6 - 6: O0ooOooooO . O0oO + o0oO0 . Oooo0Ooo000
    if 'https://team.com' in url :
     if 70 - 70: OoOO
     url = url . replace ( 'https://team.com' , 'https://verystream.com' )
     if 46 - 46: O0oO - i1IIi
    if 'https://mybox.com' in url :
     if 46 - 46: Oooo0Ooo000 % o0oO0
     url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
     if 72 - 72: iIii1I11I1II1
     if 45 - 45: ii11ii1ii - o0000oOoOoO0o % Oooo0Ooo000
    if 'https://vidcloud.co/' in url :
     if 38 - 38: Oooo0Ooo000 % IIII - OoooooooOO
     url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
     if 87 - 87: OoOO % OOooOOo
    if 'https://gounlimited.to' in url :
     if 77 - 77: iIii1I11I1II1 - i1IIi . oO0o0ooO0
     url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
     if 26 - 26: o0000oOoOoO0o * i1I111II1I . i1IIi
    if 'https://drive.com' in url :
     if 59 - 59: O0 + i1IIi - o0000oOoOoO0o
     url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
     if 62 - 62: i11iIiiIii % IIII . i1I111II1I . IIII
     if 84 - 84: i11iIiiIii * OoOO
    import resolveurl
    if 18 - 18: IIII - o0oO0 - OoOO0ooOOoo0O / Oooo0Ooo000 - O0
    iiIIii = resolveurl . HostedMediaFile ( url )
    if 70 - 70: o0000oOoOoO0o - IIII
    if not iiIIii :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
     return False
     if 62 - 62: O0oO
    try :
     ii = xbmcgui . DialogProgress ( )
     ii . create ( 'Realstream:' , 'Iniciando ...' )
     ii . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
     xbmc . sleep ( 1000 )
     O000oOo = iiIIii . resolve ( )
     if not O000oOo or not isinstance ( O000oOo , basestring ) :
      try : OoOOOO = O000oOo . msg
      except : OoOOOO = url
      raise Exception ( OoOOOO )
      if 18 - 18: iI % i11iIiiIii . iIii1I11I1II1 - O0ooOooooO
    except Exception as Ii :
     try : OoOOOO = str ( Ii )
     except : OoOOOO = url
     ii . update ( 45 , 'RESOLVEURL:' , 'Reiniciando ... ' )
     xbmc . sleep ( 1000 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Episodio no disponible.  ,3000)" )
     ii . close ( )
     if 80 - 80: OOooOOo + oO0o0ooO0 - i1IIi . o0oO0 / o0000oOoOoO0o / OOooOOo
    ii . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    ii . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
    xbmc . sleep ( 500 )
    ii . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
    xbmc . sleep ( 500 )
    ii . update ( 100 , 'RESOLVEURL:' , 'Disfrute de este capitulo!' )
    ii . close ( )
    O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
    I1Iiii = xbmcgui . ListItem ( path = O000oOo )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1Iiii )
    if 34 - 34: o0oO0 * OoOO0ooOOoo0O - i1I111II1I - OOooOOo - o0oO0
    if 42 - 42: II111iiii * OOooOOo % i1IIi - o0oO0 % i1I111II1I
   else :
    if 36 - 36: i11iIiiIii / oO0o0ooO0 * o00O0oo * o00O0oo + o0oO0 * O0oO
    O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
    if O0ii1ii1ii == 'true' :
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Por favor compruebe los ajustes de realstream.[/COLOR]" , "[COLOR white] Desde la seccion Tutoriales puede sacarle mayor partido a su Realstream, tambien puede configurarlo a su gusto. [/COLOR]" , "[COLOR gold]El addon no esta activado o bien configurado.[/COLOR]" )
     if 32 - 32: OoOO
     iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
     oO0OoO00o ( '[COLOR %s]Video tutoriales[/COLOR]' % iIIIi1 , IIIII11I1IiI , 125 , O0OOO0OOoO0O , oo00 )
  except :
   pass
   if 50 - 50: iI + i1IIi
   if 31 - 31: o0oO0
   if 78 - 78: i11iIiiIii + o0000oOoOoO0o + Oooo0Ooo000 / o0000oOoOoO0o % iIii1I11I1II1 % i1I111II1I
   if 83 - 83: iIii1I11I1II1 % OoOO0ooOOoo0O % o0000oOoOoO0o % Oooo0Ooo000 . o00O0oo % O0
iIiIi1ii = '10011hI' . replace ( '10011hI' , '1hI' )
iiiiiII = 'aHR0cDovL2JpdC5seS8yUUJQ' . decode ( 'base64' ) + iIiIi1ii
ii1ii = '1001j1G' . replace ( '1001j1G' , 'j1G' )
IIiI1i = 'aHR0cDovL2JpdC5seS8zNXpw' . decode ( 'base64' ) + ii1ii
iII1 = '1001N00' . replace ( '1001N00' , 'N00' )
O000O = 'aHR0cDovL2JpdC5seS8zMGRS' . decode ( 'base64' ) + iII1
Oo00OO0 = '1001Q7q' . replace ( '1001Q7q' , 'Q7q' )
oo0O = 'aHR0cDovL2JpdC5seS8zN1Bi' . decode ( 'base64' ) + Oo00OO0
oO00OoOOOo = '1001K0z' . replace ( '1001K0z' , 'K0z' )
Oo0 = 'aHR0cDovL2JpdC5seS8yU2NS' . decode ( 'base64' ) + oO00OoOOOo
o0OOOOO0O = '1001TTi' . replace ( '1001TTi' , 'TTi' )
I1I1IiIi1 = 'aHR0cDovL2JpdC5seS8zNkhT' . decode ( 'base64' ) + o0OOOOO0O
oOO0o0oo0 = '011057w' . replace ( '011057w' , '57w' )
iiiiI = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0Q5TXl1' . decode ( 'base64' ) + oOO0o0oo0
if 78 - 78: IIII + O0ooOooooO . i1I111II1I
def OoIIi1iI ( ) :
 if 92 - 92: OoOO * iI
 if 35 - 35: i11iIiiIii
 try :
  if 99 - 99: II111iiii . o0000oOoOoO0o + O0
  II1i111 = IiIi ( iiiiiII )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( II1i111 )
  for Iii in OOOOO0O00 :
   if 71 - 71: i1I111II1I + i1IIi * ii11ii1ii % ii11ii1ii / ii11ii1ii
   try :
    if 55 - 55: OoooooooOO + Oooo0Ooo000 + OoooooooOO * iI
    OO0OoOOO0 = Iii
    ooO = xbmc . Keyboard ( '' , 'Buscar' )
    ooO . doModal ( )
    if ( ooO . isConfirmed ( ) ) :
     ii = xbmcgui . DialogProgress ( )
     ii . create ( 'Realstream:' , 'Buscando ...' )
     OO0O0Ooo = range ( 0 , 69 )
     for oOoO0 in OO0O0Ooo :
      oOoO0 = oOoO0 + 1
     Oo00o0OO0O00o = urllib . quote_plus ( ooO . getText ( ) ) . replace ( '+' , ' ' )
     O0Oooo = IiIi ( OO0OoOOO0 )
     OOOOO0O00 = re . compile ( I1iI1 ) . findall ( O0Oooo )
     for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
      ii . update ( oOoO0 , '[COLOR orange]Realstream: Buscando ...[/COLOR]' , '[COLOR gold] %s [/COLOR]' % I1i11111i1i11 )
      xbmc . sleep ( 5 )
      if ii . iscanceled ( ) : break ;
      if re . search ( Oo00o0OO0O00o , iIi1i1iIi1iI ( I1i11111i1i11 . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       if 68 - 68: O0
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Generando listado ...  [COLOR orange] Por favor espere ![/COLOR] , 4000)" )
       O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 147 , O00ooOo , oo00 , I1IIIiIiIi )
       ii . update ( 100 , '[COLOR orange]Realstream: [/COLOR]' , '[COLOR gold] Busqueda finalizada ...[/COLOR]' )
       xbmc . sleep ( 2000 )
       ii . close ( )
     oO0OoO00o ( '[COLOR %s]Buscar Pelicula[/COLOR]' % iIIIi1 , 'search' , 146 , O0OO00o0OO , oo00 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Sin Resultados para: [COLOR orange]" + Oo00o0OO0O00o + "[/COLOR] , 2000)" )
     if 2 - 2: OoOO + O0 * OoOO - o0oO0 + oO0o0ooO0
     if 43 - 43: o00O0oo - OoOO0ooOOoo0O
   except : oO0OoO00o ( '[COLOR %s]Buscar Pelicula[/COLOR]' % iIIIi1 , 'search' , 146 , O0OO00o0OO , oo00 )
   if 36 - 36: o00O0oo - O0ooOooooO
 except :
  pass
  if 24 - 24: o0000oOoOoO0o + iI + O0oO - iIii1I11I1II1
def I11Oo0oO00 ( ) :
 if 8 - 8: OOooOOo % OOooOOo . OoOO0ooOOoo0O % o0000oOoOoO0o
 try :
  if 47 - 47: iI + II111iiii % Oooo0Ooo000 . O0oO % o00O0oo
  II1i111 = IiIi ( iiiiiII )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( II1i111 )
  for Iii in OOOOO0O00 :
   if 7 - 7: O0 / O0ooOooooO * oO0o0ooO0
   try :
    if 29 - 29: o0000oOoOoO0o
    OO0OoOOO0 = Iii
    if 86 - 86: II111iiii . i1I111II1I
   except :
    pass
    if 2 - 2: OoooooooOO
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( I1iI1 ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 60 - 60: OoOO
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 147 , O00ooOo , oo00 , I1IIIiIiIi )
    if 81 - 81: OoOO0ooOOoo0O % o0oO0
   except :
    pass
 except :
  pass
  if 87 - 87: iIii1I11I1II1 . OoooooooOO * OoOO0ooOOoo0O
  if 100 - 100: OoOO / i1IIi - OOooOOo % o0oO0 - iIii1I11I1II1
  if 17 - 17: O0oO / o0000oOoOoO0o % ii11ii1ii
def o0oo00o0O0O00 ( ) :
 if 34 - 34: IIII . ii11ii1ii
 try :
  if 78 - 78: o00O0oo % OOooOOo / OoooooooOO % IIII - O0ooOooooO
  II1i111 = IiIi ( IIiI1i )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( II1i111 )
  for Iii in OOOOO0O00 :
   if 2 - 2: iIii1I11I1II1
   try :
    if 45 - 45: OoooooooOO / i11iIiiIii
    OO0OoOOO0 = Iii
    if 10 - 10: O0ooOooooO - oO0o0ooO0 * iIii1I11I1II1 % iIii1I11I1II1 * i1I111II1I - o00O0oo
   except :
    pass
    if 97 - 97: II111iiii % Oooo0Ooo000 + Oooo0Ooo000 - OoOO / o0oO0 * OOooOOo
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( I1iI1 ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 17 - 17: o0oO0
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 147 , O00ooOo , oo00 , I1IIIiIiIi )
    if 39 - 39: iI . II111iiii
   except :
    pass
 except :
  pass
  if 45 - 45: oO0o0ooO0 * OoOO0ooOOoo0O / iIii1I11I1II1
def o00ooOoO0 ( ) :
 if 15 - 15: IIII * O0oO / o00O0oo * o0000oOoOoO0o
 try :
  if 94 - 94: O0ooOooooO + o0oO0 % o0000oOoOoO0o
  III1I1II1iI = IiIi ( Oo0 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( III1I1II1iI )
  for Iii in OOOOO0O00 :
   if 97 - 97: OoOO0ooOOoo0O
   try :
    if 77 - 77: i11iIiiIii / OoooooooOO + i1I111II1I % oO0o0ooO0
    OO0OoOOO0 = Iii
    if 36 - 36: oO0o0ooO0
   except :
    pass
    if 74 - 74: OoooooooOO
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( I1iI1 ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 72 - 72: O0 + OOooOOo - O0ooOooooO - OoOO
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 147 , O00ooOo , oo00 , I1IIIiIiIi )
    if 100 - 100: O0
   except :
    pass
 except :
  pass
  if 79 - 79: iIii1I11I1II1
def O00oO0o ( ) :
 if 15 - 15: Oooo0Ooo000 + O0oO . OoooooooOO . i11iIiiIii
 try :
  if 31 - 31: OoooooooOO + O0ooOooooO - OoOO0ooOOoo0O . i1IIi % O0ooOooooO
  II1i111 = IiIi ( O000O )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( II1i111 )
  for Iii in OOOOO0O00 :
   if 43 - 43: IIII * iI / iIii1I11I1II1 - o0oO0 * o0oO0
   try :
    if 60 - 60: iIii1I11I1II1 . IIII + o00O0oo
    OO0OoOOO0 = Iii
    if 44 - 44: O0 . oO0o0ooO0 * i11iIiiIii % i11iIiiIii + O0 / IIII
   except :
    pass
    if 89 - 89: o0oO0 % i1IIi % oO0o0ooO0
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( I1iI1 ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 53 - 53: oO0o0ooO0 * OoooooooOO . OoOO0ooOOoo0O
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 147 , O00ooOo , oo00 , I1IIIiIiIi )
    if 96 - 96: OOooOOo % i1IIi . o0000oOoOoO0o . O0
   except :
    pass
 except :
  pass
  if 37 - 37: i1IIi - IIII % OoooooooOO / IIII % iI
def iiIiII11i1 ( ) :
 if 93 - 93: OoOO0ooOOoo0O % iIii1I11I1II1
 try :
  if 90 - 90: OOooOOo - IIII / o0oO0 / O0 / O0oO
  oOO0 = IiIi ( I1I1IiIi1 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( oOO0 )
  for Iii in OOOOO0O00 :
   if 15 - 15: ii11ii1ii + O0oO . iI - iIii1I11I1II1 / O0 % iIii1I11I1II1
   try :
    if 86 - 86: OOooOOo / oO0o0ooO0 * o0oO0
    OO0OoOOO0 = Iii
    if 64 - 64: iI / O0 * OoOO0ooOOoo0O * iI
   except :
    pass
    if 60 - 60: O0oO / i1IIi % o00O0oo / o00O0oo * o00O0oo . i11iIiiIii
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( I1iI1 ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 99 - 99: OoOO0ooOOoo0O
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 147 , O00ooOo , oo00 , I1IIIiIiIi )
    if 77 - 77: o0000oOoOoO0o
   except :
    pass
 except :
  pass
  if 48 - 48: OoOO0ooOOoo0O % o00O0oo / O0oO . iIii1I11I1II1 * II111iiii
def oo000oO ( ) :
 if 78 - 78: o0oO0 + OoOO0ooOOoo0O + i1I111II1I - i1I111II1I . i11iIiiIii / OoOO
 try :
  if 27 - 27: o0oO0 - O0 % O0oO * Oooo0Ooo000 . i1I111II1I % iIii1I11I1II1
  II1i111 = IiIi ( oo0O )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( II1i111 )
  for Iii in OOOOO0O00 :
   if 37 - 37: OoooooooOO + O0 - i1IIi % iI
   try :
    if 24 - 24: OoOO0ooOOoo0O
    OO0OoOOO0 = Iii
    if 94 - 94: i1IIi * i1IIi % II111iiii + IIII
   except :
    pass
    if 28 - 28: OOooOOo
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( I1iI1 ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 49 - 49: O0oO . o0000oOoOoO0o % oO0o0ooO0 / o0oO0
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 147 , O00ooOo , oo00 , I1IIIiIiIi )
    if 95 - 95: O0 * OoOO0ooOOoo0O * i1I111II1I . iI / iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 28 - 28: i1I111II1I + oO0o0ooO0 - iI / iIii1I11I1II1 - OOooOOo
def Ii1i1 ( ) :
 if 65 - 65: oO0o0ooO0 + o00O0oo / IIII
 try :
  if 85 - 85: iIii1I11I1II1 / OoooooooOO % II111iiii
  II1i111 = IiIi ( iiiiI )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( II1i111 )
  for Iii in OOOOO0O00 :
   if 49 - 49: i11iIiiIii % OoOO0ooOOoo0O + Oooo0Ooo000 . II111iiii % O0ooOooooO * IIII
   try :
    if 67 - 67: i1IIi
    OO0OoOOO0 = Iii
    if 5 - 5: II111iiii . OoooooooOO
   except :
    pass
    if 57 - 57: OOooOOo
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( I1iI1 ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 35 - 35: OoooooooOO - Oooo0Ooo000 / OoOO
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 147 , O00ooOo , oo00 , I1IIIiIiIi )
    if 50 - 50: OoOO0ooOOoo0O
   except :
    pass
 except :
  pass
  if 33 - 33: O0oO
def oOo00OoO0O ( ) :
 if 69 - 69: iIii1I11I1II1 * OOooOOo - O0ooOooooO + O0 + O0
 try :
  if 65 - 65: Oooo0Ooo000 / i11iIiiIii / OoOO - IIII
  IiI1 = IiIi ( O0o0oO )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( IiI1 )
  for Iii in OOOOO0O00 :
   if 91 - 91: i1I111II1I . ii11ii1ii + II111iiii
   try :
    if 36 - 36: O0 * OoOO % O0ooOooooO * O0ooOooooO / OoOO * i1I111II1I
    OO0OoOOO0 = Iii
    if 14 - 14: i1IIi . i1I111II1I + O0 * iI
   except :
    pass
    if 76 - 76: OoOO
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( I1iI1 ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 92 - 92: O0oO - iIii1I11I1II1 % OoooooooOO
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 147 , O00ooOo , oo00 , I1IIIiIiIi )
    if 39 - 39: O0ooOooooO . OOooOOo * OoOO0ooOOoo0O - i11iIiiIii
   except :
    pass
 except :
  pass
  if 1 - 1: O0ooOooooO * OoOO0ooOOoo0O
def OO0ooo0 ( ) :
 if 7 - 7: o00O0oo - oO0o0ooO0 * IIII + o0000oOoOoO0o . o00O0oo
 try :
  if 85 - 85: O0
  iiII1i11i = IiIi ( IiIi11iI )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 32 - 32: OoooooooOO . OoOO / ii11ii1ii * o0000oOoOoO0o / o0000oOoOoO0o * o0oO0
   try :
    if 19 - 19: o0oO0
    OO0OoOOO0 = Iii
    if 55 - 55: IIII % IIII / O0 % O0ooOooooO - o0000oOoOoO0o . ii11ii1ii
   except :
    pass
    if 49 - 49: iIii1I11I1II1 * i1IIi . OoooooooOO
    if 90 - 90: o0000oOoOoO0o % o00O0oo - iIii1I11I1II1 % OoOO0ooOOoo0O
    if 8 - 8: OoOO0ooOOoo0O * ii11ii1ii / i1I111II1I % o0oO0 - OOooOOo
  O0Oooo = IiIi ( OO0OoOOO0 )
  OOOOO0O00 = re . compile ( I1iI1 ) . findall ( O0Oooo )
  for O00ooOo , I1i11111i1i11 , oo00 , OOoOOO0 , I1IIIiIiIi in OOOOO0O00 :
   try :
    if 71 - 71: O0ooOooooO
    O0ooOoO ( I1i11111i1i11 , OOoOOO0 , 147 , O00ooOo , oo00 , I1IIIiIiIi )
    if 23 - 23: i1IIi . iIii1I11I1II1 . IIII . O0 % o0oO0 % i11iIiiIii
   except :
    pass
 except :
  pass
  if 11 - 11: O0 - II111iiii . IIII . o0oO0 % Oooo0Ooo000
def IIi1 ( name , url ) :
 if 95 - 95: OoooooooOO + O0oO - o00O0oo / o00O0oo . i1IIi . OoooooooOO
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 29 - 29: iI - i1IIi . O0oO - o00O0oo + iI + OoooooooOO
 iI1 = IiIi ( url )
 OOOOO0O00 = re . compile ( i1I1ii11i1Iii ) . findall ( iI1 )
 for O00ooOo , name , oo00 , url , id in OOOOO0O00 :
  try :
   if 36 - 36: i1IIi / iI . iIii1I11I1II1
   O00OOOoOoo0O = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % O00OOOoOoo0O + name + '[/COLOR]'
   i1IiiiiIi1I ( name , url , 130 , O00ooOo , oo00 , id )
   if 56 - 56: OoooooooOO * O0
   if 85 - 85: OoooooooOO % OoOO0ooOOoo0O * iIii1I11I1II1
  except :
   pass
   if 44 - 44: iIii1I11I1II1 . o00O0oo + Oooo0Ooo000 . iI
def i1IiiiiIi1I ( name , url , mode , iconimage , fanart , id ) :
 if 7 - 7: o00O0oo + iIii1I11I1II1 * O0oO * O0oO / II111iiii - o0oO0
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 65 - 65: oO0o0ooO0 + OoOO0ooOOoo0O + II111iiii
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + "&id=" + str ( id )
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 iII . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 iII . setProperty ( 'fanart_image' , fanart )
 iII . setProperty ( 'IsPlayable' , 'true' )
 oOOoo = [ ]
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  oOOoo . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 6 - 6: IIII
  iII . addContextMenuItems ( oOOoo , replaceItems = True )
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII )
 return oO0O000oOoo0O
 if 98 - 98: OoooooooOO % O0 - O0
def OoOOoO0O0oO ( ) :
 if 92 - 92: ii11ii1ii / i11iIiiIii + o00O0oo
 if 87 - 87: OoOO0ooOOoo0O % iIii1I11I1II1
 o0OO0OOO0O = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 o0OO0OOO0O . doModal ( )
 if not o0OO0OOO0O . isConfirmed ( ) :
  return None ;
 I1i11111i1i11 = o0OO0OOO0O . getText ( ) . strip ( )
 if 36 - 36: i11iIiiIii / O0ooOooooO . O0oO + i1I111II1I . O0 + OOooOOo
 if 36 - 36: i1IIi - o00O0oo - Oooo0Ooo000
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 7 - 7: i11iIiiIii + OOooOOo
  I1i1I1II = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + I1i11111i1i11 + '&language=es-ES' ) )
  if 58 - 58: IIII . o0000oOoOoO0o + OOooOOo % ii11ii1ii - OoOO
  if 50 - 50: O0ooOooooO % II111iiii - iI . i1IIi + O0 % O0ooOooooO
  return 'android'
  if 10 - 10: O0ooOooooO . i1IIi + o0oO0
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 66 - 66: OoOO % o0000oOoOoO0o
  I1i1I1II = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + I1i11111i1i11 + '&language=es-ES' )
  if 21 - 21: OoOO0ooOOoo0O - OoooooooOO % i11iIiiIii
  if 71 - 71: i1IIi - O0oO * Oooo0Ooo000 + oO0o0ooO0 - OoOO % o00O0oo
  return 'windows'
  if 63 - 63: iIii1I11I1II1 + IIII . OoOO / OOooOOo
  if 84 - 84: i1IIi
def IiIIiii1I ( ) :
 if 56 - 56: i11iIiiIii - iIii1I11I1II1 . II111iiii
 try :
  if 81 - 81: i1I111II1I / OoOO0ooOOoo0O * i1I111II1I . O0
  iiII1i11i = IiIi ( iIiIi11 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 61 - 61: OoOO * IIII + Oooo0Ooo000 . iIii1I11I1II1 % O0oO . Oooo0Ooo000
   try :
    if 53 - 53: Oooo0Ooo000 * i1I111II1I / iIii1I11I1II1 / OOooOOo % o00O0oo
    all = Iii
    if 39 - 39: OoOO / OoooooooOO . OoOO * o00O0oo / OoOO0ooOOoo0O
   except :
    pass
    if 38 - 38: OoOO / iI % Oooo0Ooo000 * O0oO + i11iIiiIii % iI
  iI1 = IiIi ( all )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iI1 )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    if 61 - 61: Oooo0Ooo000 - o0oO0 % o00O0oo / iI / O0ooOooooO + iIii1I11I1II1
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 87 - 87: Oooo0Ooo000 + iI + O0 / i1IIi % i1I111II1I / Oooo0Ooo000
   except :
    pass
 except :
  pass
  if 64 - 64: OoOO % i1I111II1I . Oooo0Ooo000 % OoOO + O0oO * i1I111II1I
def OOOO00OooO ( ) :
 if 64 - 64: OoOO . OOooOOo - OoooooooOO . iI - O0ooOooooO
 try :
  if 77 - 77: o0oO0 % OoOO0ooOOoo0O / II111iiii % O0ooOooooO % OoooooooOO % OoOO
  iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
  OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 19 - 19: i1I111II1I * Oooo0Ooo000 / oO0o0ooO0 * Oooo0Ooo000 - OoooooooOO * O0oO
  Ooo0O = IiIi ( I1iIIiiIIi1i )
  OOOOO0O00 = re . compile ( oOooO0 ) . findall ( Ooo0O )
  for O0oOOo0Oo , o0oo0000OO , o000O000 in OOOOO0O00 :
   if re . search ( OOO00O , o000O000 ) :
    if 17 - 17: II111iiii + ii11ii1ii . Oooo0Ooo000
    if iiII1i1 == o0oo0000OO and o00oOO0o == O0oOOo0Oo and OOO00O == o000O000 :
     if 12 - 12: Oooo0Ooo000 + IIII + O0oO . i1I111II1I / o0oO0
     i1111 = IiIi ( iiiiI )
     OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( i1111 )
     for Iii in OOOOO0O00 :
      if 29 - 29: i1I111II1I . iI - II111iiii
      try :
       if 68 - 68: iIii1I11I1II1 + II111iiii / oO0o0ooO0
       OO0OoOOO0 = Iii
       if 91 - 91: OoOO0ooOOoo0O % iIii1I11I1II1 . OOooOOo
      except :
       pass
       if 70 - 70: O0oO % II111iiii % O0 . i1IIi / Oooo0Ooo000
     O0Oooo = IiIi ( OO0OoOOO0 )
     OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( O0Oooo )
     for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
      try :
       if 100 - 100: o00O0oo * i11iIiiIii % oO0o0ooO0 / ii11ii1ii / iI + o00O0oo
       IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
       if 59 - 59: Oooo0Ooo000 - i1I111II1I
      except :
       pass
       if 14 - 14: iIii1I11I1II1 - iIii1I11I1II1
    else :
     if 5 - 5: i1I111II1I
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Esta seccion ha sido cerrada![COLOR orange] Lo sentimos ...[/COLOR] ,5000)" )
     if 84 - 84: II111iiii * oO0o0ooO0 * II111iiii % i1I111II1I / OOooOOo
     return False
     if 100 - 100: i1I111II1I . o0oO0 - iIii1I11I1II1 . i11iIiiIii / II111iiii
 except :
  pass
  if 71 - 71: Oooo0Ooo000 * ii11ii1ii . O0oO
def i1ii1iiIi1II ( ) :
 if 98 - 98: OoOO - o0oO0 . i1I111II1I % i11iIiiIii
 try :
  if 69 - 69: o00O0oo + O0ooOooooO * O0 . IIII % OoOO0ooOOoo0O
  iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
  OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 96 - 96: iI . iI - O0oO / O0oO
  Ooo0O = IiIi ( I1iIIiiIIi1i )
  OOOOO0O00 = re . compile ( oOooO0 ) . findall ( Ooo0O )
  for o0oo0000OO , O0oOOo0Oo , o000O000 in OOOOO0O00 :
   if re . search ( OOO00O , o000O000 ) :
    if 96 - 96: i11iIiiIii / OOooOOo - O0 . iI
    if iiII1i1 == o0oo0000OO and o00oOO0o == O0oOOo0Oo and OOO00O == o000O000 :
     if 39 - 39: iI / O0 * i1I111II1I
     i11 = IiIi ( OOoO )
     OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( i11 )
     for Iii in OOOOO0O00 :
      if 17 - 17: o0oO0 / iIii1I11I1II1 - OoOO + OOooOOo % IIII
      try :
       III1III11II = Iii
      except :
       pass
       if 43 - 43: OOooOOo
     iiII1i11i = IiIi ( III1III11II )
     OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
     for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
      try :
       if 47 - 47: OoooooooOO % OoOO0ooOOoo0O
       IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
       if 63 - 63: OoOO / OoOO0ooOOoo0O * iIii1I11I1II1 . Oooo0Ooo000
      except :
       pass
       if 85 - 85: i11iIiiIii / i11iIiiIii . OoOO . O0
    else :
     if 67 - 67: II111iiii / o0000oOoOoO0o . IIII . OoooooooOO
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Esta seccion ha sido cerrada![COLOR orange] Lo sentimos ...[/COLOR] ,5000)" )
     if 19 - 19: i1I111II1I . o00O0oo / OoOO0ooOOoo0O
     return False
 except :
  pass
  if 68 - 68: iI / OoooooooOO * O0oO / oO0o0ooO0
  if 88 - 88: o0000oOoOoO0o
  if 1 - 1: OoooooooOO
def I1III1I11Iii ( ) :
 if 2 - 2: i11iIiiIii
 try :
  if 98 - 98: oO0o0ooO0 / OoOO - o0oO0 - OOooOOo / OoOO0ooOOoo0O + i11iIiiIii
  iiII1i1 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  o00oOO0o = IiII1IiiIiI1 . getSetting ( 'mail' )
  OOO00O = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 17 - 17: O0oO
  Ooo0O = IiIi ( I1iIIiiIIi1i )
  OOOOO0O00 = re . compile ( oOooO0 ) . findall ( Ooo0O )
  for O0oOOo0Oo , o0oo0000OO , o000O000 in OOOOO0O00 :
   if re . search ( OOO00O , o000O000 ) :
    if 97 - 97: o00O0oo * o00O0oo / O0ooOooooO
    if iiII1i1 == o0oo0000OO and o00oOO0o == O0oOOo0Oo and OOO00O == o000O000 :
     if 6 - 6: oO0o0ooO0
     iiII1i11i = IiIi ( db2 )
     OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
     for Iii in OOOOO0O00 :
      if 72 - 72: O0oO * o00O0oo - OoOO0ooOOoo0O / o00O0oo + IIII - O0ooOooooO
      try :
       if 49 - 49: OoOO - O0 / OoOO * OoOO0ooOOoo0O + Oooo0Ooo000
       Iiii1I = Iii
       if 61 - 61: iIii1I11I1II1 - O0oO / O0ooOooooO * O0oO % o0oO0 % O0ooOooooO
      except :
       pass
       if 63 - 63: IIII % iIii1I11I1II1
       if 20 - 20: OoOO . OOooOOo * i11iIiiIii / i11iIiiIii
     iiII1i11i = IiIi ( Iiii1I )
     OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
     for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
      try :
       IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
       if 89 - 89: O0ooOooooO . i11iIiiIii * O0
      except :
       pass
    else :
     if 44 - 44: i1IIi . OOooOOo / i11iIiiIii + i1I111II1I
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Esta seccion ha sido cerrada![COLOR orange] Lo sentimos ...[/COLOR] ,5000)" )
     if 27 - 27: IIII
     return False
     if 52 - 52: Oooo0Ooo000 % OoOO0ooOOoo0O + iIii1I11I1II1 * oO0o0ooO0 . o0oO0
 except :
  pass
  if 95 - 95: iIii1I11I1II1 . i1I111II1I - OoooooooOO * OoOO / o0000oOoOoO0o
def oOo0OO0o0 ( ) :
 if 35 - 35: ii11ii1ii . ii11ii1ii % OoooooooOO - o0oO0
 try :
  if 43 - 43: OoOO % OoOO
  IIiii11ii1i = IiIi ( OOo0O0oo0OO0O )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( IIiii11ii1i )
  for Iii in OOOOO0O00 :
   if 7 - 7: oO0o0ooO0 - O0 * O0oO - o0000oOoOoO0o - II111iiii
   try :
    if 41 - 41: OOooOOo - Oooo0Ooo000 % II111iiii . Oooo0Ooo000 - O0oO
    i1I111Ii = Iii
    if 31 - 31: OOooOOo
   except :
    pass
    if 73 - 73: iI . O0 / o0000oOoOoO0o - OoooooooOO % i11iIiiIii
    if 80 - 80: o0oO0 / iI % O0 . ii11ii1ii
  iiII1i11i = IiIi ( i1I111Ii )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    if 63 - 63: IIII . II111iiii . O0oO
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 46 - 46: iI % i1I111II1I - o0000oOoOoO0o - ii11ii1ii - o0oO0 / O0oO
   except :
    pass
 except :
  pass
  if 68 - 68: i1IIi - o00O0oo / ii11ii1ii % O0oO . O0ooOooooO
def iIIIIIIIiIII ( ) :
 if 94 - 94: O0ooOooooO * iIii1I11I1II1 . O0oO
 try :
  if 13 - 13: iIii1I11I1II1 * OoOO0ooOOoo0O / Oooo0Ooo000 % iI + oO0o0ooO0
  iiII1i11i = IiIi ( iiIiI1i1 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 41 - 41: o00O0oo
   try :
    if 5 - 5: ii11ii1ii
    o0oOo00 = Iii
    if 22 - 22: iIii1I11I1II1 + i1I111II1I + o00O0oo + Oooo0Ooo000 - o0oO0
   except :
    pass
    if 48 - 48: o0oO0 - OoOO0ooOOoo0O - OoOO + OOooOOo * o0oO0
    if 67 - 67: ii11ii1ii / iI - i1I111II1I
  iiII1i11i = IiIi ( o0oOo00 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 74 - 74: O0oO * o0oO0 - o00O0oo % iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 56 - 56: o00O0oo - O0
def o0o0oo0 ( ) :
 if 25 - 25: OoOO * oO0o0ooO0 % i11iIiiIii + i11iIiiIii * OoOO
 try :
  if 42 - 42: II111iiii / O0 . iIii1I11I1II1 / O0 / OoOO / OoooooooOO
  iiII1i11i = IiIi ( IiIi11iI )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 62 - 62: O0 . ii11ii1ii
   try :
    if 33 - 33: ii11ii1ii / iIii1I11I1II1 % i1IIi
    O0OooOO = Iii
    if 49 - 49: i1I111II1I / iI / IIII
   except :
    pass
    if 25 - 25: OOooOOo % O0 + i1IIi - iI
  iiII1i11i = IiIi ( O0OooOO )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 38 - 38: o0000oOoOoO0o % Oooo0Ooo000 + i11iIiiIii + O0ooOooooO + iI / i11iIiiIii
   except :
    pass
 except :
  pass
  if 94 - 94: O0ooOooooO - ii11ii1ii + oO0o0ooO0
def O0oooOoO ( ) :
 if 62 - 62: IIII / II111iiii + OoOO0ooOOoo0O % iI / OoOO0ooOOoo0O + o00O0oo
 try :
  if 2 - 2: i11iIiiIii - Oooo0Ooo000 + OoOO % O0oO * o0oO0
  iiII1i11i = IiIi ( i11I1IiII1i1i )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 54 - 54: O0 - O0ooOooooO . IIII % O0ooOooooO + O0ooOooooO
   try :
    if 36 - 36: IIII % i11iIiiIii
    Iiii1Ii = Iii
    if 62 - 62: i1IIi % OoOO0ooOOoo0O
   except :
    pass
    if 37 - 37: O0oO * i1IIi
    if 20 - 20: i1I111II1I + OoOO0ooOOoo0O - IIII - IIII - o00O0oo
  iiII1i11i = IiIi ( Iiii1Ii )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 7 - 7: O0
   except :
    pass
 except :
  pass
  if 26 - 26: o0000oOoOoO0o / OoooooooOO % iI % IIII
def oO0O0o0O ( ) :
 if 100 - 100: OoOO0ooOOoo0O % ii11ii1ii
 try :
  if 76 - 76: II111iiii / OoOO + OoooooooOO . o00O0oo . O0oO . iI
  iiII1i11i = IiIi ( I1111i )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 43 - 43: i1IIi
   try :
    if 17 - 17: O0 - OoOO0ooOOoo0O
    OOoooOoO0 = Iii
    if 95 - 95: o0oO0 - o00O0oo - O0 . OOooOOo . O0ooOooooO
   except :
    pass
    if 7 - 7: Oooo0Ooo000
    if 45 - 45: O0 - IIII
  iiII1i11i = IiIi ( OOoooOoO0 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 56 - 56: O0 + o0oO0
   except :
    pass
 except :
  pass
  if 24 - 24: i11iIiiIii - o0oO0 + oO0o0ooO0 * OOooOOo
def OoooOo0 ( ) :
 if 20 - 20: II111iiii - O0oO + i1IIi + o0oO0
 try :
  if 7 - 7: iI + o0oO0
  iiII1i11i = IiIi ( o00O0O )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 32 - 32: iIii1I11I1II1 % OOooOOo / i11iIiiIii + IIII - o0000oOoOoO0o . O0ooOooooO
   try :
    if 86 - 86: i1IIi / o0oO0 * OOooOOo
    OOoO0OOoO0ooo = Iii
    if 23 - 23: i1IIi - O0oO
   except :
    pass
    if 96 - 96: i1IIi % OoooooooOO
    if 99 - 99: i11iIiiIii . II111iiii . OoooooooOO
  iiII1i11i = IiIi ( OOoO0OOoO0ooo )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 59 - 59: i11iIiiIii . OoooooooOO / O0oO * o00O0oo + OoooooooOO
   except :
    pass
 except :
  pass
  if 3 - 3: i11iIiiIii * ii11ii1ii % iIii1I11I1II1 % OOooOOo * O0ooOooooO / IIII
def O00oo00oOOO0o ( ) :
 if 5 - 5: o0000oOoOoO0o / OOooOOo % o0oO0 . i1I111II1I
 try :
  if 86 - 86: i1IIi * OoOO0ooOOoo0O . O0 - o0oO0 - o0000oOoOoO0o - OoOO0ooOOoo0O
  iiII1i11i = IiIi ( o0Oooo )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 47 - 47: IIII + O0oO
   try :
    if 50 - 50: Oooo0Ooo000 + o00O0oo
    i1Ii = Iii
    if 89 - 89: ii11ii1ii * iIii1I11I1II1 - OoOO . ii11ii1ii
   except :
    pass
    if 59 - 59: OoOO - OoOO + O0ooOooooO
    if 32 - 32: i1IIi / ii11ii1ii - O0
  iiII1i11i = IiIi ( i1Ii )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 85 - 85: o0oO0 - O0 * i11iIiiIii . i1IIi
   except :
    pass
 except :
  pass
  if 20 - 20: O0ooOooooO / IIII
  if 28 - 28: iI * O0oO % i11iIiiIii * O0ooOooooO / o0oO0
def iIII1iIi ( ) :
 if 75 - 75: o0oO0 - O0oO % OoOO0ooOOoo0O
 try :
  if 80 - 80: o0oO0 / IIII
  iiII1i11i = IiIi ( Iii1I1111ii )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 21 - 21: ii11ii1ii - iIii1I11I1II1 - Oooo0Ooo000
   try :
    if 1 - 1: OOooOOo * IIII + o0oO0 + OOooOOo - i11iIiiIii
    O0o = Iii
    if 63 - 63: i1I111II1I - i1IIi * o0000oOoOoO0o + OoooooooOO
   except :
    pass
    if 11 - 11: i1I111II1I + iIii1I11I1II1 . i11iIiiIii - IIII
    if 49 - 49: iI . II111iiii
  iiII1i11i = IiIi ( O0o )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 24 - 24: O0 . OoooooooOO - OoOO * OoooooooOO
   except :
    pass
 except :
  pass
  if 12 - 12: O0 + i1I111II1I * i1IIi . OoOO
  if 71 - 71: Oooo0Ooo000 - o0000oOoOoO0o - IIII
def iiIO0OO0o0O00oO ( ) :
 if 81 - 81: i1I111II1I / O0oO
 try :
  if 46 - 46: o00O0oo / Oooo0Ooo000 + i1I111II1I / oO0o0ooO0 / Oooo0Ooo000 / IIII
  iiII1i11i = IiIi ( Ii1IIiI1i )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 73 - 73: iI + o00O0oo
   try :
    if 100 - 100: iIii1I11I1II1
    ooOOo00 = Iii
    if 39 - 39: ii11ii1ii * iIii1I11I1II1 . OOooOOo * OoOO0ooOOoo0O % O0
   except :
    pass
    if 55 - 55: iIii1I11I1II1 * O0ooOooooO
    if 85 - 85: iIii1I11I1II1 . II111iiii
  iiII1i11i = IiIi ( ooOOo00 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 54 - 54: o0oO0 . OoooooooOO % ii11ii1ii
   except :
    pass
    if 22 - 22: IIII
 except :
  pass
  if 22 - 22: O0ooOooooO * O0oO - ii11ii1ii * O0 / i11iIiiIii
  if 78 - 78: ii11ii1ii * O0 / iI + OoooooooOO + IIII
def I1iiIiiIiiI ( ) :
 if 94 - 94: i1IIi
 try :
  if 36 - 36: OOooOOo + ii11ii1ii
  iiII1i11i = IiIi ( IiII111i1i11 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 46 - 46: O0ooOooooO
   try :
    if 65 - 65: i1IIi . o00O0oo / iI
    I1i1I11111iI1 = Iii
    if 32 - 32: OOooOOo + o00O0oo - oO0o0ooO0 + o00O0oo / i1IIi * oO0o0ooO0
   except :
    pass
    if 90 - 90: o0oO0 % oO0o0ooO0
    if 6 - 6: OoooooooOO / i11iIiiIii / Oooo0Ooo000
  iiII1i11i = IiIi ( I1i1I11111iI1 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 60 - 60: OOooOOo % oO0o0ooO0 / o0000oOoOoO0o % oO0o0ooO0 * i11iIiiIii / O0ooOooooO
   except :
    pass
    if 34 - 34: Oooo0Ooo000 - IIII
 except :
  pass
  if 25 - 25: oO0o0ooO0 % OOooOOo + i11iIiiIii + O0 * OoooooooOO
def ooO0 ( ) :
 if 94 - 94: O0oO . OOooOOo
 try :
  if 73 - 73: i1IIi / II111iiii
  iiII1i11i = IiIi ( oooO )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 45 - 45: o0oO0 / iI . OoooooooOO + OoOO
   try :
    if 51 - 51: O0ooOooooO % i11iIiiIii % i1I111II1I + Oooo0Ooo000 % o00O0oo
    IIIIIiiiiI1I = Iii
    if 93 - 93: ii11ii1ii * oO0o0ooO0 + OoOO - Oooo0Ooo000 . o00O0oo + OoooooooOO
   except :
    pass
    if 44 - 44: O0oO * o0000oOoOoO0o
  iiII1i11i = IiIi ( IIIIIiiiiI1I )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 49 - 49: IIII % O0oO * i11iIiiIii / oO0o0ooO0 % IIII
   except :
    pass
 except :
  pass
  if 70 - 70: OoOO0ooOOoo0O / II111iiii % iI - O0ooOooooO
  if 2 - 2: Oooo0Ooo000 - o00O0oo + o0000oOoOoO0o * OoOO / O0ooOooooO
def iIIiI11iI1Ii1 ( ) :
 if 94 - 94: iI / i11iIiiIii % O0
 try :
  if 70 - 70: O0oO - ii11ii1ii / OoooooooOO % OoooooooOO
  iiII1i11i = IiIi ( ooo )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 95 - 95: OoooooooOO % OoooooooOO . o0oO0
   try :
    if 26 - 26: oO0o0ooO0 + i1I111II1I - II111iiii . II111iiii + o00O0oo + OoOO0ooOOoo0O
    o0IiIiI111IIII1 = Iii
    if 100 - 100: IIII * O0 + OOooOOo + OoOO0ooOOoo0O . IIII
   except :
    pass
    if 73 - 73: oO0o0ooO0 . II111iiii * O0ooOooooO % oO0o0ooO0 + OoOO0ooOOoo0O - OoOO
    if 19 - 19: O0ooOooooO * ii11ii1ii . O0ooOooooO . OoOO / OoOO - oO0o0ooO0
  iiII1i11i = IiIi ( o0IiIiI111IIII1 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 9 - 9: Oooo0Ooo000 * i1I111II1I * Oooo0Ooo000
   except :
    pass
 except :
  pass
  if 74 - 74: iIii1I11I1II1 / o0000oOoOoO0o
  if 58 - 58: iIii1I11I1II1 - OOooOOo % o0000oOoOoO0o % OoooooooOO * iIii1I11I1II1 + IIII
def iIiI1i111ii ( ) :
 if 48 - 48: iIii1I11I1II1 . O0oO - IIII . Oooo0Ooo000 * oO0o0ooO0 % oO0o0ooO0
 try :
  if 38 - 38: ii11ii1ii % o00O0oo - O0ooOooooO * iIii1I11I1II1 / O0
  iiII1i11i = IiIi ( Ooo0oOooo0 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 9 - 9: O0oO * ii11ii1ii . iI * i11iIiiIii - O0
   try :
    if 54 - 54: OOooOOo * IIII + o0000oOoOoO0o % i1IIi - o0000oOoOoO0o + OoOO0ooOOoo0O
    IIIIiI11Ii1i = Iii
    if 100 - 100: O0ooOooooO + O0oO + iI + O0ooOooooO / i1IIi
   except :
    pass
  iiII1i11i = IiIi ( IIIIiI11Ii1i )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 74 - 74: O0 % OoooooooOO * ii11ii1ii + IIII * O0ooOooooO
   except :
    pass
 except :
  pass
  if 100 - 100: IIII + o0oO0 * o0000oOoOoO0o + II111iiii
def oOo0O000Ooo0 ( ) :
 if 30 - 30: i1IIi
 try :
  if 75 - 75: O0oO . IIII - iIii1I11I1II1 * OoOO * O0ooOooooO
  iiII1i11i = IiIi ( iiIiIIIiiI )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 93 - 93: iI
   try :
    if 18 - 18: iI
    OOOooO00OO00O = Iii
    if 78 - 78: II111iiii - ii11ii1ii - O0 . IIII + i11iIiiIii - o00O0oo
   except :
    pass
    if 58 - 58: o0oO0 % OoooooooOO
    if 49 - 49: o00O0oo + O0 . o0oO0 * OoooooooOO
  iiII1i11i = IiIi ( OOOooO00OO00O )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 82 - 82: o00O0oo
   except :
    pass
 except :
  pass
  if 54 - 54: o0000oOoOoO0o + O0oO - iIii1I11I1II1 % iI % i1I111II1I
  if 19 - 19: o00O0oo / iIii1I11I1II1 % i1IIi . OoooooooOO
def O0oO0oo0O0 ( ) :
 if 66 - 66: IIII - iI - ii11ii1ii
 try :
  if 54 - 54: O0ooOooooO . i1IIi
  iiII1i11i = IiIi ( II11IiIi11 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 19 - 19: iI % oO0o0ooO0
   try :
    if 22 - 22: oO0o0ooO0 . II111iiii . ii11ii1ii
    ooIi111iII = Iii
    if 83 - 83: OoooooooOO + OoOO * oO0o0ooO0 . O0
   except :
    pass
    if 13 - 13: o0000oOoOoO0o
    if 7 - 7: OOooOOo + i1I111II1I / i11iIiiIii / ii11ii1ii
  iiII1i11i = IiIi ( ooIi111iII )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 97 - 97: Oooo0Ooo000 . O0oO / OOooOOo
   except :
    pass
 except :
  pass
  if 83 - 83: O0oO - o00O0oo * oO0o0ooO0
def oOO00OO0OooOo ( ) :
 if 13 - 13: O0 % iI % O0oO
 try :
  if 25 - 25: OoooooooOO % o0oO0 * II111iiii - OoOO
  iiII1i11i = IiIi ( I1iiii1I )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 95 - 95: OOooOOo % Oooo0Ooo000 * OOooOOo + O0 . Oooo0Ooo000 % OoooooooOO
   try :
    if 6 - 6: OoOO0ooOOoo0O - iI * o0000oOoOoO0o + OoOO0ooOOoo0O % o0000oOoOoO0o
    OOO00000o0 = Iii
    if 96 - 96: o0000oOoOoO0o * oO0o0ooO0 - IIII * o0000oOoOoO0o * i1IIi
   except :
    pass
    if 8 - 8: iI - ii11ii1ii + iIii1I11I1II1 + i1IIi * o0oO0 - iIii1I11I1II1
    if 30 - 30: O0oO / o00O0oo
  iiII1i11i = IiIi ( OOO00000o0 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 22 - 22: oO0o0ooO0 * O0ooOooooO
   except :
    pass
 except :
  pass
  if 4 - 4: OoOO0ooOOoo0O - oO0o0ooO0 + OOooOOo
  if 36 - 36: i1I111II1I
def iIi ( ) :
 if 52 - 52: iIii1I11I1II1
 try :
  if 49 - 49: IIII
  iiII1i11i = IiIi ( oO00ooooO0o )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 23 - 23: OoOO / O0ooOooooO / iIii1I11I1II1
   try :
    if 44 - 44: ii11ii1ii . ii11ii1ii + OoooooooOO * i11iIiiIii / O0oO + Oooo0Ooo000
    iIiII11 = Iii
    if 33 - 33: o0000oOoOoO0o * O0ooOooooO * iIii1I11I1II1 + i11iIiiIii . OoooooooOO
   except :
    pass
    if 51 - 51: IIII / iI + OoOO % OoOO0ooOOoo0O / o0oO0
    if 25 - 25: o0000oOoOoO0o
  iiII1i11i = IiIi ( iIiII11 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 25 - 25: iI * O0ooOooooO / O0oO / O0oO % o0000oOoOoO0o
   except :
    pass
 except :
  pass
  if 19 - 19: oO0o0ooO0 - iIii1I11I1II1 / iI . OoOO * O0 - O0
  if 41 - 41: i1IIi - OOooOOo
def IiiiIIiii ( ) :
 if 6 - 6: OoOO0ooOOoo0O / iIii1I11I1II1 * Oooo0Ooo000 / OOooOOo + O0
 try :
  if 2 - 2: OOooOOo * ii11ii1ii % o0000oOoOoO0o % ii11ii1ii
  iiII1i11i = IiIi ( o0oO0oooOoo )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 66 - 66: i1I111II1I + iIii1I11I1II1
   try :
    if 75 - 75: o00O0oo
    O00o = Iii
    if 55 - 55: iI % O0oO / i11iIiiIii
   except :
    pass
    if 20 - 20: i1I111II1I / Oooo0Ooo000 * i1I111II1I * OoOO
    if 72 - 72: OoOO . o0000oOoOoO0o * o00O0oo . iIii1I11I1II1 % o00O0oo . o0oO0
  iiII1i11i = IiIi ( O00o )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 70 - 70: IIII + iI * o0oO0 . o0oO0 + OoOO
   except :
    pass
 except :
  pass
  if 28 - 28: i1IIi . IIII
  if 88 - 88: O0oO + OOooOOo - O0oO / OoooooooOO - i11iIiiIii
def i11Ii1IiIIIi ( ) :
 if 71 - 71: OoOO % OOooOOo - O0ooOooooO . O0ooOooooO
 try :
  if 22 - 22: iI / iI - o0oO0 % O0oO . IIII + i1I111II1I
  iiII1i11i = IiIi ( I1i111I )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 64 - 64: i1IIi % o00O0oo / o0oO0 % OoooooooOO
   try :
    if 24 - 24: Oooo0Ooo000 + OoooooooOO . i1I111II1I / OoOO0ooOOoo0O / O0oO
    ooOoo = Iii
    if 91 - 91: o0000oOoOoO0o . O0ooOooooO % ii11ii1ii - O0ooOooooO . oO0o0ooO0 % i11iIiiIii
   except :
    pass
    if 25 - 25: iIii1I11I1II1
    if 63 - 63: iI
  iiII1i11i = IiIi ( ooOoo )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 96 - 96: O0oO
   except :
    pass
 except :
  pass
  if 34 - 34: OoOO0ooOOoo0O / OoOO - OOooOOo . O0 . IIII
  if 63 - 63: O0ooOooooO
def i1i1iIiI ( ) :
 if 23 - 23: i1I111II1I + iIii1I11I1II1 % iIii1I11I1II1 / iI . oO0o0ooO0 + iIii1I11I1II1
 try :
  if 93 - 93: oO0o0ooO0 * o0000oOoOoO0o / IIII - IIII . O0ooOooooO / OOooOOo
  iiII1i11i = IiIi ( I1i11 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 11 - 11: Oooo0Ooo000 - O0oO % i11iIiiIii . iIii1I11I1II1 * OOooOOo - ii11ii1ii
   try :
    if 73 - 73: O0 + iI - O0 / OoooooooOO * ii11ii1ii
    iI1I1IiIII = Iii
    if 54 - 54: o00O0oo + o00O0oo + O0oO % i1IIi % i11iIiiIii
   except :
    pass
    if 100 - 100: o00O0oo
  iiII1i11i = IiIi ( iI1I1IiIII )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 96 - 96: OOooOOo . i1I111II1I * II111iiii % i1I111II1I . Oooo0Ooo000 * i1IIi
   except :
    pass
 except :
  pass
  if 83 - 83: iIii1I11I1II1
  if 97 - 97: i11iIiiIii + ii11ii1ii * IIII % O0ooOooooO . i1I111II1I
def iiOo0 ( ) :
 if 75 - 75: OoOO / o0oO0 + II111iiii % i1I111II1I . i11iIiiIii
 try :
  if 76 - 76: O0ooOooooO . i1I111II1I % O0ooOooooO - Oooo0Ooo000
  iiII1i11i = IiIi ( IiIIi1 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 51 - 51: OoooooooOO + o0000oOoOoO0o * iIii1I11I1II1 * oO0o0ooO0 / i1IIi
   try :
    if 19 - 19: O0ooOooooO - OoOO0ooOOoo0O % oO0o0ooO0 / OoooooooOO % O0ooOooooO
    ooOoOoO0 = Iii
    if 31 - 31: i11iIiiIii - iI / o00O0oo - o0oO0
   except :
    pass
    if 5 - 5: i11iIiiIii * ii11ii1ii
    if 29 - 29: o0oO0 / iI % O0oO
  iiII1i11i = IiIi ( ooOoOoO0 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 10 - 10: iIii1I11I1II1 % OoooooooOO % o00O0oo
   except :
    pass
 except :
  pass
  if 39 - 39: II111iiii * OoOO0ooOOoo0O . O0 * O0oO
def O0o0O0O0O ( ) :
 if 79 - 79: i1I111II1I + i1I111II1I + o0oO0
 try :
  if 39 - 39: O0 - OoooooooOO
  iiII1i11i = IiIi ( II1i11I )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 63 - 63: iIii1I11I1II1 % o0000oOoOoO0o * iI
   try :
    if 79 - 79: O0
    IiI = Iii
    if 9 - 9: II111iiii % OoOO0ooOOoo0O
   except :
    pass
  iiII1i11i = IiIi ( IiI )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 26 - 26: iIii1I11I1II1 - o00O0oo . i1I111II1I . i1I111II1I + iIii1I11I1II1 * ii11ii1ii
   except :
    pass
 except :
  pass
  if 85 - 85: IIII + II111iiii - IIII * oO0o0ooO0 - i1IIi % O0ooOooooO
def IiIiI ( ) :
 if 47 - 47: OoOO0ooOOoo0O
 try :
  if 65 - 65: O0 + Oooo0Ooo000 % o0oO0 * OOooOOo / iI / OoOO0ooOOoo0O
  iiII1i11i = IiIi ( O0o0oO )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 71 - 71: i11iIiiIii / OoOO0ooOOoo0O . oO0o0ooO0
   try :
    if 33 - 33: oO0o0ooO0
    IIIi11 = Iii
    if 69 - 69: O0 - O0
   except :
    pass
  iiII1i11i = IiIi ( IIIi11 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 41 - 41: i1I111II1I % o0000oOoOoO0o
   except :
    pass
 except :
  pass
  if 67 - 67: O0 % Oooo0Ooo000
def III ( ) :
 if 48 - 48: IIII . IIII + i11iIiiIii + o00O0oo % O0
 try :
  if 67 - 67: iI / O0oO * OOooOOo % OoooooooOO
  iiII1i11i = IiIi ( Oo0o0O00 )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 46 - 46: i1I111II1I
   try :
    if 12 - 12: o0000oOoOoO0o + OoOO0ooOOoo0O . iIii1I11I1II1 % iI + i1IIi . iI
    IIIOo0o0O00 = Iii
    if 65 - 65: ii11ii1ii + o0000oOoOoO0o - o0oO0
   except :
    pass
  iiII1i11i = IiIi ( IIIOo0o0O00 )
  OOOOO0O00 = re . compile ( I1iII1iIi1I ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 , id , I1I1i , I1IIIiIiIi , oo00 in OOOOO0O00 :
   try :
    IiIii1i111 ( I1i11111i1i11 , OOoOOO0 , iiIi1i , id , I1I1i , I1IIIiIiIi , oo00 )
    if 12 - 12: OoooooooOO + o00O0oo
   except :
    pass
 except :
  pass
  if 55 - 55: IIII * II111iiii + oO0o0ooO0
def O0oOOOO00oOOo ( ) :
 if 29 - 29: OoOO0ooOOoo0O / OoooooooOO + OoOO0ooOOoo0O
 try :
  if 13 - 13: OoOO * O0oO % i11iIiiIii % i1IIi + i1I111II1I / II111iiii
  iiII1i11i = IiIi ( I11iiiiI1i )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for Iii in OOOOO0O00 :
   if 84 - 84: i1IIi + OoOO * OoooooooOO . O0ooOooooO + O0ooOooooO
   try :
    if 60 - 60: iI * iI / OoooooooOO
    OOoO0o0OOo0 = Iii
    if 51 - 51: O0ooOooooO % II111iiii - Oooo0Ooo000 - i1IIi
   except :
    pass
  iiII1i11i = IiIi ( OOoO0o0OOo0 )
  OOOOO0O00 = re . compile ( o0O ) . findall ( iiII1i11i )
  for iiIi1i , I1i11111i1i11 , OOoOOO0 in OOOOO0O00 :
   try :
    iIi11iI1i ( iiIi1i , I1i11111i1i11 , OOoOOO0 )
    if 46 - 46: i1IIi + II111iiii * i1IIi - o0oO0
   except :
    pass
    if 79 - 79: II111iiii - oO0o0ooO0 * o00O0oo - OoOO0ooOOoo0O . o00O0oo
 except :
  pass
  if 11 - 11: O0 * OoOO0ooOOoo0O
  if 37 - 37: OoOO0ooOOoo0O + O0 . O0 * ii11ii1ii % Oooo0Ooo000 / O0ooOooooO
  if 18 - 18: OoooooooOO
def iIi11iI1i ( thumb , name , url ) :
 if 57 - 57: iI . OoOO0ooOOoo0O * o0000oOoOoO0o - OoooooooOO
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 if 75 - 75: i11iIiiIii / o0000oOoOoO0o . i1I111II1I . i1IIi . i1IIi / O0oO
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   oO0OoO00o ( name , url , '' , o00 , oo00 )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 94 - 94: iI + OOooOOo
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 56 - 56: OoOO0ooOOoo0O % o0000oOoOoO0o
   i11i ( name , url , 4 , O00ooOo , oo00 )
   if 40 - 40: OOooOOo % iI % i1I111II1I + OoOO
  else :
   if 75 - 75: oO0o0ooO0 - o00O0oo + oO0o0ooO0 + OoooooooOO . i11iIiiIii
   i11i ( name , url , 4 , O00ooOo , oo00 )
   if 52 - 52: O0ooOooooO / iI - i11iIiiIii + OoooooooOO
def IiII1i ( name , url , thumb , id , trailer ) :
 if 32 - 32: OOooOOo
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 47 - 47: o00O0oo * oO0o0ooO0 + iIii1I11I1II1 - oO0o0ooO0 / i1I111II1I
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   oO0OoO00o ( name , url , '' , o00 , oo00 )
 else :
  O00OOOoOoo0O = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
  if 86 - 86: i1I111II1I
  name = '[COLOR %s]' % O00OOOoOoo0O + name + '[/COLOR]'
  if 43 - 43: OOooOOo / O0ooOooooO / iI + iIii1I11I1II1 + OoooooooOO
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   III1iII1I1ii = IiII1IiiIiI1 . getSetting ( 'selecton' )
   if III1iII1I1ii == 'true' :
    if 33 - 33: II111iiii - i1I111II1I - iI
    oO00oOoo00o0 ( name , url , 1 , thumb , thumb , id , trailer )
    if 41 - 41: oO0o0ooO0 / IIII + O0ooOooooO + iI
   else :
    if 13 - 13: i11iIiiIii - i11iIiiIii . iIii1I11I1II1
    oO00oOoo00o0 ( name , url , 130 , thumb , thumb , id , trailer )
    if 33 - 33: OoooooooOO + Oooo0Ooo000 / Oooo0Ooo000 + Oooo0Ooo000 * i1I111II1I
  else :
   if 26 - 26: Oooo0Ooo000 . OOooOOo . O0ooOooooO - OoooooooOO / iIii1I11I1II1
   if III1iII1I1ii == 'true' :
    if 47 - 47: i1I111II1I
    oO00oOoo00o0 ( name , url , 1 , thumb , thumb , id , trailer )
    if 76 - 76: OoOO * iIii1I11I1II1 + o00O0oo - iI - O0oO / i1IIi
   else :
    if 27 - 27: o00O0oo . i1I111II1I
    oO00oOoo00o0 ( name , url , 130 , thumb , thumb , id , trailer )
    if 66 - 66: O0 / O0 * i1IIi . OoooooooOO % iIii1I11I1II1
def IiIii1i111 ( name , url , thumb , id , trailer , description , fanart ) :
 if 21 - 21: i1I111II1I - OOooOOo % OoooooooOO + o0000oOoOoO0o
 if 92 - 92: iI + i1I111II1I
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . strip ( )
 O00OOOoOoo0O = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
 fanart = fanart . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 name = '[COLOR %s]' % O00OOOoOoo0O + name + '[/COLOR]'
 if 52 - 52: II111iiii / OOooOOo . oO0o0ooO0 * i1I111II1I . O0oO
 if 25 - 25: i11iIiiIii / OoOO0ooOOoo0O - Oooo0Ooo000 / OoOO . o0000oOoOoO0o . o0000oOoOoO0o
 if 'tvg-logo' in thumb :
  thumb = re . compile ( OO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  if III1iII1I1ii == 'true' :
   iI1iIIII1 ( name , url , 1 , thumb , fanart , id , trailer , description )
  else :
   if 65 - 65: O0 / II111iiii . iIii1I11I1II1 . oO0o0ooO0 / ii11ii1ii % iIii1I11I1II1
   iI1iIIII1 ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 74 - 74: i1IIi / OOooOOo % o00O0oo / O0 % O0oO - OoOO0ooOOoo0O
 else :
  if 31 - 31: OOooOOo / OoooooooOO . iIii1I11I1II1 * OoOO0ooOOoo0O . OoooooooOO + II111iiii
  if III1iII1I1ii == 'true' :
   if 8 - 8: o00O0oo * o00O0oo * i1IIi + O0ooOooooO . o00O0oo
   iI1iIIII1 ( name , url , 1 , thumb , fanart , id , trailer , description )
   if 100 - 100: OoooooooOO - O0 . O0oO / O0oO + II111iiii * OoOO0ooOOoo0O
  else :
   if 37 - 37: ii11ii1ii
   iI1iIIII1 ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 72 - 72: i1I111II1I % o00O0oo * IIII . i11iIiiIii % i1I111II1I * IIII
   if 15 - 15: O0oO / ii11ii1ii * O0oO
def I1111I1Ii ( name , trailer ) :
 if 68 - 68: OoOO + OOooOOo * o0000oOoOoO0o . oO0o0ooO0 + OoOO0ooOOoo0O + iI
 if O0ii1ii1ii == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Realstream, Reproduciendo Trailer de: [COLOR green]" + name + "[/COLOR] ,5000)" )
  if 80 - 80: OoOO0ooOOoo0O * IIII
  OOoOOO0 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  iIIii1iiiIiiI = OOoOOO0
  oOo0O = xbmcgui . ListItem ( name , trailer , path = iIIii1iiiIiiI )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOo0O )
 else :
  OOoOOO0 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  iIIii1iiiIiiI = OOoOOO0
  oOo0O = xbmcgui . ListItem ( name , trailer , path = iIIii1iiiIiiI )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOo0O )
  if 77 - 77: O0
  if 28 - 28: o00O0oo / i1IIi . ii11ii1ii + oO0o0ooO0 % iI + O0
def iI1iI ( name , url ) :
 if 69 - 69: o00O0oo . OOooOOo
 if O0ii1ii1ii == 'true' :
  if 9 - 9: o0000oOoOoO0o - i1I111II1I + iIii1I11I1II1 + OoOO
  try :
   if 32 - 32: OoOO0ooOOoo0O % OoOO + i11iIiiIii + iI - o0oO0 + oO0o0ooO0
   ii = xbmcgui . DialogProgress ( )
   ii . create ( 'Realstream:' , 'Iniciando ...' )
   ii . update ( 30 , 'Realstream:' , 'Conectando al servidor ...' )
   xbmc . sleep ( 1000 )
   ii . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   ii . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   ii . close ( )
   if 31 - 31: iIii1I11I1II1 - o0000oOoOoO0o
   iIIii1iiiIiiI = url
   oOo0O = xbmcgui . ListItem ( name , path = iIIii1iiiIiiI )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOo0O )
   if 57 - 57: ii11ii1ii % OoOO
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. ,3000)" )
  if 1 - 1: OoOO0ooOOoo0O * O0 . oO0o0ooO0 % O0 + II111iiii
 else :
  if 49 - 49: O0oO . IIII
  try :
   if 74 - 74: i1IIi
   ii = xbmcgui . DialogProgress ( )
   ii . create ( 'Realstream:' , 'Iniciando ...' )
   ii . update ( 30 , 'Realstream:' , 'Conectando al servidor ...' )
   xbmc . sleep ( 1000 )
   ii . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   ii . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   ii . close ( )
   if 15 - 15: i1IIi + i1I111II1I % OOooOOo / i11iIiiIii * OoOO0ooOOoo0O
   iIIii1iiiIiiI = url
   oOo0O = xbmcgui . ListItem ( name , path = iIIii1iiiIiiI )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOo0O )
   if 69 - 69: i11iIiiIii
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. ,3000)" )
  if 61 - 61: O0
 return
 if 21 - 21: OoOO % iIii1I11I1II1 . OoOO
 if 99 - 99: o0000oOoOoO0o * IIII % oO0o0ooO0 * oO0o0ooO0 + OoooooooOO
def O0OO ( trailer ) :
 if 30 - 30: OoOO0ooOOoo0O * ii11ii1ii % iIii1I11I1II1 % OoOO + i11iIiiIii
 if 'https://www.youtube.com' in trailer :
  if 46 - 46: OOooOOo . i1I111II1I - i11iIiiIii - Oooo0Ooo000
  try :
   if 97 - 97: II111iiii % ii11ii1ii * i1I111II1I
   import resolveurl
   if 51 - 51: ii11ii1ii % IIII . ii11ii1ii
   iiIIii = resolveurl . HostedMediaFile ( OOoOOO0 )
   ii = xbmcgui . DialogProgress ( )
   ii . create ( 'Realstream:' , 'Conectando al servidor ... ' )
   ii . update ( 20 , 'Por favor, espere ...' )
   xbmc . sleep ( 500 )
   if 72 - 72: o0oO0 % o0oO0 / OOooOOo
   if not iiIIii :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    return False
    if 40 - 40: ii11ii1ii - IIII + Oooo0Ooo000 - o0000oOoOoO0o % OOooOOo . iI
   try :
    if 35 - 35: i11iIiiIii + OoooooooOO * iIii1I11I1II1 . Oooo0Ooo000
    ii . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    O000oOo = iiIIii . resolve ( )
    if not O000oOo or not isinstance ( O000oOo , basestring ) :
     try : OoOOOO = O000oOo . msg
     except : OoOOOO = O000oOo
     raise Exception ( OoOOOO )
   except Exception as Ii :
    try : OoOOOO = str ( Ii )
    except : OoOOOO = O000oOo
    ii . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
    ii . close ( )
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    if 48 - 48: O0ooOooooO * i1IIi % OoooooooOO * o0oO0 * OoOO
   ii . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
   xbmc . sleep ( 500 )
   ii . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   ii . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
   xbmc . sleep ( 500 )
   ii . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   ii . close ( )
   if 7 - 7: O0ooOooooO . o0oO0 . O0ooOooooO - Oooo0Ooo000
   I1Iiii = xbmcgui . ListItem ( path = O000oOo )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1Iiii )
   if 33 - 33: iI + OoooooooOO - OoOO / i1IIi / OoooooooOO
  except :
   pass
   if 82 - 82: o00O0oo / IIII - O0ooOooooO / ii11ii1ii * OoOO
  else :
   if 55 - 55: OoooooooOO
   OOoOOO0 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
   iIIii1iiiIiiI = OOoOOO0
   oOo0O = xbmcgui . ListItem ( trailer , path = iIIii1iiiIiiI )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOo0O )
   return
   if 73 - 73: OoOO0ooOOoo0O - o00O0oo % ii11ii1ii + o00O0oo - O0 . OoOO
def i1iIii ( name , url ) :
 if 95 - 95: O0oO / i1I111II1I . O0 * i1I111II1I - o0000oOoOoO0o * ii11ii1ii
 if '[Youtube]' in name :
  if 6 - 6: OoOO0ooOOoo0O . II111iiii * OOooOOo . OOooOOo / o0oO0
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  iIIii1iiiIiiI = url
  oOo0O = xbmcgui . ListItem ( I1I1i , path = iIIii1iiiIiiI )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOo0O )
  if 14 - 14: Oooo0Ooo000 % i1I111II1I - O0 / Oooo0Ooo000
  if 91 - 91: i11iIiiIii % Oooo0Ooo000 * oO0o0ooO0 - o00O0oo . Oooo0Ooo000
 else :
  if 28 - 28: i11iIiiIii
  import resolveurl
  if 51 - 51: OOooOOo + iI * O0 . o0oO0
  iiIIii = resolveurl . HostedMediaFile ( url )
  if 82 - 82: IIII * o00O0oo % o0oO0 . IIII
  if not iiIIii :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 43 - 43: OoOO . iI * ii11ii1ii
   if 20 - 20: i1IIi . i1IIi - O0oO
  try :
   O000oOo = iiIIii . resolve ( )
   if not O000oOo or not isinstance ( O000oOo , basestring ) :
    try : OoOOOO = O000oOo . msg
    except : OoOOOO = url
    raise Exception ( OoOOOO )
  except Exception as Ii :
   try : OoOOOO = str ( Ii )
   except : OoOOOO = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 89 - 89: iI - O0oO . O0 % OoooooooOO . i11iIiiIii
  O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if O0ii1ii1ii == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  I1Iiii = xbmcgui . ListItem ( path = O000oOo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1Iiii )
  if 35 - 35: II111iiii / OoOO0ooOOoo0O - O0 . II111iiii
  if 55 - 55: ii11ii1ii % i1IIi * O0oO
 return
 if 95 - 95: IIII / II111iiii - o0000oOoOoO0o % Oooo0Ooo000 . O0oO
 if 63 - 63: iIii1I11I1II1 / iI
def II1i ( name , url ) :
 if 98 - 98: OoOO0ooOOoo0O - OoOO0ooOOoo0O . II111iiii . O0ooOooooO + O0
 if 'mybox.com' in url :
  if 28 - 28: i1I111II1I + i11iIiiIii + OoooooooOO / OoOO
  url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
  if 6 - 6: OOooOOo - i11iIiiIii
  try :
   if 61 - 61: Oooo0Ooo000 * o00O0oo % OOooOOo % OoOO % O0oO + O0oO
   iiII1i11i = IiIi ( url )
   OOOOO0O00 = re . compile ( O0OO0O ) . findall ( iiII1i11i )
   for url , i1111I , OoO00oo0 in OOOOO0O00 :
    if 96 - 96: i1IIi
    i1111I = i1111I . replace ( '","res":"1080",' , '' ) . replace ( '","res":"720",' , '' ) . replace ( '","res":"480",' , '' ) . replace ( '","res":"360",' , '' )
    url = url . replace ( '\/' , '/' )
    url = url . replace ( ',"type":"video/mp4",' , ' ' )
    name = '[COLOR white]' + i1111I + '[/COLOR] - [COLOR gold]' + OoO00oo0 + '[/COLOR]'
    if 55 - 55: oO0o0ooO0 + IIII + o0oO0
    OOoiII1I1i = [ ]
    OOoiII1I1i . append ( '[COLOR orange]Real Stream: [/COLOR][COLOR gold]1. Mostrar mas info. [Reiniciar][/COLOR]' )
    OOoiII1I1i . append ( '[COLOR gold]2. Mostar otras calidades disponibles [/COLOR]' )
    OOoiII1I1i . append ( '[COLOR gold]3. Ver en: %s [/COLOR]' % name )
    if 6 - 6: oO0o0ooO0 / O0 / o0oO0 / i1I111II1I / oO0o0ooO0 . iIii1I11I1II1
    if 62 - 62: iIii1I11I1II1
    IIi1i1ii11I1 = 'Seleccione una calidad e idioma:'
    oOoO0OO = xbmcgui . Dialog ( )
    o0OOO = oOoO0OO . select ( IIi1i1ii11I1 , OOoiII1I1i )
    if 48 - 48: OoooooooOO - Oooo0Ooo000 . i11iIiiIii * O0ooOooooO - o0oO0 - o0000oOoOoO0o
    if 59 - 59: O0ooOooooO / O0oO . ii11ii1ii
    if 100 - 100: O0
    if o0OOO == 0 :
     if 94 - 94: o00O0oo - o0000oOoOoO0o
     oO0O000oOoo0O = oOoO0OO . ok ( "[COLOR darkpink]REALSTREAM:[/COLOR] " , "[COLOR gold]  Reiniciadas las opciones.  [/COLOR]" , "" )
     del oOoO0OO
     return
     if 42 - 42: o0000oOoOoO0o * OoOO0ooOOoo0O . OoOO - O0ooOooooO / II111iiii
    elif o0OOO == 1 :
     if 25 - 25: ii11ii1ii % OoOO0ooOOoo0O
     pass
     if 75 - 75: i1IIi
     del oOoO0OO
     if 74 - 74: ii11ii1ii + Oooo0Ooo000 - oO0o0ooO0 - OoOO + O0ooOooooO - iIii1I11I1II1
     if 54 - 54: o00O0oo + II111iiii . OOooOOo / OoOO . iI
    elif o0OOO == 2 :
     if 58 - 58: i1I111II1I % i11iIiiIii * II111iiii . o00O0oo
     iI1iI ( name , url )
     if 94 - 94: i11iIiiIii . IIII + iIii1I11I1II1 * Oooo0Ooo000 * Oooo0Ooo000
     return
     if 36 - 36: O0oO - i1I111II1I . i1I111II1I
  except :
   pass
   if 60 - 60: i11iIiiIii * ii11ii1ii % OoOO + OoOO
 elif 'uptostream.com' in url :
  if 84 - 84: iIii1I11I1II1 + OoooooooOO
  try :
   if 77 - 77: O0 * o00O0oo * oO0o0ooO0 + OoOO + o00O0oo - Oooo0Ooo000
   iiII1i11i = IiIi ( url )
   OOOOO0O00 = re . compile ( O0OO0O ) . findall ( iiII1i11i )
   for url , i1111I , OoO00oo0 in OOOOO0O00 :
    if 10 - 10: o00O0oo + i1I111II1I
    i1111I = i1111I . replace ( '","res":"1080",' , '' ) . replace ( '","res":"720",' , '' ) . replace ( '","res":"480",' , '' ) . replace ( '","res":"360",' , '' )
    url = url . replace ( '\/' , '/' )
    url = url . replace ( ',"type":"video/mp4",' , ' ' )
    name = '[COLOR white]Calidad: ' + i1111I + '[/COLOR] [COLOR gold]Idioma: ' + OoO00oo0 + '[/COLOR]'
    if 58 - 58: OOooOOo + OoooooooOO / O0ooOooooO . iI % o0000oOoOoO0o / o00O0oo
    OOoiII1I1i = [ ]
    OOoiII1I1i . append ( '[COLOR white]Reiniciar calidades disponibles[/COLOR]' )
    OOoiII1I1i . append ( '[COLOR white]Otras calidades e idiomas[/COLOR]' )
    OOoiII1I1i . append ( '[COLOR white]Ver en: %s ' % name )
    if 62 - 62: II111iiii
    if 12 - 12: i1I111II1I + II111iiii
    IIi1i1ii11I1 = 'Seleccione una calidad e idioma:'
    oOoO0OO = xbmcgui . Dialog ( )
    o0OOO = oOoO0OO . select ( IIi1i1ii11I1 , OOoiII1I1i )
    if 92 - 92: Oooo0Ooo000 % iIii1I11I1II1 - O0ooOooooO / i11iIiiIii % iI * o0000oOoOoO0o
    if 80 - 80: O0ooOooooO
    if o0OOO == 0 :
     if 3 - 3: o00O0oo * O0oO
     oO0O000oOoo0O = oOoO0OO . ok ( "[COLOR darkpink]REALSTREAM:[/COLOR] " , "[COLOR gold]  Reiniciadas las opciones.  [/COLOR]" , "" )
     del oOoO0OO
     return
     if 53 - 53: iIii1I11I1II1 / O0ooOooooO % OoOO + i1I111II1I / iI
    elif o0OOO == 1 :
     if 74 - 74: ii11ii1ii
     pass
     if 8 - 8: OOooOOo % II111iiii - o0000oOoOoO0o - O0oO % OOooOOo
     del oOoO0OO
     if 93 - 93: o0oO0 * O0ooOooooO / IIII
     if 88 - 88: oO0o0ooO0
     if 1 - 1: ii11ii1ii
     if 95 - 95: OoooooooOO / O0oO % OoooooooOO / iI * i1I111II1I
    elif o0OOO == 2 :
     if 75 - 75: O0
     iI1iI ( name , url )
     if 56 - 56: OoOO / II111iiii
     return
     if 39 - 39: OoOO0ooOOoo0O - OoooooooOO - i1IIi / II111iiii
  except :
   pass
 else :
  if 49 - 49: ii11ii1ii + O0 + i1I111II1I . II111iiii % iI
  IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
  o00O0 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  oOO0O00Oo0O0o = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  OOoo0 = IiII1IiiIiI1 . getSetting ( 'key_ext' )
  iiII1i11i = IiIi ( oOO0O00Oo0O0o )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
  for III1I1I in OOOOO0O00 :
   if 33 - 33: OoOO0ooOOoo0O . iIii1I11I1II1 / O0oO % o0oO0
   try :
    if 49 - 49: OoOO + II111iiii / i1I111II1I - O0 % o0oO0
    if 27 - 27: OoOO + ii11ii1ii
    IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
    if 92 - 92: OOooOOo % O0ooOooooO
    if 31 - 31: OoooooooOO - oO0o0ooO0 / Oooo0Ooo000
    if IIIi1I1IIii1II == III1I1I :
     if 62 - 62: i11iIiiIii - O0oO
     if 81 - 81: O0oO
     if 'https://team.com' in url :
      if 92 - 92: IIII - ii11ii1ii - OoooooooOO / i1I111II1I - i1IIi
      url = url . replace ( 'https://team.com' , 'https://verystream.com' )
      if 81 - 81: i1IIi / Oooo0Ooo000 % i11iIiiIii . iIii1I11I1II1 * OoOO0ooOOoo0O + OoooooooOO
     if 'https://mybox.com' in url :
      if 31 - 31: i1IIi % II111iiii
      url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
      if 13 - 13: iIii1I11I1II1 - II111iiii % O0 . o0oO0 % OoOO
      if 2 - 2: OoooooooOO - o0oO0 % oO0o0ooO0 / OOooOOo / o0000oOoOoO0o
     if 'https://vidcloud.co/' in url :
      if 3 - 3: II111iiii / IIII
      url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
      if 48 - 48: iI . o00O0oo
     if 'https://gounlimited.to' in url :
      if 49 - 49: i1IIi - OoOO0ooOOoo0O . ii11ii1ii + iIii1I11I1II1 - iI / ii11ii1ii
      url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
      if 24 - 24: oO0o0ooO0 - O0ooOooooO / iI
     if 'https://drive.com' in url :
      if 10 - 10: OoOO0ooOOoo0O * i1IIi
      url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
      if 15 - 15: O0oO + i1IIi - II111iiii % OOooOOo
      if 34 - 34: OOooOOo
     import resolveurl
     if 57 - 57: IIII . o0oO0 % o0000oOoOoO0o
     iiIIii = resolveurl . HostedMediaFile ( url )
     if 32 - 32: O0oO / i1I111II1I - O0 * iIii1I11I1II1
     if 70 - 70: OoooooooOO % OoooooooOO % OoOO
     if 98 - 98: OoOO
     if 18 - 18: O0oO + ii11ii1ii - OoOO / Oooo0Ooo000 / IIII
     if not iiIIii :
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
      return False
      if 53 - 53: IIII + o0000oOoOoO0o . oO0o0ooO0 / O0oO
     try :
      if 52 - 52: Oooo0Ooo000 + Oooo0Ooo000
      ii = xbmcgui . DialogProgress ( )
      ii . create ( 'Realstream:' , 'Iniciando ...' )
      ii . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
      xbmc . sleep ( 1000 )
      if 73 - 73: o0000oOoOoO0o . i11iIiiIii % OoooooooOO + iI . OoooooooOO / IIII
      O000oOo = iiIIii . resolve ( )
      if not O000oOo or not isinstance ( O000oOo , basestring ) :
       if 54 - 54: OoOO0ooOOoo0O . OoooooooOO
       try : OoOOOO = O000oOo . msg
       except : OoOOOO = url
       raise Exception ( OoOOOO )
       if 36 - 36: oO0o0ooO0 / II111iiii * i1I111II1I % o00O0oo
     except Exception as Ii :
      try : OoOOOO = str ( Ii )
      except : OoOOOO = url
      if 31 - 31: II111iiii + IIII - OoooooooOO . O0oO
      if 28 - 28: o0oO0 . o00O0oo
      if 77 - 77: o00O0oo % II111iiii
      for OOo00o0oo0 in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       IIIIiII = 1
       ii . update ( 45 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % OOo00o0oo0 )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5  Puede cancelar cuando desee o esperar...,  1000)" % IIIIiII )
       ii . close ( )
       if 39 - 39: o0000oOoOoO0o / i1I111II1I - O0ooOooooO
      for OOo00o0oo0 in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       IIIIiII = 2
       ii . update ( 48 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % OOo00o0oo0 )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % IIIIiII )
       ii . close ( )
      for OOo00o0oo0 in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       IIIIiII = 3
       ii . update ( 50 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % OOo00o0oo0 )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % IIIIiII )
       ii . close ( )
      for OOo00o0oo0 in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       IIIIiII = 4
       ii . update ( 53 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % OOo00o0oo0 )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % IIIIiII )
       ii . close ( )
      for OOo00o0oo0 in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       IIIIiII = 5
       ii . update ( 55 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % OOo00o0oo0 )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % IIIIiII )
       ii . close ( )
       if 96 - 96: O0oO * o00O0oo * o0oO0 + o00O0oo % OOooOOo + i11iIiiIii
      if ii . iscanceled ( ) :
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Cancelando !! , 2000)" )
       ii . close ( )
       break
       if 37 - 37: O0oO % o00O0oo / iI
       if 94 - 94: O0oO / OoOO . o0000oOoOoO0o
       if 1 - 1: ii11ii1ii . II111iiii
     ii . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
     xbmc . sleep ( 500 )
     ii . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
     xbmc . sleep ( 1000 )
     ii . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
     ii . close ( )
     O0ii1ii1ii = IiII1IiiIiI1 . getSetting ( 'notificar' )
     I1Iiii = xbmcgui . ListItem ( path = O000oOo )
     xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1Iiii )
     if 93 - 93: II111iiii . i11iIiiIii + II111iiii % oO0o0ooO0
     if 98 - 98: Oooo0Ooo000 * oO0o0ooO0 * OoOO0ooOOoo0O + o0oO0 * O0ooOooooO
    else :
     if 4 - 4: i1I111II1I
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold] El addon no ha podido conectar al servidor.[/COLOR]" )
     return False
     if 16 - 16: iIii1I11I1II1 * O0ooOooooO + oO0o0ooO0 . O0 . o0000oOoOoO0o
   except :
    pass
    if 99 - 99: i11iIiiIii - O0ooOooooO
 return
 if 85 - 85: Oooo0Ooo000 % o00O0oo
 if 95 - 95: OoOO * IIII * O0ooOooooO . o0000oOoOoO0o
def oooOo00 ( ) :
 if 1 - 1: OOooOOo + o00O0oo
 Ooo0oO0 = [ ]
 OOo0I1i1ii1ii = sys . argv [ 2 ]
 if len ( OOo0I1i1ii1ii ) >= 2 :
  i1ii = sys . argv [ 2 ]
  oOOOOO0 = i1ii . replace ( '?' , '' )
  if ( i1ii [ len ( i1ii ) - 1 ] == '/' ) :
   i1ii = i1ii [ 0 : len ( i1ii ) - 2 ]
  IIi1I1 = oOOOOO0 . split ( '&' )
  Ooo0oO0 = { }
  for OOo00o0oo0 in range ( len ( IIi1I1 ) ) :
   oO00o0oOoo = { }
   oO00o0oOoo = IIi1I1 [ OOo00o0oo0 ] . split ( '=' )
   if ( len ( oO00o0oOoo ) ) == 2 :
    Ooo0oO0 [ oO00o0oOoo [ 0 ] ] = oO00o0oOoo [ 1 ]
 return Ooo0oO0
 if 66 - 66: o00O0oo . ii11ii1ii
 if 38 - 38: O0oO . i1I111II1I - OoOO . OOooOOo
def ooOoo0OOOO0o ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  pass
  if 38 - 38: OOooOOo % i1I111II1I * o0oO0
def O00OoO0 ( ) :
 oOoO0OO = xbmcgui . Dialog ( )
 list = (
 Oo00oo00o00Oo ,
 iiiiiii11III
 )
 if 48 - 48: Oooo0Ooo000 % O0ooOooooO % o0oO0 % iIii1I11I1II1 . o0oO0
 I11IIiI1IiI1 = oOoO0OO . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=%s]Accede a themoviedb.com[/COLOR]' % iIIIi1 ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 37 - 37: oO0o0ooO0 % Oooo0Ooo000 % oO0o0ooO0
 if I11IIiI1IiI1 :
  if 14 - 14: OoOO / OOooOOo
  if I11IIiI1IiI1 < 0 :
   return
  oO0o0 = list [ I11IIiI1IiI1 - 2 ]
  return oO0o0 ( )
 else :
  oO0o0 = list [ I11IIiI1IiI1 ]
  return oO0o0 ( )
 return
 if 43 - 43: IIII
def o0IiiIIII1I1i ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 26 - 26: O0ooOooooO - ii11ii1ii + OOooOOo + o0000oOoOoO0o
III1iI1Ii11Ii = o0IiiIIII1I1i ( )
if 29 - 29: OoOO0ooOOoo0O
def Oo00oo00o00Oo ( ) :
 if III1iI1Ii11Ii == 'android' :
  I1i1I1II = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  I1i1I1II = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 37 - 37: II111iiii % II111iiii + o0000oOoOoO0o % ii11ii1ii / OOooOOo . oO0o0ooO0
  if 60 - 60: O0oO . O0 / O0
def iiiiiii11III ( ) :
 if 73 - 73: II111iiii + IIII * O0ooOooooO / O0ooOooooO
 main ( )
 if 74 - 74: O0 + iIii1I11I1II1 + oO0o0ooO0 * i1I111II1I
 if 39 - 39: Oooo0Ooo000 . OoOO % iI . IIII / O0ooOooooO * OoOO
 if 12 - 12: OOooOOo / o0000oOoOoO0o
def oOO0O00o0O0 ( ) :
 oOoO0OO = xbmcgui . Dialog ( )
 ooOooO = (
 oooo ,
 IIIiI1iIIII
 )
 if 75 - 75: IIII % II111iiii
 I11IIiI1IiI1 = oOoO0OO . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 4 - 4: oO0o0ooO0 * OOooOOo - iI / II111iiii + IIII / i11iIiiIii
 if I11IIiI1IiI1 :
  if 63 - 63: OoOO + iI
  if I11IIiI1IiI1 < 0 :
   return
  oO0o0 = ooOooO [ I11IIiI1IiI1 - 2 ]
  return oO0o0 ( )
 else :
  oO0o0 = ooOooO [ I11IIiI1IiI1 ]
  return oO0o0 ( )
 return
 if 3 - 3: OoOO0ooOOoo0O - Oooo0Ooo000 / oO0o0ooO0 . O0 * iI / o00O0oo
def o0IiiIIII1I1i ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 18 - 18: o0oO0
III1iI1Ii11Ii = o0IiiIIII1I1i ( )
if 74 - 74: o0oO0 + o00O0oo + OOooOOo
def oooo ( ) :
 if III1iI1Ii11Ii == 'android' :
  I1i1I1II = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  I1i1I1II = webbrowser . open ( 'https://olpair.com/' )
  if 37 - 37: i1I111II1I
  if 97 - 97: o0000oOoOoO0o / i1I111II1I + OoOO0ooOOoo0O + OoOO % Oooo0Ooo000
def IIIiI1iIIII ( ) :
 if 18 - 18: OOooOOo - OoOO0ooOOoo0O
 main ( )
 if 18 - 18: IIII + OoOO * oO0o0ooO0 - oO0o0ooO0 . o00O0oo * O0oO
 if 95 - 95: o00O0oo / OoOO0ooOOoo0O
def i1II11iI1i ( name , url , id , trailer ) :
 oOoO0OO = xbmcgui . Dialog ( )
 ooOooO = (
 Oo0oO ,
 I11IiIi1iI1ii ,
 O0oOo0o0OOoO0 ,
 O00OoO0 ,
 i1I1IIIiii1
 )
 if 76 - 76: OoooooooOO
 I11IIiI1IiI1 = oOoO0OO . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % iIIIi1 ,

 '[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % iIIIi1 ,

 '[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % iIIIi1 ,

 '[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % iIIIi1 ,

 '[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % iIIIi1 ] )
 if 42 - 42: o0oO0 * O0 / oO0o0ooO0
 if I11IIiI1IiI1 :
  if 8 - 8: i1IIi + II111iiii / o0oO0 + o00O0oo % o0oO0 - iIii1I11I1II1
  if I11IIiI1IiI1 < 0 :
   return
  oO0o0 = ooOooO [ I11IIiI1IiI1 - 5 ]
  return oO0o0 ( )
 else :
  oO0o0 = ooOooO [ I11IIiI1IiI1 ]
  return oO0o0 ( )
 return
 if 29 - 29: ii11ii1ii + II111iiii
 if 95 - 95: oO0o0ooO0
 if 48 - 48: O0oO / iIii1I11I1II1 % II111iiii
def Oo0oO ( ) :
 if 39 - 39: i1IIi . o00O0oo / O0oO / O0oO
 II1i ( I1i11111i1i11 , OOoOOO0 )
 if 100 - 100: OoooooooOO - OoooooooOO + i1I111II1I
def I11IiIi1iI1ii ( ) :
 if 32 - 32: OoOO0ooOOoo0O * o0000oOoOoO0o / OoooooooOO
 I1111I1Ii ( I1i11111i1i11 , I1I1i )
 if 90 - 90: Oooo0Ooo000
def O0oOo0o0OOoO0 ( ) :
 if 35 - 35: II111iiii / o0oO0
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  OO0000 = id
  if 79 - 79: i1IIi / ii11ii1ii - OOooOOo . O0
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % OO0000 )
  if 56 - 56: i1I111II1I % O0 * i1IIi - II111iiii
 if O0ii1ii1ii == 'true' :
  if 74 - 74: i1IIi - OoOO0ooOOoo0O % oO0o0ooO0 . O0 - OoooooooOO
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + I1i11111i1i11 + "[/COLOR] ,5000)" )
  if 84 - 84: Oooo0Ooo000
def oOOO ( ) :
 if 54 - 54: oO0o0ooO0 / iIii1I11I1II1 / OoooooooOO . i1IIi - OoOO0ooOOoo0O
 O00OoO0 ( )
 if 57 - 57: iIii1I11I1II1 * o0oO0 * O0ooOooooO / oO0o0ooO0
def i1I1IIIiii1 ( ) :
 if 46 - 46: o0oO0
 OOI1iIi1iiIIiI ( )
def oO0OoO00o ( name , url , mode , iconimage , fanart ) :
 if 61 - 61: o0000oOoOoO0o / iI - II111iiii
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 oO0O000oOoo0O = True
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iII . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 iII . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  OO0oIiII1iiI = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII , isFolder = True )
  return oO0O000oOoo0O
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII , isFolder = True )
 return oO0O000oOoo0O
 if 87 - 87: o00O0oo / OOooOOo
def O0ooOoO ( name , url , mode , iconimage , fanart , description ) :
 if 45 - 45: OoOO0ooOOoo0O * iI / OoooooooOO + OoOO . Oooo0Ooo000 / OoOO
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 oO0O000oOoo0O = True
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iII . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 iII . setProperty ( 'fanart_image' , fanart )
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII , isFolder = True )
 return oO0O000oOoo0O
 if 64 - 64: o0oO0 / i1IIi % OOooOOo - o0000oOoOoO0o
def iIii111Ii ( name , url , mode , iconimage ) :
 if 96 - 96: o0oO0 - II111iiii % OoOO0ooOOoo0O * OOooOOo * OOooOOo . ii11ii1ii
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 oO0O000oOoo0O = True
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iII . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 iII . setProperty ( 'fanart_image' , oo00 )
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII , isFolder = True )
 return oO0O000oOoo0O
 if 75 - 75: ii11ii1ii + o0oO0 + OoOO
 if 97 - 97: iI % i11iIiiIii % O0oO
def oO00oOoo00o0 ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 21 - 21: ii11ii1ii / o0oO0 / o00O0oo / i1IIi / o0000oOoOoO0o
 ooOOoooooo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 86 - 86: i1IIi
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 oOOoo = [ ]
 if 33 - 33: OoOO0ooOOoo0O % i11iIiiIii * IIII
 oOOoo . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 iII . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 iII . setProperty ( 'fanart_image' , fanart )
 iII . setProperty ( 'IsPlayable' , 'true' )
 if 69 - 69: II111iiii + ii11ii1ii - oO0o0ooO0 . ii11ii1ii / iIii1I11I1II1 * iIii1I11I1II1
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  oOOoo . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 75 - 75: OoOO % OoooooooOO
  iII . addContextMenuItems ( oOOoo , replaceItems = True )
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII )
 return oO0O000oOoo0O
 if 16 - 16: O0 / i1IIi
 if 58 - 58: o0000oOoOoO0o / i11iIiiIii / O0 % O0oO % OOooOOo
def iI1iIIII1 ( name , url , mode , iconimage , fanart , id , trailer , description ) :
 if 86 - 86: i1I111II1I + OoOO0ooOOoo0O / OOooOOo + O0oO % O0oO / i11iIiiIii
 ooOOoooooo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 12 - 12: OoOO0ooOOoo0O + o0000oOoOoO0o . Oooo0Ooo000
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 oOOoo = [ ]
 if 52 - 52: OoOO
 oOOoo . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 iII . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 iII . setProperty ( 'fanart_image' , fanart )
 iII . setProperty ( 'IsPlayable' , 'true' )
 if 4 - 4: o0oO0 % o00O0oo + O0oO - o00O0oo
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  oOOoo . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 98 - 98: o0oO0 - O0 * oO0o0ooO0 * o0oO0 * o0oO0
  iII . addContextMenuItems ( oOOoo , replaceItems = True )
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII )
 return oO0O000oOoo0O
 if 44 - 44: i1I111II1I + O0oO
def i11i ( name , url , mode , iconimage , fanart ) :
 if 66 - 66: oO0o0ooO0
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 34 - 34: O0ooOooooO % i11iIiiIii + i11iIiiIii - O0ooOooooO
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 iII . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 iII . setProperty ( 'fanart_image' , fanart )
 iII . setProperty ( 'IsPlayable' , 'true' )
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII )
 return oO0O000oOoo0O
 if 2 - 2: II111iiii + i1IIi
def oO0OO00 ( name , url , mode , iconimage ) :
 if 16 - 16: OoooooooOO / oO0o0ooO0 . o0oO0 * iI - OOooOOo
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 32 - 32: OOooOOo / OoOO
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 iII . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 iII . setProperty ( 'fanart_image' , oo00 )
 iII . setProperty ( 'IsPlayable' , 'true' )
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII )
 return oO0O000oOoo0O
 if 28 - 28: ii11ii1ii / i1I111II1I . O0ooOooooO + OoOO + O0oO % ii11ii1ii
def iI1i ( name , url , mode , iconimage ) :
 OO0oIiII1iiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 oO0O000oOoo0O = True
 iII = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 oO0O000oOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO0oIiII1iiI , listitem = iII , isFolder = True )
 return oO0O000oOoo0O
 if 18 - 18: iIii1I11I1II1 % iIii1I11I1II1 % oO0o0ooO0 + OOooOOo % iI / o0oO0
def iIioO00O0o0oOOO ( ) :
 if 96 - 96: OOooOOo - iIii1I11I1II1
 if 25 - 25: OoooooooOO . o0oO0 % O0ooOooooO . i1I111II1I
 if 67 - 67: OoooooooOO + Oooo0Ooo000 / iI
 ooO = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 ooO . doModal ( )
 if ( ooO . isConfirmed ( ) ) :
  if 75 - 75: i1I111II1I / OoooooooOO . OOooOOo + Oooo0Ooo000 - II111iiii
  Oo00o0OO0O00o = urllib . quote_plus ( ooO . getText ( ) ) . replace ( '+' , ' ' )
  if 33 - 33: i1I111II1I / i1I111II1I . i11iIiiIii * o00O0oo + o0000oOoOoO0o
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 16 - 16: i1I111II1I
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % Oo00o0OO0O00o )
    if 10 - 10: OoOO0ooOOoo0O . i1I111II1I * iIii1I11I1II1 - oO0o0ooO0 - OoOO0ooOOoo0O / Oooo0Ooo000
    if O0ii1ii1ii == 'true' :
     if 13 - 13: oO0o0ooO0 + OoOO0ooOOoo0O % i1I111II1I % OoooooooOO
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + I1i11111i1i11 + "[/COLOR] ,10000)" )
     if 22 - 22: Oooo0Ooo000
   except :
    if 23 - 23: O0
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 41 - 41: i1IIi . IIII / iI / o0000oOoOoO0o % i1I111II1I - o0oO0
    if 14 - 14: o00O0oo - i11iIiiIii * Oooo0Ooo000
i1ii = oooOo00 ( )
OOoOOO0 = None
I1i11111i1i11 = None
iiii = None
O00ooOo = None
id = None
I1I1i = None
if 80 - 80: OOooOOo
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 58 - 58: oO0o0ooO0 + o00O0oo % OoOO0ooOOoo0O
try :
 OOoOOO0 = urllib . unquote_plus ( i1ii [ "url" ] )
except :
 pass
try :
 I1i11111i1i11 = urllib . unquote_plus ( i1ii [ "name" ] )
except :
 pass
try :
 iiii = int ( i1ii [ "mode" ] )
except :
 pass
try :
 O00ooOo = urllib . unquote_plus ( i1ii [ "iconimage" ] )
except :
 pass
try :
 id = int ( i1ii [ "id" ] )
except :
 pass
try :
 I1I1i = urllib . unquote_plus ( i1ii [ "trailer" ] )
except :
 pass
 if 22 - 22: iIii1I11I1II1 - o0oO0 / OOooOOo * i1I111II1I
 if 26 - 26: o0000oOoOoO0o + IIII - o0000oOoOoO0o + ii11ii1ii . oO0o0ooO0
print "Mode: " + str ( iiii )
print "URL: " + str ( OOoOOO0 )
print "Name: " + str ( I1i11111i1i11 )
print "iconimage: " + str ( O00ooOo )
print "id: " + str ( id )
print "trailer: " + str ( I1I1i )
if 97 - 97: i1IIi
if 46 - 46: o00O0oo
def OOOoOoO ( ) :
 if 30 - 30: OoOO / O0 * o0000oOoOoO0o * Oooo0Ooo000 + OoooooooOO * O0ooOooooO
 try :
  if 23 - 23: O0oO
  I1Io0OO = IiIi ( OOOoOoO )
  OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( I1Io0OO )
  for I1i1iii1Ii in OOOOO0O00 :
   if 11 - 11: oO0o0ooO0
   if I1i1iii1Ii == 'si' :
    if 62 - 62: OoooooooOO % oO0o0ooO0 * II111iiii * Oooo0Ooo000 * Oooo0Ooo000 / iI
    import resoveurl
    from resoveurl import common
    import random
    from random import choice
    o0oI1I1i = xbmc . Player ( )
    Oo0O0O0ooO0O = [ 'gtG1Y3_34ug' , '3d_ACcf0rDc' , 'AKpPeLAMY9I' , 'sVBa5hNZFHM' , '5ZCVhFmbAY0' ]
    i111i1IIi1i = random . choice ( Oo0O0O0ooO0O )
    OOoOOO0 = 'https://www.youtube.com/watch?v=%s' % i111i1IIi1i
    OOoOOO0 = resoveurl . HostedMediaFile ( OOoOOO0 ) . resolve ( )
    o0oI1I1i . play ( OOoOOO0 )
    if 97 - 97: iIii1I11I1II1 * O0oO
    o00oooo == 'false'
    if 63 - 63: II111iiii - O0oO . OoOO0ooOOoo0O
   else :
    if 8 - 8: OOooOOo * iI / i1I111II1I + OoOO0ooOOoo0O . i1I111II1I - IIII
    o00oooo == 'false'
    if 80 - 80: iIii1I11I1II1 / oO0o0ooO0 * ii11ii1ii - IIII * O0ooOooooO
    return False
    if 97 - 97: i1I111II1I - O0oO / II111iiii
 except :
  pass
  if 26 - 26: O0ooOooooO + O0 * O0ooOooooO . i1IIi
  if 50 - 50: iIii1I11I1II1 - O0oO % O0ooOooooO - ii11ii1ii
  if 52 - 52: oO0o0ooO0 + o0oO0 - o00O0oo * o0oO0 . IIII + Oooo0Ooo000
if iiii == None or OOoOOO0 == None or len ( OOoOOO0 ) < 1 :
 if 43 - 43: OOooOOo % i1I111II1I % o00O0oo
 if 53 - 53: oO0o0ooO0 % IIII % o00O0oo . Oooo0Ooo000 . Oooo0Ooo000 . O0ooOooooO
 IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 o00O0 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 oOO0O00Oo0O0o = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 OOoo0 = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 iiII1i11i = IiIi ( oOO0O00Oo0O0o )
 OOOOO0O00 = re . compile ( Ii1I1Ii ) . findall ( iiII1i11i )
 for III1I1I in OOOOO0O00 :
  if 73 - 73: O0ooOooooO / iI + OoOO / OoOO0ooOOoo0O . II111iiii * o0oO0
  try :
   if 21 - 21: OOooOOo - OOooOOo + O0ooOooooO % OOooOOo * oO0o0ooO0
   if 74 - 74: O0ooOooooO / O0oO . OOooOOo - OoooooooOO + II111iiii + O0oO
   IIIi1I1IIii1II = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 36 - 36: o0oO0 * OOooOOo * o00O0oo . O0oO * o00O0oo
   if 76 - 76: IIII + O0 / i1I111II1I - OoOO
   if IIIi1I1IIii1II == III1I1I :
    if 27 - 27: ii11ii1ii - iIii1I11I1II1 * O0ooOooooO * II111iiii * o00O0oo
    OOI1iIi1iiIIiI ( )
    I11iiiii1II ( )
    if 9 - 9: i11iIiiIii + IIII - OoOO0ooOOoo0O / iI % i1IIi / oO0o0ooO0
    o00oooo = IiII1IiiIiI1 . getSetting ( 'videos_event' )
    if o00oooo == 'true' :
     xbmc . sleep ( 3000 )
     OOOoOoO ( )
     if 22 - 22: i1IIi
   else :
    if 3 - 3: OoOO * o00O0oo - O0ooOooooO + o00O0oo
    iIIIi1 = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
    if 63 - 63: O0oO * iI % II111iiii % Oooo0Ooo000 + OOooOOo * ii11ii1ii
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Por favor compruebe los ajustes de realstream.[/COLOR]" , "[COLOR white] Desde la seccion Tutoriales puede sacarle mayor partido a su Realstream, tambien puede configurarlo a su gusto. [/COLOR]" , "[COLOR gold]El addon no esta activado o bien configurado.[/COLOR]" )
    if 96 - 96: i1I111II1I
  except :
   pass
   if 99 - 99: iIii1I11I1II1 - iI
elif iiii == 1 :
 i1II11iI1i ( I1i11111i1i11 , OOoOOO0 , id , I1I1i )
elif iiii == 2 :
 o0oo00o0O0O00 ( )
elif iiii == 3 :
 O00oO0o ( )
elif iiii == 4 :
 i1iIii ( I1i11111i1i11 , OOoOOO0 )
elif iiii == 5 :
 iIIIIIIIiIII ( )
elif iiii == 6 :
 OO0ooo0 ( )
elif iiii == 7 :
 O0oooOoO ( )
elif iiii == 8 :
 oO0O0o0O ( )
elif iiii == 9 :
 OoooOo0 ( )
elif iiii == 10 :
 iIII1iIi ( )
elif iiii == 11 :
 iiIO0OO0o0O00oO ( )
elif iiii == 12 :
 I1iiIiiIiiI ( )
elif iiii == 13 :
 o00ooOoO0 ( )
elif iiii == 14 :
 iIIiI11iI1Ii1 ( )
elif iiii == 15 :
 iIiI1i111ii ( )
elif iiii == 16 :
 oOo0O000Ooo0 ( )
elif iiii == 17 :
 O0oO0oo0O0 ( )
elif iiii == 18 :
 oOO00OO0OooOo ( )
elif iiii == 19 :
 iIi ( )
elif iiii == 20 :
 IiiiIIiii ( )
elif iiii == 21 :
 i11Ii1IiIIIi ( )
elif iiii == 22 :
 i1i1iIiI ( )
elif iiii == 23 :
 iiOo0 ( )
elif iiii == 24 :
 iiIiII11i1 ( )
elif iiii == 25 :
 oOo00OoO0O ( )
elif iiii == 26 :
 I11Oo0oO00 ( )
elif iiii == 28 :
 Ii11iI1ii1111 ( I1i11111i1i11 , OOoOOO0 )
elif iiii == 29 :
 oOo0OO0o0 ( )
elif iiii == 30 :
 oo000oO ( )
elif iiii == 31 :
 prueba ( )
elif iiii == 98 :
 busqueda_global ( )
elif iiii == 97 :
 oOO0O00o0O0 ( )
elif iiii == 99 :
 OoOOoO0O0oO ( )
elif iiii == 100 :
 menu_player ( I1i11111i1i11 , OOoOOO0 )
elif iiii == 111 :
 oooOoOOO0oo0o ( )
elif iiii == 115 :
 I1111I1Ii ( OOoOOO0 )
elif iiii == 116 :
 O0Oo00 ( )
elif iiii == 117 :
 I11iIiII ( )
elif iiii == 119 :
 i1iI11I1II1 ( )
elif iiii == 120 :
 o0OoO00o0000O ( )
elif iiii == 121 :
 Iiii11iIi1 ( )
elif iiii == 125 :
 O0oOOOO00oOOo ( )
elif iiii == 112 :
 list_proxy ( )
elif iiii == 127 :
 iIioO00O0o0oOOO ( )
elif iiii == 128 :
 TESTLINKS ( )
elif iiii == 130 :
 II1i ( I1i11111i1i11 , OOoOOO0 )
elif iiii == 140 :
 oooo00o0o0o ( )
elif iiii == 141 :
 Ii1i1 ( )
elif iiii == 142 :
 i1i1IiIiIi1Ii ( )
elif iiii == 143 :
 oOo0OooOo ( I1i11111i1i11 , OOoOOO0 )
elif iiii == 144 :
 Ii11iI1ii1111 ( I1i11111i1i11 , OOoOOO0 )
elif iiii == 145 :
 oo0OoOooo ( )
elif iiii == 146 :
 OoIIi1iI ( )
elif iiii == 147 :
 IIi1 ( I1i11111i1i11 , OOoOOO0 )
elif iiii == 150 :
 I1I1 ( )
elif iiii == 151 :
 i1iiI ( )
elif iiii == 152 :
 IIo0OoO00 ( )
elif iiii == 155 :
 II1i1III ( )
 if 79 - 79: OOooOOo + oO0o0ooO0 % O0oO % oO0o0ooO0
xbmcplugin . endOfDirectory ( o0OoOoOO00 ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
