# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 0.7.8
#
############################################
#
# Incluido Script ResolveURL Por Jsergio.
#
############################################
#
# Corregido imcompatibilidad con Servidor Team
# Agregados nuevos iconos, ahora se puede el aspecto desde ajustes del addon.
#
############################################
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import urlresolver
import cookielib , base64
import requests
import plugintools
import config
oo000 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
ii = oo000 . getAddonInfo ( 'version' )
oOOo = int ( sys . argv [ 1 ] )
O0 = 'gruponetai/'
o0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
iI11I1II1I1I = o0O . getAddonInfo ( 'profile' )
oooo = o0O . getAddonInfo ( 'path' )
iIIii1IIi = oo000 . getSetting ( 'iconos' )
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if iIIii1IIi == 'true' :
 if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
 O0oOO0o0 = xbmc . translatePath ( os . path . join ( oooo , 'fanart.png' ) )
 i1ii1iIII = xbmc . translatePath ( os . path . join ( oooo , 'icon.png' ) )
 Oo0oO0oo0oO00 = xbmc . translatePath ( os . path . join ( oooo , 'extended_info.png' ) )
 i111I = xbmc . translatePath ( os . path . join ( oooo , 'buscar.png' ) )
 II1Ii1iI1i = xbmc . translatePath ( os . path . join ( oooo , 'pair.png' ) )
 iiI1iIiI = xbmc . translatePath ( os . path . join ( oooo , 'theMovieDB.png' ) )
 OOo = xbmc . translatePath ( os . path . join ( oooo , 'novedades.png' ) )
 Ii1IIii11 = xbmc . translatePath ( os . path . join ( oooo , 'estrenos.png' ) )
 Oooo0000 = xbmc . translatePath ( os . path . join ( oooo , 'recomendadas.png' ) )
 i11 = xbmc . translatePath ( os . path . join ( oooo , 'accion.png' ) )
 I11 = xbmc . translatePath ( os . path . join ( oooo , 'animacion.png' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( oooo , 'aventuras.png' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( oooo , 'belico.png' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( oooo , 'ciencia-ficcion.png' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( oooo , 'comedia.png' ) )
 oO = xbmc . translatePath ( os . path . join ( oooo , 'crimen.png' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( oooo , 'drama.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( oooo , 'familiar.png' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( oooo , 'fantasia.png' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( oooo , 'historia.png' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( oooo , 'marvel.png' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( oooo , 'misterio.png' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( oooo , 'musical.png' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( oooo , 'romance.png' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( oooo , 'spain.png' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( oooo , 'suspense.png' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( oooo , 'terror.png' ) )
 II = xbmc . translatePath ( os . path . join ( oooo , 'thriller.png' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( oooo , 'western.png' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( oooo , 'sagas_cine.png' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( oooo , '4k.png' ) )
 OO0o = xbmc . translatePath ( os . path . join ( oooo , 'torrent.png' ) )
 if 82 - 82: i1I1i1Ii11 . IIIIII11i1I - o0o0OOO0o0 % IIII % IIIIII11i1I . OoO0O00
else :
 if 22 - 22: IIIIII11i1I + o0oOOo0O0Ooo % o0o0OOO0o0 . ooOoO0o . I11i
 if 76 - 76: I11i - I1IiiI % I1Ii111 / iII111i / I11i
 iIIii1IIi = oo000 . getSetting ( 'iconos' )
 O0oOO0o0 = xbmc . translatePath ( os . path . join ( oooo , 'fanart.jpg' ) )
 i1ii1iIII = xbmc . translatePath ( os . path . join ( oooo , 'icon.png' ) )
 Oo0oO0oo0oO00 = xbmc . translatePath ( os . path . join ( oooo , 'extended_info.png' ) )
 i111I = xbmc . translatePath ( os . path . join ( oooo , 'buscar.png' ) )
 II1Ii1iI1i = xbmc . translatePath ( os . path . join ( oooo , 'pair.png' ) )
 iiI1iIiI = xbmc . translatePath ( os . path . join ( oooo , 'theMovieDB.jpg' ) )
 OOo = xbmc . translatePath ( os . path . join ( oooo , 'novedades.jpg' ) )
 Ii1IIii11 = xbmc . translatePath ( os . path . join ( oooo , 'encines.jpg' ) )
 Oooo0000 = xbmc . translatePath ( os . path . join ( oooo , 'recomendadas.jpg' ) )
 i11 = xbmc . translatePath ( os . path . join ( oooo , 'accion.jpg' ) )
 I11 = xbmc . translatePath ( os . path . join ( oooo , 'animacion.jpg' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( oooo , 'aventuras.jpg' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( oooo , 'belico.jpg' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( oooo , 'ciencia-ficcion.jpg' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( oooo , 'comedia.jpg' ) )
 oO = xbmc . translatePath ( os . path . join ( oooo , 'crimen.jpg' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( oooo , 'drama.jpg' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( oooo , 'familiar.jpg' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( oooo , 'fantasia.jpg' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( oooo , 'historia.jpg' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( oooo , 'superheroes.jpg' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( oooo , 'misterio.jpg' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( oooo , 'musical.jpg' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( oooo , 'romance.jpg' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( oooo , 'spain.jpg' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( oooo , 'suspense.jpg' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( oooo , 'terror.jpg' ) )
 II = xbmc . translatePath ( os . path . join ( oooo , 'thriller.jpg' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( oooo , 'western.jpg' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( oooo , 'sagas_cine.jpg' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( oooo , '4k.jpg' ) )
 OO0o = xbmc . translatePath ( os . path . join ( oooo , 'torrent.jpg' ) )
 if 54 - 54: I1ii11iIi11i % o0oOOo0O0Ooo % o0oOOo0O0Ooo
 if 13 - 13: Ii1I . o00O0oo
 if 19 - 19: ooOoO0o + IIII
 if 53 - 53: OoO0O00 . OoOoOO00
ii1I1i1I = xbmc . translatePath ( os . path . join ( oooo , 'peliculas.png' ) )
OOoo0O0 = xbmc . translatePath ( os . path . join ( oooo , 'ajustes.png' ) )
iiiIi1i1I = xbmc . translatePath ( os . path . join ( oooo , 'videoteca.png' ) )
oOO00oOO = xbmc . translatePath ( os . path . join ( oooo , 'favorites.png' ) )
OoOo = xbmc . translatePath ( os . path . join ( oooo , 'resolver.png' ) )
iI = xbmc . translatePath ( os . path . join ( oooo , 'test.png' ) )
o00O = xbmc . translatePath ( os . path . join ( oooo , 'video-tutoriales.png' ) )
OOO0OOO00oo = xbmc . translatePath ( os . path . join ( oooo , 'proxy.png' ) )
if 31 - 31: o0oOOo0O0Ooo - I1Ii111 . o0o0OOO0o0 % I11i - I1IiiI
iii11 = oo000 . getSetting ( 'mostrar_cat' )
O0oo0OO0oOOOo = oo000 . getSetting ( 'videos' )
i1i1i11IIi = oo000 . getSetting ( 'activar' )
II1III = oo000 . getSetting ( 'favcopy' )
iI1iI1I1i1I = oo000 . getSetting ( 'anticopia' )
iIi11Ii1 = oo000 . getSetting ( 'licencia_addon' )
Ii11iII1 = oo000 . getSetting ( 'notificar' )
Oo0O0O0ooO0O = oo000 . getSetting ( 'mostrar_bus' )
IIIIii = oo000 . getSetting ( 'restante' )
O0o0 = oo000 . getSetting ( 'aviso' )
OO00Oo = oo000 . getSetting ( 'RealStream_Settings' )
O0OOO0OOoO0O = oo000 . getSetting ( 'Resolver_Settings' )
IIIIii = oo000 . getSetting ( 'restante' )
O00Oo000ooO0 = oo000 . getSetting ( 'fav' )
OoO0O00IIiII = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
o0 = 'bienvenida'
ooOooo000oOO = 'bienvenida'
copyright = oo000 . getSetting ( 'copyright' )
Oo0oOOo = 'cGx1Z2luLnZpZGVvLg==' . decode ( 'base64' ) + copyright
Oo0OoO00oOO0o = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
OOO00O = oo000 . getSetting ( 'Forceupdate' )
if OOO00O == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
OOoOO0oo0ooO = '.txt'
if 98 - 98: i1I1i1Ii11 * i1I1i1Ii11 / i1I1i1Ii11 + ooOoO0o
ii111111I1iII = OoO0O00IIiII + o0 + OOoOO0oo0ooO
O00ooo0O0 = 'http://www.youtube.com'
i1iIi1iIi1i = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
I1I1iIiII1 = '.xsl.pt'
i11i1I1 = '/master/'
ii1I = i1iIi1iIi1i + I1I1iIiII1
Oo0ooOo0o = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*texto3=[\'"](.*?)[\'"]\s*'
Ii1i1 = 'tvg-logo=[\'"](.*?)[\'"]'
if 15 - 15: o0oOOo0O0Ooo
Ii = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)'
ooo0O = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
oOoO0o00OO0 = '#(.+?),(.+)\s*(.+)'
i1I1ii = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
if 61 - 61: o0oOOo0O0Ooo
O0OOO = 'source src=[\'"](.*?)[\'"]\s*title=[\'"](.*?)[\'"]'
II11iIiIIIiI = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
o0o = '[\'"](.*?)[\'"]'
o00 = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
OooOO000 = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( 'base64' )
OOoOoo = OooOO000 + O0
oO0000OOo00 = '[\'"](.*?)[\'"]'
iiIi1IIiIi = 'UmVhbHN0cmVhbQ==' . decode ( 'base64' )
oOO00Oo = 'video=[\'"](.*?)[\'"]'
i1iIIIi1i = '0110nhu' . replace ( '0110nhu' , 'nhu' )
iI1iIIiiii = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( 'base64' ) + i1iIIIi1i
i1 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
iI11i1ii11 = '0110R0N' . replace ( '0110R0N' , 'R0N' )
OOooo0O00o = 'aHR0cDovL2JpdC5seS8yWEIx' . decode ( 'base64' ) + iI11i1ii11
oOOoOooOo = '0110pEJ' . replace ( '0110pEJ' , 'pEJ' )
O000oo = 'aHR0cDovL2JpdC5seS8yd1Nh' . decode ( 'base64' ) + oOOoOooOo
IIi1I11I1II = 'ABBAOb5' . replace ( 'ABBAOb5' , 'Ob5' )
OooOoooOo = 'aHR0cDovL2JpdC5seS8yRVhV' . decode ( 'base64' ) + IIi1I11I1II
ii11IIII11I = '0110jaw' . replace ( '0110jaw' , 'jaw' )
OOooo = 'aHR0cDovL2JpdC5seS8yd01M' . decode ( 'base64' ) + ii11IIII11I
oOooOOOoOo = '01109DI' . replace ( '01109DI' , '9DI' )
i1Iii1i1I = 'aHR0cDovL2JpdC5seS8ySXgz' . decode ( 'base64' ) + oOooOOOoOo
OOoO00 = '01103hs' . replace ( '01103hs' , '3hs' )
IiI111111IIII = 'aHR0cDovL2JpdC5seS8zMW1U' . decode ( 'base64' ) + OOoO00
i1Ii = '01107DW' . replace ( '01107DW' , '7DW' )
ii111iI1iIi1 = 'aHR0cDovL2JpdC5seS8yV1ln' . decode ( 'base64' ) + i1Ii
OOO = '0110mLl' . replace ( '0110mLl' , 'mLl' )
oo0OOo0 = 'aHR0cDovL2JpdC5seS8yS0cw' . decode ( 'base64' ) + OOO
I11IiI = '01102Hj' . replace ( '01102Hj' , '2Hj' )
O0ooO0Oo00o = 'aHR0cDovL2JpdC5seS8yWEJo' . decode ( 'base64' ) + I11IiI
ooO0oOOooOo0 = '0110fXg' . replace ( '0110fXg' , 'fXg' )
i1I1ii11i1Iii = 'aHR0cDovL2JpdC5seS8ySTVy' . decode ( 'base64' ) + ooO0oOOooOo0
I1IiiiiI = '0110NMH' . replace ( '0110NMH' , 'NMH' )
o0OIiII = 'aHR0cDovL2JpdC5seS8yd0t6' . decode ( 'base64' ) + I1IiiiiI
ii1iII1II = '0110bwQ' . replace ( '0110bwQ' , 'bwQ' )
Iii1I1I11iiI1 = 'aHR0cDovL2JpdC5seS8yd01V' . decode ( 'base64' ) + ii1iII1II
I1I1i1I = '0110xzG' . replace ( '0110xzG' , 'xzG' )
ii1IO0oO0 = 'aHR0cDovL2JpdC5seS8yWHhz' . decode ( 'base64' ) + I1I1i1I
oO0 = '0110x64' . replace ( '0110x64' , 'x64' )
O0OO0O = 'aHR0cDovL2JpdC5seS8yRVlF' . decode ( 'base64' ) + oO0
OO = '0110vUE' . replace ( '0110vUE' , 'vUE' )
OoOoO = 'aHR0cDovL2JpdC5seS8yWmhW' . decode ( 'base64' ) + OO
Ii1I1i = '01107ZL' . replace ( '01107ZL' , '7ZL' )
OOI1iI1ii1II = 'aHR0cDovL2JpdC5seS8yWm4w' . decode ( 'base64' ) + Ii1I1i
O0O0OOOOoo = '01106cf' . replace ( '01106cf' , '6cf' )
oOooO0 = 'aHR0cDovL2JpdC5seS8yRVlk' . decode ( 'base64' ) + O0O0OOOOoo
Ii1I1Ii = '0110Jtp' . replace ( '0110Jtp' , 'Jtp' )
OOoO0 = 'aHR0cDovL2JpdC5seS8yV3Nq' . decode ( 'base64' ) + Ii1I1Ii
OO0Oooo0oOO0O = '0110a5b' . replace ( '0110a5b' , 'a5b' )
o00O0 = 'aHR0cDovL2JpdC5seS8yV3dj' . decode ( 'base64' ) + OO0Oooo0oOO0O
oOO0O00Oo0O0o = '0110Q7u' . replace ( '0110Q7u' , 'Q7u' )
ii1 = 'aHR0cDovL2JpdC5seS8yV3NL' . decode ( 'base64' ) + oOO0O00Oo0O0o
I1iIIiiIIi1i = '0110rsq' . replace ( '0110rsq' , 'rsq' )
O0O0ooOOO = 'aHR0cDovL2JpdC5seS8ySzhE' . decode ( 'base64' ) + I1iIIiiIIi1i
oOOo0O00o = '0110DDR' . replace ( '0110DDR' , 'DDR' )
iIiIi11 = 'aHR0cDovL2JpdC5seS8ySzd5' . decode ( 'base64' ) + oOOo0O00o
OOOiiiiI = '0110feQ' . replace ( '0110feQ' , 'feQ' )
oooOo0OOOoo0 = 'aHR0cDovL2JpdC5seS8yS0cz' . decode ( 'base64' ) + OOOiiiiI
OOoO = '0110MHY' . replace ( '0110MHY' , 'MHY' )
OO0O000 = 'aHR0cDovL2JpdC5seS8ySXVo' . decode ( 'base64' ) + OOoO
iiIiI1i1 = '0110xdb' . replace ( '0110xdb' , 'xdb' )
oO0O00oOOoooO = 'aHR0cDovL2JpdC5seS8yWEJu' . decode ( 'base64' ) + iiIiI1i1
IiIi11iI = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( 'base64' )
Oo0oOOo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
Oo0O00O000 = '0110lxu' . replace ( '0110lxu' , 'lxu' )
i11I1IiII1i1i = 'aHR0cDovL2JpdC5seS8yV1Bj' . decode ( 'base64' ) + Oo0O00O000
if 95 - 95: II111iiii
if 32 - 32: I1Ii111
def I11iiiiIIii1I ( ) :
 if 36 - 36: IiII % IiII % OoOoOO00 / OoOoOO00 - IIII
 if 30 - 30: ooOoO0o / I1ii11iIi11i
 try :
  if 35 - 35: o0oOOo0O0Ooo % I1Ii111 . IIII + IIII % o0oOOo0O0Ooo % o0oOOo0O0Ooo
  ooOoO00 = Ii1IIiI1i ( OOooo0O00o )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( ooOoO00 )
  for IiII111i1i11 in o0O00Oo0 :
   try :
    if 40 - 40: IIII * IIIIII11i1I * II111iiii
    O000oo = IiII111i1i11
    if 57 - 57: IIII
    II11Iiii = xbmc . Keyboard ( '' , 'Busqueda por titulo, director, año, servidor:' )
    II11Iiii . doModal ( )
    if ( II11Iiii . isConfirmed ( ) ) :
     if 46 - 46: ooOoO0o / o00O0oo
     O000 = urllib . quote_plus ( II11Iiii . getText ( ) ) . replace ( '+' , ' ' )
     ooooooo00o = Ii1IIiI1i ( O000oo )
     o0O00Oo0 = re . compile ( Ii ) . findall ( ooooooo00o )
     if 73 - 73: I1Ii111
     for ooO , Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI in o0O00Oo0 :
      if re . search ( O000 , iiI1IIIi ( Ooo0oOooo0 . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       II11IiIi11 ( Ooo0oOooo0 , oOOOoo00 , ooO , id , iiIiIIIiiI )
       if 7 - 7: OOooOOo . o00O0oo % IiII * IIII + IIIIII11i1I + o0o0OOO0o0
   except :
    pass
 except :
  pass
  if 38 - 38: Ii1I - I1ii11iIi11i - Ii1I / ooOoO0o - OoOoOO00
def i1II1 ( ) :
 if 25 - 25: o0o0OOO0o0 / Oo0Ooo % i1I1i1Ii11
 IiiiiI1i1Iii = Ii1IIiI1i ( IiIi11iI )
 o0O00Oo0 = re . compile ( o0o ) . findall ( IiiiiI1i1Iii )
 for oo00oO0o in o0O00Oo0 :
  try :
   if 31 - 31: I1Ii111
   import xbmc
   import xbmcaddon
   if 23 - 23: o0o0OOO0o0 . IIIIII11i1I
   __addon__ = xbmcaddon . Addon ( )
   __addonname__ = __addon__ . getAddonInfo ( 'name' )
   __icon__ = __addon__ . getAddonInfo ( 'icon' )
   if 92 - 92: I11i + o0o0OOO0o0 * o00O0oo % I1ii11iIi11i
   ii = oo000 . getAddonInfo ( 'version' )
   if 42 - 42: oO0o
   oo000O0OoooO = "[COLOR gold]Version instalada: " + ii + " [/COLOR]" "[COLOR lime]Ultima Version: " + oo00oO0o + "  [/COLOR]"
   O0o = 5000
   if 27 - 27: IIIIII11i1I - o00O0oo / iII111i % IIIIII11i1I + I1ii11iIi11i
   xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , oo000O0OoooO , O0o , __icon__ ) )
   if 96 - 96: o0o0OOO0o0
   if 97 - 97: IIII
  except :
   pass
   if 48 - 48: OoOoOO00 - o0o0OOO0o0
   if 56 - 56: Ii1I + o0oOOo0O0Ooo + I11i - IIII . I11i
def OOOooo ( ) :
 if 94 - 94: OoO0O00 + oO0o / I11i * I1Ii111
 if 69 - 69: IIII % IiII
 O0oo0OO0oOOOo = oo000 . getSetting ( 'videos' )
 if O0oo0OO0oOOOo == 'true' :
  if 50 - 50: OoO0O00 % ooOoO0o
  try :
   if 49 - 49: IiII - II111iiii . o0o0OOO0o0 * o00O0oo % i1I1i1Ii11 + OoOoOO00
   import urlresolver
   from urlresolver import common
   import random
   from random import choice
   oOO0OOOo = xbmc . Player ( )
   iiiIi1i1I = [ 'iHJAKUyjomI' , '_pqbkWaTGX0' , '5sSQINZQjfU' , 'hEl07wzNkaE' , 'hflGH4jKU0k' , '1qP8wVmQ1eI' ]
   oo0o0000 = random . choice ( iiiIi1i1I )
   oOOOoo00 = 'https://www.youtube.com/watch?v=%s' % oo0o0000
   oOOOoo00 = urlresolver . HostedMediaFile ( oOOOoo00 ) . resolve ( )
   oOO0OOOo . play ( oOOOoo00 )
   if 11 - 11: Oo0Ooo
   O0oo0OO0oOOOo == 'false'
   if 20 - 20: o0oOOo0O0Ooo % oO0o + iII111i + IIII
  except :
   pass
   if 23 - 23: I1Ii111 * o00O0oo * oO0o . I1IiiI - II111iiii
   if 18 - 18: o00O0oo + IIIIII11i1I - I1IiiI
 ooOoO00 = Ii1IIiI1i ( ii111111I1iII )
 o0O00Oo0 = re . compile ( Oo0ooOo0o ) . findall ( ooOoO00 )
 for o00Oi1Ii1i1I11Iii , I1i1i1 , OoO0O00O0oo0O in o0O00Oo0 :
  try :
   if 36 - 36: I1Ii111 + I1IiiI - o00O0oo - I1IiiI % ooOoO0o . IiII
   if 74 - 74: II111iiii . I1ii11iIi11i
   iiI = o00Oi1Ii1i1I11Iii
   oOIIiIi = I1i1i1
   OOoOooOoOOOoo = OoO0O00O0oo0O
   if 25 - 25: OoO0O00 - I1ii11iIi11i . I1ii11iIi11i * IiII
   if 81 - 81: i1I1i1Ii11 + IIIIII11i1I
   oo000O0OoooO = "[COLOR=red][B]" + iiI + "[/B][/COLOR]"
   o0oo0 = "[COLOR yellow]" + oOIIiIi + "[/COLOR]"
   oOOoO0OoOO = "[COLOR yellow]" + OOoOooOoOOOoo + "[/COLOR]"
   if 55 - 55: IIII - ooOoO0o + o0oOOo0O0Ooo + i1I1i1Ii11 % o00O0oo
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , oo000O0OoooO , o0oo0 , oOOoO0OoOO )
   if 41 - 41: OoOoOO00 - ooOoO0o - o00O0oo
  except : III11I1 ( )
  if 36 - 36: IiII - o00O0oo . oO0o - II111iiii - I1Ii111 * oO0o
  if 76 - 76: II111iiii + Ii1I / iII111i - OOooOOo - o00O0oo + iII111i
  if 51 - 51: Oo0Ooo . IIII + Oo0Ooo
  if 95 - 95: I1ii11iIi11i
  if 46 - 46: I11i + OOooOOo
 if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
  if 70 - 70: i1I1i1Ii11 / Oo0Ooo
  if 85 - 85: OoO0O00 % OoOoOO00 * OoO0O00 / iII111i
  if 96 - 96: OoO0O00 + IiII
def iiI1IIIi ( s ) :
 if 44 - 44: IiII
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 20 - 20: ooOoO0o + o00O0oo / I1IiiI % Oo0Ooo
def oOo0O ( file ) :
 if 64 - 64: iII111i - i1I1i1Ii11 + i1I1i1Ii11 - ooOoO0o
 try :
  Iii = open ( file , 'r' )
  ooOoO00 = Iii . read ( )
  Iii . close ( )
  return ooOoO00
 except :
  pass
  if 31 - 31: Ii1I % OOooOOo
def Ii1IIiI1i ( url ) :
 if 14 - 14: IiII / IiII % IIII
 try :
  ooOii = urllib2 . Request ( url )
  if 82 - 82: I11i - OOooOOo % I11i * II111iiii . o0oOOo0O0Ooo % o0oOOo0O0Ooo
  ooOii . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  o00Ooo0 = urllib2 . urlopen ( ooOii )
  oo0O0o00o0O = o00Ooo0 . read ( )
  o00Ooo0 . close ( )
  return oo0O0o00o0O
 except urllib2 . URLError , I11i1II :
  print 'We failed to open "%s".' % url
  if hasattr ( I11i1II , 'code' ) :
   print 'We failed with error code - %s.' % I11i1II . code
  if hasattr ( I11i1II , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , I11i1II . reason
   if 72 - 72: Oo0Ooo . OoOoOO00 / oO0o . o0oOOo0O0Ooo
def ooo000o000 ( url ) :
 ooOii = urllib2 . Request ( url )
 ooOii . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 ooOii . add_header ( 'Referer' , '%s' % url )
 ooOii . add_header ( 'Connection' , 'keep-alive' )
 o00Ooo0 = urllib2 . urlopen ( ooOii )
 oo0O0o00o0O = o00Ooo0 . read ( )
 o00Ooo0 . close ( )
 return oo0O0o00o0O
 if 100 - 100: IIIIII11i1I . ooOoO0o / o00O0oo % I11i % o0oOOo0O0Ooo - OOooOOo
 if 46 - 46: I1IiiI * o0oOOo0O0Ooo - oO0o * IIII
def i11IIIiIiIi ( ) :
 if 27 - 27: iII111i + I11i - I1Ii111 + I1IiiI . o00O0oo
 if i1i1i11IIi == 'true' :
  iIi1i1iIi1iI ( '[COLOR orange]Menu Peliculas[/COLOR] ' , 'movieDB' , 116 , ii1I1i1I , O0oOO0o0 )
  if 26 - 26: OoO0O00 * I1ii11iIi11i + I1Ii111
  if 24 - 24: II111iiii % Oo0Ooo + I1Ii111 / II111iiii
 if OO00Oo == 'true' :
  iIi1i1iIi1iI ( '[COLOR orange]Ajustes[/COLOR]' , 'Settings' , 119 , OOoo0O0 , O0oOO0o0 )
  if 70 - 70: OOooOOo * I1IiiI . ooOoO0o + I1ii11iIi11i . IIIIII11i1I
  if 14 - 14: Oo0Ooo % Oo0Ooo * II111iiii - OOooOOo - ooOoO0o
  if iii11 == 'true' :
   o00oo0 ( )
   if 59 - 59: I1ii11iIi11i * o0oOOo0O0Ooo . I1IiiI
  if O0OOO0OOoO0O == 'true' :
   O000OoOO0 ( )
   i1IiIII111i1 ( )
   if 57 - 57: o00O0oo % o00O0oo * II111iiii
  if iI1iI1I1i1I == 'false' :
   if 7 - 7: I1IiiI . o00O0oo
   oo000O0OoooO = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   o0oo0 = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Program.favoritos-realstream para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   oOOoO0OoOO = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 51 - 51: OOooOOo - I1IiiI % IiII - o0oOOo0O0Ooo
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , oo000O0OoooO , o0oo0 , oOOoO0OoOO )
   if 31 - 31: i1I1i1Ii11 / oO0o - i1I1i1Ii11 - I1Ii111
def I1iiIIIi11 ( ) :
 iIi1i1iIi1iI ( '[COLOR orange]Buscador por id[/COLOR]' , O00ooo0O0 , 127 , iiI1iIiI , O0oOO0o0 )
 if 12 - 12: OoO0O00 % Ii1I * ooOoO0o % Oo0Ooo / o00O0oo
def III11I1 ( ) :
 iIi1i1iIi1iI ( '[COLOR orange]The movie DB[/COLOR]' , 'movieDB' , 99 , iiI1iIiI , O0oOO0o0 )
 iIi1i1iIi1iI ( '[COLOR orange]Buscador por id[/COLOR]' , O00ooo0O0 , 127 , iiI1iIiI , O0oOO0o0 )
 iIi1i1iIi1iI ( '[COLOR orange]Video tutoriales[/COLOR]' , O00ooo0O0 , 125 , o00O , O0oOO0o0 )
 if 27 - 27: II111iiii % o0oOOo0O0Ooo % ooOoO0o . I1IiiI - oO0o + I11i
 if 57 - 57: Oo0Ooo / ooOoO0o - OoOoOO00
 if 51 - 51: IIIIII11i1I
 if 25 - 25: OoO0O00 + IIIIII11i1I * iII111i
 if 92 - 92: I1ii11iIi11i + ooOoO0o + I1IiiI / Ii1I + o0o0OOO0o0
 if 18 - 18: IIII * I11i . i1I1i1Ii11 / iII111i / II111iiii
 iIi1i1iIi1iI ( '[COLOR orange]Autorizar[/COLOR] [COLOR blue][B]OPENLOAD[/B][/COLOR]' , 'movieDB' , 97 , II1Ii1iI1i , O0oOO0o0 )
 if 21 - 21: IiII / iII111i + o00O0oo + OoO0O00
 iIi1i1iIi1iI ( '[COLOR orange]listado Proxy[/COLOR]' , 'movieDB' , 112 , OOO0OOO00oo , O0oOO0o0 )
 i11IIIiIiIi ( )
 if 91 - 91: II111iiii / OoOoOO00 + i1I1i1Ii11 + IIII * II111iiii
 if 66 - 66: Oo0Ooo % OoOoOO00 - I1IiiI + ooOoO0o * o0o0OOO0o0 . IIIIII11i1I
 if 52 - 52: IIII + I1IiiI . i1I1i1Ii11 . iII111i . OOooOOo
 if 97 - 97: I1ii11iIi11i / i1I1i1Ii11
 if 71 - 71: o0oOOo0O0Ooo / OoOoOO00 . iII111i % OoO0O00 . I11i
 if 41 - 41: OoOoOO00 * o0oOOo0O0Ooo / OoO0O00 . I1Ii111
 if 83 - 83: i1I1i1Ii11 . I1IiiI / oO0o / I1Ii111 - o0oOOo0O0Ooo
 if 100 - 100: OOooOOo
 if 46 - 46: I11i / Oo0Ooo % i1I1i1Ii11 . Oo0Ooo * i1I1i1Ii11
 if 38 - 38: iII111i - i1I1i1Ii11 / I1IiiI . o0o0OOO0o0
 if 45 - 45: o0o0OOO0o0
def oOIIi1iiii1iI ( ) :
 iIiiii = xbmcgui . Dialog ( )
 O0000OOO0 = (
 ooo0 ,
 oO000oOo00o0o ,
 )
 if 85 - 85: i1I1i1Ii11 + OoO0O00 * i1I1i1Ii11 - o0o0OOO0o0 % II111iiii
 OOo00OoO = iIiiii . select ( '[B][COLOR=yellow]Listado de Proxys Gratuitos:[/COLOR][/B]' , [
 '[COLOR=orange]                      Ver Listado (ES)[/COLOR]' ,

 '[B][COLOR=gold]                      Volver al Menu [/COLOR][/B]' , ] )
 if 10 - 10: Ii1I / II111iiii
 if OOo00OoO :
  if 92 - 92: ooOoO0o . o0o0OOO0o0
  if OOo00OoO < 0 :
   return
  oOO00O0Ooooo00 = O0000OOO0 [ OOo00OoO - 2 ]
  return oOO00O0Ooooo00 ( )
 else :
  oOO00O0Ooooo00 = O0000OOO0 [ OOo00OoO ]
  return oOO00O0Ooooo00 ( )
 return
 if 97 - 97: IIII / o0o0OOO0o0 % OoOoOO00 % iII111i
def ii111I11iI ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 93 - 93: iII111i / Oo0Ooo * OoOoOO00 % OoO0O00 * I1IiiI * ooOoO0o
Ooooooo = ii111I11iI ( )
if 39 - 39: IIIIII11i1I * oO0o + Oo0Ooo - IIIIII11i1I + I1Ii111
def ooo0 ( ) :
 if Ooooooo == 'android' :
  o0iiiI1I1iIIIi1 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://hidemyna.me/es/proxy-list/?country=ES&type=hs#list' ) )
  if 17 - 17: Oo0Ooo . OoO0O00 / ooOoO0o % o0oOOo0O0Ooo % OoOoOO00 / II111iiii
 else :
  o0iiiI1I1iIIIi1 = webbrowser . open ( 'https://hidemyna.me/es/proxy-list/?country=ES&type=hs#list' )
  if 58 - 58: oO0o . o0oOOo0O0Ooo + IiII - II111iiii / o0oOOo0O0Ooo / I1IiiI
  if 85 - 85: I11i + I1Ii111
def oO000oOo00o0o ( ) :
 if 10 - 10: IIIIII11i1I / OOooOOo + I11i / OoOoOO00
 main ( )
 if 27 - 27: o00O0oo
 if 67 - 67: I1ii11iIi11i
 if 55 - 55: iII111i - i1I1i1Ii11 * Ii1I + I11i * I11i * I1IiiI
 if 91 - 91: o0o0OOO0o0 - I1Ii111 % Oo0Ooo - OoO0O00 % IIII
 if 98 - 98: OOooOOo . OOooOOo * IiII * o0oOOo0O0Ooo * o0o0OOO0o0
def oOooO0OOOoO000 ( ) :
 if 57 - 57: o0oOOo0O0Ooo
 if xbmc . getCondVisibility ( 'System.HasAddon(plugin.program.favoritos-realstream)' ) :
  if 54 - 54: oO0o + IiII + II111iiii
  xbmc . executebuiltin ( 'RunAddon(plugin.program.favoritos-realstream)' )
  if 28 - 28: IiII
  if II1III == 'true' :
   if 70 - 70: IIIIII11i1I
   xbmcgui . Dialog ( ) . ok ( "[COLOR orange]Real Stream Agradecimientos[/COLOR]" , "[COLOR gold]Netai quiere agradecer el genial trabajo de [/COLOR][COLOR lime][B]Spoyser[/B][/COLOR][COLOR gold] Autor de este genial script que originalmente se conoce como:[/COLOR]" , "[COLOR lime][B]Program.super.favorites[/B][/COLOR]" , "Usted puede descargar el script original desde el repositorio de Kodi >Addons de programas> program.super.favorites" )
   if 34 - 34: o0o0OOO0o0 % IIIIII11i1I
  oo000 . setSetting ( 'Favoritos-anuncio' , 'false' )
 else :
  if 3 - 3: o0oOOo0O0Ooo / I1Ii111 + IIIIII11i1I . IIII . OOooOOo
  xbmcgui . Dialog ( ) . ok ( "El programa Real stream Favoritos No esta instalado" , "[COLOR green]Necesario AddOn externo para agregar tus peliculas a favoritas dentro del addon.[/COLOR]" , "[COLOR yellow]Puedes agregarlo desde http://netai.eu/netai/ agregando la fuente a tu Kodi, instalar desde archivo zip.[/COLOR]" )
  if 83 - 83: IiII + OoO0O00
def I111IiiIi1 ( ) :
 oo000 . openSettings ( )
 if 88 - 88: OoO0O00
 if 84 - 84: I11i / ooOoO0o * i1I1i1Ii11 / IiII - II111iiii . oO0o
def oOOo000oOoO0 ( ) :
 urlresolver . display_settings ( )
 if 86 - 86: o0oOOo0O0Ooo % II111iiii + o00O0oo % II111iiii
def O000OoOO0 ( ) :
 iIi1i1iIi1iI ( '[COLOR orange]Ajustes URL RESOLVER[/COLOR]' , 'resolve' , 120 , OoOo , O0oOO0o0 )
 if 92 - 92: II111iiii - i1I1i1Ii11 / IIII / IiII
def iiI11I ( ) :
 if 11 - 11: i1I1i1Ii11 - IiII + o0oOOo0O0Ooo - Oo0Ooo
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 7 - 7: IIIIII11i1I - ooOoO0o / o0oOOo0O0Ooo * o00O0oo . i1I1i1Ii11 * i1I1i1Ii11
def i1IiIII111i1 ( ) :
 iIi1i1iIi1iI ( '[COLOR orange]Ajustes RESOLVE URL[/COLOR]' , 'resolve' , 140 , OoOo , O0oOO0o0 )
 if 61 - 61: ooOoO0o % IIII - OOooOOo / oO0o
def o00oo0 ( ) :
 iIi1i1iIi1iI ( '[COLOR yellow]Buscador[/COLOR]' , 'search' , 111 , i111I , O0oOO0o0 )
 iIi1i1iIi1iI ( '[COLOR orange]Estrenos[/COLOR]' , O00ooo0O0 , 3 , Ii1IIii11 , O0oOO0o0 )
 iIi1i1iIi1iI ( '[COLOR orange]Todas[/COLOR]' , O00ooo0O0 , 26 , Oooo0000 , O0oOO0o0 )
 iIi1i1iIi1iI ( '[COLOR orange]4K[/COLOR]' , O00ooo0O0 , 141 , II11iiii1Ii , O0oOO0o0 )
 iIi1i1iIi1iI ( '[COLOR orange]Novedades[/COLOR]' , O00ooo0O0 , 2 , OOo , O0oOO0o0 )
 iIi1i1iIi1iI ( '[COLOR orange]Accion[/COLOR]' , O00ooo0O0 , 5 , i11 , O0oOO0o0 )
 iIi1i1iIi1iI ( '[COLOR orange]Animacion[/COLOR]' , O00ooo0O0 , 6 , I11 , O0oOO0o0 )
 iIi1i1iIi1iI ( '[COLOR orange]Aventuras[/COLOR]' , O00ooo0O0 , 7 , Oo0o0000o0o0 , O0oOO0o0 )
 iIi1i1iIi1iI ( '[COLOR orange]Belico[/COLOR]' , O00ooo0O0 , 8 , oOo0oooo00o , O0oOO0o0 )
 iIi1i1iIi1iI ( '[COLOR orange]Ciencia Ficcion[/COLOR]' , O00ooo0O0 , 9 , oO0o0o0ooO0oO , O0oOO0o0 )
 iIi1i1iIi1iI ( '[COLOR orange]Comedia[/COLOR]' , O00ooo0O0 , 10 , oo0o0O00 , O0oOO0o0 )
 iIi1i1iIi1iI ( '[COLOR orange]Crimen[/COLOR]' , O00ooo0O0 , 11 , oO , O0oOO0o0 )
 iIi1i1iIi1iI ( '[COLOR orange]Drama[/COLOR]' , O00ooo0O0 , 12 , i1iiIIiiI111 , O0oOO0o0 )
 iIi1i1iIi1iI ( '[COLOR orange]Familiar[/COLOR]' , O00ooo0O0 , 13 , oooOOOOO , O0oOO0o0 )
 iIi1i1iIi1iI ( '[COLOR orange]Fantasia[/COLOR]' , O00ooo0O0 , 14 , i1iiIII111ii , O0oOO0o0 )
 iIi1i1iIi1iI ( '[COLOR orange]Historia[/COLOR]' , O00ooo0O0 , 15 , i1iIIi1 , O0oOO0o0 )
 iIi1i1iIi1iI ( '[COLOR orange]Misterio[/COLOR]' , O00ooo0O0 , 16 , iI111I11I1I1 , O0oOO0o0 )
 iIi1i1iIi1iI ( '[COLOR orange]Musical[/COLOR]' , O00ooo0O0 , 17 , OOooO0OOoo , O0oOO0o0 )
 iIi1i1iIi1iI ( '[COLOR orange]Romance[/COLOR]' , O00ooo0O0 , 18 , iIii1 , O0oOO0o0 )
 iIi1i1iIi1iI ( '[COLOR orange]Thriller[/COLOR]' , O00ooo0O0 , 19 , II , O0oOO0o0 )
 iIi1i1iIi1iI ( '[COLOR orange]Suspense[/COLOR]' , O00ooo0O0 , 20 , O0OoO000O0OO , O0oOO0o0 )
 iIi1i1iIi1iI ( '[COLOR orange]Terror[/COLOR]' , O00ooo0O0 , 21 , iiI1IiI , O0oOO0o0 )
 iIi1i1iIi1iI ( '[COLOR orange]Western[/COLOR]' , O00ooo0O0 , 22 , ooOoOoo0O , O0oOO0o0 )
 iIi1i1iIi1iI ( '[COLOR orange]Spain[/COLOR]' , O00ooo0O0 , 23 , oOOoO0 , O0oOO0o0 )
 iIi1i1iIi1iI ( '[COLOR orange]Super heroes[/COLOR]' , O00ooo0O0 , 24 , ii11iIi1I , O0oOO0o0 )
 iIi1i1iIi1iI ( '[COLOR orange]Sagas[/COLOR]' , O00ooo0O0 , 25 , OooO0 , O0oOO0o0 )
 if 4 - 4: OoO0O00 - OoOoOO00 % o00O0oo - I1Ii111 * Ii1I
 if 85 - 85: OoO0O00 * Oo0Ooo . i1I1i1Ii11 / OoO0O00 % I1ii11iIi11i % I1IiiI
 if 36 - 36: o00O0oo / o0oOOo0O0Ooo / IIIIII11i1I / IIIIII11i1I + iII111i
def oO0Ooo0ooOO0 ( ) :
 if 46 - 46: o00O0oo % I11i
 if 64 - 64: II111iiii - o0oOOo0O0Ooo
 oO0oOOO0Ooo = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 oO0oOOO0Ooo . doModal ( )
 if not oO0oOOO0Ooo . isConfirmed ( ) :
  return None ;
 Ooo0oOooo0 = oO0oOOO0Ooo . getText ( ) . strip ( )
 if 38 - 38: I1ii11iIi11i
 if 84 - 84: IiII % OoOoOO00
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 70 - 70: oO0o . OoO0O00 - i1I1i1Ii11
  o0iiiI1I1iIIIi1 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + Ooo0oOooo0 + '&language=es-ES' ) )
  if 30 - 30: iII111i % I1ii11iIi11i
  if 89 - 89: o0o0OOO0o0 + OoO0O00 + o0o0OOO0o0 * OoOoOO00 + Oo0Ooo % ooOoO0o
  return 'android'
  if 59 - 59: I1Ii111 + II111iiii
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 88 - 88: II111iiii - IIII
  o0iiiI1I1iIIIi1 = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + Ooo0oOooo0 + '&language=es-ES' )
  if 67 - 67: I1Ii111 . oO0o + I11i - OoO0O00
  if 70 - 70: I1Ii111 / o0oOOo0O0Ooo - Oo0Ooo - i1I1i1Ii11
  return 'windows'
  if 11 - 11: Oo0Ooo . OoO0O00 . o0oOOo0O0Ooo / OoOoOO00 - ooOoO0o
  if 30 - 30: I11i
def Ii111 ( ) :
 if 67 - 67: I1IiiI
 try :
  if 52 - 52: o0oOOo0O0Ooo . IIII / I11i / OoO0O00 . II111iiii
  ooOoO00 = Ii1IIiI1i ( OOooo0O00o )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( ooOoO00 )
  for IiII111i1i11 in o0O00Oo0 :
   if 30 - 30: ooOoO0o / o00O0oo . IIIIII11i1I . OoO0O00 - oO0o
   try :
    if 44 - 44: I1IiiI * OoO0O00 % IIII + o0oOOo0O0Ooo
    all = IiII111i1i11
    if 39 - 39: IiII % Oo0Ooo % I1IiiI % OoO0O00 * iII111i + i1I1i1Ii11
   except :
    pass
    if 68 - 68: oO0o + II111iiii
  ooooooo00o = Ii1IIiI1i ( all )
  o0O00Oo0 = re . compile ( Ii ) . findall ( ooooooo00o )
  for ooO , Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI in o0O00Oo0 :
   try :
    if 69 - 69: Oo0Ooo * Oo0Ooo * II111iiii + I1ii11iIi11i / I1Ii111 % o00O0oo
    II11IiIi11 ( Ooo0oOooo0 , oOOOoo00 , ooO , id , iiIiIIIiiI )
    if 58 - 58: I1Ii111 * Ii1I + I1IiiI % I1Ii111
   except :
    pass
 except :
  pass
  if 25 - 25: oO0o % iII111i * IIII
def I11oo0ooOO ( ) :
 if 24 - 24: OOooOOo % OOooOOo * Oo0Ooo
 try :
  if 50 - 50: OOooOOo . II111iiii - IiII . IiII
  OOo = Ii1IIiI1i ( O000oo )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( OOo )
  for IiII111i1i11 in o0O00Oo0 :
   if 31 - 31: I1Ii111 / oO0o * OoOoOO00 . I11i
   try :
    if 57 - 57: I1Ii111 + Oo0Ooo % OoOoOO00 % I1ii11iIi11i
    OO0oo = IiII111i1i11
    if 15 - 15: Oo0Ooo % OoO0O00 - oO0o * o00O0oo + ooOoO0o
   except :
    pass
    if 11 - 11: i1I1i1Ii11 * o00O0oo - I11i
  IiiiiI1i1Iii = Ii1IIiI1i ( OO0oo )
  o0O00Oo0 = re . compile ( Ii ) . findall ( IiiiiI1i1Iii )
  for ooO , Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI in o0O00Oo0 :
   try :
    if 66 - 66: I11i . II111iiii - i1I1i1Ii11 * Ii1I + OoO0O00 * iII111i
    II11IiIi11 ( Ooo0oOooo0 , oOOOoo00 , ooO , id , iiIiIIIiiI )
    if 74 - 74: oO0o
   except :
    pass
 except :
  pass
  if 61 - 61: oO0o - o0o0OOO0o0 * o0oOOo0O0Ooo % IIII * Oo0Ooo + OOooOOo
def O0000 ( ) :
 if 64 - 64: o0oOOo0O0Ooo - I1ii11iIi11i
 try :
  if 68 - 68: IIII - I1Ii111 - Oo0Ooo / I11i + I1Ii111 - OOooOOo
  Ii1IIii11 = Ii1IIiI1i ( OooOoooOo )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( Ii1IIii11 )
  for IiII111i1i11 in o0O00Oo0 :
   if 75 - 75: i1I1i1Ii11 / Ii1I % Oo0Ooo . OoO0O00 % OoO0O00 % o0oOOo0O0Ooo
   try :
    Ii1i1i1111 = IiII111i1i11
   except :
    pass
    if 57 - 57: o00O0oo % o0oOOo0O0Ooo
  ooOoO00 = Ii1IIiI1i ( Ii1i1i1111 )
  o0O00Oo0 = re . compile ( Ii ) . findall ( ooOoO00 )
  for ooO , Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI in o0O00Oo0 :
   try :
    II11IiIi11 ( Ooo0oOooo0 , oOOOoo00 , ooO , id , iiIiIIIiiI )
    if 67 - 67: IIII + I1ii11iIi11i * II111iiii - IiII / IIIIII11i1I % i1I1i1Ii11
   except :
    pass
 except :
  pass
  if 92 - 92: o00O0oo - IiII - IIII % OoO0O00 / I1Ii111
def iIIIiIii ( ) :
 if 71 - 71: OoO0O00
 try :
  if 33 - 33: o0o0OOO0o0
  ooOoO00 = Ii1IIiI1i ( db2 )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( ooOoO00 )
  for IiII111i1i11 in o0O00Oo0 :
   if 62 - 62: iII111i + o00O0oo + OoOoOO00 / OoO0O00
   try :
    if 7 - 7: Ii1I + OoOoOO00 . I1ii11iIi11i / oO0o
    I111i1I1 = IiII111i1i11
    if 62 - 62: I1Ii111 * o0o0OOO0o0 / oO0o * Ii1I
   except :
    pass
    if 29 - 29: oO0o % OOooOOo % IIIIII11i1I . Ii1I / OoO0O00 * IIII
    if 54 - 54: I1IiiI
  ooOoO00 = Ii1IIiI1i ( I111i1I1 )
  o0O00Oo0 = re . compile ( Ii ) . findall ( ooOoO00 )
  for ooO , Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI in o0O00Oo0 :
   try :
    II11IiIi11 ( Ooo0oOooo0 , oOOOoo00 , ooO , id , iiIiIIIiiI )
    if 68 - 68: OOooOOo * Ii1I . IIII % IiII % o0o0OOO0o0
   except :
    pass
 except :
  pass
  if 75 - 75: I11i
def i1OoOO ( ) :
 if 44 - 44: I1Ii111
 try :
  if 54 - 54: o00O0oo - ooOoO0o - o0o0OOO0o0 . Oo0Ooo
  ooOoO00 = Ii1IIiI1i ( OOooo )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( ooOoO00 )
  for IiII111i1i11 in o0O00Oo0 :
   if 79 - 79: o00O0oo . OOooOOo
   try :
    if 40 - 40: Ii1I + oO0o . Ii1I % IIII
    I11I1IIiiII1 = IiII111i1i11
    if 31 - 31: I1ii11iIi11i * IiII + OoO0O00 - i1I1i1Ii11 / OoO0O00
   except :
    pass
    if 19 - 19: IIIIII11i1I * IIII * Ii1I + I1IiiI / I1IiiI
    if 73 - 73: Oo0Ooo / Oo0Ooo - IiII
  ooOoO00 = Ii1IIiI1i ( I11I1IIiiII1 )
  o0O00Oo0 = re . compile ( Ii ) . findall ( ooOoO00 )
  for ooO , Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI in o0O00Oo0 :
   try :
    II11IiIi11 ( Ooo0oOooo0 , oOOOoo00 , ooO , id , iiIiIIIiiI )
    if 91 - 91: IiII + I1ii11iIi11i
   except :
    pass
 except :
  pass
  if 59 - 59: I1ii11iIi11i + II111iiii + OoOoOO00 / ooOoO0o
def I11iIiI1 ( ) :
 if 86 - 86: Ii1I
 try :
  if 27 - 27: I1IiiI . Ii1I . iII111i . iII111i + iII111i * Ii1I
  ooOoO00 = Ii1IIiI1i ( i1Iii1i1I )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( ooOoO00 )
  for IiII111i1i11 in o0O00Oo0 :
   if 100 - 100: oO0o % o00O0oo / ooOoO0o
   try :
    if 30 - 30: oO0o - I1Ii111 - i1I1i1Ii11
    OOOI11IIiIiI = IiII111i1i11
    if 5 - 5: oO0o * I11i
   except :
    pass
    if 46 - 46: IIII
  ooOoO00 = Ii1IIiI1i ( OOOI11IIiIiI )
  o0O00Oo0 = re . compile ( Ii ) . findall ( ooOoO00 )
  for ooO , Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI in o0O00Oo0 :
   try :
    II11IiIi11 ( Ooo0oOooo0 , oOOOoo00 , ooO , id , iiIiIIIiiI )
    if 33 - 33: i1I1i1Ii11 - o0oOOo0O0Ooo * OoO0O00 - oO0o - I1Ii111
   except :
    pass
 except :
  pass
  if 84 - 84: o0o0OOO0o0 + oO0o - I11i * I11i
def Ooo ( ) :
 if 65 - 65: oO0o / ooOoO0o
 try :
  if 12 - 12: ooOoO0o % I11i
  ooOoO00 = Ii1IIiI1i ( IiI111111IIII )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( ooOoO00 )
  for IiII111i1i11 in o0O00Oo0 :
   if 48 - 48: i1I1i1Ii11 . II111iiii
   try :
    if 5 - 5: IiII . iII111i . o0oOOo0O0Ooo . OoO0O00
    Oo0OooO0 = IiII111i1i11
    if 87 - 87: IiII % o00O0oo
   except :
    pass
    if 83 - 83: o0oOOo0O0Ooo - ooOoO0o
    if 35 - 35: OoOoOO00 - Oo0Ooo + OoOoOO00
  ooOoO00 = Ii1IIiI1i ( Oo0OooO0 )
  o0O00Oo0 = re . compile ( Ii ) . findall ( ooOoO00 )
  for ooO , Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI in o0O00Oo0 :
   try :
    II11IiIi11 ( Ooo0oOooo0 , oOOOoo00 , ooO , id , iiIiIIIiiI )
    if 86 - 86: Oo0Ooo + I11i . II111iiii - o00O0oo
   except :
    pass
 except :
  pass
  if 51 - 51: I11i
def I11IIIiIi11 ( ) :
 if 39 - 39: o00O0oo % I1IiiI % I11i . OoOoOO00
 try :
  if 86 - 86: OOooOOo * OoO0O00
  ooOoO00 = Ii1IIiI1i ( ii111iI1iIi1 )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( ooOoO00 )
  for IiII111i1i11 in o0O00Oo0 :
   if 71 - 71: Oo0Ooo - I1Ii111 . I1ii11iIi11i % OoO0O00 + I1Ii111
   try :
    if 26 - 26: oO0o + I1Ii111 / OOooOOo % I11i % iII111i + o0oOOo0O0Ooo
    i11I1I1iiI = IiII111i1i11
    if 34 - 34: ooOoO0o % IIII . I1IiiI . Oo0Ooo
   except :
    pass
    if 93 - 93: OoOoOO00 . II111iiii . oO0o
    if 99 - 99: ooOoO0o - o0o0OOO0o0 - IiII % OOooOOo
  ooOoO00 = Ii1IIiI1i ( i11I1I1iiI )
  o0O00Oo0 = re . compile ( Ii ) . findall ( ooOoO00 )
  for ooO , Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI in o0O00Oo0 :
   try :
    II11IiIi11 ( Ooo0oOooo0 , oOOOoo00 , ooO , id , iiIiIIIiiI )
    if 21 - 21: o0oOOo0O0Ooo % iII111i . OoOoOO00 - OoO0O00
   except :
    pass
 except :
  pass
  if 4 - 4: OoO0O00 . IIII
def oOO0oo ( ) :
 if 29 - 29: I1ii11iIi11i * o0oOOo0O0Ooo * OoO0O00 - iII111i * o0oOOo0O0Ooo
 try :
  if 41 - 41: I1IiiI
  ooOoO00 = Ii1IIiI1i ( oo0OOo0 )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( ooOoO00 )
  for IiII111i1i11 in o0O00Oo0 :
   if 30 - 30: IIII % i1I1i1Ii11 * I1Ii111 - iII111i * o00O0oo % IIII
   try :
    if 46 - 46: II111iiii - I1IiiI . IiII
    Oo0O = IiII111i1i11
    if 1 - 1: I1IiiI / i1I1i1Ii11 % o0o0OOO0o0 . oO0o + IIIIII11i1I
   except :
    pass
    if 27 - 27: o0o0OOO0o0 % OoO0O00 + IIIIII11i1I % OoOoOO00 / IiII / OoO0O00
    if 11 - 11: I1Ii111 % o00O0oo - II111iiii - IiII + IIII + IIIIII11i1I
  ooOoO00 = Ii1IIiI1i ( Oo0O )
  o0O00Oo0 = re . compile ( Ii ) . findall ( ooOoO00 )
  for ooO , Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI in o0O00Oo0 :
   try :
    II11IiIi11 ( Ooo0oOooo0 , oOOOoo00 , ooO , id , iiIiIIIiiI )
    if 87 - 87: o0o0OOO0o0 * OoOoOO00 / iII111i
   except :
    pass
 except :
  pass
  if 6 - 6: Ii1I + oO0o - OoO0O00 % I1Ii111 * I11i
  if 69 - 69: OoOoOO00
def ooOoOOOOo ( ) :
 if 71 - 71: o0oOOo0O0Ooo * Oo0Ooo / iII111i
 try :
  if 23 - 23: o0oOOo0O0Ooo
  ooOoO00 = Ii1IIiI1i ( O0ooO0Oo00o )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( ooOoO00 )
  for IiII111i1i11 in o0O00Oo0 :
   if 24 - 24: Oo0Ooo + Oo0Ooo * i1I1i1Ii11
   try :
    if 18 - 18: i1I1i1Ii11 * ooOoO0o - o00O0oo
    II1i1III = IiII111i1i11
    if 34 - 34: o0o0OOO0o0 - II111iiii / Oo0Ooo
   except :
    pass
    if 87 - 87: iII111i / OoO0O00 - oO0o % I11i % IIIIII11i1I % oO0o
    if 29 - 29: OoO0O00 . I1ii11iIi11i % iII111i - i1I1i1Ii11
  ooOoO00 = Ii1IIiI1i ( II1i1III )
  o0O00Oo0 = re . compile ( Ii ) . findall ( ooOoO00 )
  for ooO , Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI in o0O00Oo0 :
   try :
    II11IiIi11 ( Ooo0oOooo0 , oOOOoo00 , ooO , id , iiIiIIIiiI )
    if 8 - 8: OoOoOO00
   except :
    pass
 except :
  pass
  if 32 - 32: IiII / o0oOOo0O0Ooo
  if 45 - 45: iII111i + OOooOOo * II111iiii / I1Ii111 % ooOoO0o * I1IiiI
def i1o0oooO ( ) :
 if 89 - 89: o0oOOo0O0Ooo / IiII
 try :
  if 14 - 14: I1Ii111 . I1ii11iIi11i * IIII + o0oOOo0O0Ooo - IIII + I1Ii111
  ooOoO00 = Ii1IIiI1i ( i1I1ii11i1Iii )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( ooOoO00 )
  for IiII111i1i11 in o0O00Oo0 :
   if 18 - 18: IiII - Ii1I - I1ii11iIi11i - I1ii11iIi11i
   try :
    if 54 - 54: oO0o + I1ii11iIi11i / i1I1i1Ii11 . I1ii11iIi11i * I11i
    IIiIiiiIIIIi1 = IiII111i1i11
    if 39 - 39: OOooOOo / o00O0oo / o0o0OOO0o0
   except :
    pass
    if 81 - 81: ooOoO0o / OOooOOo % OoO0O00 * IiII / IiII
    if 28 - 28: II111iiii / Ii1I . Oo0Ooo / o0oOOo0O0Ooo
  ooOoO00 = Ii1IIiI1i ( IIiIiiiIIIIi1 )
  o0O00Oo0 = re . compile ( Ii ) . findall ( ooOoO00 )
  for ooO , Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI in o0O00Oo0 :
   try :
    II11IiIi11 ( Ooo0oOooo0 , oOOOoo00 , ooO , id , iiIiIIIiiI )
    if 72 - 72: OoO0O00 / I1ii11iIi11i + o00O0oo / I11i * o00O0oo
   except :
    pass
    if 34 - 34: I1IiiI * I1IiiI % OoO0O00 + i1I1i1Ii11 * Oo0Ooo % o00O0oo
 except :
  pass
  if 25 - 25: ooOoO0o + I11i . Ii1I % I11i * I1Ii111
  if 32 - 32: II111iiii - o0o0OOO0o0
def oo00ooOoo ( ) :
 if 28 - 28: o00O0oo
 try :
  if 1 - 1: o00O0oo
  ooOoO00 = Ii1IIiI1i ( o0OIiII )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( ooOoO00 )
  for IiII111i1i11 in o0O00Oo0 :
   if 48 - 48: I1IiiI + I1IiiI . o0o0OOO0o0 - IIII
   try :
    if 63 - 63: IiII
    Oo0 = IiII111i1i11
    if 79 - 79: OOooOOo % I1Ii111 / Oo0Ooo + I11i * OOooOOo
   except :
    pass
    if 30 - 30: OoO0O00 / ooOoO0o + i1I1i1Ii11 / iII111i * I1IiiI
    if 16 - 16: oO0o / II111iiii
  ooOoO00 = Ii1IIiI1i ( Oo0 )
  o0O00Oo0 = re . compile ( Ii ) . findall ( ooOoO00 )
  for ooO , Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI in o0O00Oo0 :
   try :
    II11IiIi11 ( Ooo0oOooo0 , oOOOoo00 , ooO , id , iiIiIIIiiI )
    if 64 - 64: II111iiii / o00O0oo * OoOoOO00
   except :
    pass
    if 73 - 73: oO0o - I11i - IiII - I1ii11iIi11i
 except :
  pass
  if 65 - 65: Ii1I
def I1i ( ) :
 if 49 - 49: iII111i
 try :
  if 84 - 84: ooOoO0o - oO0o / I1IiiI - o0o0OOO0o0
  ooOoO00 = Ii1IIiI1i ( Iii1I1I11iiI1 )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( ooOoO00 )
  for IiII111i1i11 in o0O00Oo0 :
   if 21 - 21: I1IiiI * I1IiiI % iII111i
   try :
    if 94 - 94: ooOoO0o + o0oOOo0O0Ooo % II111iiii
    i1i1IiIiIi1Ii = IiII111i1i11
    if 64 - 64: I1Ii111 + OoO0O00 * OoO0O00
   except :
    pass
    if 41 - 41: IIII . oO0o + I1ii11iIi11i
  ooOoO00 = Ii1IIiI1i ( i1i1IiIiIi1Ii )
  o0O00Oo0 = re . compile ( Ii ) . findall ( ooOoO00 )
  for ooO , Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI in o0O00Oo0 :
   try :
    II11IiIi11 ( Ooo0oOooo0 , oOOOoo00 , ooO , id , iiIiIIIiiI )
    if 100 - 100: o00O0oo + OOooOOo
   except :
    pass
 except :
  pass
  if 73 - 73: OoOoOO00 - o0o0OOO0o0 % IIII / OOooOOo
  if 40 - 40: iII111i * IIII - I1ii11iIi11i / IIIIII11i1I / II111iiii
def OOO0o ( ) :
 if 4 - 4: oO0o . OoOoOO00 - i1I1i1Ii11
 try :
  if 10 - 10: ooOoO0o * o00O0oo % OoO0O00
  ooOoO00 = Ii1IIiI1i ( ii1IO0oO0 )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( ooOoO00 )
  for IiII111i1i11 in o0O00Oo0 :
   if 83 - 83: o0o0OOO0o0 - I1ii11iIi11i - iII111i % I1IiiI . o00O0oo
   try :
    if 35 - 35: IIIIII11i1I + OoOoOO00 * IiII - o00O0oo . oO0o
    iiIii1II = IiII111i1i11
    if 60 - 60: o0oOOo0O0Ooo / Oo0Ooo + iII111i . II111iiii
   except :
    pass
    if 40 - 40: Ii1I
    if 78 - 78: Oo0Ooo
  ooOoO00 = Ii1IIiI1i ( iiIii1II )
  o0O00Oo0 = re . compile ( Ii ) . findall ( ooOoO00 )
  for ooO , Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI in o0O00Oo0 :
   try :
    II11IiIi11 ( Ooo0oOooo0 , oOOOoo00 , ooO , id , iiIiIIIiiI )
    if 56 - 56: OoO0O00 - ooOoO0o - OoOoOO00
   except :
    pass
 except :
  pass
  if 8 - 8: o0o0OOO0o0 / I1Ii111 . I1ii11iIi11i + iII111i / II111iiii
  if 31 - 31: IIII - Oo0Ooo + i1I1i1Ii11 . oO0o / IIIIII11i1I % Oo0Ooo
def I11i1iIiiIiIi ( ) :
 if 49 - 49: I1Ii111 . iII111i . II111iiii - o0oOOo0O0Ooo / o00O0oo
 try :
  if 62 - 62: I1Ii111
  ooOoO00 = Ii1IIiI1i ( O0OO0O )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( ooOoO00 )
  for IiII111i1i11 in o0O00Oo0 :
   if 1 - 1: IIIIII11i1I / IIIIII11i1I - II111iiii
   try :
    if 87 - 87: oO0o / I1IiiI * IIIIII11i1I / Ii1I
    I1iiIII = IiII111i1i11
    if 16 - 16: IiII + IIII / Ii1I
   except :
    pass
  ooOoO00 = Ii1IIiI1i ( I1iiIII )
  o0O00Oo0 = re . compile ( Ii ) . findall ( ooOoO00 )
  for ooO , Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI in o0O00Oo0 :
   try :
    II11IiIi11 ( Ooo0oOooo0 , oOOOoo00 , ooO , id , iiIiIIIiiI )
    if 82 - 82: IIIIII11i1I * II111iiii % o0oOOo0O0Ooo - OoO0O00
   except :
    pass
 except :
  pass
  if 90 - 90: oO0o . IiII * OoOoOO00 - OoOoOO00
def IiIiiI11i1Ii ( ) :
 if 100 - 100: o0o0OOO0o0 . I1ii11iIi11i * o0o0OOO0o0 - I1ii11iIi11i . ooOoO0o * o00O0oo
 try :
  if 89 - 89: OOooOOo + IIIIII11i1I * o0o0OOO0o0
  ooOoO00 = Ii1IIiI1i ( OoOoO )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( ooOoO00 )
  for IiII111i1i11 in o0O00Oo0 :
   if 28 - 28: OoO0O00 . IiII % iII111i / OoOoOO00 / I1Ii111
   try :
    if 36 - 36: Ii1I + ooOoO0o - IIIIII11i1I + Oo0Ooo + OoO0O00
    IiI1i111IiIiIi1 = IiII111i1i11
    if 39 - 39: ooOoO0o - iII111i
   except :
    pass
    if 53 - 53: Ii1I % i1I1i1Ii11 + IIII . oO0o - iII111i % Ii1I
    if 64 - 64: o0oOOo0O0Ooo
  ooOoO00 = Ii1IIiI1i ( IiI1i111IiIiIi1 )
  o0O00Oo0 = re . compile ( Ii ) . findall ( ooOoO00 )
  for ooO , Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI in o0O00Oo0 :
   try :
    II11IiIi11 ( Ooo0oOooo0 , oOOOoo00 , ooO , id , iiIiIIIiiI )
    if 40 - 40: I11i % OOooOOo
   except :
    pass
 except :
  pass
  if 62 - 62: Ii1I
  if 15 - 15: ooOoO0o + o00O0oo . I1Ii111 * OOooOOo . I11i
def IiIi1111ii ( ) :
 if 45 - 45: oO0o - Ii1I % o0o0OOO0o0
 try :
  if 38 - 38: o0o0OOO0o0 % I1Ii111 - OoO0O00
  ooOoO00 = Ii1IIiI1i ( OOI1iI1ii1II )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( ooOoO00 )
  for IiII111i1i11 in o0O00Oo0 :
   if 87 - 87: OOooOOo % I1ii11iIi11i
   try :
    if 77 - 77: Oo0Ooo - OoOoOO00 . IiII
    iIi1iIIIiIiI = IiII111i1i11
    if 62 - 62: II111iiii % I1Ii111 . IIIIII11i1I . I1Ii111
   except :
    pass
    if 84 - 84: II111iiii * OOooOOo
    if 18 - 18: I1Ii111 - o00O0oo - I11i / o0o0OOO0o0 - I1IiiI
  ooOoO00 = Ii1IIiI1i ( iIi1iIIIiIiI )
  o0O00Oo0 = re . compile ( Ii ) . findall ( ooOoO00 )
  for ooO , Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI in o0O00Oo0 :
   try :
    II11IiIi11 ( Ooo0oOooo0 , oOOOoo00 , ooO , id , iiIiIIIiiI )
    if 30 - 30: I1IiiI + iII111i + o0oOOo0O0Ooo
   except :
    pass
 except :
  pass
  if 14 - 14: Ii1I / I1Ii111 - Oo0Ooo - IiII % IIII
def I1iIiI1IiIIII ( ) :
 if 18 - 18: IIII % II111iiii . Oo0Ooo - i1I1i1Ii11
 try :
  if 80 - 80: I1ii11iIi11i + IiII - OoOoOO00 . o00O0oo / Ii1I / I1ii11iIi11i
  ooOoO00 = Ii1IIiI1i ( oOooO0 )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( ooOoO00 )
  for IiII111i1i11 in o0O00Oo0 :
   if 1 - 1: ooOoO0o + II111iiii - I1ii11iIi11i / I1Ii111 + o0o0OOO0o0
   try :
    if 80 - 80: IiII + Ii1I * o00O0oo + OOooOOo
    O0oOo = IiII111i1i11
    if 69 - 69: oO0o * o0oOOo0O0Ooo * IIII . i1I1i1Ii11 - iII111i
   except :
    pass
    if 39 - 39: o00O0oo * I1ii11iIi11i % OOooOOo . I11i
    if 24 - 24: OoOoOO00 * Oo0Ooo / o00O0oo
  ooOoO00 = Ii1IIiI1i ( O0oOo )
  o0O00Oo0 = re . compile ( Ii ) . findall ( ooOoO00 )
  for ooO , Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI in o0O00Oo0 :
   try :
    II11IiIi11 ( Ooo0oOooo0 , oOOOoo00 , ooO , id , iiIiIIIiiI )
    if 78 - 78: II111iiii + Ii1I + o0o0OOO0o0 / Ii1I % Oo0Ooo % IIIIII11i1I
   except :
    pass
 except :
  pass
  if 83 - 83: Oo0Ooo % I11i % Ii1I % o0o0OOO0o0 . iII111i % I1IiiI
  if 47 - 47: Ii1I
def oo0ooooO ( ) :
 if 12 - 12: o0oOOo0O0Ooo
 try :
  if 2 - 2: OoOoOO00 - I1ii11iIi11i + ooOoO0o . o0oOOo0O0Ooo
  ooOoO00 = Ii1IIiI1i ( OOoO0 )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( ooOoO00 )
  for IiII111i1i11 in o0O00Oo0 :
   if 25 - 25: IiII
   try :
    if 34 - 34: I11i . Oo0Ooo % I1IiiI
    iI11Ii111 = IiII111i1i11
    if 54 - 54: I11i % i1I1i1Ii11 . I11i * I1Ii111 + I11i % OoOoOO00
   except :
    pass
    if 23 - 23: o0o0OOO0o0 - I1Ii111 + o00O0oo - I11i * I11i . oO0o
    if 47 - 47: IiII % Oo0Ooo
  ooOoO00 = Ii1IIiI1i ( iI11Ii111 )
  o0O00Oo0 = re . compile ( Ii ) . findall ( ooOoO00 )
  for ooO , Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI in o0O00Oo0 :
   try :
    II11IiIi11 ( Ooo0oOooo0 , oOOOoo00 , ooO , id , iiIiIIIiiI )
    if 11 - 11: I1ii11iIi11i % o00O0oo - OOooOOo - IiII + Ii1I
   except :
    pass
 except :
  pass
  if 98 - 98: i1I1i1Ii11 + o00O0oo - OOooOOo
  if 79 - 79: I1Ii111 / o0o0OOO0o0 . I11i - iII111i
def Ii1ii11IIIi ( ) :
 if 82 - 82: IiII * Oo0Ooo . Ii1I . iII111i + I1Ii111 / I1ii11iIi11i
 try :
  if 58 - 58: o0o0OOO0o0 / IIII + I1IiiI + IIII . Oo0Ooo + o0oOOo0O0Ooo
  ooOoO00 = Ii1IIiI1i ( o00O0 )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( ooOoO00 )
  for IiII111i1i11 in o0O00Oo0 :
   if 37 - 37: ooOoO0o . oO0o % IIIIII11i1I * OoOoOO00
   try :
    if 71 - 71: oO0o / Ii1I + I1Ii111
    i11i11 = IiII111i1i11
    if 14 - 14: II111iiii
   except :
    pass
    if 73 - 73: IIII + IiII . OOooOOo
    if 46 - 46: OOooOOo - Ii1I / I11i - OoO0O00 + IiII
  ooOoO00 = Ii1IIiI1i ( i11i11 )
  o0O00Oo0 = re . compile ( Ii ) . findall ( ooOoO00 )
  for ooO , Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI in o0O00Oo0 :
   try :
    II11IiIi11 ( Ooo0oOooo0 , oOOOoo00 , ooO , id , iiIiIIIiiI )
    if 58 - 58: Ii1I / Ii1I + IIII + ooOoO0o - I11i . I1Ii111
   except :
    pass
 except :
  pass
  if 15 - 15: IIII * I11i % IIIIII11i1I . I11i . ooOoO0o
  if 97 - 97: IiII
def oOoO0O00oo ( ) :
 if 93 - 93: iII111i % I11i . I1IiiI / i1I1i1Ii11 * IiII
 try :
  if 29 - 29: Ii1I
  ooOoO00 = Ii1IIiI1i ( ii1 )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( ooOoO00 )
  for IiII111i1i11 in o0O00Oo0 :
   if 86 - 86: o0oOOo0O0Ooo . IIIIII11i1I
   try :
    if 2 - 2: OoO0O00
    o0o0O00 = IiII111i1i11
    if 35 - 35: Oo0Ooo
   except :
    pass
    if 94 - 94: I11i
    if 100 - 100: OOooOOo / OoOoOO00 - I1ii11iIi11i % o00O0oo - Oo0Ooo
  ooOoO00 = Ii1IIiI1i ( o0o0O00 )
  o0O00Oo0 = re . compile ( Ii ) . findall ( ooOoO00 )
  for ooO , Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI in o0O00Oo0 :
   try :
    II11IiIi11 ( Ooo0oOooo0 , oOOOoo00 , ooO , id , iiIiIIIiiI )
    if 17 - 17: ooOoO0o / Ii1I % oO0o
   except :
    pass
 except :
  pass
  if 71 - 71: IIIIII11i1I . o0o0OOO0o0 . OOooOOo
  if 68 - 68: II111iiii % IiII * OOooOOo * IIIIII11i1I * o0oOOo0O0Ooo + I1IiiI
def o00OoO0oO00 ( ) :
 if 2 - 2: Oo0Ooo
 try :
  if 45 - 45: OoO0O00 / II111iiii
  ooOoO00 = Ii1IIiI1i ( O0O0ooOOO )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( ooOoO00 )
  for IiII111i1i11 in o0O00Oo0 :
   if 10 - 10: i1I1i1Ii11 - IiII * Oo0Ooo % Oo0Ooo * IIIIII11i1I - iII111i
   try :
    if 97 - 97: o0oOOo0O0Ooo % o0o0OOO0o0 + o0o0OOO0o0 - OOooOOo / o00O0oo * I1ii11iIi11i
    iIii1iII1Ii = IiII111i1i11
    if 50 - 50: o00O0oo
   except :
    pass
    if 22 - 22: ooOoO0o * I1IiiI . o0oOOo0O0Ooo - OOooOOo
  ooOoO00 = Ii1IIiI1i ( iIii1iII1Ii )
  o0O00Oo0 = re . compile ( Ii ) . findall ( ooOoO00 )
  for ooO , Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI in o0O00Oo0 :
   try :
    II11IiIi11 ( Ooo0oOooo0 , oOOOoo00 , ooO , id , iiIiIIIiiI )
    if 90 - 90: IiII
   except :
    pass
 except :
  pass
  if 94 - 94: ooOoO0o / iII111i * o0o0OOO0o0 - I11i
  if 44 - 44: o00O0oo % II111iiii - i1I1i1Ii11 * iII111i + oO0o * I1Ii111
def IiI1iI1IiiIi1 ( ) :
 if 90 - 90: I1IiiI + ooOoO0o - OoO0O00 . ooOoO0o
 try :
  if 60 - 60: Ii1I . Ii1I / i1I1i1Ii11
  ooOoO00 = Ii1IIiI1i ( iIiIi11 )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( ooOoO00 )
  for IiII111i1i11 in o0O00Oo0 :
   if 45 - 45: I1IiiI . II111iiii % i1I1i1Ii11 . I11i % IIIIII11i1I % Oo0Ooo
   try :
    if 58 - 58: Oo0Ooo . I11i - II111iiii * Oo0Ooo % II111iiii / I1ii11iIi11i
    oO0oI1I1 = IiII111i1i11
    if 99 - 99: IIII / Oo0Ooo - o00O0oo * iII111i % I1ii11iIi11i
   except :
    pass
    if 13 - 13: OOooOOo
    if 70 - 70: o0o0OOO0o0 + I1IiiI . IiII * o00O0oo
  ooOoO00 = Ii1IIiI1i ( oO0oI1I1 )
  o0O00Oo0 = re . compile ( Ii ) . findall ( ooOoO00 )
  for ooO , Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI in o0O00Oo0 :
   try :
    II11IiIi11 ( Ooo0oOooo0 , oOOOoo00 , ooO , id , iiIiIIIiiI )
    if 2 - 2: OoO0O00 . I1Ii111 . IIIIII11i1I
   except :
    pass
 except :
  pass
  if 42 - 42: I1Ii111 % IiII / OOooOOo - IiII * II111iiii
def iI1IiiiIiI1Ii ( ) :
 if 78 - 78: OoO0O00 / I1Ii111 % I11i * OoO0O00
 try :
  if 68 - 68: IiII
  ooOoO00 = Ii1IIiI1i ( oooOo0OOOoo0 )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( ooOoO00 )
  for IiII111i1i11 in o0O00Oo0 :
   if 29 - 29: i1I1i1Ii11 + II111iiii % ooOoO0o
   try :
    if 93 - 93: I11i % Oo0Ooo
    Ooo0o0oo0 = IiII111i1i11
    if 87 - 87: I11i / IIIIII11i1I + Oo0Ooo
   except :
    pass
  ooOoO00 = Ii1IIiI1i ( Ooo0o0oo0 )
  o0O00Oo0 = re . compile ( Ii ) . findall ( ooOoO00 )
  for ooO , Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI in o0O00Oo0 :
   try :
    II11IiIi11 ( Ooo0oOooo0 , oOOOoo00 , ooO , id , iiIiIIIiiI )
    if 93 - 93: Oo0Ooo + IiII % IIII
   except :
    pass
 except :
  pass
  if 21 - 21: I1Ii111
def iIiI1I1IIi11 ( ) :
 if 9 - 9: IIII + i1I1i1Ii11 - ooOoO0o / OoOoOO00 % iII111i / IIIIII11i1I
 try :
  if 60 - 60: iII111i
  ooOoO00 = Ii1IIiI1i ( OO0O000 )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( ooOoO00 )
  for IiII111i1i11 in o0O00Oo0 :
   if 1 - 1: I11i . II111iiii % I11i - i1I1i1Ii11 % OoOoOO00 + iII111i
   try :
    if 2 - 2: Oo0Ooo * IiII / I11i . ooOoO0o / IIIIII11i1I
    o00O0OO = IiII111i1i11
    if 64 - 64: IIIIII11i1I . II111iiii / o0oOOo0O0Ooo + Ii1I * o00O0oo % I1IiiI
   except :
    pass
  ooOoO00 = Ii1IIiI1i ( o00O0OO )
  o0O00Oo0 = re . compile ( Ii ) . findall ( ooOoO00 )
  for ooO , Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI in o0O00Oo0 :
   try :
    II11IiIi11 ( Ooo0oOooo0 , oOOOoo00 , ooO , id , iiIiIIIiiI )
    if 89 - 89: o0o0OOO0o0 . IIIIII11i1I % oO0o . oO0o - OoO0O00
   except :
    pass
 except :
  pass
  if 56 - 56: ooOoO0o
def IiI1 ( ) :
 if 59 - 59: ooOoO0o / oO0o / I1Ii111 / I1IiiI / I11i + Ii1I
 try :
  if 13 - 13: Ii1I % IiII / o0o0OOO0o0 % o0o0OOO0o0 % I1IiiI
  ooOoO00 = Ii1IIiI1i ( i11I1IiII1i1i )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( ooOoO00 )
  for IiII111i1i11 in o0O00Oo0 :
   if 90 - 90: IIIIII11i1I . IIII / Oo0Ooo
   try :
    if 28 - 28: IIIIII11i1I + IiII - IIII / Oo0Ooo - I1ii11iIi11i
    Ii1i1oOoO00 = IiII111i1i11
    if 45 - 45: o00O0oo . OoO0O00
   except :
    pass
  ooOoO00 = Ii1IIiI1i ( Ii1i1oOoO00 )
  o0O00Oo0 = re . compile ( Ii ) . findall ( ooOoO00 )
  for ooO , Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI in o0O00Oo0 :
   try :
    II11IiIi11 ( Ooo0oOooo0 , oOOOoo00 , ooO , id , iiIiIIIiiI )
    if 27 - 27: o00O0oo * oO0o . I11i
   except :
    pass
 except :
  pass
  if 17 - 17: o0oOOo0O0Ooo % i1I1i1Ii11 * I1Ii111 % OoOoOO00 . I1ii11iIi11i . Oo0Ooo
def iiiIIIii ( ) :
 if 93 - 93: Oo0Ooo + I1ii11iIi11i + II111iiii
 try :
  if 74 - 74: ooOoO0o / o0oOOo0O0Ooo + IIII * Oo0Ooo - o0o0OOO0o0 - OOooOOo
  ooOoO00 = Ii1IIiI1i ( oO0O00oOOoooO )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( ooOoO00 )
  for IiII111i1i11 in o0O00Oo0 :
   if 69 - 69: Oo0Ooo * I1ii11iIi11i - i1I1i1Ii11 + I1IiiI + I1IiiI
   try :
    if 65 - 65: o0o0OOO0o0 / II111iiii / OOooOOo - I1Ii111
    IiI1o0O = IiII111i1i11
    if 38 - 38: IIII + IIIIII11i1I
   except :
    pass
  ooOoO00 = Ii1IIiI1i ( IiI1o0O )
  o0O00Oo0 = re . compile ( oOoO0o00OO0 ) . findall ( ooOoO00 )
  for ooO , Ooo0oOooo0 , oOOOoo00 in o0O00Oo0 :
   try :
    I11i11I ( ooO , Ooo0oOooo0 , oOOOoo00 )
    if 90 - 90: iII111i
   except :
    pass
    if 9 - 9: IIIIII11i1I + IIII
 except :
  pass
  if 7 - 7: I1IiiI % o0o0OOO0o0 + iII111i + o00O0oo % OoO0O00 . oO0o
  if 56 - 56: i1I1i1Ii11
  if 84 - 84: I11i - II111iiii
def I11i11I ( thumb , name , url ) :
 if 1 - 1: i1I1i1Ii11 * I11i
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( Ii1i1 ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   iIi1i1iIi1iI ( name , url , '' , i1ii1iIII , O0oOO0o0 )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 66 - 66: I11i + OoOoOO00 % o0oOOo0O0Ooo . I1IiiI * iII111i % iII111i
  if 'tvg-logo' in thumb :
   thumb = re . compile ( Ii1i1 ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 87 - 87: I1Ii111 + Ii1I . i1I1i1Ii11 - OoO0O00
   iiiiI1IiI1I1 ( name , url , 4 , iI111i11iI1 , O0oOO0o0 )
   if 2 - 2: I11i + o0o0OOO0o0 + OoO0O00 . OoOoOO00
  else :
   if 19 - 19: i1I1i1Ii11 - Ii1I - o00O0oo - I11i . i1I1i1Ii11 . o0o0OOO0o0
   iiiiI1IiI1I1 ( name , url , 4 , iI111i11iI1 , O0oOO0o0 )
   if 48 - 48: i1I1i1Ii11 + IIIIII11i1I
   if 60 - 60: ooOoO0o + i1I1i1Ii11 . IIIIII11i1I / OoOoOO00 . Oo0Ooo
def II11IiIi11 ( name , url , thumb , id , trailer ) :
 if 14 - 14: I1Ii111
 if 79 - 79: o00O0oo
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 76 - 76: Oo0Ooo
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( Ii1i1 ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   iIi1i1iIi1iI ( name , url , '' , i1ii1iIII , O0oOO0o0 )
 else :
  if 80 - 80: Oo0Ooo . I1IiiI / o00O0oo % o00O0oo
  if '[Rapidvideo]' in name :
   if 93 - 93: OoO0O00 * oO0o
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[Rapidvideo]' , '[COLOR orange][Rapidvideo][/COLOR]' ) % name
  if '[rapidvideo]' in name :
   if 10 - 10: o0o0OOO0o0 * OoO0O00 + ooOoO0o - iII111i / iII111i . II111iiii
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[streamgo]' , '[COLOR darkorange][streamgo][/COLOR]' ) % name
  elif '[streamago]' in name :
   if 22 - 22: o0o0OOO0o0 / Ii1I
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[Streamgo]' , '[COLOR orange][Streamgo][/COLOR]' ) % name
  elif '[Streamgo]' in name :
   if 98 - 98: OoOoOO00
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[Openload]' , '[COLOR red][Openload][/COLOR]' ) % name
  elif '[Openload]' in name :
   if 51 - 51: iII111i + IIII + oO0o / OoOoOO00 + OoOoOO00
   name = '[COLOR white]%s[/COLOR] [PAIR]' . replace ( '[Openload]' , '[COLOR red][openload Pair][/COLOR]' ) % name
  elif '[openload]' in name :
   if 12 - 12: Oo0Ooo . o00O0oo . iII111i % I1ii11iIi11i . o0oOOo0O0Ooo . IiII
   name = '[COLOR white]%s[/COLOR] [PAIR]' . replace ( '[openload]' , '[COLOR green][Vidoza][/COLOR]' ) % name
  elif '[Vidoza]' in name :
   if 32 - 32: iII111i + IIIIII11i1I / I1IiiI / I11i * OoO0O00 % IIII
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[Vidoza]' , '[COLOR green][Vidoza][/COLOR]' ) % name
  elif '[vidoza]' in name :
   if 50 - 50: OOooOOo
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[vidoza]' , '[COLOR green][vidoza][/COLOR]' ) % name
  elif '[Streamcloud]' in name :
   if 66 - 66: Oo0Ooo
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[Streamcloud]' , '[COLOR blue][Streamcloud][/COLOR]' ) % name
  elif '[streamcloud]' in name :
   if 41 - 41: o0o0OOO0o0 . I1IiiI * I1ii11iIi11i * iII111i
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[streamcloud]' , '[COLOR blue][streamcloud][/COLOR]' ) % name
   if 100 - 100: i1I1i1Ii11
  elif '[streamcherry]' in name :
   if 73 - 73: iII111i % o0oOOo0O0Ooo
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[streamcherry]' , '[COLOR pink][streamcherry][/COLOR]' ) % name
   if 79 - 79: I11i + OOooOOo - o0oOOo0O0Ooo + o00O0oo
  elif '[Streamcherry]' in name :
   if 11 - 11: IiII + Oo0Ooo
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[Streamcherry]' , '[COLOR pink][Streamcherry][/COLOR]' ) % name
   if 10 - 10: I1IiiI
  elif '[Okru]' in name :
   if 68 - 68: I1Ii111 + IiII . I1IiiI . o00O0oo % OoOoOO00 % I1Ii111
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[Okru]' , '[COLOR aqua][Okru][/COLOR]' ) % name
  elif '[okru]' in name :
   if 50 - 50: IIIIII11i1I + Ii1I
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[okru]' , '[COLOR aqua][okru][/COLOR]' ) % name
   if 96 - 96: OOooOOo
  elif '[4k]' in name :
   if 92 - 92: oO0o / II111iiii + iII111i
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[4k]' , '[COLOR yellow][4k][/COLOR]' ) % name
   if 87 - 87: I11i % Oo0Ooo
  elif '[Youtube]' in name :
   if 72 - 72: I1Ii111 . I1Ii111 - iII111i
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[Youtube]' , '[COLOR white][Youtube][/COLOR]' ) % name
  elif '[Realstream]' or '[Mybox]' in name :
   if 48 - 48: oO0o - IIII + oO0o - I1ii11iIi11i * II111iiii . i1I1i1Ii11
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[Realstream]' , '[COLOR magenta][Realstream][/COLOR]' ) % name
   if 35 - 35: IIIIII11i1I . I1IiiI + oO0o + I1Ii111 + OoOoOO00
  elif '[Team]' in name :
   if 65 - 65: I1IiiI * I1ii11iIi11i / I1ii11iIi11i . I11i
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[Team]' , '[COLOR magenta][Team][/COLOR]' ) % name
  elif '[Drive]' in name :
   if 87 - 87: o0oOOo0O0Ooo * iII111i % oO0o * oO0o
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[Drive]' , '[COLOR magenta][Drive][/COLOR]' ) % name
   if 58 - 58: I1Ii111 . Ii1I + I1ii11iIi11i % oO0o - OOooOOo
  elif '[vid]' in name :
   if 50 - 50: i1I1i1Ii11 % o0oOOo0O0Ooo - IIII . OoOoOO00 + I1IiiI % i1I1i1Ii11
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[vid]' , '[COLOR magenta][Vid][/COLOR]' ) % name
   if 10 - 10: i1I1i1Ii11 . OoOoOO00 + o00O0oo
  elif '[Vid]' in name :
   if 66 - 66: OOooOOo % Ii1I
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[Vid]' , '[COLOR magenta][Vid][/COLOR]' ) % name
  elif '[limited]' in name :
   if 21 - 21: I11i - OoO0O00 % II111iiii
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[limited]' , '[COLOR magenta][Limited][/COLOR]' ) % name
   if 71 - 71: OoOoOO00 - ooOoO0o * o0o0OOO0o0 + IiII - OOooOOo % iII111i
  elif '[Limited]' in name :
   if 63 - 63: Oo0Ooo + I1Ii111 . OOooOOo / I1ii11iIi11i
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[Limited]' , '[COLOR magenta][Limited][/COLOR]' ) % name
   if 84 - 84: OoOoOO00
  elif '[clipwatching]' in name :
   if 42 - 42: o0oOOo0O0Ooo - OOooOOo - OoO0O00 . i1I1i1Ii11 / I11i
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[clipwatching]' , '[COLOR pink][clipwatching][/COLOR]' ) % name
   if 56 - 56: II111iiii - Oo0Ooo . o0oOOo0O0Ooo
  elif '[Clipwatching]' in name :
   if 81 - 81: IIIIII11i1I / I11i * IIIIII11i1I . I1IiiI
   name = '[COLOR gold]%s[/COLOR]' . replace ( '[Clipwatching]' , '[COLOR pink][Clipwatching][/COLOR]' ) % name
   if 61 - 61: OOooOOo * I1Ii111 + o0o0OOO0o0 . Oo0Ooo % ooOoO0o . o0o0OOO0o0
  elif '[Vid]' in name :
   if 53 - 53: o0o0OOO0o0 * IIIIII11i1I / Oo0Ooo / I1ii11iIi11i % iII111i
   name = '[COLOR gold]%s[/COLOR]' % name
   if 39 - 39: OOooOOo / OoO0O00 . OOooOOo * iII111i / I11i
  else :
   if 38 - 38: OOooOOo / IIII % o0o0OOO0o0 * ooOoO0o + II111iiii % IIII
   name = '[COLOR white]%s[/COLOR]' % name
   if 61 - 61: o0o0OOO0o0 - o00O0oo % iII111i / IIII / i1I1i1Ii11 + Oo0Ooo
  if 'tvg-logo' in thumb :
   thumb = re . compile ( Ii1i1 ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 87 - 87: o0o0OOO0o0 + IIII + I1IiiI / OoOoOO00 % IIIIII11i1I / o0o0OOO0o0
   OOo000OO000 ( name , url , 1 , thumb , thumb , id , trailer )
   if 83 - 83: Ii1I % IiII + ooOoO0o % II111iiii + I1IiiI
  else :
   if 65 - 65: Oo0Ooo % IiII + I1IiiI / OoO0O00
   OOo000OO000 ( name , url , 1 , thumb , thumb , id , trailer )
   if 52 - 52: o00O0oo % I1Ii111 * I1ii11iIi11i % ooOoO0o + I1Ii111 / i1I1i1Ii11
def oo000o ( name , trailer ) :
 if 95 - 95: IiII - IIII * ooOoO0o / OOooOOo / o0oOOo0O0Ooo + I1IiiI
 if 37 - 37: ooOoO0o . o0o0OOO0o0 + I1Ii111 + ooOoO0o . IIIIII11i1I / o00O0oo
 oOOOoo00 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
 i1I = oOOOoo00
 oOOoooO0O0 = xbmcgui . ListItem ( name , trailer , path = i1I )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oOOoooO0O0 )
 return
 if 46 - 46: Oo0Ooo
 if 33 - 33: ooOoO0o % ooOoO0o % I1IiiI / I1ii11iIi11i . OoOoOO00
def O0O0ooOoOO0OO ( name , url ) :
 import urlresolver
 from urlresolver import common
 if 27 - 27: IIIIII11i1I * I1ii11iIi11i . Oo0Ooo - Oo0Ooo
 i111i1I1ii1i = urlresolver . HostedMediaFile ( url )
 if 100 - 100: IIIIII11i1I . o00O0oo - Oo0Ooo . II111iiii / o0oOOo0O0Ooo
 if not i111i1I1ii1i :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
  if 71 - 71: o0o0OOO0o0 * oO0o . ooOoO0o
  return False
  if 49 - 49: IIIIII11i1I * I1IiiI . IIIIII11i1I
  if 19 - 19: o0oOOo0O0Ooo - IIIIII11i1I
 try :
  OOOOo000o00OO = i111i1I1ii1i . resolve ( )
  if not OOOOo000o00OO or not isinstance ( OOOOo000o00OO , basestring ) :
   try : Oo0oOo0O0o000Ooo = OOOOo000o00OO . msg
   except : Oo0oOo0O0o000Ooo = url
   raise Exception ( Oo0oOo0O0o000Ooo )
 except Exception as I11i1II :
  try : Oo0oOo0O0o000Ooo = str ( I11i1II )
  except : Oo0oOo0O0o000Ooo = url
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,5000)" )
  if 65 - 65: I1IiiI . IIII
  return False
  if 39 - 39: IIII / I1IiiI * IIIIII11i1I
 Ii11iII1 = oo000 . getSetting ( 'notificar' )
 if Ii11iII1 == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
 I1IiI = xbmcgui . ListItem ( path = OOOOo000o00OO )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1IiI )
 if 44 - 44: I1Ii111 / I1Ii111 . Ii1I % IIIIII11i1I + I11i
def o0OOOoOOo0o ( name , url ) :
 if 50 - 50: o0oOOo0O0Ooo - o0o0OOO0o0 + Oo0Ooo + Oo0Ooo
 if 91 - 91: o0oOOo0O0Ooo - I1IiiI . Oo0Ooo . I1IiiI + iII111i - o0oOOo0O0Ooo
 if 'https://www.rapidvideo.com/v/' in url :
  if 26 - 26: Ii1I
  ooOoO00 = Ii1IIiI1i ( url )
  o0O00Oo0 = re . compile ( 'rapidvideo' ) . findall ( ooOoO00 )
  for url in o0O00Oo0 :
   if 12 - 12: OoO0O00 / I1IiiI + o0oOOo0O0Ooo * iII111i
   if 46 - 46: o0oOOo0O0Ooo - IIIIII11i1I * OoO0O00 / IiII % IIIIII11i1I
   try :
    Ii11iII1 = oo000 . getSetting ( 'notificar' )
    if Ii11iII1 == 'true' :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    I1IiI = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1IiI )
    if 11 - 11: Oo0Ooo . I11i / IIIIII11i1I % IIII
   except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 61 - 61: IIII - I1Ii111 + I1Ii111
   if 40 - 40: II111iiii . Oo0Ooo
 else :
  if 2 - 2: OoOoOO00 * IiII - IiII + OoO0O00 % I11i / I11i
  import urlresolver
  from urlresolver import common
  if 3 - 3: OoO0O00
  i111i1I1ii1i = urlresolver . HostedMediaFile ( url )
  if 71 - 71: IIIIII11i1I + OoOoOO00 - i1I1i1Ii11 - II111iiii . ooOoO0o - IIII
  if not i111i1I1ii1i :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 85 - 85: iII111i - I11i / iII111i + I1Ii111 - i1I1i1Ii11
   if 49 - 49: OOooOOo - I1IiiI / OOooOOo * I11i + o0o0OOO0o0
  try :
   OOOOo000o00OO = i111i1I1ii1i . resolve ( )
   if not OOOOo000o00OO or not isinstance ( OOOOo000o00OO , basestring ) :
    try : Oo0oOo0O0o000Ooo = OOOOo000o00OO . msg
    except : Oo0oOo0O0o000Ooo = url
    raise Exception ( Oo0oOo0O0o000Ooo )
  except Exception as I11i1II :
   try : Oo0oOo0O0o000Ooo = str ( I11i1II )
   except : Oo0oOo0O0o000Ooo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 35 - 35: o0oOOo0O0Ooo . I1ii11iIi11i / OoOoOO00 / I1ii11iIi11i * IiII
  Ii11iII1 = oo000 . getSetting ( 'notificar' )
  if Ii11iII1 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  I1IiI = xbmcgui . ListItem ( path = OOOOo000o00OO )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1IiI )
  if 85 - 85: o0oOOo0O0Ooo . IIII % I1Ii111 % ooOoO0o
 return
 if 80 - 80: IiII * ooOoO0o / Oo0Ooo % IiII / Oo0Ooo
 if 42 - 42: OoOoOO00 / II111iiii . oO0o * i1I1i1Ii11 . II111iiii * I1IiiI
 if 44 - 44: OoOoOO00 . I1ii11iIi11i / II111iiii + IIIIII11i1I
def iI111II1ii ( name , url ) :
 if 62 - 62: i1I1i1Ii11 * Oo0Ooo . IIIIII11i1I - OoO0O00 * o0oOOo0O0Ooo
 OOOOo000o00OO = url
 Ii11iII1 = oo000 . getSetting ( 'notificar' )
 if Ii11iII1 == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  I1IiI = xbmcgui . ListItem ( path = OOOOo000o00OO )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1IiI )
 else :
  I1IiI = xbmcgui . ListItem ( path = OOOOo000o00OO )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1IiI )
 return
 if 45 - 45: I1IiiI % I1ii11iIi11i - i1I1i1Ii11 . OOooOOo
def I1II ( name , url ) :
 if 9 - 9: oO0o % OoO0O00 - o00O0oo
 if 43 - 43: OOooOOo % OOooOOo
 if '[Youtube]' in name :
  if 46 - 46: oO0o % Oo0Ooo . i1I1i1Ii11 . I1IiiI * IIII / OoO0O00
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 7 - 7: IiII - I1IiiI * ooOoO0o - Ii1I - o0oOOo0O0Ooo
  try :
   Ii11iII1 = oo000 . getSetting ( 'notificar' )
   if Ii11iII1 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    I1IiI = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1IiI )
    if 41 - 41: I1ii11iIi11i - o0o0OOO0o0 % o0oOOo0O0Ooo . o0o0OOO0o0 - ooOoO0o
    if 45 - 45: o00O0oo - I1Ii111
    if 70 - 70: OOooOOo % I1ii11iIi11i / I1ii11iIi11i . ooOoO0o % IIII . o0oOOo0O0Ooo
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 10 - 10: o00O0oo - II111iiii . iII111i % OoOoOO00
  if 78 - 78: Oo0Ooo * oO0o . oO0o - I1Ii111 . Oo0Ooo
 else :
  if 30 - 30: IIII + IIII % IIIIII11i1I - Ii1I - iII111i
  import xbmcgui
  import urlresolver
  from urlresolver import common
  if 36 - 36: ooOoO0o % I1Ii111
  i111i1I1ii1i = urlresolver . HostedMediaFile ( url )
  if 72 - 72: I1ii11iIi11i / i1I1i1Ii11 - I1IiiI + ooOoO0o
  if not i111i1I1ii1i :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 83 - 83: I1IiiI
  import resolveurl as urlresolver
  if 89 - 89: oO0o + iII111i - Ii1I
  i111i1I1ii1i = urlresolver . HostedMediaFile ( url )
  if 40 - 40: OOooOOo + OOooOOo
  if 94 - 94: i1I1i1Ii11 * Oo0Ooo . ooOoO0o
  if not i111i1I1ii1i :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 13 - 13: Oo0Ooo * I11i / o0o0OOO0o0 % IIII + IiII
  try :
   OOOOo000o00OO = i111i1I1ii1i . resolve ( )
   if not OOOOo000o00OO or not isinstance ( OOOOo000o00OO , basestring ) :
    try : Oo0oOo0O0o000Ooo = OOOOo000o00OO . msg
    except : Oo0oOo0O0o000Ooo = url
    raise Exception ( Oo0oOo0O0o000Ooo )
  except Exception as I11i1II :
   try : Oo0oOo0O0o000Ooo = str ( I11i1II )
   except : Oo0oOo0O0o000Ooo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 41 - 41: iII111i
   if 5 - 5: oO0o
   if 100 - 100: o00O0oo + Oo0Ooo
  Ii11iII1 = oo000 . getSetting ( 'notificar' )
  if Ii11iII1 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 59 - 59: IIIIII11i1I
   if '[Realstream]' in name :
    if 89 - 89: I11i % Oo0Ooo
    IIIIii = oo000 . getSetting ( 'restante' )
    if IIIIii == 'true' :
     iIiiii = xbmcgui . Dialog ( )
     III11I1OOOO0o0O = iIiiii . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 41 - 41: Ii1I + IIII
   I1IiI = xbmcgui . ListItem ( path = OOOOo000o00OO )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1IiI )
   if 90 - 90: IIIIII11i1I - iII111i % ooOoO0o % Oo0Ooo - iII111i
   if 20 - 20: I1IiiI - OoO0O00 - IIIIII11i1I + Oo0Ooo
   if 94 - 94: o00O0oo . OoOoOO00
 return
 if 71 - 71: i1I1i1Ii11 + OOooOOo - IIIIII11i1I . OOooOOo . IIIIII11i1I + I1ii11iIi11i
 if 26 - 26: I1IiiI
 if 17 - 17: o0oOOo0O0Ooo
def iiIiii ( name , url ) :
 if 39 - 39: I1ii11iIi11i + oO0o
 if 83 - 83: OoOoOO00
 if '[Youtube]' in name :
  if 76 - 76: o00O0oo + Oo0Ooo + I11i . OOooOOo
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 49 - 49: IIIIII11i1I / IIII / I1Ii111
  try :
   Ii11iII1 = oo000 . getSetting ( 'notificar' )
   if Ii11iII1 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    I1IiI = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1IiI )
    if 25 - 25: I1ii11iIi11i % I1IiiI + OoOoOO00 - IIII
    if 38 - 38: Ii1I % o0o0OOO0o0 + II111iiii + i1I1i1Ii11 + IIII / II111iiii
    if 94 - 94: i1I1i1Ii11 - oO0o + IiII
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 59 - 59: ooOoO0o . I1ii11iIi11i - Oo0Ooo + Oo0Ooo
 else :
  if 56 - 56: IiII + IIII
  import resolveurl
  if 32 - 32: o0oOOo0O0Ooo + I11i % IIII / I11i + iII111i
  i111i1I1ii1i = urlresolver . HostedMediaFile ( url )
  if 2 - 2: II111iiii - o0o0OOO0o0 + OOooOOo % ooOoO0o * o00O0oo
  if 54 - 54: I1IiiI - i1I1i1Ii11 . I1Ii111 % i1I1i1Ii11 + i1I1i1Ii11
  if not i111i1I1ii1i :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 36 - 36: I1Ii111 % II111iiii
  try :
   OOOOo000o00OO = i111i1I1ii1i . resolve ( )
   if not OOOOo000o00OO or not isinstance ( OOOOo000o00OO , basestring ) :
    try : Oo0oOo0O0o000Ooo = OOOOo000o00OO . msg
    except : Oo0oOo0O0o000Ooo = url
    raise Exception ( Oo0oOo0O0o000Ooo )
  except Exception as I11i1II :
   try : Oo0oOo0O0o000Ooo = str ( I11i1II )
   except : Oo0oOo0O0o000Ooo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 47 - 47: OoOoOO00 + o0oOOo0O0Ooo . oO0o * IiII . ooOoO0o / OoOoOO00
   if 50 - 50: o0o0OOO0o0 / OoOoOO00 % OoO0O00
   if 83 - 83: iII111i * iII111i + I1Ii111
  Ii11iII1 = oo000 . getSetting ( 'notificar' )
  if Ii11iII1 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 57 - 57: I1IiiI - I1IiiI . iII111i / Ii1I / o00O0oo
   if '[Realstream]' in name :
    if 20 - 20: I1Ii111 * o0oOOo0O0Ooo - I11i - IiII * o0o0OOO0o0
    IIIIii = oo000 . getSetting ( 'restante' )
    if IIIIii == 'true' :
     iIiiii = xbmcgui . Dialog ( )
     III11I1OOOO0o0O = iIiiii . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 6 - 6: IIII + I1Ii111 / oO0o + IIIIII11i1I % o0oOOo0O0Ooo / OOooOOo
   I1IiI = xbmcgui . ListItem ( path = OOOOo000o00OO )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1IiI )
   if 45 - 45: OoO0O00
   if 9 - 9: ooOoO0o . OOooOOo * OoOoOO00 . OoO0O00
   if 32 - 32: I11i . iII111i % I1ii11iIi11i - o0oOOo0O0Ooo
 return
 if 11 - 11: I1IiiI + I1ii11iIi11i
def OO0OOoooo0o ( name , url ) :
 if 13 - 13: I1ii11iIi11i + I1IiiI - iII111i % oO0o / o00O0oo . OoOoOO00
 if 60 - 60: oO0o . IIIIII11i1I % I1ii11iIi11i - o0o0OOO0o0
 if '[Youtube]' in name :
  if 79 - 79: OoO0O00 / iII111i . I1IiiI
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 79 - 79: IiII - o0oOOo0O0Ooo
  try :
   Ii11iII1 = oo000 . getSetting ( 'notificar' )
   if Ii11iII1 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    I1IiI = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1IiI )
    if 43 - 43: OoOoOO00 + I1IiiI % OOooOOo / o00O0oo * I1ii11iIi11i
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 89 - 89: I1ii11iIi11i . oO0o + iII111i . I1IiiI % Ii1I
 else :
  if 84 - 84: OoO0O00 + o0o0OOO0o0 / I1ii11iIi11i % I1Ii111 % iII111i * I1ii11iIi11i
  if 'https://team.com' in url :
   if 58 - 58: OOooOOo - I11i . II111iiii % II111iiii / OoOoOO00 / IiII
   url = url . replace ( 'https://team.com' , 'https://verystream.com' )
   if 24 - 24: I1ii11iIi11i * OoOoOO00 % IIII / I1IiiI + II111iiii
  if 'https://mybox.com' in url :
   if 12 - 12: iII111i / o00O0oo
   url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
   if 5 - 5: OoO0O00
  if 'https://drive.com' in url :
   if 18 - 18: I1ii11iIi11i % OoO0O00 - i1I1i1Ii11 . II111iiii * oO0o % o00O0oo
   url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
   if 12 - 12: OoOoOO00 / I1Ii111 % IIII * IIIIII11i1I * I1IiiI * Oo0Ooo
  if 'https://vid.co/' in url :
   if 93 - 93: oO0o / iII111i + OoOoOO00 * IiII . OoO0O00
   url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
   if 54 - 54: I1IiiI / IIIIII11i1I % IIII * OoOoOO00 * I1IiiI
  if 'https://limited.to' in url :
   if 48 - 48: Ii1I . IiII % I11i - I11i
   url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
   if 33 - 33: ooOoO0o % o0oOOo0O0Ooo + OOooOOo
   if 93 - 93: OoOoOO00 . IIIIII11i1I / I1ii11iIi11i + IIIIII11i1I
  import resolveurl
  if 58 - 58: iII111i + I1IiiI . oO0o + I11i - OOooOOo - I11i
  i111i1I1ii1i = urlresolver . HostedMediaFile ( url )
  if 41 - 41: oO0o / OoOoOO00 / oO0o - i1I1i1Ii11 . Ii1I
  if 65 - 65: I1IiiI * II111iiii . OoO0O00 / I1ii11iIi11i / i1I1i1Ii11
  if not i111i1I1ii1i :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 69 - 69: IIII % IIII
  try :
   OOOOo000o00OO = i111i1I1ii1i . resolve ( )
   if not OOOOo000o00OO or not isinstance ( OOOOo000o00OO , basestring ) :
    try : Oo0oOo0O0o000Ooo = OOOOo000o00OO . msg
    except : Oo0oOo0O0o000Ooo = url
    raise Exception ( Oo0oOo0O0o000Ooo )
  except Exception as I11i1II :
   try : Oo0oOo0O0o000Ooo = str ( I11i1II )
   except : Oo0oOo0O0o000Ooo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 76 - 76: II111iiii * i1I1i1Ii11 / OOooOOo % iII111i + I1Ii111
   if 48 - 48: Oo0Ooo % OoOoOO00 + I11i % Ii1I
   if 79 - 79: I11i % I1ii11iIi11i % o00O0oo / OoOoOO00 % OOooOOo
  Ii11iII1 = oo000 . getSetting ( 'notificar' )
  if Ii11iII1 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 56 - 56: Oo0Ooo - II111iiii * i1I1i1Ii11
   if '[Realstream]' in name :
    iIiiii = xbmcgui . Dialog ( )
    III11I1OOOO0o0O = iIiiii . ok ( "[COLOR red][B]Real Stream:[/B] (Servidor de origen)[/COLOR]" , "[COLOR gold] Tiempo maximo de streaming de este servidor son[/COLOR][COLOR lime] 120 min. [/COLOR] [COLOR blue] Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold] O Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
    if 84 - 84: I1Ii111 + o00O0oo + Ii1I
   elif '[Mybox]' in name :
    iIiiii = xbmcgui . Dialog ( )
    III11I1OOOO0o0O = iIiiii . ok ( "[COLOR red][B]Real Stream:[/B] (Servidor de origen)[/COLOR]" , "[COLOR gold] Tiempo maximo de streaming de este servidor son[/COLOR][COLOR lime] 120 min. [/COLOR] [COLOR blue] Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold] O Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
   else :
    if 33 - 33: o00O0oo
    I1IiI = xbmcgui . ListItem ( path = OOOOo000o00OO )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1IiI )
    if 93 - 93: IIII
  else :
   if 34 - 34: IiII - IIII * oO0o / Ii1I
   I1IiI = xbmcgui . ListItem ( path = OOOOo000o00OO )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1IiI )
   if 19 - 19: iII111i
   if 46 - 46: Oo0Ooo . II111iiii - I11i % I1IiiI / o0oOOo0O0Ooo * OoOoOO00
 return
 if 66 - 66: I1IiiI
 if 52 - 52: OOooOOo * OoO0O00
 if 12 - 12: I1IiiI + IIIIII11i1I * OoOoOO00 . OOooOOo
def o0OO0oooo ( ) :
 if 40 - 40: o0o0OOO0o0 - I11i * ooOoO0o - IIIIII11i1I / I11i
 if 71 - 71: IiII / OoO0O00 % IIIIII11i1I / I11i % o0o0OOO0o0
 I1i1iI = [ ]
 I1iI1I1ii1 = sys . argv [ 2 ]
 if len ( I1iI1I1ii1 ) >= 2 :
  iIIi1 = sys . argv [ 2 ]
  o0Ooo0o0Oo = iIIi1 . replace ( '?' , '' )
  if ( iIIi1 [ len ( iIIi1 ) - 1 ] == '/' ) :
   iIIi1 = iIIi1 [ 0 : len ( iIIi1 ) - 2 ]
  oo00ooooOOo00 = o0Ooo0o0Oo . split ( '&' )
  I1i1iI = { }
  for ii1i in range ( len ( oo00ooooOOo00 ) ) :
   OO00Oooo000 = { }
   OO00Oooo000 = oo00ooooOOo00 [ ii1i ] . split ( '=' )
   if ( len ( OO00Oooo000 ) ) == 2 :
    I1i1iI [ OO00Oooo000 [ 0 ] ] = OO00Oooo000 [ 1 ]
 return I1i1iI
 if 38 - 38: OOooOOo . IIII
 if 34 - 34: OoOoOO00 % IIIIII11i1I
def OoOoIiI1 ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  import urlresolver
  xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
  if 13 - 13: OoO0O00 + OOooOOo
def ii1IIii ( ) :
 iIiiii = xbmcgui . Dialog ( )
 list = (
 IiI11i1I11111 ,
 Ii1IIIIIIiI1
 )
 if 24 - 24: I1ii11iIi11i * o00O0oo % I1IiiI - oO0o
 OOo00OoO = iIiiii . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=gold]Accede a themoviedb.com[/COLOR]' ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 30 - 30: OoOoOO00
 if OOo00OoO :
  if 4 - 4: o0o0OOO0o0 - I1ii11iIi11i % IiII / Ii1I % IiII * o0oOOo0O0Ooo
  if OOo00OoO < 0 :
   return
  oOO00O0Ooooo00 = list [ OOo00OoO - 2 ]
  return oOO00O0Ooooo00 ( )
 else :
  oOO00O0Ooooo00 = list [ OOo00OoO ]
  return oOO00O0Ooooo00 ( )
 return
 if 3 - 3: OoOoOO00 / o0o0OOO0o0 - OoOoOO00 - ooOoO0o % oO0o - I1ii11iIi11i
def ii111I11iI ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 45 - 45: IIIIII11i1I
Ooooooo = ii111I11iI ( )
if 7 - 7: Oo0Ooo - OoOoOO00
def IiI11i1I11111 ( ) :
 if Ooooooo == 'android' :
  o0iiiI1I1iIIIi1 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  o0iiiI1I1iIIIi1 = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 10 - 10: o0o0OOO0o0 % I1IiiI / I1ii11iIi11i % ooOoO0o
  if 25 - 25: o0oOOo0O0Ooo / OOooOOo
def Ii1IIIIIIiI1 ( ) :
 if 64 - 64: I1IiiI % IIII
 main ( )
 if 40 - 40: Ii1I + ooOoO0o
 if 77 - 77: II111iiii % IIIIII11i1I + o0o0OOO0o0 % OoO0O00 - ooOoO0o
 if 26 - 26: oO0o + I1IiiI - Oo0Ooo
def iiI1 ( ) :
 iIiiii = xbmcgui . Dialog ( )
 O0000OOO0 = (
 I1IIIIIi1IIiI ,
 III11I11ii
 )
 if 82 - 82: I1Ii111 % o0oOOo0O0Ooo - I1Ii111 + o0oOOo0O0Ooo
 OOo00OoO = iIiiii . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 61 - 61: II111iiii * IiII % oO0o * o0o0OOO0o0 - OoO0O00 - OOooOOo
 if OOo00OoO :
  if 83 - 83: IIII / I1Ii111
  if OOo00OoO < 0 :
   return
  oOO00O0Ooooo00 = O0000OOO0 [ OOo00OoO - 2 ]
  return oOO00O0Ooooo00 ( )
 else :
  oOO00O0Ooooo00 = O0000OOO0 [ OOo00OoO ]
  return oOO00O0Ooooo00 ( )
 return
 if 39 - 39: IIIIII11i1I + ooOoO0o
def ii111I11iI ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 9 - 9: I1ii11iIi11i % ooOoO0o . oO0o * I1ii11iIi11i
Ooooooo = ii111I11iI ( )
if 99 - 99: I1IiiI . Ii1I % ooOoO0o - oO0o / ooOoO0o
def I1IIIIIi1IIiI ( ) :
 if Ooooooo == 'android' :
  o0iiiI1I1iIIIi1 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  o0iiiI1I1iIIIi1 = webbrowser . open ( 'https://olpair.com/' )
  if 20 - 20: I11i * i1I1i1Ii11
  if 19 - 19: OoO0O00
def III11I11ii ( ) :
 if 76 - 76: OOooOOo * IiII
 main ( )
 if 63 - 63: o0oOOo0O0Ooo . o0oOOo0O0Ooo + iII111i + I1Ii111 + I1IiiI . o00O0oo
 if 1 - 1: I1IiiI * II111iiii - IIII - o00O0oo
def oOO000 ( name , url , id , trailer ) :
 iIiiii = xbmcgui . Dialog ( )
 O0000OOO0 = (
 OoOooO ,
 OoO0o00OOOOO ,
 I1iIi1iIIIIiI ,
 ii1IIii ,
 O000oooOO0Oo0
 )
 if 31 - 31: IIIIII11i1I - OOooOOo / I1Ii111 . OoOoOO00 / o00O0oo
 OOo00OoO = iIiiii . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=yellow]                                                 [B]Ver Pelicula[/B] [/COLOR]' ,

 '[COLOR=blue]                                                   [B]Ver Trailer[/B][/COLOR]' ,

 '[COLOR=green]                                          [B]Abrir informacion extendida  [/B][/COLOR]' ,

 '[COLOR=orange]                                           [B]Accede a la web MovieDB[/B][/COLOR]' ,

 '[COLOR=orange]                                                     [B]Salir[/B][/COLOR]' ] )
 if 66 - 66: OOooOOo
 if OOo00OoO :
  if 72 - 72: o0o0OOO0o0
  if OOo00OoO < 0 :
   return
  oOO00O0Ooooo00 = O0000OOO0 [ OOo00OoO - 5 ]
  return oOO00O0Ooooo00 ( )
 else :
  oOO00O0Ooooo00 = O0000OOO0 [ OOo00OoO ]
  return oOO00O0Ooooo00 ( )
 return
 if 91 - 91: o0oOOo0O0Ooo / IIIIII11i1I + Oo0Ooo . ooOoO0o - I1IiiI
 if 70 - 70: o00O0oo * IiII - ooOoO0o + oO0o % iII111i - IIIIII11i1I
 if 81 - 81: I1IiiI . I1IiiI
def OoOooO ( ) :
 if 75 - 75: Oo0Ooo % IIIIII11i1I + iII111i * I1IiiI . i1I1i1Ii11 - IIII
 OO0OOoooo0o ( Ooo0oOooo0 , oOOOoo00 )
 if 32 - 32: o00O0oo % IiII - OoOoOO00
def OoO0o00OOOOO ( ) :
 if 40 - 40: Oo0Ooo + i1I1i1Ii11 * I11i + IiII
 oo000o ( Ooo0oOooo0 , iiIiIIIiiI )
 if 15 - 15: ooOoO0o % I1ii11iIi11i - Oo0Ooo * IIII
def I1iIi1iIIIIiI ( ) :
 if 71 - 71: I11i % oO0o % IIII
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  I111 = id
  if 6 - 6: I11i / IIII + i1I1i1Ii11 - Ii1I * I1Ii111 + IIII
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % I111 )
  if 76 - 76: o0oOOo0O0Ooo - OoO0O00 % IIIIII11i1I
 if Ii11iII1 == 'true' :
  if 40 - 40: o00O0oo
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + Ooo0oOooo0 + "[/COLOR] ,5000)" )
  if 59 - 59: ooOoO0o * OoO0O00 + I1Ii111 . Oo0Ooo / OoOoOO00
def O0Oo0O00o0oo0OO ( ) :
 if 97 - 97: II111iiii + I11i / IIII % I1Ii111
 ii1IIii ( )
 if 38 - 38: I1Ii111 % IIIIII11i1I % o0oOOo0O0Ooo - oO0o - Oo0Ooo
def O000oooOO0Oo0 ( ) :
 if 9 - 9: Ii1I % iII111i . iII111i
 main ( )
def iIi1i1iIi1iI ( name , url , mode , iconimage , fanart ) :
 if 28 - 28: OoO0O00 % IiII + iII111i + I1IiiI . o0o0OOO0o0
 ooOO0OOO00o = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 III11I1OOOO0o0O = True
 OoOoO0ooooO0 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 OoOoO0ooooO0 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 OoOoO0ooooO0 . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  ooOO0OOO00o = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  III11I1OOOO0o0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ooOO0OOO00o , listitem = OoOoO0ooooO0 , isFolder = True )
  return III11I1OOOO0o0O
 III11I1OOOO0o0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ooOO0OOO00o , listitem = OoOoO0ooooO0 , isFolder = True )
 return III11I1OOOO0o0O
 if 4 - 4: oO0o - OOooOOo - II111iiii * o0o0OOO0o0 / o00O0oo - I1Ii111
def OOo000OO000 ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 45 - 45: Ii1I % oO0o * OoOoOO00 - I1IiiI
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 oo00 = [ ]
 ooOO0OOO00o = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 OoOoO0ooooO0 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 OoOoO0ooooO0 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 OoOoO0ooooO0 . setProperty ( 'fanart_image' , fanart )
 OoOoO0ooooO0 . setProperty ( 'IsPlayable' , 'true' )
 if 61 - 61: Oo0Ooo + IiII
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  oo00 . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  OoOoO0ooooO0 . addContextMenuItems ( oo00 , replaceItems = True )
 III11I1OOOO0o0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ooOO0OOO00o , listitem = OoOoO0ooooO0 )
 return III11I1OOOO0o0O
 if 8 - 8: o0o0OOO0o0 + OOooOOo
def iiiiI1IiI1I1 ( name , url , mode , iconimage , fanart ) :
 if 9 - 9: I1Ii111 + Ii1I
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 8 - 8: I1Ii111 * oO0o / i1I1i1Ii11 - OOooOOo - OoO0O00
 ooOO0OOO00o = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 OoOoO0ooooO0 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 OoOoO0ooooO0 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 OoOoO0ooooO0 . setProperty ( 'fanart_image' , fanart )
 OoOoO0ooooO0 . setProperty ( 'IsPlayable' , 'true' )
 III11I1OOOO0o0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ooOO0OOO00o , listitem = OoOoO0ooooO0 )
 return III11I1OOOO0o0O
 if 100 - 100: IiII . Oo0Ooo . Oo0Ooo
def oOOo0ooO0 ( name , url , mode ) :
 if 38 - 38: o0o0OOO0o0
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 18 - 18: i1I1i1Ii11 / Ii1I + IIIIII11i1I % IiII - IIIIII11i1I
 ooOO0OOO00o = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 OoOoO0ooooO0 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iI111i11iI1 )
 OoOoO0ooooO0 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 OoOoO0ooooO0 . setProperty ( 'fanart_image' , O0oOO0o0 )
 OoOoO0ooooO0 . setProperty ( 'IsPlayable' , 'true' )
 III11I1OOOO0o0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ooOO0OOO00o , listitem = OoOoO0ooooO0 )
 return III11I1OOOO0o0O
 if 18 - 18: I1ii11iIi11i + IIII % iII111i - I11i * II111iiii . Ii1I
def i1i111 ( name , url , mode , iconimage ) :
 ooOO0OOO00o = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 III11I1OOOO0o0O = True
 OoOoO0ooooO0 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 III11I1OOOO0o0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ooOO0OOO00o , listitem = OoOoO0ooooO0 , isFolder = True )
 return III11I1OOOO0o0O
 if 25 - 25: OoO0O00 % o00O0oo * o0oOOo0O0Ooo - OOooOOo
def Oo00Oooo00o ( ) :
 if 6 - 6: I11i - IIII * Ii1I + I11i % Ii1I
 if 100 - 100: OOooOOo % o0o0OOO0o0 - ooOoO0o % ooOoO0o % ooOoO0o / IIII
 if 83 - 83: IiII - IIII - IIIIII11i1I % OoOoOO00 - i1I1i1Ii11 . Ii1I
 II11Iiii = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 II11Iiii . doModal ( )
 if ( II11Iiii . isConfirmed ( ) ) :
  if 96 - 96: oO0o + o0o0OOO0o0 . OoOoOO00
  O000 = urllib . quote_plus ( II11Iiii . getText ( ) ) . replace ( '+' , ' ' )
  if 54 - 54: o0oOOo0O0Ooo . OoOoOO00 / iII111i % I1ii11iIi11i / o0o0OOO0o0
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 65 - 65: I11i . I11i - IiII + oO0o / II111iiii
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % O000 )
    if 90 - 90: Oo0Ooo + I11i
    if Ii11iII1 == 'true' :
     if 9 - 9: Oo0Ooo . OoO0O00 + OoOoOO00 - oO0o
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + Ooo0oOooo0 + "[/COLOR] ,10000)" )
     if 30 - 30: i1I1i1Ii11 / OOooOOo . i1I1i1Ii11
   except :
    if 17 - 17: oO0o + OoO0O00 * OoO0O00
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 5 - 5: o0o0OOO0o0 % OoO0O00 . I11i
    if 67 - 67: iII111i + o00O0oo
    if 72 - 72: IIIIII11i1I % Ii1I
iIIi1 = o0OO0oooo ( )
oOOOoo00 = None
Ooo0oOooo0 = None
OooooO = None
iI111i11iI1 = None
id = None
iiIiIIIiiI = None
if 77 - 77: I1ii11iIi11i % IIII
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 74 - 74: I11i / OoOoOO00 % OoO0O00
try :
 oOOOoo00 = urllib . unquote_plus ( iIIi1 [ "url" ] )
except :
 pass
try :
 Ooo0oOooo0 = urllib . unquote_plus ( iIIi1 [ "name" ] )
except :
 pass
try :
 OooooO = int ( iIIi1 [ "mode" ] )
except :
 pass
try :
 iI111i11iI1 = urllib . unquote_plus ( iIIi1 [ "iconimage" ] )
except :
 pass
try :
 id = int ( iIIi1 [ "id" ] )
except :
 pass
try :
 iiIiIIIiiI = urllib . unquote_plus ( iIIi1 [ "trailer" ] )
except :
 pass
 if 52 - 52: IIIIII11i1I % IIII
 if 25 - 25: ooOoO0o / ooOoO0o % OoO0O00 - iII111i * IiII
print "Mode: " + str ( OooooO )
print "URL: " + str ( oOOOoo00 )
print "Name: " + str ( Ooo0oOooo0 )
print "iconimage: " + str ( iI111i11iI1 )
print "id: " + str ( id )
print "trailer: " + str ( iiIiIIIiiI )
if 23 - 23: II111iiii
if OooooO == None or oOOOoo00 == None or len ( oOOOoo00 ) < 1 :
 if Oo0oOOo == Oo0OoO00oOO0o :
  if 100 - 100: IiII + I1IiiI . I1ii11iIi11i + OoOoOO00 - I11i + Ii1I
  i1II1 ( )
  O0o0 = oo000 . getSetting ( 'aviso' )
  if O0o0 == 'true' :
   OOOooo ( )
   if 65 - 65: o0oOOo0O0Ooo / oO0o
   if 42 - 42: II111iiii . I1IiiI
  iIi11Ii1 = oo000 . getSetting ( 'licencia_addon' )
  i1iIIIi1i = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  o0oo0Oo = oo000 . getSetting ( 'key_ext' )
  iI1iIIiiii = 'aHR0cDovL2JpdC5seS8yUjQxbmh1' . decode ( 'base64' )
  ooOoO00 = Ii1IIiI1i ( iI1iIIiiii )
  o0O00Oo0 = re . compile ( oO0000OOo00 ) . findall ( ooOoO00 )
  for i1i1I1II in o0O00Oo0 :
   try :
    if 66 - 66: IIIIII11i1I + Oo0Ooo
    if 75 - 75: iII111i
    iIi11Ii1 = oo000 . getSetting ( 'licencia_addon' )
    if 92 - 92: ooOoO0o / I1IiiI * I1ii11iIi11i - ooOoO0o
    if 99 - 99: II111iiii % OoO0O00
    if iIi11Ii1 == i1i1I1II :
     if 56 - 56: IIIIII11i1I * o0o0OOO0o0
     xbmcgui . Dialog ( ) . ok ( "Realstream Licencia:" , "[COLOR lime]Su llave es correcta![/COLOR] [COLOR gold]Sientese y disfrute de Realstream.[/COLOR]" )
     if 98 - 98: ooOoO0o + I1IiiI * o0o0OOO0o0 + II111iiii - I1Ii111 - Oo0Ooo
     III11I1 ( )
     if 5 - 5: I1Ii111 % oO0o % IIIIII11i1I % IIII
    else :
     if 17 - 17: o00O0oo + o0oOOo0O0Ooo + OoO0O00 / I1Ii111 / IIIIII11i1I
     xbmcgui . Dialog ( ) . ok ( "Realstream Licencia:" , "[COLOR red]Ha introducido una llave erronea.[/COLOR] [COLOR gold]Ponganse en contacto con nosotros en nuestro grupo de telegram.[/COLOR]" )
     if 80 - 80: Ii1I % OoOoOO00 / ooOoO0o
     if 56 - 56: OoOoOO00 . II111iiii
   except :
    pass
    if 15 - 15: o0oOOo0O0Ooo * IiII % i1I1i1Ii11 / II111iiii - IiII + oO0o
 else :
  xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red][B]Error, de inicio. ¿Tienes Instalado Realstream?[/B][/COLOR]" )
  if 9 - 9: ooOoO0o - IiII + I1IiiI / i1I1i1Ii11 % OoOoOO00
  if 97 - 97: Ii1I * IIII
elif OooooO == 1 :
 oOO000 ( Ooo0oOooo0 , oOOOoo00 , id , iiIiIIIiiI )
elif OooooO == 2 :
 I11oo0ooOO ( )
elif OooooO == 3 :
 O0000 ( )
elif OooooO == 4 :
 O0O0ooOoOO0OO ( Ooo0oOooo0 , oOOOoo00 )
elif OooooO == 5 :
 i1OoOO ( )
elif OooooO == 6 :
 I11iIiI1 ( )
elif OooooO == 7 :
 Ooo ( )
elif OooooO == 8 :
 I11IIIiIi11 ( )
elif OooooO == 9 :
 oOO0oo ( )
elif OooooO == 10 :
 ooOoOOOOo ( )
elif OooooO == 11 :
 i1o0oooO ( )
elif OooooO == 12 :
 oo00ooOoo ( )
elif OooooO == 13 :
 I1i ( )
elif OooooO == 14 :
 OOO0o ( )
elif OooooO == 15 :
 I11i1iIiiIiIi ( )
elif OooooO == 16 :
 IiIiiI11i1Ii ( )
elif OooooO == 17 :
 IiIi1111ii ( )
elif OooooO == 18 :
 I1iIiI1IiIIII ( )
elif OooooO == 19 :
 oo0ooooO ( )
elif OooooO == 20 :
 Ii1ii11IIIi ( )
elif OooooO == 21 :
 oOoO0O00oo ( )
elif OooooO == 22 :
 o00OoO0oO00 ( )
elif OooooO == 23 :
 IiI1iI1IiiIi1 ( )
elif OooooO == 24 :
 iI1IiiiIiI1Ii ( )
elif OooooO == 25 :
 iIiI1I1IIi11 ( )
elif OooooO == 26 :
 Ii111 ( )
elif OooooO == 28 :
 iI111II1ii ( Ooo0oOooo0 , oOOOoo00 )
elif OooooO == 98 :
 busqueda_global ( )
elif OooooO == 97 :
 iiI1 ( )
elif OooooO == 99 :
 oO0Ooo0ooOO0 ( )
elif OooooO == 100 :
 menu_player ( Ooo0oOooo0 , oOOOoo00 )
elif OooooO == 111 :
 I11iiiiIIii1I ( )
elif OooooO == 115 :
 oo000o ( oOOOoo00 )
elif OooooO == 116 :
 o00oo0 ( )
elif OooooO == 119 :
 I111IiiIi1 ( )
elif OooooO == 120 :
 oOOo000oOoO0 ( )
elif OooooO == 121 :
 oOooO0OOOoO000 ( )
elif OooooO == 125 :
 iiiIIIii ( )
elif OooooO == 112 :
 oOIIi1iiii1iI ( )
elif OooooO == 127 :
 Oo00Oooo00o ( )
elif OooooO == 128 :
 TESTLINKS ( )
elif OooooO == 140 :
 iiI11I ( )
elif OooooO == 141 :
 IiI1 ( )
xbmcplugin . endOfDirectory ( oOOo ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
