# -*- coding: utf-8 -*-
# Real stream by Netai 2019
import urllib, urllib2, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import cookielib,webbrowser
import traceback,datetime,HTMLParser,httplib
import urlresolver
import cookielib,base64
import requests


db = 'http://netai.eu/realstream/todas.m3u'
op = 'https://raw.githubusercontent.com/Andorth/rs/master/accion.m3u'
op1 = 'https://raw.githubusercontent.com/Andorth/rs/master/estrenos.m3u'
op2 = 'https://raw.githubusercontent.com/Andorth/rs/master/recomendadas.m3u'
op3 = 'https://raw.githubusercontent.com/Andorth/rs/master/accion.m3u'
op4 = 'https://raw.githubusercontent.com/Andorth/rs/master/animacion.m3u'
op5 = 'https://raw.githubusercontent.com/Andorth/rs/master/aventuras.m3u'
op6 = 'https://raw.githubusercontent.com/Andorth/rs/master/belico.m3u'
op7 = 'https://raw.githubusercontent.com/Andorth/rs/master/cifi.m3u'
op8 = 'https://raw.githubusercontent.com/Andorth/rs/master/comedia.m3u'
op9 = 'https://raw.githubusercontent.com/Andorth/rs/master/crimen.m3u'
op10 = 'https://raw.githubusercontent.com/Andorth/rs/master/drama.m3u'
op11 = 'https://raw.githubusercontent.com/Andorth/rs/master/familiar.m3u'
op12 = 'https://raw.githubusercontent.com/Andorth/rs/master/fantasia.m3u'
op13 = 'https://raw.githubusercontent.com/Andorth/rs/master/historia.m3u'
op14 = 'https://raw.githubusercontent.com/Andorth/rs/master/misterio.m3u'
op15 = 'https://raw.githubusercontent.com/Andorth/rs/master/musical.m3u'
op16 = 'https://raw.githubusercontent.com/Andorth/rs/master/romance.m3u'
op17 = 'https://raw.githubusercontent.com/Andorth/rs/master/thriller.m3u'
op18 = 'https://raw.githubusercontent.com/Andorth/rs/master/suspense.m3u'
op19 = 'https://raw.githubusercontent.com/Andorth/rs/master/terror.m3u'
op20 = 'https://raw.githubusercontent.com/Andorth/rs/master/western.m3u'
op21 = 'https://raw.githubusercontent.com/Andorth/rs/master/spain.m3u'
op22 = 'https://raw.githubusercontent.com/Andorth/rs/master/superheroes.m3u'
op23 = 'https://raw.githubusercontent.com/Andorth/rs/master/sagas.m3u'
op24 = 'https://raw.githubusercontent.com/Andorth/rs/master/4k.m3u'

