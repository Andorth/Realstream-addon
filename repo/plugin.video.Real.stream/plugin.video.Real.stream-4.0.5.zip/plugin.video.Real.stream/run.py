# -*- coding: utf-8 -*-

"""

	𝐑𝐄𝐀𝐋𝐒𝐓𝐑𝐄𝐀𝐌 
	𝐁𝐘 𝐍𝐄𝐓𝐀𝐈 𝐓𝐄𝐀𝐌 𝟐𝟎𝟐𝟎  Ver (4.05)

    
			
	Hemos decidido liberar parte de el codigo para el estudio.
	Utiliza este codigo con cabeza, y sin animo de lucro.
	
	Inspirado en codigo de los addons: TheMachine, Livestreampro, Megasearch, Realstream.
	
	No podemos dejar atras a los desarrolladores de Scrips como Extended Info, URLResolver, ResolverUrl
	sin ellos este addon no podría funcionar.
	
	Y a todos los desarrolladores de codigo libre, El conocimiento, el aprendizaje no tienen precio. 
	
	A todos gracias!
	
			
"""

import urllib, urllib2, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import cookielib,webbrowser
import traceback,datetime,HTMLParser,httplib
import cookielib,base64, zlib
import requests	
import codecs
import json

def base64dec(string):
    base64_message = string
    base64_bytes = base64_message.encode('ascii')
    message_bytes = base64.b64decode(base64_bytes)
    message = message_bytes.decode('ascii')
    return(message) 


#LLave Realstream:

keygen = base64dec('aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtL2tleXdlYi50eHQ=')
#URLS SERIES - > Aqui van las rutas a las listas m3u
dbtodas = "https://pastebin.com/raw/Srm3WyzH"
dbserie4K = base64dec('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1FCeGRZaDk1')
dbserie = base64dec('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L3VxN3FWa0Yw')
dbtserie = base64dec('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L21DTXhnUVRk')
dbeserie = base64dec('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1RHN2VwVFh4')
dbrserie = base64dec('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0RDeE5EVWsz')
dbnserie = base64dec('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L2c4eVB5OEtW')
dbiserie = base64dec('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3LzBZRXFMYjBG')
#URLS PELICULAS - > Aqui van las rutas a las listas m3u

dbpelicula = base64dec('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L3NRNmU1MXBO') 
db4k = base64dec('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L3h6ZFN2ckE4') 
dbnovedades = base64dec('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L3l5M0x6RlBq') 
dbestrenos = base64dec('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3LzZ5QlFNRTVV') 
dbclasico = base64dec('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3LzJ5V2Y2WFNU')
dbgpelis = base64dec('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L251a0R0blFm') 
dbfamiliar = base64dec('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0htOXRGNVVl') 
dbanimacion = base64dec('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L2RWTlVQa1lq') 
dbsuperheroes = base64dec('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0NDbTQ4NXZW')
Stemp = base64dec('aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtL1Nlcmllcy9kYXRhc2VyaWVzL3Nlcmllc190ZW1wLm0zdQ==')
MasterKey = base64dec('aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtL1VzdWFyaW9zL1VkYi50eHQ=')
addon_id = base64dec('cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt')
visitante = base64dec('aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtL3VsdGltYV92ZXJzaW9uLnR4dA==')
contador = base64dec('aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtL3Zpc2l0YXMvaW5kZXgucGhw')
myaddon = base64dec('cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt')
dbpeliculast = base64dec('aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtL1BlbGljdWxhcy9kYi5tM3U=')
sagasxml = base64dec('aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtL21lbnUvc2FnYXMueG1s')
sectionsxml = base64dec('aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtL21lbnUvc2VjdGlvbnMueG1s')
seriesxml = base64dec('aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtL1Nlcmllcy9kYXRhc2VyaWVzL01lbnVfc2VyaWVzLnhtbA==')
rs_registro = base64dec('aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtL1VzdWFyaW9zL2luaWNpby5waHA=')
series_menu = base64dec('aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtL1Nlcmllcy9kYXRhc2VyaWVzL01lbnVfc2VyaWVzLnhtbA==')
ser_data = base64dec('aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtL1Nlcmllcy9kYXRhc2VyaWVzL1Nlcmllcy5tM3U=')

# Menu Categorias:
series4k = "https://i.imgur.com/utoz44H.jpg"
calidad4k = "https://i.imgur.com/qa6LA7F.png"
extended = "https://i.imgur.com/xlnrAxE.jpg"
buscar = "https://i.imgur.com/nZcJmXn.png"
pair = "https://i.imgur.com/jKnDMlt.png"
theMovieDB = "https://i.imgur.com/xlnrAxE.jpg"
novedades = "https://i.imgur.com/GVMsDlk.png"
estrenos = "https://i.imgur.com/iM9hY3c.png"
recomendadas = ""
animacion = "https://i.imgur.com/D5B1ilU.png"
clasico = "https://i.imgur.com/9IxjIoh.png"
a_z = "https://i.imgur.com/rjY2Tfp.png"
by_years = "https://i.imgur.com/Tyr0WSn.png"
by_genre ="https://i.imgur.com/rsNd5R6.png"
filmoteca = "https://i.imgur.com/JWDirtu.jpg"
familiar = "https://i.imgur.com/Pzm5hP2.png"
superheroes = "https://i.imgur.com/9czS5yl.png" 
sagas = "https://i.imgur.com/aS5LpZr.png"
buscarseries = "https://i.imgur.com/YZR56pn.png"
seriestodas = "https://i.imgur.com/xNmhb3A.png"
favorites = "https://i.imgur.com/NeMqZgp.png"
emision = "https://i.imgur.com/CHq7MHw.png"
mejores = "https://i.imgur.com/8HoOXn2.png"
seriesreto = "https://i.imgur.com/RTF3Ose.png"
seriesinfantiles = "https://i.imgur.com/vvJ4kyK.jpg"
evento = "https://i.imgur.com/Uta1Huo.png"
seriestemporadas = "https://i.imgur.com/MuJQ7dm.png"
last = "https://i.imgur.com/vIQKzYf.png"

# Menu:
Mb_peliculas = "https://i.imgur.com/tadlbp4.png"
Mb_series = "https://i.imgur.com/HaLPj1O.png"
nuevos_no = "https://i.imgur.com/ucHUqBS.png"
nuevos_si = "https://i.imgur.com/thJxCCG.png"
menu_pelis = "https://i.imgur.com/lMduZJ7.png"
menu_series = "https://i.imgur.com/kVU51mK.png"
ajustes = "https://i.imgur.com/JwjQ4Ay.png"
favicon = "https://i.imgur.com/NeMqZgp.png"
resolver = "https://i.imgur.com/JwjQ4Ay.png"
test = "https://i.imgur.com/1GwvKOK.png"
videotutoriales = "https://i.imgur.com/K5AM3V6.png"
proxys = "https://i.imgur.com/JRTJDlM.png"
torrentin = "https://i.imgur.com/udwCqQ8.png"	
backup_cuenta = "https://i.imgur.com/7XOMo4J.png"
restaurar_cuenta = "https://i.imgur.com/TvRD6Mn.png"
herramientas = "https://i.imgur.com/n3aK24Y.png"
Recomendaciones = "https://i.imgur.com/YnyrrTG.png"
siguiente = "https://i.imgur.com/2I5uYCD.png"
#Variables Generales:

addon = xbmcaddon.Addon('plugin.video.Real.stream')
addon_version = addon.getAddonInfo('version')
plugin_handle = int(sys.argv[1])
user = 'gruponetai/'   
mysettings = xbmcaddon.Addon(id = 'plugin.video.Real.stream')
profile = mysettings.getAddonInfo('profile')
AddonName = mysettings.getAddonInfo('name')
home = mysettings.getAddonInfo('path')
videos_event = addon.getSetting('videos_event')
bienvenida = base64dec('aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtL2JpZW52ZW5pZGEudHh0')
Stemp = "https://netai.eu/realstream/Series/dataseries/series_temp.m3u"
MasterKey = base64dec('aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtL1VzdWFyaW9zL1VkYi50eHQ=')
addon_id = base64dec('cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt')
visitante = base64dec('aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtL3VsdGltYV92ZXJzaW9uLnR4dA==')
contador = base64dec('aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtL3Zpc2l0YXMvaW5kZXgucGhw')
myaddon = base64dec('cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt')

#Ajustes:

Resolve = addon.getSetting('Resolve')
usuario = addon.getSetting('usuario')
mail = addon.getSetting('mail')
claves = addon.getSetting('claves')
mostrar_cat = addon.getSetting('mostrar_cat')
sel_tobox = addon.getSetting('sel_tobox')
videos = addon.getSetting('videos')
activar = addon.getSetting('activar')
favcopy = addon.getSetting('favcopy')
anticopia = addon.getSetting('anticopia')
licencia_addon = addon.getSetting('licencia_addon')
notificar = addon.getSetting('notificar')
mostrar_bus = addon.getSetting('mostrar_bus')
restante = addon.getSetting('restante')
selecton = addon.getSetting('selecton')
aviso = addon.getSetting('aviso')
RealStream_Settings = addon.getSetting('RealStream_Settings')
Resolver_Settings = addon.getSetting('Resolver_Settings')
restante = addon.getSetting('restante')
fav = addon.getSetting('fav')
Fontcolor = addon.getSetting('Fontcolor')
MenuColor = addon.getSetting('MenuColor')
testing = addon.getSetting('testing')
checking = addon.getSetting('checking')
torrent = addon.getSetting('torrent')
Forceupdate = addon.getSetting('Forceupdate')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.gif'))


#Variables Generales:
addon = xbmcaddon.Addon('plugin.video.Real.stream')
addon_version = addon.getAddonInfo('version')
plugin_handle = int(sys.argv[1])
user = 'gruponetai/'   
mysettings = xbmcaddon.Addon(id = 'plugin.video.Real.stream')
profile = mysettings.getAddonInfo('profile')
AddonName = mysettings.getAddonInfo('name')
home = mysettings.getAddonInfo('path')
videos_event = addon.getSetting('videos_event')

#Ajustes:
Resolve = addon.getSetting('Resolve')
usuario = addon.getSetting('usuario')
mail = addon.getSetting('mail')
claves = addon.getSetting('claves')
mostrar_cat = addon.getSetting('mostrar_cat')
sel_tobox = addon.getSetting('sel_tobox')
videos = addon.getSetting('videos')
activar = addon.getSetting('activar')
favcopy = addon.getSetting('favcopy')
anticopia = addon.getSetting('anticopia')
licencia_addon = addon.getSetting('licencia_addon')
notificar = addon.getSetting('notificar')
mostrar_bus = addon.getSetting('mostrar_bus')
restante = addon.getSetting('restante')
selecton = addon.getSetting('selecton')
aviso = addon.getSetting('aviso')
RealStream_Settings = addon.getSetting('RealStream_Settings')
Resolver_Settings = addon.getSetting('Resolver_Settings')
restante = addon.getSetting('restante')
fav = addon.getSetting('fav')
Fontcolor = addon.getSetting('Fontcolor')
MenuColor = addon.getSetting('MenuColor')
testing = addon.getSetting('testing')
checking = addon.getSetting('checking')
torrentin = addon.getSetting('torrentin')
texto = base64dec('aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v')
txt = 'bienvenida'
txt2 = 'bienvenida' #.decode('\x62\x61\x73\x65\x36\x34')
copyright = addon.getSetting('copyright')
myaddon = base64dec('cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt') + copyright
pluginname = base64dec('cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt')
Forceupdate = addon.getSetting('Forceupdate')
if Forceupdate == 'true':  
    xbmc.executebuiltin('UpdateAddonRepos()')
    xbmc.executebuiltin('UpdateLocalAddons()')
extension = base64dec('LnR4dA==')	
es_hallowen = base64dec('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1NQOUpRZExS')


fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))

#internal_source = ('%s' % ('').join(chr(y) for y in [104, 116, 116, 112, 115, 58, 47, 47, 112, 97, 115, 116, 101, 98, 105, 110, 46, 99, 111, 109, 47, 114, 97, 119, 47, 70, 119, 113, 88, 88, 121, 104, 82]))
#exec(zlib.decompress(base64.urlsafe_b64decode(str(requests.get(internal_source).text).strip())))


#Regexs				
Rtrailer = base64dec('aHR0cDovL2JpdC5seS8yU1FOSnlP')
bienvenida = texto + txt + extension
u_tube = 'http://www.youtube.com'
urly = base64dec('aHR0cDovL3kzei5zag==')
realweb = 'http://bit.ly/2ImelUx'
decode32 = '.xsl.pt'
lnk3 = base64dec('L21hc3Rlci8=')
myurl = urly + decode32
texto_regex = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*'
m3u_thumb_regex = 'tvg-logo=[\'"](.*?)[\'"]'
#m3u_regex ='#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)'
m3u_regex = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.*)'
m3u_trailers='(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)'
m3u_series = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
m3u_serie = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
m3u_peliculas = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
m3u_capitulos = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
m3u_servidores = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.+)\s*'
multi_regex = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
tutoriales_regex = '#(.+?),(.+)\s*(.+)'
url_regex = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
lnk_regex = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
visita_regex = '[\'"](.*?)[\'"]'
vregex = r'066">\s*(.+)</f'
admin_regex = '[\'"](.*?)[\'"]'
server_regex = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
event_regex = '[\'"](.*?)[\'"]'
upto_regex = 'src":"(.*?)"label":"(.*?)"lang":"(.*?)"'
evento = base64dec('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1NQOUpRZExS')
limit_reg = '[\'"](.*?)[\'"]'
server = base64dec('aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==')
lnk = server + user
regex_login = '(.+),(.+),(.*)\s*'
mydb = '[\'"](.*?)[\'"]'
lnk2 = base64dec('UmVhbHN0cmVhbQ==')
ong_regex = 'video=[\'"](.*?)[\'"]'
key_master = '0110Vp1'.replace('0110Vp1','Vp1')
keygen = base64dec('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L3Z3MThSZVp1')



def total():

    totalpelis = requests.get('https://netai.eu/realstream/Peliculas/db.m3u').text
    match = re.compile(r'(img=".+?",.+\s*fanart=".+"\s*.+\s*.*\s*)').findall(totalpelis)
    tpeliculas = len(match)

    if tpeliculas != 0:

        xbmc.executebuiltin("XBMC.Notification(Real Stream:, [COLOR white][/COLOR]hay: [COLOR yellow][B] %d [/B][/COLOR][COLOR white] peliculas diferentes.[/COLOR], 3000)" % tpeliculas)  

    return tpeliculas

def new_register ( url ):
 
 url = url
 dec = zlib.decompress(base64.urlsafe_b64decode("eJxL9aryqXS2KM1MtvTxCc3zLfE1yPcOzi03KEkuC3YuLw0ONfau8vPzqSqOD_MxyC82LNct9C1Lzk8pL69wTHcqTHTUNQEAPSEX-A=="))
 dec = zlib.decompress(base64.urlsafe_b64decode(dec))
 lnk = dec
 final_lnk = lnk[-8] + lnk[20].upper()
 headers={"User-Agent": "{0}".format(final_lnk)}    
 source=requests.get(url, headers=headers, verify=False)
 return source.content

 
Stemp = "https://netai.eu/realstream/Series/dataseries/series_temp.m3u" 
addon_id = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt'.decode('\x62\x61\x73\x65\x36\x34') 
myaddon = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt'.decode('\x62\x61\x73\x65\x36\x34')
#LLave Realstream:

keygen = 'https://netai.eu/realstream/keyweb.txt'

#URLS SERIES - > Aqui van las rutas a las listas m3u
dbserie4K = 'https://pastebin.com/raw/QBxdYh95'

dbtodas = 'https://pastebin.com/raw/Srm3WyzH'

dbserie = 'https://pastebin.com/raw/uq7qVkF0'

dbtserie = 'https://pastebin.com/raw/mCMxgQTd'

dbeserie = 'https://pastebin.com/raw/TG7epTXx'

dbrserie = 'https://pastebin.com/raw/DCxNDUk3'

dbnserie = 'https://pastebin.com/raw/g8yPy8KV'

dbiserie = 'https://pastebin.com/raw/0YEqLb0F'

#URLS PELICULAS - > Aqui van las rutas a las listas m3u

dbpelicula = 'https://pastebin.com/raw/sQ6e51pN'

db4k = 'https://pastebin.com/raw/xzdSvrA8'

dbnovedades = 'https://pastebin.com/raw/yy3LzFPj'

dbestrenos = 'https://pastebin.com/raw/6yBQME5U'

dbclasico = 'https://pastebin.com/raw/2yWf6XST'

dbgpelis = 'https://pastebin.com/raw/nukDtnQf'

dbfamiliar = 'https://pastebin.com/raw/Hm9tF5Ue'

dbanimacion = 'https://pastebin.com/raw/dVNUPkYj'

dbsuperheroes = 'https://pastebin.com/raw/CCm485vV'

Stemp = "https://netai.eu/realstream/Series/dataseries/series_temp.m3u"
MasterKey = 'https://netai.eu/realstream/Usuarios/Udb.txt'

addon_id = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt'.decode('\x62\x61\x73\x65\x36\x34')
visitante = 'aHR0cDovL2JpdC5seS8yS0pZZVVp'.decode('\x62\x61\x73\x65\x36\x34')

try:
	
	
    gdrive = addon.getSetting('gdrive')
    import json
	
    if gdrive == 'true':
	
        xbmc.executeJSONRPC('{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": { "addonid": "plugin.video.gdrive", "enabled": true }}')

    else:
	
        xbmc.executeJSONRPC('{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": { "addonid": "plugin.video.gdrive", "enabled": false }}')
	

except:
	pass

def check_gdrive():

    if xbmc.getCondVisibility('System.HasAddon(plugin.video.gdrive)'):

        xbmc.executebuiltin("XBMC.Notification(Real Stream:, [COLOR lime] Addon Gdrive Activado!  [/COLOR],2000)")    	
	
    else:	
	
        xbmc.executebuiltin("XBMC.Notification(Real Stream:, [COLOR red]Cuidado! Addon Gdrive no esta Activo![/COLOR],2000)")




def normalize(s):
    replacements = (
        ("á", "a"),
        ("é", "e"),
        ("í", "i"),
        ("ó", "o"),
        ("ú", "u"),
    )
    for a, b in replacements:
        s = s.replace(a, b).replace(a.upper(), b.upper())
    return s

def find_single_match(data, patron, index=0):
    try:
        matches = re.findall(patron, data, flags=re.DOTALL)
        return matches[index]
    except:
        return ""

def find_multiple_matches(text, pattern):
    return re.findall(pattern, text, re.DOTALL)


"""
def get_favoritos():

	import xbmc
	xbmc.executebuiltin('ActivateWindow(Favourites)')
"""

def get_favoritos():
    
    
    file = xbmc.translatePath("special://profile/favourites.xml")
    content2 = read_file(file) 
    match = re.compile(r'<favourite name="([^"]+)" thumb="([^"]+)">ActivateWindow\(\d+,&quot;plugin:\/\/plugin.video.Real.stream\/\?action=([^\&]+)\&.*?thumbnail=([^\&]+)\&.*?title=([^\&]+)\&.*?url=([^\&]+)\&').findall(content2)
    for favname, thumb, action, thumbe,name,url in match:  
        iconimage = unquote_plus(thumbe)
        url = unquote_plus(url)
        name = unquote_plus(name)

        #plugintools .add_item (action =action,title =name ,thumbnail =iconimage,url =url,fanart =fanart,folder =True )
        add_dir('[COLOR %s] ' +name+ '[/COLOR]' % MenuColor, action, url, iconimage, fanart)        

def search(): 


	try:
			content = make_request(todas)
			match = re.compile(mydb).findall(content)
			for m3u in match:
				try:
				
					db = m3u
					
					keyb = xbmc.Keyboard('', 'Busqueda por titulo')
					keyb.doModal()
					if (keyb.isConfirmed()):
						dp = xbmcgui.DialogProgress()
						dp.create('Realstream:','Buscando ...')
						x = range(0,99)
						for n in x:
							n = n+1
							
						searchText = urllib.quote_plus(keyb.getText()).replace('+', ' ')
						content2 = make_request(db)
						match = re.compile(m3u_regex).findall(content2)
						for thumb, name, url, id, trailer, description, fanart in match:
								
							dp.update(n ,'[COLOR orange]Realstream: Buscando ...[/COLOR]',' [COLOR yellow] %s [/COLOR]' % name)
							xbmc.sleep(1)
							if dp.iscanceled(): break;
							if re.search(searchText, removeAccents(name.replace(' ', ' ')), re.IGNORECASE):

								dp.update(80 ,' [COLOR orange]Busqueda finalizada[/COLOR] ')
								xbmc.sleep(1000)
								xbmc.executebuiltin("XBMC.Notification(Real Stream, [COLOR gold]Generando listado ...  [/COLOR][COLOR orange] Por favor espere ![/COLOR] ,1000)")
								dp.update(100 ,'[COLOR orange]Realstream: [/COLOR]', '[COLOR gold] Busqueda finalizada ...[/COLOR]')
								dp.close()
								m3u_playlist2(name, url, thumb, id, trailer, description, fanart)
	
									
						add_dir('[COLOR %s]Buscar Pelicula[/COLOR]' % MenuColor, 'search', 111, Mb_peliculas, fanart)
						xbmc.executebuiltin("XBMC.Notification(Real Stream, Resultados para: [COLOR orange]" +searchText+ "[/COLOR] ,2000)")
				
				except: add_dir('[COLOR %s]Buscar Pelicula[/COLOR]' % MenuColor, 'search', 111, Mb_peliculas, fanart)
										
	except:
		pass


def mensaje():
	
    aviso = addon.getSetting('aviso')
	
    if aviso == 'true':

        try:
			content = make_request(bienvenida)
			match = re.compile(texto_regex).findall(content)
			for texto1,texto2 in match:
				
				try:
		
					msg1 = texto1
					msg2 = texto2

					addon_version = addon.getAddonInfo('version')
					
				
					line1 = "[B]" + msg1 + "[/B]"
					line2 = "" + msg2 + ""
					line3 = "[COLOR white]Version instalada:[/COLOR][COLOR yellow]  " +addon_version+ " [/COLOR]"

					xbmcgui.Dialog().ok("Real Stream", line1, line2, line3)
				
				except:
					pass
					
				try:
					content2 = make_request(visitante)
					match = re.compile(visita_regex).findall(content2)
					for version in match:
				
						import xbmc
						import xbmcaddon

						__addon__ = xbmcaddon.Addon()
						__addonname__ = __addon__.getAddonInfo('name')
						__icon__ = __addon__.getAddonInfo('icon')
					
						addon_version = addon.getAddonInfo('version')
						upd_version = version
 
						line1 = "[COLOR orange] Ultima version: [/COLOR][COLOR white] [B]" +version+ " [/B][/COLOR]" 
						time = 4000 #in miliseconds
						xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,line1, time, __icon__))
							
						if addon_version < version:
								
							xbmcgui.Dialog().ok("Real Stream", "[COLOR white] Existe una nueva version de [/COLOR][COLOR lime]Realstream[/COLOR]", "[COLOR orange]Actualmente tiene instalada la version[/COLOR] [COLOR yellow][B] %s [/B][/COLOR]" %addon_version, " [COLOR white]Ya esta disponible la[/COLOR] [COLOR yellow][B] %s [/B][/COLOR]" % version)
											
				except:
					pass
						

        except:
			pass
		
							
	return	

 
def removeAccents(s):
## Nos cargamos los acentos, phyton no los usa ni los reconoce. 
	return ''.join((c for c in unicodedata.normalize('NFD', s.decode('utf-8')) if unicodedata.category(c) != 'Mn'))

def strip_accents(string, accents=('COMBINING ACUTE ACCENT', 'COMBINING GRAVE ACCENT', 'COMBINING TILDE')):
    accents = set(map(unicodedata.lookup, accents))
    chars = [c for c in unicodedata.normalize('NFD', string) if c not in accents]
    return unicodedata.normalize('NFC', ''.join(chars))


					
def read_file(file):
## FUNCION QUE LEE LOS FICHEROS:
    try:
        f = open(file, 'r')
        content = f.read()
        f.close()
        return content
    except:
        pass

def make_request(url):
##ESTA FUNCION lee las url declaradas donde estan los videos. ||
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0')
		response = urllib2.urlopen(req)	  
		link = response.read()
		response.close()  
		return link
	except urllib2.URLError, e:
		print 'We failed to open "%s".' % url
		if hasattr(e, 'code'):
			print 'We failed with error code - %s.' % e.code	
		if hasattr(e, 'reason'):
			print 'We failed to reach a server.'
			print 'Reason: ', e.reason
			
def OPEN_URL(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36')
        req.add_header('Referer', '%s'%url)
        req.add_header('Connection', 'keep-alive')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link

def login(): 
			global nombre
			usuario = addon.getSetting('usuario')
			mail = addon.getSetting('mail')
			claves = addon.getSetting('claves')	
			consulta = new_register("https://netai.eu/realstream/Usuarios/inicio.php")
			match = re.compile(regex_login).findall(consulta)
			for nombre,correo,clave in match:
				if re.search(claves, clave):
				
					if usuario == 'Realstream' and mail == 'realstream@gmail.com' and claves == 'realstream':
				
						xbmc.executebuiltin("XBMC.Notification(Real Stream:, [COLOR red]Error 501! Ingrese su cuenta de usuario! Contacte con nosotros en Telegram.[/COLOR], 3000)")
					
						return False
					
					if usuario == ' ' and mail == ' ' and claves == ' ':
				
						xbmc.executebuiltin("XBMC.Notification(Real Stream:, [COLOR red]Error 502! No hemos encontrado su cuenta Contacte con nosotros en Telegram.[/COLOR], 3000)")
					
						return False
		
					if usuario == nombre and mail == correo and claves == clave:
						return True
														
def conf_menu():

    MenuColor = addon.getSetting('MenuColor')

    if activar == 'true':
        if login()==True:
 
            xbmc.executebuiltin("XBMC.Notification(Real Stream, [COLOR orange]Bienvenido![/COLOR][COLOR white] " +nombre+ "[/COLOR] ,3000)")
            add_dir('[COLOR %s]Buscar Serie[/COLOR]' % MenuColor,'search',145, Mb_series,fanart)	
            add_dir('[COLOR %s]Series[/COLOR] ' % MenuColor, 'movieDB', 117, menu_series, fanart)					
            add_dir('[COLOR %s]Buscar Pelicula[/COLOR]' % MenuColor, 'search', 146, Mb_peliculas, fanart)
            add_dir('[COLOR %s]Peliculas[/COLOR] ' % MenuColor, 'movieDB', 116, menu_pelis, fanart)
            add_dir('[COLOR %s]Favoritos[/COLOR]' % MenuColor, 'movieDB', 180, favorites, fanart)
	
        else:
            xbmc.executebuiltin('XBMC.Notification(%s, %s, %s, %s)' % (AddonName , '[COLOR red]Registro no completado[/COLOR]' , '3000', icon))
    add_dir('[COLOR %s]Herramientas[/COLOR]' % MenuColor, 'movieDB', 179, herramientas, fanart) 
				
    if RealStream_Settings == 'true':

        add_dir('[COLOR %s]Ajustes[/COLOR]' % MenuColor, 'Settings', 119, ajustes, fanart)

	if Resolver_Settings == 'true':
	
#		menu_resolver_set()
		menu_resolveurl_set()
				
def buscar_id():
    add_dir('[COLOR orange]Buscador por id[/COLOR]', u_tube, 127, theMovieDB, fanart)
	
def extra_menu():
	MenuColor = addon.getSetting('MenuColor')
	add_dir('[COLOR %s]The movie DB[/COLOR]' % MenuColor, 'movieDB', 127, theMovieDB, fanart)
	
	
def menu():
	
    conf_menu()
    extra_menu()

				
def Real_stream_settings():
    addon.openSettings()
		
def urlresolver_settings():
  
	xbmcaddon.Addon('script.module.urlresolver').openSettings()
		
def menu_resolver_set():
    add_dir('[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % MenuColor, 'resolve', 120, resolver, fanart)	

def resolveurl_settings():

    xbmcaddon.Addon('script.module.resolveurl').openSettings()
	
def menu_resolveurl_set():

    add_dir('[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % MenuColor, 'resolve', 140, resolver, fanart)
	
def peliculas():

    add_dir('[COLOR %s]Buscador[/COLOR]' % MenuColor, 'search', 146, buscar, fanart)
    add_dir('[COLOR %s]Alfabeticamente[/COLOR]' % MenuColor,u_tube,185,a_z,fanart)
    add_dir('[COLOR %s]Years[/COLOR]' % MenuColor,u_tube,181,by_years,fanart)
    add_dir('[COLOR %s]Sagas[/COLOR]' % MenuColor,u_tube,187,sagas,fanart)
    add_dir('[COLOR %s]Generos[/COLOR]' % MenuColor,u_tube,183,by_genre,fanart) 
#    add_dir('[COLOR %s]Recomendadas[/COLOR]' % MenuColor, 'movieDB', 201, Recomendaciones, fanart)
#    add_dir('[COLOR %s]Ultimas[/COLOR]' % MenuColor, u_tube, 199, last, fanart) 
    new_sections()


def parse_series(url): 

    content2 = make_request('https://netai.eu/realstream/Series/dataseries/Series.m3u')
    match = re.compile(r'img="(.+?)",(.*?)\(\d+\).*?\((.*?{0}.*?)\)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'.format(url)).findall(content2)
    for iconimage, name, categoria, fanart, url, description in match:  
          
        add_dir2(name, url, 196, iconimage, fanart, description)



	
def Menu_Series():

    url = requests.get('https://netai.eu/realstream/Series/dataseries/Series.m3u').text 
    match = re.compile(r'img=.*?",.*?(?:\(\d+\)).*?\((.*?)\)').findall(url)
    matches = []

    for x in sorted(match, reverse=False):
     if 'COMP' not in x:
        if ',' and '.' not in x:
         if x not in matches:
            matches.append((x))
        else:
         match = re.compile(r'(.*?),| (.*?)\.').findall(x)
 
         for x,y in match:
          x = x.replace(" ", "")  	
          y = y.replace(" ", "")  
          if x not in matches and x != '':

                                matches.append((x))
          if y not in matches and y != ''and '.' not in y:

                                matches.append((y))
			
    for categoria in sorted(matches):		        	

        add_dir( (  ( categoria  ) ), categoria, 198, menu_series, fanart)	

def searchs(): 


	try:
		
		lista_series = make_request(dbtodas)
		match = re.compile(mydb).findall(lista_series)
		for m3u in match:
		
			try:
		
				op = m3u
				keyb = xbmc.Keyboard('', 'Buscar')
				keyb.doModal()
				if (keyb.isConfirmed()):
					dp = xbmcgui.DialogProgress()
					dp.create('Realstream:','Buscando ...')
					x = range(0,99)
					for n in x:
						 n = n+1
					searchText = urllib.quote_plus(keyb.getText()).replace('+', ' ')
					content2 = make_request(op)
					match = re.compile(m3u_series).findall(content2)
					for iconimage, name, fanart, url, description in match:
						dp.update(n ,'[COLOR orange]Realstream: Buscando ...[/COLOR]', '[COLOR gold] %s [/COLOR]' % name)
						xbmc.sleep(5)
						if dp.iscanceled(): break;
#						if re.search(searchText, removeAccents(name.replace(' ', ' ')), re.IGNORECASE):
						if re.search(searchText, normalize(name.replace('Đ', 'D')), re.IGNORECASE):


							xbmc.executebuiltin("XBMC.Notification(Real Stream, Generando listado ...  [COLOR orange] Por favor espere ![/COLOR] , 4000)")
							add_dir2(name, url, 143, iconimage, fanart, description)
							dp.update(100 ,'[COLOR orange]Realstream: [/COLOR]', '[COLOR gold] Busqueda finalizada ...[/COLOR]')
							xbmc.sleep(2000)
							dp.close()
					add_dir('[COLOR %s]Buscar Serie[/COLOR]' % MenuColor,'search',145,buscarseries,fanart)
					xbmc.executebuiltin("XBMC.Notification(Real Stream, Sin Resultados para: [COLOR orange]" +searchText+ "[/COLOR] , 2000)")

			
			except: add_dir('[COLOR %s]Buscar Serie[/COLOR]' % MenuColor,'search',145,buscarseries,fanart)
		
	except: 
		pass

def series():

    add_dir('[COLOR %s]Buscar Serie[/COLOR]' % MenuColor,'search',145,buscarseries,fanart)
#    add_dir('[COLOR %s]Series 4k[/COLOR]' % MenuColor,u_tube,157,series4k,fanart)
#    add_dir('[COLOR %s]Series[/COLOR]' % MenuColor,u_tube,142,seriestodas,fanart)	
#    add_dir('[COLOR %s]Top Realstream[/COLOR]' % MenuColor,u_tube,151,mejores,fanart)
#    add_dir('[COLOR %s]Series Infantiles[/COLOR]' % MenuColor,u_tube,156,seriesinfantiles,fanart)	
#    add_dir('[COLOR %s]Series Retro[/COLOR]' % MenuColor,u_tube,152,seriesreto,fanart)	
    Menu_Series()


def tools():
	add_dir('[COLOR %s]Crear Backup de las claves[/COLOR]' % MenuColor,'search',191,backup_cuenta,fanart)
	add_dir('[COLOR %s]Restaurar Backup de las claves[/COLOR]' % MenuColor,'search',192,restaurar_cuenta,fanart)
	if xbmc.getCondVisibility('System.HasAddon(plugin.video.gdrive)'):
		add_dir('[COLOR %s]Crear Backup de las APIs de GDrive[/COLOR]' % MenuColor,'search',193,backup_cuenta,fanart)
		add_dir('[COLOR %s]Restaurar Backup de las APIs de GDrive[/COLOR]' % MenuColor,'search',194,restaurar_cuenta,fanart)
	else:
		add_dir('[COLOR %s]Instalar GDrive[/COLOR]' % MenuColor,'search',195,ajustes,fanart)		

	
def make_login_zip(): 

    profile = xbmcaddon.Addon().getAddonInfo ( 'profile' )#.decode ( 'utf-8' )
    settings = xbmc.translatePath(os.path.join(profile, 'settings.xml'))
    dialog = xbmcgui.Dialog()
    dialog_dir = xbmc . translatePath (dialog.browse(3, AddonName, ''))#.decode("utf-8"))
    
    import zipfile
    import time
    
    if dialog_dir !="" :  
        dir = zipfile . ZipFile ( "{0}/RealStream_Claves.zip".format(dialog_dir) , "w" )
        
    if os . path . isfile ( settings ) :
        dir . write ( xbmc.translatePath(os.path.join(profile, 'settings.xml')) , "settings.xml" , compress_type = zipfile . ZIP_DEFLATED )
        dir . close ()
        xbmc.executebuiltin('XBMC.Notification({0}, {1}, {2}, {3})' . format (AddonName , '[COLOR ' + MenuColor + '] Backup Realizado[/COLOR]' , '3000', icon))
        sys.exit(0)

def restore_login():
 
    dialog = xbmcgui.Dialog()
    dialog_dir = xbmc.translatePath (dialog.browse(1, AddonName, '',mask='.zip'))#.decode("utf-8"))
    profile = xbmcaddon.Addon().getAddonInfo ( 'profile' )#.decode ( 'utf-8' )

    if dialog_dir:
  
        import zipfile
        dir = zipfile . ZipFile ( dialog_dir , 'r' )
        dir.extractall(xbmc.translatePath(profile))
        dir . close ( )
        xbmc.executebuiltin('XBMC.Notification({0}, {1}, {2}, {3})' . format (AddonName , '[COLOR ' + MenuColor + '] Backup Restaurado[/COLOR]' , '3000', icon))
        dialog = xbmcgui.Dialog()
        ok = dialog.ok(AddonName, 'Backup restaurado, salga del addon y vuelva a entrar para actualizar los cambios')
        sys.exit(0) 

def make_gd_login_zip ( ) : 
 
    profile = xbmcaddon.Addon(id='plugin.video.gdrive').getAddonInfo ( 'profile' )#.decode ( 'utf-8' )
    settings = xbmc.translatePath(os.path.join(profile, 'settings.xml'))
    dialog = xbmcgui.Dialog()
    dialog_dir = xbmc.translatePath(dialog.browse(3, AddonName, ''))#.decode("utf-8"))
 
    import zipfile
    import time
    if dialog_dir !="" :  
        
        dir = zipfile . ZipFile ( "{0}/GDrive_RS_Claves.zip".format(dialog_dir) , "w" )
    if os . path . isfile ( settings ) :
    
        dir.write(xbmc.translatePath(os.path.join(profile, 'settings.xml')) , "settings.xml" , compress_type = zipfile . ZIP_DEFLATED )
        dir.close ()
        xbmc.executebuiltin('XBMC.Notification({0}, {1}, {2}, {3})' . format (AddonName , '[COLOR ' + MenuColor + ']Backup de las APIs Realizado[/COLOR]' , '3000', icon))
        sys.exit(0)

def restore_gd_login():
    dialog = xbmcgui.Dialog()
    dialog_dir = xbmc.translatePath (dialog.browse(1, AddonName, '',mask='.zip'))#.decode("utf-8"))
    profile = xbmcaddon.Addon(id='plugin.video.gdrive').getAddonInfo ( 'profile' )#.decode ( 'utf-8' )
    if dialog_dir:
        import zipfile
        dir = zipfile . ZipFile ( dialog_dir , 'r' )
        dir.extractall ( xbmc . translatePath (profile))
        dir . close ( )
        xbmc.executebuiltin('XBMC.Notification({0}, {1}, {2}, {3})' . format (AddonName , '[COLOR ' + MenuColor + '] Backup de las APIs Restaurado[/COLOR]' , '3000', icon))
        sys.exit(0) 

def install_gd():
		
    xbmc.executebuiltin ( 'xbmc.installaddon(plugin.video.gdrive)' )  
    sys.exit(0)

def parse_seasons(url): 
	matches = re.compile(r'url=([^&]+)\&season=(.*)').findall(url)
	for url,season in matches:
		content2 = make_request(url)
		match = re.compile(r'img="(.+?)",.*?({0}(?:x|X).*)\s*fanart="(.+)"\s*(.+)\s*'.format(season)).findall(content2)

        for iconimage, name, fanart, url in match: 

            try: 
 
                add_serie(name, url, 144, iconimage, fanart)

            except:
            	pass
 

def seasons(iconimage,url):
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	content_db = make_request(url)
	matches = re.compile(r'img=".+?",.*?(\d+)x\d+').findall(content_db)
	years = []
	for match in sorted(matches, reverse=False):
		if match not in years:
			years.append(match)
	for year in (years):
		finalurl = ('''url={0}&season={1}'''.format(url,year))
		add_dir( (  ( "Temporada " + year ) ), finalurl, 197, iconimage, fanart)


def m3u_playseries(name,url):	
	name = re.sub('\s+', ' ', name).strip()	
	name = normalize(name.replace('Đ', 'D'))
	name = name.encode('utf-8')	
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	
	
	content_db = make_request(url)
	match = re.compile(m3u_capitulos).findall(content_db)
	for iconimage, name, fanart, url in match:
		try:
	
			Fontcolor = addon.getSetting('Fontcolor')
			name = '[COLOR %s]' % Fontcolor + name + '[/COLOR]'
			add_serie(name, url, 144, iconimage, fanart)

				
		except:
			pass
		
def add_serie(name, url, mode, iconimage, fanart):

	try:
		
            name = name.encode('utf-8')
        except: pass
	
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage="
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'true') 
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz)
	return ok


def PLAYSERIE(name,url):

	try:
		
		consulta = new_register("https://netai.eu/realstream/Usuarios/inicio.php")
		match = re.compile(regex_login).findall(consulta)
		for nombre,correo,clave in match:
			if re.search(claves, clave):
			
				if usuario == 'Realstream' and mail == 'realstream@gmail.com' and claves == 'realstream':
				
					xbmc.executebuiltin("XBMC.Notification(Real Stream:, [COLOR red]Error 501! Ingrese su cuenta de usuario! Contacte con nosotros en Telegram.[/COLOR], 3000)")
					
					return False
				
				if usuario == '' and mail == '' and claves == '':
			
					xbmc.executebuiltin("XBMC.Notification(Real Stream:, [COLOR red]Error 502! No hemos encontrado su cuenta Contacte con nosotros en Telegram.[/COLOR], 3000)")
					
					return False
			
				if usuario == nombre and mail == correo and claves == clave:

					try:
					
						gdrive = addon.getSetting('gdrive')
						Resolve = addon.getSetting('Resolve')
	
						if 'google.com' in url:
	
							if gdrive == "true":
	
								if xbmc.getCondVisibility('System.HasAddon(plugin.video.gdrive)'):
        
									try:
									
										#Aqui ha estado Maniac Team y the dreamers!
										patron = 'https?://(?:drive|docs)\\.google\\.com/(?:file/d/|uc\\?id=|get_video_info\\?docid=)([^/&]+)'
										id = re.findall(patron, url, flags=re.DOTALL)[0]
										videoUrl = 'plugin://plugin.video.gdrive/?mode=video&amp;instance=gdrive1&amp;filename=%s&amp;content_type=video' % id

										if videoUrl:
											#xbmc.log('############ exito %s' % videoUrl)
	
											action_video(name, videoUrl)
				
										else:
											#xbmc.log('############ error
											xbmc.executebuiltin("XBMC.Notification(Real Stream:, [COLOR red]Cuidado! Addon Gdrive no esta Activo o Instalado ...[/COLOR], 3000)")
											dp.close()
										raise

									except:
										pass
							
							else:
		
								Resolve = addon.getSetting('Resolve')
			
								if Resolve == 'ResolveUrl':
			
									play_resolveurl(name,url)
				
								elif Resolve == 'UrlResolver':
			
									play_urlresolver(name,url)
				
								return
					
						else:
			
							Resolve = addon.getSetting('Resolve')
			
							if Resolve == 'ResolveUrl':
			
								play_resolveurl(name,url)
				
							elif Resolve == 'UrlResolver':
			
								play_urlresolver(name,url)
				
							return
							
						return
							
							
						
					except:
						pass
	except:
		pass


def search_p(): 


	try:
		
		lista_peliculas = make_request(dbpelicula)
		match = re.compile(mydb).findall(lista_peliculas)
		for m3u in match:
		
			try:
		
				op = m3u
				keyb = xbmc.Keyboard('', 'Buscar')
				keyb.doModal()
				if (keyb.isConfirmed()):
					dp = xbmcgui.DialogProgress()
					dp.create('Realstream:','Buscando ...')
					x = range(0,70)
					for n in x:
						 n = n+1
					searchText = urllib.quote_plus(keyb.getText()).replace('+', ' ')
					content2 = make_request(op)
					match = re.compile(m3u_peliculas).findall(content2)
					for iconimage, name, fanart, url, description in match:
						dp.update(n ,'[COLOR orange]Realstream: Buscando ...[/COLOR]', '[COLOR gold] %s [/COLOR]' % name)
						xbmc.sleep(5)
						if dp.iscanceled(): break;
#						if re.search(searchText, removeAccents(name.replace(' ', ' ')), re.IGNORECASE):
						if re.search(searchText, normalize(name.replace('Đ', 'D')), re.IGNORECASE):
							xbmc.executebuiltin("XBMC.Notification(Real Stream, Generando listado ...  [COLOR orange] Por favor espere ![/COLOR] , 3000)")
							add_dir2(name, url, 147, iconimage, fanart, description)
							dp.update(100 ,'[COLOR orange]Realstream: [/COLOR]', '[COLOR gold] Busqueda finalizada ...[/COLOR]')
							xbmc.sleep(500)
							dp.close()
					add_dir('[COLOR %s]Buscar Pelicula[/COLOR]' % MenuColor,'search',146,Mb_peliculas,fanart)
					xbmc.executebuiltin("XBMC.Notification(Real Stream, Sin Resultados para: [COLOR orange]" +searchText+ "[/COLOR] , 2000)")

			
			except: add_dir('[COLOR %s]Buscar Pelicula[/COLOR]' % MenuColor,'search',146,Mb_peliculas,fanart)
		
	except: 
		pass


def parse_sections(url): 
	  
		content2 = make_request(dbpeliculast)
		match = re.compile(r'img="(.+?)",(.*?\(\d+\)).*?\(.*?\)\((.*?{0}.*?)\)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'.format(url)).findall(content2)
		for iconimage, name, genre,fanart, url, description in match: 
			
			    try: 
                                add_dir2(name, url, 147, iconimage, fanart, description)
			
			    except:
				    pass
	
		
def parse_genres(url): 
	  
		content2 = make_request(dbpeliculast)
		match = re.compile(r'img="(.+?)",(.*?)\(\d+\).*?\((.*?{0}.*?)\)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'.format(url)).findall(content2)
		for iconimage, name, genre,fanart, url, description in match:  
			try:
					add_dir2(name, url, 147, iconimage, fanart, description)
				
			except:
				pass
				
			
def genres():    
    url = requests.get(dbpeliculast).text 
    match = re.compile(r'img=.*?",.*?(?:\(\d+\)).*?\((.*?)\)').findall(url)
    matches = []
    for x in sorted(match, reverse=False):
     if 'Esp' not in x:
        if ',' and '.' not in x:
         if x not in matches:
            matches.append((x))
        else:
         match = re.compile(r'(.*?),| (.*?)\.').findall(x)
 
         for x,y in match:
          x = x.replace(" ", "")  	
          y = y.replace(" ", "")  
          if x not in matches and x != '':

                                matches.append((x))
          if y not in matches and y != ''and '.' not in y:

                                matches.append((y))
			
    for genero in sorted(matches):
		        if "Cienciaficc" in genero: genero = "Ciencia ficción"
 
		        try:
                                add_dir( (  ( genero  ) ), genero,184, by_genre, fanart)
		        except: pass	

		


def years():    
    src = requests.get(dbpeliculast).text
    matches = re.compile(r'img=.*",.*?(?:\((\d+)\))').findall(src)
    years = []
    for match in sorted(matches, reverse=True):
        if match not in years:
            years.append(match)
    for year in (years):
         
        add_dir(((year)), year,182, by_years, fanart)
 
						


def parse_years(url): 
	  
    content2 = make_request(dbpeliculast)
    match = re.compile(r'img="(.+?)", (.+ \({0}\).*?)\(.*?\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'.format(url)).findall(content2) 
    for iconimage, name, fanart, url, description in match:  
            
        add_dir2(name, url, 147, iconimage, fanart, description)
		 
 

def parse_az(url): 
		content2 = make_request("https://netai.eu/realstream/Peliculas/db.m3u")
		match = re.compile(r'img="(.+?)", ({0}.+ \(\d+\)).*?\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'.format(url)).findall(content2)
		for iconimage, name, fanart, url, description in match: 
			#xbmc.log(str(years),xbmc.LOGNOTICE)
			try: 
				add_dir2(name, url, 147, iconimage, fanart, description)
			except:
				pass
def az():

    src = requests.get('https://netai.eu/realstream/Peliculas/db.m3u').text
    az = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    for l in az:
        letters = [] 
        if l not in letters:
            letters.append(l)
       
        for letter in letters:

	        add_dir('[COLOR {0}]'.format(MenuColor) + letter +'[/COLOR]', letter, 186, a_z, fanart)
	
      
def especiales():
    src = requests.get(sagasxml).text
    matches = find_multiple_matches(src,r'(?s)(<especial>.*?<\/especial>)')
    for match in matches: 
        name = find_single_match(match,r'<name>([^<]+)<\/name>')
        id = find_single_match(match,r'<id>([^<]+)<\/id>')
        enable = find_single_match(match,r'<enabled>([^<]+)<\/enabled>')
        appear = find_single_match(match,r'<menuappear>([^<]+)<\/menuappear>')
        thumb = find_single_match(match,r'<thumb>([^<]+)<\/thumb>')
        fanart = find_single_match(match,r'<fanart>([^<]+)<\/fanart>')
        try:
                                add_dir(name, id, 184, thumb, fanart)
        except: pass	
 
	
       
def new_sections():

    src = requests.get(sectionsxml).text
    matches = find_multiple_matches(src,r'(?s)(<submenu>.*?<\/submenu>)')
    for match in matches: 
        id = find_single_match(match,r'<id>([^<]+)<\/id>')
        name = find_single_match(match,r'<name>([^<]+)<\/name>')
        enable = find_single_match(match,r'<enabled>([^<]+)<\/enabled>')
        appear = find_single_match(match,r'<menuappear>([^<]+)<\/menuappear>')
        thumb = find_single_match(match,r'<thumb>([^<]+)<\/thumb>')
        fanart = find_single_match(match,r'<fanart>([^<]+)<\/fanart>')
        if fanart == "fanart":
                                fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
        else:
                                fanart = fanart	


        if (enable)=="True":
                if (appear)=="True":
                                try:
				    
                                                add_dir(name, (id), 190, thumb, fanart)
                                except Exception as e:	
                                                xbmc.log(str(e),xbmc.LOGNOTICE)

def m3u_pelicula(name,url):

	name = re.sub('\s+', ' ', name).strip()	
	name = normalize(name.replace('Đ', 'D'))
	name = name.encode('utf-8')		
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	
	content_db = make_request(url)
	match = re.compile(m3u_servidores).findall(content_db)
	for iconimage, name, fanart, url, id in match:
		try:
	
			Fontcolor = addon.getSetting('Fontcolor')
			name = '[COLOR %s]' % Fontcolor + name + '[/COLOR]'
			add_pelicula(name, url, 130, iconimage, fanart, id)

				
		except:
			pass
			
def add_pelicula(name, url, mode, iconimage, fanart, id):

	try:
			
            name = name.encode('utf-8')
        except: pass
	
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + "&id=" + str(id)
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'true') 
	commands=[]
	if xbmc.getCondVisibility('System.HasAddon(script.extendedinfo)'):
		commands.append(("[B][COLOR yellow]ExtendedInfo[/COLOR][/B]","XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % (name,id) ))

		liz.addContextMenuItems(commands, replaceItems=True)	
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz)
	return ok
	
def get_info_movie():

    # prompt the user to input search text
    kb = xbmc.Keyboard('', 'Titulo de la pelicula')
    kb.doModal()
    if not kb.isConfirmed():
        return None;
	
    name = kb.getText().strip()
	

    if xbmc.getCondVisibility('system.platform.android'):
	
	opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' +name+ '&language=es-ES'  ) )
	
        
	return 'android'

    elif xbmc.getCondVisibility('system.platform.windows'):
	
	opensite = webbrowser . open('https://www.themoviedb.org/search?query=' +name+ '&language=es-ES')
  
	
	return 'windows'
	


			
def video_tutoriales(): 
	
	try:
		
		content = make_request(db24)
		match = re.compile(mydb).findall(content)
		for m3u in match:
		
			try:
		
				op24 = m3u
				
			except:
				pass
		content = make_request(op24)
		match = re.compile(tutoriales_regex).findall(content)
		for thumb, name, url in match:
			try:
				m3u_videotutoriales(thumb, name, url)
			
			except:
				pass
				
	except:
		pass


def randomfilms():
    
    films = []
    selected = []
    header =[]
#    header.append(["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
#    read_url,read_header=plugintools.read_body_and_headers("https://netai.eu/realstream/Peliculas/db.m3u",headers =header)
#    content2 = make_request(dbpeliculast)
#    match = re.compile(r'img="(.+?)", (.+ \({0}\).*?)\(.*?\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'.format(url)).findall(content2)
#    src = requests.get(dbpeliculast).text
    content2 = make_request(dbpeliculast) 
    totallen=re.compile(r'(img=".+?",.+\s*fanart=".+"\s*.+\s*.+\s*)').findall(content2)
    for match in totallen:
        films.append(match) 
    for i in range(0,int(paginado_recomendaciones)):
        import random 
        selected_films=(random.choice(films)) 
        selected.append(selected_films)         
    
    finalfilms = "".join(selected)
    
    if keep_recomendaciones:
        file = (os.path.join(profile, 'recomendaciones_peliculas_{}.txt'.format(time.strftime('%Y-%m-%d'))))
        if not os.path.isfile(file):
            y = glob.glob(profile + 'recomendaciones_peliculas_*.txt')
            for x in y:
                os.remove(x)
            with open(file, 'w') as f:
                f.write( lll11(l1ll1(45) + l1ll1(53), base64.urlsafe_b64encode(zlib.compress(finalfilms))))
       
            match = re.compile(r'img="(.+?)",(.*?)\(\d+\).*?\((.*?)\)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*').findall(zlib.decompress(base64.urlsafe_b64decode(lll11(l1ll1(53),read_file(file)))))
            for iconimage, name, genre, fanart, url, description in match:  
               
            #plugintools.add_item(action="m3u_pelicula",title =name, thumbnail=iconimage, url=url, plot=description, fanart=fanart, folder=True)
                
                try:

                    add_dir2(name, url, 147, iconimage, fanart, description)

                except:
                	pass

    return

"""                    
def last():

    films = []
    content_db = make_request(dbpeliculast)
    match = re.compile(tutoriales_regex).findall(content_db) 

    for i in range(int(params.get("extra")), int(params.get("page"))):
        totallen = re.compile(r'(img=".+?",.+\s*fanart=".+"\s*.+\s*.+\s*)').findall(content_db)[i]
        films.append(totallen)
    for film in films:
        match = re.compile(r'img="(.+?)",(.*?)\(\d+\).*?\((.*?)\)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*').findall(film)
        for iconimage, name, genre,fanart, url, description in match:  
            
            #plugintools.add_item (action ="m3u_pelicula",title =name,thumbnail =iconimage,url =url,plot=description,fanart =fanart,folder =True )
            try:

                add_dir2(name, url, 147, iconimage, fanart, description)

            except:
                pass  

    #plugintools.add_item (action ="last",title ="[COLOR %s][I]>> Next Page[/I][/COLOR]"%MenuColor,page=str(int(params.get("page")) + int(paginado_peliculas)),extra=str(int(params.get("page"))), thumbnail =parse_media("siguiente.png"),fanart =addon .getAddonInfo ('fanart'),folder =True )
    add_dir("[COLOR %s][I]>> Siguiente[/I][/COLOR]" %MenuColor, url + int(paginado_peliculas), 199, siguiente, fanart)
    
    if force_views == "true":
        xbmc.executebuiltin ( "Container.SetViewMode(500)" )
    else: pass
"""


def m3u_videotutoriales(thumb, name, url):	
## despues de obtener las url de la lista m3u las muestra.
	
	name = re.sub('\s+', ' ', name).strip()	
	name = normalize(name.replace('Đ', 'D'))
	name = name.encode('utf-8')
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		if 'tvg-logo' in thumb:				
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
		else:	
			add_dir(name, url, '', icon, fanart)
	else:
		name = '[COLOR white]%s[/COLOR]' % name
			
		if 'tvg-logo' in thumb:				
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
			
			add_video(name, url, 4, iconimage, fanart)

		else:
		
			add_video(name, url, 4, iconimage, fanart)	


def m3u_playlist(name, url, thumb, id, trailer, description, fanart):	
## despues de obtener las url de la lista m3u las muestra.
    name = re.sub('\s+', ' ', name).strip()	
    name = normalize(name.replace('Đ', 'D'))
    name = name.encode('utf-8')
    url = url.replace('"', ' ').replace('&amp;', '&').strip()
    
    trailer = trailer.replace('"', ' ').strip()
    Fontcolor = addon.getSetting('Fontcolor')
    fanart = fanart.replace('"', ' ').replace('&amp;', '&').strip()
    name = '[COLOR %s]' % Fontcolor + name + '[/COLOR]'

			
    if 'tvg-logo' in thumb:				
        thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')

        if selecton == 'true':
            add_link2(name, url, 1, thumb, fanart, id, trailer, description)
        else:
				
            add_link2(name, url, 130, thumb, fanart, id, trailer, description)
						
    else:
		
        add_link2(name, url, 1, thumb, fanart, id, trailer, description)
	
    return

def m3u_playlist2(name, url, thumb, id, trailer, description, fanart):	
## despues de obtener las url de la lista m3u las muestra.
	name = re.sub('\s+', ' ', name).strip()	
	name = normalize(name.replace('Đ', 'D'))
	name = name.encode('utf-8')
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	trailer = trailer.replace('"', ' ').strip()
	Fontcolor = addon.getSetting('Fontcolor')
	fanart = fanart.replace('"', ' ').replace('&amp;', '&').strip()
	name = '[COLOR %s]' % Fontcolor + name + '[/COLOR]'

			
	if 'tvg-logo' in thumb:				
		thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
		if selecton == 'true':
			add_link2(name, url, 1, thumb, fanart, id, trailer, description)
		else:
				
			add_link2(name, url, 130, thumb, fanart, id, trailer, description)
						
	else:
		

		add_link2(name, url, 1, thumb, fanart, id, trailer, description)
	
	return

	        
def play_video(name,trailer):

	if notificar == 'true':	
		xbmc.executebuiltin("XBMC.Notification(Realstream, Reproduciendo Trailer de: [COLOR green]" +name+ "[/COLOR] ,5000)")

		url = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
		media_url = url
		item = xbmcgui.ListItem(name, trailer, path = media_url)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
	else:
		url = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
		media_url = url
		item = xbmcgui.ListItem(name, trailer, path = media_url)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
		
		
def play_box(name,url):

	if notificar == 'true':	
	
		try:
						
			dp = xbmcgui.DialogProgress()
			dp.create('Realstream:','Iniciando ...')
			dp.update(30,'Realstream:','Conectando al servidor ...')
			xbmc.sleep(1000)
			dp.update(75,'RESOLVEURL:','Resolviendo enlace ...')
			xbmc.sleep(500)
			dp.update(100,'RESOLVEURL:','Disfrute de la pelicula!')
			dp.close()
		
			media_url = url
			item = xbmcgui.ListItem(name, path = media_url)
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
			
		except: xbmc.executebuiltin("XBMC.Notification(Real Stream, Enlace borrado o no encontrado. ,3000)")  
		
	else:
	
		try:
	
			dp = xbmcgui.DialogProgress()
			dp.create('Realstream:','Iniciando ...')
			dp.update(30,'Realstream:','Conectando al servidor ...')
			xbmc.sleep(1000)
			dp.update(75,'RESOLVEURL:','Resolviendo enlace ...')
			xbmc.sleep(500)
			dp.update(100,'RESOLVEURL:','Disfrute de la pelicula!')
			dp.close()
	
			media_url = url
			item = xbmcgui.ListItem(name, path = media_url)
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
			
		except: xbmc.executebuiltin("XBMC.Notification(Real Stream, Enlace borrado o no encontrado. ,3000)") 
		
	return
		
		
def play_TRAILER(trailer):

	if 'https://www.youtube.com' in trailer:
	
		try:
	
			import resolveurl
		
			hmf = resolveurl.HostedMediaFile(url)
			dp = xbmcgui.DialogProgress()
			dp.create('Realstream:','Conectando al servidor ... ')
			dp.update(20,'Por favor, espere ...')
			xbmc.sleep(500)
		
			if not hmf:
				xbmc.executebuiltin("XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)")            
				return False

			try:
			
				dp.update(50,'RESOLVEURL:','Comprobando que existe el enlace.')
				xbmc.sleep(500)
				stream_url = hmf.resolve()
				if not stream_url or not isinstance(stream_url, basestring):
					try: msg = stream_url.msg
					except: msg = stream_url
					raise Exception(msg)
			except Exception as e:
				try: msg = str(e)
				except: msg = stream_url
				dp.update(100,'RESOLVEURL:','Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.')
				dp.close()
				xbmc.executebuiltin("XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)")            

			dp.update(50,'RESOLVEURL:','Comprobando si existe el enlace.')
			xbmc.sleep(500)
			dp.update(75,'RESOLVEURL:','Resolviendo enlace ...')
			xbmc.sleep(500)
			dp.update(95,'RESOLVEURL:','Encontrado ...')
			xbmc.sleep(500)
			dp.update(100,'RESOLVEURL:','Disfrute de la pelicula!')
			dp.close()

			listitem = xbmcgui.ListItem(path=stream_url)
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
		
		except:
			pass

		else:
		
			url = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
			media_url = url
			item = xbmcgui.ListItem(trailer, path = media_url)
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
			return

def PLAYVIDEO(name,url):

		if '[Youtube]' in name:
		
			url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
			media_url = url
			item = xbmcgui.ListItem(trailer, path = media_url)
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
	
			
		else:
		
			import resolveurl
		
			hmf = resolveurl.HostedMediaFile(url)

			if not hmf:
				xbmc.executebuiltin("XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" +name+ "[/COLOR] ,7500)")
				return False


			try:
				stream_url = hmf.resolve()
				if not stream_url or not isinstance(stream_url, basestring):
					try: msg = stream_url.msg
					except: msg = url
					raise Exception(msg)
			except Exception as e:
				try: msg = str(e)
				except: msg = url
				xbmc.executebuiltin("XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" +name+ "[/COLOR] ,7500)")            
				return False
   
			notificar = addon.getSetting('notificar')
			if notificar == 'true':
				xbmc.executebuiltin("XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" +name+ "[/COLOR] ,7500)")	
			listitem = xbmcgui.ListItem(path=stream_url)
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)

		
		return
		
def PLAY(name,url):	
	
	import urlresolver
	from urlresolver import common
    
	hmf = urlresolver.HostedMediaFile(url)

	if not hmf:
		xbmc.executebuiltin("XBMC.Notification([COLOR yellow]Realstream[/COLOR], Enlace no soportado para: [COLOR orange]" +name+ "[/COLOR] ,7500)")
		return False


	try:
		stream_url = hmf.resolve()
		if not stream_url or not isinstance(stream_url, basestring):
			try: msg = stream_url.msg
			except: msg = url
			raise Exception(msg)
	except Exception as e:
		try: msg = str(e)
		except: msg = url
		xbmc.executebuiltin("XBMC.Notification([COLOR yellow]Realstream[/COLOR], [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" +name+ "[/COLOR] ,7500)")            
		return False
   

	xbmc.executebuiltin("XBMC.Notification([COLOR yellow]Realstream[/COLOR],[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" +name+ "[/COLOR] ,7500)")	
	listitem = xbmcgui.ListItem(path=stream_url)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
	
	
	
def play_resolveurl(name,url):


	import resolveurl
		
	hmf = resolveurl.HostedMediaFile(url)
		
	if not hmf:
		xbmc.executebuiltin("XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" +name+ "[/COLOR] ,5000)")
		return False
	try:
	
		dp = xbmcgui.DialogProgress()
		dp.create('Realstream:','Iniciando ...')
		dp.update(30,'RESOLVEURL:','Conectando al servidor ...')
		xbmc.sleep(1000)
		stream_url = hmf.resolve()
		
		if not stream_url or not isinstance(stream_url, basestring):
			try: msg = stream_url.msg
			except: msg = url
			raise Exception(msg)
					
	except Exception as e:
						
		try: msg = str(e)
		except: msg = url
						
		
		xbmc.sleep(1000)
		xbmc.executebuiltin("XBMC.Notification(Real Stream, Enlace no disponible.  ,3000)")            
		dp.close()
	
						
	dp.update(60,'RESOLVEURL:','Comprobando que existe el enlace.')
	xbmc.sleep(500)
	dp.update(75,'RESOLVEURL:','Resolviendo enlace ...')
	xbmc.sleep(500)
	dp.update(95,'RESOLVEURL:','Encontrado ...')
	xbmc.sleep(500)
	dp.update(100,'RESOLVEURL:','Lanzando Streaming!')
	dp.close()
	

	listitem = xbmcgui.ListItem(path=stream_url)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)



def play_urlresolver(name,url):


	import urlresolver
	from urlresolver import common
    
	hmf = urlresolver.HostedMediaFile(url)
		
	if not hmf:
		xbmc.executebuiltin("XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" +name+ "[/COLOR] ,5000)")
		return False

	try:
						
		dp = xbmcgui.DialogProgress()
		dp.create('Realstream:','Iniciando ...')
		dp.update(30,'URLRESOLVER:','Conectando al servidor ...')
		xbmc.sleep(1000)
		stream_url = hmf.resolve()
		
		if not stream_url or not isinstance(stream_url, basestring):
			try: msg = stream_url.msg
			except: msg = url
			raise Exception(msg)
					
	except Exception as e:
						
		try: msg = str(e)
		except: msg = url
			
		xbmc.sleep(1000)
		xbmc.executebuiltin("XBMC.Notification(Real Stream, Enlace no disponible.  ,3000)")            
		dp.close()
						
	dp.update(60,'URLRESOLVER:','Comprobando que existe el enlace.')
	xbmc.sleep(500)
	dp.update(75,'URLRESOLVER:','Resolviendo enlace ...')
	xbmc.sleep(500)
	dp.update(95,'URLRESOLVER:','Encontrado ...')
	xbmc.sleep(500)
	dp.update(100,'URLRESOLVER:','Lanzando streaming !')
	dp.close()
	notificar = addon.getSetting('notificar')
	listitem = xbmcgui.ListItem(path=stream_url)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)



def check_gdrive():

	if xbmc.getCondVisibility('System.HasAddon(plugin.video.gdrive)'):

		xbmc.executebuiltin("XBMC.Notification(Real Stream:, [COLOR lime] Addon Gdrive Activado!  [/COLOR],2000)")
	
	else:	
	
		xbmc.executebuiltin("XBMC.Notification(Real Stream:, [COLOR red] Addon Gdrive No esta activo!  [/COLOR],2000)")
		
	return


	

""" gracias a Catoal """

def action_video(name, videoUrl):
    _handle = int(sys.argv[1])
    playitem = xbmcgui.ListItem(path=videoUrl)
    playitem.setInfo('video', {'title': name})
    xbmcplugin.setResolvedUrl(_handle, True, playitem)
	
""" """	

	
def play_gdrive(name,url):

    try:
					
        gdrive = addon.getSetting('gdrive')
        Resolve = addon.getSetting('Resolve')
	
        if 'google.com' in url:
		
            if xbmc.getCondVisibility('System.HasAddon(plugin.video.gdrive)'):
	
                if gdrive == "true":
	
					try:
									
						#Aqui ha estado Maniac Team y the dreamers!
						patron = 'https?://(?:drive|docs)\\.google\\.com/(?:file/d/|uc\\?id=|get_video_info\\?docid=)([^/&]+)'
						id = re.findall(patron, url, flags=re.DOTALL)[0]
						videoUrl = 'plugin://plugin.video.gdrive/?mode=video&amp;instance=gdrive1&amp;filename=%s&amp;content_type=video' % id

						if videoUrl:
											
						#xbmc.log('############ exito %s' % videoUrl)
	
							action_video(name, videoUrl)
				
						else:
							
							#xbmc.log('############ error
							xbmc.executebuiltin("XBMC.Notification(Real Stream:, [COLOR red]Enlace no disponible[/COLOR], 3000)")
						return False

					except:
						pass
							
                else:

                    try:
			
                        play_resolveurl(name,url)

                    except: 

                        xbmc.executebuiltin("XBMC.Notification(Real Stream:, [COLOR white]No se ha podido resolver el enlace![/COLOR], 3000)")

                        pass
                
            else:



                xbmc.executebuiltin("XBMC.Notification(Real Stream:, [COLOR white]Realstream debe tener instaldo Gdrive para poder visionar los enlaces Drive![/COLOR], 3000)")

            return

			
                

        elif "cloudvideo" in url:
   
            headers= {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_2) AppleWebKit/601.3.9 (KHTML, like Gecko) Version/9.0.2 Safari/601.3.9"}
            source = requests.get(url, headers=headers)
            pack = re.findall(r'(?s)javascript\">(eval.*?)<\/script', source.content)[0]
            unpack=jsunpack.unpack(pack).replace('\\', '') 
            video_Url = re.findall(r'(?s)src:"(.*?)"', unpack.content)[0]

            if videoUrl:
                
                action_video(name, videoUrl)
            
            return
                
        
        else:

            try:
			
                play_resolveurl(name,url)

            except: 

                xbmc.executebuiltin("XBMC.Notification(Real Stream:, [COLOR white]No se ha podido resolver el enlace![/COLOR], 3000)")

                pass

            
							
        return
													
    except:
        pass


			
			
		
def PLAY_Resolved(name,url):

    try:

        consulta = new_register("https://netai.eu/realstream/Usuarios/inicio.php")
        match = re.compile(regex_login).findall(consulta)
        for nombre,correo,clave in match:
            if re.search(claves, clave):
		
                if usuario == nombre and mail == correo and claves == clave:

                    try:
					
                        if 'google.com' in url:
	
                            if xbmc.getCondVisibility('System.HasAddon(plugin.video.gdrive)'):
							
							
                                play_gdrive(name,url)
								
                            else:
                            
                                xbmcgui.Dialog().ok("Real Stream", "[COLOR yellow]El addon Gdrive no esta instalado o activo.[/COLOR]", "[COLOR white]No se podran visionar enlaces Drive.[/COLOR]", "[COLOR white] Por favor asegurese de configurar las API de google para su correcto funcionamiento.[/COLOR]")
							
                                #xbmc.executebuiltin("XBMC.Notification(Real Stream:, [COLOR red]No se ha encontrado el addon Gdrive activado.[/COLOR], 3000)")
								
                            return False

							
                        else:
		
                            play_resolveurl(name,url)
					
                        return
							
                    except:
                        pass

    except:
        pass

def buscar_themovieid(): 

## ESTA FUNCION BUSCA EN LAS LISTAS m3u DENTRO DE LAS CATEGORIAS. | Cuantas mas categorias, mas lento ira el buscador a no ser que hagamos buscadores individuales.

	keyb = xbmc.Keyboard('', 'Escriba id de la pelicula: Themoviedb.org')
	keyb.doModal()
	if (keyb.isConfirmed()):
		
		searchText = urllib.quote_plus(keyb.getText()).replace('+', ' ')
			
		if xbmc.getCondVisibility('System.HasAddon(script.extendedinfo)'):
			   
			xbmc.executebuiltin( "RunScript(script.extendedinfo,info=extendedinfo, name=%s)" % searchText )

			if notificar == 'true':	
	
				xbmc.executebuiltin("XBMC.Notification(Extended Info,Abriendo: [COLOR green]" +name+ "[/COLOR] ,10000)")
		    
			  
		else:
				
			xbmcgui.Dialog().ok("El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]","[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]")     

def get_params():

	param = []
	paramstring = sys.argv[2]
	if len(paramstring)>= 2:
		params = sys.argv[2]
		cleanedparams = params.replace('?', '')
		if (params[len(params)-1] == '/'):
			params = params[0:len(params)-2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams = {}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0]] = splitparams[1]
	return param
	
	
def resolver_settings():
 
    import resolveurl
    xbmcaddon.Addon('script.module.resolveurl').openSettings()
 
    
def add_dir(name, url, mode, iconimage, fanart):
## Añadre los directorios del menu. Con sus respetivos iconos y fanart y los enlaces a las acciones a enprender por el addon.
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
	ok = True
	liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		u = 'plugin://plugin.video.youtube/%s/%s/' % (url.split( '/' )[-2], url.split( '/' )[-1])
		ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
		return ok		
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
	return ok
	
def add_dir2(name, url, mode, iconimage, fanart, description):
## Añadre los directorios del menu. Con sus respetivos iconos y fanart y los enlaces a las acciones a enprender por el addon.
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
	ok = True
	liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name, "Plot": description } )
	liz.setProperty('fanart_image', fanart)	
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
	return ok
	
def add_dir3(name, url, mode, iconimage, fanart, description):
## Añadre los directorios del menu. Con sus respetivos iconos y fanart y los enlaces a las acciones a enprender por el addon.
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
	ok = True
	liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name, "Plot": description } )
	liz.setProperty('fanart_image', fanart)	
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
	return ok
	
def add_dir_original(name, url, mode, iconimage):
## Añadre los directorios del menu. Con sus respetivos iconos y fanart y los enlaces a las acciones a enprender por el addon.
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
	ok = True
	liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name, "Plot": description } )
	liz.setProperty('fanart_image', fanart)	
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
	return ok
	
	
def add_link(name, url, mode, iconimage, fanart, id, trailer):
	
	pluginname = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt'.decode('\x62\x61\x73\x65\x36\x34')
	
	try:
		
            name = name.encode('utf-8')
        except: pass
	commands=[]
	
	commands.append(("Reproducir Trailer","XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % (trailer)))
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&id=" + str(id) + "&trailer=" + urllib.quote_plus(trailer)
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'true')

	if xbmc.getCondVisibility('System.HasAddon(script.extendedinfo)'):
		commands.append(("[B][COLOR yellow]ExtendedInfo[/COLOR][/B]","XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % (name,id) ))

		liz.addContextMenuItems(commands, replaceItems=True)
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz)
	return ok
	

def add_link2(name, url, mode, iconimage, fanart, id, trailer, description):
	
	pluginname = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt'.decode('\x62\x61\x73\x65\x36\x34')
	
	try:

            name = name.encode('utf-8')
        except: pass
	commands=[]
	
	commands.append(("Reproducir Trailer","XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % (trailer)))
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&id=" + str(id) + "&trailer=" + urllib.quote_plus(trailer)
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name, "Plot": description } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'true')

	if xbmc.getCondVisibility('System.HasAddon(script.extendedinfo)'):
		commands.append(("[B][COLOR yellow]ExtendedInfo[/COLOR][/B]","XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % (name,id) ))

		liz.addContextMenuItems(commands, replaceItems=True)
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz)
	return ok
	
def add_video(name, url, mode, iconimage, fanart):

	try:

            name = name.encode('utf-8')
        except: pass
	
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&id=" + str(id)
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'true') 
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz)
	return ok
	
def add_video2(name, url, mode, iconimage):

	try:

            name = name.encode('utf-8')
        except: pass
	
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&id=" + str(id)
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'true') 
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz)
	return ok	
	
def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
	
def buscar_themovieid(): 

## ESTA FUNCION BUSCA EN LAS LISTAS m3u DENTRO DE LAS CATEGORIAS. | Cuantas mas categorias, mas lento ira el buscador a no ser que hagamos buscadores individuales.

	keyb = xbmc.Keyboard('', 'Escriba id de la pelicula: Themoviedb.org')
	keyb.doModal()
	if (keyb.isConfirmed()):
		
		searchText = urllib.quote_plus(keyb.getText()).replace('+', ' ')
			
		if xbmc.getCondVisibility('System.HasAddon(script.extendedinfo)'):
			   
			xbmc.executebuiltin( "RunScript(script.extendedinfo,info=extendedinfo, name=%s)" % searchText )

			if notificar == 'true':	
	
				xbmc.executebuiltin("XBMC.Notification(Extended Info,Abriendo: [COLOR green]" +name+ "[/COLOR] ,10000)")
		    
			  
		else:
				
			xbmcgui.Dialog().ok("El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]","[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]")     

"""
def saz(params):

    src = requests.get('https://netai.eu/realstream/Series/dataseries/Series.m3u').text
    az = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

    plugintools .add_item (action ="parse_saz",title ='[COLOR {0}]'.format(MenuColor) + "0-9" +'[/COLOR]',thumbnail =parse_media("Seriesalfabeto.png"),url ="\d+",fanart =fanart,folder =True )

    for l in az:
        letters = [] 
        if l not in letters:
            letters.append(l)
       
        for letter in letters:

            plugintools .add_item (action ="parse_saz",title ='[COLOR {0}]'.format(MenuColor) + letter +'[/COLOR]',thumbnail =parse_media("Seriesalfabeto.png"),url =letter,fanart =fanart,folder =True )

      
def parse_saz(params): 

    if params.get("url") != "\d+":
        header =[]
        header .append (["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
        read_url ,read_header =plugintools .read_body_and_headers ("https://netai.eu/realstream/Series/dataseries/Series.m3u" ,headers =header)
        content_db =read_url .strip () 
        match = re.compile(r'img="(.+?)", ({0}.+ \(\d+\)).*?\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'.format(params.get("url"))).findall(content_db)
        for iconimage, name, fanart, url, description in match:  
 
            plugintools .add_item (action ="seasons",title =name,thumbnail =iconimage,url =url,plot=description,fanart =fanart,folder =True )
    else:
        header =[]
        header .append (["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
        read_url ,read_header =plugintools .read_body_and_headers ("https://netai.eu/realstream/Series/dataseries/Series.m3u" ,headers =header)
        content_db =read_url .strip () 
        
        spec = "0123456789#%&!¿?*-+"
        for i in spec:
            match = re.compile(r'img="(.+?)", ({0}.+ \(\d+\)).*?\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'.format(i)).findall(content_db)
            for iconimage, name, fanart, url, description in match:  
 
                plugintools .add_item (action ="seasons",title =name,thumbnail =iconimage,url =url,plot=description,fanart =fanart,folder =True )


def randomseries(params):
    
    series = []
    selected = []
    header =[]
    header .append (["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
    read_url ,read_header =plugintools .read_body_and_headers ("https://netai.eu/realstream/Series/dataseries/Series.m3u" ,headers =header)
    content2 =read_url .strip () 
    totallen = re.compile(r'(img=".+?",.+\s*fanart=".+"\s*.+\s*.+\s*)').findall(content2)
    for match in totallen:
        series.append(match) 
    for i in range(0,int(paginado_recomendaciones)):
        import random 
        selected_series = (random.choice(series)) 
        selected.append(selected_series)         
    
    finalseries = "".join(selected)
    
    if keep_recomendaciones:
      file = (os.path.join(profile, 'recomendaciones_series_{}.txt'.format(time.strftime('%Y-%m-%d'))))
      if not os.path.isfile(file):
        y = glob.glob(profile + 'recomendaciones_series_*.txt')
        for x in y:
            os.remove(x)
        with open(file, 'w') as f:
             
            f.write( lll11(l1ll1(45) + l1ll1(53), base64.urlsafe_b64encode(zlib.compress(finalseries) )))
       
      match = re.compile(r'img="(.+?)",(.*?)\(\d+\).*?\((.*?)\)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*').findall(zlib.decompress(base64.urlsafe_b64decode(lll11(l1ll1(53),read_file(file)))))
      for iconimage, name, genre,fanart, url, description in match:  
                plugintools .add_item (action ="seasons",title =name,thumbnail =iconimage,url =url,plot=description,fanart =fanart,folder =True )

def slast():
    films = []
    header =[]
#    header .append (["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
#    read_url,read_header =plugintools .read_body_and_headers ("https://netai.eu/realstream/Series/dataseries/Series.m3u" ,headers =header)

    content_db =read_url.strip()
    for i in range(int(params.get("extra")), int(params.get("page"))):
        totallen = re.compile(r'(img=".+?",.+\s*fanart=".+"\s*.+\s*.+\s*)').findall(content_db)[i]
        films.append(totallen)
    for film in films:
        match = re.compile(r'img="(.+?)",(.*?)\(\d+\).*?\((.*?)\)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*').findall(film)
        for iconimage, name, genre,fanart, url, description in match:  
                plugintools .add_item (action ="seasons",title =name,thumbnail =iconimage,url =url,plot=description,fanart =fanart,folder =True )
    plugintools .add_item (action ="slast",title ="[COLOR %s][I]>> Next Page[/I][/COLOR]"%MenuColor,page=str(int(params.get("page")) + int(paginado_peliculas)),extra=str(int(params.get("page"))), thumbnail =parse_media("siguiente.png"),fanart =addon .getAddonInfo ('fanart'),folder =True )

    if force_views == "true":
        xbmc.executebuiltin ( "Container.SetViewMode(500)" )
    else: pass    

""" 


params = get_params()
url = None
name = None
mode = None
iconimage = None
id = None
trailer = None

xbmcplugin.setContent(int(sys.argv[1]), 'movies')

try:
	url = urllib.unquote_plus(params["url"])
except:
	pass
try:
	name = urllib.unquote_plus(params["name"])
except:
	pass
try:
	mode = int(params["mode"])
except:
	pass
try:
	iconimage = urllib.unquote_plus(params["iconimage"])
except:
	pass 
try:
	id = int(params["id"])
except:
	pass 
try:
	trailer = urllib.unquote_plus(params["trailer"])
except:
	pass 
	

print "Mode: " + str(mode)
print "URL: " + str(url)
print "Name: " + str(name)
print "iconimage: " + str(iconimage)
print "id: " + str(id)
print "trailer: " + str(trailer)


if mode == None or url == None or len(url) < 1:
	
    mensaje()
    menu()
    total()

    xbmc.sleep(4000)
    check_gdrive()
	
elif mode == 1:
	selector(name, url, id, trailer)
elif mode == 4:
    PLAYVIDEO(name,url)
elif mode == 5:
	Lista_4k()
elif mode == 28:
	PLAYSERIE(name,url)
elif mode == 111:
    search()
elif mode == 116:
    peliculas()	
elif mode == 117:
	series()
elif mode == 119:
    Real_stream_settings()
elif mode == 120:
	urlresolver_settings()  
elif mode == 121:
    favoritos() 
elif mode == 127:
    buscar_themovieid()
elif mode == 130:
	PLAY_Resolved(name,url)
elif mode == 140:
	resolveurl_settings()
elif mode == 141:
	Lista_p4k()
elif mode == 142:
	Lista_Series()
elif mode == 143:
	m3u_playseries(name,url)
elif mode == 144:
	PLAYSERIE(name,url)
elif mode == 145:
    searchs()
elif mode == 146:
	search_p()
elif mode == 147:
	m3u_pelicula(name,url)
elif mode == 148:
	m3u_eventos(name,url)
elif mode == 150:
	emitiendo()
elif mode == 151:
	top15()
elif mode == 152:
	seriesretro()
elif mode == 155:
	novedades_series()
elif mode == 156:
	series_infantiles()
elif mode == 157:
	series_4k()
elif mode == 161:
    Enlace_Series(url)
elif mode == 179:
	tools()	
elif mode == 180:
	get_favoritos()
elif mode == 181:
	years()
elif mode == 182:
	parse_years(url)
elif mode == 183:
	genres()
elif mode == 184:
	parse_genres(url)
elif mode == 185:
	az()
elif mode == 186:
	parse_az(url)
elif mode == 187:
	especiales()
elif mode == 190:
	parse_sections(url)	
elif mode == 191:
	make_login_zip()
elif mode == 192:
	restore_login()
elif mode == 193:
	make_gd_login_zip()
elif mode == 194:
	restore_gd_login()
elif mode == 195:
	install_gd()
elif mode == 196:
    seasons(iconimage,url)
elif mode == 197:
    parse_seasons(url)   
elif mode == 198:
    parse_series(url)
elif mode == 199:
	last()
elif mode == 201:
    randomfilms()
xbmcplugin.endOfDirectory(plugin_handle)