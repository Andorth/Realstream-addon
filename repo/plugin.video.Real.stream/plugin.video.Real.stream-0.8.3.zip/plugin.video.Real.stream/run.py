# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 0.8.1
#
############################################
# Dependencias 
# Script ExtendedInfo
# Script Urlresolver de TVAddons
# Script ResolveURL Por Jsergio.
#
############################################
#
# Corregido imcompatibilidad con Servidor Team
# Agregados nuevos iconos, ahora se puede el aspecto desde ajustes del addon.
#
############################################
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import urlresolver
import cookielib , base64
import requests
import plugintools
import config
oo000 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
ii = oo000 . getAddonInfo ( 'version' )
oOOo = int ( sys . argv [ 1 ] )
O0 = 'gruponetai/'
o0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
iI11I1II1I1I = o0O . getAddonInfo ( 'profile' )
oooo = o0O . getAddonInfo ( 'path' )
iIIii1IIi = oo000 . getSetting ( 'iconos' )
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if iIIii1IIi == 'true' :
 if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
 O0oOO0o0 = xbmc . translatePath ( os . path . join ( oooo , 'fanart.png' ) )
 i1ii1iIII = xbmc . translatePath ( os . path . join ( oooo , 'icon.png' ) )
 Oo0oO0oo0oO00 = xbmc . translatePath ( os . path . join ( oooo , 'extended_info.png' ) )
 i111I = xbmc . translatePath ( os . path . join ( oooo , 'buscar.png' ) )
 II1Ii1iI1i = xbmc . translatePath ( os . path . join ( oooo , 'pair.png' ) )
 iiI1iIiI = xbmc . translatePath ( os . path . join ( oooo , 'theMovieDB.png' ) )
 OOo = xbmc . translatePath ( os . path . join ( oooo , 'novedades.png' ) )
 Ii1IIii11 = xbmc . translatePath ( os . path . join ( oooo , 'estrenos.png' ) )
 Oooo0000 = xbmc . translatePath ( os . path . join ( oooo , 'recomendadas.png' ) )
 i11 = xbmc . translatePath ( os . path . join ( oooo , 'accion.png' ) )
 I11 = xbmc . translatePath ( os . path . join ( oooo , 'animacion.png' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( oooo , 'aventuras.png' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( oooo , 'belico.png' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( oooo , 'ciencia-ficcion.png' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( oooo , 'comedia.png' ) )
 oO = xbmc . translatePath ( os . path . join ( oooo , 'crimen.png' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( oooo , 'drama.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( oooo , 'familiar.png' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( oooo , 'fantasia.png' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( oooo , 'historia.png' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( oooo , 'marvel.png' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( oooo , 'misterio.png' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( oooo , 'musical.png' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( oooo , 'romance.png' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( oooo , 'spain.png' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( oooo , 'suspense.png' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( oooo , 'terror.png' ) )
 II = xbmc . translatePath ( os . path . join ( oooo , 'thriller.png' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( oooo , 'western.png' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( oooo , 'sagas_cine.png' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( oooo , '4k.png' ) )
 OO0o = xbmc . translatePath ( os . path . join ( oooo , 'torrent.png' ) )
 if 82 - 82: i1I1i1Ii11 . IIIIII11i1I - o0o0OOO0o0 % IIII % IIIIII11i1I . OoO0O00
else :
 if 22 - 22: IIIIII11i1I + o0oOOo0O0Ooo % o0o0OOO0o0 . ooOoO0o . I11i
 if 76 - 76: I11i - I1IiiI % I1Ii111 / iII111i / I11i
 iIIii1IIi = oo000 . getSetting ( 'iconos' )
 O0oOO0o0 = xbmc . translatePath ( os . path . join ( oooo , 'fanart.jpg' ) )
 i1ii1iIII = xbmc . translatePath ( os . path . join ( oooo , 'icon.png' ) )
 Oo0oO0oo0oO00 = xbmc . translatePath ( os . path . join ( oooo , 'extended_info.png' ) )
 i111I = xbmc . translatePath ( os . path . join ( oooo , 'buscar.png' ) )
 II1Ii1iI1i = xbmc . translatePath ( os . path . join ( oooo , 'pair.png' ) )
 iiI1iIiI = xbmc . translatePath ( os . path . join ( oooo , 'theMovieDB.jpg' ) )
 OOo = xbmc . translatePath ( os . path . join ( oooo , 'novedades.jpg' ) )
 Ii1IIii11 = xbmc . translatePath ( os . path . join ( oooo , 'encines.jpg' ) )
 Oooo0000 = xbmc . translatePath ( os . path . join ( oooo , 'recomendadas.jpg' ) )
 i11 = xbmc . translatePath ( os . path . join ( oooo , 'accion.jpg' ) )
 I11 = xbmc . translatePath ( os . path . join ( oooo , 'animacion.jpg' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( oooo , 'aventuras.jpg' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( oooo , 'belico.jpg' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( oooo , 'ciencia-ficcion.jpg' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( oooo , 'comedia.jpg' ) )
 oO = xbmc . translatePath ( os . path . join ( oooo , 'crimen.jpg' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( oooo , 'drama.jpg' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( oooo , 'familiar.jpg' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( oooo , 'fantasia.jpg' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( oooo , 'historia.jpg' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( oooo , 'superheroes.jpg' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( oooo , 'misterio.jpg' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( oooo , 'musical.jpg' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( oooo , 'romance.jpg' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( oooo , 'spain.jpg' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( oooo , 'suspense.jpg' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( oooo , 'terror.jpg' ) )
 II = xbmc . translatePath ( os . path . join ( oooo , 'thriller.jpg' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( oooo , 'western.jpg' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( oooo , 'sagas_cine.jpg' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( oooo , '4k.jpg' ) )
 OO0o = xbmc . translatePath ( os . path . join ( oooo , 'torrent.jpg' ) )
 if 54 - 54: I1ii11iIi11i % o0oOOo0O0Ooo % o0oOOo0O0Ooo
 if 13 - 13: Ii1I . o00O0oo
 if 19 - 19: ooOoO0o + IIII
 if 53 - 53: OoO0O00 . OoOoOO00
ii1I1i1I = xbmc . translatePath ( os . path . join ( oooo , 'peliculas.png' ) )
OOoo0O0 = xbmc . translatePath ( os . path . join ( oooo , 'ajustes.png' ) )
iiiIi1i1I = xbmc . translatePath ( os . path . join ( oooo , 'videoteca.png' ) )
oOO00oOO = xbmc . translatePath ( os . path . join ( oooo , 'favorites.png' ) )
OoOo = xbmc . translatePath ( os . path . join ( oooo , 'resolver.png' ) )
iI = xbmc . translatePath ( os . path . join ( oooo , 'test.png' ) )
o00O = xbmc . translatePath ( os . path . join ( oooo , 'video-tutoriales.png' ) )
OOO0OOO00oo = xbmc . translatePath ( os . path . join ( oooo , 'proxy.png' ) )
if 31 - 31: o0oOOo0O0Ooo - I1Ii111 . o0o0OOO0o0 % I11i - I1IiiI
iii11 = oo000 . getSetting ( 'mostrar_cat' )
O0oo0OO0oOOOo = oo000 . getSetting ( 'videos' )
i1i1i11IIi = oo000 . getSetting ( 'activar' )
II1III = oo000 . getSetting ( 'favcopy' )
iI1iI1I1i1I = oo000 . getSetting ( 'anticopia' )
iIi11Ii1 = oo000 . getSetting ( 'licencia_addon' )
Ii11iII1 = oo000 . getSetting ( 'notificar' )
Oo0O0O0ooO0O = oo000 . getSetting ( 'mostrar_bus' )
IIIIii = oo000 . getSetting ( 'restante' )
O0o0 = oo000 . getSetting ( 'aviso' )
OO00Oo = oo000 . getSetting ( 'RealStream_Settings' )
O0OOO0OOoO0O = oo000 . getSetting ( 'Resolver_Settings' )
IIIIii = oo000 . getSetting ( 'restante' )
O00Oo000ooO0 = oo000 . getSetting ( 'fav' )
OoO0O00IIiII = oo000 . getSetting ( 'Fontcolor' )
o0 = oo000 . getSetting ( 'MenuColor' )
ooOooo000oOO = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
Oo0oOOo = 'bienvenida'
Oo0OoO00oOO0o = 'bienvenida'
copyright = oo000 . getSetting ( 'copyright' )
OOO00O = 'cGx1Z2luLnZpZGVvLg==' . decode ( 'base64' ) + copyright
OOoOO0oo0ooO = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
O0o0O00Oo0o0 = oo000 . getSetting ( 'Forceupdate' )
if O0o0O00Oo0o0 == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
O00O0oOO00O00 = '.txt'
if 11 - 11: IIIIII11i1I . iII111i
o0oo0oOo = ooOooo000oOO + Oo0oOOo + O00O0oOO00O00
o000O0o = 'http://www.youtube.com'
iI1iII1 = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
oO0OOoo0OO = '.xsl.pt'
O0ii1ii1ii = '/master/'
oooooOoo0ooo = iI1iII1 + oO0OOoo0OO
I1I1IiI1 = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*texto3=[\'"](.*?)[\'"]\s*'
III1iII1I1ii = 'tvg-logo=[\'"](.*?)[\'"]'
if 61 - 61: o0oOOo0O0Ooo
O0OOO = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)'
II11iIiIIIiI = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
o0o = '#(.+?),(.+)\s*(.+)'
o00 = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
if 56 - 56: I1ii11iIi11i - oO0o . o00O0oo - IIIIII11i1I
OOOoOoo0O = 'source src=[\'"](.*?)[\'"]\s*title=[\'"](.*?)[\'"]'
O000OOo00oo = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
oo0OOo = '[\'"](.*?)[\'"]'
ooOOO00Ooo = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
IiIIIi1iIi = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( 'base64' )
ooOOoooooo = IiIIIi1iIi + O0
II1I = '[\'"](.*?)[\'"]'
O0i1II1Iiii1I11 = 'UmVhbHN0cmVhbQ==' . decode ( 'base64' )
IIIIiiIiI = 'video=[\'"](.*?)[\'"]'
o00oooO0Oo = '0110nhu' . replace ( '0110nhu' , 'nhu' )
o0O0OOO0Ooo = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( 'base64' ) + o00oooO0Oo
iiIiI = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
I1 = '0110R0N' . replace ( '0110R0N' , 'R0N' )
OOO00O0O = 'aHR0cDovL2JpdC5seS8yWEIx' . decode ( 'base64' ) + I1
iii = '0110pEJ' . replace ( '0110pEJ' , 'pEJ' )
oOooOOOoOo = 'aHR0cDovL2JpdC5seS8yd1Nh' . decode ( 'base64' ) + iii
i1Iii1i1I = 'ABBAOb5' . replace ( 'ABBAOb5' , 'Ob5' )
OOoO00 = 'aHR0cDovL2JpdC5seS8yRVhV' . decode ( 'base64' ) + i1Iii1i1I
IiI111111IIII = '0110jaw' . replace ( '0110jaw' , 'jaw' )
i1Ii = 'aHR0cDovL2JpdC5seS8yd01M' . decode ( 'base64' ) + IiI111111IIII
ii111iI1iIi1 = '01109DI' . replace ( '01109DI' , '9DI' )
OOO = 'aHR0cDovL2JpdC5seS8ySXgz' . decode ( 'base64' ) + ii111iI1iIi1
oo0OOo0 = '01103hs' . replace ( '01103hs' , '3hs' )
I11IiI = 'aHR0cDovL2JpdC5seS8zMW1U' . decode ( 'base64' ) + oo0OOo0
O0ooO0Oo00o = '01107DW' . replace ( '01107DW' , '7DW' )
ooO0oOOooOo0 = 'aHR0cDovL2JpdC5seS8yV1ln' . decode ( 'base64' ) + O0ooO0Oo00o
i1I1ii11i1Iii = '0110mLl' . replace ( '0110mLl' , 'mLl' )
I1IiiiiI = 'aHR0cDovL2JpdC5seS8yS0cw' . decode ( 'base64' ) + i1I1ii11i1Iii
o0OIiII = '01102Hj' . replace ( '01102Hj' , '2Hj' )
ii1iII1II = 'aHR0cDovL2JpdC5seS8yWEJo' . decode ( 'base64' ) + o0OIiII
Iii1I1I11iiI1 = '0110fXg' . replace ( '0110fXg' , 'fXg' )
I1I1i1I = 'aHR0cDovL2JpdC5seS8ySTVy' . decode ( 'base64' ) + Iii1I1I11iiI1
ii1I = '0110NMH' . replace ( '0110NMH' , 'NMH' )
O0oO0 = 'aHR0cDovL2JpdC5seS8yd0t6' . decode ( 'base64' ) + ii1I
oO0 = '0110bwQ' . replace ( '0110bwQ' , 'bwQ' )
O0OO0O = 'aHR0cDovL2JpdC5seS8yd01V' . decode ( 'base64' ) + oO0
OO = '0110xzG' . replace ( '0110xzG' , 'xzG' )
OoOoO = 'aHR0cDovL2JpdC5seS8yWHhz' . decode ( 'base64' ) + OO
Ii1I1i = '0110x64' . replace ( '0110x64' , 'x64' )
OOI1iI1ii1II = 'aHR0cDovL2JpdC5seS8yRVlF' . decode ( 'base64' ) + Ii1I1i
O0O0OOOOoo = '0110vUE' . replace ( '0110vUE' , 'vUE' )
oOooO0 = 'aHR0cDovL2JpdC5seS8yWmhW' . decode ( 'base64' ) + O0O0OOOOoo
Ii1I1Ii = '01107ZL' . replace ( '01107ZL' , '7ZL' )
OOoO0 = 'aHR0cDovL2JpdC5seS8yWm4w' . decode ( 'base64' ) + Ii1I1Ii
OO0Oooo0oOO0O = '01106cf' . replace ( '01106cf' , '6cf' )
o00O0 = 'aHR0cDovL2JpdC5seS8yRVlk' . decode ( 'base64' ) + OO0Oooo0oOO0O
oOO0O00Oo0O0o = '0110Jtp' . replace ( '0110Jtp' , 'Jtp' )
ii1 = 'aHR0cDovL2JpdC5seS8yV3Nq' . decode ( 'base64' ) + oOO0O00Oo0O0o
I1iIIiiIIi1i = '0110a5b' . replace ( '0110a5b' , 'a5b' )
O0O0ooOOO = 'aHR0cDovL2JpdC5seS8yV3dj' . decode ( 'base64' ) + I1iIIiiIIi1i
oOOo0O00o = '0110Q7u' . replace ( '0110Q7u' , 'Q7u' )
iIiIi11 = 'aHR0cDovL2JpdC5seS8yV3NL' . decode ( 'base64' ) + oOOo0O00o
OOOiiiiI = '0110rsq' . replace ( '0110rsq' , 'rsq' )
oooOo0OOOoo0 = 'aHR0cDovL2JpdC5seS8ySzhE' . decode ( 'base64' ) + OOOiiiiI
OOoO = '0110DDR' . replace ( '0110DDR' , 'DDR' )
OO0O000 = 'aHR0cDovL2JpdC5seS8ySzd5' . decode ( 'base64' ) + OOoO
iiIiI1i1 = '0110feQ' . replace ( '0110feQ' , 'feQ' )
oO0O00oOOoooO = 'aHR0cDovL2JpdC5seS8yS0cz' . decode ( 'base64' ) + iiIiI1i1
IiIi11iI = '0110MHY' . replace ( '0110MHY' , 'MHY' )
Oo0O00O000 = 'aHR0cDovL2JpdC5seS8ySXVo' . decode ( 'base64' ) + IiIi11iI
i11I1IiII1i1i = '0110xdb' . replace ( '0110xdb' , 'xdb' )
oo = 'aHR0cDovL2JpdC5seS8yWEJu' . decode ( 'base64' ) + i11I1IiII1i1i
I1111i = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( 'base64' )
OOO00O = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
iIIii = '0110lxu' . replace ( '0110lxu' , 'lxu' )
o00O0O = 'aHR0cDovL2JpdC5seS8yV1Bj' . decode ( 'base64' ) + iIIii
if 20 - 20: OoOoOO00 - IIII
if 30 - 30: ooOoO0o / I1ii11iIi11i
def Iii1I1111ii ( ) :
 if 72 - 72: o0oOOo0O0Ooo + OoOoOO00 + Ii1I
 if 94 - 94: IiII . OoOoOO00 - Ii1I % I1IiiI - OOooOOo
 try :
  if 72 - 72: o00O0oo
  II11Ii1iI1iII = Oo0o00OO0000 ( OOO00O0O )
  I1i = re . compile ( II1I ) . findall ( II11Ii1iI1iII )
  for O00Oooo in I1i :
   try :
    if 46 - 46: ooOoO0o / o00O0oo
    oOooOOOoOo = O00Oooo
    if 57 - 57: IIIIII11i1I / i1I1i1Ii11 * I1IiiI - OoO0O00 % Oo0Ooo
    ii11i = xbmc . Keyboard ( '' , 'Busqueda por titulo,actor, director, año, servidor:' )
    ii11i . doModal ( )
    if ( ii11i . isConfirmed ( ) ) :
     if 73 - 73: I1Ii111
     ooO = urllib . quote_plus ( ii11i . getText ( ) ) . replace ( '+' , ' ' )
     Ooo0oOooo0 = Oo0o00OO0000 ( oOooOOOoOo )
     I1i = re . compile ( O0OOO ) . findall ( Ooo0oOooo0 )
     if 61 - 61: I11i - I1Ii111 - OoOoOO00
     for IiI1iIiIIIii , oOoO , oOoO00O0 , id , OOIi1iI111II1I1 in I1i :
      if re . search ( ooO , oOOOOoOO0o ( oOoO . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       i1II1 ( oOoO , oOoO00O0 , IiI1iIiIIIii , id , OOIi1iI111II1I1 )
       if 25 - 25: o0o0OOO0o0 / Oo0Ooo % i1I1i1Ii11
   except :
    pass
 except :
  pass
  if 42 - 42: II111iiii * Oo0Ooo / iII111i . II111iiii % ooOoO0o
def i1iI ( ) :
 if 29 - 29: I1ii11iIi11i % I1Ii111 - I1ii11iIi11i / I1Ii111 . OoOoOO00
 i11III1111iIi = Oo0o00OO0000 ( I1111i )
 I1i = re . compile ( oo0OOo ) . findall ( i11III1111iIi )
 for I1i111I in I1i :
  try :
   if 97 - 97: OoOoOO00 . IiII / i1I1i1Ii11 * I1IiiI
   import xbmc
   import xbmcaddon
   if 73 - 73: I1Ii111 / IiII
   __addon__ = xbmcaddon . Addon ( )
   __addonname__ = __addon__ . getAddonInfo ( 'name' )
   __icon__ = __addon__ . getAddonInfo ( 'icon' )
   if 88 - 88: ooOoO0o % iII111i
   ii = oo000 . getAddonInfo ( 'version' )
   if 48 - 48: IIII / o0o0OOO0o0 . Oo0Ooo * I11i * IiII / OoOoOO00
   OOOOoOOo0O0 = "[COLOR gold]Version instalada: " + ii + " [/COLOR]" "[COLOR lime]Ultima Version: " + I1i111I + "  [/COLOR]"
   oOooo0 = 5000
   if 58 - 58: I1ii11iIi11i . i1I1i1Ii11 + I11i
   xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , OOOOoOOo0O0 , oOooo0 , __icon__ ) )
   if 66 - 66: i1I1i1Ii11 / IiII * OoO0O00 + OoO0O00 % ooOoO0o
   if 49 - 49: IiII - II111iiii . o0o0OOO0o0 * o00O0oo % i1I1i1Ii11 + OoOoOO00
  except :
   pass
   if 71 - 71: Ii1I
   if 38 - 38: IiII % I11i + iII111i . II111iiii
def oo0000ooooO0o ( ) :
 if 40 - 40: iII111i + OoOoOO00 * I1Ii111
 if 85 - 85: o00O0oo * oO0o . I1IiiI - II111iiii
 O0oo0OO0oOOOo = oo000 . getSetting ( 'videos' )
 if O0oo0OO0oOOOo == 'true' :
  if 18 - 18: o00O0oo + IIIIII11i1I - I1IiiI
  try :
   if 53 - 53: OoOoOO00
   import urlresolver
   from urlresolver import common
   import random
   from random import choice
   Ooo00Oo = xbmc . Player ( )
   iiiIi1i1I = [ 'iHJAKUyjomI' , '_pqbkWaTGX0' , '5sSQINZQjfU' , 'hEl07wzNkaE' , 'hflGH4jKU0k' , '1qP8wVmQ1eI' ]
   oO00Oooo0O0o0 = random . choice ( iiiIi1i1I )
   oOoO00O0 = 'https://www.youtube.com/watch?v=%s' % oO00Oooo0O0o0
   oOoO00O0 = urlresolver . HostedMediaFile ( oOoO00O0 ) . resolve ( )
   Ooo00Oo . play ( oOoO00O0 )
   if 14 - 14: Ii1I % I1IiiI * i1I1i1Ii11 + o00O0oo + oO0o * o00O0oo
   O0oo0OO0oOOOo == 'false'
   if 3 - 3: I11i * oO0o
  except :
   pass
   if 95 - 95: I1Ii111 % IiII . o00O0oo
   if 72 - 72: OoO0O00
 II11Ii1iI1iII = Oo0o00OO0000 ( o0oo0oOo )
 I1i = re . compile ( I1I1IiI1 ) . findall ( II11Ii1iI1iII )
 for OooooOoooO , oOIIiIi , OOoOooOoOOOoo in I1i :
  try :
   if 25 - 25: OoO0O00 - I1ii11iIi11i . I1ii11iIi11i * IiII
   if 81 - 81: i1I1i1Ii11 + IIIIII11i1I
   o0oo0 = OooooOoooO
   oOOoO0OoOO = oOIIiIi
   O0O0Oo00 = OOoOooOoOOOoo
   if 80 - 80: IiII + I1Ii111 / ooOoO0o
   if 79 - 79: IIII
   OOOOoOOo0O0 = "[COLOR=red][B]" + o0oo0 + "[/B][/COLOR]"
   i11I1I1I = "[COLOR yellow]" + oOOoO0OoOO + "[/COLOR]"
   oOOOo00O00O = "[COLOR yellow]" + O0O0Oo00 + "[/COLOR]"
   if 2 - 2: Ii1I - iII111i
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , OOOOoOOo0O0 , i11I1I1I , oOOOo00O00O )
   if 58 - 58: o00O0oo + Ii1I - I1ii11iIi11i
  except : i1i1ii ( )
  if 46 - 46: I11i + OOooOOo
  if 70 - 70: i1I1i1Ii11 / Oo0Ooo
  if 85 - 85: OoO0O00 % OoOoOO00 * OoO0O00 / iII111i
  if 96 - 96: OoO0O00 + IiII
  if 44 - 44: IiII
 if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
  if 20 - 20: ooOoO0o + o00O0oo / I1IiiI % Oo0Ooo
  if 88 - 88: I11i / o0oOOo0O0Ooo
  if 87 - 87: iII111i - iII111i - i1I1i1Ii11 + IiII
def oOOOOoOO0o ( s ) :
 if 82 - 82: IiII / Oo0Ooo . I1ii11iIi11i . I1Ii111 / Ii1I
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 42 - 42: oO0o
def II1IIiiIiI ( file ) :
 if 1 - 1: i1I1i1Ii11
 try :
  O0O0Ooo = open ( file , 'r' )
  II11Ii1iI1iII = O0O0Ooo . read ( )
  O0O0Ooo . close ( )
  return II11Ii1iI1iII
 except :
  pass
  if 77 - 77: Ii1I / OoO0O00
def Oo0o00OO0000 ( url ) :
 if 46 - 46: Ii1I % Oo0Ooo . i1I1i1Ii11 % i1I1i1Ii11 + II111iiii
 try :
  Oo00o0OO0O00o = urllib2 . Request ( url )
  Oo00o0OO0O00o . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  O0Oooo = urllib2 . urlopen ( Oo00o0OO0O00o )
  iiIi1i = O0Oooo . read ( )
  O0Oooo . close ( )
  return iiIi1i
 except urllib2 . URLError , I1i11111i1i11 :
  print 'We failed to open "%s".' % url
  if hasattr ( I1i11111i1i11 , 'code' ) :
   print 'We failed with error code - %s.' % I1i11111i1i11 . code
  if hasattr ( I1i11111i1i11 , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , I1i11111i1i11 . reason
   if 77 - 77: iII111i + OOooOOo / IiII + I1IiiI * Ii1I
def I1ii11 ( url ) :
 Oo00o0OO0O00o = urllib2 . Request ( url )
 Oo00o0OO0O00o . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 Oo00o0OO0O00o . add_header ( 'Referer' , '%s' % url )
 Oo00o0OO0O00o . add_header ( 'Connection' , 'keep-alive' )
 O0Oooo = urllib2 . urlopen ( Oo00o0OO0O00o )
 iiIi1i = O0Oooo . read ( )
 O0Oooo . close ( )
 return iiIi1i
 if 74 - 74: oO0o - Ii1I . OoOoOO00
 if 43 - 43: i1I1i1Ii11 / I1ii11iIi11i
def OO0oo0O ( ) :
 if 13 - 13: II111iiii + OoOoOO00 * Oo0Ooo % OoO0O00 - o0oOOo0O0Ooo * I1Ii111
 o0 = oo000 . getSetting ( 'MenuColor' )
 if 26 - 26: OoO0O00 * I1ii11iIi11i + I1Ii111
 if i1i1i11IIi == 'true' :
  IiIii1i111 ( '[COLOR %s]Menu Peliculas[/COLOR] ' % o0 , 'movieDB' , 116 , ii1I1i1I , O0oOO0o0 )
  if 43 - 43: I1IiiI
  if 39 - 39: I1ii11iIi11i . Oo0Ooo * o00O0oo % IIII . Oo0Ooo
 if OO00Oo == 'true' :
  IiIii1i111 ( '[COLOR %s]Ajustes[/COLOR]' % o0 , 'Settings' , 119 , OOoo0O0 , O0oOO0o0 )
  if 54 - 54: I1Ii111
  if 45 - 45: OoO0O00 - I1Ii111 + I1IiiI * o00O0oo . iII111i
  if iii11 == 'true' :
   IiiiI ( )
   if 61 - 61: I1Ii111 % I1Ii111 * Ii1I / Ii1I
  if O0OOO0OOoO0O == 'true' :
   o0oOO ( )
   O0o0OO0000ooo ( )
   if 4 - 4: o00O0oo
  if iI1iI1I1i1I == 'false' :
   if 51 - 51: OOooOOo - I1IiiI % IiII - o0oOOo0O0Ooo
   OOOOoOOo0O0 = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   i11I1I1I = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Program.favoritos-realstream para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   oOOOo00O00O = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 31 - 31: i1I1i1Ii11 / oO0o - i1I1i1Ii11 - I1Ii111
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , OOOOoOOo0O0 , i11I1I1I , oOOOo00O00O )
   if 7 - 7: i1I1i1Ii11 % I1IiiI . I11i + I1ii11iIi11i - ooOoO0o
def o0o0O00oo0 ( ) :
 IiIii1i111 ( '[COLOR orange]Buscador por id[/COLOR]' , o000O0o , 127 , iiI1iIiI , O0oOO0o0 )
 if 27 - 27: II111iiii % o0oOOo0O0Ooo % ooOoO0o . I1IiiI - oO0o + I11i
def i1i1ii ( ) :
 if 57 - 57: Oo0Ooo / ooOoO0o - OoOoOO00
 o0 = oo000 . getSetting ( 'MenuColor' )
 IiIii1i111 ( '[COLOR %s]The movie DB[/COLOR]' % o0 , 'movieDB' , 99 , iiI1iIiI , O0oOO0o0 )
 IiIii1i111 ( '[COLOR %s]Buscador por id[/COLOR]' % o0 , o000O0o , 127 , iiI1iIiI , O0oOO0o0 )
 IiIii1i111 ( '[COLOR %s]Video tutoriales[/COLOR]' % o0 , o000O0o , 125 , o00O , O0oOO0o0 )
 if 51 - 51: IIIIII11i1I
 if 25 - 25: OoO0O00 + IIIIII11i1I * iII111i
 if 92 - 92: I1ii11iIi11i + ooOoO0o + I1IiiI / Ii1I + o0o0OOO0o0
 if 18 - 18: IIII * I11i . i1I1i1Ii11 / iII111i / II111iiii
 if 21 - 21: IiII / iII111i + o00O0oo + OoO0O00
 if 91 - 91: II111iiii / OoOoOO00 + i1I1i1Ii11 + IIII * II111iiii
 IiIii1i111 ( '[COLOR %s]Autorizar OPENLOAD[/COLOR]' % o0 , 'movieDB' , 97 , II1Ii1iI1i , O0oOO0o0 )
 if 66 - 66: Oo0Ooo % OoOoOO00 - I1IiiI + ooOoO0o * o0o0OOO0o0 . IIIIII11i1I
 IiIii1i111 ( '[COLOR %s]listado Proxy[/COLOR]' % o0 , 'movieDB' , 112 , OOO0OOO00oo , O0oOO0o0 )
 OO0oo0O ( )
 if 52 - 52: IIII + I1IiiI . i1I1i1Ii11 . iII111i . OOooOOo
 if 97 - 97: I1ii11iIi11i / i1I1i1Ii11
 if 71 - 71: o0oOOo0O0Ooo / OoOoOO00 . iII111i % OoO0O00 . I11i
 if 41 - 41: OoOoOO00 * o0oOOo0O0Ooo / OoO0O00 . I1Ii111
 if 83 - 83: i1I1i1Ii11 . I1IiiI / oO0o / I1Ii111 - o0oOOo0O0Ooo
 if 100 - 100: OOooOOo
 if 46 - 46: I11i / Oo0Ooo % i1I1i1Ii11 . Oo0Ooo * i1I1i1Ii11
 if 38 - 38: iII111i - i1I1i1Ii11 / I1IiiI . o0o0OOO0o0
 if 45 - 45: o0o0OOO0o0
 if 83 - 83: I11i . OoO0O00
 if 58 - 58: II111iiii + OoO0O00 % OoO0O00 / IIIIII11i1I / II111iiii
def oOOoo ( ) :
 iII1111III1I = xbmcgui . Dialog ( )
 ii11iO00oOo00o0o = (
 O00oO0 ,
 O0Oo00OoOo ,
 )
 if 24 - 24: II111iiii - o0o0OOO0o0
 i11iiI1111 = iII1111III1I . select ( '[B][COLOR=yellow]Listado de Proxys Gratuitos:[/COLOR][/B]' , [
 '[COLOR=orange]                      Accede a la web[/COLOR]' ,

 '[B][COLOR=gold]                      Volver al Menu [/COLOR][/B]' , ] )
 if 97 - 97: oO0o * I1ii11iIi11i . Oo0Ooo
 if i11iiI1111 :
  if 16 - 16: IIII % OoO0O00 - I1Ii111 * o00O0oo * iII111i / OoO0O00
  if i11iiI1111 < 0 :
   return
  I11o0oO00oO0o0o0 = ii11iO00oOo00o0o [ i11iiI1111 - 2 ]
  return I11o0oO00oO0o0o0 ( )
 else :
  I11o0oO00oO0o0o0 = ii11iO00oOo00o0o [ i11iiI1111 ]
  return I11o0oO00oO0o0o0 ( )
 return
 if 17 - 17: ooOoO0o . IIIIII11i1I - o0oOOo0O0Ooo + I1IiiI / Oo0Ooo / II111iiii
def I1IIIiI1I1ii1 ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 30 - 30: I1IiiI * OoO0O00
I1iIIIi1 = I1IIIiI1I1ii1 ( )
if 17 - 17: Oo0Ooo . OoO0O00 / ooOoO0o % o0oOOo0O0Ooo % OoOoOO00 / II111iiii
def O00oO0 ( ) :
 if I1iIIIi1 == 'android' :
  OOOIiiiii1iI = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://hidemyna.me/es/proxy-list/?country=ES&type=hs#list' ) )
  if 49 - 49: Ii1I . IIIIII11i1I / OOooOOo + o0oOOo0O0Ooo
 else :
  OOOIiiiii1iI = webbrowser . open ( 'https://hidemyna.me/es/proxy-list/?country=ES&type=hs#list' )
  if 47 - 47: I1IiiI / o00O0oo
  if 67 - 67: I1ii11iIi11i
def O0Oo00OoOo ( ) :
 if 55 - 55: iII111i - i1I1i1Ii11 * Ii1I + I11i * I11i * I1IiiI
 main ( )
 if 91 - 91: o0o0OOO0o0 - I1Ii111 % Oo0Ooo - OoO0O00 % IIII
 if 98 - 98: OOooOOo . OOooOOo * IiII * o0oOOo0O0Ooo * o0o0OOO0o0
 if 92 - 92: oO0o
 if 40 - 40: I11i / IIIIII11i1I
 if 79 - 79: OOooOOo - Oo0Ooo + o00O0oo - o0o0OOO0o0
def OoO ( ) :
 if 35 - 35: I11i + II111iiii - o0oOOo0O0Ooo
 if xbmc . getCondVisibility ( 'System.HasAddon(plugin.program.favoritos-realstream)' ) :
  if 15 - 15: II111iiii % I1ii11iIi11i * ooOoO0o / o0o0OOO0o0
  xbmc . executebuiltin ( 'RunAddon(plugin.program.favoritos-realstream)' )
  if 90 - 90: i1I1i1Ii11
  if II1III == 'true' :
   if 31 - 31: I1Ii111 + I1IiiI
   xbmcgui . Dialog ( ) . ok ( "[COLOR orange]Real Stream Agradecimientos[/COLOR]" , "[COLOR gold]Netai quiere agradecer el genial trabajo de [/COLOR][COLOR lime][B]Spoyser[/B][/COLOR][COLOR gold] Autor de este genial script que originalmente se conoce como:[/COLOR]" , "[COLOR lime][B]Program.super.favorites[/B][/COLOR]" , "Usted puede descargar el script original desde el repositorio de Kodi >Addons de programas> program.super.favorites" )
   if 87 - 87: IIII
  oo000 . setSetting ( 'Favoritos-anuncio' , 'false' )
 else :
  if 45 - 45: OOooOOo / OoO0O00 - i1I1i1Ii11 / o00O0oo % IIIIII11i1I
  xbmcgui . Dialog ( ) . ok ( "El programa Real stream Favoritos No esta instalado" , "[COLOR green]Necesario AddOn externo para agregar tus peliculas a favoritas dentro del addon.[/COLOR]" , "[COLOR yellow]Puedes agregarlo desde http://netai.eu/netai/ agregando la fuente a tu Kodi, instalar desde archivo zip.[/COLOR]" )
  if 83 - 83: I1ii11iIi11i . Oo0Ooo - IIIIII11i1I * II111iiii
def IiI11i1IIiiI ( ) :
 oo000 . openSettings ( )
 if 60 - 60: iII111i * I1ii11iIi11i
 if 17 - 17: I1Ii111 % oO0o / iII111i . IIIIII11i1I * I1Ii111 - o0oOOo0O0Ooo
def i1i1IIii1i1 ( ) :
 urlresolver . display_settings ( )
 if 65 - 65: I1ii11iIi11i + I11i / I1Ii111
def o0oOO ( ) :
 IiIii1i111 ( '[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % o0 , 'resolve' , 120 , OoOo , O0oOO0o0 )
 if 83 - 83: Ii1I . i1I1i1Ii11 - oO0o
def Ooo0O ( ) :
 if 87 - 87: IIIIII11i1I % o0oOOo0O0Ooo
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 15 - 15: i1I1i1Ii11 * IiII % I1Ii111 - I1Ii111 % IIII
def O0o0OO0000ooo ( ) :
 IiIii1i111 ( '[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % o0 , 'resolve' , 140 , OoOo , O0oOO0o0 )
 if 26 - 26: II111iiii + iII111i % OoO0O00
def IiiiI ( ) :
 if 73 - 73: o00O0oo - o0o0OOO0o0
 o0 = oo000 . getSetting ( 'MenuColor' )
 IiIii1i111 ( '[COLOR %s]Buscador[/COLOR]' % o0 , 'search' , 111 , i111I , O0oOO0o0 )
 IiIii1i111 ( '[COLOR %s]Estrenos[/COLOR]' % o0 , o000O0o , 3 , Ii1IIii11 , O0oOO0o0 )
 IiIii1i111 ( '[COLOR %s]Todas[/COLOR]' % o0 , o000O0o , 26 , Oooo0000 , O0oOO0o0 )
 IiIii1i111 ( '[COLOR %s]4K[/COLOR]' % o0 , o000O0o , 141 , II11iiii1Ii , O0oOO0o0 )
 IiIii1i111 ( '[COLOR %s]Novedades[/COLOR]' % o0 , o000O0o , 2 , OOo , O0oOO0o0 )
 IiIii1i111 ( '[COLOR %s]Accion[/COLOR]' % o0 , o000O0o , 5 , i11 , O0oOO0o0 )
 IiIii1i111 ( '[COLOR %s]Animacion[/COLOR]' % o0 , o000O0o , 6 , I11 , O0oOO0o0 )
 IiIii1i111 ( '[COLOR %s]Aventuras[/COLOR]' % o0 , o000O0o , 7 , Oo0o0000o0o0 , O0oOO0o0 )
 IiIii1i111 ( '[COLOR %s]Belico[/COLOR]' % o0 , o000O0o , 8 , oOo0oooo00o , O0oOO0o0 )
 IiIii1i111 ( '[COLOR %s]Ciencia Ficcion[/COLOR]' % o0 , o000O0o , 9 , oO0o0o0ooO0oO , O0oOO0o0 )
 IiIii1i111 ( '[COLOR %s]Comedia[/COLOR]' % o0 , o000O0o , 10 , oo0o0O00 , O0oOO0o0 )
 IiIii1i111 ( '[COLOR %s]Crimen[/COLOR]' % o0 , o000O0o , 11 , oO , O0oOO0o0 )
 IiIii1i111 ( '[COLOR %s]Drama[/COLOR]' % o0 , o000O0o , 12 , i1iiIIiiI111 , O0oOO0o0 )
 IiIii1i111 ( '[COLOR %s]Familiar[/COLOR]' % o0 , o000O0o , 13 , oooOOOOO , O0oOO0o0 )
 IiIii1i111 ( '[COLOR %s]Fantasia[/COLOR]' % o0 , o000O0o , 14 , i1iiIII111ii , O0oOO0o0 )
 IiIii1i111 ( '[COLOR %s]Historia[/COLOR]' % o0 , o000O0o , 15 , i1iIIi1 , O0oOO0o0 )
 IiIii1i111 ( '[COLOR %s]Misterio[/COLOR]' % o0 , o000O0o , 16 , iI111I11I1I1 , O0oOO0o0 )
 IiIii1i111 ( '[COLOR %s]Musical[/COLOR]' % o0 , o000O0o , 17 , OOooO0OOoo , O0oOO0o0 )
 IiIii1i111 ( '[COLOR %s]Romance[/COLOR]' % o0 , o000O0o , 18 , iIii1 , O0oOO0o0 )
 IiIii1i111 ( '[COLOR %s]Thriller[/COLOR]' % o0 , o000O0o , 19 , II , O0oOO0o0 )
 IiIii1i111 ( '[COLOR %s]Suspense[/COLOR]' % o0 , o000O0o , 20 , O0OoO000O0OO , O0oOO0o0 )
 IiIii1i111 ( '[COLOR %s]Terror[/COLOR]' % o0 , o000O0o , 21 , iiI1IiI , O0oOO0o0 )
 IiIii1i111 ( '[COLOR %s]Western[/COLOR]' % o0 , o000O0o , 22 , ooOoOoo0O , O0oOO0o0 )
 IiIii1i111 ( '[COLOR %s]Spain[/COLOR]' % o0 , o000O0o , 23 , oOOoO0 , O0oOO0o0 )
 IiIii1i111 ( '[COLOR %s]Super heroes[/COLOR]' % o0 , o000O0o , 24 , ii11iIi1I , O0oOO0o0 )
 IiIii1i111 ( '[COLOR %s]Sagas[/COLOR]' % o0 , o000O0o , 25 , OooO0 , O0oOO0o0 )
 if 68 - 68: i1I1i1Ii11 * OoO0O00 * Oo0Ooo . o0oOOo0O0Ooo
 if 81 - 81: I1Ii111 / I1IiiI + ooOoO0o + o00O0oo / I1ii11iIi11i
 if 27 - 27: I11i * IIIIII11i1I
def O0Ooo0oo ( ) :
 if 41 - 41: I11i * ooOoO0o / I11i % IiII
 if 18 - 18: o0oOOo0O0Ooo . OoO0O00 % I11i % o00O0oo
 II1IiiIii = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 II1IiiIii . doModal ( )
 if not II1IiiIii . isConfirmed ( ) :
  return None ;
 oOoO = II1IiiIii . getText ( ) . strip ( )
 if 84 - 84: IiII % OoOoOO00
 if 70 - 70: oO0o . OoO0O00 - i1I1i1Ii11
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 30 - 30: iII111i % I1ii11iIi11i
  OOOIiiiii1iI = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + oOoO + '&language=es-ES' ) )
  if 89 - 89: o0o0OOO0o0 + OoO0O00 + o0o0OOO0o0 * OoOoOO00 + Oo0Ooo % ooOoO0o
  if 59 - 59: I1Ii111 + II111iiii
  return 'android'
  if 88 - 88: II111iiii - IIII
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 67 - 67: I1Ii111 . oO0o + I11i - OoO0O00
  OOOIiiiii1iI = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + oOoO + '&language=es-ES' )
  if 70 - 70: I1Ii111 / o0oOOo0O0Ooo - Oo0Ooo - i1I1i1Ii11
  if 11 - 11: Oo0Ooo . OoO0O00 . o0oOOo0O0Ooo / OoOoOO00 - ooOoO0o
  return 'windows'
  if 30 - 30: I11i
  if 21 - 21: II111iiii / o0o0OOO0o0 % I1Ii111 * I1IiiI . ooOoO0o - Oo0Ooo
def iiIiiii1i1i1i ( ) :
 if 86 - 86: oO0o / IiII + I1IiiI * i1I1i1Ii11
 try :
  if 19 - 19: o0oOOo0O0Ooo * IIIIII11i1I + o00O0oo
  II11Ii1iI1iII = Oo0o00OO0000 ( OOO00O0O )
  I1i = re . compile ( II1I ) . findall ( II11Ii1iI1iII )
  for O00Oooo in I1i :
   if 65 - 65: I1Ii111 . o0o0OOO0o0 . OOooOOo . i1I1i1Ii11 - I1Ii111
   try :
    if 19 - 19: II111iiii + i1I1i1Ii11 % IIII
    all = O00Oooo
    if 14 - 14: OOooOOo . o0oOOo0O0Ooo . ooOoO0o / o00O0oo % iII111i - IIII
   except :
    pass
    if 67 - 67: ooOoO0o - I1Ii111 . OoOoOO00
  Ooo0oOooo0 = Oo0o00OO0000 ( all )
  I1i = re . compile ( O0OOO ) . findall ( Ooo0oOooo0 )
  for IiI1iIiIIIii , oOoO , oOoO00O0 , id , OOIi1iI111II1I1 in I1i :
   try :
    if 35 - 35: i1I1i1Ii11 + IIII - IiII . i1I1i1Ii11 . IIIIII11i1I
    i1II1 ( oOoO , oOoO00O0 , IiI1iIiIIIii , id , OOIi1iI111II1I1 )
    if 87 - 87: I11i
   except :
    pass
 except :
  pass
  if 25 - 25: OoOoOO00 . OOooOOo - I11i / OOooOOo % OOooOOo * Oo0Ooo
def III ( ) :
 if 1 - 1: IiII
 try :
  if 62 - 62: OoOoOO00 - I1Ii111
  OOo = Oo0o00OO0000 ( oOooOOOoOo )
  I1i = re . compile ( II1I ) . findall ( OOo )
  for O00Oooo in I1i :
   if 96 - 96: OoOoOO00 . iII111i + IiII
   try :
    if 48 - 48: Oo0Ooo % OoOoOO00 % i1I1i1Ii11 + IIII
    Iiii11iIi1 = O00Oooo
    if 40 - 40: ooOoO0o % OOooOOo . o0o0OOO0o0
   except :
    pass
    if 84 - 84: I11i % IIII - I11i . Ii1I
  i11III1111iIi = Oo0o00OO0000 ( Iiii11iIi1 )
  I1i = re . compile ( O0OOO ) . findall ( i11III1111iIi )
  for IiI1iIiIIIii , oOoO , oOoO00O0 , id , OOIi1iI111II1I1 in I1i :
   try :
    if 5 - 5: I11i * o0o0OOO0o0 - iII111i / Oo0Ooo % IiII + IIIIII11i1I
    i1II1 ( oOoO , oOoO00O0 , IiI1iIiIIIii , id , OOIi1iI111II1I1 )
    if 51 - 51: o0o0OOO0o0 * o0oOOo0O0Ooo % IIII
   except :
    pass
 except :
  pass
  if 98 - 98: OOooOOo . ooOoO0o % o0oOOo0O0Ooo
def O0OoOoO00O ( ) :
 if 96 - 96: I1ii11iIi11i % oO0o . iII111i + I1Ii111
 try :
  if 42 - 42: o0oOOo0O0Ooo * i1I1i1Ii11 * II111iiii - I1Ii111 . OoO0O00
  Ii1IIii11 = Oo0o00OO0000 ( OOoO00 )
  I1i = re . compile ( II1I ) . findall ( Ii1IIii11 )
  for O00Oooo in I1i :
   if 76 - 76: o0oOOo0O0Ooo
   try :
    Ii1i1i1111 = O00Oooo
   except :
    pass
    if 57 - 57: o00O0oo % o0oOOo0O0Ooo
  II11Ii1iI1iII = Oo0o00OO0000 ( Ii1i1i1111 )
  I1i = re . compile ( O0OOO ) . findall ( II11Ii1iI1iII )
  for IiI1iIiIIIii , oOoO , oOoO00O0 , id , OOIi1iI111II1I1 in I1i :
   try :
    i1II1 ( oOoO , oOoO00O0 , IiI1iIiIIIii , id , OOIi1iI111II1I1 )
    if 67 - 67: IIII + I1ii11iIi11i * II111iiii - IiII / IIIIII11i1I % i1I1i1Ii11
   except :
    pass
 except :
  pass
  if 92 - 92: o00O0oo - IiII - IIII % OoO0O00 / I1Ii111
def iIIIiIii ( ) :
 if 71 - 71: OoO0O00
 try :
  if 33 - 33: o0o0OOO0o0
  II11Ii1iI1iII = Oo0o00OO0000 ( db2 )
  I1i = re . compile ( II1I ) . findall ( II11Ii1iI1iII )
  for O00Oooo in I1i :
   if 62 - 62: iII111i + o00O0oo + OoOoOO00 / OoO0O00
   try :
    if 7 - 7: Ii1I + OoOoOO00 . I1ii11iIi11i / oO0o
    I111i1I1 = O00Oooo
    if 62 - 62: I1Ii111 * o0o0OOO0o0 / oO0o * Ii1I
   except :
    pass
    if 29 - 29: oO0o % OOooOOo % IIIIII11i1I . Ii1I / OoO0O00 * IIII
    if 54 - 54: I1IiiI
  II11Ii1iI1iII = Oo0o00OO0000 ( I111i1I1 )
  I1i = re . compile ( O0OOO ) . findall ( II11Ii1iI1iII )
  for IiI1iIiIIIii , oOoO , oOoO00O0 , id , OOIi1iI111II1I1 in I1i :
   try :
    i1II1 ( oOoO , oOoO00O0 , IiI1iIiIIIii , id , OOIi1iI111II1I1 )
    if 68 - 68: OOooOOo * Ii1I . IIII % IiII % o0o0OOO0o0
   except :
    pass
 except :
  pass
  if 75 - 75: I11i
def i1 ( ) :
 if 56 - 56: o0oOOo0O0Ooo / IiII + II111iiii + I1Ii111
 try :
  if 54 - 54: o00O0oo - ooOoO0o - o0o0OOO0o0 . Oo0Ooo
  II11Ii1iI1iII = Oo0o00OO0000 ( i1Ii )
  I1i = re . compile ( II1I ) . findall ( II11Ii1iI1iII )
  for O00Oooo in I1i :
   if 79 - 79: o00O0oo . OOooOOo
   try :
    if 40 - 40: Ii1I + oO0o . Ii1I % IIII
    I11I1IIiiII1 = O00Oooo
    if 31 - 31: I1ii11iIi11i * IiII + OoO0O00 - i1I1i1Ii11 / OoO0O00
   except :
    pass
    if 19 - 19: IIIIII11i1I * IIII * Ii1I + I1IiiI / I1IiiI
    if 73 - 73: Oo0Ooo / Oo0Ooo - IiII
  II11Ii1iI1iII = Oo0o00OO0000 ( I11I1IIiiII1 )
  I1i = re . compile ( O0OOO ) . findall ( II11Ii1iI1iII )
  for IiI1iIiIIIii , oOoO , oOoO00O0 , id , OOIi1iI111II1I1 in I1i :
   try :
    i1II1 ( oOoO , oOoO00O0 , IiI1iIiIIIii , id , OOIi1iI111II1I1 )
    if 91 - 91: IiII + I1ii11iIi11i
   except :
    pass
 except :
  pass
  if 59 - 59: I1ii11iIi11i + II111iiii + OoOoOO00 / ooOoO0o
def I11iIiI1 ( ) :
 if 86 - 86: Ii1I
 try :
  if 27 - 27: I1IiiI . Ii1I . iII111i . iII111i + iII111i * Ii1I
  II11Ii1iI1iII = Oo0o00OO0000 ( OOO )
  I1i = re . compile ( II1I ) . findall ( II11Ii1iI1iII )
  for O00Oooo in I1i :
   if 100 - 100: oO0o % o00O0oo / ooOoO0o
   try :
    if 30 - 30: oO0o - I1Ii111 - i1I1i1Ii11
    OOOI11IIiIiI = O00Oooo
    if 5 - 5: oO0o * I11i
   except :
    pass
    if 46 - 46: IIII
  II11Ii1iI1iII = Oo0o00OO0000 ( OOOI11IIiIiI )
  I1i = re . compile ( O0OOO ) . findall ( II11Ii1iI1iII )
  for IiI1iIiIIIii , oOoO , oOoO00O0 , id , OOIi1iI111II1I1 in I1i :
   try :
    i1II1 ( oOoO , oOoO00O0 , IiI1iIiIIIii , id , OOIi1iI111II1I1 )
    if 33 - 33: i1I1i1Ii11 - o0oOOo0O0Ooo * OoO0O00 - oO0o - I1Ii111
   except :
    pass
 except :
  pass
  if 84 - 84: o0o0OOO0o0 + oO0o - I11i * I11i
def Ooo ( ) :
 if 65 - 65: oO0o / ooOoO0o
 try :
  if 12 - 12: ooOoO0o % I11i
  II11Ii1iI1iII = Oo0o00OO0000 ( I11IiI )
  I1i = re . compile ( II1I ) . findall ( II11Ii1iI1iII )
  for O00Oooo in I1i :
   if 48 - 48: i1I1i1Ii11 . II111iiii
   try :
    if 5 - 5: IiII . iII111i . o0oOOo0O0Ooo . OoO0O00
    Oo0OooO0 = O00Oooo
    if 87 - 87: IiII % o00O0oo
   except :
    pass
    if 83 - 83: o0oOOo0O0Ooo - ooOoO0o
    if 35 - 35: OoOoOO00 - Oo0Ooo + OoOoOO00
  II11Ii1iI1iII = Oo0o00OO0000 ( Oo0OooO0 )
  I1i = re . compile ( O0OOO ) . findall ( II11Ii1iI1iII )
  for IiI1iIiIIIii , oOoO , oOoO00O0 , id , OOIi1iI111II1I1 in I1i :
   try :
    i1II1 ( oOoO , oOoO00O0 , IiI1iIiIIIii , id , OOIi1iI111II1I1 )
    if 86 - 86: Oo0Ooo + I11i . II111iiii - o00O0oo
   except :
    pass
 except :
  pass
  if 51 - 51: I11i
def I11IIIiIi11 ( ) :
 if 39 - 39: o00O0oo % I1IiiI % I11i . OoOoOO00
 try :
  if 86 - 86: OOooOOo * OoO0O00
  II11Ii1iI1iII = Oo0o00OO0000 ( ooO0oOOooOo0 )
  I1i = re . compile ( II1I ) . findall ( II11Ii1iI1iII )
  for O00Oooo in I1i :
   if 71 - 71: Oo0Ooo - I1Ii111 . I1ii11iIi11i % OoO0O00 + I1Ii111
   try :
    if 26 - 26: oO0o + I1Ii111 / OOooOOo % I11i % iII111i + o0oOOo0O0Ooo
    i11I1I1iiI = O00Oooo
    if 34 - 34: ooOoO0o % IIII . I1IiiI . Oo0Ooo
   except :
    pass
    if 93 - 93: OoOoOO00 . II111iiii . oO0o
    if 99 - 99: ooOoO0o - o0o0OOO0o0 - IiII % OOooOOo
  II11Ii1iI1iII = Oo0o00OO0000 ( i11I1I1iiI )
  I1i = re . compile ( O0OOO ) . findall ( II11Ii1iI1iII )
  for IiI1iIiIIIii , oOoO , oOoO00O0 , id , OOIi1iI111II1I1 in I1i :
   try :
    i1II1 ( oOoO , oOoO00O0 , IiI1iIiIIIii , id , OOIi1iI111II1I1 )
    if 21 - 21: o0oOOo0O0Ooo % iII111i . OoOoOO00 - OoO0O00
   except :
    pass
 except :
  pass
  if 4 - 4: OoO0O00 . IIII
def oOO0oo ( ) :
 if 29 - 29: I1ii11iIi11i * o0oOOo0O0Ooo * OoO0O00 - iII111i * o0oOOo0O0Ooo
 try :
  if 41 - 41: I1IiiI
  II11Ii1iI1iII = Oo0o00OO0000 ( I1IiiiiI )
  I1i = re . compile ( II1I ) . findall ( II11Ii1iI1iII )
  for O00Oooo in I1i :
   if 30 - 30: IIII % i1I1i1Ii11 * I1Ii111 - iII111i * o00O0oo % IIII
   try :
    if 46 - 46: II111iiii - I1IiiI . IiII
    Oo0O = O00Oooo
    if 1 - 1: I1IiiI / i1I1i1Ii11 % o0o0OOO0o0 . oO0o + IIIIII11i1I
   except :
    pass
    if 27 - 27: o0o0OOO0o0 % OoO0O00 + IIIIII11i1I % OoOoOO00 / IiII / OoO0O00
    if 11 - 11: I1Ii111 % o00O0oo - II111iiii - IiII + IIII + IIIIII11i1I
  II11Ii1iI1iII = Oo0o00OO0000 ( Oo0O )
  I1i = re . compile ( O0OOO ) . findall ( II11Ii1iI1iII )
  for IiI1iIiIIIii , oOoO , oOoO00O0 , id , OOIi1iI111II1I1 in I1i :
   try :
    i1II1 ( oOoO , oOoO00O0 , IiI1iIiIIIii , id , OOIi1iI111II1I1 )
    if 87 - 87: o0o0OOO0o0 * OoOoOO00 / iII111i
   except :
    pass
 except :
  pass
  if 6 - 6: Ii1I + oO0o - OoO0O00 % I1Ii111 * I11i
  if 69 - 69: OoOoOO00
def ooOoOOOOo ( ) :
 if 71 - 71: o0oOOo0O0Ooo * Oo0Ooo / iII111i
 try :
  if 23 - 23: o0oOOo0O0Ooo
  II11Ii1iI1iII = Oo0o00OO0000 ( ii1iII1II )
  I1i = re . compile ( II1I ) . findall ( II11Ii1iI1iII )
  for O00Oooo in I1i :
   if 24 - 24: Oo0Ooo + Oo0Ooo * i1I1i1Ii11
   try :
    if 18 - 18: i1I1i1Ii11 * ooOoO0o - o00O0oo
    II1i1III = O00Oooo
    if 34 - 34: o0o0OOO0o0 - II111iiii / Oo0Ooo
   except :
    pass
    if 87 - 87: iII111i / OoO0O00 - oO0o % I11i % IIIIII11i1I % oO0o
    if 29 - 29: OoO0O00 . I1ii11iIi11i % iII111i - i1I1i1Ii11
  II11Ii1iI1iII = Oo0o00OO0000 ( II1i1III )
  I1i = re . compile ( O0OOO ) . findall ( II11Ii1iI1iII )
  for IiI1iIiIIIii , oOoO , oOoO00O0 , id , OOIi1iI111II1I1 in I1i :
   try :
    i1II1 ( oOoO , oOoO00O0 , IiI1iIiIIIii , id , OOIi1iI111II1I1 )
    if 8 - 8: OoOoOO00
   except :
    pass
 except :
  pass
  if 32 - 32: IiII / o0oOOo0O0Ooo
  if 45 - 45: iII111i + OOooOOo * II111iiii / I1Ii111 % ooOoO0o * I1IiiI
def i1o0oooO ( ) :
 if 89 - 89: o0oOOo0O0Ooo / IiII
 try :
  if 14 - 14: I1Ii111 . I1ii11iIi11i * IIII + o0oOOo0O0Ooo - IIII + I1Ii111
  II11Ii1iI1iII = Oo0o00OO0000 ( I1I1i1I )
  I1i = re . compile ( II1I ) . findall ( II11Ii1iI1iII )
  for O00Oooo in I1i :
   if 18 - 18: IiII - Ii1I - I1ii11iIi11i - I1ii11iIi11i
   try :
    if 54 - 54: oO0o + I1ii11iIi11i / i1I1i1Ii11 . I1ii11iIi11i * I11i
    IIiIiiiIIIIi1 = O00Oooo
    if 39 - 39: OOooOOo / o00O0oo / o0o0OOO0o0
   except :
    pass
    if 81 - 81: ooOoO0o / OOooOOo % OoO0O00 * IiII / IiII
    if 28 - 28: II111iiii / Ii1I . Oo0Ooo / o0oOOo0O0Ooo
  II11Ii1iI1iII = Oo0o00OO0000 ( IIiIiiiIIIIi1 )
  I1i = re . compile ( O0OOO ) . findall ( II11Ii1iI1iII )
  for IiI1iIiIIIii , oOoO , oOoO00O0 , id , OOIi1iI111II1I1 in I1i :
   try :
    i1II1 ( oOoO , oOoO00O0 , IiI1iIiIIIii , id , OOIi1iI111II1I1 )
    if 72 - 72: OoO0O00 / I1ii11iIi11i + o00O0oo / I11i * o00O0oo
   except :
    pass
    if 34 - 34: I1IiiI * I1IiiI % OoO0O00 + i1I1i1Ii11 * Oo0Ooo % o00O0oo
 except :
  pass
  if 25 - 25: ooOoO0o + I11i . Ii1I % I11i * I1Ii111
  if 32 - 32: II111iiii - o0o0OOO0o0
def oo00ooOoo ( ) :
 if 28 - 28: o00O0oo
 try :
  if 1 - 1: o00O0oo
  II11Ii1iI1iII = Oo0o00OO0000 ( O0oO0 )
  I1i = re . compile ( II1I ) . findall ( II11Ii1iI1iII )
  for O00Oooo in I1i :
   if 48 - 48: I1IiiI + I1IiiI . o0o0OOO0o0 - IIII
   try :
    if 63 - 63: IiII
    Oo0 = O00Oooo
    if 79 - 79: OOooOOo % I1Ii111 / Oo0Ooo + I11i * OOooOOo
   except :
    pass
    if 30 - 30: OoO0O00 / ooOoO0o + i1I1i1Ii11 / iII111i * I1IiiI
    if 16 - 16: oO0o / II111iiii
  II11Ii1iI1iII = Oo0o00OO0000 ( Oo0 )
  I1i = re . compile ( O0OOO ) . findall ( II11Ii1iI1iII )
  for IiI1iIiIIIii , oOoO , oOoO00O0 , id , OOIi1iI111II1I1 in I1i :
   try :
    i1II1 ( oOoO , oOoO00O0 , IiI1iIiIIIii , id , OOIi1iI111II1I1 )
    if 64 - 64: II111iiii / o00O0oo * OoOoOO00
   except :
    pass
    if 73 - 73: oO0o - I11i - IiII - I1ii11iIi11i
 except :
  pass
  if 65 - 65: Ii1I
def I1ii1II1iII ( ) :
 if 8 - 8: I11i / I1IiiI * I1IiiI % o0o0OOO0o0 - oO0o + ooOoO0o
 try :
  if 83 - 83: I1IiiI . I1ii11iIi11i
  II11Ii1iI1iII = Oo0o00OO0000 ( O0OO0O )
  I1i = re . compile ( II1I ) . findall ( II11Ii1iI1iII )
  for O00Oooo in I1i :
   if 95 - 95: ooOoO0o . OoO0O00 - OoOoOO00 - OoO0O00 - OOooOOo % Oo0Ooo
   try :
    if 64 - 64: I1Ii111 + OoO0O00 * OoO0O00
    i1I = O00Oooo
    if 36 - 36: I1ii11iIi11i * oO0o
   except :
    pass
    if 77 - 77: IiII % OoOoOO00 - o00O0oo
  II11Ii1iI1iII = Oo0o00OO0000 ( i1I )
  I1i = re . compile ( O0OOO ) . findall ( II11Ii1iI1iII )
  for IiI1iIiIIIii , oOoO , oOoO00O0 , id , OOIi1iI111II1I1 in I1i :
   try :
    i1II1 ( oOoO , oOoO00O0 , IiI1iIiIIIii , id , OOIi1iI111II1I1 )
    if 93 - 93: OOooOOo * oO0o
   except :
    pass
 except :
  pass
  if 73 - 73: Ii1I - I1ii11iIi11i * OoOoOO00 / II111iiii * I1Ii111 % o0oOOo0O0Ooo
  if 56 - 56: OoO0O00 * oO0o . oO0o . iII111i
def II1 ( ) :
 if 74 - 74: OoO0O00 % I1Ii111 % o0o0OOO0o0 - I1ii11iIi11i - ooOoO0o
 try :
  if 58 - 58: I1IiiI
  II11Ii1iI1iII = Oo0o00OO0000 ( OoOoO )
  I1i = re . compile ( II1I ) . findall ( II11Ii1iI1iII )
  for O00Oooo in I1i :
   if 78 - 78: OOooOOo % IIIIII11i1I * OoOoOO00
   try :
    if 66 - 66: o00O0oo . I1ii11iIi11i + Ii1I . Oo0Ooo
    o0iIiiIiiIi = O00Oooo
    if 40 - 40: Ii1I
   except :
    pass
    if 78 - 78: Oo0Ooo
    if 56 - 56: OoO0O00 - ooOoO0o - OoOoOO00
  II11Ii1iI1iII = Oo0o00OO0000 ( o0iIiiIiiIi )
  I1i = re . compile ( O0OOO ) . findall ( II11Ii1iI1iII )
  for IiI1iIiIIIii , oOoO , oOoO00O0 , id , OOIi1iI111II1I1 in I1i :
   try :
    i1II1 ( oOoO , oOoO00O0 , IiI1iIiIIIii , id , OOIi1iI111II1I1 )
    if 8 - 8: o0o0OOO0o0 / I1Ii111 . I1ii11iIi11i + iII111i / II111iiii
   except :
    pass
 except :
  pass
  if 31 - 31: IIII - Oo0Ooo + i1I1i1Ii11 . oO0o / IIIIII11i1I % Oo0Ooo
  if 6 - 6: IIIIII11i1I * II111iiii % Oo0Ooo % II111iiii + Ii1I / OoOoOO00
def o0o0oOO ( ) :
 if 5 - 5: o00O0oo / IiII
 try :
  if 6 - 6: oO0o . IIIIII11i1I / IIIIII11i1I - II111iiii
  II11Ii1iI1iII = Oo0o00OO0000 ( OOI1iI1ii1II )
  I1i = re . compile ( II1I ) . findall ( II11Ii1iI1iII )
  for O00Oooo in I1i :
   if 87 - 87: oO0o / I1IiiI * IIIIII11i1I / Ii1I
   try :
    if 19 - 19: o0o0OOO0o0 + OoOoOO00 . I1ii11iIi11i - oO0o
    iIi1I1 = O00Oooo
    if 63 - 63: i1I1i1Ii11 * iII111i . OoO0O00 / I1Ii111 * oO0o . IIII
   except :
    pass
  II11Ii1iI1iII = Oo0o00OO0000 ( iIi1I1 )
  I1i = re . compile ( O0OOO ) . findall ( II11Ii1iI1iII )
  for IiI1iIiIIIii , oOoO , oOoO00O0 , id , OOIi1iI111II1I1 in I1i :
   try :
    i1II1 ( oOoO , oOoO00O0 , IiI1iIiIIIii , id , OOIi1iI111II1I1 )
    if 62 - 62: OoOoOO00 / IIII . I1ii11iIi11i * Ii1I
   except :
    pass
 except :
  pass
  if 21 - 21: Ii1I
def O0Oo0 ( ) :
 if 98 - 98: o0o0OOO0o0
 try :
  if 92 - 92: o0o0OOO0o0 - Oo0Ooo
  II11Ii1iI1iII = Oo0o00OO0000 ( oOooO0 )
  I1i = re . compile ( II1I ) . findall ( II11Ii1iI1iII )
  for O00Oooo in I1i :
   if 32 - 32: o00O0oo % OOooOOo * OOooOOo + IIIIII11i1I * o0oOOo0O0Ooo * o00O0oo
   try :
    if 11 - 11: IiII % o0oOOo0O0Ooo
    o0O0 = O00Oooo
    if 48 - 48: ooOoO0o - IIIIII11i1I + Oo0Ooo + OoO0O00
   except :
    pass
    if 4 - 4: o0oOOo0O0Ooo . ooOoO0o + o00O0oo * o0o0OOO0o0 . IIII
    if 87 - 87: I11i / OOooOOo / II111iiii
  II11Ii1iI1iII = Oo0o00OO0000 ( o0O0 )
  I1i = re . compile ( O0OOO ) . findall ( II11Ii1iI1iII )
  for IiI1iIiIIIii , oOoO , oOoO00O0 , id , OOIi1iI111II1I1 in I1i :
   try :
    i1II1 ( oOoO , oOoO00O0 , IiI1iIiIIIii , id , OOIi1iI111II1I1 )
    if 74 - 74: IiII / iII111i % Ii1I
   except :
    pass
 except :
  pass
  if 88 - 88: I11i - II111iiii % Ii1I * ooOoO0o + iII111i
  if 52 - 52: o0oOOo0O0Ooo . I1ii11iIi11i + I11i % OOooOOo
def oo0O0o00 ( ) :
 if 70 - 70: OOooOOo
 try :
  if 46 - 46: ooOoO0o - OoOoOO00
  II11Ii1iI1iII = Oo0o00OO0000 ( OOoO0 )
  I1i = re . compile ( II1I ) . findall ( II11Ii1iI1iII )
  for O00Oooo in I1i :
   if 46 - 46: o0o0OOO0o0 % o00O0oo
   try :
    if 72 - 72: Oo0Ooo
    iI1I1II1 = O00Oooo
    if 92 - 92: OoO0O00 - OoO0O00 * OOooOOo % I1ii11iIi11i
   except :
    pass
    if 77 - 77: Oo0Ooo - OoOoOO00 . IiII
    if 26 - 26: Ii1I * IIIIII11i1I . OoOoOO00
  II11Ii1iI1iII = Oo0o00OO0000 ( iI1I1II1 )
  I1i = re . compile ( O0OOO ) . findall ( II11Ii1iI1iII )
  for IiI1iIiIIIii , oOoO , oOoO00O0 , id , OOIi1iI111II1I1 in I1i :
   try :
    i1II1 ( oOoO , oOoO00O0 , IiI1iIiIIIii , id , OOIi1iI111II1I1 )
    if 59 - 59: I1IiiI + OoOoOO00 - Ii1I
   except :
    pass
 except :
  pass
  if 62 - 62: II111iiii % I1Ii111 . IIIIII11i1I . I1Ii111
def ooOo0O0O0oOO0 ( ) :
 if 10 - 10: oO0o + I1IiiI
 try :
  if 43 - 43: Oo0Ooo / o0oOOo0O0Ooo % Ii1I - I1Ii111
  II11Ii1iI1iII = Oo0o00OO0000 ( o00O0 )
  I1i = re . compile ( II1I ) . findall ( II11Ii1iI1iII )
  for O00Oooo in I1i :
   if 62 - 62: ooOoO0o
   try :
    if 63 - 63: I1Ii111 + IIII * IiII / Ii1I / oO0o * Oo0Ooo
    OOoO00ooO = O00Oooo
    if 12 - 12: IIII % I1ii11iIi11i + IiII - OoOoOO00 . o00O0oo / I1ii11iIi11i
   except :
    pass
    if 51 - 51: I1Ii111 . I1ii11iIi11i
    if 73 - 73: OoO0O00 . I1ii11iIi11i / o0o0OOO0o0 % o00O0oo
  II11Ii1iI1iII = Oo0o00OO0000 ( OOoO00ooO )
  I1i = re . compile ( O0OOO ) . findall ( II11Ii1iI1iII )
  for IiI1iIiIIIii , oOoO , oOoO00O0 , id , OOIi1iI111II1I1 in I1i :
   try :
    i1II1 ( oOoO , oOoO00O0 , IiI1iIiIIIii , id , OOIi1iI111II1I1 )
    if 65 - 65: IIIIII11i1I - I1ii11iIi11i - o00O0oo
   except :
    pass
 except :
  pass
  if 42 - 42: o0oOOo0O0Ooo * I1ii11iIi11i % OoOoOO00 - o00O0oo % IIIIII11i1I
  if 36 - 36: II111iiii / IiII * iII111i * iII111i + o00O0oo * ooOoO0o
def iIiI1i ( ) :
 if 31 - 31: o00O0oo
 try :
  if 78 - 78: II111iiii + Ii1I + o0o0OOO0o0 / Ii1I % Oo0Ooo % IIIIII11i1I
  II11Ii1iI1iII = Oo0o00OO0000 ( ii1 )
  I1i = re . compile ( II1I ) . findall ( II11Ii1iI1iII )
  for O00Oooo in I1i :
   if 83 - 83: Oo0Ooo % I11i % Ii1I % o0o0OOO0o0 . iII111i % I1IiiI
   try :
    if 47 - 47: Ii1I
    oo0ooooO = O00Oooo
    if 12 - 12: o0oOOo0O0Ooo
   except :
    pass
    if 2 - 2: OoOoOO00 - I1ii11iIi11i + ooOoO0o . o0oOOo0O0Ooo
    if 25 - 25: IiII
  II11Ii1iI1iII = Oo0o00OO0000 ( oo0ooooO )
  I1i = re . compile ( O0OOO ) . findall ( II11Ii1iI1iII )
  for IiI1iIiIIIii , oOoO , oOoO00O0 , id , OOIi1iI111II1I1 in I1i :
   try :
    i1II1 ( oOoO , oOoO00O0 , IiI1iIiIIIii , id , OOIi1iI111II1I1 )
    if 34 - 34: I11i . Oo0Ooo % I1IiiI
   except :
    pass
 except :
  pass
  if 43 - 43: iII111i - i1I1i1Ii11
  if 70 - 70: i1I1i1Ii11 / I1Ii111 % IIII - o00O0oo
def i1II11Iii1I ( ) :
 if 92 - 92: I1Ii111 % IIIIII11i1I % I11i
 try :
  if 4 - 4: I11i + o00O0oo / IiII
  II11Ii1iI1iII = Oo0o00OO0000 ( O0O0ooOOO )
  I1i = re . compile ( II1I ) . findall ( II11Ii1iI1iII )
  for O00Oooo in I1i :
   if 13 - 13: i1I1i1Ii11
   try :
    if 80 - 80: o00O0oo - Ii1I
    iI1II1I1I = O00Oooo
    if 79 - 79: I1Ii111 / o0o0OOO0o0 . I11i - iII111i
   except :
    pass
    if 47 - 47: OoO0O00 % I1IiiI * i1I1i1Ii11 . o00O0oo
    if 38 - 38: I1IiiI - IIIIII11i1I % o0o0OOO0o0
  II11Ii1iI1iII = Oo0o00OO0000 ( iI1II1I1I )
  I1i = re . compile ( O0OOO ) . findall ( II11Ii1iI1iII )
  for IiI1iIiIIIii , oOoO , oOoO00O0 , id , OOIi1iI111II1I1 in I1i :
   try :
    i1II1 ( oOoO , oOoO00O0 , IiI1iIiIIIii , id , OOIi1iI111II1I1 )
    if 64 - 64: Oo0Ooo
   except :
    pass
 except :
  pass
  if 15 - 15: iII111i + I1Ii111 / iII111i / o0o0OOO0o0
  if 31 - 31: IIII + I1IiiI + IIII . Oo0Ooo + oO0o / Ii1I
def II11i1IiIII ( ) :
 if 67 - 67: oO0o / i1I1i1Ii11 * OoO0O00
 try :
  if 100 - 100: I1IiiI . ooOoO0o . OOooOOo + I1IiiI * IiII
  II11Ii1iI1iII = Oo0o00OO0000 ( iIiIi11 )
  I1i = re . compile ( II1I ) . findall ( II11Ii1iI1iII )
  for O00Oooo in I1i :
   if 42 - 42: IiII % OoO0O00 + Ii1I
   try :
    if 56 - 56: OoO0O00 + iII111i - i1I1i1Ii11
    III1I1 = O00Oooo
    if 12 - 12: Oo0Ooo % IIII % IIII
   except :
    pass
    if 78 - 78: IIIIII11i1I . I11i . ooOoO0o
    if 97 - 97: IiII
  II11Ii1iI1iII = Oo0o00OO0000 ( III1I1 )
  I1i = re . compile ( O0OOO ) . findall ( II11Ii1iI1iII )
  for IiI1iIiIIIii , oOoO , oOoO00O0 , id , OOIi1iI111II1I1 in I1i :
   try :
    i1II1 ( oOoO , oOoO00O0 , IiI1iIiIIIii , id , OOIi1iI111II1I1 )
    if 80 - 80: I1ii11iIi11i . o00O0oo
   except :
    pass
 except :
  pass
  if 47 - 47: ooOoO0o + IIII + o0oOOo0O0Ooo % II111iiii
  if 93 - 93: iII111i % I11i . I1IiiI / i1I1i1Ii11 * IiII
def i1iii1ii ( ) :
 if 18 - 18: OOooOOo . o0oOOo0O0Ooo % I11i % o00O0oo
 try :
  if 87 - 87: Oo0Ooo . OoO0O00 * I11i
  II11Ii1iI1iII = Oo0o00OO0000 ( oooOo0OOOoo0 )
  I1i = re . compile ( II1I ) . findall ( II11Ii1iI1iII )
  for O00Oooo in I1i :
   if 100 - 100: OOooOOo / OoOoOO00 - I1ii11iIi11i % o00O0oo - Oo0Ooo
   try :
    if 17 - 17: ooOoO0o / Ii1I % oO0o
    o0oo00o0O0O00 = O00Oooo
    if 34 - 34: I1Ii111 . oO0o
   except :
    pass
    if 78 - 78: iII111i % I1ii11iIi11i / OoO0O00 % I1Ii111 - i1I1i1Ii11
  II11Ii1iI1iII = Oo0o00OO0000 ( o0oo00o0O0O00 )
  I1i = re . compile ( O0OOO ) . findall ( II11Ii1iI1iII )
  for IiI1iIiIIIii , oOoO , oOoO00O0 , id , OOIi1iI111II1I1 in I1i :
   try :
    i1II1 ( oOoO , oOoO00O0 , IiI1iIiIIIii , id , OOIi1iI111II1I1 )
    if 2 - 2: Oo0Ooo
   except :
    pass
 except :
  pass
  if 45 - 45: OoO0O00 / II111iiii
  if 10 - 10: i1I1i1Ii11 - IiII * Oo0Ooo % Oo0Ooo * IIIIII11i1I - iII111i
def OoO0O0oO00 ( ) :
 if 33 - 33: I1IiiI
 try :
  if 78 - 78: I1IiiI / o0oOOo0O0Ooo * OOooOOo
  II11Ii1iI1iII = Oo0o00OO0000 ( OO0O000 )
  I1i = re . compile ( II1I ) . findall ( II11Ii1iI1iII )
  for O00Oooo in I1i :
   if 50 - 50: OoO0O00 - Oo0Ooo + OoOoOO00 % o0o0OOO0o0 - Oo0Ooo % I1IiiI
   try :
    if 58 - 58: IIIIII11i1I + Oo0Ooo
    Oo00OO0OO = O00Oooo
    if 85 - 85: Ii1I % IIII . I11i % o0o0OOO0o0 - oO0o
   except :
    pass
    if 69 - 69: IIII - Ii1I . IIII
    if 9 - 9: IiII % II111iiii / oO0o
  II11Ii1iI1iII = Oo0o00OO0000 ( Oo00OO0OO )
  I1i = re . compile ( O0OOO ) . findall ( II11Ii1iI1iII )
  for IiI1iIiIIIii , oOoO , oOoO00O0 , id , OOIi1iI111II1I1 in I1i :
   try :
    i1II1 ( oOoO , oOoO00O0 , IiI1iIiIIIii , id , OOIi1iI111II1I1 )
    if 20 - 20: IiII * I1IiiI + ooOoO0o - OoO0O00 . ooOoO0o
   except :
    pass
 except :
  pass
  if 60 - 60: Ii1I . Ii1I / i1I1i1Ii11
def Ii ( ) :
 if 79 - 79: Oo0Ooo
 try :
  if 81 - 81: I1Ii111 + Oo0Ooo * o0o0OOO0o0 - Oo0Ooo . I1Ii111
  II11Ii1iI1iII = Oo0o00OO0000 ( oO0O00oOOoooO )
  I1i = re . compile ( II1I ) . findall ( II11Ii1iI1iII )
  for O00Oooo in I1i :
   if 48 - 48: ooOoO0o . OoO0O00 . I1ii11iIi11i . I11i % iII111i / i1I1i1Ii11
   try :
    if 11 - 11: OoOoOO00 % OOooOOo % i1I1i1Ii11
    O0Oo0OOooO0OO0 = O00Oooo
    if 5 - 5: i1I1i1Ii11
   except :
    pass
  II11Ii1iI1iII = Oo0o00OO0000 ( O0Oo0OOooO0OO0 )
  I1i = re . compile ( O0OOO ) . findall ( II11Ii1iI1iII )
  for IiI1iIiIIIii , oOoO , oOoO00O0 , id , OOIi1iI111II1I1 in I1i :
   try :
    i1II1 ( oOoO , oOoO00O0 , IiI1iIiIIIii , id , OOIi1iI111II1I1 )
    if 62 - 62: I11i . OoO0O00 . I1Ii111 . OOooOOo * i1I1i1Ii11
   except :
    pass
 except :
  pass
  if 78 - 78: IiII / OOooOOo - IiII * OoO0O00 . I11i
def OOoooOoO0Oo ( ) :
 if 78 - 78: OoO0O00 / I1Ii111 % I11i * OoO0O00
 try :
  if 68 - 68: IiII
  II11Ii1iI1iII = Oo0o00OO0000 ( Oo0O00O000 )
  I1i = re . compile ( II1I ) . findall ( II11Ii1iI1iII )
  for O00Oooo in I1i :
   if 29 - 29: i1I1i1Ii11 + II111iiii % ooOoO0o
   try :
    if 93 - 93: I11i % Oo0Ooo
    Ooo0o0oo0 = O00Oooo
    if 87 - 87: I11i / IIIIII11i1I + Oo0Ooo
   except :
    pass
  II11Ii1iI1iII = Oo0o00OO0000 ( Ooo0o0oo0 )
  I1i = re . compile ( O0OOO ) . findall ( II11Ii1iI1iII )
  for IiI1iIiIIIii , oOoO , oOoO00O0 , id , OOIi1iI111II1I1 in I1i :
   try :
    i1II1 ( oOoO , oOoO00O0 , IiI1iIiIIIii , id , OOIi1iI111II1I1 )
    if 93 - 93: Oo0Ooo + IiII % IIII
   except :
    pass
 except :
  pass
  if 21 - 21: I1Ii111
def iIiI1I1IIi11 ( ) :
 if 9 - 9: IIII + i1I1i1Ii11 - ooOoO0o / OoOoOO00 % iII111i / IIIIII11i1I
 try :
  if 60 - 60: iII111i
  II11Ii1iI1iII = Oo0o00OO0000 ( o00O0O )
  I1i = re . compile ( II1I ) . findall ( II11Ii1iI1iII )
  for O00Oooo in I1i :
   if 1 - 1: I11i . II111iiii % I11i - i1I1i1Ii11 % OoOoOO00 + iII111i
   try :
    if 2 - 2: Oo0Ooo * IiII / I11i . ooOoO0o / IIIIII11i1I
    o00O0OO = O00Oooo
    if 64 - 64: IIIIII11i1I . II111iiii / o0oOOo0O0Ooo + Ii1I * o00O0oo % I1IiiI
   except :
    pass
  II11Ii1iI1iII = Oo0o00OO0000 ( o00O0OO )
  I1i = re . compile ( O0OOO ) . findall ( II11Ii1iI1iII )
  for IiI1iIiIIIii , oOoO , oOoO00O0 , id , OOIi1iI111II1I1 in I1i :
   try :
    i1II1 ( oOoO , oOoO00O0 , IiI1iIiIIIii , id , OOIi1iI111II1I1 )
    if 89 - 89: o0o0OOO0o0 . IIIIII11i1I % oO0o . oO0o - OoO0O00
   except :
    pass
 except :
  pass
  if 56 - 56: ooOoO0o
def IiI1 ( ) :
 if 59 - 59: ooOoO0o / oO0o / I1Ii111 / I1IiiI / I11i + Ii1I
 try :
  if 13 - 13: Ii1I % IiII / o0o0OOO0o0 % o0o0OOO0o0 % I1IiiI
  II11Ii1iI1iII = Oo0o00OO0000 ( oo )
  I1i = re . compile ( II1I ) . findall ( II11Ii1iI1iII )
  for O00Oooo in I1i :
   if 90 - 90: IIIIII11i1I . IIII / Oo0Ooo
   try :
    if 28 - 28: IIIIII11i1I + IiII - IIII / Oo0Ooo - I1ii11iIi11i
    Ii1i1 = O00Oooo
    if 65 - 65: IiII + iII111i / I1Ii111
   except :
    pass
  II11Ii1iI1iII = Oo0o00OO0000 ( Ii1i1 )
  I1i = re . compile ( o0o ) . findall ( II11Ii1iI1iII )
  for IiI1iIiIIIii , oOoO , oOoO00O0 in I1i :
   try :
    oo0oo ( IiI1iIiIIIii , oOoO , oOoO00O0 )
    if 49 - 49: II111iiii % I11i + o0o0OOO0o0 . o0oOOo0O0Ooo % i1I1i1Ii11 * I1Ii111
   except :
    pass
    if 67 - 67: OoOoOO00
 except :
  pass
  if 5 - 5: o0oOOo0O0Ooo . OoO0O00
  if 57 - 57: I1ii11iIi11i
  if 35 - 35: OoO0O00 - o0o0OOO0o0 / OOooOOo
def oo0oo ( thumb , name , url ) :
 if 50 - 50: I11i
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( III1iII1I1ii ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   IiIii1i111 ( name , url , '' , i1ii1iIII , O0oOO0o0 )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 33 - 33: ooOoO0o
  if 'tvg-logo' in thumb :
   thumb = re . compile ( III1iII1I1ii ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 98 - 98: I11i % o0oOOo0O0Ooo
   OoO0O000 ( name , url , 4 , II1Ii , O0oOO0o0 )
   if 6 - 6: OoOoOO00 - o0oOOo0O0Ooo * Ii1I . OOooOOo
  else :
   if 68 - 68: Ii1I
   OoO0O000 ( name , url , 4 , II1Ii , O0oOO0o0 )
   if 20 - 20: o0o0OOO0o0 - o0o0OOO0o0
   if 37 - 37: IIIIII11i1I
def i1II1 ( name , url , thumb , id , trailer ) :
 if 37 - 37: oO0o / IIIIII11i1I * I1IiiI
 if 73 - 73: i1I1i1Ii11 * i1I1i1Ii11 / IIII
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 43 - 43: iII111i . OoOoOO00 . IIIIII11i1I + I1IiiI * o00O0oo * I1IiiI
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( III1iII1I1ii ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   IiIii1i111 ( name , url , '' , i1ii1iIII , O0oOO0o0 )
 else :
  OoO0O00IIiII = oo000 . getSetting ( 'Fontcolor' )
  if 41 - 41: iII111i + o00O0oo % OoO0O00 . iII111i + i1I1i1Ii11 . i1I1i1Ii11
  name = '[COLOR %s]' % OoO0O00IIiII + name + '[/COLOR]'
  if 31 - 31: II111iiii + o0oOOo0O0Ooo . i1I1i1Ii11 * I11i
  if 'tvg-logo' in thumb :
   thumb = re . compile ( III1iII1I1ii ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 66 - 66: I11i + OoOoOO00 % o0oOOo0O0Ooo . I1IiiI * iII111i % iII111i
   O0oOO0o ( name , url , 1 , thumb , thumb , id , trailer )
   if 6 - 6: Oo0Ooo * OoO0O00
  else :
   if 28 - 28: oO0o * Ii1I / o0o0OOO0o0
   O0oOO0o ( name , url , 1 , thumb , thumb , id , trailer )
   if 52 - 52: I1IiiI / Ii1I % i1I1i1Ii11 * I1ii11iIi11i % I1Ii111
def o0oOOOO0 ( name , trailer ) :
 if 11 - 11: OoOoOO00
 if 19 - 19: i1I1i1Ii11 - Ii1I - o00O0oo - I11i . i1I1i1Ii11 . o0o0OOO0o0
 oOoO00O0 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
 i11I1I = oOoO00O0
 oo0ooooo00o = xbmcgui . ListItem ( name , trailer , path = i11I1I )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0ooooo00o )
 return
 if 78 - 78: Oo0Ooo . Ii1I % Oo0Ooo . I1IiiI / I1Ii111
 if 76 - 76: OoOoOO00 * OoO0O00 * I1IiiI + o0o0OOO0o0 * o0o0OOO0o0
def i1iIiIii ( name , url ) :
 import urlresolver
 from urlresolver import common
 if 20 - 20: Ii1I * IIII
 i1III1iI = urlresolver . HostedMediaFile ( url )
 if 38 - 38: Oo0Ooo / IIII
 if not i1III1iI :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
  if 13 - 13: Oo0Ooo
  return False
  if 77 - 77: II111iiii - Oo0Ooo / IiII / IIII / OOooOOo
  if 56 - 56: OoO0O00 * I1IiiI
 try :
  oo0OoOOooO = i1III1iI . resolve ( )
  if not oo0OoOOooO or not isinstance ( oo0OoOOooO , basestring ) :
   try : o0o0OO0o00o0O = oo0OoOOooO . msg
   except : o0o0OO0o00o0O = url
   raise Exception ( o0o0OO0o00o0O )
 except Exception as I1i11111i1i11 :
  try : o0o0OO0o00o0O = str ( I1i11111i1i11 )
  except : o0o0OO0o00o0O = url
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,5000)" )
  if 28 - 28: OOooOOo - IiII + I11i + o00O0oo / Oo0Ooo
  return False
  if 26 - 26: Oo0Ooo - I1IiiI . I1IiiI
 Ii11iII1 = oo000 . getSetting ( 'notificar' )
 if Ii11iII1 == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
 O0oOoo = xbmcgui . ListItem ( path = oo0OoOOooO )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0oOoo )
 if 76 - 76: OoOoOO00 % I11i - I1ii11iIi11i / Ii1I * IIII
def iIiIIiI1i1Ii ( name , url ) :
 if 72 - 72: I1Ii111 . I1Ii111 - iII111i
 if 48 - 48: oO0o - IIII + oO0o - I1ii11iIi11i * II111iiii . i1I1i1Ii11
 if 'https://www.rapidvideo.com/v/' in url :
  if 35 - 35: IIIIII11i1I . I1IiiI + oO0o + I1Ii111 + OoOoOO00
  II11Ii1iI1iII = Oo0o00OO0000 ( url )
  I1i = re . compile ( 'rapidvideo' ) . findall ( II11Ii1iI1iII )
  for url in I1i :
   if 65 - 65: I1IiiI * I1ii11iIi11i / I1ii11iIi11i . I11i
   if 87 - 87: o0oOOo0O0Ooo * iII111i % oO0o * oO0o
   try :
    Ii11iII1 = oo000 . getSetting ( 'notificar' )
    if Ii11iII1 == 'true' :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    O0oOoo = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0oOoo )
    if 58 - 58: I1Ii111 . Ii1I + I1ii11iIi11i % oO0o - OOooOOo
   except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 50 - 50: i1I1i1Ii11 % o0oOOo0O0Ooo - IIII . OoOoOO00 + I1IiiI % i1I1i1Ii11
   if 10 - 10: i1I1i1Ii11 . OoOoOO00 + o00O0oo
 else :
  if 66 - 66: OOooOOo % Ii1I
  import urlresolver
  from urlresolver import common
  if 21 - 21: I11i - OoO0O00 % II111iiii
  i1III1iI = urlresolver . HostedMediaFile ( url )
  if 71 - 71: OoOoOO00 - ooOoO0o * o0o0OOO0o0 + IiII - OOooOOo % iII111i
  if not i1III1iI :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 63 - 63: Oo0Ooo + I1Ii111 . OOooOOo / I1ii11iIi11i
   if 84 - 84: OoOoOO00
  try :
   oo0OoOOooO = i1III1iI . resolve ( )
   if not oo0OoOOooO or not isinstance ( oo0OoOOooO , basestring ) :
    try : o0o0OO0o00o0O = oo0OoOOooO . msg
    except : o0o0OO0o00o0O = url
    raise Exception ( o0o0OO0o00o0O )
  except Exception as I1i11111i1i11 :
   try : o0o0OO0o00o0O = str ( I1i11111i1i11 )
   except : o0o0OO0o00o0O = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 42 - 42: o0oOOo0O0Ooo - OOooOOo - OoO0O00 . i1I1i1Ii11 / I11i
  Ii11iII1 = oo000 . getSetting ( 'notificar' )
  if Ii11iII1 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  O0oOoo = xbmcgui . ListItem ( path = oo0OoOOooO )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0oOoo )
  if 56 - 56: II111iiii - Oo0Ooo . o0oOOo0O0Ooo
 return
 if 81 - 81: IIIIII11i1I / I11i * IIIIII11i1I . I1IiiI
 if 61 - 61: OOooOOo * I1Ii111 + o0o0OOO0o0 . Oo0Ooo % ooOoO0o . o0o0OOO0o0
 if 53 - 53: o0o0OOO0o0 * IIIIII11i1I / Oo0Ooo / I1ii11iIi11i % iII111i
def IIii ( name , url ) :
 if 97 - 97: iII111i / oO0o + o0o0OOO0o0
 oo0OoOOooO = url
 Ii11iII1 = oo000 . getSetting ( 'notificar' )
 if Ii11iII1 == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  O0oOoo = xbmcgui . ListItem ( path = oo0OoOOooO )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0oOoo )
 else :
  O0oOoo = xbmcgui . ListItem ( path = oo0OoOOooO )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0oOoo )
 return
 if 32 - 32: IIII % o0o0OOO0o0 * oO0o
def O0O000oOo0O ( name , url ) :
 if 82 - 82: IIIIII11i1I
 if 86 - 86: oO0o * o0oOOo0O0Ooo * I1IiiI
 if '[Youtube]' in name :
  if 83 - 83: IIIIII11i1I / o0o0OOO0o0
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 64 - 64: OOooOOo % IIIIII11i1I . o0o0OOO0o0 % OOooOOo + ooOoO0o * IIIIII11i1I
  try :
   Ii11iII1 = oo000 . getSetting ( 'notificar' )
   if Ii11iII1 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    O0oOoo = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0oOoo )
    if 83 - 83: Ii1I % IiII + ooOoO0o % II111iiii + I1IiiI
    if 65 - 65: Oo0Ooo % IiII + I1IiiI / OoO0O00
    if 52 - 52: o00O0oo % I1Ii111 * I1ii11iIi11i % ooOoO0o + I1Ii111 / i1I1i1Ii11
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 80 - 80: OoO0O00 + IIIIII11i1I
  if 95 - 95: o0o0OOO0o0 / IiII * o0o0OOO0o0 - OoO0O00 * OoO0O00 % OOooOOo
 else :
  if 43 - 43: oO0o . o0o0OOO0o0
  import xbmcgui
  import urlresolver
  from urlresolver import common
  if 12 - 12: o0o0OOO0o0 + I1Ii111 + ooOoO0o . IIIIII11i1I / o00O0oo
  i1III1iI = urlresolver . HostedMediaFile ( url )
  if 29 - 29: IIIIII11i1I . IIII - o0oOOo0O0Ooo
  if not i1III1iI :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 68 - 68: Oo0Ooo + o0oOOo0O0Ooo / IiII
  import resolveurl as urlresolver
  if 91 - 91: I11i % Oo0Ooo . I1ii11iIi11i
  i1III1iI = urlresolver . HostedMediaFile ( url )
  if 70 - 70: ooOoO0o % o0oOOo0O0Ooo % I1IiiI . OoOoOO00 / o0o0OOO0o0
  if 100 - 100: iII111i * II111iiii % IiII / oO0o / IIII + iII111i
  if not i1III1iI :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 59 - 59: o0o0OOO0o0 - IIIIII11i1I
  try :
   oo0OoOOooO = i1III1iI . resolve ( )
   if not oo0OoOOooO or not isinstance ( oo0OoOOooO , basestring ) :
    try : o0o0OO0o00o0O = oo0OoOOooO . msg
    except : o0o0OO0o00o0O = url
    raise Exception ( o0o0OO0o00o0O )
  except Exception as I1i11111i1i11 :
   try : o0o0OO0o00o0O = str ( I1i11111i1i11 )
   except : o0o0OO0o00o0O = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 14 - 14: Oo0Ooo - Oo0Ooo
   if 5 - 5: IIIIII11i1I
   if 84 - 84: o0oOOo0O0Ooo * IiII * o0oOOo0O0Ooo % IIIIII11i1I / I1ii11iIi11i
  Ii11iII1 = oo000 . getSetting ( 'notificar' )
  if Ii11iII1 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 100 - 100: IIIIII11i1I . o00O0oo - Oo0Ooo . II111iiii / o0oOOo0O0Ooo
   if '[Realstream]' in name :
    if 71 - 71: o0o0OOO0o0 * oO0o . ooOoO0o
    IIIIii = oo000 . getSetting ( 'restante' )
    if IIIIii == 'true' :
     iII1111III1I = xbmcgui . Dialog ( )
     i1ii1iiIi1II = iII1111III1I . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 98 - 98: OOooOOo - o00O0oo . IIIIII11i1I % II111iiii
   O0oOoo = xbmcgui . ListItem ( path = oo0OoOOooO )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0oOoo )
   if 69 - 69: iII111i + i1I1i1Ii11 * I1IiiI . I1Ii111 % I11i
   if 96 - 96: IIII . IIII - ooOoO0o / ooOoO0o
   if 96 - 96: II111iiii / I1ii11iIi11i - I1IiiI . IIII
 return
 if 39 - 39: IIII / I1IiiI * IIIIII11i1I
 if 17 - 17: o00O0oo / Oo0Ooo - OOooOOo + I1ii11iIi11i % I1Ii111
 if 14 - 14: Ii1I % IIIIII11i1I + iII111i + OOooOOo
def OOOoOOo0o ( name , url ) :
 if 50 - 50: o0oOOo0O0Ooo - o0o0OOO0o0 + Oo0Ooo + Oo0Ooo
 if 91 - 91: o0oOOo0O0Ooo - I1IiiI . Oo0Ooo . I1IiiI + iII111i - o0oOOo0O0Ooo
 if '[Youtube]' in name :
  if 26 - 26: Ii1I
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 12 - 12: OoO0O00 / I1IiiI + o0oOOo0O0Ooo * iII111i
  try :
   Ii11iII1 = oo000 . getSetting ( 'notificar' )
   if Ii11iII1 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    O0oOoo = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0oOoo )
    if 46 - 46: o0oOOo0O0Ooo - IIIIII11i1I * OoO0O00 / IiII % IIIIII11i1I
    if 11 - 11: Oo0Ooo . I11i / IIIIII11i1I % IIII
    if 61 - 61: IIII - I1Ii111 + I1Ii111
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 40 - 40: II111iiii . Oo0Ooo
 else :
  if 2 - 2: OoOoOO00 * IiII - IiII + OoO0O00 % I11i / I11i
  import resolveurl
  if 3 - 3: OoO0O00
  i1III1iI = urlresolver . HostedMediaFile ( url )
  if 71 - 71: IIIIII11i1I + OoOoOO00 - i1I1i1Ii11 - II111iiii . ooOoO0o - IIII
  if 85 - 85: iII111i - I11i / iII111i + I1Ii111 - i1I1i1Ii11
  if not i1III1iI :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 49 - 49: OOooOOo - I1IiiI / OOooOOo * I11i + o0o0OOO0o0
  try :
   oo0OoOOooO = i1III1iI . resolve ( )
   if not oo0OoOOooO or not isinstance ( oo0OoOOooO , basestring ) :
    try : o0o0OO0o00o0O = oo0OoOOooO . msg
    except : o0o0OO0o00o0O = url
    raise Exception ( o0o0OO0o00o0O )
  except Exception as I1i11111i1i11 :
   try : o0o0OO0o00o0O = str ( I1i11111i1i11 )
   except : o0o0OO0o00o0O = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 35 - 35: o0oOOo0O0Ooo . I1ii11iIi11i / OoOoOO00 / I1ii11iIi11i * IiII
   if 85 - 85: o0oOOo0O0Ooo . IIII % I1Ii111 % ooOoO0o
   if 80 - 80: IiII * ooOoO0o / Oo0Ooo % IiII / Oo0Ooo
  Ii11iII1 = oo000 . getSetting ( 'notificar' )
  if Ii11iII1 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 42 - 42: OoOoOO00 / II111iiii . oO0o * i1I1i1Ii11 . II111iiii * I1IiiI
   if '[Realstream]' in name :
    if 44 - 44: OoOoOO00 . I1ii11iIi11i / II111iiii + IIIIII11i1I
    IIIIii = oo000 . getSetting ( 'restante' )
    if IIIIii == 'true' :
     iII1111III1I = xbmcgui . Dialog ( )
     i1ii1iiIi1II = iII1111III1I . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 27 - 27: I1Ii111
   O0oOoo = xbmcgui . ListItem ( path = oo0OoOOooO )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0oOoo )
   if 52 - 52: o0o0OOO0o0 % I11i + Oo0Ooo * IiII . o00O0oo
   if 95 - 95: Oo0Ooo . IIIIII11i1I - OoO0O00 * OOooOOo / Ii1I
   if 74 - 74: IiII
 return
 if 34 - 34: i1I1i1Ii11
def ii1IIiI1IIi ( name , url ) :
 if 76 - 76: i1I1i1Ii11 / OOooOOo + I11i
 if 86 - 86: II111iiii + II111iiii . o0o0OOO0o0 % I1ii11iIi11i . IIII
 if '[Youtube]' in name :
  if 17 - 17: o00O0oo
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 67 - 67: I1IiiI * ooOoO0o - Ii1I - o0oOOo0O0Ooo
  try :
   Ii11iII1 = oo000 . getSetting ( 'notificar' )
   if Ii11iII1 == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    O0oOoo = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0oOoo )
    if 41 - 41: I1ii11iIi11i - o0o0OOO0o0 % o0oOOo0O0Ooo . o0o0OOO0o0 - ooOoO0o
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 45 - 45: o00O0oo - I1Ii111
 else :
  if 70 - 70: OOooOOo % I1ii11iIi11i / I1ii11iIi11i . ooOoO0o % IIII . o0oOOo0O0Ooo
  if 'https://team.com' in url :
   if 10 - 10: o00O0oo - II111iiii . iII111i % OoOoOO00
   url = url . replace ( 'https://team.com' , 'https://verystream.com' )
   if 78 - 78: Oo0Ooo * oO0o . oO0o - I1Ii111 . Oo0Ooo
  if 'https://mybox.com' in url :
   if 30 - 30: IIII + IIII % IIIIII11i1I - Ii1I - iII111i
   url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
   if 36 - 36: ooOoO0o % I1Ii111
  if 'https://drive.com' in url :
   if 72 - 72: I1ii11iIi11i / i1I1i1Ii11 - I1IiiI + ooOoO0o
   url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
   if 83 - 83: I1IiiI
  if 'https://vid.co/' in url :
   if 89 - 89: oO0o + iII111i - Ii1I
   url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
   if 40 - 40: OOooOOo + OOooOOo
  if 'https://limited.to' in url :
   if 94 - 94: i1I1i1Ii11 * Oo0Ooo . ooOoO0o
   url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
   if 13 - 13: Oo0Ooo * I11i / o0o0OOO0o0 % IIII + IiII
  import resolveurl
  if 41 - 41: iII111i
  i1III1iI = urlresolver . HostedMediaFile ( url )
  if 5 - 5: oO0o
  if 100 - 100: o00O0oo + Oo0Ooo
  if not i1III1iI :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 59 - 59: IIIIII11i1I
  try :
   oo0OoOOooO = i1III1iI . resolve ( )
   if not oo0OoOOooO or not isinstance ( oo0OoOOooO , basestring ) :
    try : o0o0OO0o00o0O = oo0OoOOooO . msg
    except : o0o0OO0o00o0O = url
    raise Exception ( o0o0OO0o00o0O )
  except Exception as I1i11111i1i11 :
   try : o0o0OO0o00o0O = str ( I1i11111i1i11 )
   except : o0o0OO0o00o0O = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace borrado, reportalo en nuesto grupo de telegram [/COLOR][COLOR ligthblue] https://t.me/OficialNetai [/COLOR]  ,5000)" )
   return False
   if 89 - 89: I11i % Oo0Ooo
   if 35 - 35: iII111i + o0o0OOO0o0 - I11i % IiII % Ii1I % I11i
   if 45 - 45: I1ii11iIi11i * I1Ii111 % OOooOOo
  Ii11iII1 = oo000 . getSetting ( 'notificar' )
  if Ii11iII1 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 24 - 24: IIII - ooOoO0o * IiII
   if 87 - 87: o00O0oo - iII111i % iII111i . IiII / iII111i
   O0oOoo = xbmcgui . ListItem ( path = oo0OoOOooO )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0oOoo )
   if 6 - 6: I11i / Oo0Ooo * OoO0O00 * II111iiii
  else :
   if 79 - 79: IIIIII11i1I % OOooOOo
   O0oOoo = xbmcgui . ListItem ( path = oo0OoOOooO )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0oOoo )
   if 81 - 81: II111iiii + II111iiii * OOooOOo + IIIIII11i1I
   if 32 - 32: I1IiiI . OoO0O00
 return
 if 15 - 15: I1ii11iIi11i . OOooOOo
 if 17 - 17: II111iiii / oO0o . OOooOOo / I1ii11iIi11i
 if 38 - 38: OoOoOO00 . iII111i % o00O0oo + Oo0Ooo + I1IiiI
def iIi1i11 ( ) :
 if 25 - 25: I1ii11iIi11i % I1IiiI + OoOoOO00 - IIII
 if 38 - 38: Ii1I % o0o0OOO0o0 + II111iiii + i1I1i1Ii11 + IIII / II111iiii
 o0OOOOOo0 = [ ]
 oooOoO = sys . argv [ 2 ]
 if len ( oooOoO ) >= 2 :
  O0Oo0iIIIi1IiI11I1 = sys . argv [ 2 ]
  O0Ooo000 = O0Oo0iIIIi1IiI11I1 . replace ( '?' , '' )
  if ( O0Oo0iIIIi1IiI11I1 [ len ( O0Oo0iIIIi1IiI11I1 ) - 1 ] == '/' ) :
   O0Oo0iIIIi1IiI11I1 = O0Oo0iIIIi1IiI11I1 [ 0 : len ( O0Oo0iIIIi1IiI11I1 ) - 2 ]
  IIi11iI1Iii = O0Ooo000 . split ( '&' )
  o0OOOOOo0 = { }
  for IiIi1i in range ( len ( IIi11iI1Iii ) ) :
   i11ii = { }
   i11ii = IIi11iI1Iii [ IiIi1i ] . split ( '=' )
   if ( len ( i11ii ) ) == 2 :
    o0OOOOOo0 [ i11ii [ 0 ] ] = i11ii [ 1 ]
 return o0OOOOOo0
 if 83 - 83: iII111i * iII111i + I1Ii111
 if 57 - 57: I1IiiI - I1IiiI . iII111i / Ii1I / o00O0oo
def I1IiII1I1i1I1 ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  import urlresolver
  xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
  if 28 - 28: oO0o + IIIIII11i1I % o0oOOo0O0Ooo / OOooOOo + II111iiii
def ii11Iiii ( ) :
 iII1111III1I = xbmcgui . Dialog ( )
 list = (
 II1OoooOo ,
 I1I1IIiiii1ii
 )
 if 92 - 92: IiII / I1Ii111 . iII111i
 i11iiI1111 = iII1111III1I . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=%s]Accede a themoviedb.com[/COLOR]' % o0 ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 30 - 30: o00O0oo . iII111i / I1Ii111
 if i11iiI1111 :
  if 2 - 2: IIIIII11i1I % I1ii11iIi11i - o0o0OOO0o0
  if i11iiI1111 < 0 :
   return
  I11o0oO00oO0o0o0 = list [ i11iiI1111 - 2 ]
  return I11o0oO00oO0o0o0 ( )
 else :
  I11o0oO00oO0o0o0 = list [ i11iiI1111 ]
  return I11o0oO00oO0o0o0 ( )
 return
 if 79 - 79: OoO0O00 / iII111i . I1IiiI
def I1IIIiI1I1ii1 ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 79 - 79: IiII - o0oOOo0O0Ooo
I1iIIIi1 = I1IIIiI1I1ii1 ( )
if 43 - 43: OoOoOO00 + I1IiiI % OOooOOo / o00O0oo * I1ii11iIi11i
def II1OoooOo ( ) :
 if I1iIIIi1 == 'android' :
  OOOIiiiii1iI = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  OOOIiiiii1iI = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 89 - 89: I1ii11iIi11i . oO0o + iII111i . I1IiiI % Ii1I
  if 84 - 84: OoO0O00 + o0o0OOO0o0 / I1ii11iIi11i % I1Ii111 % iII111i * I1ii11iIi11i
def I1I1IIiiii1ii ( ) :
 if 58 - 58: OOooOOo - I11i . II111iiii % II111iiii / OoOoOO00 / IiII
 main ( )
 if 24 - 24: I1ii11iIi11i * OoOoOO00 % IIII / I1IiiI + II111iiii
 if 12 - 12: iII111i / o00O0oo
 if 5 - 5: OoO0O00
def IIIii11i1I ( ) :
 iII1111III1I = xbmcgui . Dialog ( )
 ii11iO00oOo00o0o = (
 ooo0O00000oo0 ,
 oOO0ooo0oo0000
 )
 if 89 - 89: I11i . I1Ii111
 i11iiI1111 = iII1111III1I . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 7 - 7: IiII % I11i - I1ii11iIi11i + oO0o
 if i11iiI1111 :
  if 70 - 70: o0oOOo0O0Ooo + o0o0OOO0o0 + II111iiii - OoOoOO00 / IIIIII11i1I
  if i11iiI1111 < 0 :
   return
  I11o0oO00oO0o0o0 = ii11iO00oOo00o0o [ i11iiI1111 - 2 ]
  return I11o0oO00oO0o0o0 ( )
 else :
  I11o0oO00oO0o0o0 = ii11iO00oOo00o0o [ i11iiI1111 ]
  return I11o0oO00oO0o0o0 ( )
 return
 if 40 - 40: iII111i * o0o0OOO0o0
def I1IIIiI1I1ii1 ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 38 - 38: I1IiiI . oO0o + I11i - IiII
I1iIIIi1 = I1IIIiI1I1ii1 ( )
if 43 - 43: i1I1i1Ii11 + oO0o / OoO0O00
def ooo0O00000oo0 ( ) :
 if I1iIIIi1 == 'android' :
  OOOIiiiii1iI = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  OOOIiiiii1iI = webbrowser . open ( 'https://olpair.com/' )
  if 24 - 24: I1IiiI + Ii1I * o00O0oo - o0o0OOO0o0
  if 10 - 10: II111iiii
def oOO0ooo0oo0000 ( ) :
 if 21 - 21: I1ii11iIi11i / i1I1i1Ii11
 main ( )
 if 69 - 69: IIII % IIII
 if 76 - 76: II111iiii * i1I1i1Ii11 / OOooOOo % iII111i + I1Ii111
def IiIi1II111I ( name , url , id , trailer ) :
 iII1111III1I = xbmcgui . Dialog ( )
 ii11iO00oOo00o0o = (
 o00o ,
 IIi1i1 ,
 o0O0Ooo ,
 ii11Iiii ,
 O0o
 )
 if 63 - 63: IIIIII11i1I - OoOoOO00 * Ii1I + OoO0O00
 i11iiI1111 = iII1111III1I . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % o0 ,

 '[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % o0 ,

 '[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % o0 ,

 '[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % o0 ,

 '[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % o0 ] )
 if 11 - 11: IIIIII11i1I + Oo0Ooo . II111iiii - I1Ii111
 if i11iiI1111 :
  if 49 - 49: IIII . o0oOOo0O0Ooo
  if i11iiI1111 < 0 :
   return
  I11o0oO00oO0o0o0 = ii11iO00oOo00o0o [ i11iiI1111 - 5 ]
  return I11o0oO00oO0o0o0 ( )
 else :
  I11o0oO00oO0o0o0 = ii11iO00oOo00o0o [ i11iiI1111 ]
  return I11o0oO00oO0o0o0 ( )
 return
 if 24 - 24: I1IiiI . OoO0O00 - OOooOOo * OoO0O00
 if 12 - 12: I1IiiI + IIIIII11i1I * OoOoOO00 . OOooOOo
 if 71 - 71: o0o0OOO0o0 - Ii1I - I1Ii111
def o00o ( ) :
 if 28 - 28: Oo0Ooo
 ii1IIiI1IIi ( oOoO , oOoO00O0 )
 if 7 - 7: Ii1I % IIIIII11i1I * I11i
def IIi1i1 ( ) :
 if 58 - 58: IIIIII11i1I / ooOoO0o + o0oOOo0O0Ooo % i1I1i1Ii11 - OoO0O00
 o0oOOOO0 ( oOoO , OOIi1iI111II1I1 )
 if 25 - 25: I11i % OoO0O00 * oO0o - OoOoOO00 * o0oOOo0O0Ooo * IiII
def o0O0Ooo ( ) :
 if 30 - 30: ooOoO0o % I11i / iII111i * I1IiiI * o00O0oo . I1ii11iIi11i
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  iIi11I11 = id
  if 40 - 40: Oo0Ooo
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % iIi11I11 )
  if 92 - 92: I11i % I1IiiI
 if Ii11iII1 == 'true' :
  if 55 - 55: Oo0Ooo * i1I1i1Ii11
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + oOoO + "[/COLOR] ,5000)" )
  if 85 - 85: Oo0Ooo . o0oOOo0O0Ooo
def o0ooo0o0 ( ) :
 if 84 - 84: ooOoO0o - oO0o * I1IiiI / o00O0oo . o00O0oo
 ii11Iiii ( )
 if 93 - 93: I1IiiI / IIII + I1ii11iIi11i
def O0o ( ) :
 if 20 - 20: IIIIII11i1I / i1I1i1Ii11 % OoO0O00 / Oo0Ooo + I1ii11iIi11i
 main ( )
def IiIii1i111 ( name , url , mode , iconimage , fanart ) :
 if 57 - 57: Ii1I / o0o0OOO0o0
 iiIiII = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 i1ii1iiIi1II = True
 IIiiiI1iI = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 IIiiiI1iI . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IIiiiI1iI . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  iiIiII = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  i1ii1iiIi1II = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiIiII , listitem = IIiiiI1iI , isFolder = True )
  return i1ii1iiIi1II
 i1ii1iiIi1II = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiIiII , listitem = IIiiiI1iI , isFolder = True )
 return i1ii1iiIi1II
 if 100 - 100: IIII / IIII - I1Ii111 % I1Ii111 * IiII / IIIIII11i1I
def O0oOO0o ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 32 - 32: I1ii11iIi11i + iII111i - IiII + iII111i / OoOoOO00 * IiII
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 o0OoOoooo0 = [ ]
 iiIiII = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 IIiiiI1iI = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 IIiiiI1iI . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IIiiiI1iI . setProperty ( 'fanart_image' , fanart )
 IIiiiI1iI . setProperty ( 'IsPlayable' , 'true' )
 if 60 - 60: I1ii11iIi11i % IiII / Ii1I % IiII * II111iiii / i1I1i1Ii11
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  o0OoOoooo0 . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  IIiiiI1iI . addContextMenuItems ( o0OoOoooo0 , replaceItems = True )
 i1ii1iiIi1II = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiIiII , listitem = IIiiiI1iI )
 return i1ii1iiIi1II
 if 34 - 34: o0o0OOO0o0 - I1Ii111
def OoO0O000 ( name , url , mode , iconimage , fanart ) :
 if 25 - 25: IiII % I1ii11iIi11i + II111iiii + I1IiiI * OoO0O00
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 64 - 64: OoOoOO00
 iiIiII = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 IIiiiI1iI = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 IIiiiI1iI . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IIiiiI1iI . setProperty ( 'fanart_image' , fanart )
 IIiiiI1iI . setProperty ( 'IsPlayable' , 'true' )
 i1ii1iiIi1II = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiIiII , listitem = IIiiiI1iI )
 return i1ii1iiIi1II
 if 10 - 10: o0o0OOO0o0 % I1IiiI / I1ii11iIi11i % ooOoO0o
def iiII ( name , url , mode ) :
 if 28 - 28: IIII . OoO0O00 + Ii1I + o00O0oo % i1I1i1Ii11
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 80 - 80: oO0o
 iiIiII = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 IIiiiI1iI = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = II1Ii )
 IIiiiI1iI . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 IIiiiI1iI . setProperty ( 'fanart_image' , O0oOO0o0 )
 IIiiiI1iI . setProperty ( 'IsPlayable' , 'true' )
 i1ii1iiIi1II = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiIiII , listitem = IIiiiI1iI )
 return i1ii1iiIi1II
 if 86 - 86: iII111i * ooOoO0o . I11i / oO0o + IiII
def iiiiI1I ( name , url , mode , iconimage ) :
 iiIiII = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 i1ii1iiIi1II = True
 IIiiiI1iI = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1ii1iiIi1II = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiIiII , listitem = IIiiiI1iI , isFolder = True )
 return i1ii1iiIi1II
 if 93 - 93: oO0o * IiII + OOooOOo - o0o0OOO0o0 . iII111i + OoO0O00
def i1II11I11ii1 ( ) :
 if 64 - 64: IiII % I11i / o0oOOo0O0Ooo % IIII - i1I1i1Ii11
 if 2 - 2: o0o0OOO0o0 - iII111i + Ii1I * OOooOOo / i1I1i1Ii11
 if 26 - 26: I1Ii111 * oO0o
 ii11i = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 ii11i . doModal ( )
 if ( ii11i . isConfirmed ( ) ) :
  if 31 - 31: ooOoO0o * IiII . o00O0oo
  ooO = urllib . quote_plus ( ii11i . getText ( ) ) . replace ( '+' , ' ' )
  if 35 - 35: ooOoO0o
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 94 - 94: IIII / II111iiii % I1IiiI
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % ooO )
    if 70 - 70: ooOoO0o - oO0o / OoO0O00 % OoO0O00
    if Ii11iII1 == 'true' :
     if 95 - 95: OoO0O00 % OoO0O00 . o00O0oo
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + oOoO + "[/COLOR] ,10000)" )
     if 26 - 26: IiII + IIIIII11i1I - o0oOOo0O0Ooo . o0oOOo0O0Ooo + iII111i + I11i
   except :
    if 68 - 68: I1IiiI
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 76 - 76: iII111i
    if 99 - 99: Ii1I
    if 1 - 1: o00O0oo * I11i * OOooOOo + oO0o
O0Oo0iIIIi1IiI11I1 = iIi1i11 ( )
oOoO00O0 = None
oOoO = None
O0OOoOooO00 = None
II1Ii = None
id = None
OOIi1iI111II1I1 = None
if 89 - 89: IiII
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 87 - 87: i1I1i1Ii11 % oO0o
try :
 oOoO00O0 = urllib . unquote_plus ( O0Oo0iIIIi1IiI11I1 [ "url" ] )
except :
 pass
try :
 oOoO = urllib . unquote_plus ( O0Oo0iIIIi1IiI11I1 [ "name" ] )
except :
 pass
try :
 O0OOoOooO00 = int ( O0Oo0iIIIi1IiI11I1 [ "mode" ] )
except :
 pass
try :
 II1Ii = urllib . unquote_plus ( O0Oo0iIIIi1IiI11I1 [ "iconimage" ] )
except :
 pass
try :
 id = int ( O0Oo0iIIIi1IiI11I1 [ "id" ] )
except :
 pass
try :
 OOIi1iI111II1I1 = urllib . unquote_plus ( O0Oo0iIIIi1IiI11I1 [ "trailer" ] )
except :
 pass
 if 62 - 62: OOooOOo + IIII / i1I1i1Ii11 * II111iiii
 if 37 - 37: i1I1i1Ii11
print "Mode: " + str ( O0OOoOooO00 )
print "URL: " + str ( oOoO00O0 )
print "Name: " + str ( oOoO )
print "iconimage: " + str ( II1Ii )
print "id: " + str ( id )
print "trailer: " + str ( OOIi1iI111II1I1 )
if 33 - 33: OOooOOo - I1IiiI - OOooOOo
if O0OOoOooO00 == None or oOoO00O0 == None or len ( oOoO00O0 ) < 1 :
 if OOO00O == OOoOO0oo0ooO :
  if 94 - 94: IIIIII11i1I * ooOoO0o * OoO0O00 / Ii1I . IIIIII11i1I - Ii1I
  i1iI ( )
  O0o0 = oo000 . getSetting ( 'aviso' )
  if O0o0 == 'true' :
   oo0000ooooO0o ( )
   if 13 - 13: I1Ii111 / IIIIII11i1I - OOooOOo / I1Ii111 . OoOoOO00
   if 22 - 22: I1IiiI - ooOoO0o + o0o0OOO0o0 . o00O0oo * OoOoOO00
  iIi11Ii1 = oo000 . getSetting ( 'licencia_addon' )
  o00oooO0Oo = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  iiiI1i1111II = oo000 . getSetting ( 'key_ext' )
  o0O0OOO0Ooo = 'aHR0cDovL2JpdC5seS8yUjQxbmh1' . decode ( 'base64' )
  II11Ii1iI1iII = Oo0o00OO0000 ( o0O0OOO0Ooo )
  I1i = re . compile ( II1I ) . findall ( II11Ii1iI1iII )
  for IIII11iiii in I1i :
   try :
    if 75 - 75: Oo0Ooo % IIIIII11i1I + iII111i * I1IiiI . i1I1i1Ii11 - IIII
    if 32 - 32: o00O0oo % IiII - OoOoOO00
    iIi11Ii1 = oo000 . getSetting ( 'licencia_addon' )
    if 40 - 40: Oo0Ooo + i1I1i1Ii11 * I11i + IiII
    if 15 - 15: ooOoO0o % I1ii11iIi11i - Oo0Ooo * IIII
    if iIi11Ii1 == IIII11iiii :
     if 71 - 71: I11i % oO0o % IIII
     xbmcgui . Dialog ( ) . ok ( "Realstream Licencia:" , "[COLOR lime]Su llave es correcta![/COLOR] [COLOR gold]Sientese y disfrute de Realstream.[/COLOR]" )
     if 34 - 34: ooOoO0o / ooOoO0o % IIIIII11i1I . I11i / oO0o
     i1i1ii ( )
     if 99 - 99: IIII * I1ii11iIi11i - IIII % o00O0oo
    else :
     if 40 - 40: I1Ii111 / IIIIII11i1I / Oo0Ooo + o00O0oo
     xbmcgui . Dialog ( ) . ok ( "Realstream Licencia:" , "[COLOR red]Ha introducido una llave erronea.[/COLOR] [COLOR gold]Ponganse en contacto con nosotros en nuestro grupo de telegram.[/COLOR]" )
     if 59 - 59: ooOoO0o * OoO0O00 + I1Ii111 . Oo0Ooo / OoOoOO00
     if 75 - 75: ooOoO0o . I1Ii111 - Oo0Ooo * OOooOOo * i1I1i1Ii11
   except :
    pass
    if 93 - 93: IIII
 else :
  xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red][B]Error, de inicio. ¿Tienes Instalado Realstream?[/B][/COLOR]" )
  if 18 - 18: IIII
  if 66 - 66: IiII * II111iiii + I11i / I1Ii111
elif O0OOoOooO00 == 1 :
 IiIi1II111I ( oOoO , oOoO00O0 , id , OOIi1iI111II1I1 )
elif O0OOoOooO00 == 2 :
 III ( )
elif O0OOoOooO00 == 3 :
 O0OoOoO00O ( )
elif O0OOoOooO00 == 4 :
 i1iIiIii ( oOoO , oOoO00O0 )
elif O0OOoOooO00 == 5 :
 i1 ( )
elif O0OOoOooO00 == 6 :
 I11iIiI1 ( )
elif O0OOoOooO00 == 7 :
 Ooo ( )
elif O0OOoOooO00 == 8 :
 I11IIIiIi11 ( )
elif O0OOoOooO00 == 9 :
 oOO0oo ( )
elif O0OOoOooO00 == 10 :
 ooOoOOOOo ( )
elif O0OOoOooO00 == 11 :
 i1o0oooO ( )
elif O0OOoOooO00 == 12 :
 oo00ooOoo ( )
elif O0OOoOooO00 == 13 :
 I1ii1II1iII ( )
elif O0OOoOooO00 == 14 :
 II1 ( )
elif O0OOoOooO00 == 15 :
 o0o0oOO ( )
elif O0OOoOooO00 == 16 :
 O0Oo0 ( )
elif O0OOoOooO00 == 17 :
 oo0O0o00 ( )
elif O0OOoOooO00 == 18 :
 ooOo0O0O0oOO0 ( )
elif O0OOoOooO00 == 19 :
 iIiI1i ( )
elif O0OOoOooO00 == 20 :
 i1II11Iii1I ( )
elif O0OOoOooO00 == 21 :
 II11i1IiIII ( )
elif O0OOoOooO00 == 22 :
 i1iii1ii ( )
elif O0OOoOooO00 == 23 :
 OoO0O0oO00 ( )
elif O0OOoOooO00 == 24 :
 Ii ( )
elif O0OOoOooO00 == 25 :
 OOoooOoO0Oo ( )
elif O0OOoOooO00 == 26 :
 iiIiiii1i1i1i ( )
elif O0OOoOooO00 == 28 :
 IIii ( oOoO , oOoO00O0 )
elif O0OOoOooO00 == 98 :
 busqueda_global ( )
elif O0OOoOooO00 == 97 :
 IIIii11i1I ( )
elif O0OOoOooO00 == 99 :
 O0Ooo0oo ( )
elif O0OOoOooO00 == 100 :
 menu_player ( oOoO , oOoO00O0 )
elif O0OOoOooO00 == 111 :
 Iii1I1111ii ( )
elif O0OOoOooO00 == 115 :
 o0oOOOO0 ( oOoO00O0 )
elif O0OOoOooO00 == 116 :
 IiiiI ( )
elif O0OOoOooO00 == 119 :
 IiI11i1IIiiI ( )
elif O0OOoOooO00 == 120 :
 i1i1IIii1i1 ( )
elif O0OOoOooO00 == 121 :
 OoO ( )
elif O0OOoOooO00 == 125 :
 IiI1 ( )
elif O0OOoOooO00 == 112 :
 oOOoo ( )
elif O0OOoOooO00 == 127 :
 i1II11I11ii1 ( )
elif O0OOoOooO00 == 128 :
 TESTLINKS ( )
elif O0OOoOooO00 == 140 :
 Ooo0O ( )
elif O0OOoOooO00 == 141 :
 iIiI1I1IIi11 ( )
xbmcplugin . endOfDirectory ( oOOo ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
