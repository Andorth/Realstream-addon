# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 1.0.2
#
############################################
# Dependencias 
# Script ExtendedInfo
# Script Urlresolver de TVAddons
# Script ResolveURL Por Jsergio.
#
############################################
#
# Corregida fallo que producia cuelgue de kodi al realstream no encontrar un enlace.
# Adaptacion del codigo fuente a kodi 18.4
#
############################################
if 64 - 64: i11iIiiIii
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import urlresolver
import cookielib , base64
import requests
import plugintools
import config
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
IiII1IiiIiI1 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
o0OoOoOO00 = int ( sys . argv [ 1 ] )
I11i = 'gruponetai/'
O0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
Oo = O0O . getAddonInfo ( 'profile' )
I1ii11iIi11i = O0O . getAddonInfo ( 'path' )
I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
if 73 - 73: OOooOOo / ii11ii1ii
def O00ooOO ( ) :
 if 47 - 47: oO0ooO % iI1Ii11111iIi + ii1II11I1ii1I + oO0o0ooO0 - iiIIIII1i1iI
 o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 oo00 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 o00 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 Oo0oO0ooo = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 o0oOoO00o = i1 ( o00 )
 oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
 for i11 in oOOoo00O0O :
  try :
   if 41 - 41: O00o0o0000o0o . oOo0oooo00o * I1i1i1ii - IIIII
   if 26 - 26: O00OoOoo00 . iiiI11 / oooOOOOO * iI1Ii11111iIi / iiiI11
   o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 80 - 80: ii1II11I1ii1I . iiIIIII1i1iI
   if 34 - 34: O00o0o0000o0o % OoooooooOO / i1IIi . IIIII + O0
   if o0oO0 == i11 :
    if 42 - 42: O00o0o0000o0o / i1IIi + i11iIiiIii - I1i1i1ii
    if 78 - 78: oO0ooO
    if 18 - 18: O0 - IIIII / IIIII + oooOOOOO % oooOOOOO - O00OoOoo00
    O0O00Ooo ( )
    if 64 - 64: iiIIIII1i1iI - O0 / II111iiii / ii1II11I1ii1I / iIii1I11I1II1
   else :
    if 24 - 24: O0 % ii1II11I1ii1I + i1IIi + iiiI11 + oO0o0ooO0
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold]>El addon esta desactivado.[/COLOR]" )
    if 70 - 70: ii11ii1ii % ii11ii1ii . O00OoOoo00 % oO0ooO * ii1II11I1ii1I % iiIIIII1i1iI
    if 23 - 23: i11iIiiIii + OOooOOo
  except :
   pass
   if 68 - 68: iI1Ii11111iIi . iiIIIII1i1iI . i11iIiiIii
   if 40 - 40: iiIIIII1i1iI . iI1Ii11111iIi . ii11ii1ii . i1IIi
   if 33 - 33: I1i1i1ii + II111iiii % i11iIiiIii . oooOOOOO - OOooOOo
   if 66 - 66: I1i1i1ii - OoooooooOO * OoooooooOO . O00o0o0000o0o . oO0o0ooO0
if I1IiI == 'true' :
 if 22 - 22: OoooooooOO % oOo0oooo00o - IIIII . iIii1I11I1II1 * i11iIiiIii
 II1i1Ii11Ii11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.png' ) )
 iII11i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 O0O00o0OOO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 Ii1iIIIi1ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 o0oo0o0O00OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 o0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.png' ) )
 I1i1iii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.png' ) )
 i1iiI11I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'estrenos.png' ) )
 iiii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.png' ) )
 oO0o0O0OOOoo0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.png' ) )
 IiIiiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.png' ) )
 I1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.png' ) )
 oOO00oOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.png' ) )
 OoOo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.png' ) )
 iI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 o00O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.png' ) )
 OOO0OOO00oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.png' ) )
 Iii111II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.png' ) )
 iiii11I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.png' ) )
 Ooo0OO0oOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.png' ) )
 ii11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.png' ) )
 IIIii1II1II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'marvel.png' ) )
 i1I1iI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.png' ) )
 oo0OooOOo0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.png' ) )
 o0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.png' ) )
 O00oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.png' ) )
 I11i1I1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.png' ) )
 oO0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.png' ) )
 oOOoo0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.png' ) )
 o00OO00OoO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.png' ) )
 OOOO0OOoO0O0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.png' ) )
 O0Oo000ooO00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.png' ) )
 oO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.png' ) )
 Ii1iIiII1ii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.jpg' ) )
 ooOooo000oOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.jpg' ) )
 Oo0oOOo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
 Oo0OoO00oOO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 OOO00O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 OOoOO0oo0ooO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.png' ) )
 O0o0O00Oo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 O00O0oOO00O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 i1Oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
else :
 if 31 - 31: iiiI11 . iI1Ii11111iIi / O0
 if 89 - 89: iI1Ii11111iIi
 Oo0OoO00oOO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 O0o0O00Oo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
 II1i1Ii11Ii11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.jpg' ) )
 iII11i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 O0O00o0OOO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 Ii1iIIIi1ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 o0oo0o0O00OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 o0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.jpg' ) )
 I1i1iii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.jpg' ) )
 i1iiI11I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'encines.jpg' ) )
 iiii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.jpg' ) )
 oO0o0O0OOOoo0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.jpg' ) )
 IiIiiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.jpg' ) )
 I1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.jpg' ) )
 oOO00oOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.jpg' ) )
 OoOo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.jpg' ) )
 iI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 o00O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.jpg' ) )
 OOO0OOO00oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.jpg' ) )
 Iii111II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.jpg' ) )
 iiii11I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.jpg' ) )
 Ooo0OO0oOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.jpg' ) )
 ii11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.jpg' ) )
 IIIii1II1II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'superheroes.jpg' ) )
 i1I1iI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.jpg' ) )
 oo0OooOOo0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.jpg' ) )
 o0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.jpg' ) )
 O00oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.jpg' ) )
 I11i1I1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.jpg' ) )
 oO0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.jpg' ) )
 oOOoo0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.jpg' ) )
 o00OO00OoO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.jpg' ) )
 OOOO0OOoO0O0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.jpg' ) )
 O0Oo000ooO00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.jpg' ) )
 oO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.jpg' ) )
 Ii1iIiII1ii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.jpg' ) )
 ooOooo000oOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.jpg' ) )
 OOO00O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 OOoOO0oo0ooO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.jpg' ) )
 Oo0oOOo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favoritos.png' ) )
 O00O0oOO00O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 i1Oo00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
 if 68 - 68: oO0ooO * OoooooooOO % O0 + oO0ooO + oooOOOOO
 if 4 - 4: oooOOOOO + O0 * O00o0o0000o0o
 if 55 - 55: ii11ii1ii + iIii1I11I1II1 / iI1Ii11111iIi * iiIIIII1i1iI - i11iIiiIii - I1i1i1ii
 if 25 - 25: oO0o0ooO0
 if 7 - 7: i1IIi / OOooOOo * iiiI11 . O00OoOoo00 . iIii1I11I1II1
iIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'peliculas.png' ) )
ooo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series.png' ) )
oOoO0o00OO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ajustes.png' ) )
i1I1ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'videoteca.png' ) )
oOOo0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
oo00O00oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'resolver.png' ) )
iIiIIIi = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'test.png' ) )
ooo00OOOooO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'video-tutoriales.png' ) )
O00OOOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'proxy.png' ) )
if 77 - 77: IIIII % IIIII * iiIIIII1i1iI - i11iIiiIii
Oo0oO = IiII1IiiIiI1 . getSetting ( 'mostrar_cat' )
IIiIi1iI = IiII1IiiIiI1 . getSetting ( 'videos' )
i1IiiiI1iI = IiII1IiiIiI1 . getSetting ( 'activar' )
i1iIi = IiII1IiiIiI1 . getSetting ( 'favcopy' )
ooOOoooooo = IiII1IiiIiI1 . getSetting ( 'anticopia' )
o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
O0i1II1Iiii1I11 = IiII1IiiIiI1 . getSetting ( 'mostrar_bus' )
IIII = IiII1IiiIiI1 . getSetting ( 'restante' )
iiIiI = IiII1IiiIiI1 . getSetting ( 'selecton' )
o00oooO0Oo = IiII1IiiIiI1 . getSetting ( 'aviso' )
o0O0OOO0Ooo = IiII1IiiIiI1 . getSetting ( 'RealStream_Settings' )
iiIiII1 = IiII1IiiIiI1 . getSetting ( 'Resolver_Settings' )
IIII = IiII1IiiIiI1 . getSetting ( 'restante' )
OOO00O0O = IiII1IiiIiI1 . getSetting ( 'fav' )
iii = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
oOooOOOoOo = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
i1Iii1i1I = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
OOoO00 = 'bienvenida'
IiI111111IIII = 'bienvenida'
copyright = IiII1IiiIiI1 . getSetting ( 'copyright' )
i1Ii = 'cGx1Z2luLnZpZGVvLg==' . decode ( 'base64' ) + copyright
ii111iI1iIi1 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
OOO = IiII1IiiIiI1 . getSetting ( 'Forceupdate' )
if OOO == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
oo0OOo0 = 'LnR4dA==' . decode ( 'base64' )
if 47 - 47: iiiI11 + iI1Ii11111iIi * ii11ii1ii / oooOOOOO - IIIII % iIii1I11I1II1
IIi11i1i1iI1 = 'aHR0cDovL2JpdC5seS8yU1FOSnlP' . decode ( 'base64' )
iiiIi1 = i1Iii1i1I + OOoO00 + oo0OOo0
i1I1ii11i1Iii = 'http://www.youtube.com'
I1IiiiiI = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
o0OIiII = '.xsl.pt'
ii1iII1II = 'L21hc3Rlci8=' . decode ( 'base64' )
Iii1I1I11iiI1 = I1IiiiiI + o0OIiII
I1I1i1I = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*texto3=[\'"](.*?)[\'"]\s*'
ii1I = 'tvg-logo=[\'"](.*?)[\'"]'
if 99 - 99: I1i1i1ii / ii11ii1ii / O00OoOoo00 % OOooOOo
i11I1II1I11i = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)'
OooOoOO0 = '(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)'
iI1i11iII111 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
Iii1IIII11I = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
OOOoo0OO = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
oO0o0 = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
iI1Ii11iIiI1 = '#(.+?),(.+)\s*(.+)'
OO0Oooo0oOO0O = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
if 62 - 62: OOooOOo
O00o0OO0 = 'source src=[\'"](.*?)[\'"]\s*title=[\'"](.*?)[\'"]'
IIi1I1iiiii = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
o00oOOooOOo0o = '[\'"](.*?)[\'"]'
O0O0ooOOO = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
oOOo0O00o = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( 'base64' )
iIiIi11 = oOOo0O00o + I11i
i1111 = '[\'"](.*?)[\'"]'
OOOiiiiI = 'UmVhbHN0cmVhbQ==' . decode ( 'base64' )
oooOo0OOOoo0 = 'video=[\'"](.*?)[\'"]'
oo00 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
o00 = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( 'base64' ) + oo00
OOoO = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
OO0O000 = '0110R0N' . replace ( '0110R0N' , 'R0N' )
iiIiI1i1 = 'aHR0cDovL2JpdC5seS8yWEIx' . decode ( 'base64' ) + OO0O000
oO0O00oOOoooO = '0110pEJ' . replace ( '0110pEJ' , 'pEJ' )
IiIi11iI = 'aHR0cDovL2JpdC5seS8yd1Nh' . decode ( 'base64' ) + oO0O00oOOoooO
Oo0O00O000 = 'ABBAOb5' . replace ( 'ABBAOb5' , 'Ob5' )
i11I1IiII1i1i = 'aHR0cDovL2JpdC5seS8yRVhV' . decode ( 'base64' ) + Oo0O00O000
oo = '0110jaw' . replace ( '0110jaw' , 'jaw' )
I1111i = 'aHR0cDovL2JpdC5seS8yd01M' . decode ( 'base64' ) + oo
iIIii = '01109DI' . replace ( '01109DI' , '9DI' )
o00O0O = 'aHR0cDovL2JpdC5seS8ySXgz' . decode ( 'base64' ) + iIIii
ii1iii1i = '01103hs' . replace ( '01103hs' , '3hs' )
Iii1I1111ii = 'aHR0cDovL2JpdC5seS8zMW1U' . decode ( 'base64' ) + ii1iii1i
ooOoO00 = '01107DW' . replace ( '01107DW' , '7DW' )
Ii1IIiI1i = 'aHR0cDovL2JpdC5seS8yV1ln' . decode ( 'base64' ) + ooOoO00
o0O00Oo0 = '0110mLl' . replace ( '0110mLl' , 'mLl' )
IiII111i1i11 = 'aHR0cDovL2JpdC5seS8yS0cw' . decode ( 'base64' ) + o0O00Oo0
i111iIi1i1II1 = '01102Hj' . replace ( '01102Hj' , '2Hj' )
oooO = 'aHR0cDovL2JpdC5seS8yWEJo' . decode ( 'base64' ) + i111iIi1i1II1
i1I1i111Ii = '0110fXg' . replace ( '0110fXg' , 'fXg' )
ooo = 'aHR0cDovL2JpdC5seS8ySTVy' . decode ( 'base64' ) + i1I1i111Ii
i1i1iI1iiiI = '0110NMH' . replace ( '0110NMH' , 'NMH' )
Ooo0oOooo0 = 'aHR0cDovL2JpdC5seS8yd0t6' . decode ( 'base64' ) + i1i1iI1iiiI
oOOOoo00 = '0110bwQ' . replace ( '0110bwQ' , 'bwQ' )
iiIiIIIiiI = 'aHR0cDovL2JpdC5seS8yd01V' . decode ( 'base64' ) + oOOOoo00
iiI1IIIi = '0110xzG' . replace ( '0110xzG' , 'xzG' )
II11IiIi11 = 'aHR0cDovL2JpdC5seS8yWHhz' . decode ( 'base64' ) + iiI1IIIi
II = '0110x64' . replace ( '0110x64' , 'x64' )
OOO0O00O0OOOO = 'aHR0cDovL2JpdC5seS8yRVlF' . decode ( 'base64' ) + II
I1iiii1I = '0110vUE' . replace ( '0110vUE' , 'vUE' )
OOo0 = 'aHR0cDovL2JpdC5seS8yWmhW' . decode ( 'base64' ) + I1iiii1I
oO00ooooO0o = '01107ZL' . replace ( '01107ZL' , '7ZL' )
oo0o = 'aHR0cDovL2JpdC5seS8yWm4w' . decode ( 'base64' ) + oO00ooooO0o
o0oO0oooOoo = '01106cf' . replace ( '01106cf' , '6cf' )
I1III1111iIi = 'aHR0cDovL2JpdC5seS8yRVlk' . decode ( 'base64' ) + o0oO0oooOoo
I1i111I = '0110Jtp' . replace ( '0110Jtp' , 'Jtp' )
Ooo = 'aHR0cDovL2JpdC5seS8yV3Nq' . decode ( 'base64' ) + I1i111I
Oo0oo0O0o00O = '0110a5b' . replace ( '0110a5b' , 'a5b' )
I1i11 = 'aHR0cDovL2JpdC5seS8yV3dj' . decode ( 'base64' ) + Oo0oo0O0o00O
IiIi1I1 = '0110Q7u' . replace ( '0110Q7u' , 'Q7u' )
IiIIi1 = 'aHR0cDovL2JpdC5seS8yV3NL' . decode ( 'base64' ) + IiIi1I1
IIIIiii1IIii = '0110rsq' . replace ( '0110rsq' , 'rsq' )
II1i11I = 'aHR0cDovL2JpdC5seS8ySzhE' . decode ( 'base64' ) + IIIIiii1IIii
ii1I1IIii11 = '0110DDR' . replace ( '0110DDR' , 'DDR' )
O0o0oO = 'aHR0cDovL2JpdC5seS8ySzd5' . decode ( 'base64' ) + ii1I1IIii11
IIIIiIiIi1 = '0110feQ' . replace ( '0110feQ' , 'feQ' )
I11iiiiI1i = 'aHR0cDovL2JpdC5seS8yS0cz' . decode ( 'base64' ) + IIIIiIiIi1
iI1i11 = '0110MHY' . replace ( '0110MHY' , 'MHY' )
OoOOoooOO0O = 'aHR0cDovL2JpdC5seS8ySXVo' . decode ( 'base64' ) + iI1i11
ooo00Ooo = '0110xdb' . replace ( '0110xdb' , 'xdb' )
Oo0o0O00 = 'aHR0cDovL2JpdC5seS8yWEJu' . decode ( 'base64' ) + ooo00Ooo
ii1 = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( 'base64' )
i1Ii = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
I1i11OO = '0110lxu' . replace ( '0110lxu' , 'lxu' )
o0O0oo0OO0O = 'aHR0cDovL2JpdC5seS8yV1Bj' . decode ( 'base64' ) + I1i11OO
OO0 = '0110pzp' . replace ( '0110pzp' , 'pzp' )
o0Oooo = 'aHR0cDovL2JpdC5seS8yVHpB' . decode ( 'base64' ) + OO0
iiI = '01105yt' . replace ( '01105yt' , '5yt' )
oO = 'aHR0cDovL2JpdC5seS8yTVpp' . decode ( 'base64' ) + iiI
if 10 - 10: ii11ii1ii / ii11ii1ii / iiiI11 . iiiI11
if 98 - 98: ii11ii1ii / OOooOOo . O0 + oO0ooO
ii = '1001DTs' . replace ( '1001DTs' , 'DTs' )
Iiii1iI1i = 'aHR0cDovL2JpdC5seS8ySzhP' . decode ( 'base64' ) + ii
I1ii1ii11i1I = '1001Hky' . replace ( '1001Hky' , 'Hky' )
o0OoOO = 'aHR0cDovL2JpdC5seS8yTGVL' . decode ( 'base64' ) + I1ii1ii11i1I
O0O0Oo00 = '1001VFU' . replace ( '1001VFU' , 'VFU' )
oOoO00o = 'aHR0cDovL2JpdC5seS8zMERx' . decode ( 'base64' ) + O0O0Oo00
oO00O0 = '3545OMZ' . replace ( '3545OMZ' , 'OMZ' )
IIi1IIIi = 'aHR0cDovL2JpdC5seS8yazhk' . decode ( 'base64' ) + oO00O0
if 99 - 99: I1i1i1ii + oO0ooO * II111iiii . ii1II11I1ii1I - oO0o0ooO0
def o0OOOo ( ) :
 if 11 - 11: iIii1I11I1II1 * iIii1I11I1II1 * OOooOOo
 if 46 - 46: iI1Ii11111iIi + oO0ooO
 try :
  if 70 - 70: IIIII / iIii1I11I1II1
  o0oOoO00o = i1 ( iiIiI1i1 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   try :
    if 19 - 19: i11iIiiIii + OoooooooOO - ii11ii1ii - oOo0oooo00o
    IiIi11iI = Oo0oooO0oO
    if 21 - 21: O0 % O00OoOoo00 . OOooOOo / II111iiii + O00OoOoo00
    OOOO0O00o = xbmc . Keyboard ( '' , 'Busqueda por titulo' )
    OOOO0O00o . doModal ( )
    if ( OOOO0O00o . isConfirmed ( ) ) :
     if 62 - 62: iIii1I11I1II1
     i1II = urllib . quote_plus ( OOOO0O00o . getText ( ) ) . replace ( '+' , ' ' )
     iI1I = i1 ( IiIi11iI )
     oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( iI1I )
     if 100 - 100: iIii1I11I1II1 + iI1Ii11111iIi / ii11ii1ii . i11iIiiIii
     for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
      if re . search ( i1II , iiIi1i ( i1Iii11I1i . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
       if 77 - 77: oO0o0ooO0 + oO0ooO / iiIIIII1i1iI + O0 * ii1II11I1ii1I
   except :
    pass
 except :
  pass
  if 28 - 28: oooOOOOO + i11iIiiIii / oOo0oooo00o % iI1Ii11111iIi % ii11ii1ii - O0
  if 54 - 54: i1IIi + II111iiii
  if 83 - 83: oO0o0ooO0 - OOooOOo + O00o0o0000o0o
def iIi1Ii1i1iI ( ) :
 if 16 - 16: O00o0o0000o0o / ii11ii1ii / OoooooooOO * OOooOOo + i1IIi % O00o0o0000o0o
 o00oooO0Oo = IiII1IiiIiI1 . getSetting ( 'aviso' )
 if o00oooO0Oo == 'true' :
  o0oOoO00o = i1 ( iiiIi1 )
  oOOoo00O0O = re . compile ( I1I1i1I ) . findall ( o0oOoO00o )
  for ooo0o00 , ooO , o0o00 in oOOoo00O0O :
   try :
    if 14 - 14: ii1II11I1ii1I . O00o0o0000o0o . oOo0oooo00o + OoooooooOO - O00o0o0000o0o + O00OoOoo00
    if 9 - 9: I1i1i1ii
    oooooOOO000Oo = ooo0o00
    Ooo00OoOOO = ooO
    Oo0OO0000oooo = o0o00
    if 7 - 7: iiIIIII1i1iI - oO0ooO - O0 % iiIIIII1i1iI - II111iiii
    if 31 - 31: IIIII / ii11ii1ii - IIIII - O00o0o0000o0o
    I1iiIIIi11 = "[B]" + oooooOOO000Oo + "[/B]"
    Ii1I11ii1i = "" + Ooo00OoOOO + ""
    O0iIiIIIIIii = "" + Oo0OO0000oooo + ""
    if 58 - 58: ii1II11I1ii1I / O00OoOoo00 . iI1Ii11111iIi / OoooooooOO + iiiI11
    xbmcgui . Dialog ( ) . ok ( "Real Stream" , I1iiIIIi11 , Ii1I11ii1i , O0iIiIIIIIii )
    if 86 - 86: oOo0oooo00o * OOooOOo + oOo0oooo00o + II111iiii
   except :
    pass
    if 8 - 8: iiiI11 - IIIII / oooOOOOO
    if 96 - 96: iI1Ii11111iIi
 IIiiI = i1 ( ii1 )
 oOOoo00O0O = re . compile ( o00oOOooOOo0o ) . findall ( IIiiI )
 for III1i11 in oOOoo00O0O :
  try :
   if 25 - 25: oO0ooO
   import xbmc
   import xbmcaddon
   if 24 - 24: O00OoOoo00 * i11iIiiIii * O00o0o0000o0o
   __addon__ = xbmcaddon . Addon ( )
   __addonname__ = __addon__ . getAddonInfo ( 'name' )
   __icon__ = __addon__ . getAddonInfo ( 'icon' )
   if 85 - 85: ii1II11I1ii1I . iI1Ii11111iIi / oooOOOOO . O0 % iiiI11
   iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
   OO0ooo0oOO = III1i11
   if 97 - 97: OOooOOo / IIIII
   I1iiIIIi11 = "[COLOR orange]Version instalada: [COLOR gold] " + iIiiiI1IiI1I1 + " [/COLOR][/COLOR]"
   Oooo0 = 5000
   if 59 - 59: OoooooooOO
   xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , I1iiIIIi11 , Oooo0 , __icon__ ) )
   if 47 - 47: oooOOOOO - OOooOOo / II111iiii
   if 12 - 12: O00o0o0000o0o
   if iIiiiI1IiI1I1 < OO0ooo0oOO :
    if 83 - 83: IIIII . O0 / ii11ii1ii / O00o0o0000o0o - II111iiii
    xbmcgui . Dialog ( ) . ok ( "[B][COLOR fuchsia]Realstream:[/COLOR][/B]" , "[COLOR orange]Ya esta disponible la nueva version  [B][/COLOR][COLOR lime]" + III1i11 + "[/B][/COLOR][COLOR orange] Puedes actualizarla desde el repositorio Realstream, sino se actualiza sola.[/COLOR]" )
    xbmcgui . Dialog ( ) . ok ( "[B][COLOR fuchsia]Realstream: " + iIiiiI1IiI1I1 + "[/COLOR][/B]" , "[COLOR gold]Actualmente tiene instalada la version:  [/COLOR][COLOR lime][B]" + iIiiiI1IiI1I1 + "[/B][/COLOR]" , "[COLOR orange]Por favor actualiza desde el repositorio o bien configuralo para que se actualize automaticamente.[/COLOR]" )
  except :
   pass
 if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
  if 100 - 100: oO0ooO
  if 46 - 46: iI1Ii11111iIi / iIii1I11I1II1 % IIIII . iIii1I11I1II1 * IIIII
  if 38 - 38: oO0o0ooO0 - IIIII / O0 . iiiI11
def iiIi1i ( s ) :
 if 45 - 45: iiiI11
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 83 - 83: iI1Ii11111iIi . OoooooooOO
def Oo0ooo ( file ) :
 if 28 - 28: iiIIIII1i1iI . II111iiii / oO0o0ooO0 + II111iiii . OoooooooOO . O00OoOoo00
 try :
  O000OOO0OOo = open ( file , 'r' )
  o0oOoO00o = O000OOO0OOo . read ( )
  O000OOO0OOo . close ( )
  return o0oOoO00o
 except :
  pass
  if 32 - 32: I1i1i1ii * O0
def i1 ( url ) :
 if 100 - 100: oooOOOOO % iIii1I11I1II1 * II111iiii - IIIII
 try :
  oo00O00oO000o = urllib2 . Request ( url )
  oo00O00oO000o . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  OOo00OoO = urllib2 . urlopen ( oo00O00oO000o )
  iIi1 = OOo00OoO . read ( )
  OOo00OoO . close ( )
  return iIi1
 except urllib2 . URLError , i11iiI1111 :
  print 'We failed to open "%s".' % url
  if hasattr ( i11iiI1111 , 'code' ) :
   print 'We failed with error code - %s.' % i11iiI1111 . code
  if hasattr ( i11iiI1111 , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , i11iiI1111 . reason
   if 97 - 97: ii11ii1ii * OOooOOo . iIii1I11I1II1
def I1Ii1111iIi ( url ) :
 oo00O00oO000o = urllib2 . Request ( url )
 oo00O00oO000o . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 oo00O00oO000o . add_header ( 'Referer' , '%s' % url )
 oo00O00oO000o . add_header ( 'Connection' , 'keep-alive' )
 OOo00OoO = urllib2 . urlopen ( oo00O00oO000o )
 iIi1 = OOo00OoO . read ( )
 OOo00OoO . close ( )
 return iIi1
 if 31 - 31: oOo0oooo00o . iiiI11 * oooOOOOO + i11iIiiIii * iiIIIII1i1iI
 if 93 - 93: oO0o0ooO0 / iIii1I11I1II1 * i1IIi % OoooooooOO * O0 * oOo0oooo00o
def Ooooooo ( ) :
 if 39 - 39: O00OoOoo00 * ii11ii1ii + iIii1I11I1II1 - O00OoOoo00 + O00o0o0000o0o
 oOooOOOoOo = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 if 69 - 69: O0
 if i1IiiiI1iI == 'true' :
  if 85 - 85: oooOOOOO / O0
  iI1iIIIi1i ( '[COLOR %s]Buscar Pelicula[/COLOR]' % oOooOOOoOo , 'search' , 111 , O00O0oOO00O00 , II1i1Ii11Ii11 )
  iI1iIIIi1i ( '[COLOR %s]Buscar Serie[/COLOR]' % oOooOOOoOo , 'search' , 145 , i1Oo00 , II1i1Ii11Ii11 )
  iI1iIIIi1i ( '[COLOR %s]Peliculas[/COLOR] ' % oOooOOOoOo , 'movieDB' , 116 , iIii , II1i1Ii11Ii11 )
  iI1iIIIi1i ( '[COLOR %s]Series[/COLOR] ' % oOooOOOoOo , 'movieDB' , 117 , ooo0O , II1i1Ii11Ii11 )
  if 89 - 89: iIii1I11I1II1
  if 21 - 21: oOo0oooo00o % oOo0oooo00o
 if o0O0OOO0Ooo == 'true' :
  iI1iIIIi1i ( '[COLOR %s]Ajustes[/COLOR]' % oOooOOOoOo , 'Settings' , 119 , oOoO0o00OO0 , II1i1Ii11Ii11 )
  if 27 - 27: i11iIiiIii / oO0o0ooO0
  if 84 - 84: ii11ii1ii
  if Oo0oO == 'true' :
   iIiiiii1i ( )
   if 40 - 40: O0 - OoooooooOO - O00OoOoo00
  if iiIiII1 == 'true' :
   iIiii ( )
   OOOO00OO0O0 ( )
   if 48 - 48: iiiI11
  if ooOOoooooo == 'false' :
   if 72 - 72: IIIII * iiIIIII1i1iI % I1i1i1ii . OoooooooOO
   I1iiIIIi11 = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   Ii1I11ii1i = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Script.ResolveURL para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   O0iIiIIIIIii = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 99 - 99: iIii1I11I1II1 % oooOOOOO + oooOOOOO + IIIII - iiiI11 / iiiI11
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , I1iiIIIi11 , Ii1I11ii1i , O0iIiIIIIIii )
   if 7 - 7: OOooOOo + iI1Ii11111iIi / O00OoOoo00
def OOOoO000 ( ) :
 iI1iIIIi1i ( '[COLOR orange]Buscador por id[/COLOR]' , i1I1ii11i1Iii , 127 , o0oO , II1i1Ii11Ii11 )
 if 57 - 57: II111iiii
def oOOOoo ( ) :
 oOooOOOoOo = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 iI1iIIIi1i ( '[COLOR %s]The movie DB[/COLOR]' % oOooOOOoOo , 'movieDB' , 99 , o0oO , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Buscador por id[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 127 , o0oO , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Video tutoriales[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 125 , ooo00OOOooO , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Autorizar OPENLOAD[/COLOR]' % oOooOOOoOo , 'movieDB' , 97 , o0oo0o0O00OO , II1i1Ii11Ii11 )
 if 15 - 15: i11iIiiIii % OOooOOo * oOo0oooo00o / iiiI11
def O0O00Ooo ( ) :
 if 90 - 90: IIIII
 Ooooooo ( )
 oOOOoo ( )
 if 31 - 31: O00o0o0000o0o + O0
 if 87 - 87: oooOOOOO
 if 45 - 45: oO0ooO / OoooooooOO - IIIII / I1i1i1ii % O00OoOoo00
 if 83 - 83: OOooOOo . iIii1I11I1II1 - O00OoOoo00 * i11iIiiIii
 if 20 - 20: i1IIi * iiiI11 + II111iiii % ii1II11I1ii1I % iiIIIII1i1iI
 if 13 - 13: ii11ii1ii
 if 60 - 60: oO0o0ooO0 * OOooOOo
 if 17 - 17: O00o0o0000o0o % ii11ii1ii / oO0o0ooO0 . O00OoOoo00 * O00o0o0000o0o - II111iiii
 if 41 - 41: I1i1i1ii
 if 77 - 77: iiiI11
 if 65 - 65: II111iiii . OOooOOo % iiIIIII1i1iI * oO0ooO
def iI11I ( ) :
 I1IIIiii1 = xbmcgui . Dialog ( )
 O00oo = (
 O0OO00O0oOO ,
 Ii1iI111 ,
 )
 if 51 - 51: O00OoOoo00 * O0 / II111iiii . I1i1i1ii % O00o0o0000o0o / OOooOOo
 ii1iii1I1I = I1IIIiii1 . select ( '[B][COLOR=yellow]Listado de Proxys Gratuitos:[/COLOR][/B]' , [
 '[COLOR=orange]                      Accede a la web[/COLOR]' ,

 '[B][COLOR=gold]                      Volver al Menu [/COLOR][/B]' , ] )
 if 95 - 95: O00OoOoo00
 if ii1iii1I1I :
  if 51 - 51: II111iiii + O00OoOoo00 . i1IIi . oO0o0ooO0 + iI1Ii11111iIi * OOooOOo
  if ii1iii1I1I < 0 :
   return
  OOoOoo0 = O00oo [ ii1iii1I1I - 2 ]
  return OOoOoo0 ( )
 else :
  OOoOoo0 = O00oo [ ii1iii1I1I ]
  return OOoOoo0 ( )
 return
 if 17 - 17: I1i1i1ii + iiIIIII1i1iI . oO0ooO - ii11ii1ii * i11iIiiIii
def iioOo0OoOOo0 ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 30 - 30: oO0o0ooO0 % OOooOOo
O0Oo00 = iioOo0OoOOo0 ( )
if 41 - 41: iIii1I11I1II1 % oOo0oooo00o
def O0OO00O0oOO ( ) :
 if O0Oo00 == 'android' :
  oOo0oO = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://hidemyna.me/es/proxy-list/?country=ES&type=hs#list' ) )
  if 5 - 5: O00o0o0000o0o - O00o0o0000o0o . ii11ii1ii + iI1Ii11111iIi - O00o0o0000o0o . iiIIIII1i1iI
 else :
  oOo0oO = webbrowser . open ( 'https://hidemyna.me/es/proxy-list/?country=ES&type=hs#list' )
  if 31 - 31: II111iiii - iIii1I11I1II1 - iIii1I11I1II1 % oOo0oooo00o
  if 12 - 12: iIii1I11I1II1
def Ii1iI111 ( ) :
 if 20 - 20: ii1II11I1ii1I / i1IIi
 O0O00Ooo ( )
 if 71 - 71: iI1Ii11111iIi . i1IIi
 if 94 - 94: O00o0o0000o0o . iiiI11
def OoO ( ) :
 if xbmc . getCondVisibility ( 'System.HasAddon(script.favourites)' ) :
  try :
   xbmc . executebuiltin ( "RunScript(script.favourites)" )
  except :
   pass
def oo0oO ( ) :
 IiII1IiiIiI1 . openSettings ( )
 if 10 - 10: II111iiii . IIIII
 if 32 - 32: I1i1i1ii . O00OoOoo00 . OoooooooOO - oO0ooO + iiIIIII1i1iI
def ooO0oO00O0o ( ) :
 urlresolver . display_settings ( )
 if 70 - 70: iiiI11
def iIiii ( ) :
 iI1iIIIi1i ( '[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % oOooOOOoOo , 'resolve' , 120 , oo00O00oO , II1i1Ii11Ii11 )
 if 16 - 16: IIIII - OoooooooOO % ii11ii1ii
def i11i1iIiii ( ) :
 if 71 - 71: oO0o0ooO0 % oooOOOOO - OOooOOo % oOo0oooo00o - O0
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 67 - 67: O00o0o0000o0o + ii11ii1ii
def OOOO00OO0O0 ( ) :
 iI1iIIIi1i ( '[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % oOooOOOoOo , 'resolve' , 140 , oo00O00oO , II1i1Ii11Ii11 )
 if 84 - 84: O0 * OoooooooOO - O00OoOoo00 * O00OoOoo00
def iIiiiii1i ( ) :
 if 8 - 8: oooOOOOO / i1IIi . iiIIIII1i1iI
 oOooOOOoOo = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 iI1iIIIi1i ( '[COLOR %s]Buscador[/COLOR]' % oOooOOOoOo , 'search' , 111 , Ii1iIIIi1ii , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Estrenos[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 3 , i1iiI11I , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Todas[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 26 , iiii , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]4K[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 141 , O0Oo000ooO00 , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Novedades[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 2 , I1i1iii , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Accion[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 5 , oO0o0O0OOOoo0 , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Animacion[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 6 , IiIiiI , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Artes Marciales[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 29 , Oo0OoO00oOO0o , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Aventuras[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 7 , I1I , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Belico[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 8 , oOO00oOO , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Ciencia Ficcion[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 9 , OoOo , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Cine Clasico[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 30 , iI , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Comedia[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 10 , o00O , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Crimen[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 11 , OOO0OOO00oo , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Drama[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 12 , Iii111II , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Familiar[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 13 , iiii11I , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Fantasia[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 14 , Ooo0OO0oOO , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Historia[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 15 , ii11i1 , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Misterio[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 16 , i1I1iI , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Musical[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 17 , oo0OooOOo0 , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Romance[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 18 , o0O , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Thriller[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 19 , oOOoo0Oo , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Suspense[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 20 , I11i1I1I , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Terror[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 21 , oO0Oo , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Western[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 22 , o00OO00OoO , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Spain[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 23 , O00oO , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Super heroes[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 24 , IIIii1II1II , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Sagas[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 25 , OOOO0OOoO0O0 , II1i1Ii11Ii11 )
 if 41 - 41: IIIII + oO0ooO
def oOO ( ) :
 if 11 - 11: i11iIiiIii - iiIIIII1i1iI . iiIIIII1i1iI
 iI1iIIIi1i ( '[COLOR %s]Buscar Serie[/COLOR]' % oOooOOOoOo , 'search' , 145 , Ii1iIiII1ii1 , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]En emision[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 150 , OOO00O , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Mejor valoradas[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 151 , OOoOO0oo0ooO , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Series Retro[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 152 , O0o0O00Oo0o0 , II1i1Ii11Ii11 )
 iI1iIIIi1i ( '[COLOR %s]Todas[/COLOR]' % oOooOOOoOo , i1I1ii11i1Iii , 142 , ooOooo000oOO , II1i1Ii11Ii11 )
 if 31 - 31: O00o0o0000o0o / ii11ii1ii * i1IIi . iI1Ii11111iIi
def OO0o0oO ( ) :
 if 83 - 83: ii1II11I1ii1I / i11iIiiIii % iIii1I11I1II1 . oOo0oooo00o % iiIIIII1i1iI . OoooooooOO
 if 94 - 94: I1i1i1ii + iIii1I11I1II1 % oO0ooO
 try :
  if 93 - 93: I1i1i1ii - O00o0o0000o0o + iIii1I11I1II1 * ii1II11I1ii1I + iiiI11 . IIIII
  IiI1iII1II111 = i1 ( Iiii1iI1i )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( IiI1iII1II111 )
  for Oo0oooO0oO in oOOoo00O0O :
   if 28 - 28: iI1Ii11111iIi * oO0ooO . oOo0oooo00o % oOo0oooo00o / oOo0oooo00o * iiiI11
   try :
    if 64 - 64: II111iiii - OOooOOo
    O0O0ooOOOo0o00Ooo0o = Oo0oooO0oO
    OOOO0O00o = xbmc . Keyboard ( '' , 'Buscar' )
    OOOO0O00o . doModal ( )
    if ( OOOO0O00o . isConfirmed ( ) ) :
     if 76 - 76: II111iiii
     i1II = urllib . quote_plus ( OOOO0O00o . getText ( ) ) . replace ( '+' , ' ' )
     IIiiI = i1 ( O0O0ooOOOo0o00Ooo0o )
     oOOoo00O0O = re . compile ( iI1i11iII111 ) . findall ( IIiiI )
     for iII11i , i1Iii11I1i , II1i1Ii11Ii11 , Oo00o0OO0O00o in oOOoo00O0O :
      if re . search ( i1II , iiIi1i ( i1Iii11I1i . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       iI1iIIIi1i ( i1Iii11I1i , Oo00o0OO0O00o , 143 , iII11i , II1i1Ii11Ii11 )
       if 26 - 26: II111iiii % i11iIiiIii % iIii1I11I1II1 % oOo0oooo00o * oOo0oooo00o * oO0o0ooO0
   except :
    pass
 except :
  pass
  if 24 - 24: II111iiii % iiiI11 - oooOOOOO + OOooOOo * oO0o0ooO0
def i11111I1I ( ) :
 if 61 - 61: II111iiii * O00o0o0000o0o / OoooooooOO / ii11ii1ii - oO0ooO
 try :
  if 56 - 56: oO0o0ooO0
  IiI1iII1II111 = i1 ( IIi1IIIi )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( IiI1iII1II111 )
  for Oo0oooO0oO in oOOoo00O0O :
   if 26 - 26: OoooooooOO % OoooooooOO
   try :
    if 33 - 33: iiiI11
    O0O0ooOOOo0o00Ooo0o = Oo0oooO0oO
    if 62 - 62: oO0o0ooO0 + I1i1i1ii + i1IIi / OoooooooOO
   except :
    pass
    if 7 - 7: ii1II11I1ii1I + i1IIi . OOooOOo / ii11ii1ii
  IIiiI = i1 ( O0O0ooOOOo0o00Ooo0o )
  oOOoo00O0O = re . compile ( iI1i11iII111 ) . findall ( IIiiI )
  for iII11i , i1Iii11I1i , II1i1Ii11Ii11 , Oo00o0OO0O00o in oOOoo00O0O :
   try :
    if 22 - 22: oooOOOOO - oooOOOOO % O00o0o0000o0o . iiiI11 + iiIIIII1i1iI
    iI1iIIIi1i ( i1Iii11I1i , Oo00o0OO0O00o , 143 , iII11i , II1i1Ii11Ii11 )
    if 63 - 63: OOooOOo % iiiI11 * ii1II11I1ii1I + iiiI11 / ii11ii1ii % IIIII
   except :
    pass
 except :
  pass
  if 45 - 45: O00OoOoo00
  if 20 - 20: OoooooooOO * ii1II11I1ii1I * O0 . O00o0o0000o0o
def OoO000O ( ) :
 if 94 - 94: iI1Ii11111iIi . O0 / I1i1i1ii . oO0o0ooO0 - i1IIi
 try :
  if 26 - 26: oO0ooO - O00o0o0000o0o . ii1II11I1ii1I
  IiI1iII1II111 = i1 ( oOoO00o )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( IiI1iII1II111 )
  for Oo0oooO0oO in oOOoo00O0O :
   if 65 - 65: oO0o0ooO0 % O0 % iIii1I11I1II1 * I1i1i1ii
   try :
    if 31 - 31: I1i1i1ii
    O0O0ooOOOo0o00Ooo0o = Oo0oooO0oO
    if 44 - 44: iI1Ii11111iIi - iIii1I11I1II1 - ii11ii1ii
   except :
    pass
    if 80 - 80: iIii1I11I1II1 * iiiI11 % oOo0oooo00o % ii11ii1ii
  IIiiI = i1 ( O0O0ooOOOo0o00Ooo0o )
  oOOoo00O0O = re . compile ( iI1i11iII111 ) . findall ( IIiiI )
  for iII11i , i1Iii11I1i , II1i1Ii11Ii11 , Oo00o0OO0O00o in oOOoo00O0O :
   try :
    if 95 - 95: iIii1I11I1II1 - oO0o0ooO0 . iiiI11 - OOooOOo
    iI1iIIIi1i ( i1Iii11I1i , Oo00o0OO0O00o , 143 , iII11i , II1i1Ii11Ii11 )
    if 75 - 75: oO0ooO + ii1II11I1ii1I - i1IIi . OoooooooOO * I1i1i1ii / O00OoOoo00
   except :
    pass
 except :
  pass
  if 86 - 86: iI1Ii11111iIi * II111iiii - O0 . iI1Ii11111iIi % iIii1I11I1II1 / O00o0o0000o0o
def IiIIiIIIiIii ( ) :
 if 23 - 23: IIIII + oOo0oooo00o . iI1Ii11111iIi * OOooOOo + oO0o0ooO0
 try :
  if 18 - 18: O00OoOoo00 * ii1II11I1ii1I . O00OoOoo00 / O0
  IiI1iII1II111 = i1 ( o0OoOO )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( IiI1iII1II111 )
  for Oo0oooO0oO in oOOoo00O0O :
   if 8 - 8: ii1II11I1ii1I
   try :
    if 4 - 4: oO0o0ooO0 + oO0o0ooO0 * oooOOOOO - iI1Ii11111iIi
    O0O0ooOOOo0o00Ooo0o = Oo0oooO0oO
    if 78 - 78: I1i1i1ii / II111iiii % iI1Ii11111iIi
   except :
    pass
    if 52 - 52: O00o0o0000o0o - IIIII * iiIIIII1i1iI
  IIiiI = i1 ( O0O0ooOOOo0o00Ooo0o )
  oOOoo00O0O = re . compile ( iI1i11iII111 ) . findall ( IIiiI )
  for iII11i , i1Iii11I1i , II1i1Ii11Ii11 , Oo00o0OO0O00o in oOOoo00O0O :
   try :
    if 17 - 17: OoooooooOO + O00o0o0000o0o * oOo0oooo00o * iI1Ii11111iIi
    iI1iIIIi1i ( i1Iii11I1i , Oo00o0OO0O00o , 143 , iII11i , II1i1Ii11Ii11 )
    if 36 - 36: O0 + ii11ii1ii
   except :
    pass
 except :
  pass
  if 5 - 5: ii11ii1ii * iI1Ii11111iIi
def ii1I11iIiIII1 ( ) :
 if 52 - 52: ii1II11I1ii1I * O00OoOoo00 + iI1Ii11111iIi
 try :
  if 49 - 49: iIii1I11I1II1 - O0 . i1IIi - OoooooooOO
  IiI1iII1II111 = i1 ( Iiii1iI1i )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( IiI1iII1II111 )
  for Oo0oooO0oO in oOOoo00O0O :
   if 37 - 37: i1IIi . oOo0oooo00o % iI1Ii11111iIi + OoooooooOO / IIIII
   try :
    if 3 - 3: oO0o0ooO0
    O0O0ooOOOo0o00Ooo0o = Oo0oooO0oO
    if 17 - 17: oO0o0ooO0 . II111iiii . oooOOOOO / oO0o0ooO0
   except :
    pass
    if 57 - 57: oOo0oooo00o
  IIiiI = i1 ( O0O0ooOOOo0o00Ooo0o )
  oOOoo00O0O = re . compile ( iI1i11iII111 ) . findall ( IIiiI )
  for iII11i , i1Iii11I1i , II1i1Ii11Ii11 , Oo00o0OO0O00o in oOOoo00O0O :
   try :
    if 67 - 67: oO0ooO . oooOOOOO
    iI1iIIIi1i ( i1Iii11I1i , Oo00o0OO0O00o , 143 , iII11i , II1i1Ii11Ii11 )
    if 87 - 87: iiIIIII1i1iI % I1i1i1ii
   except :
    pass
 except :
  pass
  if 83 - 83: II111iiii - oOo0oooo00o
def iiIii1IIi ( name , url ) :
 if 10 - 10: i11iIiiIii - ii1II11I1ii1I % iIii1I11I1II1
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 49 - 49: iiIIIII1i1iI
 iI1I = i1 ( url )
 oOOoo00O0O = re . compile ( OOOoo0OO ) . findall ( iI1I )
 for OOOOoOo00OO , name , II1i1Ii11Ii11 , url in oOOoo00O0O :
  try :
   if 75 - 75: O0 % iI1Ii11111iIi . O00OoOoo00 / O00OoOoo00 / oO0ooO
   if 19 - 19: oO0o0ooO0 % i11iIiiIii . O00o0o0000o0o - ii11ii1ii / OoooooooOO
   iii = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % iii + name + '[/COLOR]'
   oOOo00O0OOOo ( name , url , 144 , OOOOoOo00OO , II1i1Ii11Ii11 )
   if 31 - 31: oOo0oooo00o % O00o0o0000o0o * oOo0oooo00o
   if 45 - 45: i1IIi . OOooOOo + O00o0o0000o0o - OoooooooOO % oooOOOOO
  except :
   pass
   if 1 - 1: iIii1I11I1II1
   if 93 - 93: i1IIi . i11iIiiIii . ii11ii1ii
   if 99 - 99: oOo0oooo00o - iiiI11 - iiIIIII1i1iI % oO0ooO
def oOOo00O0OOOo ( name , url , mode , iconimage , fanart ) :
 if 21 - 21: II111iiii % oO0o0ooO0 . i1IIi - OoooooooOO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 4 - 4: OoooooooOO . oooOOOOO
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage="
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , fanart )
 II1iIi1IiIii . setProperty ( 'IsPlayable' , 'true' )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii )
 return I111I11I111
 if 46 - 46: i11iIiiIii - O0 . iiIIIII1i1iI
 if 100 - 100: OOooOOo / ii1II11I1ii1I * IIIII . O0 / O00o0o0000o0o
def oOO0o000Oo00o ( name , url ) :
 if 21 - 21: OoooooooOO - iIii1I11I1II1
 if 93 - 93: iiIIIII1i1iI - ii1II11I1ii1I % iI1Ii11111iIi . iI1Ii11111iIi - oooOOOOO
 o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 oo00 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 o00 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 Oo0oO0ooo = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 o0oOoO00o = i1 ( o00 )
 oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
 for i11 in oOOoo00O0O :
  if 90 - 90: oooOOOOO + II111iiii * oO0o0ooO0 / I1i1i1ii . ii1II11I1ii1I + ii1II11I1ii1I
  try :
   if 40 - 40: oooOOOOO / iI1Ii11111iIi % i11iIiiIii % oO0o0ooO0 / OOooOOo
   if 62 - 62: i1IIi - iI1Ii11111iIi
   o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 62 - 62: i1IIi + ii11ii1ii % O00OoOoo00
   if 28 - 28: oO0o0ooO0 . i1IIi
   if o0oO0 == i11 :
    if 10 - 10: oO0ooO / ii11ii1ii
    if 15 - 15: IIIII . iI1Ii11111iIi / IIIII * oOo0oooo00o - OOooOOo % oO0o0ooO0
    if 'https://team.com' in url :
     if 57 - 57: O0 % iI1Ii11111iIi % iiIIIII1i1iI
     url = url . replace ( 'https://team.com' , 'https://verystream.com' )
     if 45 - 45: oO0o0ooO0 + II111iiii * i11iIiiIii
    if 'https://mybox.com' in url :
     if 13 - 13: OoooooooOO * iiIIIII1i1iI - I1i1i1ii / O00o0o0000o0o + oOo0oooo00o + O00OoOoo00
     url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
     if 39 - 39: iIii1I11I1II1 - OoooooooOO
     if 81 - 81: oO0o0ooO0 - O0 * OoooooooOO
    if 'https://vidcloud.co/' in url :
     if 23 - 23: II111iiii / iiIIIII1i1iI
     url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
     if 28 - 28: ii11ii1ii * oooOOOOO - oO0ooO
    if 'https://gounlimited.to' in url :
     if 19 - 19: oOo0oooo00o
     url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
     if 67 - 67: O0 % iIii1I11I1II1 / O00OoOoo00 . i11iIiiIii - I1i1i1ii + O0
    if 'https://drive.com' in url :
     if 27 - 27: O00o0o0000o0o
     url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
     if 89 - 89: II111iiii / iiIIIII1i1iI
     if 14 - 14: O00o0o0000o0o . OOooOOo * oooOOOOO + II111iiii - oooOOOOO + O00o0o0000o0o
    import resolveurl
    if 18 - 18: iiIIIII1i1iI - ii1II11I1ii1I - OOooOOo - OOooOOo
    OOooo00 = urlresolver . HostedMediaFile ( url )
    if 35 - 35: iiiI11 . iI1Ii11111iIi * i11iIiiIii
    if not OOooo00 :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
     return False
     if 44 - 44: i11iIiiIii / ii11ii1ii
    try :
     Ii1IIi = xbmcgui . DialogProgress ( )
     Ii1IIi . create ( 'Realstream:' , 'Iniciando ...' )
     Ii1IIi . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
     xbmc . sleep ( 1000 )
     i111i11I1ii = OOooo00 . resolve ( )
     if not i111i11I1ii or not isinstance ( i111i11I1ii , basestring ) :
      try : OOooo = i111i11I1ii . msg
      except : OOooo = url
      raise Exception ( OOooo )
      if 54 - 54: II111iiii . oOo0oooo00o
    except Exception as i11iiI1111 :
     try : OOooo = str ( i11iiI1111 )
     except : OOooo = url
     Ii1IIi . update ( 45 , 'RESOLVEURL:' , 'Reiniciando ... ' )
     xbmc . sleep ( 1000 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Episodio no disponible.  ,3000)" )
     Ii1IIi . close ( )
     if 73 - 73: iI1Ii11111iIi . OOooOOo
    Ii1IIi . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    Ii1IIi . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
    xbmc . sleep ( 500 )
    Ii1IIi . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
    xbmc . sleep ( 500 )
    Ii1IIi . update ( 100 , 'RESOLVEURL:' , 'Disfrute de este capitulo!' )
    Ii1IIi . close ( )
    II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
    II1i11i1iIi11 = xbmcgui . ListItem ( path = i111i11I1ii )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
    if 83 - 83: I1i1i1ii
    if 25 - 25: oOo0oooo00o + iI1Ii11111iIi . ii1II11I1ii1I % iI1Ii11111iIi * O00o0o0000o0o
   else :
    if 32 - 32: i11iIiiIii - iiiI11
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold]>El addon esta desactivado.[/COLOR]" )
    if 53 - 53: OoooooooOO - O00OoOoo00
    if 87 - 87: iiIIIII1i1iI . OOooOOo
  except :
   pass
   if 17 - 17: I1i1i1ii . i11iIiiIii
   if 5 - 5: oO0o0ooO0 + O0 + O0 . iiiI11 - oooOOOOO
   if 63 - 63: iiIIIII1i1iI
   if 71 - 71: i1IIi . I1i1i1ii * IIIII % OoooooooOO + O00o0o0000o0o
   if 36 - 36: O00OoOoo00
   if 49 - 49: O00o0o0000o0o / OoooooooOO / OOooOOo
def o0OooooOoOO ( ) :
 if 19 - 19: O00OoOoo00
 if 78 - 78: O00o0o0000o0o % ii1II11I1ii1I
 IIIiIiI = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 IIIiIiI . doModal ( )
 if not IIIiIiI . isConfirmed ( ) :
  return None ;
 i1Iii11I1i = IIIiIiI . getText ( ) . strip ( )
 if 7 - 7: O00OoOoo00 . iI1Ii11111iIi / oO0o0ooO0 . O00o0o0000o0o * oOo0oooo00o - II111iiii
 if 37 - 37: iiiI11 . iI1Ii11111iIi / O0 * IIIII
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 7 - 7: oO0ooO * oOo0oooo00o + II111iiii % i11iIiiIii
  oOo0oO = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + i1Iii11I1i + '&language=es-ES' ) )
  if 8 - 8: oooOOOOO * O0
  if 73 - 73: ii1II11I1ii1I / iiIIIII1i1iI / oOo0oooo00o / oO0ooO
  return 'android'
  if 11 - 11: iI1Ii11111iIi + O00OoOoo00 - OoooooooOO / oO0ooO
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 34 - 34: oooOOOOO
  oOo0oO = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + i1Iii11I1i + '&language=es-ES' )
  if 45 - 45: oooOOOOO / ii11ii1ii / I1i1i1ii
  if 44 - 44: oO0o0ooO0 - I1i1i1ii / II111iiii * oO0ooO * ii11ii1ii
  return 'windows'
  if 73 - 73: ii1II11I1ii1I - OOooOOo * i1IIi / i11iIiiIii * O00o0o0000o0o % II111iiii
  if 56 - 56: OoooooooOO * ii11ii1ii . ii11ii1ii . oO0o0ooO0
def II1 ( ) :
 if 74 - 74: OoooooooOO % O00o0o0000o0o % iiiI11 - OOooOOo - oOo0oooo00o
 try :
  if 58 - 58: O0
  o0oOoO00o = i1 ( iiIiI1i1 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 78 - 78: oO0ooO % O00OoOoo00 * i1IIi
   try :
    if 66 - 66: I1i1i1ii . OOooOOo + ii1II11I1ii1I . iIii1I11I1II1
    all = Oo0oooO0oO
    if 51 - 51: oOo0oooo00o . ii11ii1ii
   except :
    pass
    if 45 - 45: i1IIi - ii11ii1ii / O0 . oO0o0ooO0
  iI1I = i1 ( all )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( iI1I )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    if 5 - 5: ii1II11I1ii1I . iIii1I11I1II1 % iIii1I11I1II1
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 56 - 56: OoooooooOO - oOo0oooo00o - i1IIi
   except :
    pass
 except :
  pass
  if 8 - 8: iiiI11 / O00o0o0000o0o . OOooOOo + oO0o0ooO0 / i11iIiiIii
def I1Iii1iI1 ( ) :
 if 86 - 86: O0
 try :
  if 95 - 95: IIIII * O00o0o0000o0o . iI1Ii11111iIi . i1IIi . i1IIi - ii1II11I1ii1I
  I1i1iii = i1 ( IiIi11iI )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( I1i1iii )
  for Oo0oooO0oO in oOOoo00O0O :
   if 26 - 26: iIii1I11I1II1 % i11iIiiIii % oO0o0ooO0
   try :
    if 67 - 67: OoooooooOO
    O0O0ooOOOo0o00Ooo0o = Oo0oooO0oO
    if 29 - 29: O0 - i11iIiiIii - II111iiii + O00o0o0000o0o * O00OoOoo00
   except :
    pass
    if 2 - 2: i1IIi - oooOOOOO + OOooOOo . ii1II11I1ii1I * ii1II11I1ii1I / iI1Ii11111iIi
  IIiiI = i1 ( O0O0ooOOOo0o00Ooo0o )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( IIiiI )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    if 93 - 93: i1IIi
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 53 - 53: OoooooooOO + ii11ii1ii + iiIIIII1i1iI
   except :
    pass
 except :
  pass
  if 24 - 24: IIIII - O00OoOoo00 - IIIII * oO0o0ooO0 . OoooooooOO / O00OoOoo00
def o0OOoo ( ) :
 if 16 - 16: OOooOOo * i1IIi - ii1II11I1ii1I . O00OoOoo00 % oOo0oooo00o / ii1II11I1ii1I
 try :
  if 14 - 14: iIii1I11I1II1 * iiiI11 * oO0o0ooO0 / iIii1I11I1II1 * O00OoOoo00 / oOo0oooo00o
  i1iiI11I = i1 ( i11I1IiII1i1i )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( i1iiI11I )
  for Oo0oooO0oO in oOOoo00O0O :
   if 77 - 77: oO0ooO + iiiI11 + iiiI11 * I1i1i1ii / OoooooooOO . I1i1i1ii
   try :
    ooo0O0OO = Oo0oooO0oO
   except :
    pass
    if 61 - 61: O00OoOoo00 + iIii1I11I1II1 + i11iIiiIii / i11iIiiIii % II111iiii
  o0oOoO00o = i1 ( ooo0O0OO )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 42 - 42: I1i1i1ii * iiiI11 . O00OoOoo00 * OOooOOo + iI1Ii11111iIi
   except :
    pass
 except :
  pass
  if 25 - 25: oOo0oooo00o . OOooOOo + iiIIIII1i1iI
def O00OO0o0 ( ) :
 if 52 - 52: oO0o0ooO0 % iiIIIII1i1iI - i11iIiiIii
 try :
  if 30 - 30: IIIII / oO0ooO + iiIIIII1i1iI
  o0oOoO00o = i1 ( db2 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 6 - 6: IIIII . oOo0oooo00o + I1i1i1ii . iiiI11
   try :
    if 70 - 70: oO0ooO
    i1iIi1111 = Oo0oooO0oO
    if 13 - 13: oO0ooO
   except :
    pass
    if 37 - 37: I1i1i1ii + iiiI11 - ii11ii1ii + I1i1i1ii
    if 92 - 92: OoooooooOO - OoooooooOO * oO0ooO % OOooOOo
  o0oOoO00o = i1 ( i1iIi1111 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 77 - 77: iIii1I11I1II1 - i1IIi . iiIIIII1i1iI
   except :
    pass
 except :
  pass
  if 26 - 26: ii1II11I1ii1I * O00OoOoo00 . i1IIi
def ooOoOO ( ) :
 if 56 - 56: iIii1I11I1II1 . i11iIiiIii - O00o0o0000o0o * II111iiii * iiiI11
 try :
  if 5 - 5: O00o0o0000o0o / O00o0o0000o0o - oO0o0ooO0
  oO0ooOO = i1 ( o0Oooo )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( oO0ooOO )
  for Oo0oooO0oO in oOOoo00O0O :
   if 7 - 7: II111iiii - O00o0o0000o0o . II111iiii
   try :
    if 53 - 53: iiIIIII1i1iI % oOo0oooo00o . oooOOOOO - iI1Ii11111iIi
    OoOoO0OoOOOOo = Oo0oooO0oO
    if 61 - 61: i11iIiiIii * iiIIIII1i1iI . IIIII . oooOOOOO % oO0ooO
   except :
    pass
    if 34 - 34: i11iIiiIii - II111iiii / OOooOOo % ii1II11I1ii1I
    if 33 - 33: O00o0o0000o0o
  o0oOoO00o = i1 ( OoOoO0OoOOOOo )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 35 - 35: i11iIiiIii - OOooOOo / O00o0o0000o0o + I1i1i1ii * iiIIIII1i1iI
   except :
    pass
 except :
  pass
  if 49 - 49: ii1II11I1ii1I * I1i1i1ii + oOo0oooo00o + IIIII
def IIi11 ( ) :
 if 89 - 89: II111iiii * oooOOOOO . iiIIIII1i1iI
 try :
  if 85 - 85: oO0o0ooO0 + I1i1i1ii * OOooOOo % i11iIiiIii
  o0oOoO00o = i1 ( I1111i )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 42 - 42: iI1Ii11111iIi / i1IIi * OOooOOo
   try :
    if 12 - 12: iiiI11 % i11iIiiIii + ii1II11I1ii1I + iiiI11 / oOo0oooo00o
    O00 = Oo0oooO0oO
    if 94 - 94: oOo0oooo00o . oOo0oooo00o + i11iIiiIii - O00o0o0000o0o * oO0o0ooO0
   except :
    pass
    if 9 - 9: ii1II11I1ii1I . OOooOOo - oO0o0ooO0
    if 32 - 32: OoooooooOO / OOooOOo / iIii1I11I1II1 + II111iiii . iiIIIII1i1iI . ii1II11I1ii1I
  o0oOoO00o = i1 ( O00 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 21 - 21: iIii1I11I1II1 / II111iiii % i1IIi
   except :
    pass
 except :
  pass
  if 8 - 8: oO0ooO + iI1Ii11111iIi . iIii1I11I1II1 % O0
def iI11Ii111 ( ) :
 if 54 - 54: iI1Ii11111iIi % IIIII . iI1Ii11111iIi * O00o0o0000o0o + iI1Ii11111iIi % i1IIi
 try :
  if 23 - 23: iiiI11 - O00o0o0000o0o + I1i1i1ii - iI1Ii11111iIi * iI1Ii11111iIi . ii11ii1ii
  o0oOoO00o = i1 ( o00O0O )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 47 - 47: iiIIIII1i1iI % iIii1I11I1II1
   try :
    if 11 - 11: OOooOOo % I1i1i1ii - oO0ooO - iiIIIII1i1iI + ii1II11I1ii1I
    o0O0O0 = Oo0oooO0oO
    if 55 - 55: O0 - iiiI11
   except :
    pass
    if 58 - 58: iI1Ii11111iIi - IIIII - OoooooooOO
  o0oOoO00o = i1 ( o0O0O0 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 96 - 96: iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 82 - 82: iI1Ii11111iIi + O0 - O00OoOoo00 % iiIIIII1i1iI * i11iIiiIii
def iIIi1iI1 ( ) :
 if 31 - 31: oooOOOOO + O0 + oooOOOOO . iIii1I11I1II1 + ii11ii1ii / ii1II11I1ii1I
 try :
  if 6 - 6: ii11ii1ii % O00OoOoo00 * oOo0oooo00o / OOooOOo + ii11ii1ii
  o0oOoO00o = i1 ( Iii1I1111ii )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 39 - 39: iI1Ii11111iIi - ii11ii1ii / IIIII * OoooooooOO
   try :
    if 100 - 100: O0 . oOo0oooo00o . oO0ooO + O0 * iiIIIII1i1iI
    iIIiIIIIiII = Oo0oooO0oO
    if 85 - 85: oO0ooO - ii1II11I1ii1I
   except :
    pass
    if 37 - 37: oOo0oooo00o - iI1Ii11111iIi . iIii1I11I1II1 % oooOOOOO % I1i1i1ii * iI1Ii11111iIi
    if 8 - 8: iI1Ii11111iIi . oooOOOOO % iiIIIII1i1iI . OOooOOo % OOooOOo . I1i1i1ii
  o0oOoO00o = i1 ( iIIiIIIIiII )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 47 - 47: oOo0oooo00o + oooOOOOO + II111iiii % i11iIiiIii
   except :
    pass
 except :
  pass
  if 93 - 93: oO0o0ooO0 % iI1Ii11111iIi . O0 / IIIII * iiIIIII1i1iI
def i1iii1ii ( ) :
 if 18 - 18: oO0ooO . II111iiii % iI1Ii11111iIi % I1i1i1ii
 try :
  if 87 - 87: iIii1I11I1II1 . OoooooooOO * iI1Ii11111iIi
  o0oOoO00o = i1 ( Ii1IIiI1i )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 100 - 100: oO0ooO / i1IIi - OOooOOo % I1i1i1ii - iIii1I11I1II1
   try :
    if 17 - 17: oOo0oooo00o / ii1II11I1ii1I % ii11ii1ii
    o0o = Oo0oooO0oO
    if 93 - 93: oooOOOOO % i11iIiiIii % iiiI11
   except :
    pass
    if 64 - 64: iiiI11 + OOooOOo * O0 / ii11ii1ii - oOo0oooo00o % oOo0oooo00o
    if 59 - 59: O00o0o0000o0o + OoooooooOO
  o0oOoO00o = i1 ( o0o )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 55 - 55: i11iIiiIii % iIii1I11I1II1 . i1IIi + OoooooooOO / i11iIiiIii
   except :
    pass
 except :
  pass
  if 10 - 10: IIIII - iiIIIII1i1iI * iIii1I11I1II1 % iIii1I11I1II1 * O00OoOoo00 - oO0o0ooO0
def OoO0O0oO00 ( ) :
 if 33 - 33: O0
 try :
  if 78 - 78: O0 / II111iiii * oO0ooO
  o0oOoO00o = i1 ( IiII111i1i11 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 50 - 50: OoooooooOO - iIii1I11I1II1 + i1IIi % iiiI11 - iIii1I11I1II1 % O0
   try :
    if 58 - 58: O00OoOoo00 + iIii1I11I1II1
    Oo00OO0OO = Oo0oooO0oO
    if 85 - 85: ii1II11I1ii1I % oooOOOOO . iI1Ii11111iIi % iiiI11 - ii11ii1ii
   except :
    pass
    if 69 - 69: oooOOOOO - ii1II11I1ii1I . oooOOOOO
    if 9 - 9: iiIIIII1i1iI % i11iIiiIii / ii11ii1ii
  o0oOoO00o = i1 ( Oo00OO0OO )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 20 - 20: iiIIIII1i1iI * O0 + oOo0oooo00o - OoooooooOO . oOo0oooo00o
   except :
    pass
 except :
  pass
  if 60 - 60: ii1II11I1ii1I . ii1II11I1ii1I / IIIII
def Ii ( ) :
 if 79 - 79: iIii1I11I1II1
 try :
  if 81 - 81: O00o0o0000o0o + iIii1I11I1II1 * iiiI11 - iIii1I11I1II1 . O00o0o0000o0o
  o0oOoO00o = i1 ( oO )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 48 - 48: oOo0oooo00o . OoooooooOO . OOooOOo . iI1Ii11111iIi % oO0o0ooO0 / IIIII
   try :
    if 11 - 11: i1IIi % oO0ooO % IIIII
    O0Oo0 = Oo0oooO0oO
    if 80 - 80: OOooOOo - iIii1I11I1II1 . O00o0o0000o0o + oO0ooO - iiiI11
   except :
    pass
    if 5 - 5: IIIII
    if 62 - 62: iI1Ii11111iIi . OoooooooOO . O00o0o0000o0o . oO0ooO * IIIII
  o0oOoO00o = i1 ( O0Oo0 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 78 - 78: iiIIIII1i1iI / oO0ooO - iiIIIII1i1iI * OoooooooOO . iI1Ii11111iIi
   except :
    pass
 except :
  pass
  if 96 - 96: OOooOOo % i1IIi . ii1II11I1ii1I . O0
  if 37 - 37: i1IIi - O00o0o0000o0o % OoooooooOO / O00o0o0000o0o % oooOOOOO
def iiIiII11i1 ( ) :
 if 93 - 93: iI1Ii11111iIi % iIii1I11I1II1
 try :
  if 90 - 90: OOooOOo - O00o0o0000o0o / I1i1i1ii / O0 / oOo0oooo00o
  o0oOoO00o = i1 ( oooO )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 87 - 87: iI1Ii11111iIi / O00OoOoo00 + iIii1I11I1II1
   try :
    if 93 - 93: iIii1I11I1II1 + iiIIIII1i1iI % oooOOOOO
    iii1IiI1I1 = Oo0oooO0oO
    if 64 - 64: oooOOOOO / O0 * iI1Ii11111iIi * oooOOOOO
   except :
    pass
    if 60 - 60: oOo0oooo00o / i1IIi % oO0o0ooO0 / oO0o0ooO0 * oO0o0ooO0 . i11iIiiIii
    if 99 - 99: iI1Ii11111iIi
  o0oOoO00o = i1 ( iii1IiI1I1 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 77 - 77: ii1II11I1ii1I
   except :
    pass
 except :
  pass
  if 48 - 48: iI1Ii11111iIi % oO0o0ooO0 / oOo0oooo00o . iIii1I11I1II1 * II111iiii
  if 65 - 65: iI1Ii11111iIi
def I1iI11I1III1 ( ) :
 if 8 - 8: i11iIiiIii / II111iiii + ii1II11I1ii1I * I1i1i1ii % O00OoOoo00 . oOo0oooo00o
 try :
  if 6 - 6: O00OoOoo00 % ii11ii1ii . ii11ii1ii - oO0o0ooO0 / oOo0oooo00o . i1IIi
  o0oOoO00o = i1 ( ooo )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 99 - 99: iI1Ii11111iIi . iiiI11
   try :
    if 59 - 59: oOo0oooo00o / ii11ii1ii / O00o0o0000o0o / O0 / iI1Ii11111iIi + ii1II11I1ii1I
    IIiI1111i1 = Oo0oooO0oO
    if 46 - 46: O00OoOoo00
   except :
    pass
    if 29 - 29: II111iiii . iI1Ii11111iIi % ii1II11I1ii1I * II111iiii - ii1II11I1ii1I * iIii1I11I1II1
    if 35 - 35: II111iiii - O00OoOoo00 . i1IIi
  o0oOoO00o = i1 ( IIiI1111i1 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 95 - 95: OOooOOo + OOooOOo - O00o0o0000o0o - IIIII
   except :
    pass
    if 45 - 45: I1i1i1ii . OoooooooOO
 except :
  pass
  if 27 - 27: I1i1i1ii * ii11ii1ii . iI1Ii11111iIi
  if 17 - 17: II111iiii % IIIII * O00o0o0000o0o % i1IIi . OOooOOo . iIii1I11I1II1
def iiiIIIii ( ) :
 if 93 - 93: iIii1I11I1II1 + OOooOOo + i11iIiiIii
 try :
  if 74 - 74: oOo0oooo00o / II111iiii + oooOOOOO * iIii1I11I1II1 - iiiI11 - oO0ooO
  o0oOoO00o = i1 ( Ooo0oOooo0 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 69 - 69: iIii1I11I1II1 * OOooOOo - IIIII + O0 + O0
   try :
    if 65 - 65: iiiI11 / i11iIiiIii / oO0ooO - O00o0o0000o0o
    IiI1 = Oo0oooO0oO
    if 91 - 91: O00OoOoo00 . ii11ii1ii + II111iiii
   except :
    pass
    if 36 - 36: O0 * oO0ooO % IIIII * IIIII / oO0ooO * O00OoOoo00
    if 14 - 14: i1IIi . O00OoOoo00 + O0 * oooOOOOO
  o0oOoO00o = i1 ( IiI1 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 76 - 76: oO0ooO
   except :
    pass
    if 92 - 92: oOo0oooo00o - iIii1I11I1II1 % OoooooooOO
 except :
  pass
  if 39 - 39: IIIII . OOooOOo * iI1Ii11111iIi - i11iIiiIii
def i1II1II1iii1i ( ) :
 if 75 - 75: O00OoOoo00 - iI1Ii11111iIi - iIii1I11I1II1 % ii1II11I1ii1I
 try :
  if 58 - 58: O0 . O00OoOoo00 / OoooooooOO . oO0ooO / ii11ii1ii * II111iiii
  o0oOoO00o = i1 ( iiIiIIIiiI )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 53 - 53: I1i1i1ii - O0 / ii1II11I1ii1I % IIIII * OOooOOo % O00o0o0000o0o
   try :
    if 69 - 69: oO0o0ooO0
    oOOO0ooo = Oo0oooO0oO
    if 19 - 19: IIIII - ii1II11I1ii1I - I1i1i1ii - iI1Ii11111iIi . IIIII . iiiI11
   except :
    pass
    if 48 - 48: IIIII + O00OoOoo00
  o0oOoO00o = i1 ( oOOO0ooo )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 60 - 60: oOo0oooo00o + IIIII . O00OoOoo00 / i1IIi . iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 14 - 14: O00o0o0000o0o
  if 79 - 79: I1i1i1ii
def o0Oii111 ( ) :
 if 93 - 93: OoooooooOO * ii11ii1ii
 try :
  if 10 - 10: iiiI11 * OoooooooOO + oOo0oooo00o - oO0o0ooO0 / oO0o0ooO0 . i11iIiiIii
  o0oOoO00o = i1 ( II11IiIi11 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 22 - 22: iiiI11 / ii1II11I1ii1I
   try :
    if 98 - 98: i1IIi
    OOO0oO = Oo0oooO0oO
    if 38 - 38: iIii1I11I1II1 / oooOOOOO
   except :
    pass
    if 13 - 13: iIii1I11I1II1
    if 77 - 77: i11iIiiIii - iIii1I11I1II1 / iiIIIII1i1iI / oooOOOOO / oO0ooO
  o0oOoO00o = i1 ( OOO0oO )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 56 - 56: OoooooooOO * O0
   except :
    pass
 except :
  pass
  if 85 - 85: OoooooooOO % iI1Ii11111iIi * iIii1I11I1II1
  if 44 - 44: iIii1I11I1II1 . oO0o0ooO0 + iiiI11 . oooOOOOO
def II1i11 ( ) :
 if 28 - 28: II111iiii - iiIIIII1i1iI % iI1Ii11111iIi + oO0ooO - iI1Ii11111iIi
 try :
  if 28 - 28: II111iiii . iiIIIII1i1iI + O0 . O0 . O00o0o0000o0o
  o0oOoO00o = i1 ( OOO0O00O0OOOO )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 98 - 98: OoooooooOO % O0 - O0
   try :
    if 76 - 76: i1IIi % iI1Ii11111iIi - OOooOOo / ii1II11I1ii1I * oooOOOOO
    iIiIIiI1i1Ii = Oo0oooO0oO
    if 72 - 72: O00o0o0000o0o . O00o0o0000o0o - oO0o0ooO0
   except :
    pass
  o0oOoO00o = i1 ( iIiIIiI1i1Ii )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 48 - 48: ii11ii1ii - oooOOOOO + ii11ii1ii - OOooOOo * i11iIiiIii . IIIII
   except :
    pass
 except :
  pass
  if 35 - 35: O00OoOoo00 . O0 + ii11ii1ii + O00o0o0000o0o + i1IIi
def OooOooO0O0o0 ( ) :
 if 59 - 59: ii11ii1ii + IIIII - O00o0o0000o0o . ii1II11I1ii1I + OOooOOo % iiIIIII1i1iI
 try :
  if 37 - 37: IIIII + IIIII % ii1II11I1ii1I
  o0oOoO00o = i1 ( OOo0 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 29 - 29: oooOOOOO
   try :
    if 41 - 41: O0 % IIIII
    i1iIi1IIiIII1 = Oo0oooO0oO
    if 19 - 19: oOo0oooo00o
   except :
    pass
    if 87 - 87: oooOOOOO / iI1Ii11111iIi % ii1II11I1ii1I * iiIIIII1i1iI
    if 77 - 77: iiIIIII1i1iI - ii11ii1ii - iIii1I11I1II1
  o0oOoO00o = i1 ( i1iIi1IIiIII1 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 16 - 16: oO0ooO / IIIII / i1IIi . IIIII + iiIIIII1i1iI
   except :
    pass
 except :
  pass
  if 26 - 26: iIii1I11I1II1 + i1IIi / iI1Ii11111iIi % oO0o0ooO0
  if 44 - 44: OoooooooOO . II111iiii . O00o0o0000o0o % OoooooooOO
def Oo0oO00 ( ) :
 if 41 - 41: O0 - oOo0oooo00o * iIii1I11I1II1
 try :
  if 12 - 12: ii1II11I1ii1I * iiiI11 % II111iiii * i1IIi * iIii1I11I1II1
  o0oOoO00o = i1 ( oo0o )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 81 - 81: ii11ii1ii - oOo0oooo00o
   try :
    if 24 - 24: OoooooooOO . oO0ooO * II111iiii
    o0oO00 = Oo0oooO0oO
    if 88 - 88: oOo0oooo00o + i11iIiiIii % iiIIIII1i1iI * O00o0o0000o0o * O00o0o0000o0o * I1i1i1ii
   except :
    pass
    if 24 - 24: oooOOOOO / IIIII + O00OoOoo00 . O00OoOoo00
    if 39 - 39: oooOOOOO + O0 / i1IIi % O00OoOoo00 / iiIIIII1i1iI * O00OoOoo00
  o0oOoO00o = i1 ( o0oO00 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 77 - 77: O00OoOoo00 . iiiI11 % iI1Ii11111iIi
   except :
    pass
 except :
  pass
  if 42 - 42: O00OoOoo00 % IIIII % ii1II11I1ii1I % iiIIIII1i1iI + oOo0oooo00o % iI1Ii11111iIi
def iI1iIIiii ( ) :
 if 52 - 52: I1i1i1ii % O00o0o0000o0o * OOooOOo % oOo0oooo00o + O00o0o0000o0o / IIIII
 try :
  if 80 - 80: OoooooooOO + O00OoOoo00
  o0oOoO00o = i1 ( I1III1111iIi )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 95 - 95: iiiI11 / iiIIIII1i1iI * iiiI11 - OoooooooOO * OoooooooOO % oO0ooO
   try :
    if 43 - 43: ii11ii1ii . iiiI11
    I1I1i1i = Oo0oooO0oO
    if 87 - 87: iI1Ii11111iIi / O00OoOoo00 . oooOOOOO - O00o0o0000o0o / oO0ooO
   except :
    pass
    if 41 - 41: II111iiii
    if 27 - 27: ii11ii1ii * iI1Ii11111iIi % iIii1I11I1II1 . OOooOOo
  o0oOoO00o = i1 ( I1I1i1i )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 70 - 70: oOo0oooo00o % II111iiii % O0 . i1IIi / iiiI11
   except :
    pass
 except :
  pass
  if 100 - 100: oO0o0ooO0 * i11iIiiIii % iiIIIII1i1iI / ii11ii1ii / oooOOOOO + oO0o0ooO0
  if 59 - 59: iiiI11 - O00OoOoo00
def iiiii111 ( ) :
 if 93 - 93: iiIIIII1i1iI * I1i1i1ii
 try :
  if 27 - 27: OOooOOo * oooOOOOO
  o0oOoO00o = i1 ( Ooo )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 77 - 77: O00OoOoo00
   try :
    if 66 - 66: iIii1I11I1II1 . i11iIiiIii / oOo0oooo00o / oooOOOOO + iiiI11
    iII11ii1ii = Oo0oooO0oO
    if 51 - 51: oO0o0ooO0 * oO0o0ooO0
   except :
    pass
    if 98 - 98: oO0ooO - I1i1i1ii . O00OoOoo00 % i11iIiiIii
    if 69 - 69: oO0o0ooO0 + IIIII * O0 . O00o0o0000o0o % iI1Ii11111iIi
  o0oOoO00o = i1 ( iII11ii1ii )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 96 - 96: oooOOOOO . oooOOOOO - oOo0oooo00o / oOo0oooo00o
   except :
    pass
 except :
  pass
  if 96 - 96: i11iIiiIii / OOooOOo - O0 . oooOOOOO
  if 39 - 39: oooOOOOO / O0 * O00OoOoo00
def I1IiII1iI1 ( ) :
 if 52 - 52: iI1Ii11111iIi * oO0ooO - I1i1i1ii
 try :
  if 82 - 82: oO0ooO + OOooOOo . i1IIi + O00o0o0000o0o
  o0oOoO00o = i1 ( I1i11 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 16 - 16: ii1II11I1ii1I - oO0ooO / iiiI11
   try :
    if 48 - 48: iIii1I11I1II1
    OoooooOo = Oo0oooO0oO
    if 67 - 67: II111iiii / ii1II11I1ii1I . O00o0o0000o0o . OoooooooOO
   except :
    pass
    if 19 - 19: O00OoOoo00 . oO0o0ooO0 / iI1Ii11111iIi
    if 68 - 68: oooOOOOO / OoooooooOO * oOo0oooo00o / iiIIIII1i1iI
  o0oOoO00o = i1 ( OoooooOo )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 88 - 88: ii1II11I1ii1I
   except :
    pass
 except :
  pass
  if 1 - 1: OoooooooOO
  if 48 - 48: oooOOOOO * iI1Ii11111iIi - oooOOOOO - O00o0o0000o0o + O00o0o0000o0o
def iiiIiIIII1iiIIi ( ) :
 if 17 - 17: oOo0oooo00o
 try :
  if 97 - 97: oO0o0ooO0 * oO0o0ooO0 / IIIII
  o0oOoO00o = i1 ( IiIIi1 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 6 - 6: iiIIIII1i1iI
   try :
    if 72 - 72: oOo0oooo00o * oO0o0ooO0 - iI1Ii11111iIi / oO0o0ooO0 + O00o0o0000o0o - IIIII
    IIii1III = Oo0oooO0oO
    if 94 - 94: i11iIiiIii % OoooooooOO / OOooOOo
   except :
    pass
    if 24 - 24: OOooOOo * iiIIIII1i1iI
    if 85 - 85: II111iiii . oooOOOOO % O00o0o0000o0o % oOo0oooo00o
  o0oOoO00o = i1 ( IIii1III )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 80 - 80: iiIIIII1i1iI * oOo0oooo00o / iIii1I11I1II1 % iiIIIII1i1iI / iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 42 - 42: i1IIi / i11iIiiIii . ii11ii1ii * IIIII . i11iIiiIii * O0
  if 44 - 44: i1IIi . OOooOOo / i11iIiiIii + O00OoOoo00
def iI111II1ii ( ) :
 if 62 - 62: IIIII * iIii1I11I1II1 . O00OoOoo00 - OoooooooOO * II111iiii
 try :
  if 45 - 45: O0 % OOooOOo - IIIII . oO0ooO
  o0oOoO00o = i1 ( II1i11I )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 42 - 42: IIIII / ii1II11I1ii1I + ii11ii1ii . ii11ii1ii % O00o0o0000o0o
   try :
    if 16 - 16: i1IIi + oO0ooO % iI1Ii11111iIi + I1i1i1ii * ii11ii1ii
    i1o0oo0 = Oo0oooO0oO
    if 67 - 67: O0 * oOo0oooo00o - ii1II11I1ii1I - II111iiii
   except :
    pass
    if 41 - 41: OOooOOo - iiiI11 % II111iiii . iiiI11 - oOo0oooo00o
  o0oOoO00o = i1 ( i1o0oo0 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 45 - 45: I1i1i1ii - O00o0o0000o0o
   except :
    pass
 except :
  pass
  if 70 - 70: oO0ooO % OOooOOo / OOooOOo . oOo0oooo00o % oooOOOOO . II111iiii
  if 10 - 10: I1i1i1ii - i11iIiiIii . oO0o0ooO0 % i1IIi
def OooOOOoOoo0O0 ( ) :
 if 81 - 81: O00OoOoo00 - ii1II11I1ii1I - ii11ii1ii - I1i1i1ii / O00o0o0000o0o % oOo0oooo00o
 try :
  if 52 - 52: oO0o0ooO0 / IIIII
  o0oOoO00o = i1 ( O0o0oO )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 37 - 37: oOo0oooo00o
   try :
    if 83 - 83: O0
    oOOOOOo = Oo0oooO0oO
    if 50 - 50: iiiI11 + oooOOOOO + IIIII
   except :
    pass
    if 15 - 15: oOo0oooo00o
    if 13 - 13: iIii1I11I1II1 * iI1Ii11111iIi / iiiI11 % oooOOOOO + iiIIIII1i1iI
  o0oOoO00o = i1 ( oOOOOOo )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 41 - 41: oO0o0ooO0
   except :
    pass
 except :
  pass
  if 5 - 5: ii11ii1ii
def o0oOo00 ( ) :
 if 22 - 22: iIii1I11I1II1 + O00OoOoo00 + oO0o0ooO0 + iiiI11 - I1i1i1ii
 try :
  if 48 - 48: I1i1i1ii - iI1Ii11111iIi - oO0ooO + OOooOOo * I1i1i1ii
  o0oOoO00o = i1 ( I11iiiiI1i )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 67 - 67: ii11ii1ii / oooOOOOO - O00OoOoo00
   try :
    if 74 - 74: oOo0oooo00o * I1i1i1ii - oO0o0ooO0 % iIii1I11I1II1
    oOoOoO0o0 = Oo0oooO0oO
    if 18 - 18: I1i1i1ii
   except :
    pass
  o0oOoO00o = i1 ( oOoOoO0o0 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 25 - 25: oO0ooO * iiIIIII1i1iI % i11iIiiIii + i11iIiiIii * oO0ooO
   except :
    pass
 except :
  pass
  if 42 - 42: II111iiii / O0 . iIii1I11I1II1 / O0 / oO0ooO / OoooooooOO
def ooiiI1ii ( ) :
 if 76 - 76: I1i1i1ii + iIii1I11I1II1 + iI1Ii11111iIi . oO0ooO
 try :
  if 49 - 49: O00OoOoo00 / oooOOOOO / O00o0o0000o0o
  o0oOoO00o = i1 ( OoOOoooOO0O )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 25 - 25: OOooOOo % O0 + i1IIi - oooOOOOO
   try :
    if 38 - 38: ii1II11I1ii1I % iiiI11 + i11iIiiIii + IIIII + oooOOOOO / i11iIiiIii
    o0OOOOOo0 = Oo0oooO0oO
    if 57 - 57: iIii1I11I1II1 + iIii1I11I1II1
   except :
    pass
  o0oOoO00o = i1 ( o0OOOOOo0 )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 56 - 56: iiIIIII1i1iI + oooOOOOO
   except :
    pass
 except :
  pass
  if 32 - 32: II111iiii + iI1Ii11111iIi % oooOOOOO / iI1Ii11111iIi + oO0o0ooO0
def IiI11I111 ( ) :
 if 54 - 54: O0 - IIIII . O00o0o0000o0o % IIIII + IIIII
 try :
  if 36 - 36: O00o0o0000o0o % i11iIiiIii
  o0oOoO00o = i1 ( o0O0oo0OO0O )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 47 - 47: i1IIi + II111iiii . ii11ii1ii * iiIIIII1i1iI . oOo0oooo00o / i1IIi
   try :
    if 50 - 50: iiiI11 / i1IIi % OoooooooOO
    oOOOOO0Ooooo = Oo0oooO0oO
    if 57 - 57: I1i1i1ii - OoooooooOO
   except :
    pass
  o0oOoO00o = i1 ( oOOOOO0Ooooo )
  oOOoo00O0O = re . compile ( i11I1II1I11i ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo in oOOoo00O0O :
   try :
    I1i11111i1i11 ( i1Iii11I1i , Oo00o0OO0O00o , III1I1Iii1iiI , id , O0Oooo )
    if 68 - 68: ii1II11I1ii1I % oO0o0ooO0 / iiiI11 + iiiI11 - iiiI11 . oO0ooO
   except :
    pass
 except :
  pass
  if 100 - 100: iI1Ii11111iIi % ii11ii1ii
def OoOO ( ) :
 if 1 - 1: oO0o0ooO0 . i11iIiiIii
 try :
  if 74 - 74: O0 + OoooooooOO / iiIIIII1i1iI / iI1Ii11111iIi . oO0o0ooO0 % iiIIIII1i1iI
  o0oOoO00o = i1 ( Oo0o0O00 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for Oo0oooO0oO in oOOoo00O0O :
   if 34 - 34: i1IIi . OOooOOo
   try :
    if 6 - 6: iiiI11 % iiIIIII1i1iI % I1i1i1ii
    OooIi = Oo0oooO0oO
    if 92 - 92: iiIIIII1i1iI / O00o0o0000o0o . oO0o0ooO0
   except :
    pass
  o0oOoO00o = i1 ( OooIi )
  oOOoo00O0O = re . compile ( iI1Ii11iIiI1 ) . findall ( o0oOoO00o )
  for III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o in oOOoo00O0O :
   try :
    i1i ( III1I1Iii1iiI , i1Iii11I1i , Oo00o0OO0O00o )
    if 60 - 60: ii11ii1ii . O00OoOoo00 % OOooOOo - iiiI11
   except :
    pass
    if 79 - 79: OoooooooOO / oO0o0ooO0 . O0
 except :
  pass
  if 79 - 79: iiIIIII1i1iI - II111iiii
  if 43 - 43: i1IIi + O0 % oO0ooO / I1i1i1ii * OOooOOo
  if 89 - 89: OOooOOo . ii11ii1ii + oO0o0ooO0 . O0 % ii1II11I1ii1I
def i1i ( thumb , name , url ) :
 if 84 - 84: OoooooooOO + iiiI11 / OOooOOo % O00o0o0000o0o % oO0o0ooO0 * OOooOOo
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( ii1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   iI1iIIIi1i ( name , url , '' , iII11i , II1i1Ii11Ii11 )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 58 - 58: oO0ooO - iI1Ii11111iIi . i11iIiiIii % i11iIiiIii / i1IIi / iiIIIII1i1iI
  if 'tvg-logo' in thumb :
   thumb = re . compile ( ii1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 24 - 24: OOooOOo * i1IIi % oooOOOOO / O0 + i11iIiiIii
   iI1i ( name , url , 4 , OOOOoOo00OO , II1i1Ii11Ii11 )
   if 3 - 3: O00OoOoo00 / oOo0oooo00o
  else :
   if 34 - 34: i11iIiiIii / iiiI11 * O00o0o0000o0o . ii11ii1ii
   iI1i ( name , url , 4 , OOOOoOo00OO , II1i1Ii11Ii11 )
   if 79 - 79: iiiI11
def I1i11111i1i11 ( name , url , thumb , id , trailer ) :
 if 31 - 31: O00o0o0000o0o % iiiI11
 if 98 - 98: O00OoOoo00 * iIii1I11I1II1 . I1i1i1ii * ii11ii1ii / oO0o0ooO0 + oooOOOOO
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 25 - 25: iiIIIII1i1iI
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( ii1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   iI1iIIIi1i ( name , url , '' , iII11i , II1i1Ii11Ii11 )
 else :
  iii = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
  if 19 - 19: OOooOOo % I1i1i1ii . O00OoOoo00 * oooOOOOO
  name = '[COLOR %s]' % iii + name + '[/COLOR]'
  if 89 - 89: iI1Ii11111iIi . O00o0o0000o0o
  if 'tvg-logo' in thumb :
   thumb = re . compile ( ii1I ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   iiIiI = IiII1IiiIiI1 . getSetting ( 'selecton' )
   if iiIiI == 'true' :
    if 7 - 7: iiIIIII1i1iI % iI1Ii11111iIi - OOooOOo + ii11ii1ii
    OoO0Ooo ( name , url , 1 , thumb , thumb , id , trailer )
    if 21 - 21: OOooOOo + oO0o0ooO0 * ii11ii1ii * iIii1I11I1II1 - oO0ooO . ii11ii1ii
   else :
    if 59 - 59: oO0ooO - oO0ooO + IIIII
    OoO0Ooo ( name , url , 130 , thumb , thumb , id , trailer )
    if 32 - 32: i1IIi / ii11ii1ii - O0
  else :
   if 85 - 85: I1i1i1ii - O0 * i11iIiiIii . i1IIi
   if iiIiI == 'true' :
    if 20 - 20: IIIII / O00o0o0000o0o
    OoO0Ooo ( name , url , 1 , thumb , thumb , id , trailer )
    if 28 - 28: oooOOOOO * oOo0oooo00o % i11iIiiIii * IIIII / I1i1i1ii
   else :
    if 41 - 41: O00o0o0000o0o - ii1II11I1ii1I + I1i1i1ii
    OoO0Ooo ( name , url , 130 , thumb , thumb , id , trailer )
    if 15 - 15: oOo0oooo00o / ii1II11I1ii1I + I1i1i1ii
    if 76 - 76: I1i1i1ii + OoooooooOO / O00o0o0000o0o % oO0ooO / oO0o0ooO0
def I1i ( name , trailer ) :
 if 82 - 82: oO0ooO + oO0ooO % ii1II11I1ii1I % i11iIiiIii / iiiI11 % OoooooooOO
 if II1I == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Realstream, Reproduciendo Trailer de: [COLOR green]" + name + "[/COLOR] ,5000)" )
  if 96 - 96: iiIIIII1i1iI - iiIIIII1i1iI
  Oo00o0OO0O00o = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  OOOo = Oo00o0OO0O00o
  I1iiIi1 = xbmcgui . ListItem ( name , trailer , path = OOOo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1iiIi1 )
 else :
  Oo00o0OO0O00o = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  OOOo = Oo00o0OO0O00o
  I1iiIi1 = xbmcgui . ListItem ( name , trailer , path = OOOo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1iiIi1 )
  if 49 - 49: oooOOOOO . II111iiii
  if 24 - 24: O0 . OoooooooOO - oO0ooO * OoooooooOO
def Ii11iiI ( trailer ) :
 if 71 - 71: iiiI11 - ii1II11I1ii1I - O00o0o0000o0o
 if 'https://www.youtube.com' in trailer :
  if 28 - 28: iIii1I11I1II1
  try :
   if 7 - 7: ii1II11I1ii1I % O00OoOoo00 * iI1Ii11111iIi
   import resolveurl
   if 58 - 58: O00OoOoo00 / oOo0oooo00o + II111iiii % IIIII - OoooooooOO
   OOooo00 = urlresolver . HostedMediaFile ( Oo00o0OO0O00o )
   Ii1IIi = xbmcgui . DialogProgress ( )
   Ii1IIi . create ( 'Realstream:' , 'Conectando al servidor ... ' )
   Ii1IIi . update ( 20 , 'Por favor, espere ...' )
   xbmc . sleep ( 500 )
   if 25 - 25: iI1Ii11111iIi % OoooooooOO * ii11ii1ii - i1IIi * II111iiii * iiIIIII1i1iI
   if not OOooo00 :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    return False
    if 30 - 30: oOo0oooo00o % iI1Ii11111iIi / oO0o0ooO0 * O0 * I1i1i1ii . OOooOOo
   try :
    if 46 - 46: iI1Ii11111iIi - O0
    Ii1IIi . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    i111i11I1ii = OOooo00 . resolve ( )
    if not i111i11I1ii or not isinstance ( i111i11I1ii , basestring ) :
     try : OOooo = i111i11I1ii . msg
     except : OOooo = i111i11I1ii
     raise Exception ( OOooo )
   except Exception as i11iiI1111 :
    try : OOooo = str ( i11iiI1111 )
    except : OOooo = i111i11I1ii
    Ii1IIi . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
    Ii1IIi . close ( )
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    if 70 - 70: oOo0oooo00o + ii11ii1ii * iIii1I11I1II1 . OOooOOo * oOo0oooo00o
   Ii1IIi . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
   xbmc . sleep ( 500 )
   Ii1IIi . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   Ii1IIi . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
   xbmc . sleep ( 500 )
   Ii1IIi . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   Ii1IIi . close ( )
   if 49 - 49: ii1II11I1ii1I
   II1i11i1iIi11 = xbmcgui . ListItem ( path = i111i11I1ii )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
   if 25 - 25: IIIII . OoooooooOO * iIii1I11I1II1 . ii1II11I1ii1I / O0 + I1i1i1ii
  except :
   pass
   if 68 - 68: ii11ii1ii
  else :
   if 22 - 22: O00o0o0000o0o
   Oo00o0OO0O00o = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
   OOOo = Oo00o0OO0O00o
   I1iiIi1 = xbmcgui . ListItem ( trailer , path = OOOo )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1iiIi1 )
   return
   if 22 - 22: IIIII * oOo0oooo00o - ii11ii1ii * O0 / i11iIiiIii
def OOooO0Oo0o000 ( name , url ) :
 if 17 - 17: iIii1I11I1II1 + OOooOOo
 if '[Youtube]' in name :
  if 57 - 57: ii1II11I1ii1I / iiiI11
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  OOOo = url
  I1iiIi1 = xbmcgui . ListItem ( O0Oooo , path = OOOo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1iiIi1 )
  if 13 - 13: OoooooooOO + oO0ooO
  if 32 - 32: O0 + iiIIIII1i1iI % ii11ii1ii
 else :
  if 7 - 7: oO0o0ooO0 / oooOOOOO
  import urlresolver
  from urlresolver import common
  if 11 - 11: O00OoOoo00 * oooOOOOO / oooOOOOO - O00o0o0000o0o
  OOooo00 = urlresolver . HostedMediaFile ( url )
  if 68 - 68: OOooOOo % O00OoOoo00 - O00OoOoo00 / OOooOOo + oO0o0ooO0 - ii11ii1ii
  if not OOooo00 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 65 - 65: oooOOOOO - i1IIi
   if 62 - 62: oOo0oooo00o / iiIIIII1i1iI % ii11ii1ii . OoooooooOO / i11iIiiIii / iiiI11
  try :
   i111i11I1ii = OOooo00 . resolve ( )
   if not i111i11I1ii or not isinstance ( i111i11I1ii , basestring ) :
    try : OOooo = i111i11I1ii . msg
    except : OOooo = url
    raise Exception ( OOooo )
  except Exception as i11iiI1111 :
   try : OOooo = str ( i11iiI1111 )
   except : OOooo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 60 - 60: OOooOOo % iiIIIII1i1iI / ii1II11I1ii1I % iiIIIII1i1iI * i11iIiiIii / IIIII
  II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if II1I == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  II1i11i1iIi11 = xbmcgui . ListItem ( path = i111i11I1ii )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
  if 34 - 34: iiiI11 - O00o0o0000o0o
  if 25 - 25: iiIIIII1i1iI % OOooOOo + i11iIiiIii + O0 * OoooooooOO
 return
 if 64 - 64: i1IIi
def I1ii1i1iiii ( name , url ) :
 if 45 - 45: I1i1i1ii / oooOOOOO . OoooooooOO + oO0ooO
 import resolveurl
 if 51 - 51: IIIII % i11iIiiIii % O00OoOoo00 + iiiI11 % oO0o0ooO0
 OOooo00 = urlresolver . HostedMediaFile ( url )
 dp = xbmcgui . DialogProgress ( )
 dp . create ( 'Realstream:' , 'Conectando al servidor ... ' )
 dp . update ( 20 , 'Por favor, espere ...' )
 xbmc . sleep ( 500 )
 if 16 - 16: iI1Ii11111iIi / ii11ii1ii + O0 - iI1Ii11111iIi . OoooooooOO
 if not OOooo00 :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  return False
  if 19 - 19: ii1II11I1ii1I
 try :
  if 73 - 73: iiiI11 * ii11ii1ii * iI1Ii11111iIi
  dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
  xbmc . sleep ( 500 )
  i111i11I1ii = OOooo00 . resolve ( )
  if not i111i11I1ii or not isinstance ( i111i11I1ii , basestring ) :
   try : OOooo = i111i11I1ii . msg
   except : OOooo = i111i11I1ii
   raise Exception ( OOooo )
 except Exception as i11iiI1111 :
  try : OOooo = str ( i11iiI1111 )
  except : OOooo = i111i11I1ii
  dp . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
  dp . close ( )
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  if 65 - 65: i11iIiiIii + ii11ii1ii * OoooooooOO - oO0ooO
 dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
 xbmc . sleep ( 500 )
 dp . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
 xbmc . sleep ( 500 )
 dp . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
 xbmc . sleep ( 500 )
 dp . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
 dp . close ( )
 II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
 if 26 - 26: ii1II11I1ii1I % O00o0o0000o0o + O00o0o0000o0o % oOo0oooo00o * i11iIiiIii / IIIII
 if 64 - 64: iiIIIII1i1iI % iI1Ii11111iIi / II111iiii % oooOOOOO - IIIII
 if '[Realstream]' or '[Mybox]' in name :
  restante = IiII1IiiIiI1 . getSetting ( 'restante' )
 elif restante == 'true' :
  dialog = xbmcgui . Dialog ( )
  ok = dialog . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
 II1i11i1iIi11 = xbmcgui . ListItem ( path = i111i11I1ii )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
 if 2 - 2: iiiI11 - oO0o0ooO0 + ii1II11I1ii1I * oO0ooO / IIIII
def I1ii1i1iiii ( name , url ) :
 if 26 - 26: O00o0o0000o0o * ii11ii1ii
 if 31 - 31: oOo0oooo00o * iiIIIII1i1iI . I1i1i1ii
 if 'https://www.rapidvideo.com/v/' in url :
  if 35 - 35: oOo0oooo00o
  o0oOoO00o = i1 ( url )
  oOOoo00O0O = re . compile ( 'rapidvideo' ) . findall ( o0oOoO00o )
  for url in oOOoo00O0O :
   if 94 - 94: oooOOOOO / i11iIiiIii % O0
   if 70 - 70: oOo0oooo00o - ii11ii1ii / OoooooooOO % OoooooooOO
   try :
    II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
    if II1I == 'true' :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    II1i11i1iIi11 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
    if 95 - 95: OoooooooOO % OoooooooOO . I1i1i1ii
   except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 26 - 26: iiIIIII1i1iI + O00OoOoo00 - II111iiii . II111iiii + oO0o0ooO0 + iI1Ii11111iIi
   if 68 - 68: O0
 else :
  if 76 - 76: oO0o0ooO0
  import urlresolver
  from urlresolver import common
  if 99 - 99: ii1II11I1ii1I
  OOooo00 = urlresolver . HostedMediaFile ( url )
  if 1 - 1: I1i1i1ii * iI1Ii11111iIi * oO0ooO + ii11ii1ii
  if not OOooo00 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 90 - 90: iiiI11 % ii11ii1ii - ii11ii1ii . iIii1I11I1II1 / O00o0o0000o0o + oOo0oooo00o
   if 89 - 89: iiIIIII1i1iI
  try :
   i111i11I1ii = OOooo00 . resolve ( )
   if not i111i11I1ii or not isinstance ( i111i11I1ii , basestring ) :
    try : OOooo = i111i11I1ii . msg
    except : OOooo = url
    raise Exception ( OOooo )
  except Exception as i11iiI1111 :
   try : OOooo = str ( i11iiI1111 )
   except : OOooo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 87 - 87: IIIII % ii11ii1ii
  II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if II1I == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  II1i11i1iIi11 = xbmcgui . ListItem ( path = i111i11I1ii )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
  if 62 - 62: oO0ooO + oooOOOOO / IIIII * i11iIiiIii
 return
 if 37 - 37: IIIII
 if 33 - 33: oO0ooO - O0 - oO0ooO
 if 94 - 94: O00OoOoo00 * oOo0oooo00o * OoooooooOO / ii1II11I1ii1I . O00OoOoo00 - ii1II11I1ii1I
def I1I1i ( name , url ) :
 if 45 - 45: O00o0o0000o0o
 i111i11I1ii = url
 II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
 if II1I == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  II1i11i1iIi11 = xbmcgui . ListItem ( path = i111i11I1ii )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
 else :
  II1i11i1iIi11 = xbmcgui . ListItem ( path = i111i11I1ii )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
 return
 if 25 - 25: O00o0o0000o0o % O0
def I11 ( name , url ) :
 if 77 - 77: iI1Ii11111iIi / O00OoOoo00
 if 13 - 13: ii1II11I1ii1I
 if '[Youtube]' in name :
  if 73 - 73: O00o0o0000o0o
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 88 - 88: iiIIIII1i1iI % ii11ii1ii - oOo0oooo00o % iiIIIII1i1iI + O00OoOoo00 - IIIII
  try :
   II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if II1I == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    II1i11i1iIi11 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
    if 23 - 23: O0
    if 9 - 9: oOo0oooo00o * ii11ii1ii . oooOOOOO * i11iIiiIii - O0
    if 54 - 54: OOooOOo * O00o0o0000o0o + ii1II11I1ii1I % i1IIi - ii1II11I1ii1I + iI1Ii11111iIi
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 15 - 15: iI1Ii11111iIi * iiIIIII1i1iI + O00o0o0000o0o . oOo0oooo00o % OOooOOo - oooOOOOO
  if 13 - 13: iI1Ii11111iIi % iI1Ii11111iIi % ii11ii1ii % OOooOOo * i1IIi % oOo0oooo00o
 else :
  if 82 - 82: O00OoOoo00 . iI1Ii11111iIi / oooOOOOO + IIIII - oooOOOOO
  import xbmcgui
  import urlresolver
  from urlresolver import common
  if 55 - 55: oooOOOOO % ii11ii1ii % ii1II11I1ii1I
  OOooo00 = urlresolver . HostedMediaFile ( url )
  if 29 - 29: O00OoOoo00 / iIii1I11I1II1 + oO0o0ooO0 % IIIII % oOo0oooo00o
  if not OOooo00 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 46 - 46: iIii1I11I1II1
  import resolveurl as urlresolver
  if 70 - 70: i1IIi . oOo0oooo00o
  OOooo00 = urlresolver . HostedMediaFile ( url )
  if 74 - 74: oOo0oooo00o
  if 58 - 58: iIii1I11I1II1 * oO0ooO * iiiI11 * oooOOOOO . OoooooooOO
  if not OOooo00 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 6 - 6: oO0o0ooO0 - iiIIIII1i1iI * i11iIiiIii + iI1Ii11111iIi / oooOOOOO % O00o0o0000o0o
  try :
   i111i11I1ii = OOooo00 . resolve ( )
   if not i111i11I1ii or not isinstance ( i111i11I1ii , basestring ) :
    try : OOooo = i111i11I1ii . msg
    except : OOooo = url
    raise Exception ( OOooo )
  except Exception as i11iiI1111 :
   try : OOooo = str ( i11iiI1111 )
   except : OOooo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 38 - 38: O00o0o0000o0o % O00OoOoo00 % II111iiii - ii11ii1ii - iIii1I11I1II1
   if 9 - 9: ii1II11I1ii1I % oO0o0ooO0 . oO0o0ooO0
   if 28 - 28: OoooooooOO % iiIIIII1i1iI + oO0o0ooO0 + O0 . iiiI11
  II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if II1I == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 80 - 80: i11iIiiIii % oO0o0ooO0
   if '[Realstream]' in name :
    if 54 - 54: ii1II11I1ii1I + oOo0oooo00o - iIii1I11I1II1 % oooOOOOO % O00OoOoo00
    IIII = IiII1IiiIiI1 . getSetting ( 'restante' )
    if IIII == 'true' :
     I1IIIiii1 = xbmcgui . Dialog ( )
     I111I11I111 = I1IIIiii1 . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 19 - 19: oO0o0ooO0 / iIii1I11I1II1 % i1IIi . OoooooooOO
   II1i11i1iIi11 = xbmcgui . ListItem ( path = i111i11I1ii )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
   if 57 - 57: oooOOOOO . ii11ii1ii - oO0ooO - i11iIiiIii * iiiI11 / ii1II11I1ii1I
   if 79 - 79: oO0o0ooO0 + ii1II11I1ii1I % ii11ii1ii * ii1II11I1ii1I
   if 21 - 21: IIIII
 return
 if 24 - 24: IIIII / oooOOOOO
 if 61 - 61: iIii1I11I1II1 + iiIIIII1i1iI
 if 8 - 8: iiiI11 + oO0ooO
def i1Ii111 ( name , url ) :
 if 20 - 20: IIIII - oO0ooO - OoooooooOO
 if 100 - 100: iiIIIII1i1iI . iIii1I11I1II1 . iIii1I11I1II1
 if '[Youtube]' in name :
  if 55 - 55: iiIIIII1i1iI
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 37 - 37: O00OoOoo00 / i11iIiiIii / ii11ii1ii
  try :
   II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if II1I == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    II1i11i1iIi11 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
    if 97 - 97: iiiI11 . oOo0oooo00o / OOooOOo
    if 83 - 83: oOo0oooo00o - oO0o0ooO0 * iiIIIII1i1iI
    if 90 - 90: ii11ii1ii * OOooOOo
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 75 - 75: oO0o0ooO0 - iI1Ii11111iIi * i11iIiiIii . OoooooooOO - ii11ii1ii . oOo0oooo00o
 else :
  if 6 - 6: oOo0oooo00o * iiIIIII1i1iI / OoooooooOO % I1i1i1ii * ii1II11I1ii1I
  import resolveurl
  if 28 - 28: O00OoOoo00 * OOooOOo % O00OoOoo00
  OOooo00 = urlresolver . HostedMediaFile ( url )
  if 95 - 95: O0 / oOo0oooo00o . iiiI11
  if 17 - 17: oOo0oooo00o
  if not OOooo00 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 56 - 56: oooOOOOO * ii1II11I1ii1I + oOo0oooo00o
  try :
   i111i11I1ii = OOooo00 . resolve ( )
   if not i111i11I1ii or not isinstance ( i111i11I1ii , basestring ) :
    try : OOooo = i111i11I1ii . msg
    except : OOooo = url
    raise Exception ( OOooo )
  except Exception as i11iiI1111 :
   try : OOooo = str ( i11iiI1111 )
   except : OOooo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 48 - 48: O00OoOoo00 * oO0ooO % iiiI11 - oOo0oooo00o
   if 72 - 72: i1IIi % oooOOOOO % O00OoOoo00 % iiIIIII1i1iI - iiIIIII1i1iI
   if 97 - 97: ii1II11I1ii1I * O0 / ii1II11I1ii1I * oO0ooO * ii11ii1ii
  II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if II1I == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 38 - 38: iiiI11
   if '[Realstream]' in name :
    if 25 - 25: iIii1I11I1II1 % II111iiii / oOo0oooo00o / oO0o0ooO0
    IIII = IiII1IiiIiI1 . getSetting ( 'restante' )
    if IIII == 'true' :
     I1IIIiii1 = xbmcgui . Dialog ( )
     I111I11I111 = I1IIIiii1 . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 22 - 22: iiIIIII1i1iI * IIIII
   II1i11i1iIi11 = xbmcgui . ListItem ( path = i111i11I1ii )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
   if 4 - 4: iI1Ii11111iIi - iiIIIII1i1iI + OOooOOo
   if 36 - 36: O00OoOoo00
   if 19 - 19: iI1Ii11111iIi . ii1II11I1ii1I . OoooooooOO
 return
 if 13 - 13: O00o0o0000o0o . ii11ii1ii / II111iiii
def iiI1iIII1ii ( name , url ) :
 if 5 - 5: iiiI11 % OoooooooOO . iI1Ii11111iIi
 if 67 - 67: oO0o0ooO0 + I1i1i1ii
 if '[Youtube]' in name :
  if 72 - 72: O00OoOoo00 % ii1II11I1ii1I
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 93 - 93: iIii1I11I1II1 + i11iIiiIii . ii1II11I1ii1I . i1IIi % OOooOOo % oooOOOOO
  try :
   II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if II1I == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    II1i11i1iIi11 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
    if 74 - 74: iI1Ii11111iIi / i1IIi % OoooooooOO
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 52 - 52: O00OoOoo00 % oooOOOOO
 else :
  if 25 - 25: oOo0oooo00o / oOo0oooo00o % OoooooooOO - oO0o0ooO0 * iiIIIII1i1iI
  if 'https://team.com' in url :
   if 23 - 23: i11iIiiIii
   url = url . replace ( 'https://team.com' , 'https://verystream.com' )
   if 100 - 100: iiIIIII1i1iI + O0 . OOooOOo + i1IIi - iI1Ii11111iIi + ii1II11I1ii1I
  if 'https://mybox.com' in url :
   if 65 - 65: II111iiii / ii11ii1ii
   url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
   if 42 - 42: i11iIiiIii . O0
  if 'https://drive.com' in url :
   if 75 - 75: iiiI11 + iIii1I11I1II1
   url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
   if 19 - 19: OOooOOo + i11iIiiIii . O00OoOoo00 - oOo0oooo00o / I1i1i1ii + ii1II11I1ii1I
  if 'https://vid.co' in url :
   if 38 - 38: ii11ii1ii / iIii1I11I1II1 * iIii1I11I1II1 % oO0o0ooO0
   url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
   if 92 - 92: oOo0oooo00o / O0 * OOooOOo - oOo0oooo00o
  if 'https://limited.to' in url :
   if 99 - 99: i11iIiiIii % OoooooooOO
   url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
   if 56 - 56: O00OoOoo00 * iiiI11
  import resolveurl
  if 98 - 98: oOo0oooo00o + O0 * iiiI11 + i11iIiiIii - O00o0o0000o0o - iIii1I11I1II1
  OOooo00 = urlresolver . HostedMediaFile ( url )
  if 5 - 5: O00o0o0000o0o % ii11ii1ii % O00OoOoo00 % oooOOOOO
  if 17 - 17: I1i1i1ii + II111iiii + OoooooooOO / O00o0o0000o0o / O00OoOoo00
  if not OOooo00 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no encontrado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 80 - 80: ii1II11I1ii1I % i1IIi / oOo0oooo00o
  try :
   i111i11I1ii = OOooo00 . resolve ( )
   if not i111i11I1ii or not isinstance ( i111i11I1ii , basestring ) :
    try : OOooo = i111i11I1ii . msg
    except : OOooo = url
    raise Exception ( OOooo )
  except Exception as i11iiI1111 :
   try : OOooo = str ( i11iiI1111 )
   except : OOooo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace borrado, o no encontrado. Prueba a reiniciar el router o poner una VPN.[/COLOR]  ,5000)" )
   return False
   if 56 - 56: i1IIi . i11iIiiIii
   if 15 - 15: II111iiii * iiIIIII1i1iI % IIIII / i11iIiiIii - iiIIIII1i1iI + ii11ii1ii
   if 9 - 9: oOo0oooo00o - iiIIIII1i1iI + O0 / IIIII % i1IIi
   II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if II1I == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
    if 97 - 97: ii1II11I1ii1I * oooOOOOO
    if '[Realstream]' or '[Mybox]' in name :
     IIII = IiII1IiiIiI1 . getSetting ( 'restante' )
    elif IIII == 'true' :
     I1IIIiii1 = xbmcgui . Dialog ( )
     I111I11I111 = I1IIIiii1 . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 78 - 78: oOo0oooo00o . O00o0o0000o0o + iiIIIII1i1iI * IIIII - i1IIi
  II1i11i1iIi11 = xbmcgui . ListItem ( path = i111i11I1ii )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
  if 27 - 27: I1i1i1ii % i1IIi . ii11ii1ii % iiiI11
 return
 if 10 - 10: O00OoOoo00 / OoooooooOO
def IiiiIIiii ( name , url ) :
 if 91 - 91: ii1II11I1ii1I . IIIII % ii11ii1ii - IIIII . iiIIIII1i1iI % i11iIiiIii
 if 25 - 25: iIii1I11I1II1
 if '[Youtube]' in name :
  if 63 - 63: oooOOOOO
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 96 - 96: oOo0oooo00o
  try :
   II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
   if II1I == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    II1i11i1iIi11 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
    if 34 - 34: iI1Ii11111iIi / oO0ooO - OOooOOo . O0 . O00o0o0000o0o
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 63 - 63: IIIII
 else :
  if 11 - 11: IIIII - iIii1I11I1II1
  o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
  oo00 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  o00 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  Oo0oO0ooo = IiII1IiiIiI1 . getSetting ( 'key_ext' )
  o0oOoO00o = i1 ( o00 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for i11 in oOOoo00O0O :
   if 92 - 92: oO0ooO
   try :
    if 15 - 15: O00OoOoo00 / O00OoOoo00 + iIii1I11I1II1 % OoooooooOO
    if 12 - 12: oooOOOOO
    o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
    if 36 - 36: iiiI11 . O00OoOoo00 * OoooooooOO - ii1II11I1ii1I
    if 60 - 60: O00o0o0000o0o . IIIII / iIii1I11I1II1 + O00o0o0000o0o * iiiI11
    if o0oO0 == i11 :
     if 82 - 82: i11iIiiIii . iIii1I11I1II1 * OOooOOo - oOo0oooo00o + I1i1i1ii
     if 48 - 48: oO0o0ooO0
     if 'https://team.com' in url :
      if 96 - 96: oooOOOOO . OoooooooOO
      url = url . replace ( 'https://team.com' , 'https://verystream.com' )
      if 39 - 39: O00o0o0000o0o + oO0ooO
     if 'https://mybox.com' in url :
      if 80 - 80: O00o0o0000o0o % oO0ooO / iI1Ii11111iIi
      url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
      if 54 - 54: ii11ii1ii % oO0ooO - O00o0o0000o0o - oOo0oooo00o
      if 71 - 71: oooOOOOO . i11iIiiIii
     if 'https://vidcloud.co/' in url :
      if 56 - 56: O0 * IIIII + IIIII * iIii1I11I1II1 / oooOOOOO * iiiI11
      url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
      if 25 - 25: iIii1I11I1II1 . oOo0oooo00o * i11iIiiIii + ii11ii1ii * oOo0oooo00o
     if 'https://gounlimited.to' in url :
      if 67 - 67: IIIII
      url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
      if 88 - 88: ii11ii1ii
     if 'https://drive.com' in url :
      if 8 - 8: oO0o0ooO0
      url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
      if 82 - 82: OoooooooOO
      if 75 - 75: II111iiii % OOooOOo + O00o0o0000o0o % OoooooooOO / O00OoOoo00
     import resolveurl
     if 4 - 4: i11iIiiIii - O00o0o0000o0o % oO0o0ooO0 * iiiI11 % ii1II11I1ii1I
     OOooo00 = urlresolver . HostedMediaFile ( url )
     if 71 - 71: oooOOOOO . oooOOOOO - iIii1I11I1II1
     if not OOooo00 :
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
      return False
      if 22 - 22: OoooooooOO / oO0o0ooO0 % IIIII * iI1Ii11111iIi
     try :
      Ii1IIi = xbmcgui . DialogProgress ( )
      Ii1IIi . create ( 'Realstream:' , 'Iniciando ...' )
      Ii1IIi . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
      xbmc . sleep ( 1000 )
      if 32 - 32: OoooooooOO % iiIIIII1i1iI % iIii1I11I1II1 / O0
      i111i11I1ii = OOooo00 . resolve ( )
      if not i111i11I1ii or not isinstance ( i111i11I1ii , basestring ) :
       if 61 - 61: II111iiii . O0 - I1i1i1ii - oO0o0ooO0 / i11iIiiIii - II111iiii
       try : OOooo = i111i11I1ii . msg
       except : OOooo = url
       raise Exception ( OOooo )
       if 98 - 98: I1i1i1ii - OOooOOo . i11iIiiIii * ii11ii1ii
     except Exception as i11iiI1111 :
      try : OOooo = str ( i11iiI1111 )
      except : OOooo = url
      Ii1IIi . update ( 45 , 'RESOLVEURL:' , 'Reiniciando ... ' )
      xbmc . sleep ( 1000 )
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no disponible.  ,3000)" )
      Ii1IIi . close ( )
      if 29 - 29: I1i1i1ii / oooOOOOO % oOo0oooo00o
     Ii1IIi . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
     xbmc . sleep ( 500 )
     Ii1IIi . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
     xbmc . sleep ( 1000 )
     Ii1IIi . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
     Ii1IIi . close ( )
     II1I = IiII1IiiIiI1 . getSetting ( 'notificar' )
     II1i11i1iIi11 = xbmcgui . ListItem ( path = i111i11I1ii )
     xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i11i1iIi11 )
     if 10 - 10: iIii1I11I1II1 % OoooooooOO % oO0o0ooO0
     if 39 - 39: II111iiii * iI1Ii11111iIi . O0 * oOo0oooo00o
    else :
     if 89 - 89: I1i1i1ii - oooOOOOO . oOo0oooo00o - iiiI11 - OOooOOo
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold]>El addon esta desactivado.[/COLOR]" )
     return False
     if 79 - 79: O00OoOoo00 + O00OoOoo00 + I1i1i1ii
   except :
    pass
    if 39 - 39: O0 - OoooooooOO
 return
 if 63 - 63: iIii1I11I1II1 % ii1II11I1ii1I * oooOOOOO
def oo0 ( ) :
 if 17 - 17: O0 + OoooooooOO
 if 78 - 78: II111iiii + O00OoOoo00
 oOo = [ ]
 o0oO00O0Oo00 = sys . argv [ 2 ]
 if len ( o0oO00O0Oo00 ) >= 2 :
  Oo0o0ooOoO = sys . argv [ 2 ]
  iI1Ii11 = Oo0o0ooOoO . replace ( '?' , '' )
  if ( Oo0o0ooOoO [ len ( Oo0o0ooOoO ) - 1 ] == '/' ) :
   Oo0o0ooOoO = Oo0o0ooOoO [ 0 : len ( Oo0o0ooOoO ) - 2 ]
  Ooo0 = iI1Ii11 . split ( '&' )
  oOo = { }
  for IiiiIIi in range ( len ( Ooo0 ) ) :
   I1IIIi = { }
   I1IIIi = Ooo0 [ IiiiIIi ] . split ( '=' )
   if ( len ( I1IIIi ) ) == 2 :
    oOo [ I1IIIi [ 0 ] ] = I1IIIi [ 1 ]
 return oOo
 if 87 - 87: II111iiii % O0 - oO0ooO . oOo0oooo00o / ii1II11I1ii1I * O00o0o0000o0o
 if 26 - 26: iiiI11 . I1i1i1ii + OOooOOo . iI1Ii11111iIi + O00o0o0000o0o
def I1Ii1I ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  import urlresolver
  xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
  if 8 - 8: OOooOOo - iiiI11 * oOo0oooo00o % OoooooooOO / iI1Ii11111iIi
def I1Io0oO0oo ( ) :
 I1IIIiii1 = xbmcgui . Dialog ( )
 list = (
 ooOO00Oo ,
 oO00OOOOOO0o
 )
 if 18 - 18: oO0o0ooO0 / ii11ii1ii - IIIII
 ii1iii1I1I = I1IIIiii1 . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=%s]Accede a themoviedb.com[/COLOR]' % oOooOOOoOo ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 69 - 69: iiIIIII1i1iI / O00OoOoo00 * oooOOOOO
 if ii1iii1I1I :
  if 81 - 81: iiIIIII1i1iI
  if ii1iii1I1I < 0 :
   return
  OOoOoo0 = list [ ii1iii1I1I - 2 ]
  return OOoOoo0 ( )
 else :
  OOoOoo0 = list [ ii1iii1I1I ]
  return OOoOoo0 ( )
 return
 if 62 - 62: I1i1i1ii + O0 * oO0ooO
def iioOo0OoOOo0 ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 59 - 59: II111iiii
O0Oo00 = iioOo0OoOOo0 ( )
if 43 - 43: ii11ii1ii + OoooooooOO
def ooOO00Oo ( ) :
 if O0Oo00 == 'android' :
  oOo0oO = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  oOo0oO = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 47 - 47: oooOOOOO
  if 92 - 92: oOo0oooo00o % i11iIiiIii % ii11ii1ii
def oO00OOOOOO0o ( ) :
 if 23 - 23: II111iiii * IIIII
 main ( )
 if 80 - 80: iiiI11 / i11iIiiIii + OoooooooOO
 if 38 - 38: oO0o0ooO0 % oooOOOOO + i1IIi * OoooooooOO * iiIIIII1i1iI
 if 83 - 83: iIii1I11I1II1 - oooOOOOO - iiiI11 / oO0ooO - O0
def O00OoO0oo ( ) :
 I1IIIiii1 = xbmcgui . Dialog ( )
 O00oo = (
 Ii11iI1iI ,
 o0oOI1Ii1IIIiII
 )
 if 11 - 11: O0 * iI1Ii11111iIi
 ii1iii1I1I = I1IIIiii1 . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 37 - 37: iI1Ii11111iIi + O0 . O0 * ii11ii1ii % iiiI11 / IIIII
 if ii1iii1I1I :
  if 18 - 18: OoooooooOO
  if ii1iii1I1I < 0 :
   return
  OOoOoo0 = O00oo [ ii1iii1I1I - 2 ]
  return OOoOoo0 ( )
 else :
  OOoOoo0 = O00oo [ ii1iii1I1I ]
  return OOoOoo0 ( )
 return
 if 57 - 57: oooOOOOO . iI1Ii11111iIi * ii1II11I1ii1I - OoooooooOO
def iioOo0OoOOo0 ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 75 - 75: i11iIiiIii / ii1II11I1ii1I . O00OoOoo00 . i1IIi . i1IIi / oOo0oooo00o
O0Oo00 = iioOo0OoOOo0 ( )
if 94 - 94: oooOOOOO + OOooOOo
def Ii11iI1iI ( ) :
 if O0Oo00 == 'android' :
  oOo0oO = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  oOo0oO = webbrowser . open ( 'https://olpair.com/' )
  if 56 - 56: iI1Ii11111iIi % ii1II11I1ii1I
  if 40 - 40: O00o0o0000o0o / O00OoOoo00
def o0oOI1Ii1IIIiII ( ) :
 if 29 - 29: I1i1i1ii - I1i1i1ii / oooOOOOO
 main ( )
 if 49 - 49: oOo0oooo00o + iiIIIII1i1iI % oO0ooO - ii11ii1ii - O0 - OoooooooOO
 if 4 - 4: II111iiii - iiIIIII1i1iI % ii11ii1ii * i11iIiiIii
def iIiII1iiiiI ( name , url , id , trailer ) :
 I1IIIiii1 = xbmcgui . Dialog ( )
 O00oo = (
 OOOOooO0 ,
 oO0ooo0O0Ooo ,
 iiI111i1 ,
 I1Io0oO0oo ,
 IiIii11i1IIiI
 )
 if 40 - 40: IIIII + iIii1I11I1II1 * iiIIIII1i1iI + i11iIiiIii . i11iIiiIii
 ii1iii1I1I = I1IIIiii1 . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % oOooOOOoOo ,

 '[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % oOooOOOoOo ,

 '[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % oOooOOOoOo ,

 '[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % oOooOOOoOo ,

 '[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % oOooOOOoOo ] )
 if 11 - 11: oO0ooO % OoooooooOO
 if ii1iii1I1I :
  if 20 - 20: iiiI11 + iiiI11 * II111iiii * iIii1I11I1II1 % O0 * OOooOOo
  if ii1iii1I1I < 0 :
   return
  OOoOoo0 = O00oo [ ii1iii1I1I - 5 ]
  return OOoOoo0 ( )
 else :
  OOoOoo0 = O00oo [ ii1iii1I1I ]
  return OOoOoo0 ( )
 return
 if 62 - 62: OoooooooOO / iI1Ii11111iIi . O00OoOoo00 . O00OoOoo00 % oooOOOOO
 if 42 - 42: ii1II11I1ii1I . O00o0o0000o0o - oooOOOOO
 if 33 - 33: II111iiii / O0 / O00OoOoo00 - oOo0oooo00o - i1IIi
def OOOOooO0 ( ) :
 if 8 - 8: i11iIiiIii . IIIII / iIii1I11I1II1 / oO0o0ooO0 / O00OoOoo00 - I1i1i1ii
 IiiiIIiii ( i1Iii11I1i , Oo00o0OO0O00o )
 if 32 - 32: ii1II11I1ii1I . i1IIi * ii11ii1ii
def oO0ooo0O0Ooo ( ) :
 if 98 - 98: I1i1i1ii - II111iiii / OOooOOo . iiIIIII1i1iI * O00OoOoo00 . oOo0oooo00o
 I1i ( i1Iii11I1i , O0Oooo )
 if 25 - 25: i11iIiiIii / iI1Ii11111iIi - iiiI11 / oO0ooO . ii1II11I1ii1I . ii1II11I1ii1I
def iiI111i1 ( ) :
 if 6 - 6: iiIIIII1i1iI . oOo0oooo00o
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  iIIII1 = id
  if 65 - 65: O0 / II111iiii . iIii1I11I1II1 . iiIIIII1i1iI / ii11ii1ii % iIii1I11I1II1
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % iIIII1 )
  if 74 - 74: i1IIi / OOooOOo % oO0o0ooO0 / O0 % oOo0oooo00o - iI1Ii11111iIi
 if II1I == 'true' :
  if 31 - 31: OOooOOo / OoooooooOO . iIii1I11I1II1 * iI1Ii11111iIi . OoooooooOO + II111iiii
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + i1Iii11I1i + "[/COLOR] ,5000)" )
  if 8 - 8: oO0o0ooO0 * oO0o0ooO0 * i1IIi + IIIII . oO0o0ooO0
def Ooooo0O0 ( ) :
 if 99 - 99: ii11ii1ii + i11iIiiIii
 I1Io0oO0oo ( )
 if 36 - 36: I1i1i1ii * iiiI11 * iIii1I11I1II1 - oOo0oooo00o % i11iIiiIii
def IiIii11i1IIiI ( ) :
 if 98 - 98: iIii1I11I1II1 - i1IIi + oooOOOOO % oOo0oooo00o + oooOOOOO / iiIIIII1i1iI
 O0O00Ooo ( )
def iI1iIIIi1i ( name , url , mode , iconimage , fanart ) :
 if 97 - 97: O00OoOoo00 % oooOOOOO + II111iiii - O00OoOoo00 % oO0ooO + oooOOOOO
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 I111I11I111 = True
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  oOO0oo = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii , isFolder = True )
  return I111I11I111
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii , isFolder = True )
 return I111I11I111
 if 31 - 31: ii1II11I1ii1I
def OoO0Ooo ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 35 - 35: iI1Ii11111iIi + I1i1i1ii * oooOOOOO / iI1Ii11111iIi
 ii111iI1iIi1 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 69 - 69: oooOOOOO . O00o0o0000o0o - OOooOOo
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 IiIi = [ ]
 if 44 - 44: II111iiii . II111iiii + O00o0o0000o0o * I1i1i1ii
 IiIi . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , fanart )
 II1iIi1IiIii . setProperty ( 'IsPlayable' , 'true' )
 if 16 - 16: II111iiii
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  IiIi . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 100 - 100: O0 - i1IIi
  II1iIi1IiIii . addContextMenuItems ( IiIi , replaceItems = True )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii )
 return I111I11I111
 if 48 - 48: iiIIIII1i1iI % oooOOOOO + O0
def iI1i ( name , url , mode , iconimage , fanart ) :
 if 27 - 27: oO0o0ooO0 / O00o0o0000o0o
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 33 - 33: OoooooooOO % oO0o0ooO0 . O0 / oO0o0ooO0
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , fanart )
 II1iIi1IiIii . setProperty ( 'IsPlayable' , 'true' )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii )
 return I111I11I111
 if 63 - 63: O00OoOoo00 + iIii1I11I1II1 + OOooOOo + iiiI11
def oOOoO0O ( name , url , mode ) :
 if 76 - 76: i1IIi / iIii1I11I1II1 - oO0o0ooO0 - II111iiii
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 76 - 76: i11iIiiIii + O00OoOoo00 % iI1Ii11111iIi
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = OOOOoOo00OO )
 II1iIi1IiIii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 II1iIi1IiIii . setProperty ( 'fanart_image' , II1i1Ii11Ii11 )
 II1iIi1IiIii . setProperty ( 'IsPlayable' , 'true' )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii )
 return I111I11I111
 if 6 - 6: IIIII
def ooOi11iii1Ii1 ( name , url , mode , iconimage ) :
 oOO0oo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 I111I11I111 = True
 II1iIi1IiIii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 I111I11I111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOO0oo , listitem = II1iIi1IiIii , isFolder = True )
 return I111I11I111
 if 86 - 86: oooOOOOO / i11iIiiIii
def IiI ( ) :
 if 13 - 13: i1IIi
 if 48 - 48: O0 + oO0ooO . IIIII * ii1II11I1ii1I * IIIII
 if 69 - 69: oO0ooO - OoooooooOO - O00o0o0000o0o % oOo0oooo00o / iI1Ii11111iIi - II111iiii
 OOOO0O00o = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 OOOO0O00o . doModal ( )
 if ( OOOO0O00o . isConfirmed ( ) ) :
  if 67 - 67: O00o0o0000o0o + O00o0o0000o0o + oO0ooO . i11iIiiIii + oO0o0ooO0 + i11iIiiIii
  i1II = urllib . quote_plus ( OOOO0O00o . getText ( ) ) . replace ( '+' , ' ' )
  if 31 - 31: iiIIIII1i1iI * iiiI11 . iI1Ii11111iIi * oOo0oooo00o
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 28 - 28: O00OoOoo00 + OOooOOo - ii11ii1ii % O00o0o0000o0o . oOo0oooo00o + OOooOOo
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % i1II )
    if 72 - 72: I1i1i1ii / ii11ii1ii / iiIIIII1i1iI * iI1Ii11111iIi + O00o0o0000o0o
    if II1I == 'true' :
     if 58 - 58: ii1II11I1ii1I % OOooOOo . OOooOOo * oO0ooO - O00OoOoo00 . OoooooooOO
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + i1Iii11I1i + "[/COLOR] ,10000)" )
     if 10 - 10: iiiI11
   except :
    if 48 - 48: IIIII * i1IIi % OoooooooOO * I1i1i1ii * oO0ooO
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 7 - 7: IIIII . I1i1i1ii . IIIII - iiiI11
    if 33 - 33: oooOOOOO + OoooooooOO - oO0ooO / i1IIi / OoooooooOO
    if 82 - 82: oO0o0ooO0 / O00o0o0000o0o - IIIII / ii11ii1ii * oO0ooO
Oo0o0ooOoO = oo0 ( )
Oo00o0OO0O00o = None
i1Iii11I1i = None
o00OIIIIIiiI = None
OOOOoOo00OO = None
id = None
O0Oooo = None
if 38 - 38: O0
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 79 - 79: i1IIi . iiIIIII1i1iI
try :
 Oo00o0OO0O00o = urllib . unquote_plus ( Oo0o0ooOoO [ "url" ] )
except :
 pass
try :
 i1Iii11I1i = urllib . unquote_plus ( Oo0o0ooOoO [ "name" ] )
except :
 pass
try :
 o00OIIIIIiiI = int ( Oo0o0ooOoO [ "mode" ] )
except :
 pass
try :
 OOOOoOo00OO = urllib . unquote_plus ( Oo0o0ooOoO [ "iconimage" ] )
except :
 pass
try :
 id = int ( Oo0o0ooOoO [ "id" ] )
except :
 pass
try :
 O0Oooo = urllib . unquote_plus ( Oo0o0ooOoO [ "trailer" ] )
except :
 pass
 if 34 - 34: iiiI11 * II111iiii
 if 71 - 71: O00OoOoo00
print "Mode: " + str ( o00OIIIIIiiI )
print "URL: " + str ( Oo00o0OO0O00o )
print "Name: " + str ( i1Iii11I1i )
print "iconimage: " + str ( OOOOoOo00OO )
print "id: " + str ( id )
print "trailer: " + str ( O0Oooo )
if 97 - 97: oO0o0ooO0
if o00OIIIIIiiI == None or Oo00o0OO0O00o == None or len ( Oo00o0OO0O00o ) < 1 :
 if i1Ii == ii111iI1iIi1 :
  if 86 - 86: ii11ii1ii - O00o0o0000o0o . iI1Ii11111iIi . II111iiii * OOooOOo . II111iiii
  if 34 - 34: ii1II11I1ii1I . iiiI11 % O00OoOoo00 - O0 / iiiI11
  iIi1Ii1i1iI ( )
  if 91 - 91: i11iIiiIii % iiiI11 * iiIIIII1i1iI - oO0o0ooO0 . iiiI11
  if 28 - 28: i11iIiiIii
  o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
  oo00 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  o00 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  Oo0oO0ooo = IiII1IiiIiI1 . getSetting ( 'key_ext' )
  o0oOoO00o = i1 ( o00 )
  oOOoo00O0O = re . compile ( i1111 ) . findall ( o0oOoO00o )
  for i11 in oOOoo00O0O :
   try :
    if 51 - 51: OOooOOo + oooOOOOO * O0 . I1i1i1ii
    if 82 - 82: O00o0o0000o0o * oO0o0ooO0 % I1i1i1ii . O00o0o0000o0o
    o0oO0 = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
    if 43 - 43: oO0ooO . oooOOOOO * ii11ii1ii
    if 20 - 20: i1IIi . i1IIi - oOo0oooo00o
    if o0oO0 == i11 :
     if 89 - 89: oooOOOOO - oOo0oooo00o . O0 % OoooooooOO . i11iIiiIii
     if 35 - 35: II111iiii / iI1Ii11111iIi - O0 . II111iiii
     if 55 - 55: ii11ii1ii % i1IIi * oOo0oooo00o
     O0O00Ooo ( )
     if 95 - 95: O00o0o0000o0o / II111iiii - ii1II11I1ii1I % iiiI11 . oOo0oooo00o
    else :
     if 63 - 63: iIii1I11I1II1 / oooOOOOO
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold]>El addon esta desactivado.[/COLOR]" )
     if 24 - 24: ii11ii1ii / iIii1I11I1II1 % O00o0o0000o0o * iI1Ii11111iIi - iIii1I11I1II1
     if 50 - 50: II111iiii
   except :
    pass
    if 39 - 39: II111iiii . iI1Ii11111iIi - ii11ii1ii * i1IIi . OoooooooOO
 else :
  xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red][B]Error, de inicio. ¿Tienes Instalado Realstream?[/B][/COLOR]" )
  if 44 - 44: OOooOOo
  if 55 - 55: iiIIIII1i1iI . iiiI11 * iiiI11
  if 82 - 82: OOooOOo % oO0ooO % oOo0oooo00o + oOo0oooo00o
elif o00OIIIIIiiI == 1 :
 iIiII1iiiiI ( i1Iii11I1i , Oo00o0OO0O00o , id , O0Oooo )
elif o00OIIIIIiiI == 2 :
 I1Iii1iI1 ( )
elif o00OIIIIIiiI == 3 :
 o0OOoo ( )
elif o00OIIIIIiiI == 4 :
 OOooO0Oo0o000 ( i1Iii11I1i , Oo00o0OO0O00o )
elif o00OIIIIIiiI == 5 :
 IIi11 ( )
elif o00OIIIIIiiI == 6 :
 iI11Ii111 ( )
elif o00OIIIIIiiI == 7 :
 iIIi1iI1 ( )
elif o00OIIIIIiiI == 8 :
 i1iii1ii ( )
elif o00OIIIIIiiI == 9 :
 OoO0O0oO00 ( )
elif o00OIIIIIiiI == 10 :
 iiIiII11i1 ( )
elif o00OIIIIIiiI == 11 :
 I1iI11I1III1 ( )
elif o00OIIIIIiiI == 12 :
 iiiIIIii ( )
elif o00OIIIIIiiI == 13 :
 i1II1II1iii1i ( )
elif o00OIIIIIiiI == 14 :
 o0Oii111 ( )
elif o00OIIIIIiiI == 15 :
 II1i11 ( )
elif o00OIIIIIiiI == 16 :
 OooOooO0O0o0 ( )
elif o00OIIIIIiiI == 17 :
 Oo0oO00 ( )
elif o00OIIIIIiiI == 18 :
 iI1iIIiii ( )
elif o00OIIIIIiiI == 19 :
 iiiii111 ( )
elif o00OIIIIIiiI == 20 :
 I1IiII1iI1 ( )
elif o00OIIIIIiiI == 21 :
 iiiIiIIII1iiIIi ( )
elif o00OIIIIIiiI == 22 :
 iI111II1ii ( )
elif o00OIIIIIiiI == 23 :
 OooOOOoOoo0O0 ( )
elif o00OIIIIIiiI == 24 :
 o0oOo00 ( )
elif o00OIIIIIiiI == 25 :
 ooiiI1ii ( )
elif o00OIIIIIiiI == 26 :
 II1 ( )
elif o00OIIIIIiiI == 28 :
 oOO0o000Oo00o ( i1Iii11I1i , Oo00o0OO0O00o )
elif o00OIIIIIiiI == 29 :
 ooOoOO ( )
elif o00OIIIIIiiI == 30 :
 Ii ( )
elif o00OIIIIIiiI == 98 :
 busqueda_global ( )
elif o00OIIIIIiiI == 97 :
 O00OoO0oo ( )
elif o00OIIIIIiiI == 99 :
 o0OooooOoOO ( )
elif o00OIIIIIiiI == 100 :
 menu_player ( i1Iii11I1i , Oo00o0OO0O00o )
elif o00OIIIIIiiI == 111 :
 o0OOOo ( )
elif o00OIIIIIiiI == 115 :
 I1i ( Oo00o0OO0O00o )
elif o00OIIIIIiiI == 116 :
 iIiiiii1i ( )
elif o00OIIIIIiiI == 117 :
 oOO ( )
elif o00OIIIIIiiI == 119 :
 oo0oO ( )
elif o00OIIIIIiiI == 120 :
 ooO0oO00O0o ( )
elif o00OIIIIIiiI == 121 :
 OoO ( )
elif o00OIIIIIiiI == 125 :
 OoOO ( )
elif o00OIIIIIiiI == 112 :
 iI11I ( )
elif o00OIIIIIiiI == 127 :
 IiI ( )
elif o00OIIIIIiiI == 128 :
 TESTLINKS ( )
elif o00OIIIIIiiI == 130 :
 IiiiIIiii ( i1Iii11I1i , Oo00o0OO0O00o )
elif o00OIIIIIiiI == 140 :
 i11i1iIiii ( )
elif o00OIIIIIiiI == 141 :
 IiI11I111 ( )
elif o00OIIIIIiiI == 142 :
 ii1I11iIiIII1 ( )
elif o00OIIIIIiiI == 143 :
 iiIii1IIi ( i1Iii11I1i , Oo00o0OO0O00o )
elif o00OIIIIIiiI == 144 :
 oOO0o000Oo00o ( i1Iii11I1i , Oo00o0OO0O00o )
elif o00OIIIIIiiI == 145 :
 OO0o0oO ( )
elif o00OIIIIIiiI == 150 :
 OoO000O ( )
elif o00OIIIIIiiI == 151 :
 IiIIiIIIiIii ( )
elif o00OIIIIIiiI == 152 :
 i11111I1I ( )
 if 6 - 6: ii11ii1ii
xbmcplugin . endOfDirectory ( o0OoOoOO00 ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
