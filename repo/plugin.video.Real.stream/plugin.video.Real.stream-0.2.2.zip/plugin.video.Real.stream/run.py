# -*- coding: utf-8 -*-
# Real stream by Netai 2019
import urllib, urllib2, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import cookielib,base64,webbrowser
import traceback,datetime,HTMLParser,httplib
import urlresolver
import kodi
try:
    import json
except:
    import simplejson as json
	
##########################################
# Conf settings: Database links Protect.
#
#########################################



addon = xbmcaddon.Addon('plugin.video.Real.stream')
addon_version = addon.getAddonInfo('version')
plugin_handle = int(sys.argv[1])
mysettings = xbmcaddon.Addon(id = 'plugin.video.Real.stream')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
extended = xbmc.translatePath(os.path.join(home, 'extended_info.png'))
buscar = xbmc.translatePath(os.path.join(home, 'buscar.png'))
pair = xbmc.translatePath(os.path.join(home, 'openload.jpg'))
theMovieDB = xbmc.translatePath(os.path.join(home, 'theMovieDB.jpg'))
novedades = xbmc.translatePath(os.path.join(home, 'estrenos.png'))
estrenos = xbmc.translatePath(os.path.join(home, 'encines.jpg'))
recomendadas = xbmc.translatePath(os.path.join(home, 'recomendadas.jpg'))
p_accion = xbmc.translatePath(os.path.join(home, 'accion.jpg'))
animacion = xbmc.translatePath(os.path.join(home, 'animacion.jpg'))
aventuras = xbmc.translatePath(os.path.join(home, 'aventuras.jpg'))
belico = xbmc.translatePath(os.path.join(home, 'belico.jpg'))
cifi = xbmc.translatePath(os.path.join(home, 'ciencia-ficcion.jpg'))
comedia = xbmc.translatePath(os.path.join(home, 'comedia.jpg'))
crimen = xbmc.translatePath(os.path.join(home, 'crimen.jpg'))
drama = xbmc.translatePath(os.path.join(home, 'drama.jpg'))
familiar = xbmc.translatePath(os.path.join(home, 'familiar.jpg'))
fantasia = xbmc.translatePath(os.path.join(home, 'fantasia.jpg'))
historia = xbmc.translatePath(os.path.join(home, 'historia.jpg'))
superheroes = xbmc.translatePath(os.path.join(home, 'marvel.png'))
misterio = xbmc.translatePath(os.path.join(home, 'misterio.jpg'))
musical = xbmc.translatePath(os.path.join(home, 'musical.jpg'))
romance = xbmc.translatePath(os.path.join(home, 'romance.jpg'))
spain = xbmc.translatePath(os.path.join(home, 'spain.jpg'))
suspense = xbmc.translatePath(os.path.join(home, 'suspense.jpg'))
terror = xbmc.translatePath(os.path.join(home, 'terror.jpg'))
thriller = xbmc.translatePath(os.path.join(home, 'thriller.jpg'))
western = xbmc.translatePath(os.path.join(home, 'western.jpg'))
sagas = xbmc.translatePath(os.path.join(home, 'sagas_cine.jpg'))
menu_pelis = xbmc.translatePath(os.path.join(home, 'peliculas.png'))
ajustes = xbmc.translatePath(os.path.join(home, 'ajustes.png'))
vid = xbmc.translatePath(os.path.join(home, 'videoteca.png'))
favicon = xbmc.translatePath(os.path.join(home, 'favorites.png'))
mostrar_cat = addon.getSetting('mostrar_cat')
videos = addon.getSetting('videos')
activar = addon.getSetting('activar')
anticopia = addon.getSetting('anticopia')
notificar = addon.getSetting('notificar') 
aviso = addon.getSetting('aviso')
RealStream_Settings = addon.getSetting('notificar')
fav = addon.getSetting('fav') 
u_tube = 'http://www.youtube.com'
texto = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0vYmllbnZlbmlkYS50eHQ='.decode(base64)
urly = 'aHR0cDovL3kzei5zag=='.decode('base64')
decode32 = '.xsl.pt'
myurl = urly + decode32



def url():

	link = make_request(myurl)
	match = re.compile(reg_url).findall(link)
	
	for enlace in match:
		try:
			links = enlace
			
		except:
			pass
			
def urls(): 

    url()

	cat = make_request(links)
	match = re.compile(url_regex).findall(cat)
	for lk,lk1,lk2,lk3,lk4,lk5,lk6,lk7,lk8,lk9,lk10,lk11,lk12,lk13,lk14,lk15,lk16,lk17,lk18,lk19,lk20,lk21,lk22,lk23 in match:

        try:
             
			lk = l0
			lk1 = l1
			lk2 = l2
			lk3 = l3
			lk4 = l4
			lk5 = l5
			lk6 = l6
			lk7 = l7
			lk8 = l8
			lk9 = l9
			lk10 = l10
			lk11 = l11
			lk12 = l12
			lk13 = l13
			lk14 = l14
			lk15 = l15
			lk16 = l16
			lk17 = l17
			lk18 = l18
			lk19 = l19
			lk20 = l20
			lk21 = l21
			lk22 = l22
			lk23 = l23
			
	
	
			op = l0
			op1 = l1
			op2 = l2
			op3 = l3
			op4 = l4
			op5 = l5
			op6 = l6
			op7 = l7
			op8 = l8
			op9 = l9
			op10 = l10
			op11 = l11
			op12 = l12
			op13 = l13
			op14 = l14
			op15 = l15
			op16 = l16
			op17 = l17
			op18 = l18
			op19 = l19
			op20 = l20
			op21 = l21
			op22 = l22
			op23 = l23

        except:
			pass

		
##REGEX:
texto_regex = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*texto3=[\'"](.*?)[\'"]\s*'
m3u_thumb_regex = 'tvg-logo=[\'"](.*?)[\'"]'
m3u_regex = '#(.+?),(.+)\s*(.+)\s*(.*)'
url_regex = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
reg_url = 'enlace=[\'"](.*?)[\'"]'
def mensaje(): 

	content = make_request(texto)
	match = re.compile(texto_regex).findall(content)
	for texto1,texto2,texto3 in match:
		try:
		
			msg1 = texto1
			msg2 = texto2
			msg3 = texto3
		
			aviso = addon.getSetting('aviso')
			if aviso == 'true':
				line1 = "[COLOR=red][B]" + msg1 + "[/B][/COLOR]"
				line2 = "[COLOR yellow]" + msg2 + "[/COLOR]"
				line3 = "[COLOR yellow]" + msg3 + "[/COLOR]"

			xbmcgui.Dialog().ok("Real Stream", line1, line2, line3)
			


			if not xbmc.getCondVisibility('System.HasAddon(script.extendedinfo)'):
				xbmcgui.Dialog().ok("El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]","[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]")

			
		except:
			pass
			

def removeAccents(s):
## Nos cargamos los acentos, phyton no los usa ni los reconoce. 
	return ''.join((c for c in unicodedata.normalize('NFD', s.decode('utf-8')) if unicodedata.category(c) != 'Mn'))
					
def read_file(file):
## FUNCION QUE LEE LOS FICHEROS:
    try:
        f = open(file, 'r')
        content = f.read()
        f.close()
        return content
    except:
        pass

def make_request(url):
##ESTA FUNCION lee las url declaradas donde estan los videos. ||
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0')
		response = urllib2.urlopen(req)	  
		link = response.read()
		response.close()  
		return link
	except urllib2.URLError, e:
		print 'We failed to open "%s".' % url
		if hasattr(e, 'code'):
			print 'We failed with error code - %s.' % e.code	
		if hasattr(e, 'reason'):
			print 'We failed to reach a server.'
			print 'Reason: ', e.reason
			
def OPEN_URL(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36')
        req.add_header('Referer', '%s'%url)
        req.add_header('Connection', 'keep-alive')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link


def conf_menu():

    if activar == 'true':
	add_dir('[COLOR dodgerblue]Menu Peliculas[/COLOR] ', 'movieDB', 116, menu_pelis, fanart)
	
	if fav == 'true':
		add_dir('[COLOR orange]favoritos Real stream[/COLOR]', 'movieDB', 121, favicon, fanart)
	
    if RealStream_Settings == 'true':
        add_dir('[COLOR orange]Ajustes[/COLOR]', 'Settings', 119, ajustes, fanart)
    		
	if mostrar_cat == 'true':
		peliculas()
		
	if videos == 'true':
		add_dir('[COLOR orange]Mis enlaces[/COLOR]', 'movieDB', 120, vid, fanart)		
 
	if anticopia == 'false':

		line1 = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
		line2 = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver para su correcto funcionamiento.[/COLOR]"
		line3 = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"

		xbmcgui.Dialog().ok("Real Stream", line1, line2, line3)
		


def menu():
	add_dir('[COLOR lime]The movie DB[/COLOR]', 'movieDB', 99, theMovieDB, fanart)
	
#	add_dir('[COLOR orange]Ajustes[/COLOR]', 'Settings', 119, ajustes, fanart)
#	add_dir('[COLOR orange]Mis enlaces[/COLOR]', 'video', 120, videoteca, fanart)
#   add_dir('[COLOR lime]The movie DB[/COLOR]', 'movieDB', 99, theMovieDB, fanart)
#	add_dir('[COLOR orange]Ajustes[/COLOR]', 'Settings', 119, ajustes, fanart)
#	add_dir('[COLOR red]Autorizar[/COLOR] [COLOR aquamarine][B]OPENLOAD[/B][/COLOR]', 'movieDB', 97, pair, fanart)
#	add_dir('[COLOR orange]Mis enlaces[/COLOR]', 'movieDB', 120, vid, fanart)
	add_dir('[COLOR red]Autorizar[/COLOR] [COLOR aquamarine][B]OPENLOAD[/B][/COLOR]', 'movieDB', 97, pair, fanart)
	conf_menu()

			

def videoteca():
    if not xbmc.getCondVisibility('System.HasAddon(plugin.program.videoteca)'):
		xbmcgui.Dialog().ok("El programa videoteca no esta instalado ..." , "[COLOR gold]Necesario AddOn externo para agregar enlaces desde la nube[/COLOR]","[COLOR yellow]Por favor, Agrege la fuente: http://netai.eu/netai desde ajustes > agregar fuente\n [COLOR lime]Instalar desde Zip > netai > Plugin.program.videoteca[/COLOR]")
    else:
    xbmc.executebuiltin('RunAddon(plugin.program.videoteca)')
	
def favoritos():

	if not xbmc.getCondVisibility('System.HasAddon(plugin.program.real.stream.fav)'):
		xbmcgui.Dialog().ok("La dependencia Real stream favoritos no esta instalada ..." , "[COLOR gold]Necesario AddOn externo para agregar Favoritos dentro del addon por categorias.[/COLOR]","[COLOR yellow]Por favor, Agrege la fuente: http://netai.eu/netai desde ajustes > agregar fuente\n [COLOR lime]Instalar desde Zip > netai > plugin.program.real.stream.fav[/COLOR]")
    else:
    xbmc.executebuiltin('RunAddon(plugin.program.real.stream.fav)')
    

def Real_stream_settings():
    addon.openSettings()
	
	
def peliculas():
	add_dir('[COLOR yellow]Buscador[/COLOR]', 'searchlink', 111, buscar, fanart)
	add_dir('[COLOR orange]Novedades[/COLOR]',u_tube,3,novedades,fanart)
	add_dir('[COLOR orange]Estrenos[/COLOR]',u_tube,2,estrenos,fanart)
	add_dir('[COLOR orange]Recomendadas[/COLOR]',u_tube,4,recomendadas,fanart)
	add_dir('[COLOR orange]Accion[/COLOR]',u_tube,5,p_accion,fanart)
	add_dir('[COLOR orange]Animacion[/COLOR]',u_tube,6,animacion,fanart)
	add_dir('[COLOR orange]Aventuras[/COLOR]',u_tube,7,aventuras,fanart)
	add_dir('[COLOR orange]Belico[/COLOR]',u_tube,8,belico,fanart)
	add_dir('[COLOR orange]Ciencia Ficcion[/COLOR]',u_tube,9,cifi,fanart)
	add_dir('[COLOR orange]Comedia[/COLOR]',u_tube,10,comedia,fanart)
	add_dir('[COLOR orange]Crimen[/COLOR]',u_tube,11,crimen,fanart)
	add_dir('[COLOR orange]Drama[/COLOR]',u_tube,12,drama,fanart)
	add_dir('[COLOR orange]Familiar[/COLOR]',u_tube,13,familiar,fanart)
	add_dir('[COLOR orange]Fantasia[/COLOR]',u_tube,14,fantasia,fanart)
	add_dir('[COLOR orange]Historica[/COLOR]',u_tube,15,historia,fanart)
	add_dir('[COLOR orange]Misterio[/COLOR]',u_tube,16,misterio,fanart)
	add_dir('[COLOR orange]Musical[/COLOR]',u_tube,17,musical,fanart)
	add_dir('[COLOR orange]Romance[/COLOR]',u_tube,18,romance,fanart)
	add_dir('[COLOR orange]Thriller[/COLOR]',u_tube,19,thriller,fanart)
	add_dir('[COLOR orange]Suspense[/COLOR]',u_tube,20,suspense,fanart)
	add_dir('[COLOR orange]Terror[/COLOR]',u_tube,21,terror,fanart)
	add_dir('[COLOR orange]Western[/COLOR]',u_tube,22,western,fanart)
	add_dir('[COLOR orange]Spain[/COLOR]',u_tube,23,spain,fanart)
	add_dir('[COLOR orange]Super heroes[/COLOR]',u_tube,24,superheroes,fanart)
	add_dir('[COLOR orange]Saga de Peliculas[/COLOR]',u_tube,25,sagas,fanart)
	

	
def get_info_movie():

    # prompt the user to input search text
    kb = xbmc.Keyboard('', 'Titulo de la pelicula')
    kb.doModal()
    if not kb.isConfirmed():
        return None;
    name = kb.getText().strip()
	

    if xbmc.getCondVisibility('system.platform.android'):
	
	opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' +name+ '&language=es-ES'  ) )
	
        
	return 'android'

    elif xbmc.getCondVisibility('system.platform.windows'):
	
	opensite = webbrowser . open('https://www.themoviedb.org/search?query=' +name+ '&language=es-ES')
  
	
	return 'windows'
	
def search(): 	
## ESTA FUNCION BUSCA EN LAS LISTAS m3u DENTRO DE LAS CATEGORIAS. | Cuantas mas categorias, mas lento ira el buscador a no ser que hagamos buscadores individuales.
	try:
		keyb = xbmc.Keyboard('', 'Nombre de la pelicula')
		keyb.doModal()
		if (keyb.isConfirmed()):
		
			searchText = urllib.quote_plus(keyb.getText()).replace('+', ' ')
			content_db = make_request(op) + make_request(op1) + make_request(op2) + make_request(op3) + make_request(op4) + make_request(op5) + make_request(op6) + make_request(op7) + make_request(op8) + make_request(op9) + make_request(op10) + make_request(op11) + make_request(op12) + make_request(op13) + make_request(op14) + make_request(op15) + make_request(op16) + make_request(op17) + make_request(op18) + make_request(op19) + make_request(op20) + make_request(op21) + make_request(op22) + make_request(op23)
			match = re.compile(m3u_regex).findall(content_db)
			
			for thumb, name, url, id in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(thumb, name, url, id)
	except:
		pass
		

	
		
def Novedades(): 
## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
def Estrenos(): 
## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op1)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
def Recomendadas(): 
## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op2)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass

def Accion(): 
## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op3)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
def Animacion(): 
## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op4)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
def Aventuras(): 
## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op5)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
def Belico(): 
## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op6)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
def Cifi(): 
## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op7)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
			
def Comedia(): 
## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op8)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
			
def Crimen(): 
## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op9)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
			
def Drama(): 
## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op10)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
def Familiar(): 
## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op11)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
			
def Fantasia(): 
## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op12)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
			
def Historia(): 
## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op13)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
def Misterio(): 
## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op14)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
			
def Musical(): 
## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op15)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
def Romance(): 
## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op16)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
			
def Thriller(): 
## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op17)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
			
def Suspense(): 
## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op18)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
			
def Terror(): 
## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op19)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
			
def Western(): 
## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op20)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
			
def Spain(): 
## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op21)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
			
def Superheroes(): 
## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op22)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass
def Sagas(): 
## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op23)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id in match:
		try:
			m3u_playlist(thumb, name, url, id)
		except:
			pass			

def playlist(thumb, name, url, id):	

	name = re.sub('\s+', ' ', name).strip()			
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		if 'tvg-logo' in thumb:
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')			
			add_dir(name, url, '', thumb, thumb)			
		else:	
			add_dir(name, url, '', icon, fanart)
	else:
		if 'youtube.com/watch?v=' in url:
			url = 'plugin://plugin.video.youtube/play/?video_id=%s' % (url.split('=')[-1])
		elif 'dailymotion.com/video/' in url:
			url = url.split('/')[-1].split('_')[0]
			url = 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=%s' % url	
		else:			
			url = url
		if 'tvg-logo' in thumb:				
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
			add_link(name, url, 1, thumb, thumb)			
		else:				
			add_link(name, url, 1, icon, fanart)	

def m3u_playlist(thumb, name, url, id):	
## despues de obtener las url de la lista m3u las muestra.
	name = re.sub('\s+', ' ', name).strip()			
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		if 'tvg-logo' in thumb:
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')			
			add_dir(name, url, '', thumb, thumb)		
		else:	
			add_dir(name, url, '', icon, fanart)
	else:
		if 'youtube.com/watch?v=' in url:
			url = 'plugin://plugin.video.youtube/play/?video_id=%s' % (url.split('=')[-1])
		elif 'dailymotion.com/video/' in url:
			url = url.split('/')[-1].split('_')[0]
			url = 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=%s' % url	
		else:			
			url = url
		if 'tvg-logo' in thumb:				
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
			
			add_link(name, url, 1, thumb, thumb, id)
			
		else:
            	
			add_link(name, url, 1, icon, fanart, id)
						
            
def play_video(url):
## Cuando se clica en el enlace de la url obtenida, si la lista es .m3u hara 'if' y si es texto plano hara else.
	if '.m3u8' in url:
		url = url.replace("http://","plugin://plugin.video.f4mTester/?url=http://").replace(".m3u8",".ts")
		url = url + "&amp;streamtype=TSDOWNLOADER"
		media_url = url
		item = xbmcgui.ListItem(name, path = media_url)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
		return
	else:
		media_url = url
		item = xbmcgui.ListItem(name, path = media_url)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
		return			

def PLAYVIDEO(name,url):
    import urlresolver
    from urlresolver import common
    url=urlresolver.HostedMediaFile(url).resolve()
    media_url = url	
    item = xbmcgui.ListItem(name, path = media_url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)



def get_params():
## Codigo de shani de Live Stream Pro Con este script se obtienen los parametros. Sino sabes ... dejalo como lo puso Shani que asi funciona.

	param = []
	paramstring = sys.argv[2]
	if len(paramstring)>= 2:
		params = sys.argv[2]
		cleanedparams = params.replace('?', '')
		if (params[len(params)-1] == '/'):
			params = params[0:len(params)-2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams = {}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0]] = splitparams[1]
	return param
	


def ThemovieDB():
    dialog = xbmcgui.Dialog()
    list = (
        opc1,
        opc2
        )
        
    call = dialog.select('[B][COLOR=orange]The Movie db[/COLOR][/B]', [
	'[COLOR=gold]Accede a themoviedb.com[/COLOR]', 
    
	'[B][COLOR=white]                           Volver al Menu [/COLOR][/B]',])

    if call:
        # esc is not pressed
        if call < 0:
            return
        func = list[call-2]
        return func()
    else:
        func = list[call]
        return func()
    return 

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()

def opc1():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
    else:
        opensite = webbrowser . open('https://www.themoviedb.org/movie/')

        
def opc2():

    main()
	
	
	
def PAIR():
    dialog = xbmcgui.Dialog()
    funcs = (
        functionA,
        functionB
        )
        
    call = dialog.select('[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]', [
	'[COLOR=orange]                       Pair OpenLoad [/COLOR]', 
    
	'[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]',])

    if call:
        # esc is not pressed
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()

def functionA():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
    else:
        opensite = webbrowser . open('https://olpair.com/')

        
def functionB():

    main()
	

def selector(name,url,id):
    dialog = xbmcgui.Dialog()
    funcs = (
        function1,
        function2,
		gopair,
		goThemovieDB,
        )
        
    call = dialog.select('[B][COLOR=yellow]REAL STREAM MENU:[/COLOR][/B]', [
	'[COLOR=lime]*Ver:   [/COLOR][B][COLOR gold]' +name+ '[/COLOR][/B]', 
    
	'[B][COLOR=yellow]  *Ampliar Informacion, ver trailers  [/COLOR][/B]',
	
	'[COLOR=red][B]PAIR:[/B][COLOR=blue] OPENLOAD[/COLOR]',
	
	'[COLOR orange][B]*Accede a la web MovieDB[/B][/COLOR]',])

    if call:
        # esc is not pressed
        if call < 0:
            return
        func = funcs[call-4]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def function1():
    PLAYVIDEO(name,url)
	
    if notificar == 'true':
	
		xbmc.executebuiltin("XBMC.Notification(Real Stream, play: [COLOR orange]" +name+ "[/COLOR] ,25000)")
        
def function2():
    
    if xbmc.getCondVisibility('System.HasAddon(script.extendedinfo)'):
	movie_id = id
	
	xbmc.executebuiltin( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % movie_id )

    if notificar == 'true':	
	
		xbmc.executebuiltin("XBMC.Notification(Extended Info,Abriendo: [COLOR green]" +name+ "[/COLOR] ,10000)")
#    __addon__ = xbmcaddon.Addon()
#    __addonname__ = __addon__.getAddonInfo('name')

#    line1 = "[COLOR=blue]                [B]     Extended info script[/COLOR][COLOR gold] by Phil65 dev Kodi.[/B][/COLOR]"
#    line2 = "[COLOR gold]Real stream: Nosotros no alojamos peliculas en nuestro script, solo enlazamos a contenido externo, libre en servidores publicos de internet. Por lo tanto no somos responsables de dicho contenido. Este contenido es propiedad de sus respectivos dueños.[/COLOR]"
#    line3 = "[COLOR lime]Agradecimientos a Ciberus de Torrentin por ayudarme con su adaptacion en Real Stream. Disfrute de su pelicula.[/COLOR]"

#    xbmcgui.Dialog().ok(__addonname__, line1, line2, line3)
	
def gopair():

    PAIR()
    


def goThemovieDB():

    ThemovieDB()
	
def add_dir(name, url, mode, iconimage, fanart, showcontext=False):

	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
	ok = True
	liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		u = 'plugin://plugin.video.youtube/%s/%s/' % (url.split( '/' )[-2], url.split( '/' )[-1])
		ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
		return ok		
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
	return ok
	
def add_link(name, url, mode, iconimage, fanart, id):

	try:
            name = name.encode('utf-8')
        except: pass
	commands=[]
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&id=" + str(id)	
	liz = xbmcgui.ListItem(name, id, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'true') 
	
	if xbmc.getCondVisibility('System.HasAddon(script.extendedinfo)'):
		commands.append(("[B][COLOR yellow]ExtendedInfo[/COLOR][/B]","XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % (name,id) ))	
		liz.addContextMenuItems(commands, replaceItems=True)
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz)
	return ok

	
   	
params = get_params()
url = None
name = None
mode = None
iconimage = None
id = None


try:
	url = urllib.unquote_plus(params["url"])
except:
	pass
try:
	name = urllib.unquote_plus(params["name"])
except:
	pass
try:
	mode = int(params["mode"])
except:
	pass
try:
	iconimage = urllib.unquote_plus(params["iconimage"])
except:
	pass 
try:
	id = int(params["id"])
except:
	pass 
	

print "Mode: " + str(mode)
print "URL: " + str(url)
print "Name: " + str(name)
print "iconimage: " + str(iconimage)

    	


if mode == None or url == None or len(url) < 1:
	menu()
	mensaje()
elif mode == 1:
    selector(name,url,id)
elif mode == 2:
    Novedades()
elif mode == 3:
	Estrenos()
elif mode == 4:
    Recomendadas()
elif mode == 5:
    Accion()
elif mode == 6:
    Animacion()
elif mode == 7:
    Aventuras()
elif mode == 8:
    Belico()
elif mode == 9:
    Cifi()
elif mode == 10:
    Comedia()
elif mode == 11:
    Crimen()
elif mode == 12:
    Drama()
elif mode == 13:
    Familiar()
elif mode == 14:
    Fantasia()
elif mode == 15:
    Historia()
elif mode == 16:
    Misterio()
elif mode == 17:
    Musical()
elif mode == 18:
    Romance()
elif mode == 19:
    Thriller()
elif mode == 20:
    Suspense()
elif mode == 21:
    Terror()
elif mode == 22:
    Western()
elif mode == 23:
    Spain()
elif mode == 24:
    Superheroes()
elif mode == 25:
    Sagas()	
elif mode == 98:
    busqueda_global()
elif mode == 97:
    PAIR()
elif mode == 99:
    get_info_movie()
elif mode == 100:
    menu_player(name,url)
elif mode == 111:
    search()
elif mode == 115:
    play_video(url) 
elif mode == 116:
    peliculas()	
elif mode == 119:
    Real_stream_settings()
elif mode == 120:
    videoteca()
elif mode == 121:
    favoritos()    
xbmcplugin.endOfDirectory(plugin_handle)			