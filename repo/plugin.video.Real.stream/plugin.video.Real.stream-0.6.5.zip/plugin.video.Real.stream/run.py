# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 0.5.5 
#
############################################
#
# Incluido Script ResolveURL Por Jsergio.
#
############################################
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import urlresolver
import cookielib , base64
import requests
import plugintools
import config
if 64 - 64: i11iIiiIii
OO0o = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
Oo0Ooo = OO0o . getAddonInfo ( 'version' )
O0O0OO0O0O0 = int ( sys . argv [ 1 ] )
iiiii = 'gruponetai/'
ooo0OO = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
II1 = ooo0OO . getAddonInfo ( 'profile' )
O00ooooo00 = ooo0OO . getAddonInfo ( 'path' )
if 32 - 32: ooOoO + iIiiiI1IiI1I1 * IIiIiII11i * o0oOOo0O0Ooo
I1ii11iIi11i = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'fanart.jpg' ) )
I1IiI = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'icon.png' ) )
o0OOO = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'extended_info.png' ) )
iIiiiI = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'buscar.png' ) )
Iii1ii1II11i = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'pair.png' ) )
iI111iI = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'theMovieDB.jpg' ) )
IiII = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'estrenos.png' ) )
iI1Ii11111iIi = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'encines.jpg' ) )
i1i1II = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'recomendadas.jpg' ) )
O0oo0OO0 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'accion.jpg' ) )
I1i1iiI1 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'animacion.jpg' ) )
iiIIIII1i1iI = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'aventuras.jpg' ) )
o0oO0 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'belico.jpg' ) )
oo00 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'ciencia-ficcion.jpg' ) )
o00 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'comedia.jpg' ) )
Oo0oO0ooo = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'crimen.jpg' ) )
o0oOoO00o = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'drama.jpg' ) )
i1 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'familiar.jpg' ) )
oOOoo00O0O = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'fantasia.jpg' ) )
i1111 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'historia.jpg' ) )
i11 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'marvel.png' ) )
I11 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'misterio.jpg' ) )
Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'musical.jpg' ) )
oOo0oooo00o = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'romance.jpg' ) )
oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'spain.jpg' ) )
oo0o0O00 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'suspense.jpg' ) )
oO = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'terror.jpg' ) )
i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'thriller.jpg' ) )
oooOOOOO = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'western.jpg' ) )
i1iiIII111ii = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'sagas_cine.jpg' ) )
i1iIIi1 = xbmc . translatePath ( os . path . join ( O00ooooo00 , '4k.jpg' ) )
ii11iIi1I = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'torrent.jpg' ) )
if 6 - 6: I1I11I1I1I * OooO0OO
iiiIi = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'peliculas.png' ) )
IiIIIiI1I1 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'ajustes.png' ) )
OoO000 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'videoteca.png' ) )
IIiiIiI1 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'favorites.png' ) )
iiIiIIi = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'resolver.png' ) )
ooOoo0O = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'test.png' ) )
OooO0 = xbmc . translatePath ( os . path . join ( O00ooooo00 , 'video-tutoriales.png' ) )
if 35 - 35: Ooooo0Oo00oO0 % Ooo . oo0Oo00Oo0 % oOOO00o
O0O00o0OOO0 = OO0o . getSetting ( 'mostrar_cat' )
Ii1iIIIi1ii = OO0o . getSetting ( 'videos' )
o0oo0o0O00OO = OO0o . getSetting ( 'activar' )
o0oO = OO0o . getSetting ( 'favcopy' )
I1i1iii = OO0o . getSetting ( 'anticopia' )
i1iiI11I = OO0o . getSetting ( 'licencia_addon' )
iiii = OO0o . getSetting ( 'notificar' )
oO0o0O0OOOoo0 = OO0o . getSetting ( 'mostrar_bus' )
IiIiiI = OO0o . getSetting ( 'restante' )
I1I = OO0o . getSetting ( 'aviso' )
oOO00oOO = OO0o . getSetting ( 'RealStream_Settings' )
OoOo = OO0o . getSetting ( 'Resolver_Settings' )
IiIiiI = OO0o . getSetting ( 'restante' )
iI = OO0o . getSetting ( 'fav' )
o00O = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
OOO0OOO00oo = 'bienvenida'
Iii111II = 'bienvenida'
iiii11I = OO0o . getSetting ( 'Forceupdate' )
if iiii11I == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
Ooo0OO0oOO = '.txt'
if 50 - 50: i1i1i11IIi
II1III = o00O + OOO0OOO00oo + Ooo0OO0oOO
iI1iI1I1i1I = 'http://www.youtube.com'
iIi11Ii1 = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
Ii11iII1 = '.xsl.pt'
Oo0O0O0ooO0O = '/master/'
IIIIii = iIi11Ii1 + Ii11iII1
O0o0 = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*texto3=[\'"](.*?)[\'"]\s*'
OO00Oo = 'tvg-logo=[\'"](.*?)[\'"]'
if 51 - 51: oO0OOoO0 * O00Oo000ooO0 + oO0 * Ii1iIiII1ii1
ooOooo000oOO = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)'
Oo0oOOo = '#(.+?),(.+)\s*(.+)'
Oo0OoO00oOO0o = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
if 80 - 80: O0O0O0OoOO + iiiI1I11i1 % Oo0o00 + O0O0oOO00O00o
iI1ii11iIi1i = 'source src=[\'"](.*?)[\'"]\s*title=[\'"](.*?)[\'"]'
iiI111I1iIiI = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
II = '[\'"](.*?)[\'"]'
Ii1I1IIii1II = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( 'base64' )
O0 = Ii1I1IIii1II + iiiii
ii1ii1ii = '[\'"](.*?)[\'"]'
oooooOoo0ooo = 'Realstream'
I1I1IiI1 = 'video=[\'"](.*?)[\'"]'
III1iII1I1ii = '0110nhu' . replace ( '0110nhu' , 'nhu' )
oOOo0 = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( 'base64' ) + III1iII1I1ii
oo00O00oO = '0110R0N' . replace ( '0110R0N' , 'R0N' )
iIiIIIi = 'aHR0cDovL2JpdC5seS8yWEIx' . decode ( 'base64' ) + oo00O00oO
ooo00OOOooO = '0110BGc' . replace ( '0110BGc' , 'BGc' )
O00OOOoOoo0O = 'aHR0cDovL2JpdC5seS8ySXFu' . decode ( 'base64' ) + ooo00OOOooO
O000OOo00oo = 'ABBAOb5' . replace ( 'ABBAOb5' , 'Ob5' )
oo0OOo = 'aHR0cDovL2JpdC5seS8yRVhV' . decode ( 'base64' ) + O000OOo00oo
ooOOO00Ooo = '0110jaw' . replace ( '0110jaw' , 'jaw' )
IiIIIi1iIi = 'aHR0cDovL2JpdC5seS8yd01M' . decode ( 'base64' ) + ooOOO00Ooo
ooOOoooooo = '01109DI' . replace ( '01109DI' , '9DI' )
II1I = 'aHR0cDovL2JpdC5seS8ySXgz' . decode ( 'base64' ) + ooOOoooooo
O0i1II1Iiii1I11 = '01103hs' . replace ( '01103hs' , '3hs' )
IIII = 'aHR0cDovL2JpdC5seS8zMW1U' . decode ( 'base64' ) + O0i1II1Iiii1I11
iiIiI = '01107DW' . replace ( '01107DW' , '7DW' )
o00oooO0Oo = 'aHR0cDovL2JpdC5seS8yV1ln' . decode ( 'base64' ) + iiIiI
o0O0OOO0Ooo = '0110mLl' . replace ( '0110mLl' , 'mLl' )
iiIiII1 = 'aHR0cDovL2JpdC5seS8yS0cw' . decode ( 'base64' ) + o0O0OOO0Ooo
OOO00O0O = '01102Hj' . replace ( '01102Hj' , '2Hj' )
iii = 'aHR0cDovL2JpdC5seS8yWEJo' . decode ( 'base64' ) + OOO00O0O
oOooOOOoOo = '0110fXg' . replace ( '0110fXg' , 'fXg' )
i1Iii1i1I = 'aHR0cDovL2JpdC5seS8ySTVy' . decode ( 'base64' ) + oOooOOOoOo
OOoO00 = '0110NMH' . replace ( '0110NMH' , 'NMH' )
IiI111111IIII = 'aHR0cDovL2JpdC5seS8yd0t6' . decode ( 'base64' ) + OOoO00
i1Ii = '0110bwQ' . replace ( '0110bwQ' , 'bwQ' )
ii111iI1iIi1 = 'aHR0cDovL2JpdC5seS8yd01V' . decode ( 'base64' ) + i1Ii
OOO = '0110xzG' . replace ( '0110xzG' , 'xzG' )
oo0OOo0 = 'aHR0cDovL2JpdC5seS8yWHhz' . decode ( 'base64' ) + OOO
I11IiI = '0110x64' . replace ( '0110x64' , 'x64' )
O0ooO0Oo00o = 'aHR0cDovL2JpdC5seS8yRVlF' . decode ( 'base64' ) + I11IiI
ooO0oOOooOo0 = '0110vUE' . replace ( '0110vUE' , 'vUE' )
i1I1ii11i1Iii = 'aHR0cDovL2JpdC5seS8yWmhW' . decode ( 'base64' ) + ooO0oOOooOo0
I1IiiiiI = '01107ZL' . replace ( '01107ZL' , '7ZL' )
o0O = 'aHR0cDovL2JpdC5seS8yWm4w' . decode ( 'base64' ) + I1IiiiiI
IiIIii1iII1II = '01106cf' . replace ( '01106cf' , '6cf' )
Iii1I1I11iiI1 = 'aHR0cDovL2JpdC5seS8yRVlk' . decode ( 'base64' ) + IiIIii1iII1II
I1I1i1I = '0110Jtp' . replace ( '0110Jtp' , 'Jtp' )
ii1I = 'aHR0cDovL2JpdC5seS8yV3Nq' . decode ( 'base64' ) + I1I1i1I
O0oO0 = '0110a5b' . replace ( '0110a5b' , 'a5b' )
oO0O0OO0O = 'aHR0cDovL2JpdC5seS8yV3dj' . decode ( 'base64' ) + O0oO0
OO = '0110Q7u' . replace ( '0110Q7u' , 'Q7u' )
OoOoO = 'aHR0cDovL2JpdC5seS8yV3NL' . decode ( 'base64' ) + OO
Ii1I1i = '0110rsq' . replace ( '0110rsq' , 'rsq' )
OOI1iI1ii1II = 'aHR0cDovL2JpdC5seS8ySzhE' . decode ( 'base64' ) + Ii1I1i
O0O0OOOOoo = '0110DDR' . replace ( '0110DDR' , 'DDR' )
oOooO0 = 'aHR0cDovL2JpdC5seS8ySzd5' . decode ( 'base64' ) + O0O0OOOOoo
Ii1I1Ii = '0110feQ' . replace ( '0110feQ' , 'feQ' )
OOoO0 = 'aHR0cDovL2JpdC5seS8yS0cz' . decode ( 'base64' ) + Ii1I1Ii
OO0Oooo0oOO0O = '0110MHY' . replace ( '0110MHY' , 'MHY' )
o00O0 = 'aHR0cDovL2JpdC5seS8ySXVo' . decode ( 'base64' ) + OO0Oooo0oOO0O
oOO0O00Oo0O0o = '0110xdb' . replace ( '0110xdb' , 'xdb' )
ii1 = 'aHR0cDovL2JpdC5seS8yWEJu' . decode ( 'base64' ) + oOO0O00Oo0O0o
I1iIIiiIIi1i = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( 'base64' )
O0O0ooOOO = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
if 77 - 77: oo0Oo00Oo0 - I1I11I1I1I - O0O0oOO00O00o
def IiiiIIiIi1 ( ) :
 if 74 - 74: iIiiiI1IiI1I1 * i1i1i11IIi + oo0Oo00Oo0 / o0oOOo0O0Ooo / I1I11I1I1I . Ooooo0Oo00oO0
 if 62 - 62: IIiIiII11i * OooO0OO
 try :
  if 58 - 58: oo0Oo00Oo0 % oOOO00o
  i1OOoO = OO0O000 ( iIiIIIi )
  iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( i1OOoO )
  for oO0O00oOOoooO in iiIiI1i1 :
   try :
    if 46 - 46: OooO0OO - IIiIiII11i - oO0 * I1I11I1I1I
    O00OOOoOoo0O = oO0O00oOOoooO
    if 34 - 34: oO0 - O0O0O0OoOO / O00Oo000ooO0 + i1i1i11IIi * Ii1iIiII1ii1
    OOOO0OoOO0o0o = xbmc . Keyboard ( '' , 'Busqueda por titulo, año, servidor:' )
    OOOO0OoOO0o0o . doModal ( )
    if ( OOOO0OoOO0o0o . isConfirmed ( ) ) :
     if 95 - 95: i11iIiiIii
     iI1111iiii = urllib . quote_plus ( OOOO0OoOO0o0o . getText ( ) ) . replace ( '+' , ' ' )
     Oo0OO = OO0O000 ( O00OOOoOoo0O )
     iiIiI1i1 = re . compile ( ooOooo000oOO ) . findall ( Oo0OO )
     if 78 - 78: O00Oo000ooO0 - IIiIiII11i - i1i1i11IIi / O0O0oOO00O00o / I1I11I1I1I
     for iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 , id , IIo0Oo0oO0oOO00 in iiIiI1i1 :
      if re . search ( iI1111iiii , oo00OO0000oO ( Ooo0OOoOoO0 . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       I1II1 ( Ooo0OOoOoO0 , oOo0OOoO0 , iiI11ii1I1 , id , IIo0Oo0oO0oOO00 )
   except :
    pass
 except :
  pass
  if 86 - 86: iIiiiI1IiI1I1 / oo0Oo00Oo0 . I1I11I1I1I
def II1i111Ii1i ( ) :
 if 15 - 15: I1I11I1I1I / o0oOOo0O0Ooo
 O0oO0iII11 = OO0O000 ( I1iIIiiIIi1i )
 iiIiI1i1 = re . compile ( II ) . findall ( O0oO0iII11 )
 for iiIiii1IIIII in iiIiI1i1 :
  try :
   if 67 - 67: Ii1iIiII1ii1 / iiiI1I11i1
   import xbmc
   import xbmcaddon
   if 9 - 9: ooOoO % ooOoO - oOOO00o
   __addon__ = xbmcaddon . Addon ( )
   __addonname__ = __addon__ . getAddonInfo ( 'name' )
   __icon__ = __addon__ . getAddonInfo ( 'icon' )
   if 51 - 51: OooO0OO . iIiiiI1IiI1I1 - i1i1i11IIi / ooOoO
   Oo0Ooo = OO0o . getAddonInfo ( 'version' )
   if 52 - 52: oOOO00o + ooOoO + O0O0O0OoOO + Ooooo0Oo00oO0 % O0O0O0OoOO
   OOIi1iI111II1I1 = "[COLOR lime]Version oficial: " + iiIiii1IIIII + "  Verion instalada: " + Oo0Ooo + "[/COLOR]"
   oOOOOoOO0o = 5000
   if 1 - 1: I1I11I1I1I
   xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , OOIi1iI111II1I1 , oOOOOoOO0o , __icon__ ) )
   if 68 - 68: O0O0O0OoOO - OooO0OO / Oo0o00 / oO0
   if 12 - 12: Ii1iIiII1ii1 + i11iIiiIii * iIiiiI1IiI1I1 / i1i1i11IIi . oO0
  except :
   pass
   if 5 - 5: o0oOOo0O0Ooo + iiiI1I11i1 / oOOO00o . O0O0O0OoOO / oO0
   if 32 - 32: OooO0OO % iIiiiI1IiI1I1 / o0oOOo0O0Ooo - OooO0OO
def I1III1111iIi ( ) :
 if 38 - 38: O0O0O0OoOO + oO0 / Oo0o00 % O0O0oOO00O00o - i1i1i11IIi
 if 14 - 14: oO0OOoO0 / Oo0o00
 Ii1iIIIi1ii = OO0o . getSetting ( 'videos' )
 if Ii1iIIIi1ii == 'true' :
  if 85 - 85: oO0
  try :
   if 20 - 20: oO0OOoO0 % iiiI1I11i1
   import urlresolver
   from urlresolver import common
   import random
   from random import choice
   III1i1i11i = xbmc . Player ( )
   OoO000 = [ 'iHJAKUyjomI' , '_pqbkWaTGX0' , '5sSQINZQjfU' , 'hEl07wzNkaE' , 'hflGH4jKU0k' , '1qP8wVmQ1eI' ]
   oOo0 = random . choice ( OoO000 )
   oOo0OOoO0 = 'https://www.youtube.com/watch?v=%s' % oOo0
   oOo0OOoO0 = urlresolver . HostedMediaFile ( oOo0OOoO0 ) . resolve ( )
   III1i1i11i . play ( oOo0OOoO0 )
   if 56 - 56: oOOO00o + I1I11I1I1I + oo0Oo00Oo0 - O0O0oOO00O00o . oo0Oo00Oo0
   Ii1iIIIi1ii == 'false'
   if 84 - 84: Ooo + o0oOOo0O0Ooo - I1I11I1I1I . i1i1i11IIi * IIiIiII11i + OooO0OO
  except :
   pass
   if 38 - 38: O00Oo000ooO0 + I1I11I1I1I % O0O0oOO00O00o % oo0Oo00Oo0 - Ii1iIiII1ii1 / IIiIiII11i
   if 73 - 73: oOOO00o * ooOoO - i11iIiiIii
 i1OOoO = OO0O000 ( II1III )
 iiIiI1i1 = re . compile ( O0o0 ) . findall ( i1OOoO )
 for O0O0o0oOOO , OOoOoOo , o000ooooO0o in iiIiI1i1 :
  try :
   if 40 - 40: i1i1i11IIi + o0oOOo0O0Ooo * O00Oo000ooO0
   if 85 - 85: Ii1iIiII1ii1 * Ooooo0Oo00oO0 . ooOoO - i11iIiiIii
   i1I1iIi = O0O0o0oOOO
   IIii11Ii1i1I = OOoOoOo
   Oooo0O = o000ooooO0o
   if 90 - 90: iIiiiI1IiI1I1 % O0O0oOO00O00o
   if 73 - 73: ooOoO * O0O0O0OoOO + Ii1iIiII1ii1 + O0O0oOO00O00o
   OOIi1iI111II1I1 = "[COLOR=red][B]" + i1I1iIi + "[/B][/COLOR]"
   Ii = "[COLOR yellow]" + IIii11Ii1i1I + "[/COLOR]"
   o0O0Oo = "[COLOR yellow]" + Oooo0O + "[/COLOR]"
   if 62 - 62: ooOoO % oO0 . oO0 - iIiiiI1IiI1I1 / i11iIiiIii
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , OOIi1iI111II1I1 , Ii , o0O0Oo )
   if 31 - 31: iIiiiI1IiI1I1 / Ooo / i1i1i11IIi
  except : iiIiIi ( )
  if 39 - 39: Oo0o00
  if 91 - 91: IIiIiII11i - iIiiiI1IiI1I1 + oo0Oo00Oo0 / Ooo . oo0Oo00Oo0 + ooOoO
  if 26 - 26: i1i1i11IIi - IIiIiII11i
  if 11 - 11: OooO0OO * oO0OOoO0
  if 81 - 81: O0O0O0OoOO + iiiI1I11i1
 if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
  if 98 - 98: OooO0OO
  if 95 - 95: O0O0oOO00O00o / O0O0oOO00O00o
  if 30 - 30: i1i1i11IIi + Ooooo0Oo00oO0 / Ooooo0Oo00oO0 % i1i1i11IIi . i1i1i11IIi
def oo00OO0000oO ( s ) :
 if 55 - 55: O0O0oOO00O00o - oO0 + I1I11I1I1I + O0O0O0OoOO % Ii1iIiII1ii1
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 41 - 41: o0oOOo0O0Ooo - oO0 - Ii1iIiII1ii1
def III11I1 ( file ) :
 if 36 - 36: oO0OOoO0 - Ii1iIiII1ii1 . Ooooo0Oo00oO0 - i11iIiiIii - O00Oo000ooO0 * Ooooo0Oo00oO0
 try :
  OooOOOO = open ( file , 'r' )
  i1OOoO = OooOOOO . read ( )
  OooOOOO . close ( )
  return i1OOoO
 except :
  pass
  if 45 - 45: i1i1i11IIi % OooO0OO - i11iIiiIii
def OO0O000 ( url ) :
 if 11 - 11: iIiiiI1IiI1I1 * iIiiiI1IiI1I1 * OooO0OO
 try :
  iII1ii1 = urllib2 . Request ( url )
  if 12 - 12: O00Oo000ooO0 - O0O0oOO00O00o . IIiIiII11i / i1i1i11IIi . o0oOOo0O0Ooo * Ooo
  iII1ii1 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  IiIiII1 = urllib2 . urlopen ( iII1ii1 )
  Iii1iiIi1II = IiIiII1 . read ( )
  IiIiII1 . close ( )
  return Iii1iiIi1II
 except urllib2 . URLError , OO0O00oOo :
  print 'We failed to open "%s".' % url
  if hasattr ( OO0O00oOo , 'code' ) :
   print 'We failed with error code - %s.' % OO0O00oOo . code
  if hasattr ( OO0O00oOo , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , OO0O00oOo . reason
   if 14 - 14: OooO0OO
def IIiIiI1I ( url ) :
 iII1ii1 = urllib2 . Request ( url )
 iII1ii1 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 iII1ii1 . add_header ( 'Referer' , '%s' % url )
 iII1ii1 . add_header ( 'Connection' , 'keep-alive' )
 IiIiII1 = urllib2 . urlopen ( iII1ii1 )
 Iii1iiIi1II = IiIiII1 . read ( )
 IiIiII1 . close ( )
 return Iii1iiIi1II
 if 100 - 100: iIiiiI1IiI1I1 + oo0Oo00Oo0 / Ooooo0Oo00oO0 . i11iIiiIii
 if 14 - 14: oOOO00o * O00Oo000ooO0 + O0O0O0OoOO + ooOoO + i11iIiiIii
def oOoO0 ( ) :
 if 77 - 77: iIiiiI1IiI1I1 . O0O0O0OoOO % O0O0O0OoOO + i11iIiiIii
 if o0oo0o0O00OO == 'true' :
  Oo00o0OO0O00o ( '[COLOR orange]Menu Peliculas[/COLOR] ' , 'movieDB' , 116 , iiiIi , I1ii11iIi11i )
  if 82 - 82: oO0 + IIiIiII11i - o0oOOo0O0Ooo . o0oOOo0O0Ooo
  if 6 - 6: oOOO00o / oO0 / I1I11I1I1I
 if oOO00oOO == 'true' :
  Oo00o0OO0O00o ( '[COLOR orange]Ajustes[/COLOR]' , 'Settings' , 119 , IiIIIiI1I1 , I1ii11iIi11i )
  if 27 - 27: O00Oo000ooO0 * O0O0oOO00O00o . Oo0o00 % iiiI1I11i1 * iiiI1I11i1 . o0oOOo0O0Ooo
  if 72 - 72: O00Oo000ooO0 % i1i1i11IIi + Ooo / oO0OOoO0 + iiiI1I11i1
  if O0O00o0OOO0 == 'true' :
   I1I1i ( )
   if 1 - 1: oO0 % O00Oo000ooO0 + ooOoO + o0oOOo0O0Ooo - Ooo
  if OoOo == 'true' :
   iIIIII1ii1I ( )
   Ii1i1iI ( )
   if 16 - 16: O00Oo000ooO0 / Ooooo0Oo00oO0 / IIiIiII11i * OooO0OO + o0oOOo0O0Ooo % O00Oo000ooO0
  if I1i1iii == 'false' :
   if 71 - 71: oo0Oo00Oo0
   OOIi1iI111II1I1 = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   Ii = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Program.favoritos-realstream para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   o0O0Oo = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 14 - 14: i11iIiiIii % O00Oo000ooO0
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , OOIi1iI111II1I1 , Ii , o0O0Oo )
   if 82 - 82: iIiiiI1IiI1I1 + Ooooo0Oo00oO0 . iIiiiI1IiI1I1 % iiiI1I11i1 / Ii1iIiII1ii1 . Ii1iIiII1ii1
def IIi ( ) :
 Oo00o0OO0O00o ( '[COLOR orange]Buscador por id[/COLOR]' , iI1iI1I1i1I , 127 , iI111iI , I1ii11iIi11i )
 if 66 - 66: oO0OOoO0 % Ooo . O00Oo000ooO0
def iiIiIi ( ) :
 Oo00o0OO0O00o ( '[COLOR orange]The movie DB[/COLOR]' , 'movieDB' , 99 , iI111iI , I1ii11iIi11i )
 Oo00o0OO0O00o ( '[COLOR orange]Buscador por id[/COLOR]' , iI1iI1I1i1I , 127 , iI111iI , I1ii11iIi11i )
 Oo00o0OO0O00o ( '[COLOR orange]Video tutoriales[/COLOR]' , iI1iI1I1i1I , 125 , OooO0 , I1ii11iIi11i )
 if 86 - 86: iIiiiI1IiI1I1
 if 76 - 76: O0O0oOO00O00o + iIiiiI1IiI1I1 / ooOoO / i1i1i11IIi
 if 61 - 61: O00Oo000ooO0 % O00Oo000ooO0 * oOOO00o / oOOO00o
 if 75 - 75: iiiI1I11i1 . O0O0oOO00O00o
 if 50 - 50: oo0Oo00Oo0
 if 60 - 60: O0O0oOO00O00o * iIiiiI1IiI1I1 * i1i1i11IIi * Ooooo0Oo00oO0
 Oo00o0OO0O00o ( '[COLOR orange]Autorizar[/COLOR] [COLOR blue][B]OPENLOAD[/B][/COLOR]' , 'movieDB' , 97 , Iii1ii1II11i , I1ii11iIi11i )
 if 69 - 69: Ii1iIiII1ii1 * ooOoO . i11iIiiIii / Ii1iIiII1ii1 . oOOO00o
 oOoO0 ( )
 if 63 - 63: oO0 + oOOO00o . I1I11I1I1I - OooO0OO
 if 52 - 52: oOOO00o % Ooooo0Oo00oO0
def Oo000ooOOO ( ) :
 if 31 - 31: iIiiiI1IiI1I1 % oO0 % O0O0oOO00O00o . Ii1iIiII1ii1 - oO0
 if xbmc . getCondVisibility ( 'System.HasAddon(plugin.program.favoritos-realstream)' ) :
  if 17 - 17: Ii1iIiII1ii1
  xbmc . executebuiltin ( 'RunAddon(plugin.program.favoritos-realstream)' )
  if 27 - 27: i11iIiiIii % I1I11I1I1I % oO0 . ooOoO - Ooooo0Oo00oO0 + oo0Oo00Oo0
  if o0oO == 'true' :
   if 57 - 57: iIiiiI1IiI1I1 / oO0 - o0oOOo0O0Ooo
   xbmcgui . Dialog ( ) . ok ( "[COLOR orange]Real Stream Agradecimientos[/COLOR]" , "[COLOR gold]Netai quiere agradecer el genial trabajo de [/COLOR][COLOR lime][B]Spoyser[/B][/COLOR][COLOR gold] Autor de este genial script que originalmente se conoce como:[/COLOR]" , "[COLOR lime][B]Program.super.favorites[/B][/COLOR]" , "Usted puede descargar el script original desde el repositorio de Kodi >Addons de programas> program.super.favorites" )
   if 51 - 51: iiiI1I11i1
  OO0o . setSetting ( 'Favoritos-anuncio' , 'false' )
 else :
  if 25 - 25: IIiIiII11i + iiiI1I11i1 * i1i1i11IIi
  xbmcgui . Dialog ( ) . ok ( "El programa Real stream Favoritos No esta instalado" , "[COLOR green]Necesario AddOn externo para agregar tus peliculas a favoritas dentro del addon.[/COLOR]" , "[COLOR yellow]Puedes agregarlo desde http://netai.eu/netai/ agregando la fuente a tu Kodi, instalar desde archivo zip.[/COLOR]" )
  if 92 - 92: OooO0OO + oO0 + ooOoO / oOOO00o + Oo0o00
def I1iIi1iIiiIiI ( ) :
 OO0o . openSettings ( )
 if 47 - 47: Ii1iIiII1ii1 + Oo0o00 / o0oOOo0O0Ooo % i11iIiiIii
def i111iI ( ) :
 urlresolver . display_settings ( )
 if 85 - 85: oOOO00o . oo0Oo00Oo0 / O0O0oOO00O00o . ooOoO % Oo0o00
def iIIIII1ii1I ( ) :
 Oo00o0OO0O00o ( '[COLOR orange]Ajustes URL RESOLVER[/COLOR]' , 'resolve' , 120 , iiIiIIi , I1ii11iIi11i )
 if 90 - 90: Ooooo0Oo00oO0 % ooOoO * iIiiiI1IiI1I1 . O0O0O0OoOO
def I1iii11 ( ) :
 if 74 - 74: ooOoO / o0oOOo0O0Ooo
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 78 - 78: IIiIiII11i . Ooo + O0O0oOO00O00o - o0oOOo0O0Ooo
def Ii1i1iI ( ) :
 Oo00o0OO0O00o ( '[COLOR orange]Ajustes RESOLVE URL[/COLOR]' , 'resolve' , 140 , iiIiIIi , I1ii11iIi11i )
 if 31 - 31: IIiIiII11i . O00Oo000ooO0
def I1I1i ( ) :
 Oo00o0OO0O00o ( '[COLOR yellow]Buscador[/COLOR]' , 'search' , 111 , iIiiiI , I1ii11iIi11i )
 Oo00o0OO0O00o ( '[COLOR orange]Todas[/COLOR]' , iI1iI1I1i1I , 26 , i1i1II , I1ii11iIi11i )
 Oo00o0OO0O00o ( '[COLOR orange]Novedades[/COLOR]' , iI1iI1I1i1I , 2 , IiII , I1ii11iIi11i )
 Oo00o0OO0O00o ( '[COLOR orange]Estrenos[/COLOR]' , iI1iI1I1i1I , 3 , iI1Ii11111iIi , I1ii11iIi11i )
 Oo00o0OO0O00o ( '[COLOR orange]Accion[/COLOR]' , iI1iI1I1i1I , 5 , O0oo0OO0 , I1ii11iIi11i )
 Oo00o0OO0O00o ( '[COLOR orange]Animacion[/COLOR]' , iI1iI1I1i1I , 6 , I1i1iiI1 , I1ii11iIi11i )
 Oo00o0OO0O00o ( '[COLOR orange]Aventuras[/COLOR]' , iI1iI1I1i1I , 7 , iiIIIII1i1iI , I1ii11iIi11i )
 Oo00o0OO0O00o ( '[COLOR orange]Belico[/COLOR]' , iI1iI1I1i1I , 8 , o0oO0 , I1ii11iIi11i )
 Oo00o0OO0O00o ( '[COLOR orange]Ciencia Ficcion[/COLOR]' , iI1iI1I1i1I , 9 , oo00 , I1ii11iIi11i )
 Oo00o0OO0O00o ( '[COLOR orange]Comedia[/COLOR]' , iI1iI1I1i1I , 10 , o00 , I1ii11iIi11i )
 Oo00o0OO0O00o ( '[COLOR orange]Crimen[/COLOR]' , iI1iI1I1i1I , 11 , Oo0oO0ooo , I1ii11iIi11i )
 Oo00o0OO0O00o ( '[COLOR orange]Drama[/COLOR]' , iI1iI1I1i1I , 12 , o0oOoO00o , I1ii11iIi11i )
 Oo00o0OO0O00o ( '[COLOR orange]Familiar[/COLOR]' , iI1iI1I1i1I , 13 , i1 , I1ii11iIi11i )
 Oo00o0OO0O00o ( '[COLOR orange]Fantasia[/COLOR]' , iI1iI1I1i1I , 14 , oOOoo00O0O , I1ii11iIi11i )
 Oo00o0OO0O00o ( '[COLOR orange]Historia[/COLOR]' , iI1iI1I1i1I , 15 , i1111 , I1ii11iIi11i )
 Oo00o0OO0O00o ( '[COLOR orange]Misterio[/COLOR]' , iI1iI1I1i1I , 16 , I11 , I1ii11iIi11i )
 Oo00o0OO0O00o ( '[COLOR orange]Musical[/COLOR]' , iI1iI1I1i1I , 17 , Oo0o0000o0o0 , I1ii11iIi11i )
 Oo00o0OO0O00o ( '[COLOR orange]Romance[/COLOR]' , iI1iI1I1i1I , 18 , oOo0oooo00o , I1ii11iIi11i )
 Oo00o0OO0O00o ( '[COLOR orange]Thriller[/COLOR]' , iI1iI1I1i1I , 19 , i1iiIIiiI111 , I1ii11iIi11i )
 Oo00o0OO0O00o ( '[COLOR orange]Suspense[/COLOR]' , iI1iI1I1i1I , 20 , oo0o0O00 , I1ii11iIi11i )
 Oo00o0OO0O00o ( '[COLOR orange]Terror[/COLOR]' , iI1iI1I1i1I , 21 , oO , I1ii11iIi11i )
 Oo00o0OO0O00o ( '[COLOR orange]Western[/COLOR]' , iI1iI1I1i1I , 22 , oooOOOOO , I1ii11iIi11i )
 Oo00o0OO0O00o ( '[COLOR orange]Spain[/COLOR]' , iI1iI1I1i1I , 23 , oO0o0o0ooO0oO , I1ii11iIi11i )
 Oo00o0OO0O00o ( '[COLOR orange]Super heroes[/COLOR]' , iI1iI1I1i1I , 24 , i11 , I1ii11iIi11i )
 Oo00o0OO0O00o ( '[COLOR orange]Sagas[/COLOR]' , iI1iI1I1i1I , 25 , i1iiIII111ii , I1ii11iIi11i )
 if 83 - 83: O0O0O0OoOO . ooOoO / Ooooo0Oo00oO0 / O00Oo000ooO0 - I1I11I1I1I
def oO0oO0 ( ) :
 if 14 - 14: O0O0O0OoOO
 if 99 - 99: O0O0O0OoOO
 IIi1ii1Ii = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 IIi1ii1Ii . doModal ( )
 if not IIi1ii1Ii . isConfirmed ( ) :
  return None ;
 Ooo0OOoOoO0 = IIi1ii1Ii . getText ( ) . strip ( )
 if 91 - 91: i11iIiiIii / IIiIiII11i + O0O0O0OoOO - i11iIiiIii + O00Oo000ooO0
 if 18 - 18: I1I11I1I1I / iiiI1I11i1
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 4 - 4: I1I11I1I1I / i1i1i11IIi + I1I11I1I1I . iIiiiI1IiI1I1
  II1111II = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + Ooo0OOoOoO0 + '&language=es-ES' ) )
  if 49 - 49: Ooooo0Oo00oO0 - OooO0OO / iiiI1I11i1 / ooOoO % oOOO00o * Ii1iIiII1ii1
  if 100 - 100: O00Oo000ooO0 . O0O0O0OoOO / ooOoO * o0oOOo0O0Ooo * Ii1iIiII1ii1 * Ooooo0Oo00oO0
  return 'android'
  if 84 - 84: i1i1i11IIi / O00Oo000ooO0 % i11iIiiIii * Oo0o00 % i1i1i11IIi - IIiIiII11i
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 99 - 99: OooO0OO + ooOoO + o0oOOo0O0Ooo / i11iIiiIii - o0oOOo0O0Ooo * iIiiiI1IiI1I1
  II1111II = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + Ooo0OOoOoO0 + '&language=es-ES' )
  if 72 - 72: OooO0OO * i1i1i11IIi . Ii1iIiII1ii1 * iiiI1I11i1 * Ooooo0Oo00oO0 * Oo0o00
  if 40 - 40: OooO0OO
  return 'windows'
  if 14 - 14: Oo0o00
def Oo0000oOo ( ) :
 if 31 - 31: oO0 . Oo0o00 * O0O0oOO00O00o + i11iIiiIii * oO0OOoO0
 try :
  if 93 - 93: i1i1i11IIi / iIiiiI1IiI1I1 * o0oOOo0O0Ooo % IIiIiII11i * ooOoO * oO0
  i1OOoO = OO0O000 ( iIiIIIi )
  iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( i1OOoO )
  for oO0O00oOOoooO in iiIiI1i1 :
   if 64 - 64: I1I11I1I1I + ooOoO / iIiiiI1IiI1I1 / Ooooo0Oo00oO0 . O0O0oOO00O00o % iiiI1I11i1
   try :
    if 50 - 50: iIiiiI1IiI1I1 - iiiI1I11i1 + O00Oo000ooO0
    all = oO0O00oOOoooO
    if 69 - 69: ooOoO
   except :
    pass
    if 85 - 85: O0O0oOO00O00o / ooOoO
  Oo0OO = OO0O000 ( all )
  iiIiI1i1 = re . compile ( ooOooo000oOO ) . findall ( Oo0OO )
  for iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 , id , IIo0Oo0oO0oOO00 in iiIiI1i1 :
   try :
    if 18 - 18: oOOO00o % ooOoO * i1i1i11IIi
    I1II1 ( Ooo0OOoOoO0 , oOo0OOoO0 , iiI11ii1I1 , id , IIo0Oo0oO0oOO00 )
    if 62 - 62: Oo0o00 . iiiI1I11i1 . IIiIiII11i
   except :
    pass
 except :
  pass
  if 11 - 11: O00Oo000ooO0 / oO0
def oooO0 ( ) :
 if 16 - 16: I1I11I1I1I + oO0OOoO0 - IIiIiII11i
 try :
  if 3 - 3: ooOoO / O0O0O0OoOO
  IiII = OO0O000 ( O00OOOoOoo0O )
  iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( IiII )
  for oO0O00oOOoooO in iiIiI1i1 :
   if 31 - 31: O00Oo000ooO0 + oOOO00o . IIiIiII11i
   try :
    if 89 - 89: I1I11I1I1I + o0oOOo0O0Ooo + I1I11I1I1I
    IiII1II11I = oO0O00oOOoooO
    if 54 - 54: iiiI1I11i1 + ooOoO + oO0 * Oo0o00 - O00Oo000ooO0 % oO0OOoO0
   except :
    pass
    if 13 - 13: O0O0oOO00O00o / O0O0O0OoOO * Ooo . Ooo * O0O0oOO00O00o
  O0oO0iII11 = OO0O000 ( IiII1II11I )
  iiIiI1i1 = re . compile ( ooOooo000oOO ) . findall ( O0oO0iII11 )
  for iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 , id , IIo0Oo0oO0oOO00 in iiIiI1i1 :
   try :
    if 63 - 63: Oo0o00 / ooOoO * Ooooo0Oo00oO0 + I1I11I1I1I / iiiI1I11i1 + Ii1iIiII1ii1
    I1II1 ( Ooo0OOoOoO0 , oOo0OOoO0 , iiI11ii1I1 , id , IIo0Oo0oO0oOO00 )
    if 63 - 63: Ooo + i1i1i11IIi . Oo0o00 % Oo0o00
   except :
    pass
 except :
  pass
  if 57 - 57: I1I11I1I1I
def oOOOoo ( ) :
 if 15 - 15: i11iIiiIii % OooO0OO * oO0 / Oo0o00
 try :
  if 90 - 90: O0O0O0OoOO
  iI1Ii11111iIi = OO0O000 ( oo0OOo )
  iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( iI1Ii11111iIi )
  for oO0O00oOOoooO in iiIiI1i1 :
   if 31 - 31: O00Oo000ooO0 + ooOoO
   try :
    oO0oOOoo00000 = oO0O00oOOoooO
   except :
    pass
    if 52 - 52: OooO0OO
  i1OOoO = OO0O000 ( oO0oOOoo00000 )
  iiIiI1i1 = re . compile ( ooOooo000oOO ) . findall ( i1OOoO )
  for iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 , id , IIo0Oo0oO0oOO00 in iiIiI1i1 :
   try :
    I1II1 ( Ooo0OOoOoO0 , oOo0OOoO0 , iiI11ii1I1 , id , IIo0Oo0oO0oOO00 )
    if 51 - 51: iiiI1I11i1
   except :
    pass
 except :
  pass
  if 88 - 88: IIiIiII11i
def OO00 ( ) :
 if 28 - 28: oO0OOoO0 - i11iIiiIii . i1i1i11IIi + iiiI1I11i1 / i1i1i11IIi
 try :
  if 35 - 35: iiiI1I11i1
  i1OOoO = OO0O000 ( db2 )
  iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( i1OOoO )
  for oO0O00oOOoooO in iiIiI1i1 :
   if 75 - 75: Ooooo0Oo00oO0 / i1i1i11IIi . iiiI1I11i1 * O00Oo000ooO0 - I1I11I1I1I
   try :
    if 41 - 41: Ii1iIiII1ii1
    oOOoo0o0OOOO = oO0O00oOOoooO
    if 26 - 26: O0O0O0OoOO % iIiiiI1IiI1I1 + oOOO00o
   except :
    pass
    if 67 - 67: oO0OOoO0 + I1I11I1I1I - ooOoO . oO0OOoO0 * I1I11I1I1I * oO0
    if 90 - 90: Ii1iIiII1ii1 . iiiI1I11i1
  i1OOoO = OO0O000 ( oOOoo0o0OOOO )
  iiIiI1i1 = re . compile ( ooOooo000oOO ) . findall ( i1OOoO )
  for iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 , id , IIo0Oo0oO0oOO00 in iiIiI1i1 :
   try :
    I1II1 ( Ooo0OOoOoO0 , oOo0OOoO0 , iiI11ii1I1 , id , IIo0Oo0oO0oOO00 )
    if 81 - 81: O00Oo000ooO0 - oO0 % O0O0oOO00O00o - Ooo / Ooooo0Oo00oO0
   except :
    pass
 except :
  pass
  if 4 - 4: IIiIiII11i - o0oOOo0O0Ooo % Ii1iIiII1ii1 - O00Oo000ooO0 * oOOO00o
def Ooooo00o0OoO ( ) :
 if 75 - 75: OooO0OO % I1I11I1I1I
 try :
  if 30 - 30: iiiI1I11i1 + Oo0o00 - iiiI1I11i1 . iiiI1I11i1 - I1I11I1I1I + ooOoO
  i1OOoO = OO0O000 ( IiIIIi1iIi )
  iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( i1OOoO )
  for oO0O00oOOoooO in iiIiI1i1 :
   if 86 - 86: o0oOOo0O0Ooo
   try :
    if 41 - 41: oo0Oo00Oo0 * oO0 / oo0Oo00Oo0 % oO0OOoO0
    IioO0oOOO0Ooo = oO0O00oOOoooO
    if 38 - 38: OooO0OO
   except :
    pass
    if 84 - 84: oO0OOoO0 % o0oOOo0O0Ooo
    if 70 - 70: Ooooo0Oo00oO0 . IIiIiII11i - O0O0O0OoOO
  i1OOoO = OO0O000 ( IioO0oOOO0Ooo )
  iiIiI1i1 = re . compile ( ooOooo000oOO ) . findall ( i1OOoO )
  for iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 , id , IIo0Oo0oO0oOO00 in iiIiI1i1 :
   try :
    I1II1 ( Ooo0OOoOoO0 , oOo0OOoO0 , iiI11ii1I1 , id , IIo0Oo0oO0oOO00 )
    if 30 - 30: i1i1i11IIi % OooO0OO
   except :
    pass
 except :
  pass
  if 89 - 89: Oo0o00 + IIiIiII11i + Oo0o00 * o0oOOo0O0Ooo + iIiiiI1IiI1I1 % oO0
def oOo0oO ( ) :
 if 5 - 5: O00Oo000ooO0 - O00Oo000ooO0 . Ooooo0Oo00oO0 + oo0Oo00Oo0 - O00Oo000ooO0 . oO0OOoO0
 try :
  if 31 - 31: I1I11I1I1I - iIiiiI1IiI1I1 - iIiiiI1IiI1I1 % oO0
  i1OOoO = OO0O000 ( II1I )
  iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( i1OOoO )
  for oO0O00oOOoooO in iiIiI1i1 :
   if 12 - 12: iIiiiI1IiI1I1
   try :
    if 20 - 20: oOOO00o / o0oOOo0O0Ooo
    oOIi111 = oO0O00oOOoooO
    if 67 - 67: ooOoO
   except :
    pass
    if 52 - 52: I1I11I1I1I . O0O0oOO00O00o / oo0Oo00Oo0 / IIiIiII11i . i11iIiiIii
  i1OOoO = OO0O000 ( oOIi111 )
  iiIiI1i1 = re . compile ( ooOooo000oOO ) . findall ( i1OOoO )
  for iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 , id , IIo0Oo0oO0oOO00 in iiIiI1i1 :
   try :
    I1II1 ( Ooo0OOoOoO0 , oOo0OOoO0 , iiI11ii1I1 , id , IIo0Oo0oO0oOO00 )
    if 30 - 30: oO0 / Ii1iIiII1ii1 . iiiI1I11i1 . IIiIiII11i - Ooooo0Oo00oO0
   except :
    pass
 except :
  pass
  if 44 - 44: ooOoO * IIiIiII11i % O0O0oOO00O00o + I1I11I1I1I
def II1i1i1iII1 ( ) :
 if 68 - 68: Ooooo0Oo00oO0 + i11iIiiIii
 try :
  if 69 - 69: iIiiiI1IiI1I1 * iIiiiI1IiI1I1 * i11iIiiIii + OooO0OO / O00Oo000ooO0 % Ii1iIiII1ii1
  i1OOoO = OO0O000 ( IIII )
  iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( i1OOoO )
  for oO0O00oOOoooO in iiIiI1i1 :
   if 58 - 58: O00Oo000ooO0 * oOOO00o + ooOoO % O00Oo000ooO0
   try :
    if 25 - 25: Ooooo0Oo00oO0 % i1i1i11IIi * O0O0oOO00O00o
    I11oo0ooOO = oO0O00oOOoooO
    if 24 - 24: Ooo % Ooo * iIiiiI1IiI1I1
   except :
    pass
    if 50 - 50: Ooo . i11iIiiIii - oO0OOoO0 . oO0OOoO0
    if 31 - 31: O00Oo000ooO0 / Ooooo0Oo00oO0 * o0oOOo0O0Ooo . oo0Oo00Oo0
  i1OOoO = OO0O000 ( I11oo0ooOO )
  iiIiI1i1 = re . compile ( ooOooo000oOO ) . findall ( i1OOoO )
  for iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 , id , IIo0Oo0oO0oOO00 in iiIiI1i1 :
   try :
    I1II1 ( Ooo0OOoOoO0 , oOo0OOoO0 , iiI11ii1I1 , id , IIo0Oo0oO0oOO00 )
    if 57 - 57: O00Oo000ooO0 + iIiiiI1IiI1I1 % o0oOOo0O0Ooo % OooO0OO
   except :
    pass
 except :
  pass
  if 83 - 83: oOOO00o / i11iIiiIii % iIiiiI1IiI1I1 . oO0 % oO0OOoO0 . IIiIiII11i
def o00oO00 ( ) :
 if 59 - 59: O00Oo000ooO0 + iIiiiI1IiI1I1 * oOOO00o + Oo0o00 . O0O0O0OoOO
 try :
  if 49 - 49: IIiIiII11i * oO0 - Ooooo0Oo00oO0 . oO0OOoO0
  i1OOoO = OO0O000 ( o00oooO0Oo )
  iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( i1OOoO )
  for oO0O00oOOoooO in iiIiI1i1 :
   if 89 - 89: O0O0oOO00O00o + Ii1iIiII1ii1 * O0O0oOO00O00o / O0O0oOO00O00o
   try :
    if 46 - 46: Ooo
    O0000 = oO0O00oOOoooO
    if 64 - 64: I1I11I1I1I - OooO0OO
   except :
    pass
    if 68 - 68: O0O0oOO00O00o - O00Oo000ooO0 - iIiiiI1IiI1I1 / oo0Oo00Oo0 + O00Oo000ooO0 - Ooo
    if 75 - 75: O0O0O0OoOO / oOOO00o % iIiiiI1IiI1I1 . IIiIiII11i % IIiIiII11i % I1I11I1I1I
  i1OOoO = OO0O000 ( O0000 )
  iiIiI1i1 = re . compile ( ooOooo000oOO ) . findall ( i1OOoO )
  for iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 , id , IIo0Oo0oO0oOO00 in iiIiI1i1 :
   try :
    I1II1 ( Ooo0OOoOoO0 , oOo0OOoO0 , iiI11ii1I1 , id , IIo0Oo0oO0oOO00 )
    if 26 - 26: I1I11I1I1I % i11iIiiIii % iIiiiI1IiI1I1 % oO0 * oO0 * i1i1i11IIi
   except :
    pass
 except :
  pass
  if 24 - 24: I1I11I1I1I % Oo0o00 - O0O0oOO00O00o + OooO0OO * i1i1i11IIi
def i11111I1I ( ) :
 if 61 - 61: I1I11I1I1I * O00Oo000ooO0 / IIiIiII11i / Ooooo0Oo00oO0 - Ooo
 try :
  if 56 - 56: i1i1i11IIi
  i1OOoO = OO0O000 ( iiIiII1 )
  iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( i1OOoO )
  for oO0O00oOOoooO in iiIiI1i1 :
   if 26 - 26: IIiIiII11i % IIiIiII11i
   try :
    if 33 - 33: Oo0o00
    OOO0ooo = oO0O00oOOoooO
    if 7 - 7: oOOO00o + o0oOOo0O0Ooo . OooO0OO / Ooooo0Oo00oO0
   except :
    pass
    if 22 - 22: O0O0oOO00O00o - O0O0oOO00O00o % O00Oo000ooO0 . Oo0o00 + oO0OOoO0
    if 63 - 63: OooO0OO % Oo0o00 * oOOO00o + Oo0o00 / Ooooo0Oo00oO0 % O0O0O0OoOO
  i1OOoO = OO0O000 ( OOO0ooo )
  iiIiI1i1 = re . compile ( ooOooo000oOO ) . findall ( i1OOoO )
  for iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 , id , IIo0Oo0oO0oOO00 in iiIiI1i1 :
   try :
    I1II1 ( Ooo0OOoOoO0 , oOo0OOoO0 , iiI11ii1I1 , id , IIo0Oo0oO0oOO00 )
    if 45 - 45: iiiI1I11i1
   except :
    pass
 except :
  pass
  if 20 - 20: IIiIiII11i * oOOO00o * ooOoO . O00Oo000ooO0
  if 78 - 78: iIiiiI1IiI1I1 + oO0 - Ii1iIiII1ii1 * Oo0o00 - IIiIiII11i % oo0Oo00Oo0
def i1OoOO ( ) :
 if 44 - 44: O00Oo000ooO0
 try :
  if 54 - 54: Ii1iIiII1ii1 - oO0 - Oo0o00 . iIiiiI1IiI1I1
  i1OOoO = OO0O000 ( iii )
  iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( i1OOoO )
  for oO0O00oOOoooO in iiIiI1i1 :
   if 79 - 79: Ii1iIiII1ii1 . Ooo
   try :
    if 40 - 40: oOOO00o + Ooooo0Oo00oO0 . oOOO00o % O0O0oOO00O00o
    I11I1IIiiII1 = oO0O00oOOoooO
    if 31 - 31: OooO0OO * oO0OOoO0 + IIiIiII11i - O0O0O0OoOO / IIiIiII11i
   except :
    pass
    if 19 - 19: iiiI1I11i1 * O0O0oOO00O00o * oOOO00o + ooOoO / ooOoO
    if 73 - 73: iIiiiI1IiI1I1 / iIiiiI1IiI1I1 - oO0OOoO0
  i1OOoO = OO0O000 ( I11I1IIiiII1 )
  iiIiI1i1 = re . compile ( ooOooo000oOO ) . findall ( i1OOoO )
  for iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 , id , IIo0Oo0oO0oOO00 in iiIiI1i1 :
   try :
    I1II1 ( Ooo0OOoOoO0 , oOo0OOoO0 , iiI11ii1I1 , id , IIo0Oo0oO0oOO00 )
    if 91 - 91: oO0OOoO0 + OooO0OO
   except :
    pass
 except :
  pass
  if 59 - 59: OooO0OO + i11iIiiIii + o0oOOo0O0Ooo / oO0
  if 44 - 44: oO0 . oo0Oo00Oo0 * OooO0OO + IIiIiII11i - O0O0O0OoOO - iiiI1I11i1
def I1iii ( ) :
 if 51 - 51: i1i1i11IIi
 try :
  if 41 - 41: i1i1i11IIi * O0O0oOO00O00o - Ii1iIiII1ii1 + Ooooo0Oo00oO0
  i1OOoO = OO0O000 ( i1Iii1i1I )
  iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( i1OOoO )
  for oO0O00oOOoooO in iiIiI1i1 :
   if 23 - 23: I1I11I1I1I % oOOO00o + oOOO00o + O0O0O0OoOO - O0O0O0OoOO
   try :
    if 62 - 62: oOOO00o
    iI11IIiIiIii1 = oO0O00oOOoooO
    if 37 - 37: i11iIiiIii + OooO0OO * oO0
   except :
    pass
    if 53 - 53: I1I11I1I1I * IIiIiII11i - Ooooo0Oo00oO0 - O0O0O0OoOO - oOOO00o
    if 38 - 38: Ooooo0Oo00oO0 - oo0Oo00Oo0 * oO0OOoO0 + iIiiiI1IiI1I1 - ooOoO . oO0OOoO0
  i1OOoO = OO0O000 ( iI11IIiIiIii1 )
  iiIiI1i1 = re . compile ( ooOooo000oOO ) . findall ( i1OOoO )
  for iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 , id , IIo0Oo0oO0oOO00 in iiIiI1i1 :
   try :
    I1II1 ( Ooo0OOoOoO0 , oOo0OOoO0 , iiI11ii1I1 , id , IIo0Oo0oO0oOO00 )
    if 22 - 22: oO0 + iIiiiI1IiI1I1
   except :
    pass
    if 24 - 24: oo0Oo00Oo0 % o0oOOo0O0Ooo + O0O0O0OoOO . i11iIiiIii . i1i1i11IIi
 except :
  pass
  if 17 - 17: i1i1i11IIi . I1I11I1I1I . O0O0oOO00O00o / i1i1i11IIi
  if 57 - 57: oO0
def oO0oO00oOo0OOO ( ) :
 if 23 - 23: o0oOOo0O0Ooo . oOOO00o * Ooo
 try :
  if 15 - 15: oo0Oo00Oo0
  i1OOoO = OO0O000 ( IiI111111IIII )
  iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( i1OOoO )
  for oO0O00oOOoooO in iiIiI1i1 :
   if 62 - 62: Ii1iIiII1ii1
   try :
    if 51 - 51: oo0Oo00Oo0
    I11IIIiIi11 = oO0O00oOOoooO
    if 39 - 39: Ii1iIiII1ii1 % ooOoO % oo0Oo00Oo0 . o0oOOo0O0Ooo
   except :
    pass
    if 86 - 86: Ooo * IIiIiII11i
    if 71 - 71: iIiiiI1IiI1I1 - O00Oo000ooO0 . OooO0OO % IIiIiII11i + O00Oo000ooO0
  i1OOoO = OO0O000 ( I11IIIiIi11 )
  iiIiI1i1 = re . compile ( ooOooo000oOO ) . findall ( i1OOoO )
  for iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 , id , IIo0Oo0oO0oOO00 in iiIiI1i1 :
   try :
    I1II1 ( Ooo0OOoOoO0 , oOo0OOoO0 , iiI11ii1I1 , id , IIo0Oo0oO0oOO00 )
    if 26 - 26: Ooooo0Oo00oO0 + O00Oo000ooO0 / Ooo % oo0Oo00Oo0 % i1i1i11IIi + I1I11I1I1I
   except :
    pass
    if 31 - 31: oO0 % O00Oo000ooO0 * oO0
 except :
  pass
  if 45 - 45: o0oOOo0O0Ooo . OooO0OO + O00Oo000ooO0 - IIiIiII11i % O0O0oOO00O00o
def i1I ( ) :
 if 7 - 7: i11iIiiIii . Ooooo0Oo00oO0
 try :
  if 99 - 99: oO0 - Oo0o00 - oO0OOoO0 % Ooo
  i1OOoO = OO0O000 ( ii111iI1iIi1 )
  iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( i1OOoO )
  for oO0O00oOOoooO in iiIiI1i1 :
   if 21 - 21: I1I11I1I1I % i1i1i11IIi . o0oOOo0O0Ooo - IIiIiII11i
   try :
    if 4 - 4: IIiIiII11i . O0O0oOO00O00o
    oOO0oo = oO0O00oOOoooO
    if 29 - 29: OooO0OO * I1I11I1I1I * IIiIiII11i - i1i1i11IIi * I1I11I1I1I
   except :
    pass
    if 41 - 41: ooOoO
  i1OOoO = OO0O000 ( oOO0oo )
  iiIiI1i1 = re . compile ( ooOooo000oOO ) . findall ( i1OOoO )
  for iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 , id , IIo0Oo0oO0oOO00 in iiIiI1i1 :
   try :
    I1II1 ( Ooo0OOoOoO0 , oOo0OOoO0 , iiI11ii1I1 , id , IIo0Oo0oO0oOO00 )
    if 30 - 30: O0O0oOO00O00o % O0O0O0OoOO * O00Oo000ooO0 - i1i1i11IIi * Ii1iIiII1ii1 % O0O0oOO00O00o
   except :
    pass
 except :
  pass
  if 46 - 46: i11iIiiIii - ooOoO . oO0OOoO0
  if 100 - 100: OooO0OO / oOOO00o * O0O0O0OoOO . ooOoO / O00Oo000ooO0
def oOO0o000Oo00o ( ) :
 if 21 - 21: IIiIiII11i - iIiiiI1IiI1I1
 try :
  if 93 - 93: oO0OOoO0 - oOOO00o % oo0Oo00Oo0 . oo0Oo00Oo0 - O0O0oOO00O00o
  i1OOoO = OO0O000 ( oo0OOo0 )
  iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( i1OOoO )
  for oO0O00oOOoooO in iiIiI1i1 :
   if 90 - 90: O0O0oOO00O00o + I1I11I1I1I * i1i1i11IIi / Ii1iIiII1ii1 . oOOO00o + oOOO00o
   try :
    if 40 - 40: O0O0oOO00O00o / oo0Oo00Oo0 % i11iIiiIii % i1i1i11IIi / OooO0OO
    ooOOOOo0 = oO0O00oOOoooO
    if 38 - 38: IIiIiII11i / i1i1i11IIi . ooOoO / o0oOOo0O0Ooo / Ooooo0Oo00oO0 + iIiiiI1IiI1I1
   except :
    pass
    if 96 - 96: O0O0O0OoOO
    if 18 - 18: O0O0O0OoOO * oO0 - Ii1iIiII1ii1
  i1OOoO = OO0O000 ( ooOOOOo0 )
  iiIiI1i1 = re . compile ( ooOooo000oOO ) . findall ( i1OOoO )
  for iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 , id , IIo0Oo0oO0oOO00 in iiIiI1i1 :
   try :
    I1II1 ( Ooo0OOoOoO0 , oOo0OOoO0 , iiI11ii1I1 , id , IIo0Oo0oO0oOO00 )
    if 31 - 31: Ooooo0Oo00oO0 - ooOoO % oo0Oo00Oo0 % oO0OOoO0
   except :
    pass
 except :
  pass
  if 45 - 45: i1i1i11IIi + I1I11I1I1I * i11iIiiIii
  if 13 - 13: IIiIiII11i * oO0OOoO0 - Ii1iIiII1ii1 / O00Oo000ooO0 + oO0 + iiiI1I11i1
def iii1III1i ( ) :
 if 17 - 17: I1I11I1I1I / I1I11I1I1I
 try :
  if 65 - 65: iiiI1I11i1 + Ooooo0Oo00oO0
  i1OOoO = OO0O000 ( O0ooO0Oo00o )
  iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( i1OOoO )
  for oO0O00oOOoooO in iiIiI1i1 :
   if 59 - 59: IIiIiII11i + oO0 . Oo0o00 - ooOoO % iIiiiI1IiI1I1 / ooOoO
   try :
    if 88 - 88: Ooooo0Oo00oO0 . ooOoO % IIiIiII11i / O00Oo000ooO0
    ooOo = oO0O00oOOoooO
    if 84 - 84: O00Oo000ooO0
   except :
    pass
  i1OOoO = OO0O000 ( ooOo )
  iiIiI1i1 = re . compile ( ooOooo000oOO ) . findall ( i1OOoO )
  for iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 , id , IIo0Oo0oO0oOO00 in iiIiI1i1 :
   try :
    I1II1 ( Ooo0OOoOoO0 , oOo0OOoO0 , iiI11ii1I1 , id , IIo0Oo0oO0oOO00 )
    if 87 - 87: O0O0oOO00O00o + oOOO00o
   except :
    pass
 except :
  pass
  if 28 - 28: O00Oo000ooO0 * i1i1i11IIi / oO0OOoO0
def OOoOO0OO ( ) :
 if 26 - 26: O0O0O0OoOO . O0O0O0OoOO
 try :
  if 35 - 35: Oo0o00 . oo0Oo00Oo0 * i11iIiiIii
  i1OOoO = OO0O000 ( i1I1ii11i1Iii )
  iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( i1OOoO )
  for oO0O00oOOoooO in iiIiI1i1 :
   if 44 - 44: i11iIiiIii / Ooooo0Oo00oO0
   try :
    if 42 - 42: IIiIiII11i + Ooooo0Oo00oO0 % I1I11I1I1I + Ooo
    I11i11I1iiII = oO0O00oOOoooO
    if 28 - 28: i11iIiiIii / oOOO00o . iIiiiI1IiI1I1 / I1I11I1I1I
   except :
    pass
    if 72 - 72: IIiIiII11i / OooO0OO + Ii1iIiII1ii1 / oo0Oo00Oo0 * Ii1iIiII1ii1
    if 34 - 34: ooOoO * ooOoO % IIiIiII11i + O0O0O0OoOO * iIiiiI1IiI1I1 % Ii1iIiII1ii1
  i1OOoO = OO0O000 ( I11i11I1iiII )
  iiIiI1i1 = re . compile ( ooOooo000oOO ) . findall ( i1OOoO )
  for iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 , id , IIo0Oo0oO0oOO00 in iiIiI1i1 :
   try :
    I1II1 ( Ooo0OOoOoO0 , oOo0OOoO0 , iiI11ii1I1 , id , IIo0Oo0oO0oOO00 )
    if 25 - 25: oO0 + oo0Oo00Oo0 . oOOO00o % oo0Oo00Oo0 * O00Oo000ooO0
   except :
    pass
 except :
  pass
  if 32 - 32: i11iIiiIii - Oo0o00
  if 53 - 53: IIiIiII11i - iiiI1I11i1
def oOo ( ) :
 if 17 - 17: Ii1iIiII1ii1 . i11iIiiIii
 try :
  if 5 - 5: i1i1i11IIi + ooOoO + ooOoO . Oo0o00 - O0O0oOO00O00o
  i1OOoO = OO0O000 ( o0O )
  iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( i1OOoO )
  for oO0O00oOOoooO in iiIiI1i1 :
   if 63 - 63: oO0OOoO0
   try :
    if 71 - 71: o0oOOo0O0Ooo . Ii1iIiII1ii1 * O0O0O0OoOO % IIiIiII11i + O00Oo000ooO0
    iIIi1iiI1i11 = oO0O00oOOoooO
    if 56 - 56: IIiIiII11i
   except :
    pass
    if 30 - 30: i11iIiiIii + oO0OOoO0
    if 38 - 38: iiiI1I11i1 . Ii1iIiII1ii1
  i1OOoO = OO0O000 ( iIIi1iiI1i11 )
  iiIiI1i1 = re . compile ( ooOooo000oOO ) . findall ( i1OOoO )
  for iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 , id , IIo0Oo0oO0oOO00 in iiIiI1i1 :
   try :
    I1II1 ( Ooo0OOoOoO0 , oOo0OOoO0 , iiI11ii1I1 , id , IIo0Oo0oO0oOO00 )
    if 24 - 24: oOOO00o - oOOO00o + i1i1i11IIi + OooO0OO - oO0OOoO0
   except :
    pass
 except :
  pass
  if 12 - 12: O0O0O0OoOO . iiiI1I11i1 . oo0Oo00Oo0 / ooOoO
def OO0oOOo0o ( ) :
 if 50 - 50: O0O0O0OoOO . i1i1i11IIi . Ooo * oO0 + I1I11I1I1I % i11iIiiIii
 try :
  if 8 - 8: O0O0oOO00O00o * ooOoO
  i1OOoO = OO0O000 ( Iii1I1I11iiI1 )
  iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( i1OOoO )
  for oO0O00oOOoooO in iiIiI1i1 :
   if 73 - 73: oOOO00o / oO0OOoO0 / oO0 / Ooo
   try :
    if 11 - 11: oo0Oo00Oo0 + iiiI1I11i1 - IIiIiII11i / Ooo
    iIIi1iI1I1IIi = oO0O00oOOoooO
    if 77 - 77: O0O0oOO00O00o / Ooooo0Oo00oO0 + O0O0oOO00O00o % oOOO00o - OooO0OO * OooO0OO
   except :
    pass
    if 23 - 23: O0O0O0OoOO . I1I11I1I1I % i1i1i11IIi - IIiIiII11i * Ooooo0Oo00oO0 . iIiiiI1IiI1I1
    if 37 - 37: O0O0O0OoOO / Ooooo0Oo00oO0 . oO0 * oO0
  i1OOoO = OO0O000 ( iIIi1iI1I1IIi )
  iiIiI1i1 = re . compile ( ooOooo000oOO ) . findall ( i1OOoO )
  for iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 , id , IIo0Oo0oO0oOO00 in iiIiI1i1 :
   try :
    I1II1 ( Ooo0OOoOoO0 , oOo0OOoO0 , iiI11ii1I1 , id , IIo0Oo0oO0oOO00 )
    if 80 - 80: O00Oo000ooO0 % i1i1i11IIi
   except :
    pass
 except :
  pass
  if 91 - 91: oO0 / ooOoO - Ii1iIiII1ii1 . OooO0OO
  if 82 - 82: iiiI1I11i1 * O00Oo000ooO0 / oO0OOoO0
def IiiIiI ( ) :
 if 23 - 23: oO0
 try :
  if 40 - 40: oOOO00o - I1I11I1I1I / Ooooo0Oo00oO0
  i1OOoO = OO0O000 ( ii1I )
  iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( i1OOoO )
  for oO0O00oOOoooO in iiIiI1i1 :
   if 14 - 14: i1i1i11IIi
   try :
    if 5 - 5: oOOO00o . iIiiiI1IiI1I1 % iIiiiI1IiI1I1
    ooO0oo0o0 = oO0O00oOOoooO
    if 9 - 9: OooO0OO + i1i1i11IIi / OooO0OO . oO0OOoO0 * O0O0oOO00O00o
   except :
    pass
    if 45 - 45: i11iIiiIii
    if 82 - 82: Ii1iIiII1ii1 + iiiI1I11i1
  i1OOoO = OO0O000 ( ooO0oo0o0 )
  iiIiI1i1 = re . compile ( ooOooo000oOO ) . findall ( i1OOoO )
  for iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 , id , IIo0Oo0oO0oOO00 in iiIiI1i1 :
   try :
    I1II1 ( Ooo0OOoOoO0 , oOo0OOoO0 , iiI11ii1I1 , id , IIo0Oo0oO0oOO00 )
    if 12 - 12: Oo0o00
   except :
    pass
 except :
  pass
  if 93 - 93: i11iIiiIii % iIiiiI1IiI1I1 % i11iIiiIii + oOOO00o / oOOO00o / I1I11I1I1I
  if 49 - 49: O00Oo000ooO0 . i1i1i11IIi . i11iIiiIii - I1I11I1I1I / Ii1iIiII1ii1
def ooOo0O0o0 ( ) :
 if 65 - 65: O0O0oOO00O00o + ooOoO
 try :
  if 32 - 32: IIiIiII11i - oo0Oo00Oo0 - i11iIiiIii * oOOO00o / Ooooo0Oo00oO0 + IIiIiII11i
  i1OOoO = OO0O000 ( oO0O0OO0O )
  iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( i1OOoO )
  for oO0O00oOOoooO in iiIiI1i1 :
   if 35 - 35: o0oOOo0O0Ooo - oOOO00o * O0O0O0OoOO
   try :
    if 63 - 63: O0O0O0OoOO * i1i1i11IIi . IIiIiII11i / O00Oo000ooO0 * Ooooo0Oo00oO0 . O0O0oOO00O00o
    Ooo0 = oO0O00oOOoooO
    if 91 - 91: o0oOOo0O0Ooo - iIiiiI1IiI1I1
   except :
    pass
    if 55 - 55: OooO0OO * oOOO00o % O0O0oOO00O00o . iIiiiI1IiI1I1 * Oo0o00
    if 92 - 92: Oo0o00 - iIiiiI1IiI1I1
  i1OOoO = OO0O000 ( Ooo0 )
  iiIiI1i1 = re . compile ( ooOooo000oOO ) . findall ( i1OOoO )
  for iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 , id , IIo0Oo0oO0oOO00 in iiIiI1i1 :
   try :
    I1II1 ( Ooo0OOoOoO0 , oOo0OOoO0 , iiI11ii1I1 , id , IIo0Oo0oO0oOO00 )
    if 32 - 32: Ii1iIiII1ii1 % Ooo * Ooo + iiiI1I11i1 * I1I11I1I1I * Ii1iIiII1ii1
   except :
    pass
 except :
  pass
  if 11 - 11: oO0OOoO0 % I1I11I1I1I
  if 57 - 57: O00Oo000ooO0 / Ooooo0Oo00oO0
def oO0O0Ooo ( ) :
 if 4 - 4: I1I11I1I1I . oO0 + Ii1iIiII1ii1 * Oo0o00 . O0O0oOO00O00o
 try :
  if 87 - 87: oo0Oo00Oo0 / Ooo / i11iIiiIii
  i1OOoO = OO0O000 ( OoOoO )
  iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( i1OOoO )
  for oO0O00oOOoooO in iiIiI1i1 :
   if 74 - 74: oO0OOoO0 / i1i1i11IIi % oOOO00o
   try :
    if 88 - 88: oo0Oo00Oo0 - i11iIiiIii % oOOO00o * oO0 + i1i1i11IIi
    Oo = oO0O00oOOoooO
    if 40 - 40: oo0Oo00Oo0 % Ooo
   except :
    pass
    if 62 - 62: oOOO00o
    if 15 - 15: oO0 + Ii1iIiII1ii1 . O00Oo000ooO0 * Ooo . oo0Oo00Oo0
  i1OOoO = OO0O000 ( Oo )
  iiIiI1i1 = re . compile ( ooOooo000oOO ) . findall ( i1OOoO )
  for iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 , id , IIo0Oo0oO0oOO00 in iiIiI1i1 :
   try :
    I1II1 ( Ooo0OOoOoO0 , oOo0OOoO0 , iiI11ii1I1 , id , IIo0Oo0oO0oOO00 )
    if 18 - 18: o0oOOo0O0Ooo % I1I11I1I1I + Oo0o00 % Ii1iIiII1ii1
   except :
    pass
 except :
  pass
  if 72 - 72: iIiiiI1IiI1I1
  if 45 - 45: Ooooo0Oo00oO0 - oOOO00o % Oo0o00
def i1IIi1i1Ii1 ( ) :
 if 45 - 45: iIiiiI1IiI1I1 . oO0OOoO0 / oo0Oo00Oo0 / iiiI1I11i1
 try :
  if 55 - 55: iiiI1I11i1
  i1OOoO = OO0O000 ( OOI1iI1ii1II )
  iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( i1OOoO )
  for oO0O00oOOoooO in iiIiI1i1 :
   if 24 - 24: Ooo + oO0OOoO0 . oOOO00o / oO0OOoO0
   try :
    if 56 - 56: iIiiiI1IiI1I1 . i11iIiiIii - O00Oo000ooO0 * I1I11I1I1I * Oo0o00
    i1I1 = oO0O00oOOoooO
    if 60 - 60: oo0Oo00Oo0 / Oo0o00 - I1I11I1I1I . Ooooo0Oo00oO0 + ooOoO
   except :
    pass
    if 43 - 43: iIiiiI1IiI1I1 / I1I11I1I1I % oOOO00o - O00Oo000ooO0
  i1OOoO = OO0O000 ( i1I1 )
  iiIiI1i1 = re . compile ( ooOooo000oOO ) . findall ( i1OOoO )
  for iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 , id , IIo0Oo0oO0oOO00 in iiIiI1i1 :
   try :
    I1II1 ( Ooo0OOoOoO0 , oOo0OOoO0 , iiI11ii1I1 , id , IIo0Oo0oO0oOO00 )
    if 62 - 62: oO0
   except :
    pass
 except :
  pass
  if 63 - 63: O00Oo000ooO0 + O0O0oOO00O00o * oO0OOoO0 / oOOO00o / Ooooo0Oo00oO0 * iIiiiI1IiI1I1
  if 57 - 57: oo0Oo00Oo0 - oO0OOoO0 / O0O0oOO00O00o % i11iIiiIii
def I11oOOooo ( ) :
 if 80 - 80: OooO0OO - i11iIiiIii
 try :
  if 69 - 69: oO0OOoO0 % IIiIiII11i . OooO0OO
  i1OOoO = OO0O000 ( oOooO0 )
  iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( i1OOoO )
  for oO0O00oOOoooO in iiIiI1i1 :
   if 34 - 34: Ii1iIiII1ii1 * oo0Oo00Oo0 - iiiI1I11i1 - OooO0OO - Ii1iIiII1ii1
   try :
    if 42 - 42: I1I11I1I1I * OooO0OO % o0oOOo0O0Ooo - Ii1iIiII1ii1 % iiiI1I11i1
    Ii1I1 = oO0O00oOOoooO
    if 58 - 58: iiiI1I11i1 - oO0 % OooO0OO
   except :
    pass
    if 4 - 4: o0oOOo0O0Ooo + O0O0oOO00O00o + o0oOOo0O0Ooo
    if 31 - 31: Ii1iIiII1ii1
  i1OOoO = OO0O000 ( Ii1I1 )
  iiIiI1i1 = re . compile ( ooOooo000oOO ) . findall ( i1OOoO )
  for iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 , id , IIo0Oo0oO0oOO00 in iiIiI1i1 :
   try :
    I1II1 ( Ooo0OOoOoO0 , oOo0OOoO0 , iiI11ii1I1 , id , IIo0Oo0oO0oOO00 )
    if 78 - 78: i11iIiiIii + oOOO00o + Oo0o00 / oOOO00o % iIiiiI1IiI1I1 % iiiI1I11i1
   except :
    pass
 except :
  pass
  if 83 - 83: iIiiiI1IiI1I1 % oo0Oo00Oo0 % oOOO00o % Oo0o00 . i1i1i11IIi % ooOoO
def iIiIi1ii ( ) :
 if 28 - 28: iIiiiI1IiI1I1 + iIiiiI1IiI1I1
 try :
  if 28 - 28: oO0OOoO0
  i1OOoO = OO0O000 ( OOoO0 )
  iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( i1OOoO )
  for oO0O00oOOoooO in iiIiI1i1 :
   if 52 - 52: OooO0OO + iIiiiI1IiI1I1
   try :
    if 71 - 71: ooOoO / oO0OOoO0
    iI1 = oO0O00oOOoooO
    if 11 - 11: Ooo
   except :
    pass
  i1OOoO = OO0O000 ( iI1 )
  iiIiI1i1 = re . compile ( ooOooo000oOO ) . findall ( i1OOoO )
  for iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 , id , IIo0Oo0oO0oOO00 in iiIiI1i1 :
   try :
    I1II1 ( Ooo0OOoOoO0 , oOo0OOoO0 , iiI11ii1I1 , id , IIo0Oo0oO0oOO00 )
    if 18 - 18: O0O0O0OoOO - oO0OOoO0 % O0O0O0OoOO / oO0
   except :
    pass
 except :
  pass
  if 68 - 68: Ii1iIiII1ii1 * iIiiiI1IiI1I1 + Oo0o00 % oo0Oo00Oo0
def IIii1I1I1I ( ) :
 if 79 - 79: i11iIiiIii + Ooooo0Oo00oO0 + IIiIiII11i + oO0OOoO0 % iIiiiI1IiI1I1 . O0O0O0OoOO
 try :
  if 80 - 80: Ii1iIiII1ii1 - oOOO00o
  i1OOoO = OO0O000 ( o00O0 )
  iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( i1OOoO )
  for oO0O00oOOoooO in iiIiI1i1 :
   if 41 - 41: oOOO00o - Ooooo0Oo00oO0 * OooO0OO
   try :
    if 82 - 82: Ooo % oOOO00o % O00Oo000ooO0 / ooOoO
    OOOO0o0 = oO0O00oOOoooO
    if 7 - 7: O0O0O0OoOO
   except :
    pass
  i1OOoO = OO0O000 ( OOOO0o0 )
  iiIiI1i1 = re . compile ( ooOooo000oOO ) . findall ( i1OOoO )
  for iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 , id , IIo0Oo0oO0oOO00 in iiIiI1i1 :
   try :
    I1II1 ( Ooo0OOoOoO0 , oOo0OOoO0 , iiI11ii1I1 , id , IIo0Oo0oO0oOO00 )
    if 78 - 78: O00Oo000ooO0 + O0O0O0OoOO . iiiI1I11i1
   except :
    pass
 except :
  pass
  if 91 - 91: iIiiiI1IiI1I1 . oOOO00o . i1i1i11IIi + IIiIiII11i
def o0o0O0Oo ( ) :
 if 1 - 1: iIiiiI1IiI1I1 + Ooooo0Oo00oO0 / ooOoO - O0O0O0OoOO % iiiI1I11i1 + iiiI1I11i1
 try :
  if 24 - 24: OooO0OO + Ooooo0Oo00oO0 + O00Oo000ooO0 - IIiIiII11i + Ooooo0Oo00oO0
  i1OOoO = OO0O000 ( ii1 )
  iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( i1OOoO )
  for oO0O00oOOoooO in iiIiI1i1 :
   if 93 - 93: O0O0oOO00O00o . iIiiiI1IiI1I1 % i11iIiiIii . oo0Oo00Oo0 % O0O0oOO00O00o + ooOoO
   try :
    if 65 - 65: Ii1iIiII1ii1 + Ooo - IIiIiII11i
    OOoOO0o = oO0O00oOOoooO
    if 51 - 51: Ooooo0Oo00oO0 - i1i1i11IIi * oO0
   except :
    pass
  i1OOoO = OO0O000 ( OOoOO0o )
  iiIiI1i1 = re . compile ( Oo0oOOo ) . findall ( i1OOoO )
  for iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 in iiIiI1i1 :
   try :
    ii1111Ii1i ( iiI11ii1I1 , Ooo0OOoOoO0 , oOo0OOoO0 )
    if 48 - 48: ooOoO * Ii1iIiII1ii1 - ooOoO / Ii1iIiII1ii1 + oo0Oo00Oo0
   except :
    pass
    if 52 - 52: Ooo % Ii1iIiII1ii1 * I1I11I1I1I
 except :
  pass
  if 4 - 4: oO0 % ooOoO - IIiIiII11i + O0O0oOO00O00o . oO0OOoO0 % I1I11I1I1I
  if 9 - 9: I1I11I1I1I * I1I11I1I1I . i11iIiiIii * iIiiiI1IiI1I1
def II1I11Iii1 ( thumb , name , url , id ) :
 if 16 - 16: Ii1iIiII1ii1 * Ooo / oO0OOoO0
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO00Oo ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   Oo00o0OO0O00o ( name , url , '' , thumb , thumb )
  else :
   Oo00o0OO0O00o ( name , url , '' , I1IiI , I1ii11iIi11i )
 else :
  if 'youtube.com/watch?v=' in url :
   url = 'plugin://plugin.video.youtube/play/?video_id=%s' % ( url . split ( '=' ) [ - 1 ] )
  elif 'dailymotion.com/video/' in url :
   url = url . split ( '/' ) [ - 1 ] . split ( '_' ) [ 0 ]
   url = 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=%s' % url
  else :
   url = url
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO00Oo ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   II1iiI ( name , url , 1 , thumb , thumb )
  else :
   II1iiI ( name , url , 1 , I1IiI , I1ii11iIi11i )
   if 31 - 31: oOOO00o % oO0 + iIiiiI1IiI1I1 + i11iIiiIii * Oo0o00
def ii1111Ii1i ( thumb , name , url ) :
 if 45 - 45: O00Oo000ooO0 * Oo0o00 . O0O0oOO00O00o - Oo0o00 + iiiI1I11i1
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO00Oo ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   Oo00o0OO0O00o ( name , url , '' , I1IiI , I1ii11iIi11i )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 34 - 34: O00Oo000ooO0 . Ooooo0Oo00oO0
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO00Oo ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 78 - 78: i1i1i11IIi % OooO0OO / IIiIiII11i % O00Oo000ooO0 - O0O0O0OoOO
   iIi ( name , url , 4 , ii , I1ii11iIi11i )
   if 94 - 94: O0O0oOO00O00o * oO0 - iiiI1I11i1 . iIiiiI1IiI1I1
  else :
   if 66 - 66: O0O0oOO00O00o - O00Oo000ooO0 * oo0Oo00Oo0 / oO0OOoO0 * I1I11I1I1I * Ooo
   iIi ( name , url , 4 , ii , I1ii11iIi11i )
   if 91 - 91: IIiIiII11i / Ii1iIiII1ii1 . OooO0OO + O0O0oOO00O00o . I1I11I1I1I
def I1II1 ( name , url , thumb , id , trailer ) :
 if 45 - 45: oO0OOoO0 * oo0Oo00Oo0 / iIiiiI1IiI1I1
 if 77 - 77: Oo0o00 - oO0
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 11 - 11: i1i1i11IIi
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO00Oo ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   Oo00o0OO0O00o ( name , url , '' , I1IiI , I1ii11iIi11i )
 else :
  if 26 - 26: iIiiiI1IiI1I1 * Oo0o00 - O00Oo000ooO0
  if '[Rapidvideo]' in name :
   if 27 - 27: i1i1i11IIi * Oo0o00 - Ooo + Ii1iIiII1ii1 * Ii1iIiII1ii1
   name = '[COLOR gold]%s[/COLOR]' % name
  if '[rapidvideo]' in name :
   if 55 - 55: O0O0oOO00O00o
   name = '[COLOR gold]%s[/COLOR]' % name
  elif '[streamago]' in name :
   if 82 - 82: Oo0o00 - O00Oo000ooO0 + Ooo
   name = '[COLOR gold]%s[/COLOR]' % name
  elif '[Streamgo]' in name :
   if 64 - 64: oOOO00o . ooOoO * Ii1iIiII1ii1 + IIiIiII11i - Ooooo0Oo00oO0 . IIiIiII11i
   name = '[COLOR gold]%s[/COLOR]' % name
  elif '[Openload]' in name :
   if 70 - 70: Ooooo0Oo00oO0 - oO0OOoO0 . iIiiiI1IiI1I1 % oO0 / oo0Oo00Oo0 - ooOoO
   name = '[COLOR red]%s[/COLOR] [PAIR]' % name
  elif '[openload]' in name :
   if 55 - 55: O0O0O0OoOO - Ooo
   name = '[COLOR red]%s[/COLOR] [PAIR]' % name
  elif '[Vidoza]' in name :
   if 100 - 100: ooOoO
   name = '[COLOR gold]%s[/COLOR]' % name
  elif '[vidoza]' in name :
   if 79 - 79: iIiiiI1IiI1I1
   name = '[COLOR gold]%s[/COLOR]' % name
  elif '[Streamcloud]' in name :
   if 81 - 81: O00Oo000ooO0 + iIiiiI1IiI1I1 * Oo0o00 - iIiiiI1IiI1I1 . O00Oo000ooO0
   name = '[COLOR gold]%s[/COLOR]' % name
  elif '[streamcloud]' in name :
   if 48 - 48: oO0 . IIiIiII11i . OooO0OO . oo0Oo00Oo0 % i1i1i11IIi / O0O0O0OoOO
   name = '[COLOR gold]%s[/COLOR]' % name
   if 11 - 11: o0oOOo0O0Ooo % Ooo % O0O0O0OoOO
  elif '[streamcherry]' in name :
   if 99 - 99: O0O0oOO00O00o / iIiiiI1IiI1I1 - Ii1iIiII1ii1 * i1i1i11IIi % OooO0OO
   name = '[COLOR gold]%s[/COLOR]' % name
   if 13 - 13: Ooo
  elif '[Streamcherry]' in name :
   if 70 - 70: Oo0o00 + ooOoO . oO0OOoO0 * Ii1iIiII1ii1
   name = '[COLOR gold]%s[/COLOR]' % name
   if 2 - 2: IIiIiII11i . O00Oo000ooO0 . iiiI1I11i1
  elif '[Okru]' in name :
   if 42 - 42: O00Oo000ooO0 % oO0OOoO0 / Ooo - oO0OOoO0 * i11iIiiIii
   name = '[COLOR gold]%s[/COLOR]' % name
  elif '[okru]' in name :
   if 19 - 19: oO0OOoO0 * OooO0OO % i11iIiiIii
   name = '[COLOR gold]%s[/COLOR]' % name
  elif '[Multi enlace]' in name :
   if 24 - 24: oOOO00o
   name = '[COLOR gold]%s[/COLOR]' % name
  elif '[4k]' in name :
   if 10 - 10: oOOO00o % Ii1iIiII1ii1 / O00Oo000ooO0
   name = '[COLOR gold]%s[/COLOR]' % name
  elif '[sd]' in name :
   if 28 - 28: O00Oo000ooO0 % O0O0oOO00O00o
   name = '[COLOR gold]%s[/COLOR]' % name
  elif '[hd]' in name :
   if 48 - 48: i11iIiiIii % oO0OOoO0
   name = '[COLOR gold]%s[/COLOR]' % name
  elif '[Youtube]' in name :
   if 29 - 29: O0O0O0OoOO + i11iIiiIii % oO0
   name = '[COLOR white]%s[/COLOR]' % name
  elif '[Realstream]' in name :
   if 93 - 93: oo0Oo00Oo0 % iIiiiI1IiI1I1
   name = '[COLOR gold]%s[/COLOR]' % name
  else :
   if 90 - 90: OooO0OO - O00Oo000ooO0 / Ii1iIiII1ii1 / ooOoO / oO0
   name = '[COLOR white]%s[/COLOR]' % name
   if 87 - 87: oo0Oo00Oo0 / iiiI1I11i1 + iIiiiI1IiI1I1
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OO00Oo ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 93 - 93: iIiiiI1IiI1I1 + oO0OOoO0 % O0O0oOO00O00o
   II1iiI ( name , url , 1 , thumb , thumb , id , trailer )
   if 21 - 21: O00Oo000ooO0
  else :
   if 6 - 6: iiiI1I11i1
   II1iiI ( name , url , 1 , thumb , thumb , id , trailer )
   if 46 - 46: iiiI1I11i1 + oO0OOoO0
def Oo00o0O0O ( name , trailer ) :
 if 84 - 84: oO0 % o0oOOo0O0Ooo
 if 33 - 33: i1i1i11IIi * i1i1i11IIi . O0O0oOO00O00o . i11iIiiIii
 oOo0OOoO0 = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
 IIIIiIi11iiIi = oOo0OOoO0
 i11iI11I1I = xbmcgui . ListItem ( name , trailer , path = IIIIiIi11iiIi )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , i11iI11I1I )
 return
 if 47 - 47: ooOoO * OooO0OO * Ooo . I1I11I1I1I
 if 95 - 95: Ii1iIiII1ii1 % iiiI1I11i1 . ooOoO % Oo0o00
def OOOii1i1iiI ( name , url ) :
 import urlresolver
 from urlresolver import common
 if 94 - 94: o0oOOo0O0Ooo * o0oOOo0O0Ooo % I1I11I1I1I + O00Oo000ooO0
 iIIi11 = urlresolver . HostedMediaFile ( url )
 if 54 - 54: Ii1iIiII1ii1 - Oo0o00
 if not iIIi11 :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 81 - 81: iiiI1I11i1 . ooOoO + I1I11I1I1I * iIiiiI1IiI1I1 * O00Oo000ooO0 / oo0Oo00Oo0
  return False
  if 88 - 88: I1I11I1I1I - oOOO00o * OooO0OO . Ooo
  if 65 - 65: iiiI1I11i1 . o0oOOo0O0Ooo
 try :
  OOOoO0 = iIIi11 . resolve ( )
  if not OOOoO0 or not isinstance ( OOOoO0 , basestring ) :
   try : oo0oo = OOOoO0 . msg
   except : oo0oo = url
   raise Exception ( oo0oo )
 except Exception as OO0O00oOo :
  try : oo0oo = str ( OO0O00oOo )
  except : oo0oo = url
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 49 - 49: i11iIiiIii % oo0Oo00Oo0 + Oo0o00 . I1I11I1I1I % O0O0O0OoOO * O00Oo000ooO0
  return False
  if 67 - 67: o0oOOo0O0Ooo
 iiii = OO0o . getSetting ( 'notificar' )
 if iiii == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
 iiioOOOo = xbmcgui . ListItem ( path = OOOoO0 )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iiioOOOo )
 if 31 - 31: oo0Oo00Oo0 + oo0Oo00Oo0 . i11iIiiIii / O0O0oOO00O00o % oO0 / oo0Oo00Oo0
def IIiI1I111iIiI ( name , url ) :
 if 85 - 85: ooOoO . i1i1i11IIi - o0oOOo0O0Ooo
 if 94 - 94: oOOO00o . Ooo
 if 'https://www.rapidvideo.com/v/' in url :
  if 68 - 68: oOOO00o
  i1OOoO = OO0O000 ( url )
  iiIiI1i1 = re . compile ( 'rapidvideo' ) . findall ( i1OOoO )
  for url in iiIiI1i1 :
   if 20 - 20: Oo0o00 - Oo0o00
   if 37 - 37: iiiI1I11i1
   try :
    iiii = OO0o . getSetting ( 'notificar' )
    if iiii == 'true' :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    iiioOOOo = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iiioOOOo )
    if 37 - 37: Ooooo0Oo00oO0 / iiiI1I11i1 * ooOoO
   except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 73 - 73: O0O0O0OoOO * O0O0O0OoOO / O0O0oOO00O00o
   if 43 - 43: i1i1i11IIi . o0oOOo0O0Ooo . iiiI1I11i1 + ooOoO * Ii1iIiII1ii1 * ooOoO
 else :
  if 41 - 41: i1i1i11IIi + Ii1iIiII1ii1 % IIiIiII11i . i1i1i11IIi + O0O0O0OoOO . O0O0O0OoOO
  import urlresolver
  from urlresolver import common
  if 31 - 31: i11iIiiIii + I1I11I1I1I . O0O0O0OoOO * oo0Oo00Oo0
  iIIi11 = urlresolver . HostedMediaFile ( url )
  if 66 - 66: oo0Oo00Oo0 + o0oOOo0O0Ooo % I1I11I1I1I . ooOoO * i1i1i11IIi % i1i1i11IIi
  if not iIIi11 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 87 - 87: O00Oo000ooO0 + oOOO00o . O0O0O0OoOO - IIiIiII11i
   if 6 - 6: iIiiiI1IiI1I1 * IIiIiII11i
  try :
   OOOoO0 = iIIi11 . resolve ( )
   if not OOOoO0 or not isinstance ( OOOoO0 , basestring ) :
    try : oo0oo = OOOoO0 . msg
    except : oo0oo = url
    raise Exception ( oo0oo )
  except Exception as OO0O00oOo :
   try : oo0oo = str ( OO0O00oOo )
   except : oo0oo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 28 - 28: Ooooo0Oo00oO0 * oOOO00o / Oo0o00
  iiii = OO0o . getSetting ( 'notificar' )
  if iiii == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  iiioOOOo = xbmcgui . ListItem ( path = OOOoO0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iiioOOOo )
  if 52 - 52: ooOoO / oOOO00o % O0O0O0OoOO * OooO0OO % O00Oo000ooO0
 return
 if 69 - 69: i1i1i11IIi
 if 83 - 83: oOOO00o
 if 38 - 38: Oo0o00 + IIiIiII11i . o0oOOo0O0Ooo
def I1III1iIi ( name , url ) :
 if 82 - 82: OooO0OO + O0O0O0OoOO + i1i1i11IIi * OooO0OO % i11iIiiIii % O0O0O0OoOO
 if '[Youtube]' in name :
  if 23 - 23: o0oOOo0O0Ooo . iIiiiI1IiI1I1 . O00Oo000ooO0 . ooOoO % Ii1iIiII1ii1 % i11iIiiIii
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 11 - 11: ooOoO - I1I11I1I1I . O00Oo000ooO0 . Ii1iIiII1ii1 % Oo0o00
  try :
   iiii = OO0o . getSetting ( 'notificar' )
   if iiii == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    iiioOOOo = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iiioOOOo )
    if 21 - 21: Ooooo0Oo00oO0 / O0O0O0OoOO . Oo0o00 * IIiIiII11i + oO0 - o0oOOo0O0Ooo
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 58 - 58: i1i1i11IIi
  if 2 - 2: I1I11I1I1I / Oo0o00
 else :
  if 54 - 54: o0oOOo0O0Ooo . oO0 - i1i1i11IIi + O0O0oOO00O00o + Ooooo0Oo00oO0 / Ooooo0Oo00oO0
  import urlresolver
  from urlresolver import common
  if 22 - 22: O0O0oOO00O00o . iIiiiI1IiI1I1
  iIIi11 = urlresolver . HostedMediaFile ( url )
  if 12 - 12: Ii1iIiII1ii1
  if not iIIi11 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 71 - 71: OooO0OO . I1I11I1I1I . OooO0OO - O0O0oOO00O00o
   if 45 - 45: iiiI1I11i1 / ooOoO / oo0Oo00Oo0 * O00Oo000ooO0
  try :
   OOOoO0 = iIIi11 . resolve ( )
   if not OOOoO0 or not isinstance ( OOOoO0 , basestring ) :
    try : oo0oo = OOOoO0 . msg
    except : oo0oo = url
    raise Exception ( oo0oo )
  except Exception as OO0O00oOo :
   try : oo0oo = str ( OO0O00oOo )
   except : oo0oo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 18 - 18: iIiiiI1IiI1I1 + O00Oo000ooO0 + iIiiiI1IiI1I1 . i1i1i11IIi + Oo0o00 . O0O0oOO00O00o
  iiii = OO0o . getSetting ( 'notificar' )
  if iiii == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  iiioOOOo = xbmcgui . ListItem ( path = OOOoO0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iiioOOOo )
  if 7 - 7: i1i1i11IIi + iIiiiI1IiI1I1 * oO0 * oO0 / I1I11I1I1I - Ii1iIiII1ii1
 return
 if 65 - 65: oO0OOoO0 + oo0Oo00Oo0 + I1I11I1I1I
def oOOoo ( name , url ) :
 if 6 - 6: O00Oo000ooO0
 if 98 - 98: IIiIiII11i % ooOoO - ooOoO
 if '[Youtube]' in name :
  if 76 - 76: o0oOOo0O0Ooo % oo0Oo00Oo0 - OooO0OO / oOOO00o * O0O0oOO00O00o
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 4 - 4: Ooooo0Oo00oO0 * Ooooo0Oo00oO0 / oo0Oo00Oo0
  try :
   iiii = OO0o . getSetting ( 'notificar' )
   if iiii == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    iiioOOOo = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iiioOOOo )
    if 4 - 4: OooO0OO * oo0Oo00Oo0 % oO0 . oo0Oo00Oo0
    if 11 - 11: O00Oo000ooO0 - oo0Oo00Oo0 - oOOO00o * oo0Oo00Oo0 + O0O0oOO00O00o
    if 62 - 62: OooO0OO * i11iIiiIii . O0O0O0OoOO
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 35 - 35: iiiI1I11i1 . ooOoO + Ooooo0Oo00oO0 + O00Oo000ooO0 + o0oOOo0O0Ooo
  if 65 - 65: ooOoO * OooO0OO / OooO0OO . oo0Oo00Oo0
 else :
  if 87 - 87: I1I11I1I1I * i1i1i11IIi % Ooooo0Oo00oO0 * Ooooo0Oo00oO0
  import xbmcgui
  import urlresolver
  from urlresolver import common
  if 58 - 58: O00Oo000ooO0 . oOOO00o + OooO0OO % Ooooo0Oo00oO0 - Ooo
  iIIi11 = urlresolver . HostedMediaFile ( url )
  if 50 - 50: O0O0O0OoOO % I1I11I1I1I - O0O0oOO00O00o . o0oOOo0O0Ooo + ooOoO % O0O0O0OoOO
  if not iIIi11 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 10 - 10: O0O0O0OoOO . o0oOOo0O0Ooo + Ii1iIiII1ii1
  import resolveurl as urlresolver
  if 66 - 66: Ooo % oOOO00o
  iIIi11 = urlresolver . HostedMediaFile ( url )
  if 21 - 21: oo0Oo00Oo0 - IIiIiII11i % i11iIiiIii
  if 71 - 71: o0oOOo0O0Ooo - oO0 * Oo0o00 + oO0OOoO0 - Ooo % i1i1i11IIi
  if not iIIi11 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 63 - 63: iIiiiI1IiI1I1 + O00Oo000ooO0 . Ooo / OooO0OO
  try :
   OOOoO0 = iIIi11 . resolve ( )
   if not OOOoO0 or not isinstance ( OOOoO0 , basestring ) :
    try : oo0oo = OOOoO0 . msg
    except : oo0oo = url
    raise Exception ( oo0oo )
  except Exception as OO0O00oOo :
   try : oo0oo = str ( OO0O00oOo )
   except : oo0oo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 84 - 84: o0oOOo0O0Ooo
   if 42 - 42: I1I11I1I1I - Ooo - IIiIiII11i . O0O0O0OoOO / oo0Oo00Oo0
   if 56 - 56: i11iIiiIii - iIiiiI1IiI1I1 . I1I11I1I1I
  iiii = OO0o . getSetting ( 'notificar' )
  if iiii == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 81 - 81: iiiI1I11i1 / oo0Oo00Oo0 * iiiI1I11i1 . ooOoO
   if '[Realstream]' in name :
    if 61 - 61: Ooo * O00Oo000ooO0 + Oo0o00 . iIiiiI1IiI1I1 % oO0 . Oo0o00
    IiIiiI = OO0o . getSetting ( 'restante' )
    if IiIiiI == 'true' :
     O0o0oo0oOO0oO = xbmcgui . Dialog ( )
     iIiIII1iI1111 = O0o0oo0oOO0oO . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 37 - 37: i11iIiiIii % oO0OOoO0 * O00Oo000ooO0 * O00Oo000ooO0 * Ii1iIiII1ii1
   iiioOOOo = xbmcgui . ListItem ( path = OOOoO0 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iiioOOOo )
   if 24 - 24: O0O0oOO00O00o / O0O0O0OoOO + iiiI1I11i1 . iiiI1I11i1
   if 39 - 39: O0O0oOO00O00o + ooOoO / o0oOOo0O0Ooo % iiiI1I11i1 / oO0OOoO0 * iiiI1I11i1
   if 77 - 77: iiiI1I11i1 . Oo0o00 % oo0Oo00Oo0
 return
 if 42 - 42: iiiI1I11i1 % O0O0O0OoOO % oOOO00o % oO0OOoO0 + oO0 % oo0Oo00Oo0
 if 3 - 3: oO0OOoO0
 if 64 - 64: Ooo . OooO0OO - IIiIiII11i . O0O0oOO00O00o - O0O0O0OoOO
def O0oO0o000o ( name , url ) :
 if 42 - 42: Oo0o00 * iiiI1I11i1
 if 23 - 23: oO0OOoO0 * Oo0o00 - IIiIiII11i * IIiIiII11i % Ooo + I1I11I1I1I
 if '[Youtube]' in name :
  if 9 - 9: iIiiiI1IiI1I1 * Ooo % Oo0o00
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 46 - 46: oO0 . iiiI1I11i1 / I1I11I1I1I % iIiiiI1IiI1I1 + iiiI1I11i1
  try :
   iiii = OO0o . getSetting ( 'notificar' )
   if iiii == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    iiioOOOo = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iiioOOOo )
    if 61 - 61: O00Oo000ooO0 / Ooo + I1I11I1I1I . oO0OOoO0 / Ooooo0Oo00oO0 * O00Oo000ooO0
    if 46 - 46: iIiiiI1IiI1I1
    if 33 - 33: oO0 % oO0 % ooOoO / OooO0OO . o0oOOo0O0Ooo
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 91 - 91: O0O0oOO00O00o * oO0 - I1I11I1I1I . OooO0OO - Ooooo0Oo00oO0 + O0O0oOO00O00o
  if 56 - 56: oOOO00o / iiiI1I11i1 * OooO0OO . oOOO00o
 else :
  if 15 - 15: i11iIiiIii
  import resolveurl
  if 13 - 13: oO0 * I1I11I1I1I * oO0OOoO0 * I1I11I1I1I % iiiI1I11i1 / OooO0OO
  iIIi11 = urlresolver . HostedMediaFile ( url )
  if 100 - 100: iiiI1I11i1 . Ii1iIiII1ii1 - iIiiiI1IiI1I1 . i11iIiiIii / I1I11I1I1I
  if 71 - 71: Oo0o00 * Ooooo0Oo00oO0 . oO0
  if not iIIi11 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 49 - 49: iiiI1I11i1 * ooOoO . iiiI1I11i1
  try :
   OOOoO0 = iIIi11 . resolve ( )
   if not OOOoO0 or not isinstance ( OOOoO0 , basestring ) :
    try : oo0oo = OOOoO0 . msg
    except : oo0oo = url
    raise Exception ( oo0oo )
  except Exception as OO0O00oOo :
   try : oo0oo = str ( OO0O00oOo )
   except : oo0oo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 19 - 19: I1I11I1I1I - iiiI1I11i1
   if 59 - 59: oOOO00o * Ooo - Ii1iIiII1ii1 . O00Oo000ooO0
   if 89 - 89: O00Oo000ooO0
  iiii = OO0o . getSetting ( 'notificar' )
  if iiii == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 69 - 69: O0O0oOO00O00o - IIiIiII11i * ooOoO
   if '[Realstream]' in name :
    if 84 - 84: O0O0oOO00O00o + i11iIiiIii - O00Oo000ooO0 * O0O0oOO00O00o
    IiIiiI = OO0o . getSetting ( 'restante' )
    if IiIiiI == 'true' :
     O0o0oo0oOO0oO = xbmcgui . Dialog ( )
     iIiIII1iI1111 = O0o0oo0oOO0oO . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 33 - 33: O0O0oOO00O00o % o0oOOo0O0Ooo - oO0OOoO0 . ooOoO / ooOoO
   iiioOOOo = xbmcgui . ListItem ( path = OOOoO0 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iiioOOOo )
   if 96 - 96: IIiIiII11i + iiiI1I11i1 * ooOoO
   if 86 - 86: Ii1iIiII1ii1
   if 29 - 29: iIiiiI1IiI1I1 - Ooo + OooO0OO % iIiiiI1IiI1I1 % O00Oo000ooO0
 return
 if 84 - 84: iiiI1I11i1 + i1i1i11IIi + Ii1iIiII1ii1 + O0O0O0OoOO
def ooOOo0o ( name , url ) :
 if 50 - 50: I1I11I1I1I - Oo0o00 + iIiiiI1IiI1I1 + iIiiiI1IiI1I1
 if 91 - 91: I1I11I1I1I - ooOoO . iIiiiI1IiI1I1 . ooOoO + i1i1i11IIi - I1I11I1I1I
 if '[Youtube]' in name :
  if 26 - 26: oOOO00o
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 12 - 12: IIiIiII11i / ooOoO + I1I11I1I1I * i1i1i11IIi
  try :
   iiii = OO0o . getSetting ( 'notificar' )
   if iiii == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    iiioOOOo = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iiioOOOo )
    if 46 - 46: I1I11I1I1I - iiiI1I11i1 * IIiIiII11i / oO0OOoO0 % iiiI1I11i1
    if 11 - 11: iIiiiI1IiI1I1 . oo0Oo00Oo0 / iiiI1I11i1 % O0O0oOO00O00o
    if 61 - 61: O0O0oOO00O00o - O00Oo000ooO0 + O00Oo000ooO0
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace borrado, o no disponible en tu pais.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 40 - 40: i11iIiiIii . iIiiiI1IiI1I1
  if 2 - 2: o0oOOo0O0Ooo * oO0OOoO0 - oO0OOoO0 + IIiIiII11i % oo0Oo00Oo0 / oo0Oo00Oo0
 else :
  if 3 - 3: IIiIiII11i
  if 71 - 71: iiiI1I11i1 + o0oOOo0O0Ooo - O0O0O0OoOO - i11iIiiIii . oO0 - O0O0oOO00O00o
  import resolveurl
  if 85 - 85: i1i1i11IIi - oo0Oo00Oo0 / i1i1i11IIi + O00Oo000ooO0 - O0O0O0OoOO
  iIIi11 = urlresolver . HostedMediaFile ( url )
  if 49 - 49: Ooo - ooOoO / Ooo * oo0Oo00Oo0 + Oo0o00
  if 35 - 35: I1I11I1I1I . OooO0OO / o0oOOo0O0Ooo / OooO0OO * oO0OOoO0
  if not iIIi11 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 85 - 85: I1I11I1I1I . O0O0oOO00O00o % O00Oo000ooO0 % oO0
  try :
   OOOoO0 = iIIi11 . resolve ( )
   if not OOOoO0 or not isinstance ( OOOoO0 , basestring ) :
    try : oo0oo = OOOoO0 . msg
    except : oo0oo = url
    raise Exception ( oo0oo )
  except Exception as OO0O00oOo :
   try : oo0oo = str ( OO0O00oOo )
   except : oo0oo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 80 - 80: oO0OOoO0 * oO0 / iIiiiI1IiI1I1 % oO0OOoO0 / iIiiiI1IiI1I1
   if 42 - 42: o0oOOo0O0Ooo / i11iIiiIii . Ooooo0Oo00oO0 * O0O0O0OoOO . i11iIiiIii * ooOoO
   if 44 - 44: o0oOOo0O0Ooo . OooO0OO / i11iIiiIii + iiiI1I11i1
  iiii = OO0o . getSetting ( 'notificar' )
  if iiii == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 27 - 27: O00Oo000ooO0
   if '[Realstream]' in name :
    if 52 - 52: Oo0o00 % oo0Oo00Oo0 + iIiiiI1IiI1I1 * oO0OOoO0 . Ii1iIiII1ii1
    IiIiiI = OO0o . getSetting ( 'restante' )
    if IiIiiI == 'true' :
     O0o0oo0oOO0oO = xbmcgui . Dialog ( )
     iIiIII1iI1111 = O0o0oo0oOO0oO . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 95 - 95: iIiiiI1IiI1I1 . iiiI1I11i1 - IIiIiII11i * Ooo / oOOO00o
   iiioOOOo = xbmcgui . ListItem ( path = OOOoO0 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iiioOOOo )
   if 74 - 74: oO0OOoO0
   if 34 - 34: O0O0O0OoOO
   if 44 - 44: o0oOOo0O0Ooo % OooO0OO % oOOO00o
 return
def iIIi1Ii1III ( ) :
 if 86 - 86: i11iIiiIii + i11iIiiIii . Oo0o00 % OooO0OO . O0O0oOO00O00o
 if 17 - 17: Ii1iIiII1ii1
 OoO0OOoO0Oo0 = [ ]
 oO00O = sys . argv [ 2 ]
 if len ( oO00O ) >= 2 :
  II111IiiiI1 = sys . argv [ 2 ]
  oooOO0oo0Oo00 = II111IiiiI1 . replace ( '?' , '' )
  if ( II111IiiiI1 [ len ( II111IiiiI1 ) - 1 ] == '/' ) :
   II111IiiiI1 = II111IiiiI1 [ 0 : len ( II111IiiiI1 ) - 2 ]
  oOoO = oooOO0oo0Oo00 . split ( '&' )
  OoO0OOoO0Oo0 = { }
  for iI111I1III in range ( len ( oOoO ) ) :
   i111IiiI1Ii = { }
   i111IiiI1Ii = oOoO [ iI111I1III ] . split ( '=' )
   if ( len ( i111IiiI1Ii ) ) == 2 :
    OoO0OOoO0Oo0 [ i111IiiI1Ii [ 0 ] ] = i111IiiI1Ii [ 1 ]
 return OoO0OOoO0Oo0
 if 72 - 72: ooOoO . oo0Oo00Oo0 * Ooooo0Oo00oO0 + i1i1i11IIi - oOOO00o
 if 40 - 40: Ooo + Ooo
def o0oo0o00ooO00 ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  import urlresolver
  xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
  if 37 - 37: Ooo - i1i1i11IIi . IIiIiII11i . O0O0oOO00O00o + oo0Oo00Oo0 / Ii1iIiII1ii1
def I1 ( ) :
 O0o0oo0oOO0oO = xbmcgui . Dialog ( )
 list = (
 oOoO0OOO00O ,
 OOOOO0o0OOo
 )
 if 40 - 40: iiiI1I11i1 * oO0OOoO0 % oO0 * i1i1i11IIi
 OoOoOOoO = O0o0oo0oOO0oO . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=gold]Accede a themoviedb.com[/COLOR]' ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 19 - 19: iIiiiI1IiI1I1 * IIiIiII11i * i11iIiiIii
 if OoOoOOoO :
  if 79 - 79: iiiI1I11i1 % Ooo
  if OoOoOOoO < 0 :
   return
  Oo0oOO = list [ OoOoOOoO - 2 ]
  return Oo0oOO ( )
 else :
  Oo0oOO = list [ OoOoOOoO ]
  return Oo0oOO ( )
 return
 if 86 - 86: iIiiiI1IiI1I1 / ooOoO
def iiiIioo ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 39 - 39: OooO0OO + Ooooo0Oo00oO0
o0OO = iiiIioo ( )
if 76 - 76: ooOoO . Ooo + oo0Oo00Oo0
def oOoO0OOO00O ( ) :
 if o0OO == 'android' :
  II1111II = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  II1111II = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 41 - 41: I1I11I1I1I * O0O0oOO00O00o
  if 68 - 68: Ii1iIiII1ii1 - OooO0OO
def OOOOO0o0OOo ( ) :
 if 41 - 41: oO0OOoO0
 main ( )
 if 21 - 21: O0O0oOO00O00o + oOOO00o % Oo0o00 + i11iIiiIii + O0O0O0OoOO + I1I11I1I1I
 if 98 - 98: Oo0o00
 if 49 - 49: Ooooo0Oo00oO0 * oO0OOoO0 + oOOO00o - i11iIiiIii
def OOooO ( ) :
 O0o0oo0oOO0oO = xbmcgui . Dialog ( )
 i1i1Ii1Ii = (
 oOo0OoO ,
 O000O0
 )
 if 65 - 65: i11iIiiIii
 OoOoOOoO = O0o0oo0oOO0oO . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 84 - 84: Ooooo0Oo00oO0 % O0O0O0OoOO % IIiIiII11i + O00Oo000ooO0 % i11iIiiIii
 if OoOoOOoO :
  if 47 - 47: o0oOOo0O0Ooo + I1I11I1I1I . Ooooo0Oo00oO0 * oO0OOoO0 . oO0 / o0oOOo0O0Ooo
  if OoOoOOoO < 0 :
   return
  Oo0oOO = i1i1Ii1Ii [ OoOoOOoO - 2 ]
  return Oo0oOO ( )
 else :
  Oo0oOO = i1i1Ii1Ii [ OoOoOOoO ]
  return Oo0oOO ( )
 return
 if 50 - 50: Oo0o00 / o0oOOo0O0Ooo % IIiIiII11i
def iiiIioo ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 83 - 83: i1i1i11IIi * i1i1i11IIi + O00Oo000ooO0
o0OO = iiiIioo ( )
if 57 - 57: ooOoO - ooOoO . i1i1i11IIi / oOOO00o / Ii1iIiII1ii1
def oOo0OoO ( ) :
 if o0OO == 'android' :
  II1111II = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  II1111II = webbrowser . open ( 'https://olpair.com/' )
  if 20 - 20: O00Oo000ooO0 * I1I11I1I1I - oo0Oo00Oo0 - oO0OOoO0 * Oo0o00
  if 6 - 6: O0O0oOO00O00o + O00Oo000ooO0 / Ooooo0Oo00oO0 + iiiI1I11i1 % I1I11I1I1I / Ooo
def O000O0 ( ) :
 if 45 - 45: IIiIiII11i
 main ( )
 if 9 - 9: oO0 . Ooo * o0oOOo0O0Ooo . IIiIiII11i
 if 32 - 32: oo0Oo00Oo0 . i1i1i11IIi % OooO0OO - I1I11I1I1I
def iiI111 ( name , url , id , trailer ) :
 O0o0oo0oOO0oO = xbmcgui . Dialog ( )
 i1i1Ii1Ii = (
 OOoooo0oo ,
 oOo0O ,
 i1i ,
 I1
 )
 if 60 - 60: Ooooo0Oo00oO0 . iiiI1I11i1 % OooO0OO - Oo0o00
 OoOoOOoO = O0o0oo0oOO0oO . select ( '[COLOR=yellow]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=yellow]Reproducir [/COLOR] [COLOR orange]' + name + '[/COLOR]' ,

 '[COLOR=yellow]Reproducir Trailer de: [/COLOR][COLOR orange]' + name + '[/COLOR]' ,

 '[COLOR=yellow]      Mas Informacion, ver trailers  [/COLOR]' ,

 '[COLOR orange]        Accede a la web MovieDB[/COLOR]' ] )
 if 79 - 79: IIiIiII11i / i1i1i11IIi . ooOoO
 if OoOoOOoO :
  if 79 - 79: oO0OOoO0 - I1I11I1I1I
  if OoOoOOoO < 0 :
   return
  Oo0oOO = i1i1Ii1Ii [ OoOoOOoO - 4 ]
  return Oo0oOO ( )
 else :
  Oo0oOO = i1i1Ii1Ii [ OoOoOOoO ]
  return Oo0oOO ( )
 return
 if 43 - 43: o0oOOo0O0Ooo + ooOoO % Ooo / Ii1iIiII1ii1 * OooO0OO
 if 89 - 89: OooO0OO . Ooooo0Oo00oO0 + i1i1i11IIi . ooOoO % oOOO00o
def OOoooo0oo ( ) :
 if 84 - 84: IIiIiII11i + Oo0o00 / OooO0OO % O00Oo000ooO0 % i1i1i11IIi * OooO0OO
 ooOOo0o ( Ooo0OOoOoO0 , oOo0OOoO0 )
 if 58 - 58: Ooo - oo0Oo00Oo0 . i11iIiiIii % i11iIiiIii / o0oOOo0O0Ooo / oO0OOoO0
def oOo0O ( ) :
 if 24 - 24: OooO0OO * o0oOOo0O0Ooo % O0O0oOO00O00o / ooOoO + i11iIiiIii
 Oo00o0O0O ( Ooo0OOoOoO0 , IIo0Oo0oO0oOO00 )
 if 12 - 12: i1i1i11IIi / Ii1iIiII1ii1
 if 5 - 5: IIiIiII11i
def i1i ( ) :
 if 18 - 18: OooO0OO % IIiIiII11i - O0O0O0OoOO . i11iIiiIii * Ooooo0Oo00oO0 % Ii1iIiII1ii1
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  Ii1I1O0oo00oOOO0o = id
  if 5 - 5: oOOO00o / OooO0OO % Ii1iIiII1ii1 . iiiI1I11i1
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % Ii1I1O0oo00oOOO0o )
  if 86 - 86: o0oOOo0O0Ooo * oo0Oo00Oo0 . ooOoO - Ii1iIiII1ii1 - oOOO00o - oo0Oo00Oo0
 if iiii == 'true' :
  if 47 - 47: O00Oo000ooO0 + oO0
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + Ooo0OOoOoO0 + "[/COLOR] ,5000)" )
  if 50 - 50: Oo0o00 + i1i1i11IIi
  if 4 - 4: iiiI1I11i1 / Ooooo0Oo00oO0
def I1IIiiII ( ) :
 if 59 - 59: Ooo - Ooo + O0O0O0OoOO
 I1 ( )
 if 32 - 32: o0oOOo0O0Ooo / Ooooo0Oo00oO0 - ooOoO
 if 85 - 85: Ii1iIiII1ii1 - ooOoO * i11iIiiIii . o0oOOo0O0Ooo
 if 20 - 20: O0O0O0OoOO / O00Oo000ooO0
def Oo00o0OO0O00o ( name , url , mode , iconimage , fanart ) :
 if 28 - 28: O0O0oOO00O00o * oO0 % i11iIiiIii * O0O0O0OoOO / Ii1iIiII1ii1
 iIII1iIi = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 iIiIII1iI1111 = True
 o000O0oo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 o000O0oo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 o000O0oo . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  iIII1iIi = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  iIiIII1iI1111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iIII1iIi , listitem = o000O0oo , isFolder = True )
  return iIiIII1iI1111
 iIiIII1iI1111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iIII1iIi , listitem = o000O0oo , isFolder = True )
 return iIiIII1iI1111
 if 78 - 78: Ooo / Ooooo0Oo00oO0 - iIiiiI1IiI1I1 - i11iIiiIii * O0O0O0OoOO
def II1iiI ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 84 - 84: O00Oo000ooO0 + Ii1iIiII1ii1 + oOOO00o
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 i1i1iIII11i = [ ]
 iIII1iIi = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 o000O0oo = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 o000O0oo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 o000O0oo . setProperty ( 'fanart_image' , fanart )
 o000O0oo . setProperty ( 'IsPlayable' , 'true' )
 if 40 - 40: iIiiiI1IiI1I1 / oo0Oo00Oo0 - ooOoO * iIiiiI1IiI1I1
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  i1i1iIII11i . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  o000O0oo . addContextMenuItems ( i1i1iIII11i , replaceItems = True )
 iIiIII1iI1111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iIII1iIi , listitem = o000O0oo )
 return iIiIII1iI1111
 if 56 - 56: O00Oo000ooO0
def iIi ( name , url , mode , iconimage , fanart ) :
 if 49 - 49: O0O0oOO00O00o . I1I11I1I1I
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 24 - 24: ooOoO . IIiIiII11i - Ooo * IIiIiII11i
 iIII1iIi = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 o000O0oo = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 o000O0oo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 o000O0oo . setProperty ( 'fanart_image' , fanart )
 o000O0oo . setProperty ( 'IsPlayable' , 'true' )
 iIiIII1iI1111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iIII1iIi , listitem = o000O0oo )
 return iIiIII1iI1111
 if 12 - 12: ooOoO + iiiI1I11i1 * o0oOOo0O0Ooo . Ooo
 if 71 - 71: Oo0o00 - oOOO00o - O00Oo000ooO0
def iiI ( ) :
 if 81 - 81: iiiI1I11i1 * i1i1i11IIi + I1I11I1I1I % iiiI1I11i1
 if 46 - 46: I1I11I1I1I % O0O0O0OoOO - o0oOOo0O0Ooo / oO0 * oo0Oo00Oo0
 if 92 - 92: Ooooo0Oo00oO0 - Oo0o00
 OOOO0OoOO0o0o = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 OOOO0OoOO0o0o . doModal ( )
 if ( OOOO0OoOO0o0o . isConfirmed ( ) ) :
  if 24 - 24: oO0OOoO0 / Oo0o00 / oO0 % oo0Oo00Oo0 / i1i1i11IIi * O0O0oOO00O00o
  iI1111iiii = urllib . quote_plus ( OOOO0OoOO0o0o . getText ( ) ) . replace ( '+' , ' ' )
  if 8 - 8: Ii1iIiII1ii1
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 33 - 33: oOOO00o / ooOoO + O00Oo000ooO0
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % iI1111iiii )
    if 75 - 75: iiiI1I11i1 % i11iIiiIii + iIiiiI1IiI1I1
    if iiii == 'true' :
     if 92 - 92: oo0Oo00Oo0 % ooOoO
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + Ooo0OOoOoO0 + "[/COLOR] ,10000)" )
     if 55 - 55: iIiiiI1IiI1I1 * O0O0O0OoOO
   except :
    if 85 - 85: iIiiiI1IiI1I1 . I1I11I1I1I
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 54 - 54: Ii1iIiII1ii1 . IIiIiII11i % Ooooo0Oo00oO0
    if 22 - 22: O00Oo000ooO0
    if 22 - 22: O0O0O0OoOO * oO0 - Ooooo0Oo00oO0 * ooOoO / i11iIiiIii
II111IiiiI1 = iIIi1Ii1III ( )
oOo0OOoO0 = None
Ooo0OOoOoO0 = None
OOooO0Oo0o000 = None
ii = None
id = None
IIo0Oo0oO0oOO00 = None
if 17 - 17: iIiiiI1IiI1I1 + OooO0OO
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 57 - 57: oOOO00o / Oo0o00
try :
 oOo0OOoO0 = urllib . unquote_plus ( II111IiiiI1 [ "url" ] )
except :
 pass
try :
 Ooo0OOoOoO0 = urllib . unquote_plus ( II111IiiiI1 [ "name" ] )
except :
 pass
try :
 OOooO0Oo0o000 = int ( II111IiiiI1 [ "mode" ] )
except :
 pass
try :
 ii = urllib . unquote_plus ( II111IiiiI1 [ "iconimage" ] )
except :
 pass
try :
 id = int ( II111IiiiI1 [ "id" ] )
except :
 pass
try :
 IIo0Oo0oO0oOO00 = urllib . unquote_plus ( II111IiiiI1 [ "trailer" ] )
except :
 pass
 if 13 - 13: IIiIiII11i + Ooo
 if 32 - 32: ooOoO + oO0OOoO0 % Ooooo0Oo00oO0
print "Mode: " + str ( OOooO0Oo0o000 )
print "URL: " + str ( oOo0OOoO0 )
print "Name: " + str ( Ooo0OOoOoO0 )
print "iconimage: " + str ( ii )
print "id: " + str ( id )
print "trailer: " + str ( IIo0Oo0oO0oOO00 )
if 7 - 7: i1i1i11IIi / O0O0oOO00O00o
if OOooO0Oo0o000 == None or oOo0OOoO0 == None or len ( oOo0OOoO0 ) < 1 :
 if 11 - 11: iiiI1I11i1 * O0O0oOO00O00o / O0O0oOO00O00o - O00Oo000ooO0
 if 68 - 68: OooO0OO % iiiI1I11i1 - iiiI1I11i1 / OooO0OO + i1i1i11IIi - Ooooo0Oo00oO0
 II1i111Ii1i ( )
 I1I = OO0o . getSetting ( 'aviso' )
 if I1I == 'true' :
  I1III1111iIi ( )
  if 65 - 65: O0O0oOO00O00o - o0oOOo0O0Ooo
  if 62 - 62: oO0 / oO0OOoO0 % Ooooo0Oo00oO0 . IIiIiII11i / i11iIiiIii / Oo0o00
 i1iiI11I = OO0o . getSetting ( 'licencia_addon' )
 III1iII1I1ii = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 OooO0O0Ooo = OO0o . getSetting ( 'key_ext' )
 oOOo0 = 'aHR0cDovL2JpdC5seS8yUjQxbmh1' . decode ( 'base64' )
 i1OOoO = OO0O000 ( oOOo0 )
 iiIiI1i1 = re . compile ( ii1ii1ii ) . findall ( i1OOoO )
 for oO0O in iiIiI1i1 :
  try :
   if 25 - 25: oO0OOoO0 % OooO0OO + i11iIiiIii + ooOoO * IIiIiII11i
   if 64 - 64: o0oOOo0O0Ooo
   i1iiI11I = OO0o . getSetting ( 'licencia_addon' )
   if 10 - 10: Oo0o00 % ooOoO / OooO0OO % oO0
   if 25 - 25: I1I11I1I1I / Ooo
   if i1iiI11I == oO0O :
    if 64 - 64: ooOoO % O0O0oOO00O00o
    xbmcgui . Dialog ( ) . ok ( "Realstream Licencia:" , "[COLOR lime]Su licencia es correcta.[/COLOR] [COLOR gold]Sientese y disfrute de Realstream.[/COLOR]" )
    if 40 - 40: oOOO00o + oO0
    iiIiIi ( )
    if 77 - 77: i11iIiiIii % iiiI1I11i1 + Oo0o00 % IIiIiII11i - oO0
   else :
    if 26 - 26: Ooooo0Oo00oO0 + ooOoO - iIiiiI1IiI1I1
    xbmcgui . Dialog ( ) . ok ( "Realstream Licencia:" , "[COLOR red]Su licencia ha prescrito, o no ha introducido una valida desde ajustes del addon.[/COLOR] [COLOR gold]Ponganse en contacto con nosotros en nuestro grupo de telegram.[/COLOR]" )
    if 47 - 47: IIiIiII11i
    if 2 - 2: oo0Oo00Oo0 % Oo0o00 * Ooooo0Oo00oO0 * oo0Oo00Oo0
  except :
   pass
   if 65 - 65: i11iIiiIii + Ooooo0Oo00oO0 * IIiIiII11i - Ooo
elif OOooO0Oo0o000 == 1 :
 iiI111 ( Ooo0OOoOoO0 , oOo0OOoO0 , id , IIo0Oo0oO0oOO00 )
elif OOooO0Oo0o000 == 2 :
 oooO0 ( )
elif OOooO0Oo0o000 == 3 :
 oOOOoo ( )
elif OOooO0Oo0o000 == 4 :
 OOOii1i1iiI ( Ooo0OOoOoO0 , oOo0OOoO0 )
elif OOooO0Oo0o000 == 5 :
 Ooooo00o0OoO ( )
elif OOooO0Oo0o000 == 6 :
 oOo0oO ( )
elif OOooO0Oo0o000 == 7 :
 II1i1i1iII1 ( )
elif OOooO0Oo0o000 == 8 :
 o00oO00 ( )
elif OOooO0Oo0o000 == 9 :
 i11111I1I ( )
elif OOooO0Oo0o000 == 10 :
 i1OoOO ( )
elif OOooO0Oo0o000 == 11 :
 I1iii ( )
elif OOooO0Oo0o000 == 12 :
 oO0oO00oOo0OOO ( )
elif OOooO0Oo0o000 == 13 :
 i1I ( )
elif OOooO0Oo0o000 == 14 :
 oOO0o000Oo00o ( )
elif OOooO0Oo0o000 == 15 :
 iii1III1i ( )
elif OOooO0Oo0o000 == 16 :
 OOoOO0OO ( )
elif OOooO0Oo0o000 == 17 :
 oOo ( )
elif OOooO0Oo0o000 == 18 :
 OO0oOOo0o ( )
elif OOooO0Oo0o000 == 19 :
 IiiIiI ( )
elif OOooO0Oo0o000 == 20 :
 ooOo0O0o0 ( )
elif OOooO0Oo0o000 == 21 :
 oO0O0Ooo ( )
elif OOooO0Oo0o000 == 22 :
 i1IIi1i1Ii1 ( )
elif OOooO0Oo0o000 == 23 :
 I11oOOooo ( )
elif OOooO0Oo0o000 == 24 :
 iIiIi1ii ( )
elif OOooO0Oo0o000 == 25 :
 IIii1I1I1I ( )
elif OOooO0Oo0o000 == 26 :
 Oo0000oOo ( )
elif OOooO0Oo0o000 == 98 :
 busqueda_global ( )
elif OOooO0Oo0o000 == 97 :
 OOooO ( )
elif OOooO0Oo0o000 == 99 :
 oO0oO0 ( )
elif OOooO0Oo0o000 == 100 :
 menu_player ( Ooo0OOoOoO0 , oOo0OOoO0 )
elif OOooO0Oo0o000 == 111 :
 IiiiIIiIi1 ( )
elif OOooO0Oo0o000 == 115 :
 Oo00o0O0O ( oOo0OOoO0 )
elif OOooO0Oo0o000 == 116 :
 I1I1i ( )
elif OOooO0Oo0o000 == 119 :
 I1iIi1iIiiIiI ( )
elif OOooO0Oo0o000 == 120 :
 i111iI ( )
elif OOooO0Oo0o000 == 121 :
 Oo000ooOOO ( )
elif OOooO0Oo0o000 == 125 :
 o0o0O0Oo ( )
elif OOooO0Oo0o000 == 126 :
 torrentPro ( )
elif OOooO0Oo0o000 == 127 :
 iiI ( )
elif OOooO0Oo0o000 == 128 :
 TESTLINKS ( )
elif OOooO0Oo0o000 == 140 :
 I1iii11 ( )
 if 26 - 26: oOOO00o % O00Oo000ooO0 + O00Oo000ooO0 % oO0 * i11iIiiIii / O0O0O0OoOO
xbmcplugin . endOfDirectory ( O0O0OO0O0O0 ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
