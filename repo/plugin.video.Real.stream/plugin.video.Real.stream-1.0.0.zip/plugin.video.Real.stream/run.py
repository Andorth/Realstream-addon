# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 1.0.0
#
############################################
# Dependencias 
# Script ExtendedInfo
# Script Urlresolver de TVAddons
# Script ResolveURL Por Jsergio.
#
############################################
#
# Corregida fallo que producia cuelgue de kodi al realstream no encontrar un enlace.
# Adaptacion del codigo fuente a kodi 18.4
#
############################################
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import urlresolver
import cookielib , base64
import requests
import plugintools
import config
oo000 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
ii = oo000 . getAddonInfo ( 'version' )
oOOo = int ( sys . argv [ 1 ] )
O0 = 'gruponetai/'
o0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
iI11I1II1I1I = o0O . getAddonInfo ( 'profile' )
oooo = o0O . getAddonInfo ( 'path' )
iIIii1IIi = oo000 . getSetting ( 'iconos' )
if 73 - 73: II111iiii
def IiII1IiiIiI1 ( ) :
 if 40 - 40: oo * OoO0O00
 IIiIiII11i = oo000 . getSetting ( 'licencia_addon' )
 o0oOOo0O0Ooo = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 I1ii11iIi11i = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 I1IiI = oo000 . getSetting ( 'key_ext' )
 o0OOO = iIiiiI ( I1ii11iIi11i )
 Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
 for IiII in Iii1ii1II11i :
  try :
   if 28 - 28: Ii11111i * iiI1i1
   if 46 - 46: Ooo0OO0oOO * Ii * Oo0o
   IIiIiII11i = oo000 . getSetting ( 'licencia_addon' )
   if 60 - 60: Oo0oO0oo0oO00 + i11Ii11I1Ii1i . ooO - IiIiI11iIi
   if 1 - 1: IIii11I1 - i1111 - i1IIi11111i / I11i1i11i1I % Iiii
   if IIiIiII11i == IiII :
    if 87 - 87: oO0o0o0ooO0oO / I1i1I - OoOoo0 % Ii % Oo0oO0oo0oO00 / Oo0oO0oo0oO00
    if 30 - 30: Oo0oO0oo0oO00
    if 95 - 95: IIii11I1 * ooO / Ooo0OO0oOO . IiIiI11iIi + i1111
    iI11 ( )
    if 17 - 17: ooO
   else :
    if 64 - 64: I11i1i11i1I % iiI1i1 % Ii11111i
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold]>El addon esta desactivado.[/COLOR]" )
    if 3 - 3: Iiii + oo
    if 42 - 42: i1111 / iiI1i1 + II111iiii - I11i1i11i1I
  except :
   pass
   if 78 - 78: Oo0oO0oo0oO00
   if 18 - 18: oo - Iiii / Iiii + OoOoo0 % OoOoo0 - oO0o0o0ooO0oO
   if 62 - 62: Iiii - oO0o0o0ooO0oO - i11Ii11I1Ii1i % iiI1i1 / IIii11I1
   if 77 - 77: Ooo0OO0oOO - Ooo0OO0oOO . Ii / ooO
if iIIii1IIi == 'true' :
 if 14 - 14: i1IIi11111i % oo
 IiI1I1 = xbmc . translatePath ( os . path . join ( oooo , 'fanart.png' ) )
 OoO000 = xbmc . translatePath ( os . path . join ( oooo , 'icon.png' ) )
 IIiiIiI1 = xbmc . translatePath ( os . path . join ( oooo , 'extended_info.png' ) )
 iiIiIIi = xbmc . translatePath ( os . path . join ( oooo , 'buscar.png' ) )
 ooOoo0O = xbmc . translatePath ( os . path . join ( oooo , 'pair.png' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( oooo , 'theMovieDB.png' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( oooo , 'novedades.png' ) )
 OO0o = xbmc . translatePath ( os . path . join ( oooo , 'estrenos.png' ) )
 Ooo = xbmc . translatePath ( os . path . join ( oooo , 'recomendadas.png' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( oooo , 'accion.png' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( oooo , 'animacion.png' ) )
 O0O = xbmc . translatePath ( os . path . join ( oooo , 'aventuras.png' ) )
 O00o0OO = xbmc . translatePath ( os . path . join ( oooo , 'belico.png' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( oooo , 'ciencia-ficcion.png' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( oooo , 'clasicos.png' ) )
 o0 = xbmc . translatePath ( os . path . join ( oooo , 'comedia.png' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( oooo , 'crimen.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( oooo , 'drama.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( oooo , 'familiar.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( oooo , 'fantasia.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( oooo , 'historia.png' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( oooo , 'marvel.png' ) )
 OOOO = xbmc . translatePath ( os . path . join ( oooo , 'misterio.png' ) )
 OOO00 = xbmc . translatePath ( os . path . join ( oooo , 'musical.png' ) )
 iiiiiIIii = xbmc . translatePath ( os . path . join ( oooo , 'romance.png' ) )
 O000OO0 = xbmc . translatePath ( os . path . join ( oooo , 'spain.png' ) )
 I11iii1Ii = xbmc . translatePath ( os . path . join ( oooo , 'suspense.png' ) )
 I1IIiiIiii = xbmc . translatePath ( os . path . join ( oooo , 'terror.png' ) )
 O000oo0O = xbmc . translatePath ( os . path . join ( oooo , 'thriller.png' ) )
 OOOOi11i1 = xbmc . translatePath ( os . path . join ( oooo , 'western.png' ) )
 IIIii1II1II = xbmc . translatePath ( os . path . join ( oooo , 'sagas_cine.png' ) )
 i1I1iI = xbmc . translatePath ( os . path . join ( oooo , '4k.png' ) )
 oo0OooOOo0 = xbmc . translatePath ( os . path . join ( oooo , 'torrent.png' ) )
 o0OO00oO = xbmc . translatePath ( os . path . join ( oooo , 'buscar-serie.jpg' ) )
 I11i1I1I = xbmc . translatePath ( os . path . join ( oooo , 'series-todas.jpg' ) )
 oO0Oo = xbmc . translatePath ( os . path . join ( oooo , 'favorites.png' ) )
 oOOoo0Oo = xbmc . translatePath ( os . path . join ( oooo , 'artesmarciales.png' ) )
 o00OO00OoO = xbmc . translatePath ( os . path . join ( oooo , 'emision.png' ) )
 OOOO0OOoO0O0 = xbmc . translatePath ( os . path . join ( oooo , 'mejores.png' ) )
 if 65 - 65: oO0o0o0ooO0oO * Ii + I11i1i11i1I % II111iiii * IIii11I1 . I1i1I
else :
 if 100 - 100: oo + oO0o0o0ooO0oO - i1111 + II111iiii * I11i1i11i1I
 if 30 - 30: ooO . I11i1i11i1I - Ii11111i
 oOOoo0Oo = xbmc . translatePath ( os . path . join ( oooo , 'artesmarciales.png' ) )
 iIIii1IIi = oo000 . getSetting ( 'iconos' )
 IiI1I1 = xbmc . translatePath ( os . path . join ( oooo , 'fanart.jpg' ) )
 OoO000 = xbmc . translatePath ( os . path . join ( oooo , 'icon.png' ) )
 IIiiIiI1 = xbmc . translatePath ( os . path . join ( oooo , 'extended_info.png' ) )
 iiIiIIi = xbmc . translatePath ( os . path . join ( oooo , 'buscar.png' ) )
 ooOoo0O = xbmc . translatePath ( os . path . join ( oooo , 'pair.png' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( oooo , 'theMovieDB.jpg' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( oooo , 'novedades.jpg' ) )
 OO0o = xbmc . translatePath ( os . path . join ( oooo , 'encines.jpg' ) )
 Ooo = xbmc . translatePath ( os . path . join ( oooo , 'recomendadas.jpg' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( oooo , 'accion.jpg' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( oooo , 'animacion.jpg' ) )
 O0O = xbmc . translatePath ( os . path . join ( oooo , 'aventuras.jpg' ) )
 O00o0OO = xbmc . translatePath ( os . path . join ( oooo , 'belico.jpg' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( oooo , 'ciencia-ficcion.jpg' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( oooo , 'clasicos.png' ) )
 o0 = xbmc . translatePath ( os . path . join ( oooo , 'comedia.jpg' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( oooo , 'crimen.jpg' ) )
 IIIII = xbmc . translatePath ( os . path . join ( oooo , 'drama.jpg' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( oooo , 'familiar.jpg' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( oooo , 'fantasia.jpg' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( oooo , 'historia.jpg' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( oooo , 'superheroes.jpg' ) )
 OOOO = xbmc . translatePath ( os . path . join ( oooo , 'misterio.jpg' ) )
 OOO00 = xbmc . translatePath ( os . path . join ( oooo , 'musical.jpg' ) )
 iiiiiIIii = xbmc . translatePath ( os . path . join ( oooo , 'romance.jpg' ) )
 O000OO0 = xbmc . translatePath ( os . path . join ( oooo , 'spain.jpg' ) )
 I11iii1Ii = xbmc . translatePath ( os . path . join ( oooo , 'suspense.jpg' ) )
 I1IIiiIiii = xbmc . translatePath ( os . path . join ( oooo , 'terror.jpg' ) )
 O000oo0O = xbmc . translatePath ( os . path . join ( oooo , 'thriller.jpg' ) )
 OOOOi11i1 = xbmc . translatePath ( os . path . join ( oooo , 'western.jpg' ) )
 IIIii1II1II = xbmc . translatePath ( os . path . join ( oooo , 'sagas_cine.jpg' ) )
 i1I1iI = xbmc . translatePath ( os . path . join ( oooo , '4k.jpg' ) )
 oo0OooOOo0 = xbmc . translatePath ( os . path . join ( oooo , 'torrent.jpg' ) )
 o0OO00oO = xbmc . translatePath ( os . path . join ( oooo , 'buscar-serie.jpg' ) )
 I11i1I1I = xbmc . translatePath ( os . path . join ( oooo , 'series-todas.jpg' ) )
 o00OO00OoO = xbmc . translatePath ( os . path . join ( oooo , 'emision.png' ) )
 OOOO0OOoO0O0 = xbmc . translatePath ( os . path . join ( oooo , 'mejores.jpg' ) )
 oO0Oo = xbmc . translatePath ( os . path . join ( oooo , 'favoritos.png' ) )
 if 8 - 8: iiI1i1 - OoO0O00 * Ooo0OO0oOO + II111iiii / I1i1I % i1111
 if 16 - 16: IiIiI11iIi + Oo0oO0oo0oO00 - Ooo0OO0oOO
 if 85 - 85: i11Ii11I1Ii1i + iiI1i1
Oo0OoO00oOO0o = xbmc . translatePath ( os . path . join ( oooo , 'peliculas.png' ) )
OOO00O = xbmc . translatePath ( os . path . join ( oooo , 'series.png' ) )
OOoOO0oo0ooO = xbmc . translatePath ( os . path . join ( oooo , 'ajustes.png' ) )
O0o0O00Oo0o0 = xbmc . translatePath ( os . path . join ( oooo , 'videoteca.png' ) )
O00O0oOO00O00 = xbmc . translatePath ( os . path . join ( oooo , 'favorites.png' ) )
i1 = xbmc . translatePath ( os . path . join ( oooo , 'resolver.png' ) )
Oo00 = xbmc . translatePath ( os . path . join ( oooo , 'test.png' ) )
i1i = xbmc . translatePath ( os . path . join ( oooo , 'video-tutoriales.png' ) )
iiI111I1iIiI = xbmc . translatePath ( os . path . join ( oooo , 'proxy.png' ) )
if 41 - 41: Oo0o . OoOoo0 + oo * ooO % Oo0o * Oo0o
iIIIIi1iiIi1 = oo000 . getSetting ( 'mostrar_cat' )
iii1i1iiiiIi = oo000 . getSetting ( 'videos' )
IiiiOO0OoO0o00 = oo000 . getSetting ( 'activar' )
ooOO0O0ooOooO = oo000 . getSetting ( 'favcopy' )
oOOOo00O00oOo = oo000 . getSetting ( 'anticopia' )
IIiIiII11i = oo000 . getSetting ( 'licencia_addon' )
iiIIIi = oo000 . getSetting ( 'notificar' )
ooo00OOOooO = oo000 . getSetting ( 'mostrar_bus' )
O00OOOoOoo0O = oo000 . getSetting ( 'restante' )
O000OOo00oo = oo000 . getSetting ( 'selecton' )
oo0OOo = oo000 . getSetting ( 'aviso' )
ooOOO00Ooo = oo000 . getSetting ( 'RealStream_Settings' )
IiIIIi1iIi = oo000 . getSetting ( 'Resolver_Settings' )
O00OOOoOoo0O = oo000 . getSetting ( 'restante' )
ooOOoooooo = oo000 . getSetting ( 'fav' )
II1I = oo000 . getSetting ( 'Fontcolor' )
O0i1II1Iiii1I11 = oo000 . getSetting ( 'MenuColor' )
IIII = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
iiIiI = 'bienvenida'
o00oooO0Oo = 'bienvenida'
copyright = oo000 . getSetting ( 'copyright' )
o0O0OOO0Ooo = 'cGx1Z2luLnZpZGVvLg==' . decode ( 'base64' ) + copyright
iiIiII1 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
OOO00O0O = oo000 . getSetting ( 'Forceupdate' )
if OOO00O0O == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
iii = 'LnR4dA==' . decode ( 'base64' )
if 90 - 90: ooO % iiI1i1 / Oo0oO0oo0oO00
IIi = 'aHR0cDovL2JpdC5seS8yU1FOSnlP' . decode ( 'base64' )
i1Iii1i1I = IIII + iiIiI + iii
OOoO00 = 'http://www.youtube.com'
IiI111111IIII = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
i1Ii = '.xsl.pt'
ii111iI1iIi1 = 'L21hc3Rlci8=' . decode ( 'base64' )
OOO = IiI111111IIII + i1Ii
oo0OOo0 = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*texto3=[\'"](.*?)[\'"]\s*'
I11IiI = 'tvg-logo=[\'"](.*?)[\'"]'
if 53 - 53: Iiii % Ooo0OO0oOO . oO0o0o0ooO0oO - OoO0O00 - oO0o0o0ooO0oO * Ooo0OO0oOO
ooO0oOOooOo0 = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)'
i1I1ii11i1Iii = '(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)'
I1IiiiiI = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
o0OIiII = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
ii1iII1II = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
Iii1I1I11iiI1 = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
I1I1i1I = '#(.+?),(.+)\s*(.+)'
ii1I = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
if 99 - 99: I11i1i11i1I / Oo0o / oO0o0o0ooO0oO % Ii
i11I1II1I11i = 'source src=[\'"](.*?)[\'"]\s*title=[\'"](.*?)[\'"]'
OooOoOO0 = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
iI1i11iII111 = '[\'"](.*?)[\'"]'
Iii1IIII11I = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
OOOoo0OO = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( 'base64' )
oO0o0 = OOOoo0OO + O0
iI111iI = '[\'"](.*?)[\'"]'
iI1Ii11iIiI1 = 'UmVhbHN0cmVhbQ==' . decode ( 'base64' )
OO0Oooo0oOO0O = 'video=[\'"](.*?)[\'"]'
o0oOOo0O0Ooo = '0110nhu' . replace ( '0110nhu' , 'nhu' )
I1ii11iIi11i = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( 'base64' ) + o0oOOo0O0Ooo
o00O0 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
oOO0O00Oo0O0o = '0110R0N' . replace ( '0110R0N' , 'R0N' )
ii1 = 'aHR0cDovL2JpdC5seS8yWEIx' . decode ( 'base64' ) + oOO0O00Oo0O0o
I1iIIiiIIi1i = '0110pEJ' . replace ( '0110pEJ' , 'pEJ' )
O0O0ooOOO = 'aHR0cDovL2JpdC5seS8yd1Nh' . decode ( 'base64' ) + I1iIIiiIIi1i
oOOo0O00o = 'ABBAOb5' . replace ( 'ABBAOb5' , 'Ob5' )
iIiIi11 = 'aHR0cDovL2JpdC5seS8yRVhV' . decode ( 'base64' ) + oOOo0O00o
OOOiiiiI = '0110jaw' . replace ( '0110jaw' , 'jaw' )
oooOo0OOOoo0 = 'aHR0cDovL2JpdC5seS8yd01M' . decode ( 'base64' ) + OOOiiiiI
OOoO = '01109DI' . replace ( '01109DI' , '9DI' )
OO0O000 = 'aHR0cDovL2JpdC5seS8ySXgz' . decode ( 'base64' ) + OOoO
iiIiI1i1 = '01103hs' . replace ( '01103hs' , '3hs' )
oO0O00oOOoooO = 'aHR0cDovL2JpdC5seS8zMW1U' . decode ( 'base64' ) + iiIiI1i1
IiIi11iI = '01107DW' . replace ( '01107DW' , '7DW' )
Oo0O00O000 = 'aHR0cDovL2JpdC5seS8yV1ln' . decode ( 'base64' ) + IiIi11iI
i11I1IiII1i1i = '0110mLl' . replace ( '0110mLl' , 'mLl' )
ooI1111i = 'aHR0cDovL2JpdC5seS8yS0cw' . decode ( 'base64' ) + i11I1IiII1i1i
iIIii = '01102Hj' . replace ( '01102Hj' , '2Hj' )
o00O0O = 'aHR0cDovL2JpdC5seS8yWEJo' . decode ( 'base64' ) + iIIii
ii1iii1i = '0110fXg' . replace ( '0110fXg' , 'fXg' )
Iii1I1111ii = 'aHR0cDovL2JpdC5seS8ySTVy' . decode ( 'base64' ) + ii1iii1i
ooOoO00 = '0110NMH' . replace ( '0110NMH' , 'NMH' )
Ii1IIiI1i = 'aHR0cDovL2JpdC5seS8yd0t6' . decode ( 'base64' ) + ooOoO00
o0O00Oo0 = '0110bwQ' . replace ( '0110bwQ' , 'bwQ' )
IiII111i1i11 = 'aHR0cDovL2JpdC5seS8yd01V' . decode ( 'base64' ) + o0O00Oo0
i111iIi1i1II1 = '0110xzG' . replace ( '0110xzG' , 'xzG' )
oooO = 'aHR0cDovL2JpdC5seS8yWHhz' . decode ( 'base64' ) + i111iIi1i1II1
i1I1i111Ii = '0110x64' . replace ( '0110x64' , 'x64' )
ooo = 'aHR0cDovL2JpdC5seS8yRVlF' . decode ( 'base64' ) + i1I1i111Ii
i1i1iI1iiiI = '0110vUE' . replace ( '0110vUE' , 'vUE' )
Ooo0oOooo0 = 'aHR0cDovL2JpdC5seS8yWmhW' . decode ( 'base64' ) + i1i1iI1iiiI
oOOOoo00 = '01107ZL' . replace ( '01107ZL' , '7ZL' )
iiIiIIIiiI = 'aHR0cDovL2JpdC5seS8yWm4w' . decode ( 'base64' ) + oOOOoo00
iiI1IIIi = '01106cf' . replace ( '01106cf' , '6cf' )
II11IiIi11 = 'aHR0cDovL2JpdC5seS8yRVlk' . decode ( 'base64' ) + iiI1IIIi
II = '0110Jtp' . replace ( '0110Jtp' , 'Jtp' )
OOO0O00O0OOOO = 'aHR0cDovL2JpdC5seS8yV3Nq' . decode ( 'base64' ) + II
I1iiii1I = '0110a5b' . replace ( '0110a5b' , 'a5b' )
OOo0 = 'aHR0cDovL2JpdC5seS8yV3dj' . decode ( 'base64' ) + I1iiii1I
oO00ooooO0o = '0110Q7u' . replace ( '0110Q7u' , 'Q7u' )
oo0o = 'aHR0cDovL2JpdC5seS8yV3NL' . decode ( 'base64' ) + oO00ooooO0o
o0oO0oooOoo = '0110rsq' . replace ( '0110rsq' , 'rsq' )
I1III1111iIi = 'aHR0cDovL2JpdC5seS8ySzhE' . decode ( 'base64' ) + o0oO0oooOoo
I1i111I = '0110DDR' . replace ( '0110DDR' , 'DDR' )
OooOo0oo0O0o00O = 'aHR0cDovL2JpdC5seS8ySzd5' . decode ( 'base64' ) + I1i111I
I1i11 = '0110feQ' . replace ( '0110feQ' , 'feQ' )
IiIi1I1 = 'aHR0cDovL2JpdC5seS8yS0cz' . decode ( 'base64' ) + I1i11
IiIIi1 = '0110MHY' . replace ( '0110MHY' , 'MHY' )
IIIIiii1IIii = 'aHR0cDovL2JpdC5seS8ySXVo' . decode ( 'base64' ) + IiIIi1
II1i11I = '0110xdb' . replace ( '0110xdb' , 'xdb' )
ii1I1IIii11 = 'aHR0cDovL2JpdC5seS8yWEJu' . decode ( 'base64' ) + II1i11I
O0o0oO = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( 'base64' )
o0O0OOO0Ooo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
IIIIiIiIi1 = '0110lxu' . replace ( '0110lxu' , 'lxu' )
I11iiiiI1i = 'aHR0cDovL2JpdC5seS8yV1Bj' . decode ( 'base64' ) + IIIIiIiIi1
iI1i11 = '0110pzp' . replace ( '0110pzp' , 'pzp' )
OoOOoooOO0O = 'aHR0cDovL2JpdC5seS8yVHpB' . decode ( 'base64' ) + iI1i11
ooo00Ooo = '01105yt' . replace ( '01105yt' , '5yt' )
Oo0o0O00 = 'aHR0cDovL2JpdC5seS8yTVpp' . decode ( 'base64' ) + ooo00Ooo
if 40 - 40: Ii11111i
I1i1i1 = '1001DTs' . replace ( '1001DTs' , 'DTs' )
OoO0O00O0oo0O = 'aHR0cDovL2JpdC5seS8ySzhP' . decode ( 'base64' ) + I1i1i1
I1IiI11 = '1001Hky' . replace ( '1001Hky' , 'Hky' )
iI1iiiiIii = 'aHR0cDovL2JpdC5seS8yTGVL' . decode ( 'base64' ) + I1IiI11
iIiIiIiI = '1001VFU' . replace ( '1001VFU' , 'VFU' )
i11 = 'aHR0cDovL2JpdC5seS8zMERx' . decode ( 'base64' ) + iIiIiIiI
if 98 - 98: Oo0o / Ii . oo + Oo0oO0oo0oO00
def iiIiii1iI1i ( ) :
 if 34 - 34: OoOoo0 * Ii . iiI1i1 * OoOoo0 / OoOoo0
 if 30 - 30: IiIiI11iIi + Oo0o / Oo0o % IiIiI11iIi . IiIiI11iIi
 try :
  if 55 - 55: OoOoo0 - i1IIi11111i + Ooo0OO0oOO + Iiii % I11i1i11i1I
  o0OOO = iIiiiI ( ii1 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for iiI11i1II in Iii1ii1II11i :
   try :
    if 51 - 51: ooO % Oo0o % ooO * oo - i1111 % Oo0o
    O0O0ooOOO = iiI11i1II
    if 65 - 65: OoOoo0
    o0OooOOOOOO = xbmc . Keyboard ( '' , 'Busqueda por titulo' )
    o0OooOOOOOO . doModal ( )
    if ( o0OooOOOOOO . isConfirmed ( ) ) :
     if 78 - 78: Ii - OoO0O00 . OoOoo0 + OoO0O00
     oOoOO = urllib . quote_plus ( o0OooOOOOOO . getText ( ) ) . replace ( '+' , ' ' )
     Ii1i1 = iIiiiI ( O0O0ooOOO )
     Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( Ii1i1 )
     if 65 - 65: OoOoo0 . Ii11111i / IiIiI11iIi . iiI1i1 * Oo0oO0oo0oO00
     for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
      if re . search ( oOoOO , iI1I ( Iii1iiIi1II . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
       if 14 - 14: ooO * i1111 + Iiii + oo + II111iiii
   except :
    pass
 except :
  pass
  if 77 - 77: ooO / Ii11111i
  if 46 - 46: ooO % OoO0O00 . Iiii % Iiii + II111iiii
  if 72 - 72: OoO0O00 * I11i1i11i1I % OoOoo0 / Oo0oO0oo0oO00
def I11i1II ( ) :
 if 72 - 72: OoO0O00 . iiI1i1 / Oo0o . Ooo0OO0oOO
 oo0OOo = oo000 . getSetting ( 'aviso' )
 if oo0OOo == 'true' :
  o0OOO = iIiiiI ( i1Iii1i1I )
  Iii1ii1II11i = re . compile ( oo0OOo0 ) . findall ( o0OOO )
  for ooo000o000 , O0o , O0OOoOOO0oO in Iii1ii1II11i :
   try :
    if 28 - 28: OoOoo0 + II111iiii / i1IIi11111i % i11Ii11I1Ii1i % Oo0o - oo
    if 54 - 54: iiI1i1 + Ooo0OO0oOO
    oOOO0oo0 = ooo000o000
    iIi1i1iIi1iI = O0o
    iiIi1iI1iIii = O0OOoOOO0oO
    if 68 - 68: i1111
    if 82 - 82: OoO0O00 + Oo0o . OoO0O00 % oO0o0o0ooO0oO / I11i1i11i1I . I11i1i11i1I
    IIioOoO00oo0O = "[B]" + oOOO0oo0 + "[/B]"
    IiiiI = "" + iIi1i1iIi1iI + ""
    O00OoOO0oo0 = "" + iiIi1iI1iIii + ""
    if 96 - 96: i11Ii11I1Ii1i . ooO - OoOoo0
    xbmcgui . Dialog ( ) . ok ( "Real Stream" , IIioOoO00oo0O , IiiiI , O00OoOO0oo0 )
    if 99 - 99: oO0o0o0ooO0oO . Oo0o - I11i1i11i1I % I11i1i11i1I * oo . Ooo0OO0oOO
   except :
    pass
    if 4 - 4: I11i1i11i1I
    if 51 - 51: Oo0oO0oo0oO00 - oo % IIii11I1 - Ooo0OO0oOO
 I1II = iIiiiI ( O0o0oO )
 Iii1ii1II11i = re . compile ( iI1i11iII111 ) . findall ( I1II )
 for Oo000ooOOO in Iii1ii1II11i :
  try :
   if 31 - 31: OoO0O00 % i1IIi11111i % OoOoo0 . I11i1i11i1I - i1IIi11111i
   import xbmc
   import xbmcaddon
   if 17 - 17: I11i1i11i1I
   __addon__ = xbmcaddon . Addon ( )
   __addonname__ = __addon__ . getAddonInfo ( 'name' )
   __icon__ = __addon__ . getAddonInfo ( 'icon' )
   if 27 - 27: II111iiii % Ooo0OO0oOO % i1IIi11111i . oo - Oo0o + i11Ii11I1Ii1i
   ii = oo000 . getAddonInfo ( 'version' )
   ooO0o = Oo000ooOOO
   if 51 - 51: oO0o0o0ooO0oO
   IIioOoO00oo0O = "[COLOR orange]Version instalada Actualmente: [COLOR gold] " + ii + " [/COLOR][/COLOR]" "[COLOR white]Disponible la version: [COLOR lime] " + Oo000ooOOO + "  [/COLOR][/COLOR]"
   ii11I1 = 5000
   if 75 - 75: Oo0oO0oo0oO00 / Ooo0OO0oOO % oo
   xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , IIioOoO00oo0O , ii11I1 , __icon__ ) )
   if 38 - 38: Ii11111i * OoOoo0 % oo * i11Ii11I1Ii1i
   if 29 - 29: IiIiI11iIi / iiI1i1 . Ii - i11Ii11I1Ii1i - i11Ii11I1Ii1i - I11i1i11i1I
   if ii < ooO0o :
    if 20 - 20: iiI1i1 % Oo0oO0oo0oO00 . Ii / oO0o0o0ooO0oO * II111iiii * i1111
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR orange]Ya esta disponible la nueva version[/COLOR][COLOR lime]" + Oo000ooOOO + "[/COLOR][COLOR orange]. Puedes instalarla desde el repositorio Realstream, sino se actualiza sola.[/COLOR]" )
  except :
   pass
 if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
  if 85 - 85: ooO . i11Ii11I1Ii1i / OoOoo0 . oo % I1i1I
  if 90 - 90: Oo0o % oo * OoO0O00 . Iiii
  if 8 - 8: OoOoo0 + Ooo0OO0oOO / Iiii / i1IIi11111i
def iI1I ( s ) :
 if 74 - 74: oo / iiI1i1
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 78 - 78: Ii11111i . Oo0oO0oo0oO00 + OoOoo0 - iiI1i1
def ii1O0 ( file ) :
 if 33 - 33: iiI1i1
 try :
  Ii1iII1iI1 = open ( file , 'r' )
  o0OOO = Ii1iII1iI1 . read ( )
  Ii1iII1iI1 . close ( )
  return o0OOO
 except :
  pass
  if 14 - 14: Iiii
def iIiiiI ( url ) :
 if 99 - 99: Iiii
 try :
  IIi1ii1Ii = urllib2 . Request ( url )
  IIi1ii1Ii . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  OoOoO = urllib2 . urlopen ( IIi1ii1Ii )
  o0ii1i = OoOoO . read ( )
  OoOoO . close ( )
  return o0ii1i
 except urllib2 . URLError , oOOoo :
  print 'We failed to open "%s".' % url
  if hasattr ( oOOoo , 'code' ) :
   print 'We failed with error code - %s.' % oOOoo . code
  if hasattr ( oOOoo , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , oOOoo . reason
   if 14 - 14: ooO * IIii11I1
def O0OOO0OOooo00 ( url ) :
 IIi1ii1Ii = urllib2 . Request ( url )
 IIi1ii1Ii . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 IIi1ii1Ii . add_header ( 'Referer' , '%s' % url )
 IIi1ii1Ii . add_header ( 'Connection' , 'keep-alive' )
 OoOoO = urllib2 . urlopen ( IIi1ii1Ii )
 o0ii1i = OoOoO . read ( )
 OoOoO . close ( )
 return o0ii1i
 if 6 - 6: I11i1i11i1I - OoOoo0 * i1111 . Iiii / oo * OoOoo0
 if 22 - 22: Oo0o % Iiii * IiIiI11iIi / i1111 % II111iiii * i1IIi11111i
def Oo00OoOo ( ) :
 if 24 - 24: II111iiii - I1i1I
 O0i1II1Iiii1I11 = oo000 . getSetting ( 'MenuColor' )
 if 21 - 21: i1IIi11111i
 if IiiiOO0OoO0o00 == 'true' :
  if 92 - 92: II111iiii / I1i1I - Iiii % OoOoo0 * I1i1I + Oo0o
  ii1Oo0000oOo ( '[COLOR %s]Peliculas[/COLOR] ' % O0i1II1Iiii1I11 , 'movieDB' , 116 , Oo0OoO00oOO0o , IiI1I1 )
  ii1Oo0000oOo ( '[COLOR %s]Series[/COLOR] ' % O0i1II1Iiii1I11 , 'movieDB' , 117 , OOO00O , IiI1I1 )
  if 31 - 31: i1IIi11111i . I1i1I * OoOoo0 + II111iiii * IIii11I1
  if 93 - 93: IiIiI11iIi / OoO0O00 * iiI1i1 % Ii11111i * oo * i1IIi11111i
 if ooOOO00Ooo == 'true' :
  ii1Oo0000oOo ( '[COLOR %s]Ajustes[/COLOR]' % O0i1II1Iiii1I11 , 'Settings' , 119 , OOoOO0oo0ooO , IiI1I1 )
  if 64 - 64: Ooo0OO0oOO + oo / OoO0O00 / Oo0o . OoOoo0 % oO0o0o0ooO0oO
  if 50 - 50: OoO0O00 - oO0o0o0ooO0oO + i1111
  if iIIIIi1iiIi1 == 'true' :
   o0iiiI1I1iIIIi1 ( )
   if 17 - 17: OoO0O00 . Ii11111i / i1IIi11111i % Ooo0OO0oOO % iiI1i1 / II111iiii
  if IiIIIi1iIi == 'true' :
   OOOIiiiii1iI ( )
   IIiooOooo0 ( )
   if 67 - 67: Ii
  if oOOOo00O00oOo == 'false' :
   if 55 - 55: IiIiI11iIi - Iiii * ooO + i11Ii11I1Ii1i * i11Ii11I1Ii1i * oo
   IIioOoO00oo0O = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   IiiiI = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Script.ResolveURL para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   O00OoOO0oo0 = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 91 - 91: I1i1I - i1111 % OoO0O00 - Ii11111i % OoOoo0
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , IIioOoO00oo0O , IiiiI , O00OoOO0oo0 )
   if 98 - 98: Oo0oO0oo0oO00 . Oo0oO0oo0oO00 * IIii11I1 * Ooo0OO0oOO * I1i1I
def oOooO0 ( ) :
 ii1Oo0000oOo ( '[COLOR orange]Buscador por id[/COLOR]' , OOoO00 , 127 , OooO0 , IiI1I1 )
 if 79 - 79: Oo0oO0oo0oO00 - OoO0O00 + I11i1i11i1I - I1i1I
def iI11 ( ) :
 if 93 - 93: Ooo0OO0oOO . Ii - Oo0o + i11Ii11I1Ii1i
 O0i1II1Iiii1I11 = oo000 . getSetting ( 'MenuColor' )
 ii1Oo0000oOo ( '[COLOR %s]The movie DB[/COLOR]' % O0i1II1Iiii1I11 , 'movieDB' , 99 , OooO0 , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Buscador por id[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 127 , OooO0 , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Video tutoriales[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 125 , i1i , IiI1I1 )
 if 61 - 61: Ooo0OO0oOO
 if 15 - 15: II111iiii % Ii * i1IIi11111i / I1i1I
 if 90 - 90: Iiii
 if 31 - 31: i1111 + oo
 if 87 - 87: OoOoo0
 if 45 - 45: Oo0oO0oo0oO00 / Ii11111i - Iiii / I11i1i11i1I % oO0o0o0ooO0oO
 ii1Oo0000oOo ( '[COLOR %s]Autorizar OPENLOAD[/COLOR]' % O0i1II1Iiii1I11 , 'movieDB' , 97 , ooOoo0O , IiI1I1 )
 if 83 - 83: Ii . OoO0O00 - oO0o0o0ooO0oO * II111iiii
 if 20 - 20: iiI1i1 * I1i1I + Ooo0OO0oOO % ooO % IIii11I1
 if 13 - 13: Oo0o
 Oo00OoOo ( )
 if 60 - 60: IiIiI11iIi * Ii
 if 17 - 17: i1111 % Oo0o / IiIiI11iIi . oO0o0o0ooO0oO * i1111 - Ooo0OO0oOO
 if 41 - 41: I11i1i11i1I
 if 77 - 77: I1i1I
 if 65 - 65: Ooo0OO0oOO . Ii % IIii11I1 * Oo0oO0oo0oO00
 if 38 - 38: i11Ii11I1Ii1i / Iiii % Oo0o
 if 11 - 11: Iiii - IIii11I1 + Ooo0OO0oOO - OoO0O00
 if 7 - 7: oO0o0o0ooO0oO - i1IIi11111i / Ooo0OO0oOO * I11i1i11i1I . Iiii * Iiii
 if 61 - 61: i1IIi11111i % OoOoo0 - Oo0oO0oo0oO00 / Oo0o
 if 4 - 4: Ii11111i - iiI1i1 % I11i1i11i1I - i1111 * ooO
 if 85 - 85: Ii11111i * OoO0O00 . Iiii / Ii11111i % Ii % oo
def I1iii ( ) :
 oO0o0O0Ooo0o = xbmcgui . Dialog ( )
 i1Ii11II = (
 IioO0oOOO0Ooo ,
 i1i1I ,
 )
 if 25 - 25: OoO0O00 + IiIiI11iIi + Iiii / Ooo0OO0oOO / i1IIi11111i
 o0O0Oo00Oo0o = oO0o0O0Ooo0o . select ( '[B][COLOR=yellow]Listado de Proxys Gratuitos:[/COLOR][/B]' , [
 '[COLOR=orange]                      Accede a la web[/COLOR]' ,

 '[B][COLOR=gold]                      Volver al Menu [/COLOR][/B]' , ] )
 if 74 - 74: Oo0o / II111iiii - Ooo0OO0oOO * ooO
 if o0O0Oo00Oo0o :
  if 5 - 5: i1111 - i1111 . Oo0o + i11Ii11I1Ii1i - i1111 . IIii11I1
  if o0O0Oo00Oo0o < 0 :
   return
  IiIi1i1ii = i1Ii11II [ o0O0Oo00Oo0o - 2 ]
  return IiIi1i1ii ( )
 else :
  IiIi1i1ii = i1Ii11II [ o0O0Oo00Oo0o ]
  return IiIi1i1ii ( )
 return
 if 11 - 11: Ooo0OO0oOO / ooO
def IiIi1 ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 34 - 34: i1111
OooO0ooo0o = IiIi1 ( )
if 47 - 47: Ii11111i
def IioO0oOOO0Ooo ( ) :
 if OooO0ooo0o == 'android' :
  ii1i1i1IiII = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://hidemyna.me/es/proxy-list/?country=ES&type=hs#list' ) )
  if 63 - 63: Iiii . Oo0oO0oo0oO00 / Ooo0OO0oOO * oO0o0o0ooO0oO + IIii11I1 % I11i1i11i1I
 else :
  ii1i1i1IiII = webbrowser . open ( 'https://hidemyna.me/es/proxy-list/?country=ES&type=hs#list' )
  if 12 - 12: I1i1I . Oo0oO0oo0oO00 . Iiii - Ii11111i % Oo0o
  if 36 - 36: i1111
def i1i1I ( ) :
 if 84 - 84: I1i1I . Oo0oO0oo0oO00 . Ooo0OO0oOO . i1IIi11111i / I11i1i11i1I % IiIiI11iIi
 iI11 ( )
 if 57 - 57: Ii % i1IIi11111i - i1111 . Ii / Oo0o % Iiii
 if 56 - 56: IIii11I1 . Iiii . oO0o0o0ooO0oO * i11Ii11I1Ii1i . OoOoo0 / oo
def IiI1I1iIiIIii ( ) :
 if xbmc . getCondVisibility ( 'System.HasAddon(script.favourites)' ) :
  try :
   xbmc . executebuiltin ( "RunScript(script.favourites)" )
  except :
   pass
def OOo00 ( ) :
 oo000 . openSettings ( )
 if 37 - 37: iiI1i1
 if 46 - 46: i11Ii11I1Ii1i - i1IIi11111i - I11i1i11i1I . iiI1i1
def IiI1iii11iIi1 ( ) :
 urlresolver . display_settings ( )
 if 40 - 40: i1IIi11111i % Oo0oO0oo0oO00 . I1i1I
def OOOIiiiii1iI ( ) :
 ii1Oo0000oOo ( '[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % O0i1II1Iiii1I11 , 'resolve' , 120 , i1 , IiI1I1 )
 if 84 - 84: i11Ii11I1Ii1i % OoOoo0 - i11Ii11I1Ii1i . ooO
def III1iI1iII1I ( ) :
 if 39 - 39: I11i1i11i1I * OoOoo0 / i11Ii11I1Ii1i * Oo0oO0oo0oO00 . i1IIi11111i % Ooo0OO0oOO
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 71 - 71: I1i1I % iiI1i1 - Ooo0OO0oOO - i1111 + i1111 * OoOoo0
def IIiooOooo0 ( ) :
 ii1Oo0000oOo ( '[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % O0i1II1Iiii1I11 , 'resolve' , 140 , i1 , IiI1I1 )
 if 51 - 51: OoO0O00 / i11Ii11I1Ii1i + i1111 - i1IIi11111i + Iiii
def o0iiiI1I1iIIIi1 ( ) :
 if 29 - 29: ooO % OoO0O00 . Ii11111i % Ii11111i % Ooo0OO0oOO / Iiii
 O0i1II1Iiii1I11 = oo000 . getSetting ( 'MenuColor' )
 ii1Oo0000oOo ( '[COLOR %s]Buscador[/COLOR]' % O0i1II1Iiii1I11 , 'search' , 111 , iiIiIIi , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Estrenos[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 3 , OO0o , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Todas[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 26 , Ooo , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]4K[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 141 , i1I1iI , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Novedades[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 2 , II11iiii1Ii , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Accion[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 5 , O0o0Oo , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Animacion[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 6 , Oo00OOOOO , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Artes Marciales[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 29 , oOOoo0Oo , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Aventuras[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 7 , O0O , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Belico[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 8 , O00o0OO , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Ciencia Ficcion[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 9 , I11i1 , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Cine Clasico[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 30 , iIi1ii1I1 , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Comedia[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 10 , o0 , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Crimen[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 11 , I11II1i , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Drama[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 12 , IIIII , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Familiar[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 13 , ooooooO0oo , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Fantasia[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 14 , IIiiiiiiIi1I1 , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Historia[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 15 , I1IIIii , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Misterio[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 16 , OOOO , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Musical[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 17 , OOO00 , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Romance[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 18 , iiiiiIIii , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Thriller[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 19 , O000oo0O , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Suspense[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 20 , I11iii1Ii , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Terror[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 21 , I1IIiiIiii , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Western[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 22 , OOOOi11i1 , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Spain[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 23 , O000OO0 , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Super heroes[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 24 , oOoOooOo0o0 , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Sagas[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 25 , IIIii1II1II , IiI1I1 )
 if 70 - 70: II111iiii % Iiii
def I11Ii11iI1 ( ) :
 if 39 - 39: Ii * II111iiii - IIii11I1 / oO0o0o0ooO0oO % I1i1I % i1IIi11111i
 ii1Oo0000oOo ( '[COLOR %s]Buscar Serie[/COLOR]' % O0i1II1Iiii1I11 , 'search' , 145 , o0OO00oO , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]En emision[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 150 , o00OO00OoO , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]15 Mejores[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 151 , OOOO0OOoO0O0 , IiI1I1 )
 ii1Oo0000oOo ( '[COLOR %s]Todas[/COLOR]' % O0i1II1Iiii1I11 , OOoO00 , 142 , I11i1I1I , IiI1I1 )
 if 65 - 65: IIii11I1 - OoOoo0 % Ii11111i / Ii11111i % Ii11111i
def oOoOoo0 ( ) :
 if 16 - 16: Ii
 if 6 - 6: i1111 - IiIiI11iIi + I11i1i11i1I + iiI1i1 / oo / ooO
 try :
  if 42 - 42: iiI1i1 . Ii / iiI1i1 + I11i1i11i1I
  O0o0O0OO00o = iIiiiI ( OoO0O00O0oo0O )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( O0o0O0OO00o )
  for iiI11i1II in Iii1ii1II11i :
   if 92 - 92: ooO + I1i1I / Oo0o % Oo0oO0oo0oO00 % oO0o0o0ooO0oO . Ii11111i
   try :
    if 52 - 52: OoOoo0 / II111iiii - i1111 . oO0o0o0ooO0oO % OoO0O00 + ooO
    OO00oOooo0O = iiI11i1II
    o0OooOOOOOO = xbmc . Keyboard ( '' , 'Buscar' )
    o0OooOOOOOO . doModal ( )
    if ( o0OooOOOOOO . isConfirmed ( ) ) :
     if 58 - 58: Oo0o / IIii11I1
     oOoOO = urllib . quote_plus ( o0OooOOOOOO . getText ( ) ) . replace ( '+' , ' ' )
     I1II = iIiiiI ( OO00oOooo0O )
     Iii1ii1II11i = re . compile ( I1IiiiiI ) . findall ( I1II )
     for OoO000 , Iii1iiIi1II , IiI1I1 , OO0O00oOo in Iii1ii1II11i :
      if re . search ( oOoOO , iI1I ( Iii1iiIi1II . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       ii1Oo0000oOo ( Iii1iiIi1II , OO0O00oOo , 143 , OoO000 , IiI1I1 )
       if 44 - 44: i1111
   except :
    pass
 except :
  pass
  if 54 - 54: I11i1i11i1I - i1IIi11111i - I1i1I . OoO0O00
  if 79 - 79: I11i1i11i1I . Oo0oO0oo0oO00
def IIiI1I1 ( ) :
 if 15 - 15: I11i1i11i1I * Oo0o % IiIiI11iIi * OoO0O00 - II111iiii
 try :
  if 60 - 60: Ii * I1i1I % Oo0oO0oo0oO00 + IIii11I1
  O0o0O0OO00o = iIiiiI ( i11 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( O0o0O0OO00o )
  for iiI11i1II in Iii1ii1II11i :
   if 52 - 52: iiI1i1
   try :
    if 84 - 84: I11i1i11i1I / oO0o0o0ooO0oO
    OO00oOooo0O = iiI11i1II
    if 86 - 86: i11Ii11I1Ii1i * Ooo0OO0oOO - oo . i11Ii11I1Ii1i % OoO0O00 / i1111
   except :
    pass
    if 11 - 11: Ii * IIii11I1 + IiIiI11iIi / IiIiI11iIi
  I1II = iIiiiI ( OO00oOooo0O )
  Iii1ii1II11i = re . compile ( I1IiiiiI ) . findall ( I1II )
  for OoO000 , Iii1iiIi1II , IiI1I1 , OO0O00oOo in Iii1ii1II11i :
   try :
    if 37 - 37: II111iiii + iiI1i1
    ii1Oo0000oOo ( Iii1iiIi1II , OO0O00oOo , 143 , OoO000 , IiI1I1 )
    if 23 - 23: Iiii + i1IIi11111i . i11Ii11I1Ii1i * Ii + IiIiI11iIi
   except :
    pass
 except :
  pass
  if 18 - 18: oO0o0o0ooO0oO * ooO . oO0o0o0ooO0oO / oo
def iiIII1II ( ) :
 if 100 - 100: Oo0o % I11i1i11i1I / i1IIi11111i
 try :
  if 30 - 30: Oo0o - i1111 - Iiii
  O0o0O0OO00o = iIiiiI ( iI1iiiiIii )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( O0o0O0OO00o )
  for iiI11i1II in Iii1ii1II11i :
   if 81 - 81: ooO . Ii11111i + i1111 * OoOoo0
   try :
    if 74 - 74: iiI1i1 + oo + Oo0o
    OO00oOooo0O = iiI11i1II
    if 5 - 5: Oo0o * i11Ii11I1Ii1i
   except :
    pass
    if 46 - 46: OoOoo0
  I1II = iIiiiI ( OO00oOooo0O )
  Iii1ii1II11i = re . compile ( I1IiiiiI ) . findall ( I1II )
  for OoO000 , Iii1iiIi1II , IiI1I1 , OO0O00oOo in Iii1ii1II11i :
   try :
    if 33 - 33: Iiii - Ooo0OO0oOO * Ii11111i - Oo0o - i1111
    ii1Oo0000oOo ( Iii1iiIi1II , OO0O00oOo , 143 , OoO000 , IiI1I1 )
    if 84 - 84: I1i1I + Oo0o - i11Ii11I1Ii1i * i11Ii11I1Ii1i
   except :
    pass
 except :
  pass
  if 61 - 61: Ii11111i . IIii11I1 . Ii11111i / Oo0o
def o00O ( ) :
 if 48 - 48: Iiii . II111iiii
 try :
  if 5 - 5: IIii11I1 . IiIiI11iIi . Ooo0OO0oOO . Ii11111i
  O0o0O0OO00o = iIiiiI ( OoO0O00O0oo0O )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( O0o0O0OO00o )
  for iiI11i1II in Iii1ii1II11i :
   if 96 - 96: II111iiii - i1111 % oo / Oo0oO0oo0oO00
   try :
    if 100 - 100: Iiii / I11i1i11i1I - Ii11111i % Ooo0OO0oOO - Ii % i11Ii11I1Ii1i
    OO00oOooo0O = iiI11i1II
    if 60 - 60: OoO0O00 + iiI1i1
   except :
    pass
    if 86 - 86: OoO0O00 + i11Ii11I1Ii1i . II111iiii - I11i1i11i1I
  I1II = iIiiiI ( OO00oOooo0O )
  Iii1ii1II11i = re . compile ( I1IiiiiI ) . findall ( I1II )
  for OoO000 , Iii1iiIi1II , IiI1I1 , OO0O00oOo in Iii1ii1II11i :
   try :
    if 51 - 51: i11Ii11I1Ii1i
    ii1Oo0000oOo ( Iii1iiIi1II , OO0O00oOo , 143 , OoO000 , IiI1I1 )
    if 14 - 14: oO0o0o0ooO0oO % IIii11I1 % Oo0o - II111iiii
   except :
    pass
 except :
  pass
  if 53 - 53: I11i1i11i1I % Oo0o
def O0ooOo0o0Oo ( name , url ) :
 if 71 - 71: OoO0O00 - i1111 . Ii % Ii11111i + i1111
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 26 - 26: Oo0o + i1111 / Oo0oO0oo0oO00 % i11Ii11I1Ii1i % IiIiI11iIi + Ooo0OO0oOO
 Ii1i1 = iIiiiI ( url )
 Iii1ii1II11i = re . compile ( ii1iII1II ) . findall ( Ii1i1 )
 for i11I1I1iiI , name , IiI1I1 , url in Iii1ii1II11i :
  try :
   if 34 - 34: i1IIi11111i % OoOoo0 . oo . OoO0O00
   if 93 - 93: iiI1i1 . II111iiii . Oo0o
   II1I = oo000 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % II1I + name + '[/COLOR]'
   O0O00OOo ( name , url , 144 , i11I1I1iiI , IiI1I1 )
   if 66 - 66: II111iiii / ooO - Ii11111i / iiI1i1 . II111iiii
   if 16 - 16: Oo0o % IiIiI11iIi + i1IIi11111i - oo . Iiii / I1i1I
  except :
   pass
   if 35 - 35: IIii11I1 / I1i1I / Ooo0OO0oOO - OoO0O00 + Ooo0OO0oOO . I1i1I
   if 81 - 81: Iiii * i1111 - IiIiI11iIi * I11i1i11i1I % i11Ii11I1Ii1i * i11Ii11I1Ii1i
   if 59 - 59: OoO0O00
def O0O00OOo ( name , url , mode , iconimage , fanart ) :
 if 7 - 7: i1111 * Ii / ooO * II111iiii
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 84 - 84: i1111 . Iiii
 II1i111 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage="
 i1iiiIii11 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 i1iiiIii11 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 i1iiiIii11 . setProperty ( 'fanart_image' , fanart )
 i1iiiIii11 . setProperty ( 'IsPlayable' , 'true' )
 OOoOOO000O0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1i111 , listitem = i1iiiIii11 )
 return OOoOOO000O0
 if 92 - 92: IiIiI11iIi / oo
 if 80 - 80: ooO - i1111 + Ii11111i
def O0ooOoO ( name , url ) :
 if 26 - 26: i11Ii11I1Ii1i / Oo0o - iiI1i1 + i1IIi11111i
 if 38 - 38: Ii11111i / IiIiI11iIi . oo / iiI1i1 / Oo0o + OoO0O00
 IIiIiII11i = oo000 . getSetting ( 'licencia_addon' )
 o0oOOo0O0Ooo = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 I1ii11iIi11i = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
 I1IiI = oo000 . getSetting ( 'key_ext' )
 o0OOO = iIiiiI ( I1ii11iIi11i )
 Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
 for IiII in Iii1ii1II11i :
  if 96 - 96: Iiii
  try :
   if 18 - 18: Iiii * i1IIi11111i - I11i1i11i1I
   if 31 - 31: Oo0o - oo % i11Ii11I1Ii1i % IIii11I1
   IIiIiII11i = oo000 . getSetting ( 'licencia_addon' )
   if 45 - 45: IiIiI11iIi + Ooo0OO0oOO * II111iiii
   if 13 - 13: Ii11111i * IIii11I1 - I11i1i11i1I / i1111 + i1IIi11111i + oO0o0o0ooO0oO
   if IIiIiII11i == IiII :
    if 39 - 39: OoO0O00 - Ii11111i
    if 81 - 81: IiIiI11iIi - oo * Ii11111i
    if 'https://team.com' in url :
     if 23 - 23: Ooo0OO0oOO / IIii11I1
     url = url . replace ( 'https://team.com' , 'https://verystream.com' )
     if 28 - 28: Oo0o * OoOoo0 - Oo0oO0oo0oO00
    if 'https://mybox.com' in url :
     if 19 - 19: i1IIi11111i
     url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
     if 67 - 67: oo % OoO0O00 / oO0o0o0ooO0oO . II111iiii - I11i1i11i1I + oo
     if 27 - 27: i1111
    if 'https://vidcloud.co/' in url :
     if 89 - 89: Ooo0OO0oOO / IIii11I1
     url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
     if 14 - 14: i1111 . Ii * OoOoo0 + Ooo0OO0oOO - OoOoo0 + i1111
    if 'https://gounlimited.to' in url :
     if 18 - 18: IIii11I1 - ooO - Ii - Ii
     url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
     if 54 - 54: Oo0o + Ii / Iiii . Ii * i11Ii11I1Ii1i
    if 'https://drive.com' in url :
     if 1 - 1: i11Ii11I1Ii1i * Oo0oO0oo0oO00 . iiI1i1 / Oo0o . IiIiI11iIi + Oo0o
     url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
     if 17 - 17: Oo0o + Oo0oO0oo0oO00 / I11i1i11i1I / Iiii * i1111
     if 29 - 29: Oo0oO0oo0oO00 % Ii11111i * IIii11I1 / Ooo0OO0oOO - IIii11I1
    import resolveurl
    if 19 - 19: II111iiii
    oo0 = urlresolver . HostedMediaFile ( url )
    if 73 - 73: i11Ii11I1Ii1i . Ii
    if not oo0 :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
     return False
     if 32 - 32: i11Ii11I1Ii1i * Ii % OoOoo0 * I11i1i11i1I . oo
    try :
     i11i1i1I1iI1 = xbmcgui . DialogProgress ( )
     i11i1i1I1iI1 . create ( 'Realstream:' , 'Iniciando ...' )
     i11i1i1I1iI1 . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
     xbmc . sleep ( 1000 )
     O0ooOo0 = oo0 . resolve ( )
     if not O0ooOo0 or not isinstance ( O0ooOo0 , basestring ) :
      try : oo00ooOoo = O0ooOo0 . msg
      except : oo00ooOoo = url
      raise Exception ( oo00ooOoo )
      if 28 - 28: I11i1i11i1I
    except Exception as oOOoo :
     try : oo00ooOoo = str ( oOOoo )
     except : oo00ooOoo = url
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,7000)" )
     if 1 - 1: I11i1i11i1I
    i11i1i1I1iI1 . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    i11i1i1I1iI1 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
    xbmc . sleep ( 500 )
    i11i1i1I1iI1 . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
    xbmc . sleep ( 500 )
    i11i1i1I1iI1 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de este capitulo!' )
    i11i1i1I1iI1 . close ( )
    iiIIIi = oo000 . getSetting ( 'notificar' )
    IiiiI1 = xbmcgui . ListItem ( path = O0ooOo0 )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiiiI1 )
    if 100 - 100: IIii11I1 . I11i1i11i1I % iiI1i1 . OoOoo0
    if 79 - 79: Oo0oO0oo0oO00 % i1111 / OoO0O00 + i11Ii11I1Ii1i * Oo0oO0oo0oO00
   else :
    if 30 - 30: Ii11111i / i1IIi11111i + Iiii / IiIiI11iIi * oo
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold]>El addon esta desactivado.[/COLOR]" )
    if 16 - 16: Oo0o / II111iiii
    if 64 - 64: II111iiii / I11i1i11i1I * iiI1i1
  except :
   pass
   if 73 - 73: Oo0o - i11Ii11I1Ii1i - IIii11I1 - Ii
   if 65 - 65: ooO
   if 7 - 7: oO0o0o0ooO0oO . i11Ii11I1Ii1i / IiIiI11iIi . i1111 * i1IIi11111i - Ooo0OO0oOO
   if 37 - 37: I1i1I . i11Ii11I1Ii1i / oo * Iiii
   if 7 - 7: Oo0oO0oo0oO00 * i1IIi11111i + Ooo0OO0oOO % II111iiii
   if 8 - 8: OoOoo0 * oo
def OOoOIiIIII ( ) :
 if 89 - 89: Oo0oO0oo0oO00 / Ii
 if 16 - 16: Oo0o + OoOoo0 / Oo0o / Oo0oO0oo0oO00 % IIii11I1 % IiIiI11iIi
 Ii1II11II1iii = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 Ii1II11II1iii . doModal ( )
 if not Ii1II11II1iii . isConfirmed ( ) :
  return None ;
 Iii1iiIi1II = Ii1II11II1iii . getText ( ) . strip ( )
 if 86 - 86: Iiii
 if 69 - 69: IiIiI11iIi - I1i1I
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 16 - 16: Oo0o
  ii1i1i1IiII = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + Iii1iiIi1II + '&language=es-ES' ) )
  if 14 - 14: iiI1i1 - oo % Oo0o
  if 92 - 92: I11i1i11i1I % Iiii / IiIiI11iIi % IiIiI11iIi * Ii
  return 'android'
  if 74 - 74: oo . Ii % Oo0oO0oo0oO00 % oO0o0o0ooO0oO
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 87 - 87: IIii11I1 - II111iiii
  ii1i1i1IiII = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + Iii1iiIi1II + '&language=es-ES' )
  if 78 - 78: II111iiii / OoO0O00 - ooO
  if 23 - 23: i1IIi11111i
  return 'windows'
  if 40 - 40: ooO - Ooo0OO0oOO / Oo0o
  if 14 - 14: IiIiI11iIi
def iI1 ( ) :
 if 14 - 14: IiIiI11iIi
 try :
  if 49 - 49: IIii11I1 / iiI1i1 % I11i1i11i1I . Ii
  o0OOO = iIiiiI ( ii1 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for iiI11i1II in Iii1ii1II11i :
   if 93 - 93: i1111
   try :
    if 43 - 43: IiIiI11iIi / Ii . OoOoo0
    all = iiI11i1II
    if 62 - 62: OoO0O00 + Iiii . Oo0o / oO0o0o0ooO0oO % oo . I1i1I
   except :
    pass
    if 93 - 93: II111iiii % OoO0O00 % II111iiii + ooO / ooO / Ooo0OO0oOO
  Ii1i1 = iIiiiI ( all )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( Ii1i1 )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    if 49 - 49: i1111 . IiIiI11iIi . II111iiii - Ooo0OO0oOO / I11i1i11i1I
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 62 - 62: i1111
   except :
    pass
 except :
  pass
  if 1 - 1: oO0o0o0ooO0oO / oO0o0o0ooO0oO - II111iiii
def OO0oIiII1iiI ( ) :
 if 34 - 34: Ii . IIii11I1 + iiI1i1
 try :
  if 98 - 98: IIii11I1 % oO0o0o0ooO0oO * II111iiii % IiIiI11iIi
  II11iiii1Ii = iIiiiI ( O0O0ooOOO )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( II11iiii1Ii )
  for iiI11i1II in Iii1ii1II11i :
   if 29 - 29: oO0o0o0ooO0oO
   try :
    if 66 - 66: Oo0o
    OO00oOooo0O = iiI11i1II
    if 97 - 97: iiI1i1 - Ii11111i / I1i1I * Ii
   except :
    pass
    if 55 - 55: ooO . Iiii
  I1II = iIiiiI ( OO00oOooo0O )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( I1II )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    if 87 - 87: ooO % OoO0O00
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 100 - 100: I1i1I . Ii * I1i1I - Ii . i1IIi11111i * I11i1i11i1I
   except :
    pass
 except :
  pass
  if 89 - 89: Oo0oO0oo0oO00 + oO0o0o0ooO0oO * I1i1I
def Ii1 ( ) :
 if 62 - 62: iiI1i1 - iiI1i1
 try :
  if 69 - 69: i11Ii11I1Ii1i % IIii11I1 - i1IIi11111i
  OO0o = iIiiiI ( iIiIi11 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( OO0o )
  for iiI11i1II in Iii1ii1II11i :
   if 38 - 38: OoO0O00 + II111iiii / II111iiii % Oo0oO0oo0oO00 / OoOoo0 % I11i1i11i1I
   try :
    I1IiIiIi1IiI1 = iiI11i1II
   except :
    pass
    if 60 - 60: I11i1i11i1I * i11Ii11I1Ii1i - II111iiii % OoOoo0
  o0OOO = iIiiiI ( I1IiIiIi1IiI1 )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( o0OOO )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 52 - 52: IiIiI11iIi % IIii11I1 - II111iiii
   except :
    pass
 except :
  pass
  if 30 - 30: Iiii / Oo0oO0oo0oO00 + IIii11I1
def I1I ( ) :
 if 73 - 73: I11i1i11i1I
 try :
  if 94 - 94: Oo0oO0oo0oO00 . Ii11111i + i1IIi11111i - i11Ii11I1Ii1i / Ooo0OO0oOO
  o0OOO = iIiiiI ( db2 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for iiI11i1II in Iii1ii1II11i :
   if 70 - 70: i1IIi11111i % OoO0O00 . Oo0o + Oo0o - ooO % I1i1I
   try :
    if 38 - 38: I1i1I % i1111 - Ii11111i
    oOo0OOoooO = iiI11i1II
    if 26 - 26: ooO * oO0o0o0ooO0oO . iiI1i1
   except :
    pass
    if 59 - 59: oo + iiI1i1 - ooO
    if 62 - 62: II111iiii % i1111 . oO0o0o0ooO0oO . i1111
  o0OOO = iIiiiI ( oOo0OOoooO )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( o0OOO )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 84 - 84: II111iiii * Oo0oO0oo0oO00
   except :
    pass
 except :
  pass
  if 18 - 18: i1111 - I11i1i11i1I - i11Ii11I1Ii1i / I1i1I - oo
def iiIIii ( ) :
 if 70 - 70: ooO - i1111
 try :
  if 62 - 62: i1IIi11111i
  O000oOo = iIiiiI ( OoOOoooOO0O )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( O000oOo )
  for iiI11i1II in Iii1ii1II11i :
   if 53 - 53: OoO0O00 + ooO - i11Ii11I1Ii1i - IIii11I1 / OoOoo0 % II111iiii
   try :
    if 3 - 3: Iiii . OoOoo0 % Ii + IiIiI11iIi
    oo0oo0 = iiI11i1II
    if 35 - 35: II111iiii - Ii / i1111 + I11i1i11i1I * IIii11I1
   except :
    pass
    if 49 - 49: ooO * I11i1i11i1I + i1IIi11111i + Iiii
    if 30 - 30: ooO / i1111 / oO0o0o0ooO0oO % OoOoo0 + Ooo0OO0oOO
  o0OOO = iIiiiI ( oo0oo0 )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( o0OOO )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 4 - 4: Iiii - Oo0o - oO0o0o0ooO0oO - i1IIi11111i % II111iiii / Oo0oO0oo0oO00
   except :
    pass
 except :
  pass
  if 50 - 50: OoOoo0 + iiI1i1
def i11IiIIi11I ( ) :
 if 78 - 78: oO0o0o0ooO0oO
 try :
  if 83 - 83: OoO0O00 % i11Ii11I1Ii1i % ooO % I1i1I . IiIiI11iIi % oo
  o0OOO = iIiiiI ( oooOo0OOOoo0 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for iiI11i1II in Iii1ii1II11i :
   if 47 - 47: ooO
   try :
    if 66 - 66: Ii - oO0o0o0ooO0oO
    iiIii = iiI11i1II
    if 28 - 28: IIii11I1
   except :
    pass
    if 52 - 52: Ii + OoO0O00
    if 71 - 71: oo / IIii11I1
  o0OOO = iIiiiI ( iiIii )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( o0OOO )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 34 - 34: i11Ii11I1Ii1i . OoO0O00 % oo
   except :
    pass
 except :
  pass
  if 43 - 43: IiIiI11iIi - Iiii
def O000O ( ) :
 if 98 - 98: OoO0O00 + I1i1I % i11Ii11I1Ii1i + i1IIi11111i % i11Ii11I1Ii1i
 try :
  if 24 - 24: IIii11I1 * I1i1I
  o0OOO = iIiiiI ( OO0O000 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for iiI11i1II in Iii1ii1II11i :
   if 40 - 40: I11i1i11i1I - i11Ii11I1Ii1i * i11Ii11I1Ii1i . i11Ii11I1Ii1i + Ii11111i
   try :
    if 77 - 77: OoO0O00 . I11i1i11i1I % IIii11I1 / I11i1i11i1I
    oOO0OO = iiI11i1II
    if 82 - 82: Oo0oO0oo0oO00 % ooO % i1111 / oo
   except :
    pass
    if 94 - 94: IiIiI11iIi + IiIiI11iIi + Ii11111i % OoOoo0
  o0OOO = iIiiiI ( oOO0OO )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( o0OOO )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 7 - 7: Iiii
   except :
    pass
 except :
  pass
  if 78 - 78: i1111 + Iiii . oO0o0o0ooO0oO
def Oo ( ) :
 if 15 - 15: IiIiI11iIi + i1111 / IiIiI11iIi / I1i1I
 try :
  if 31 - 31: OoOoo0 + oo + OoOoo0 . OoO0O00 + Oo0o / ooO
  o0OOO = iIiiiI ( oO0O00oOOoooO )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for iiI11i1II in Iii1ii1II11i :
   if 6 - 6: Oo0o % oO0o0o0ooO0oO * i1IIi11111i / Ii + Oo0o
   try :
    if 39 - 39: i11Ii11I1Ii1i - Oo0o / Iiii * Ii11111i
    Oooo0oOOO0 = iiI11i1II
    if 61 - 61: ooO / i11Ii11I1Ii1i - Oo0o
   except :
    pass
    if 19 - 19: Iiii - ooO / ooO + Oo0o
    if 98 - 98: OoO0O00 % i1111 + i1IIi11111i . OoOoo0
  o0OOO = iIiiiI ( Oooo0oOOO0 )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( o0OOO )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 99 - 99: oo + oo * i1IIi11111i + oo * IIii11I1
   except :
    pass
 except :
  pass
  if 80 - 80: Ii . I11i1i11i1I
def I1I11ii ( ) :
 if 93 - 93: IiIiI11iIi % i11Ii11I1Ii1i . oo / Iiii * IIii11I1
 try :
  if 29 - 29: ooO
  o0OOO = iIiiiI ( Oo0O00O000 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for iiI11i1II in Iii1ii1II11i :
   if 86 - 86: Ooo0OO0oOO . oO0o0o0ooO0oO
   try :
    if 2 - 2: Ii11111i
    o0o0O00 = iiI11i1II
    if 35 - 35: OoO0O00
   except :
    pass
    if 94 - 94: i11Ii11I1Ii1i
    if 100 - 100: Oo0oO0oo0oO00 / iiI1i1 - Ii % I11i1i11i1I - OoO0O00
  o0OOO = iIiiiI ( o0o0O00 )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( o0OOO )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 17 - 17: i1IIi11111i / ooO % Oo0o
   except :
    pass
 except :
  pass
  if 71 - 71: oO0o0o0ooO0oO . I1i1I . Oo0oO0oo0oO00
def Oo0O0O00Oo ( ) :
 if 10 - 10: I11i1i11i1I + i1IIi11111i % Ii11111i - Ii
 try :
  if 70 - 70: i1111 - Iiii
  o0OOO = iIiiiI ( ooI1111i )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for iiI11i1II in Iii1ii1II11i :
   if 2 - 2: OoO0O00
   try :
    if 45 - 45: Ii11111i / II111iiii
    I11I1i1iI = iiI11i1II
    if 90 - 90: oO0o0o0ooO0oO * Ooo0OO0oOO % I1i1I + IIii11I1
   except :
    pass
    if 93 - 93: I1i1I + I11i1i11i1I
    if 33 - 33: oo
  o0OOO = iIiiiI ( I11I1i1iI )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( o0OOO )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 78 - 78: oo / Ooo0OO0oOO * Oo0oO0oo0oO00
   except :
    pass
 except :
  pass
  if 50 - 50: Ii11111i - OoO0O00 + iiI1i1 % I1i1I - OoO0O00 % oo
def o0oO0Oo ( ) :
 if 71 - 71: ooO - i11Ii11I1Ii1i * Iiii + I11i1i11i1I % II111iiii - OoOoo0
 try :
  if 82 - 82: I1i1I - i1111 + Oo0oO0oo0oO00
  o0OOO = iIiiiI ( Oo0o0O00 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for iiI11i1II in Iii1ii1II11i :
   if 64 - 64: ooO . oo * I11i1i11i1I + Ii11111i - Oo0o . Ii11111i
   try :
    if 70 - 70: Oo0o - IIii11I1 . OoO0O00 % i1IIi11111i / i11Ii11I1Ii1i - oo
    o0O0oo0o = iiI11i1II
    if 12 - 12: i11Ii11I1Ii1i % oO0o0o0ooO0oO % IiIiI11iIi . II111iiii * OoO0O00
   except :
    pass
    if 66 - 66: II111iiii * OoO0O00 % Ii11111i
    if 5 - 5: i11Ii11I1Ii1i % Ii11111i
  o0OOO = iIiiiI ( o0O0oo0o )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( o0OOO )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 60 - 60: i11Ii11I1Ii1i . iiI1i1 % Oo0oO0oo0oO00 % OoOoo0 % i1111
   except :
    pass
 except :
  pass
  if 33 - 33: OoO0O00 - I11i1i11i1I * IiIiI11iIi % OoO0O00 + Oo0oO0oo0oO00 . i1111
  if 56 - 56: II111iiii * Iiii . IIii11I1
def ooooO0O ( ) :
 if 81 - 81: iiI1i1 % ooO - I1i1I + II111iiii - Ii11111i
 try :
  if 50 - 50: I11i1i11i1I - II111iiii + OoO0O00 / oo - I11i1i11i1I + ooO
  o0OOO = iIiiiI ( o00O0O )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for iiI11i1II in Iii1ii1II11i :
   if 22 - 22: Ooo0OO0oOO - I11i1i11i1I / OoOoo0 % Ii11111i + i1111
   try :
    if 5 - 5: Oo0oO0oo0oO00 / Iiii + II111iiii % i1IIi11111i
    oOo00Ooo0o0 = iiI11i1II
    if 33 - 33: i1IIi11111i
   except :
    pass
    if 87 - 87: i11Ii11I1Ii1i / oO0o0o0ooO0oO + OoO0O00
    if 93 - 93: OoO0O00 + IIii11I1 % OoOoo0
  o0OOO = iIiiiI ( oOo00Ooo0o0 )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( o0OOO )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 21 - 21: i1111
   except :
    pass
 except :
  pass
  if 6 - 6: oO0o0o0ooO0oO
  if 46 - 46: oO0o0o0ooO0oO + IIii11I1
def Oo00o0O0O ( ) :
 if 84 - 84: i1IIi11111i % iiI1i1
 try :
  if 33 - 33: IiIiI11iIi * IiIiI11iIi . OoOoo0 . II111iiii
  o0OOO = iIiiiI ( Iii1I1111ii )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for iiI11i1II in Iii1ii1II11i :
   if 48 - 48: ooO . I11i1i11i1I + i11Ii11I1Ii1i % IiIiI11iIi / II111iiii
   try :
    if 74 - 74: Ooo0OO0oOO . oo - Ii + oO0o0o0ooO0oO % II111iiii % i11Ii11I1Ii1i
    O0OOO0 = iiI11i1II
    if 8 - 8: II111iiii / Ooo0OO0oOO + ooO * I11i1i11i1I % oO0o0o0ooO0oO . i1IIi11111i
   except :
    pass
    if 6 - 6: oO0o0o0ooO0oO % Oo0o . Oo0o - IiIiI11iIi / i1IIi11111i . iiI1i1
    if 99 - 99: i11Ii11I1Ii1i . I1i1I
  o0OOO = iIiiiI ( O0OOO0 )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( o0OOO )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 59 - 59: i1IIi11111i / Oo0o / i1111 / oo / i11Ii11I1Ii1i + ooO
   except :
    pass
    if 13 - 13: ooO % IIii11I1 / I1i1I % I1i1I % oo
 except :
  pass
  if 90 - 90: oO0o0o0ooO0oO . OoOoo0 / OoO0O00
  if 28 - 28: oO0o0o0ooO0oO + IIii11I1 - OoOoo0 / OoO0O00 - Ii
def Ii1i1oOoO00 ( ) :
 if 45 - 45: I11i1i11i1I . Ii11111i
 try :
  if 27 - 27: I11i1i11i1I * Oo0o . i11Ii11I1Ii1i
  o0OOO = iIiiiI ( Ii1IIiI1i )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for iiI11i1II in Iii1ii1II11i :
   if 17 - 17: Ooo0OO0oOO % Iiii * i1111 % iiI1i1 . Ii . OoO0O00
   try :
    if 27 - 27: II111iiii - Ii
    iii1IIiI = iiI11i1II
    if 33 - 33: i1IIi11111i
   except :
    pass
    if 98 - 98: i11Ii11I1Ii1i % Ooo0OO0oOO
    if 95 - 95: OoO0O00 - I1i1I - i1111 + I1i1I % IiIiI11iIi . Ii
  o0OOO = iIiiiI ( iii1IIiI )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( o0OOO )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 41 - 41: oo + IIii11I1 . iiI1i1 - Ooo0OO0oOO * ooO . Oo0oO0oo0oO00
   except :
    pass
    if 68 - 68: ooO
 except :
  pass
  if 20 - 20: I1i1I - I1i1I
def iIIiI11i1I11 ( ) :
 if 29 - 29: Oo0oO0oo0oO00 * OoO0O00 * oo - i11Ii11I1Ii1i / oO0o0o0ooO0oO
 try :
  if 99 - 99: OoOoo0
  o0OOO = iIiiiI ( IiII111i1i11 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for iiI11i1II in Iii1ii1II11i :
   if 76 - 76: Oo0oO0oo0oO00
   try :
    if 92 - 92: i1IIi11111i - OoO0O00 % Ii11111i
    I1 = iiI11i1II
    if 84 - 84: i11Ii11I1Ii1i - II111iiii
   except :
    pass
    if 1 - 1: Iiii * i11Ii11I1Ii1i
  o0OOO = iIiiiI ( I1 )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( o0OOO )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 66 - 66: i11Ii11I1Ii1i + iiI1i1 % Ooo0OO0oOO . oo * IiIiI11iIi % IiIiI11iIi
   except :
    pass
 except :
  pass
  if 87 - 87: i1111 + ooO . Iiii - Ii11111i
  if 6 - 6: OoO0O00 * Ii11111i
def iIiI1I1ii1I1 ( ) :
 if 83 - 83: i1111 / oo % Iiii - ooO . Oo0o
 try :
  if 49 - 49: OoO0O00 * iiI1i1 . Ii11111i
  o0OOO = iIiiiI ( oooO )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for iiI11i1II in Iii1ii1II11i :
   if 90 - 90: ooO % IiIiI11iIi - OoO0O00 % i11Ii11I1Ii1i
   try :
    if 8 - 8: i11Ii11I1Ii1i * Oo0o / oO0o0o0ooO0oO % I11i1i11i1I - Ii
    oo0ooooo00o = iiI11i1II
    if 78 - 78: OoO0O00 . ooO % OoO0O00 . oo / i1111
   except :
    pass
    if 76 - 76: iiI1i1 * Ii11111i * oo + I1i1I * I1i1I
    if 35 - 35: ooO
  o0OOO = iIiiiI ( oo0ooooo00o )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( o0OOO )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 73 - 73: oo - IiIiI11iIi
   except :
    pass
 except :
  pass
  if 2 - 2: Ooo0OO0oOO / I1i1I
  if 54 - 54: iiI1i1 . i1IIi11111i - IiIiI11iIi + OoOoo0 + Oo0o / Oo0o
def i1ii1IiiiiIi1I ( ) :
 if 56 - 56: Ii11111i * oo
 try :
  if 85 - 85: Ii11111i % i11Ii11I1Ii1i * OoO0O00
  o0OOO = iIiiiI ( ooo )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for iiI11i1II in Iii1ii1II11i :
   if 44 - 44: OoO0O00 . IiIiI11iIi + I1i1I . OoOoo0
   try :
    if 7 - 7: IiIiI11iIi + OoO0O00 * i1IIi11111i * i1IIi11111i / Ooo0OO0oOO - I11i1i11i1I
    oOOOo0o = iiI11i1II
    if 26 - 26: OoO0O00 - oo . oo
   except :
    pass
  o0OOO = iIiiiI ( oOOOo0o )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( o0OOO )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 68 - 68: i1111 + IIii11I1 . oo . I11i1i11i1I % iiI1i1 % i1111
   except :
    pass
 except :
  pass
  if 50 - 50: oO0o0o0ooO0oO + ooO
def o0OoOOo ( ) :
 if 56 - 56: i1IIi11111i / OoO0O00 + i11Ii11I1Ii1i % i1111 . i1111 - IiIiI11iIi
 try :
  if 48 - 48: Oo0o - OoOoo0 + Oo0o - Ii * II111iiii . Iiii
  o0OOO = iIiiiI ( Ooo0oOooo0 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for iiI11i1II in Iii1ii1II11i :
   if 35 - 35: oO0o0o0ooO0oO . oo + Oo0o + i1111 + iiI1i1
   try :
    if 65 - 65: oo * Ii / Ii . i11Ii11I1Ii1i
    Oo0O0OOO0o0O = iiI11i1II
    if 51 - 51: IIii11I1 + Oo0oO0oo0oO00 + Iiii + Iiii % ooO
   except :
    pass
    if 29 - 29: OoOoo0
    if 41 - 41: oo % Iiii
  o0OOO = iIiiiI ( Oo0O0OOO0o0O )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( o0OOO )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 10 - 10: Iiii . iiI1i1 + I11i1i11i1I
   except :
    pass
 except :
  pass
  if 66 - 66: Oo0oO0oo0oO00 % ooO
  if 21 - 21: i11Ii11I1Ii1i - Ii11111i % II111iiii
def Oo00O0OO ( ) :
 if 77 - 77: IIii11I1 - Oo0o - OoO0O00
 try :
  if 16 - 16: Oo0oO0oo0oO00 / Iiii / iiI1i1 . Iiii + IIii11I1
  o0OOO = iIiiiI ( iiIiIIIiiI )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for iiI11i1II in Iii1ii1II11i :
   if 26 - 26: OoO0O00 + iiI1i1 / i11Ii11I1Ii1i % IiIiI11iIi
   try :
    if 44 - 44: Ii11111i . Ooo0OO0oOO . i1111 % Ii11111i
    Oo0oO00 = iiI11i1II
    if 41 - 41: oo - i1IIi11111i * OoO0O00
   except :
    pass
    if 12 - 12: ooO * I1i1I % Ooo0OO0oOO * iiI1i1 * OoO0O00
    if 81 - 81: Oo0o - i1IIi11111i
  o0OOO = iIiiiI ( Oo0oO00 )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( o0OOO )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 24 - 24: Ii11111i . Oo0oO0oo0oO00 * Ooo0OO0oOO
   except :
    pass
 except :
  pass
  if 59 - 59: I1i1I + Oo0oO0oo0oO00 / i1111
def OO00o0O0O000o ( ) :
 if 56 - 56: Oo0o * Iiii
 try :
  if 13 - 13: Oo0o * Oo0o * Ooo0OO0oOO * Iiii . iiI1i1 / oO0o0o0ooO0oO
  o0OOO = iIiiiI ( II11IiIi11 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for iiI11i1II in Iii1ii1II11i :
   if 92 - 92: I11i1i11i1I * II111iiii + Iiii * I1i1I
   try :
    if 48 - 48: i1IIi11111i * Iiii * Iiii
    OO00Oo = iiI11i1II
    if 6 - 6: I11i1i11i1I - Oo0oO0oo0oO00 . Ii - oo
   except :
    pass
    if 16 - 16: Iiii * Iiii % I11i1i11i1I % Ii
    if 48 - 48: i1111 / I11i1i11i1I % Oo0oO0oo0oO00 / oO0o0o0ooO0oO / I1i1I
  o0OOO = iIiiiI ( OO00Oo )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( o0OOO )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 89 - 89: I1i1I * IIii11I1
   except :
    pass
 except :
  pass
  if 63 - 63: Ii11111i * Ii11111i % Oo0oO0oo0oO00 + oo / I1i1I + OoO0O00
  if 72 - 72: i11Ii11I1Ii1i * OoO0O00 % i1IIi11111i
def IiIi1I1i1II ( ) :
 if 15 - 15: IIii11I1 / I1i1I
 try :
  if 37 - 37: II111iiii + Ii . i1111 % i1IIi11111i % i1IIi11111i
  o0OOO = iIiiiI ( OOO0O00O0OOOO )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for iiI11i1II in Iii1ii1II11i :
   if 26 - 26: oo
   try :
    if 34 - 34: OoOoo0 * I1i1I
    OooOoOO0OO = iiI11i1II
    if 27 - 27: oO0o0o0ooO0oO * Ii . OoO0O00 - OoO0O00
   except :
    pass
    if 5 - 5: oO0o0o0ooO0oO
    if 84 - 84: Ooo0OO0oOO * IIii11I1 * Ooo0OO0oOO % oO0o0o0ooO0oO / Ii
  o0OOO = iIiiiI ( OooOoOO0OO )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( o0OOO )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 100 - 100: oO0o0o0ooO0oO . I11i1i11i1I - OoO0O00 . II111iiii / Ooo0OO0oOO
   except :
    pass
 except :
  pass
  if 71 - 71: I1i1I * Oo0o . i1IIi11111i
  if 49 - 49: oO0o0o0ooO0oO * oo . oO0o0o0ooO0oO
def ii1II1II ( ) :
 if 42 - 42: I11i1i11i1I
 try :
  if 68 - 68: i1111 . Oo0o % OoOoo0 - Ii11111i * Iiii . i1111
  o0OOO = iIiiiI ( OOo0 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for iiI11i1II in Iii1ii1II11i :
   if 46 - 46: II111iiii - i1111 * Ii * i1IIi11111i % IiIiI11iIi * iiI1i1
   try :
    if 5 - 5: oo / OoOoo0 . Oo0o + Ii11111i
    O0ooOoOO0o0oO0 = iiI11i1II
    if 52 - 52: i11Ii11I1Ii1i * Oo0oO0oo0oO00 - I11i1i11i1I
   except :
    pass
    if 82 - 82: Oo0oO0oo0oO00 + Ii . iiI1i1 + i1111
    if 16 - 16: ooO - Oo0oO0oo0oO00 / I1i1I
  o0OOO = iIiiiI ( O0ooOoOO0o0oO0 )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( o0OOO )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 48 - 48: OoO0O00
   except :
    pass
 except :
  pass
  if 91 - 91: Ooo0OO0oOO - oo . OoO0O00 . oo + IiIiI11iIi - Ooo0OO0oOO
  if 26 - 26: ooO
def IiIi ( ) :
 if 88 - 88: i11Ii11I1Ii1i - i1111
 try :
  if 63 - 63: oO0o0o0ooO0oO * Ii11111i
  o0OOO = iIiiiI ( oo0o )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for iiI11i1II in Iii1ii1II11i :
   if 19 - 19: oO0o0o0ooO0oO - ooO . OoO0O00 . i11Ii11I1Ii1i / i1111
   try :
    if 87 - 87: i11Ii11I1Ii1i - OoOoo0 - i1111 + Oo0o % OoO0O00 / II111iiii
    i1iIIII1iiIIi = iiI11i1II
    if 17 - 17: i1IIi11111i
   except :
    pass
    if 97 - 97: IiIiI11iIi * IiIiI11iIi / Iiii
    if 6 - 6: IIii11I1
  o0OOO = iIiiiI ( i1iIIII1iiIIi )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( o0OOO )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 72 - 72: i1IIi11111i * IiIiI11iIi - i11Ii11I1Ii1i / IiIiI11iIi + i1111 - Iiii
   except :
    pass
 except :
  pass
  if 49 - 49: Oo0oO0oo0oO00 - oo / Oo0oO0oo0oO00 * i11Ii11I1Ii1i + I1i1I
  if 35 - 35: Ooo0OO0oOO . Ii / iiI1i1 / Ii * IIii11I1
def Oo0 ( ) :
 if 96 - 96: i1IIi11111i % I11i1i11i1I % IIii11I1 * i1IIi11111i / i1111
 try :
  if 13 - 13: OoO0O00 - Oo0oO0oo0oO00
  o0OOO = iIiiiI ( I1III1111iIi )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for iiI11i1II in Iii1ii1II11i :
   if 100 - 100: II111iiii / II111iiii
   try :
    if 89 - 89: Iiii . II111iiii * oo
    Iii = iiI11i1II
    if 35 - 35: oO0o0o0ooO0oO . Ii11111i / i1111
   except :
    pass
    if 52 - 52: I1i1I % i11Ii11I1Ii1i + OoO0O00 * IIii11I1 . I11i1i11i1I
  o0OOO = iIiiiI ( Iii )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( o0OOO )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 95 - 95: OoO0O00 . oO0o0o0ooO0oO - Ii11111i * Oo0oO0oo0oO00 / ooO
   except :
    pass
 except :
  pass
  if 74 - 74: IIii11I1
  if 34 - 34: Iiii
def ii1IIiI1IIi ( ) :
 if 76 - 76: Iiii / Oo0oO0oo0oO00 + i11Ii11I1Ii1i
 try :
  if 86 - 86: II111iiii + II111iiii . I1i1I % Ii . OoOoo0
  o0OOO = iIiiiI ( OooOo0oo0O0o00O )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for iiI11i1II in Iii1ii1II11i :
   if 17 - 17: I11i1i11i1I
   try :
    if 67 - 67: oo * i1IIi11111i - ooO - Ooo0OO0oOO
    Ii11iiI1 = iiI11i1II
    if 71 - 71: ooO / i1111 % i1111
   except :
    pass
    if 89 - 89: Ii11111i + II111iiii / i1IIi11111i + OoO0O00 % OoOoo0
    if 29 - 29: IiIiI11iIi
  o0OOO = iIiiiI ( Ii11iiI1 )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( o0OOO )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 53 - 53: II111iiii . IiIiI11iIi % I11i1i11i1I / OoOoo0 % OoO0O00
   except :
    pass
 except :
  pass
  if 6 - 6: Oo0o - i1111 . OoO0O00
def I111I1I ( ) :
 if 54 - 54: Ooo0OO0oOO + i1IIi11111i % i1IIi11111i % ooO
 try :
  if 25 - 25: Iiii - Oo0o
  o0OOO = iIiiiI ( IiIi1I1 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for iiI11i1II in Iii1ii1II11i :
   if 10 - 10: oo % oO0o0o0ooO0oO . Oo0oO0oo0oO00 + ooO + IiIiI11iIi
   try :
    if 52 - 52: i11Ii11I1Ii1i / Oo0oO0oo0oO00 + I1i1I
    Iii1i11iiI1 = iiI11i1II
    if 95 - 95: IIii11I1 * OoO0O00 + IiIiI11iIi
   except :
    pass
  o0OOO = iIiiiI ( Iii1i11iiI1 )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( o0OOO )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 5 - 5: Oo0o
   except :
    pass
 except :
  pass
  if 100 - 100: I11i1i11i1I + OoO0O00
def o0o0OoO0OOO0 ( ) :
 if 79 - 79: IIii11I1 % ooO % i11Ii11I1Ii1i
 try :
  if 45 - 45: Ii * i1111 % Oo0oO0oo0oO00
  o0OOO = iIiiiI ( IIIIiii1IIii )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for iiI11i1II in Iii1ii1II11i :
   if 24 - 24: OoOoo0 - i1IIi11111i * IIii11I1
   try :
    if 87 - 87: I11i1i11i1I - IiIiI11iIi % IiIiI11iIi . IIii11I1 / IiIiI11iIi
    II1i = iiI11i1II
    if 94 - 94: I11i1i11i1I . iiI1i1
   except :
    pass
  o0OOO = iIiiiI ( II1i )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( o0OOO )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 71 - 71: Iiii + Oo0oO0oo0oO00 - oO0o0o0ooO0oO . Oo0oO0oo0oO00 . oO0o0o0ooO0oO + Ii
   except :
    pass
 except :
  pass
  if 26 - 26: oo
def iiiIi ( ) :
 if 62 - 62: oo . Oo0o
 try :
  if 33 - 33: Oo0o / OoO0O00 % iiI1i1
  o0OOO = iIiiiI ( I11iiiiI1i )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for iiI11i1II in Iii1ii1II11i :
   if 76 - 76: I11i1i11i1I + OoO0O00 + i11Ii11I1Ii1i . Oo0oO0oo0oO00
   try :
    if 49 - 49: oO0o0o0ooO0oO / OoOoo0 / i1111
    IiIiIi1I11I = iiI11i1II
    if 43 - 43: II111iiii + Iiii + OoOoo0 / I1i1I . IiIiI11iIi + Iiii
   except :
    pass
  o0OOO = iIiiiI ( IiIiIi1I11I )
  Iii1ii1II11i = re . compile ( ooO0oOOooOo0 ) . findall ( o0OOO )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo , id , ii1II in Iii1ii1II11i :
   try :
    OooOoOo ( Iii1iiIi1II , OO0O00oOo , IiIiII1 , id , ii1II )
    if 39 - 39: IiIiI11iIi - II111iiii - i1IIi11111i
   except :
    pass
 except :
  pass
  if 57 - 57: OoO0O00 + OoO0O00
def oO0o0Oo ( ) :
 if 76 - 76: OoOoo0 / i11Ii11I1Ii1i + IiIiI11iIi
 try :
  if 2 - 2: II111iiii - I1i1I + Oo0oO0oo0oO00 % i1IIi11111i * I11i1i11i1I
  o0OOO = iIiiiI ( ii1I1IIii11 )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for iiI11i1II in Iii1ii1II11i :
   if 54 - 54: oo - Iiii . i1111 % Iiii + Iiii
   try :
    if 36 - 36: i1111 % II111iiii
    Iiii1Ii = iiI11i1II
    if 62 - 62: iiI1i1 % i11Ii11I1Ii1i
   except :
    pass
  o0OOO = iIiiiI ( Iiii1Ii )
  Iii1ii1II11i = re . compile ( I1I1i1I ) . findall ( o0OOO )
  for IiIiII1 , Iii1iiIi1II , OO0O00oOo in Iii1ii1II11i :
   try :
    i1ii1I1IIIII ( IiIiII1 , Iii1iiIi1II , OO0O00oOo )
    if 69 - 69: OoO0O00 . Ooo0OO0oOO . iiI1i1 - ooO
   except :
    pass
    if 79 - 79: OoOoo0 % i1111
 except :
  pass
  if 54 - 54: i11Ii11I1Ii1i - I1i1I
  if 65 - 65: I1i1I . OoOoo0 + i1111 / Oo0o + oO0o0o0ooO0oO % iiI1i1
  if 28 - 28: II111iiii + oo / IiIiI11iIi
def i1ii1I1IIIII ( thumb , name , url ) :
 if 3 - 3: Oo0oO0oo0oO00 * iiI1i1 . Ii . oo - i11Ii11I1Ii1i
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( I11IiI ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   ii1Oo0000oOo ( name , url , '' , OoO000 , IiI1I1 )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 81 - 81: Ii - OoO0O00 / Ii / oo
  if 'tvg-logo' in thumb :
   thumb = re . compile ( I11IiI ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 34 - 34: I11i1i11i1I * I11i1i11i1I - IiIiI11iIi - oo . II111iiii
   IioOo0O ( name , url , 4 , i11I1I1iiI , IiI1I1 )
   if 30 - 30: I11i1i11i1I . IiIiI11iIi / i1111
  else :
   if 2 - 2: oO0o0o0ooO0oO % Ii - I1i1I
   IioOo0O ( name , url , 4 , i11I1I1iiI , IiI1I1 )
   if 79 - 79: Ii11111i / IiIiI11iIi . oo
def OooOoOo ( name , url , thumb , id , trailer ) :
 if 79 - 79: IIii11I1 - Ooo0OO0oOO
 if 43 - 43: iiI1i1 + oo % Oo0oO0oo0oO00 / I11i1i11i1I * Ii
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 89 - 89: Ii . Oo0o + IiIiI11iIi . oo % ooO
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( I11IiI ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   ii1Oo0000oOo ( name , url , '' , OoO000 , IiI1I1 )
 else :
  II1I = oo000 . getSetting ( 'Fontcolor' )
  if 84 - 84: Ii11111i + I1i1I / Ii % i1111 % IiIiI11iIi * Ii
  name = '[COLOR %s]' % II1I + name + '[/COLOR]'
  if 58 - 58: Oo0oO0oo0oO00 - i11Ii11I1Ii1i . II111iiii % II111iiii / iiI1i1 / IIii11I1
  if 'tvg-logo' in thumb :
   thumb = re . compile ( I11IiI ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   O000OOo00oo = oo000 . getSetting ( 'selecton' )
   if O000OOo00oo == 'true' :
    if 24 - 24: Ii * iiI1i1 % OoOoo0 / oo + II111iiii
    iI1i ( name , url , 1 , thumb , thumb , id , trailer )
    if 3 - 3: oO0o0o0ooO0oO / i1IIi11111i
   else :
    if 34 - 34: II111iiii / I1i1I * i1111 . Oo0o
    iI1i ( name , url , 130 , thumb , thumb , id , trailer )
    if 79 - 79: I1i1I
  else :
   if 31 - 31: i1111 % I1i1I
   if O000OOo00oo == 'true' :
    if 98 - 98: oO0o0o0ooO0oO * OoO0O00 . I11i1i11i1I * Oo0o / IiIiI11iIi + OoOoo0
    iI1i ( name , url , 1 , thumb , thumb , id , trailer )
    if 25 - 25: IIii11I1
   else :
    if 19 - 19: Ii % I11i1i11i1I . oO0o0o0ooO0oO * OoOoo0
    iI1i ( name , url , 130 , thumb , thumb , id , trailer )
    if 89 - 89: i11Ii11I1Ii1i . i1111
    if 7 - 7: IIii11I1 % i11Ii11I1Ii1i - Ii + Oo0o
def OoO0Ooo ( name , trailer ) :
 if 21 - 21: Ii + IiIiI11iIi * Oo0o * OoO0O00 - Oo0oO0oo0oO00 . Oo0o
 if iiIIIi == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Realstream, Reproduciendo Trailer de: [COLOR green]" + name + "[/COLOR] ,5000)" )
  if 59 - 59: Oo0oO0oo0oO00 - Oo0oO0oo0oO00 + Iiii
  OO0O00oOo = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  iiII = OO0O00oOo
  II11iiii = xbmcgui . ListItem ( name , trailer , path = iiII )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II11iiii )
 else :
  OO0O00oOo = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  iiII = OO0O00oOo
  II11iiii = xbmcgui . ListItem ( name , trailer , path = iiII )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II11iiii )
  if 20 - 20: Iiii / i1111
  if 28 - 28: OoOoo0 * i1IIi11111i % II111iiii * Iiii / I11i1i11i1I
def iIII1iIi ( trailer ) :
 if 75 - 75: I11i1i11i1I - i1IIi11111i % i11Ii11I1Ii1i
 if 'https://www.youtube.com' in trailer :
  if 80 - 80: I11i1i11i1I / i1111
  try :
   if 21 - 21: Oo0o - OoO0O00 - I1i1I
   import resolveurl
   if 1 - 1: Ii * i1111 + I11i1i11i1I + Ii - II111iiii
   oo0 = urlresolver . HostedMediaFile ( OO0O00oOo )
   i11i1i1I1iI1 = xbmcgui . DialogProgress ( )
   i11i1i1I1iI1 . create ( 'Realstream:' , 'Conectando al servidor ... ' )
   i11i1i1I1iI1 . update ( 20 , 'Por favor, espere ...' )
   xbmc . sleep ( 500 )
   if 79 - 79: OoOoo0 . IIii11I1 / IIii11I1 - OoOoo0 * Oo0o / ooO
   if not oo0 :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    return False
    if 19 - 19: IiIiI11iIi
   try :
    if 46 - 46: OoO0O00 . II111iiii - i11Ii11I1Ii1i % oo / Ooo0OO0oOO * iiI1i1
    i11i1i1I1iI1 . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    O0ooOo0 = oo0 . resolve ( )
    if not O0ooOo0 or not isinstance ( O0ooOo0 , basestring ) :
     try : oo00ooOoo = O0ooOo0 . msg
     except : oo00ooOoo = O0ooOo0
     raise Exception ( oo00ooOoo )
   except Exception as oOOoo :
    try : oo00ooOoo = str ( oOOoo )
    except : oo00ooOoo = O0ooOo0
    i11i1i1I1iI1 . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
    i11i1i1I1iI1 . close ( )
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    if 66 - 66: oo
   i11i1i1I1iI1 . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
   xbmc . sleep ( 500 )
   i11i1i1I1iI1 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   i11i1i1I1iI1 . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
   xbmc . sleep ( 500 )
   i11i1i1I1iI1 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   i11i1i1I1iI1 . close ( )
   if 52 - 52: Oo0oO0oo0oO00 * Ii11111i
   IiiiI1 = xbmcgui . ListItem ( path = O0ooOo0 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiiiI1 )
   if 12 - 12: oo + oO0o0o0ooO0oO * iiI1i1 . Oo0oO0oo0oO00
  except :
   pass
   if 71 - 71: I1i1I - ooO - i1111
  else :
   if 28 - 28: OoO0O00
   OO0O00oOo = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
   iiII = OO0O00oOo
   II11iiii = xbmcgui . ListItem ( trailer , path = iiII )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II11iiii )
   return
   if 7 - 7: ooO % oO0o0o0ooO0oO * i11Ii11I1Ii1i
def O0O00 ( name , url ) :
 if 30 - 30: Ii11111i % oO0o0o0ooO0oO / i11Ii11I1Ii1i % I1i1I
 if '[Youtube]' in name :
  if 19 - 19: I1i1I + oO0o0o0ooO0oO / IIii11I1 / Ooo0OO0oOO
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  iiII = url
  II11iiii = xbmcgui . ListItem ( ii1II , path = iiII )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II11iiii )
  if 92 - 92: iiI1i1 % OoOoo0 + OoOoo0 - OoO0O00 . I11i1i11i1I
  if 33 - 33: ooO / oo + i1111
 else :
  if 75 - 75: oO0o0o0ooO0oO % II111iiii + OoO0O00
  import urlresolver
  from urlresolver import common
  if 92 - 92: i11Ii11I1Ii1i % oo
  oo0 = urlresolver . HostedMediaFile ( url )
  if 55 - 55: OoO0O00 * Iiii
  if not oo0 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 85 - 85: OoO0O00 . Ooo0OO0oOO
   if 54 - 54: I11i1i11i1I . Ii11111i % Oo0o
  try :
   O0ooOo0 = oo0 . resolve ( )
   if not O0ooOo0 or not isinstance ( O0ooOo0 , basestring ) :
    try : oo00ooOoo = O0ooOo0 . msg
    except : oo00ooOoo = url
    raise Exception ( oo00ooOoo )
  except Exception as oOOoo :
   try : oo00ooOoo = str ( oOOoo )
   except : oo00ooOoo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 22 - 22: i1111
  iiIIIi = oo000 . getSetting ( 'notificar' )
  if iiIIIi == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  IiiiI1 = xbmcgui . ListItem ( path = O0ooOo0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiiiI1 )
  if 22 - 22: Iiii * i1IIi11111i - Oo0o * oo / II111iiii
  if 78 - 78: Oo0o * oo / OoOoo0 + Ii11111i + i1111
 return
 if 23 - 23: Iiii % Ii11111i / OoO0O00 + IiIiI11iIi / iiI1i1 / ooO
def oOoO ( name , url ) :
 if 32 - 32: oo + IIii11I1 % Oo0o
 import resolveurl
 if 7 - 7: IiIiI11iIi / OoOoo0
 oo0 = urlresolver . HostedMediaFile ( url )
 dp = xbmcgui . DialogProgress ( )
 dp . create ( 'Realstream:' , 'Conectando al servidor ... ' )
 dp . update ( 20 , 'Por favor, espere ...' )
 xbmc . sleep ( 500 )
 if 11 - 11: oO0o0o0ooO0oO * OoOoo0 / OoOoo0 - i1111
 if not oo0 :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  return False
  if 68 - 68: Ii % oO0o0o0ooO0oO - oO0o0o0ooO0oO / Ii + IiIiI11iIi - Oo0o
 try :
  if 65 - 65: OoOoo0 - iiI1i1
  dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
  xbmc . sleep ( 500 )
  O0ooOo0 = oo0 . resolve ( )
  if not O0ooOo0 or not isinstance ( O0ooOo0 , basestring ) :
   try : oo00ooOoo = O0ooOo0 . msg
   except : oo00ooOoo = O0ooOo0
   raise Exception ( oo00ooOoo )
 except Exception as oOOoo :
  try : oo00ooOoo = str ( oOOoo )
  except : oo00ooOoo = O0ooOo0
  dp . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
  dp . close ( )
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  if 62 - 62: i1IIi11111i / IIii11I1 % Oo0o . Ii11111i / II111iiii / I1i1I
 dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
 xbmc . sleep ( 500 )
 dp . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
 xbmc . sleep ( 500 )
 dp . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
 xbmc . sleep ( 500 )
 dp . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
 dp . close ( )
 iiIIIi = oo000 . getSetting ( 'notificar' )
 if 60 - 60: Ii % IIii11I1 / ooO % IIii11I1 * II111iiii / Iiii
 if 34 - 34: I1i1I - i1111
 if '[Realstream]' or '[Mybox]' in name :
  restante = oo000 . getSetting ( 'restante' )
 elif restante == 'true' :
  dialog = xbmcgui . Dialog ( )
  ok = dialog . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
 IiiiI1 = xbmcgui . ListItem ( path = O0ooOo0 )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiiiI1 )
 if 25 - 25: IIii11I1 % Ii + II111iiii + oo * Ii11111i
def oOoO ( name , url ) :
 if 64 - 64: iiI1i1
 if 10 - 10: I1i1I % oo / Ii % i1IIi11111i
 if 'https://www.rapidvideo.com/v/' in url :
  if 25 - 25: Ooo0OO0oOO / Oo0oO0oo0oO00
  o0OOO = iIiiiI ( url )
  Iii1ii1II11i = re . compile ( 'rapidvideo' ) . findall ( o0OOO )
  for url in Iii1ii1II11i :
   if 64 - 64: oo % OoOoo0
   if 40 - 40: ooO + i1IIi11111i
   try :
    iiIIIi = oo000 . getSetting ( 'notificar' )
    if iiIIIi == 'true' :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    IiiiI1 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiiiI1 )
    if 77 - 77: II111iiii % oO0o0o0ooO0oO + I1i1I % Ii11111i - i1IIi11111i
   except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 26 - 26: Oo0o + oo - OoO0O00
   if 47 - 47: Ii11111i
 else :
  if 2 - 2: i11Ii11I1Ii1i % I1i1I * Oo0o * i11Ii11I1Ii1i
  import urlresolver
  from urlresolver import common
  if 65 - 65: II111iiii + Oo0o * Ii11111i - Oo0oO0oo0oO00
  oo0 = urlresolver . HostedMediaFile ( url )
  if 26 - 26: ooO % i1111 + i1111 % i1IIi11111i * II111iiii / Iiii
  if not oo0 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 64 - 64: IIii11I1 % i11Ii11I1Ii1i / Ooo0OO0oOO % OoOoo0 - Iiii
   if 2 - 2: I1i1I - IiIiI11iIi + ooO * Oo0oO0oo0oO00 / Iiii
  try :
   O0ooOo0 = oo0 . resolve ( )
   if not O0ooOo0 or not isinstance ( O0ooOo0 , basestring ) :
    try : oo00ooOoo = O0ooOo0 . msg
    except : oo00ooOoo = url
    raise Exception ( oo00ooOoo )
  except Exception as oOOoo :
   try : oo00ooOoo = str ( oOOoo )
   except : oo00ooOoo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 26 - 26: i1111 * Oo0o
  iiIIIi = oo000 . getSetting ( 'notificar' )
  if iiIIIi == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  IiiiI1 = xbmcgui . ListItem ( path = O0ooOo0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiiiI1 )
  if 31 - 31: i1IIi11111i * IIii11I1 . I11i1i11i1I
 return
 if 35 - 35: i1IIi11111i
 if 94 - 94: OoOoo0 / II111iiii % oo
 if 70 - 70: i1IIi11111i - Oo0o / Ii11111i % Ii11111i
def oooo0o0OOO0 ( name , url ) :
 if 17 - 17: Ooo0OO0oOO + Ii
 O0ooOo0 = url
 iiIIIi = oo000 . getSetting ( 'notificar' )
 if iiIIIi == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  IiiiI1 = xbmcgui . ListItem ( path = O0ooOo0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiiiI1 )
 else :
  IiiiI1 = xbmcgui . ListItem ( path = O0ooOo0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiiiI1 )
 return
 if 59 - 59: OoO0O00 % I11i1i11i1I . II111iiii
def OOo ( name , url ) :
 if 61 - 61: I1i1I % Ii + Oo0o + OoOoo0 * I1i1I % i1111
 if 38 - 38: Oo0o
 if '[Youtube]' in name :
  if 34 - 34: i11Ii11I1Ii1i
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 70 - 70: OoO0O00 * oO0o0o0ooO0oO - i1111 / Oo0o % IIii11I1
  try :
   iiIIIi = oo000 . getSetting ( 'notificar' )
   if iiIIIi == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    IiiiI1 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiiiI1 )
    if 66 - 66: Ii11111i + OoOoo0 * Iiii
    if 2 - 2: Iiii . Oo0oO0oo0oO00 / IIii11I1
    if 41 - 41: Oo0oO0oo0oO00 . I1i1I * oO0o0o0ooO0oO * I1i1I
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 74 - 74: OoO0O00 / ooO
  if 58 - 58: OoO0O00 - Ii % ooO % Ii11111i * OoO0O00 + i1111
 else :
  if 25 - 25: i1111 % oo
  import xbmcgui
  import urlresolver
  from urlresolver import common
  if 44 - 44: I1i1I . I11i1i11i1I * Ooo0OO0oOO / oO0o0o0ooO0oO + OoO0O00
  oo0 = urlresolver . HostedMediaFile ( url )
  if 14 - 14: oo % oO0o0o0ooO0oO % I11i1i11i1I * IIii11I1
  if not oo0 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 65 - 65: i1IIi11111i % IIii11I1 + IiIiI11iIi
  import resolveurl as urlresolver
  if 86 - 86: OoO0O00 / oo . I1i1I % OoO0O00 % Oo0o
  oo0 = urlresolver . HostedMediaFile ( url )
  if 86 - 86: II111iiii - ooO . OoOoo0 * Oo0o / I11i1i11i1I % ooO
  if 61 - 61: ooO + i11Ii11I1Ii1i
  if not oo0 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 15 - 15: i11Ii11I1Ii1i * IIii11I1 + i1111 . i1IIi11111i % Ii - OoOoo0
  try :
   O0ooOo0 = oo0 . resolve ( )
   if not O0ooOo0 or not isinstance ( O0ooOo0 , basestring ) :
    try : oo00ooOoo = O0ooOo0 . msg
    except : oo00ooOoo = url
    raise Exception ( oo00ooOoo )
  except Exception as oOOoo :
   try : oo00ooOoo = str ( oOOoo )
   except : oo00ooOoo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 13 - 13: i11Ii11I1Ii1i % i11Ii11I1Ii1i % Oo0o % Ii * iiI1i1 % i1IIi11111i
   if 82 - 82: oO0o0o0ooO0oO . i11Ii11I1Ii1i / OoOoo0 + Iiii - OoOoo0
   if 55 - 55: OoOoo0 % Oo0o % ooO
  iiIIIi = oo000 . getSetting ( 'notificar' )
  if iiIIIi == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 29 - 29: oO0o0o0ooO0oO / OoO0O00 + IiIiI11iIi % Iiii % i1IIi11111i
   if '[Realstream]' in name :
    if 46 - 46: OoO0O00
    O00OOOoOoo0O = oo000 . getSetting ( 'restante' )
    if O00OOOoOoo0O == 'true' :
     oO0o0O0Ooo0o = xbmcgui . Dialog ( )
     OOoOOO000O0 = oO0o0O0Ooo0o . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 70 - 70: iiI1i1 . i1IIi11111i
   IiiiI1 = xbmcgui . ListItem ( path = O0ooOo0 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiiiI1 )
   if 74 - 74: i1IIi11111i
   if 58 - 58: OoO0O00 * Oo0oO0oo0oO00 * I1i1I * OoOoo0 . Ii11111i
   if 6 - 6: IiIiI11iIi - IIii11I1 * II111iiii + i11Ii11I1Ii1i / OoOoo0 % i1111
 return
 if 38 - 38: i1111 % oO0o0o0ooO0oO % Ooo0OO0oOO - Oo0o - OoO0O00
 if 9 - 9: ooO % IiIiI11iIi . IiIiI11iIi
 if 28 - 28: Ii11111i % IIii11I1 + IiIiI11iIi + oo . I1i1I
def ooOO0OOO00o ( name , url ) :
 if 76 - 76: Ii11111i * Ii11111i - Iiii - OoO0O00 . Ii11111i / IiIiI11iIi
 if 86 - 86: OoOoo0
 if '[Youtube]' in name :
  if 51 - 51: Oo0oO0oo0oO00 - II111iiii * Ii
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 95 - 95: i1111 % IiIiI11iIi + ooO % OoOoo0
  try :
   iiIIIi = oo000 . getSetting ( 'notificar' )
   if iiIIIi == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    IiiiI1 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiiiI1 )
    if 36 - 36: oo / iiI1i1 % Ooo0OO0oOO / Iiii
    if 96 - 96: Oo0o / IIii11I1 . Ooo0OO0oOO . Oo0o
    if 91 - 91: Ooo0OO0oOO . i1111 + ooO
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 8 - 8: i1111 * Oo0o / Iiii - Oo0oO0oo0oO00 - Ii11111i
 else :
  if 100 - 100: IIii11I1 . OoO0O00 . OoO0O00
  import resolveurl
  if 55 - 55: IIii11I1
  oo0 = urlresolver . HostedMediaFile ( url )
  if 37 - 37: oO0o0o0ooO0oO / II111iiii / Oo0o
  if 97 - 97: I1i1I . i1IIi11111i / Ii
  if not oo0 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 83 - 83: i1IIi11111i - IiIiI11iIi * IIii11I1
  try :
   O0ooOo0 = oo0 . resolve ( )
   if not O0ooOo0 or not isinstance ( O0ooOo0 , basestring ) :
    try : oo00ooOoo = O0ooOo0 . msg
    except : oo00ooOoo = url
    raise Exception ( oo00ooOoo )
  except Exception as oOOoo :
   try : oo00ooOoo = str ( oOOoo )
   except : oo00ooOoo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 90 - 90: Oo0o * Ii
   if 75 - 75: IiIiI11iIi - i11Ii11I1Ii1i * II111iiii . Ii11111i - Oo0o . i1IIi11111i
   if 6 - 6: i1IIi11111i * IIii11I1 / Ii11111i % I11i1i11i1I * ooO
  iiIIIi = oo000 . getSetting ( 'notificar' )
  if iiIIIi == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 28 - 28: oO0o0o0ooO0oO * Ii % oO0o0o0ooO0oO
   if '[Realstream]' in name :
    if 95 - 95: oo / i1IIi11111i . I1i1I
    O00OOOoOoo0O = oo000 . getSetting ( 'restante' )
    if O00OOOoOoo0O == 'true' :
     oO0o0O0Ooo0o = xbmcgui . Dialog ( )
     OOoOOO000O0 = oO0o0O0Ooo0o . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 17 - 17: i1IIi11111i
   IiiiI1 = xbmcgui . ListItem ( path = O0ooOo0 )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiiiI1 )
   if 56 - 56: OoOoo0 * ooO + i1IIi11111i
   if 48 - 48: oO0o0o0ooO0oO * Oo0oO0oo0oO00 % I1i1I - i1IIi11111i
   if 72 - 72: iiI1i1 % OoOoo0 % oO0o0o0ooO0oO % IIii11I1 - IIii11I1
 return
 if 97 - 97: ooO * oo / ooO * Oo0oO0oo0oO00 * Oo0o
def iiI1iiii1Iii ( name , url ) :
 if 94 - 94: II111iiii % IIii11I1 + Oo0o + IIii11I1
 if 33 - 33: oO0o0o0ooO0oO . Oo0o / OoO0O00
 if '[Youtube]' in name :
  if 50 - 50: ooO
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 16 - 16: i11Ii11I1Ii1i
  try :
   iiIIIi = oo000 . getSetting ( 'notificar' )
   if iiIIIi == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    IiiiI1 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiiiI1 )
    if 16 - 16: Oo0o / Oo0oO0oo0oO00 / Iiii / OoO0O00
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 44 - 44: Oo0o . Oo0o + Ii11111i * II111iiii / i1IIi11111i + I1i1I
 else :
  if 17 - 17: i1111 + Ooo0OO0oOO
  if 'https://team.com' in url :
   if 43 - 43: i1IIi11111i % I11i1i11i1I / ooO * I1i1I
   url = url . replace ( 'https://team.com' , 'https://verystream.com' )
   if 85 - 85: OoO0O00 . Ii11111i . ooO
  if 'https://mybox.com' in url :
   if 77 - 77: Ii % OoOoo0
   url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
   if 74 - 74: i11Ii11I1Ii1i / iiI1i1 % Ii11111i
  if 'https://drive.com' in url :
   if 52 - 52: oO0o0o0ooO0oO % OoOoo0
   url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
   if 25 - 25: i1IIi11111i / i1IIi11111i % Ii11111i - IiIiI11iIi * IIii11I1
  if 'https://vid.co' in url :
   if 23 - 23: II111iiii
   url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
   if 100 - 100: IIii11I1 + oo . Ii + iiI1i1 - i11Ii11I1Ii1i + ooO
  if 'https://limited.to' in url :
   if 65 - 65: Ooo0OO0oOO / Oo0o
   url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
   if 42 - 42: II111iiii . oo
  import resolveurl
  if 75 - 75: I1i1I + OoO0O00
  oo0 = urlresolver . HostedMediaFile ( url )
  if 19 - 19: Ii + II111iiii . oO0o0o0ooO0oO - i1IIi11111i / I11i1i11i1I + ooO
  if 38 - 38: Oo0o / OoO0O00 * OoO0O00 % IiIiI11iIi
  if not oo0 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no encontrado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 92 - 92: i1IIi11111i / oo * Ii - i1IIi11111i
  try :
   O0ooOo0 = oo0 . resolve ( )
   if not O0ooOo0 or not isinstance ( O0ooOo0 , basestring ) :
    try : oo00ooOoo = O0ooOo0 . msg
    except : oo00ooOoo = url
    raise Exception ( oo00ooOoo )
  except Exception as oOOoo :
   try : oo00ooOoo = str ( oOOoo )
   except : oo00ooOoo = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace borrado, o no encontrado. Prueba a reiniciar el router o poner una VPN.[/COLOR]  ,5000)" )
   return False
   if 99 - 99: II111iiii % Ii11111i
   if 56 - 56: oO0o0o0ooO0oO * I1i1I
   if 98 - 98: i1IIi11111i + oo * I1i1I + II111iiii - i1111 - OoO0O00
   iiIIIi = oo000 . getSetting ( 'notificar' )
   if iiIIIi == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
    if 5 - 5: i1111 % Oo0o % oO0o0o0ooO0oO % OoOoo0
    if '[Realstream]' or '[Mybox]' in name :
     O00OOOoOoo0O = oo000 . getSetting ( 'restante' )
    elif O00OOOoOoo0O == 'true' :
     oO0o0O0Ooo0o = xbmcgui . Dialog ( )
     OOoOOO000O0 = oO0o0O0Ooo0o . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 17 - 17: I11i1i11i1I + Ooo0OO0oOO + Ii11111i / i1111 / oO0o0o0ooO0oO
  IiiiI1 = xbmcgui . ListItem ( path = O0ooOo0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiiiI1 )
  if 80 - 80: ooO % iiI1i1 / i1IIi11111i
 return
 if 56 - 56: iiI1i1 . II111iiii
def Ii1Ii1IiIIIi1 ( name , url ) :
 if 55 - 55: IIii11I1 + oo / Iiii % OoOoo0 / Ii11111i
 if 98 - 98: I11i1i11i1I * OoO0O00 % Oo0o % i1111
 if '[Youtube]' in name :
  if 88 - 88: Iiii - Ooo0OO0oOO / Iiii - I11i1i11i1I
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 16 - 16: Oo0o % I1i1I
  try :
   iiIIIi = oo000 . getSetting ( 'notificar' )
   if iiIIIi == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    IiiiI1 = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiiiI1 )
    if 10 - 10: oO0o0o0ooO0oO / Ii11111i
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 50 - 50: II111iiii - Ii11111i . IIii11I1 + oo . iiI1i1
 else :
  if 91 - 91: ooO . Iiii % Oo0o - Iiii . IIii11I1 % II111iiii
  IIiIiII11i = oo000 . getSetting ( 'licencia_addon' )
  o0oOOo0O0Ooo = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  I1ii11iIi11i = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  I1IiI = oo000 . getSetting ( 'key_ext' )
  o0OOO = iIiiiI ( I1ii11iIi11i )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for IiII in Iii1ii1II11i :
   if 25 - 25: OoO0O00
   try :
    if 63 - 63: OoOoo0
    if 96 - 96: i1IIi11111i
    IIiIiII11i = oo000 . getSetting ( 'licencia_addon' )
    if 34 - 34: i11Ii11I1Ii1i / Oo0oO0oo0oO00 - Ii . oo . i1111
    if 63 - 63: Iiii
    if IIiIiII11i == IiII :
     if 11 - 11: Iiii - OoO0O00
     if 92 - 92: Oo0oO0oo0oO00
     if 'https://team.com' in url :
      if 15 - 15: oO0o0o0ooO0oO / oO0o0o0ooO0oO + OoO0O00 % Ii11111i
      url = url . replace ( 'https://team.com' , 'https://verystream.com' )
      if 12 - 12: OoOoo0
     if 'https://mybox.com' in url :
      if 36 - 36: I1i1I . oO0o0o0ooO0oO * Ii11111i - ooO
      url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
      if 60 - 60: i1111 . Iiii / OoO0O00 + i1111 * I1i1I
      if 82 - 82: II111iiii . OoO0O00 * Ii - i1IIi11111i + I11i1i11i1I
     if 'https://vidcloud.co/' in url :
      if 48 - 48: IiIiI11iIi
      url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
      if 96 - 96: OoOoo0 . Ii11111i
     if 'https://gounlimited.to' in url :
      if 39 - 39: i1111 + Oo0oO0oo0oO00
      url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
      if 80 - 80: i1111 % Oo0oO0oo0oO00 / i11Ii11I1Ii1i
     if 'https://drive.com' in url :
      if 54 - 54: Oo0o % Oo0oO0oo0oO00 - i1111 - i1IIi11111i
      url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
      if 71 - 71: OoOoo0 . II111iiii
      if 56 - 56: oo * Iiii + Iiii * OoO0O00 / OoOoo0 * I1i1I
     import resolveurl
     if 25 - 25: OoO0O00 . i1IIi11111i * II111iiii + Oo0o * i1IIi11111i
     oo0 = urlresolver . HostedMediaFile ( url )
     if 67 - 67: Iiii
     if not oo0 :
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
      return False
      if 88 - 88: Oo0o
     try :
      i11i1i1I1iI1 = xbmcgui . DialogProgress ( )
      i11i1i1I1iI1 . create ( 'Realstream:' , 'Iniciando ...' )
      i11i1i1I1iI1 . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
      xbmc . sleep ( 1000 )
      O0ooOo0 = oo0 . resolve ( )
      if not O0ooOo0 or not isinstance ( O0ooOo0 , basestring ) :
       try : oo00ooOoo = O0ooOo0 . msg
       except : oo00ooOoo = url
       raise Exception ( oo00ooOoo )
       if 8 - 8: IiIiI11iIi
     except Exception as oOOoo :
      try : oo00ooOoo = str ( oOOoo )
      except : oo00ooOoo = url
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,7000)" )
      if 82 - 82: Ii11111i
     i11i1i1I1iI1 . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
     xbmc . sleep ( 500 )
     i11i1i1I1iI1 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
     xbmc . sleep ( 500 )
     i11i1i1I1iI1 . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
     xbmc . sleep ( 500 )
     i11i1i1I1iI1 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de este capitulo!' )
     i11i1i1I1iI1 . close ( )
     iiIIIi = oo000 . getSetting ( 'notificar' )
     IiiiI1 = xbmcgui . ListItem ( path = O0ooOo0 )
     xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiiiI1 )
     if 75 - 75: Ooo0OO0oOO % Ii + i1111 % Ii11111i / oO0o0o0ooO0oO
     if 4 - 4: II111iiii - i1111 % IiIiI11iIi * I1i1I % ooO
    else :
     if 71 - 71: OoOoo0 . OoOoo0 - OoO0O00
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold]>El addon esta desactivado.[/COLOR]" )
     if 22 - 22: Ii11111i / IiIiI11iIi % Iiii * i11Ii11I1Ii1i
     if 32 - 32: Ii11111i % IIii11I1 % OoO0O00 / oo
   except :
    pass
    if 61 - 61: Ooo0OO0oOO . oo - I11i1i11i1I - IiIiI11iIi / II111iiii - Ooo0OO0oOO
 return
 if 98 - 98: I11i1i11i1I - Ii . II111iiii * Oo0o
def i111 ( ) :
 if 71 - 71: Oo0oO0oo0oO00
 if 75 - 75: Iiii
 II1iiI = [ ]
 o00O0o0O0O = sys . argv [ 2 ]
 if len ( o00O0o0O0O ) >= 2 :
  oOO0O00OoOo = sys . argv [ 2 ]
  I1i1I11 = oOO0O00OoOo . replace ( '?' , '' )
  if ( oOO0O00OoOo [ len ( oOO0O00OoOo ) - 1 ] == '/' ) :
   oOO0O00OoOo = oOO0O00OoOo [ 0 : len ( oOO0O00OoOo ) - 2 ]
  i1iiI = I1i1I11 . split ( '&' )
  II1iiI = { }
  for iiIi1IiiIi1 in range ( len ( i1iiI ) ) :
   IiI11I1Ii11II = { }
   IiI11I1Ii11II = i1iiI [ iiIi1IiiIi1 ] . split ( '=' )
   if ( len ( IiI11I1Ii11II ) ) == 2 :
    II1iiI [ IiI11I1Ii11II [ 0 ] ] = IiI11I1Ii11II [ 1 ]
 return II1iiI
 if 75 - 75: II111iiii % oO0o0o0ooO0oO
 if 30 - 30: Oo0o
def iiII1Ii ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  import urlresolver
  xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
  if 74 - 74: I11i1i11i1I * Ii / OoOoo0 / i1IIi11111i + Ooo0OO0oOO + II111iiii
def iiiII1III ( ) :
 oO0o0O0Ooo0o = xbmcgui . Dialog ( )
 list = (
 I1iIiiIi11I1i ,
 oO0oOOO0o0O0
 )
 if 39 - 39: I11i1i11i1I
 o0O0Oo00Oo0o = oO0o0O0Ooo0o . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=%s]Accede a themoviedb.com[/COLOR]' % O0i1II1Iiii1I11 ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 60 - 60: i1111
 if o0O0Oo00Oo0o :
  if 62 - 62: I1i1I * i1IIi11111i
  if o0O0Oo00Oo0o < 0 :
   return
  IiIi1i1ii = list [ o0O0Oo00Oo0o - 2 ]
  return IiIi1i1ii ( )
 else :
  IiIi1i1ii = list [ o0O0Oo00Oo0o ]
  return IiIi1i1ii ( )
 return
 if 74 - 74: i11Ii11I1Ii1i . OoO0O00
def IiIi1 ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 87 - 87: OoOoo0
OooO0ooo0o = IiIi1 ( )
if 41 - 41: i11Ii11I1Ii1i . OoO0O00 % OoOoo0 + oo
def I1iIiiIi11I1i ( ) :
 if OooO0ooo0o == 'android' :
  ii1i1i1IiII = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  ii1i1i1IiII = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 22 - 22: ooO + Oo0o . OoOoo0 + IiIiI11iIi * Iiii . II111iiii
  if 90 - 90: i1111 * i11Ii11I1Ii1i - Oo0o + ooO
def oO0oOOO0o0O0 ( ) :
 if 53 - 53: Ii11111i . Ii11111i + ooO - Iiii + i1111
 main ( )
 if 44 - 44: I1i1I - oO0o0o0ooO0oO
 if 100 - 100: IIii11I1 . Oo0oO0oo0oO00 - I11i1i11i1I + oo * Oo0oO0oo0oO00
 if 59 - 59: Ooo0OO0oOO
def iIiIi11I1iIii1i11 ( ) :
 oO0o0O0Ooo0o = xbmcgui . Dialog ( )
 i1Ii11II = (
 iIiiI11II11i ,
 o00OoO0o0
 )
 if 52 - 52: Iiii . IIii11I1 - I11i1i11i1I
 o0O0Oo00Oo0o = oO0o0O0Ooo0o . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 85 - 85: IiIiI11iIi / iiI1i1 * Oo0oO0oo0oO00 . IIii11I1
 if o0O0Oo00Oo0o :
  if 60 - 60: i1IIi11111i
  if o0O0Oo00Oo0o < 0 :
   return
  IiIi1i1ii = i1Ii11II [ o0O0Oo00Oo0o - 2 ]
  return IiIi1i1ii ( )
 else :
  IiIi1i1ii = i1Ii11II [ o0O0Oo00Oo0o ]
  return IiIi1i1ii ( )
 return
 if 93 - 93: Oo0o
def IiIi1 ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 75 - 75: i11Ii11I1Ii1i
OooO0ooo0o = IiIi1 ( )
if 64 - 64: oO0o0o0ooO0oO / ooO / iiI1i1
def iIiiI11II11i ( ) :
 if OooO0ooo0o == 'android' :
  ii1i1i1IiII = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  ii1i1i1IiII = webbrowser . open ( 'https://olpair.com/' )
  if 79 - 79: i1111 % I1i1I / IIii11I1 - OoO0O00 - i11Ii11I1Ii1i
  if 60 - 60: Ooo0OO0oOO
def o00OoO0o0 ( ) :
 if 90 - 90: i11Ii11I1Ii1i
 main ( )
 if 37 - 37: i11Ii11I1Ii1i + oo . oo * Oo0o % I1i1I / Iiii
 if 18 - 18: Ii11111i
def O0oOo00oooO ( name , url , id , trailer ) :
 oO0o0O0Ooo0o = xbmcgui . Dialog ( )
 i1Ii11II = (
 IiiIiI1IIi1IIIii ,
 OOO0o ,
 O0O00OO ,
 iiiII1III ,
 IIiiiI
 )
 if 59 - 59: IIii11I1 % OoOoo0
 o0O0Oo00Oo0o = oO0o0O0Ooo0o . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % O0i1II1Iiii1I11 ,

 '[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % O0i1II1Iiii1I11 ,

 '[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % O0i1II1Iiii1I11 ,

 '[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % O0i1II1Iiii1I11 ,

 '[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % O0i1II1Iiii1I11 ] )
 if 36 - 36: Ii11111i
 if o0O0Oo00Oo0o :
  if 33 - 33: oo + Oo0o - OoO0O00 % II111iiii / Ii
  if o0O0Oo00Oo0o < 0 :
   return
  IiIi1i1ii = i1Ii11II [ o0O0Oo00Oo0o - 5 ]
  return IiIi1i1ii ( )
 else :
  IiIi1i1ii = i1Ii11II [ o0O0Oo00Oo0o ]
  return IiIi1i1ii ( )
 return
 if 47 - 47: IiIiI11iIi * IIii11I1 + OoO0O00 - IIii11I1 / oO0o0o0ooO0oO
 if 86 - 86: oO0o0o0ooO0oO
 if 43 - 43: Ii / Iiii / OoOoo0 + OoO0O00 + Ii11111i
def IiiIiI1IIi1IIIii ( ) :
 if 33 - 33: Ooo0OO0oOO - oO0o0o0ooO0oO - OoOoo0
 Ii1Ii1IiIIIi1 ( Iii1iiIi1II , OO0O00oOo )
 if 92 - 92: Oo0oO0oo0oO00 * oO0o0o0ooO0oO
def OOO0o ( ) :
 if 92 - 92: IIii11I1
 OoO0Ooo ( Iii1iiIi1II , ii1II )
 if 7 - 7: Iiii
def O0O00OO ( ) :
 if 73 - 73: Oo0oO0oo0oO00 % IiIiI11iIi
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  I1I11i = id
  if 38 - 38: II111iiii . OoO0O00 . i1111 / Oo0oO0oo0oO00
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % I1I11i )
  if 18 - 18: Oo0o * I1i1I
 if iiIIIi == 'true' :
  if 99 - 99: Ooo0OO0oOO * OoO0O00 % oo * IIii11I1 / Ooo0OO0oOO % Ii11111i
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + Iii1iiIi1II + "[/COLOR] ,5000)" )
  if 14 - 14: oO0o0o0ooO0oO . oO0o0o0ooO0oO % OoOoo0
def iII ( ) :
 if 67 - 67: i1IIi11111i / Ooo0OO0oOO / oo / oO0o0o0ooO0oO - i1IIi11111i - iiI1i1
 iiiII1III ( )
 if 8 - 8: II111iiii . Iiii / OoO0O00 / IiIiI11iIi / oO0o0o0ooO0oO - I11i1i11i1I
def IIiiiI ( ) :
 if 32 - 32: ooO . iiI1i1 * Oo0o
 iI11 ( )
def ii1Oo0000oOo ( name , url , mode , iconimage , fanart ) :
 if 98 - 98: I11i1i11i1I - Ooo0OO0oOO / Ii . IIii11I1 * oO0o0o0ooO0oO . i1IIi11111i
 II1i111 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 OOoOOO000O0 = True
 i1iiiIii11 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1iiiIii11 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 i1iiiIii11 . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  II1i111 = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  OOoOOO000O0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1i111 , listitem = i1iiiIii11 , isFolder = True )
  return OOoOOO000O0
 OOoOOO000O0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1i111 , listitem = i1iiiIii11 , isFolder = True )
 return OOoOOO000O0
 if 25 - 25: II111iiii / i11Ii11I1Ii1i - I1i1I / Oo0oO0oo0oO00 . ooO . ooO
def iI1i ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 6 - 6: IIii11I1 . i1IIi11111i
 iiIiII1 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 43 - 43: IiIiI11iIi + ooO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 iI1iiiiiii = [ ]
 if 63 - 63: OoO0O00 + oO0o0o0ooO0oO % iiI1i1 / Ii % Ooo0OO0oOO
 iI1iiiiiii . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 II1i111 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 i1iiiIii11 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 i1iiiIii11 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 i1iiiIii11 . setProperty ( 'fanart_image' , fanart )
 i1iiiIii11 . setProperty ( 'IsPlayable' , 'true' )
 if 60 - 60: ooO . i11Ii11I1Ii1i % I1i1I / Ii / oo
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  iI1iiiiiii . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 19 - 19: II111iiii . Ii + Ooo0OO0oOO / i1111 . IiIiI11iIi * OoOoo0
  i1iiiIii11 . addContextMenuItems ( iI1iiiiiii , replaceItems = True )
 OOoOOO000O0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1i111 , listitem = i1iiiIii11 )
 return OOoOOO000O0
 if 59 - 59: OoO0O00 / IiIiI11iIi % OoOoo0
def IioOo0O ( name , url , mode , iconimage , fanart ) :
 if 84 - 84: OoO0O00 / Ii . i11Ii11I1Ii1i % i1IIi11111i
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 99 - 99: Oo0o + II111iiii
 II1i111 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 i1iiiIii11 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 i1iiiIii11 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 i1iiiIii11 . setProperty ( 'fanart_image' , fanart )
 i1iiiIii11 . setProperty ( 'IsPlayable' , 'true' )
 OOoOOO000O0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1i111 , listitem = i1iiiIii11 )
 return OOoOOO000O0
 if 36 - 36: I11i1i11i1I * I1i1I * OoO0O00 - i1IIi11111i % II111iiii
def OoOo00O0o ( name , url , mode ) :
 if 96 - 96: oO0o0o0ooO0oO * oO0o0o0ooO0oO % OoOoo0 + ooO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 27 - 27: Oo0o * OoOoo0 + II111iiii / Ii - IIii11I1
 II1i111 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 i1iiiIii11 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = i11I1I1iiI )
 i1iiiIii11 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 i1iiiIii11 . setProperty ( 'fanart_image' , IiI1I1 )
 i1iiiIii11 . setProperty ( 'IsPlayable' , 'true' )
 OOoOOO000O0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1i111 , listitem = i1iiiIii11 )
 return OOoOOO000O0
 if 44 - 44: I11i1i11i1I * OoOoo0 / i11Ii11I1Ii1i
def o0Oo0ooo ( name , url , mode , iconimage ) :
 II1i111 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 OOoOOO000O0 = True
 i1iiiIii11 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 OOoOOO000O0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1i111 , listitem = i1iiiIii11 , isFolder = True )
 return OOoOOO000O0
 if 60 - 60: Ii
def IiiI1iii1iIiiI ( ) :
 if 36 - 36: Oo0oO0oo0oO00 - oo * Ii / IiIiI11iIi / i1111
 if 33 - 33: Ii11111i % IiIiI11iIi . oo / IiIiI11iIi
 if 63 - 63: oO0o0o0ooO0oO + OoO0O00 + Ii + I1i1I
 o0OooOOOOOO = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 o0OooOOOOOO . doModal ( )
 if ( o0OooOOOOOO . isConfirmed ( ) ) :
  if 72 - 72: Oo0oO0oo0oO00 + II111iiii + IiIiI11iIi
  oOoOO = urllib . quote_plus ( o0OooOOOOOO . getText ( ) ) . replace ( '+' , ' ' )
  if 96 - 96: IIii11I1 % iiI1i1 / ooO
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 13 - 13: Ooo0OO0oOO - Oo0o % II111iiii + Iiii
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % oOoOO )
    if 88 - 88: oo . IIii11I1 % Ii
    if iiIIIi == 'true' :
     if 10 - 10: Ii + oo
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + Iii1iiIi1II + "[/COLOR] ,10000)" )
     if 75 - 75: oo % OoO0O00 / i11Ii11I1Ii1i % i1111 / oO0o0o0ooO0oO
   except :
    if 31 - 31: II111iiii * i11Ii11I1Ii1i
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 69 - 69: II111iiii
    if 61 - 61: oo
    if 21 - 21: Oo0oO0oo0oO00 % OoO0O00 . Oo0oO0oo0oO00
oOO0O00OoOo = i111 ( )
OO0O00oOo = None
Iii1iiIi1II = None
OO000OOOo0Oo = None
i11I1I1iiI = None
id = None
ii1II = None
if 75 - 75: Ooo0OO0oOO + OoOoo0 % i1111 + Oo0o
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 70 - 70: Oo0oO0oo0oO00
try :
 OO0O00oOo = urllib . unquote_plus ( oOO0O00OoOo [ "url" ] )
except :
 pass
try :
 Iii1iiIi1II = urllib . unquote_plus ( oOO0O00OoOo [ "name" ] )
except :
 pass
try :
 OO000OOOo0Oo = int ( oOO0O00OoOo [ "mode" ] )
except :
 pass
try :
 i11I1I1iiI = urllib . unquote_plus ( oOO0O00OoOo [ "iconimage" ] )
except :
 pass
try :
 id = int ( oOO0O00OoOo [ "id" ] )
except :
 pass
try :
 ii1II = urllib . unquote_plus ( oOO0O00OoOo [ "trailer" ] )
except :
 pass
 if 43 - 43: i11Ii11I1Ii1i
 if 57 - 57: Ii
print "Mode: " + str ( OO000OOOo0Oo )
print "URL: " + str ( OO0O00oOo )
print "Name: " + str ( Iii1iiIi1II )
print "iconimage: " + str ( i11I1I1iiI )
print "id: " + str ( id )
print "trailer: " + str ( ii1II )
if 65 - 65: II111iiii - OoOoo0 * i1IIi11111i + OoOoo0 / oO0o0o0ooO0oO + ooO
if OO000OOOo0Oo == None or OO0O00oOo == None or len ( OO0O00oOo ) < 1 :
 if o0O0OOO0Ooo == iiIiII1 :
  if 35 - 35: oo + Oo0o - Ii % I11i1i11i1I % Ooo0OO0oOO
  if 77 - 77: I1i1I + IIii11I1
  I11i1II ( )
  if 38 - 38: IiIiI11iIi - I11i1i11i1I * ooO
  if 13 - 13: Ii * IIii11I1
  IIiIiII11i = oo000 . getSetting ( 'licencia_addon' )
  o0oOOo0O0Ooo = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  I1ii11iIi11i = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  I1IiI = oo000 . getSetting ( 'key_ext' )
  o0OOO = iIiiiI ( I1ii11iIi11i )
  Iii1ii1II11i = re . compile ( iI111iI ) . findall ( o0OOO )
  for IiII in Iii1ii1II11i :
   try :
    if 41 - 41: oO0o0o0ooO0oO
    if 16 - 16: OoO0O00
    IIiIiII11i = oo000 . getSetting ( 'licencia_addon' )
    if 94 - 94: OoOoo0 % i1IIi11111i % iiI1i1
    if 90 - 90: I11i1i11i1I * Oo0oO0oo0oO00
    if IIiIiII11i == IiII :
     if 7 - 7: Iiii . I11i1i11i1I . Iiii - I1i1I
     if 33 - 33: OoOoo0 + Ii11111i - Oo0oO0oo0oO00 / iiI1i1 / Ii11111i
     if 82 - 82: IiIiI11iIi / i1111 - Iiii / Oo0o * Oo0oO0oo0oO00
     iI11 ( )
     if 55 - 55: Ii11111i
    else :
     if 73 - 73: i11Ii11I1Ii1i - IiIiI11iIi % Oo0o + IiIiI11iIi - oo . Oo0oO0oo0oO00
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold]>El addon esta desactivado.[/COLOR]" )
     if 38 - 38: oo
     if 79 - 79: iiI1i1 . IIii11I1
   except :
    pass
    if 34 - 34: I1i1I * Ooo0OO0oOO
 else :
  xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red][B]Error, de inicio. ¿Tienes Instalado Realstream?[/B][/COLOR]" )
  if 71 - 71: oO0o0o0ooO0oO
  if 97 - 97: IiIiI11iIi
  if 86 - 86: Oo0o - i1111 . i11Ii11I1Ii1i . Ooo0OO0oOO * Ii . Ooo0OO0oOO
elif OO000OOOo0Oo == 1 :
 O0oOo00oooO ( Iii1iiIi1II , OO0O00oOo , id , ii1II )
elif OO000OOOo0Oo == 2 :
 OO0oIiII1iiI ( )
elif OO000OOOo0Oo == 3 :
 Ii1 ( )
elif OO000OOOo0Oo == 4 :
 O0O00 ( Iii1iiIi1II , OO0O00oOo )
elif OO000OOOo0Oo == 5 :
 i11IiIIi11I ( )
elif OO000OOOo0Oo == 6 :
 O000O ( )
elif OO000OOOo0Oo == 7 :
 Oo ( )
elif OO000OOOo0Oo == 8 :
 I1I11ii ( )
elif OO000OOOo0Oo == 9 :
 Oo0O0O00Oo ( )
elif OO000OOOo0Oo == 10 :
 ooooO0O ( )
elif OO000OOOo0Oo == 11 :
 Oo00o0O0O ( )
elif OO000OOOo0Oo == 12 :
 Ii1i1oOoO00 ( )
elif OO000OOOo0Oo == 13 :
 iIIiI11i1I11 ( )
elif OO000OOOo0Oo == 14 :
 iIiI1I1ii1I1 ( )
elif OO000OOOo0Oo == 15 :
 i1ii1IiiiiIi1I ( )
elif OO000OOOo0Oo == 16 :
 o0OoOOo ( )
elif OO000OOOo0Oo == 17 :
 Oo00O0OO ( )
elif OO000OOOo0Oo == 18 :
 OO00o0O0O000o ( )
elif OO000OOOo0Oo == 19 :
 IiIi1I1i1II ( )
elif OO000OOOo0Oo == 20 :
 ii1II1II ( )
elif OO000OOOo0Oo == 21 :
 IiIi ( )
elif OO000OOOo0Oo == 22 :
 Oo0 ( )
elif OO000OOOo0Oo == 23 :
 ii1IIiI1IIi ( )
elif OO000OOOo0Oo == 24 :
 I111I1I ( )
elif OO000OOOo0Oo == 25 :
 o0o0OoO0OOO0 ( )
elif OO000OOOo0Oo == 26 :
 iI1 ( )
elif OO000OOOo0Oo == 28 :
 O0ooOoO ( Iii1iiIi1II , OO0O00oOo )
elif OO000OOOo0Oo == 29 :
 iiIIii ( )
elif OO000OOOo0Oo == 30 :
 o0oO0Oo ( )
elif OO000OOOo0Oo == 98 :
 busqueda_global ( )
elif OO000OOOo0Oo == 97 :
 iIiIi11I1iIii1i11 ( )
elif OO000OOOo0Oo == 99 :
 OOoOIiIIII ( )
elif OO000OOOo0Oo == 100 :
 menu_player ( Iii1iiIi1II , OO0O00oOo )
elif OO000OOOo0Oo == 111 :
 iiIiii1iI1i ( )
elif OO000OOOo0Oo == 115 :
 OoO0Ooo ( OO0O00oOo )
elif OO000OOOo0Oo == 116 :
 o0iiiI1I1iIIIi1 ( )
elif OO000OOOo0Oo == 117 :
 I11Ii11iI1 ( )
elif OO000OOOo0Oo == 119 :
 OOo00 ( )
elif OO000OOOo0Oo == 120 :
 IiI1iii11iIi1 ( )
elif OO000OOOo0Oo == 121 :
 IiI1I1iIiIIii ( )
elif OO000OOOo0Oo == 125 :
 oO0o0Oo ( )
elif OO000OOOo0Oo == 112 :
 I1iii ( )
elif OO000OOOo0Oo == 127 :
 IiiI1iii1iIiiI ( )
elif OO000OOOo0Oo == 128 :
 TESTLINKS ( )
elif OO000OOOo0Oo == 130 :
 Ii1Ii1IiIIIi1 ( Iii1iiIi1II , OO0O00oOo )
elif OO000OOOo0Oo == 140 :
 III1iI1iII1I ( )
elif OO000OOOo0Oo == 141 :
 iiiIi ( )
elif OO000OOOo0Oo == 142 :
 o00O ( )
elif OO000OOOo0Oo == 143 :
 O0ooOo0o0Oo ( Iii1iiIi1II , OO0O00oOo )
elif OO000OOOo0Oo == 144 :
 O0ooOoO ( Iii1iiIi1II , OO0O00oOo )
elif OO000OOOo0Oo == 145 :
 oOoOoo0 ( )
elif OO000OOOo0Oo == 150 :
 IIiI1I1 ( )
elif OO000OOOo0Oo == 151 :
 iiIII1II ( )
xbmcplugin . endOfDirectory ( oOOo ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
