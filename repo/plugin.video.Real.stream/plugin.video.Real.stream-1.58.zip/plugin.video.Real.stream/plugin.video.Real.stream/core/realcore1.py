# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 1.58
#
############################################
# Dependencias 
# Script ExtendedInfo
# Script ResolveURL Por Jsergio.
############################################
#
# Agregado multi enlace de servidores.
# Agregado sistema individual de usuarios.
# Agregadas categorias de peliculas.
#
############################################
if 64 - 64: i11iIiiIii
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import resolveurl
import cookielib , base64
import requests
import plugintools
import codecs
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
IiII1IiiIiI1 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
o0OoOoOO00 = int ( sys . argv [ 1 ] )
I11i = 'gruponetai/'
O0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
Oo = O0O . getAddonInfo ( 'profile' )
I1ii11iIi11i = O0O . getAddonInfo ( 'path' )
I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
if 73 - 73: OOooOOo / ii11ii1ii
if 94 - 94: OoOO + OoOO0ooOOoo0O + o0000oOoOoO0o * o00O0oo
if 97 - 97: oO0o0ooO0 - IIII / O0oO - o0oO0
if I1IiI == 'true' :
 if 100 - 100: i11Ii11I1Ii1i
 Ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.png' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 i1111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 i11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.png' ) )
 I11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.png' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'estrenos.png' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.png' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.png' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.png' ) )
 oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.png' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.png' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.png' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.png' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.png' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.png' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.png' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.png' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'marvel.png' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.png' ) )
 II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.png' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.png' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.png' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.png' ) )
 OO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.png' ) )
 OooO0o0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.png' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.png' ) )
 O0OO00o0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.png' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.png' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.png' ) )
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.png' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
 ooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.png' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 OOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 OOO00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
 iiiiiIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_series.png' ) )
 O000OO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_Episodios.png' ) )
 if 43 - 43: OoIii111II - iii11 . Ooo0OO0oOO - OoOO0ooOOoo0O
else :
 if 10 - 10: IIII / OOooOOo * IIII
 if 29 - 29: o00O0oo % OOooOOo + Ooo0OO0oOO / o0000oOoOoO0o + IIII * o0000oOoOoO0o
 ooooooO0oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'artesmarciales.png' ) )
 oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'seriesretro.png' ) )
 I1IiI = IiII1IiiIiI1 . getSetting ( 'iconos' )
 Ooo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fanart.jpg' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'icon.png' ) )
 i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'extended_info.png' ) )
 oOOoo00O0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar.png' ) )
 i1111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'pair.png' ) )
 i11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'theMovieDB.jpg' ) )
 I11 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'novedades.jpg' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'encines.jpg' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'recomendadas.jpg' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'accion.jpg' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'animacion.jpg' ) )
 oO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'aventuras.jpg' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'belico.jpg' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ciencia-ficcion.jpg' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'clasicos.png' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'comedia.jpg' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'crimen.jpg' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'drama.jpg' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'familiar.jpg' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'fantasia.jpg' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'historia.jpg' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'superheroes.jpg' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'misterio.jpg' ) )
 II = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'musical.jpg' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'romance.jpg' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'spain.jpg' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'suspense.jpg' ) )
 OO0o = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'terror.jpg' ) )
 OooO0o0Oo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'thriller.jpg' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'western.jpg' ) )
 O0OO00o0OO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'sagas_cine.jpg' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , '4k.jpg' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'torrent.jpg' ) )
 o0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'buscar-serie.png' ) )
 I11II1i = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series-todas.png' ) )
 IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'emision.png' ) )
 I1IIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'mejores.png' ) )
 IIIII = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favoritos.png' ) )
 OOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorPeliculas.png' ) )
 OOO00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'BuscadorSeries.png' ) )
 iiiiiIIii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_series.png' ) )
 O000OO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'Novedades_Episodios.png' ) )
 i1I1iI = '\x68\x65\x78\x68\x65\x78'
 oo0OooOOo0 = i1I1iI . replace ( '\x68\x65\x78\x68\x65\x78' , '\x68\x65\x78' )
 if 92 - 92: i11Ii11I1Ii1i . O0oO + o0000oOoOoO0o
 if 28 - 28: i1IIi * ii11ii1ii - o0000oOoOoO0o * OoIii111II * o0oO0 / OoOO
OooO0OoOOOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'peliculas.png' ) )
i1Ii = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'series.png' ) )
o00OO00OoO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'ajustes.png' ) )
OOOO0OOoO0O0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'videoteca.png' ) )
O0Oo000ooO00 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'favorites.png' ) )
oO0 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'resolver.png' ) )
Ii1iIiII1ii1 = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'test.png' ) )
ooOooo000oOO = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'video-tutoriales.png' ) )
Oo0oOOo = xbmc . translatePath ( os . path . join ( I1ii11iIi11i , 'proxy.png' ) )
if 58 - 58: II111iiii * IIII * o00O0oo / IIII
if 75 - 75: oO0o0ooO0
I1III = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
OO0O0OoOO0 = IiII1IiiIiI1 . getSetting ( 'usuario' )
iiiI1I11i1 = IiII1IiiIiI1 . getSetting ( 'mail' )
IIi1i11111 = IiII1IiiIiI1 . getSetting ( 'claves' )
ooOO00O00oo = IiII1IiiIiI1 . getSetting ( 'mostrar_cat' )
I1ii11iI = IiII1IiiIiI1 . getSetting ( 'sel_tobox' )
IIi1i = IiII1IiiIiI1 . getSetting ( 'videos' )
I1I1iIiII1 = IiII1IiiIiI1 . getSetting ( 'activar' )
i11i1I1 = IiII1IiiIiI1 . getSetting ( 'favcopy' )
ii1I = IiII1IiiIiI1 . getSetting ( 'anticopia' )
Oo0ooOo0o = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
Ii1i1 = IiII1IiiIiI1 . getSetting ( 'notificar' )
iiIii = IiII1IiiIiI1 . getSetting ( 'mostrar_bus' )
ooo0O = IiII1IiiIiI1 . getSetting ( 'restante' )
oOoO0o00OO0 = IiII1IiiIiI1 . getSetting ( 'selecton' )
i1I1ii = IiII1IiiIiI1 . getSetting ( 'aviso' )
oOOo0 = IiII1IiiIiI1 . getSetting ( 'RealStream_Settings' )
oo00O00oO = IiII1IiiIiI1 . getSetting ( 'Resolver_Settings' )
ooo0O = IiII1IiiIiI1 . getSetting ( 'restante' )
iIiIIIi = IiII1IiiIiI1 . getSetting ( 'fav' )
ooo00OOOooO = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
I1III = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
O00OOOoOoo0O = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( '\x62\x61\x73\x65\x36\x34' )
O000OOo00oo = 'bienvenida'
oo0OOo = 'bienvenida'
copyright = IiII1IiiIiI1 . getSetting ( 'copyright' )
ooOOO00Ooo = 'cGx1Z2luLnZpZGVvLg==' . decode ( '\x62\x61\x73\x65\x36\x34' ) + copyright
IiIIIi1iIi = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( '\x62\x61\x73\x65\x36\x34' )
ooOOoooooo = IiII1IiiIiI1 . getSetting ( 'Forceupdate' )
if ooOOoooooo == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
II1I = 'LnR4dA==' . decode ( '\x62\x61\x73\x65\x36\x34' )
O0i1II1Iiii1I11 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1NQOUpRZExS' . decode ( '\x62\x61\x73\x65\x36\x34' )
if 9 - 9: o00O0oo / ii11ii1ii - OOooOOo / OoooooooOO / iIii1I11I1II1 - o0000oOoOoO0o
if 91 - 91: i11Ii11I1Ii1i % i1IIi % iIii1I11I1II1
IIi1I11I1II = 'aHR0cDovL2JpdC5seS8yU1FOSnlP' . decode ( '\x62\x61\x73\x65\x36\x34' )
OooOoooOo = O00OOOoOoo0O + O000OOo00oo + II1I
ii11IIII11I = 'http://www.youtube.com'
OOooo = 'aHR0cDovL3kzei5zag==' . decode ( '\x62\x61\x73\x65\x36\x34' )
oOooOOOoOo = 'http://bit.ly/2ImelUx'
i1Iii1i1I = '.xsl.pt'
OOoO00 = 'L21hc3Rlci8=' . decode ( '\x62\x61\x73\x65\x36\x34' )
IiI111111IIII = OOooo + i1Iii1i1I
i1Iiii111iI1iIi1 = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*'
OOO = 'tvg-logo=[\'"](.*?)[\'"]'
if 68 - 68: II111iiii + O0oO
I1I1I = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.*)'
OoOO000 = '(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)'
i1Ii11i1i = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
o0oOOoo = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
oOo00O0oo00o0 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
ii = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
OOooooO0Oo = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.+)\s*'
OO = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
iIiIIi1 = '#(.+?),(.+)\s*(.+)'
I1IIII1i = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
I1I11i = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
Ii1I1I1i1Ii = '[\'"](.*?)[\'"]'
i1Oo0oO00o = r'066">\s*(.+)</f'
i11I1II1I11i = '[\'"](.*?)[\'"]'
OooOoOO0 = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
iI1i11iII111 = '[\'"](.*?)[\'"]'
Iii1IIII11I = 'src":"(.*?)"label":"(.*?)"lang":"(.*?)"'
OOOoo0OO = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1NQOUpRZExS' . decode ( '\x62\x61\x73\x65\x36\x34' )
oO0o0 = '[\'"](.*?)[\'"]'
iI1Ii11iIiI1 = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( '\x62\x61\x73\x65\x36\x34' )
OO0Oooo0oOO0O = iI1Ii11iIiI1 + I11i
o00O0 = '(.+),(.+),(.*)\s*'
oOO0O00Oo0O0o = '[\'"](.*?)[\'"]'
ii1 = 'UmVhbHN0cmVhbQ==' . decode ( '\x62\x61\x73\x65\x36\x34' )
I1iIIiiIIi1i = 'video=[\'"](.*?)[\'"]'
O0O0ooOOO = '0110nhu' . replace ( '0110nhu' , 'nhu' )
oOOo0O00o = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( '\x62\x61\x73\x65\x36\x34' ) + O0O0ooOOO
iIiIi11 = codecs . decode ( "5573756172696F732F5564622E747874" , "\x68\x65\x78" ) . decode ( 'utf-8' )
OOOiiiiI = 'aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtLw==' . decode ( '\x62\x61\x73\x65\x36\x34' ) + iIiIi11
oooOo0OOOoo0 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( '\x62\x61\x73\x65\x36\x34' )
OOoO = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( '\x62\x61\x73\x65\x36\x34' )
OO0O000 = 'aHR0cHM6Ly9uZXRhaS5ldS92aXNpdGFzL2luZGV4LnBocA==' . decode ( '\x62\x61\x73\x65\x36\x34' )
ooOOO00Ooo = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( '\x62\x61\x73\x65\x36\x34' )
if 37 - 37: OoooooooOO - O0 - o0000oOoOoO0o
exec codecs . decode ( "64627365726965203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C304656526C42614D326875272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A6462747365726965203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C315672526E49355247526E272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C78333427290D0A6462657365726965203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C327442566C453355445232272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A6462727365726965203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C314E7A4D584E7752476842272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C783334272920200D0A64626E7365726965203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C30784B533164694D46424C272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C78333427292020" , '\x68\x65\x78' ) . decode ( 'utf-8' )
exec codecs . decode ( "646270656C6963756C61203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C3074705A48424B59325A47272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A64626E6F76656461646573203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C7A4A4D5230687553485A43272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A646265737472656E6F73203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C316335593046315A556442272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A64626770656C6973203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C7A64514E55703151317078272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A646266616D696C696172203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C326456656D747753326C6A272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A646273757065726865726F6573203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C3064796146703363485A5243676F3D272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A50346B203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C7A4D78526E4A7A5A6B6457272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A646234203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C32315A6148565964454E31272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C783334272920" , '\x68\x65\x78' ) . decode ( 'utf-8' )
if 77 - 77: IIII * iIii1I11I1II1
if 98 - 98: OOooOOo % o0oO0 * OoooooooOO
def OoiIIiIi1 ( ) :
 if 74 - 74: i11Ii11I1Ii1i + o0000oOoOoO0o
 if 71 - 71: ii11ii1ii % IIII
 try :
  O00oO000O0O = I1i1i1iii ( todas )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for iIIii in I1111i :
   try :
    if 92 - 92: o0oO0 + oO0o0ooO0 % IIII
    oOo0 = iIIii
    if 30 - 30: O0oO / OOooOOo
    Iii1I1111ii = xbmc . Keyboard ( '' , 'Busqueda por titulo' )
    Iii1I1111ii . doModal ( )
    if ( Iii1I1111ii . isConfirmed ( ) ) :
     ooOoO00 = xbmcgui . DialogProgress ( )
     ooOoO00 . create ( 'Realstream:' , 'Buscando ...' )
     Ii1IIiI1i = range ( 0 , 76 )
     for o0O00Oo0 in Ii1IIiI1i :
      o0O00Oo0 = o0O00Oo0 + 1
      if 33 - 33: O0 * o0000oOoOoO0o - iii11 % iii11
     I11I = urllib . quote_plus ( Iii1I1111ii . getText ( ) ) . replace ( '+' , ' ' )
     I11iIi1i1II11 = I1i1i1iii ( oOo0 )
     I1111i = re . compile ( I1I1I ) . findall ( I11iIi1i1II11 )
     for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
      if 61 - 61: OoOO0ooOOoo0O - IIII - i1IIi
      ooOoO00 . update ( o0O00Oo0 , '[COLOR orange]Realstream: Buscando ...[/COLOR]' , ' [COLOR yellow] %s [/COLOR]' % i1I1i111Ii )
      xbmc . sleep ( 1 )
      if ooOoO00 . iscanceled ( ) : break ;
      if re . search ( I11I , IiI1iIiIIIii ( i1I1i111Ii . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       if 53 - 53: i1IIi
       ooOoO00 . update ( 80 , ' [COLOR orange]Busqueda finalizada[/COLOR] ' )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR gold]Generando listado ...  [/COLOR][COLOR orange] Por favor espere ![/COLOR] ,1000)" )
       ooOoO00 . update ( 100 , '[COLOR orange]Realstream: [/COLOR]' , '[COLOR gold] Busqueda finalizada ...[/COLOR]' )
       ooOoO00 . close ( )
       o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
       if 73 - 73: O0oO % i11iIiiIii - OOooOOo
       if 7 - 7: O0 * i11iIiiIii * o0oO0 + Ooo0OO0oOO % OoOO - Ooo0OO0oOO
     II1IIIIiII1i ( '[COLOR %s]Buscar Pelicula[/COLOR]' % I1III , 'search' , 111 , OOOO , Ooo )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Resultados para: [COLOR orange]" + I11I + "[/COLOR] ,2000)" )
     if 1 - 1: II111iiii
   except : II1IIIIiII1i ( '[COLOR %s]Buscar Pelicula[/COLOR]' % I1III , 'search' , 111 , OOOO , Ooo )
   if 68 - 68: i11Ii11I1Ii1i - OOooOOo / iii11 / O0oO
 except :
  pass
  if 12 - 12: o0oO0 + i11iIiiIii * iIii1I11I1II1 / o00O0oo . O0oO
def Iii1iI ( ) :
 if 29 - 29: OOooOOo % IIII - OOooOOo / IIII . i1IIi
 i1I1ii = IiII1IiiIiI1 . getSetting ( 'aviso' )
 if 31 - 31: iii11
 if i1I1ii == 'true' :
  if 88 - 88: OoOO - Ooo0OO0oOO + IIII * OOooOOo % iIii1I11I1II1 + ii11ii1ii
  try :
   O00oO000O0O = I1i1i1iii ( OooOoooOo )
   I1111i = re . compile ( i1Iiii111iI1iIi1 ) . findall ( O00oO000O0O )
   for oo000O0OoooO , O0o in I1111i :
    try :
     if 27 - 27: OoIii111II - o0oO0 / o00O0oo % OoIii111II + OOooOOo
     if 96 - 96: iii11
     oOoOo0O0OOOoO = oo000O0OoooO
     iI11IIIiii1II = O0o
     if 16 - 16: i11Ii11I1Ii1i + OoOO0ooOOoo0O
     if 66 - 66: i11Ii11I1Ii1i / oO0o0ooO0 * OoooooooOO + OoooooooOO % O0oO
     from datetime import datetime
     if 49 - 49: oO0o0ooO0 - i11iIiiIii . iii11 * o0oO0 % i11Ii11I1Ii1i + i1IIi
     oOO0OOOo = datetime . now ( )
     oo0o0000 = oOO0OOOo . strftime ( '%d/%m/%Y' )
     iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
     if 11 - 11: iIii1I11I1II1
     if 20 - 20: II111iiii % ii11ii1ii + o00O0oo + Ooo0OO0oOO
     if 23 - 23: IIII * o0oO0 * ii11ii1ii . O0 - i11iIiiIii
     if 18 - 18: o0oO0 + OoIii111II - O0
     if 53 - 53: i1IIi
     Ooo00Oo = "[B]" + oOoOo0O0OOOoO + "[/B]"
     oO00Oooo0O0o0 = "" + iI11IIIiii1II + ""
     II1iI1I11I = "[COLOR white]Hoy es: " + oo0o0000 + ", Su version instalada es:[/COLOR][COLOR gold] " + iIiiiI1IiI1I1 + "[/COLOR]"
     if 78 - 78: II111iiii
     xbmcgui . Dialog ( ) . ok ( "Real Stream" , Ooo00Oo , oO00Oooo0O0o0 , II1iI1I11I )
    except :
     pass
     if 100 - 100: iii11 + IIII + IIII
  except :
   pass
   if 9 - 9: O0oO % OoooooooOO . oO0o0ooO0 % O0oO
  try :
   I11iIi1i1II11 = I1i1i1iii ( OOoO )
   I1111i = re . compile ( Ii1I1I1i1Ii ) . findall ( I11iIi1i1II11 )
   for iiiiI in I1111i :
    if 56 - 56: ii11ii1ii . o00O0oo . OOooOOo
    import xbmc
    import xbmcaddon
    if 39 - 39: O0 + iii11
    __addon__ = xbmcaddon . Addon ( )
    __addonname__ = __addon__ . getAddonInfo ( 'name' )
    __icon__ = __addon__ . getAddonInfo ( 'icon' )
    if 91 - 91: OoooooooOO - iIii1I11I1II1 + OoOO0ooOOoo0O / OoOO . OoOO0ooOOoo0O + O0
    iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'version' )
    iIiii1iI1 = iiiiI
    if 33 - 33: OoIii111II % iIii1I11I1II1 * OOooOOo
    Ooo00Oo = "[COLOR orange] Ultima version: [/COLOR][COLOR white] [B]" + iiiiI + " [/B][/COLOR]"
    o00o0 = 4000
    xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , Ooo00Oo , o00o0 , __icon__ ) )
    if 50 - 50: ii11ii1ii / ii11ii1ii % o00O0oo . o00O0oo
    if iIiiiI1IiI1I1 < iiiiI :
     if 55 - 55: Ooo0OO0oOO - O0oO + II111iiii + i11Ii11I1Ii1i % o0oO0
     xbmcgui . Dialog ( ) . ok ( "Real Stream" , "[COLOR white] Existe una nueva version de [/COLOR][COLOR fuchsia]Realstream[/COLOR]" , "[COLOR orange]Actualimete tiene instalada la version[/COLOR] [COLOR white][B] %s [/B][/COLOR]" % iIiiiI1IiI1I1 , " [COLOR white]Ya esta disponible la[/COLOR] [COLOR gold][B] %s [/B][/COLOR]" % iiiiI )
     if 41 - 41: i1IIi - O0oO - o0oO0
     if 8 - 8: OoOO + iii11 - o0000oOoOoO0o % ii11ii1ii % o0000oOoOoO0o * oO0o0ooO0
  except :
   pass
   if 9 - 9: ii11ii1ii - i11iIiiIii - IIII * o0oO0 + Ooo0OO0oOO
   if 44 - 44: II111iiii
   if 52 - 52: o00O0oo - ii11ii1ii + o00O0oo % o0000oOoOoO0o
   if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 35 - 35: iIii1I11I1II1
    if 42 - 42: iii11 . OOooOOo . i1IIi + OoOO0ooOOoo0O + IIII + OOooOOo
    if 31 - 31: i11Ii11I1Ii1i . IIII - Ooo0OO0oOO . OoooooooOO / OoooooooOO
def IiI1iIiIIIii ( s ) :
 if 56 - 56: OoOO / oO0o0ooO0 / i11iIiiIii + OoooooooOO - ii11ii1ii - O0oO
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 21 - 21: O0 % OoIii111II . OOooOOo / II111iiii + OoIii111II
def OOOO0O00o ( file ) :
 if 62 - 62: iIii1I11I1II1
 try :
  i1II = open ( file , 'r' )
  O00oO000O0O = i1II . read ( )
  i1II . close ( )
  return O00oO000O0O
 except :
  pass
  if 14 - 14: oO0o0ooO0 / oO0o0ooO0 % Ooo0OO0oOO
def I1i1i1iii ( url ) :
 if 56 - 56: OOooOOo . O0 + ii11ii1ii
 try :
  i1II1I1Iii1 = urllib2 . Request ( url )
  i1II1I1Iii1 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  iiI11Iii = urllib2 . urlopen ( i1II1I1Iii1 )
  O0o0O0 = iiI11Iii . read ( )
  iiI11Iii . close ( )
  return O0o0O0
 except urllib2 . URLError , Ii1II1I11i1 :
  print 'We failed to open "%s".' % url
  if hasattr ( Ii1II1I11i1 , 'code' ) :
   print 'We failed with error code - %s.' % Ii1II1I11i1 . code
  if hasattr ( Ii1II1I11i1 , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , Ii1II1I11i1 . reason
   if 59 - 59: oO0o0ooO0 % iIii1I11I1II1 . i1IIi
def iiIi1i ( url ) :
 i1II1I1Iii1 = urllib2 . Request ( url )
 i1II1I1Iii1 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 i1II1I1Iii1 . add_header ( 'Referer' , '%s' % url )
 i1II1I1Iii1 . add_header ( 'Connection' , 'keep-alive' )
 iiI11Iii = urllib2 . urlopen ( i1II1I1Iii1 )
 O0o0O0 = iiI11Iii . read ( )
 iiI11Iii . close ( )
 return O0o0O0
 if 27 - 27: IIII * Ooo0OO0oOO . iii11 % OoIii111II * OoIii111II . i1IIi
 if 72 - 72: IIII % o00O0oo + OoOO / oO0o0ooO0 + OoIii111II
 if 10 - 10: iii11 / Ooo0OO0oOO + i11iIiiIii / o0oO0
def OOOoOoO ( ) :
 if 22 - 22: OOooOOo % o00O0oo
 I1III = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 if 57 - 57: IIII + O0 . o0oO0
 if I1I1iIiII1 == 'true' :
  if 46 - 46: OoIii111II
  if 45 - 45: Ooo0OO0oOO
  try :
   if 21 - 21: oO0o0ooO0 . iii11 . IIII / ii11ii1ii / iii11
   OO0O0OoOO0 = IiII1IiiIiI1 . getSetting ( 'usuario' )
   iiiI1I11i1 = IiII1IiiIiI1 . getSetting ( 'mail' )
   IIi1i11111 = IiII1IiiIiI1 . getSetting ( 'claves' )
   if 17 - 17: IIII / IIII / O0oO
   ii1I1IiiI1ii1i = I1i1i1iii ( OOOiiiiI )
   I1111i = re . compile ( o00O0 ) . findall ( ii1I1IiiI1ii1i )
   for O0ooO0OoO00o , II1iiiiII , O0OoOO0oo0 in I1111i :
    if re . search ( IIi1i11111 , O0OoOO0oo0 ) :
     if 96 - 96: OoOO0ooOOoo0O . o0000oOoOoO0o - Ooo0OO0oOO
     if OO0O0OoOO0 == O0ooO0OoO00o and iiiI1I11i1 == II1iiiiII and IIi1i11111 == O0OoOO0oo0 :
      xbmc . sleep ( 3000 )
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR orange]Bienvenido![/COLOR][COLOR white] " + O0ooO0OoO00o + "[/COLOR] ,3000)" )
      II1IIIIiII1i ( '[COLOR %s]Buscar Serie[/COLOR]' % I1III , 'search' , 145 , OOO00 , Ooo )
      II1IIIIiII1i ( '[COLOR %s]Series[/COLOR] ' % I1III , 'movieDB' , 117 , i1Ii , Ooo )
      II1IIIIiII1i ( '[COLOR %s]Buscar Pelicula[/COLOR]' % I1III , 'search' , 146 , OOOO , Ooo )
      II1IIIIiII1i ( '[COLOR %s]Peliculas[/COLOR] ' % I1III , 'movieDB' , 116 , OooO0OoOOOO , Ooo )
      if 99 - 99: OoIii111II . ii11ii1ii - o0oO0 % o0oO0 * O0 . II111iiii
  except :
   pass
   if 4 - 4: o0oO0
 if oOOo0 == 'true' :
  II1IIIIiII1i ( '[COLOR %s]Ajustes[/COLOR]' % I1III , 'Settings' , 119 , o00OO00OoO , Ooo )
  if 51 - 51: OoOO - O0 % oO0o0ooO0 - II111iiii
  if 31 - 31: i11Ii11I1Ii1i / ii11ii1ii - i11Ii11I1Ii1i - IIII
  if ooOO00O00oo == 'true' :
   try :
    if 7 - 7: i11Ii11I1Ii1i % O0 . OoOO0ooOOoo0O + OOooOOo - O0oO
    OO0O0OoOO0 = IiII1IiiIiI1 . getSetting ( 'usuario' )
    iiiI1I11i1 = IiII1IiiIiI1 . getSetting ( 'mail' )
    IIi1i11111 = IiII1IiiIiI1 . getSetting ( 'claves' )
    if 75 - 75: O0oO
    if 71 - 71: Ooo0OO0oOO
    ii1I1IiiI1ii1i = I1i1i1iii ( OOOiiiiI )
    I1111i = re . compile ( o00O0 ) . findall ( ii1I1IiiI1ii1i )
    for II1iiiiII , O0ooO0OoO00o , O0OoOO0oo0 in I1111i :
     if re . search ( IIi1i11111 , O0OoOO0oo0 ) :
      if 53 - 53: OoooooooOO % o0oO0 . OoIii111II / i11iIiiIii % i11Ii11I1Ii1i
      if OO0O0OoOO0 == O0ooO0OoO00o and iiiI1I11i1 == II1iiiiII and IIi1i11111 == O0OoOO0oo0 :
       if 28 - 28: O0oO
       oOOOOoo ( )
   except :
    pass
    if 58 - 58: o0000oOoOoO0o / OoIii111II . OoOO0ooOOoo0O / OoooooooOO + iii11
  if oo00O00oO == 'true' :
   if 86 - 86: O0oO * OOooOOo + O0oO + II111iiii
   i1i111iI ( )
   if 29 - 29: o00O0oo / i1IIi . OOooOOo - OoOO0ooOOoo0O - OoOO0ooOOoo0O - o0oO0
  if ii1I == 'false' :
   if 20 - 20: i1IIi % OoOO . OOooOOo / OoIii111II * i11iIiiIii * IIII
   Ooo00Oo = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   oO00Oooo0O0o0 = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.ResolveURL para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   II1iI1I11I = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, Script.resolveurl instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 85 - 85: o0000oOoOoO0o . OoOO0ooOOoo0O / Ooo0OO0oOO . O0 % iii11
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , Ooo00Oo , oO00Oooo0O0o0 , II1iI1I11I )
   if 90 - 90: ii11ii1ii % O0 * iIii1I11I1II1 . i11Ii11I1Ii1i
def I1iii11 ( ) :
 II1IIIIiII1i ( '[COLOR orange]Buscador por id[/COLOR]' , ii11IIII11I , 127 , i11 , Ooo )
 if 74 - 74: O0 / i1IIi
def OoO ( ) :
 I1III = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
 II1IIIIiII1i ( '[COLOR %s]The movie DB[/COLOR]' % I1III , 'movieDB' , 99 , i11 , Ooo )
 if 41 - 41: i1IIi * II111iiii / OoooooooOO . IIII
 if 83 - 83: i11Ii11I1Ii1i . O0 / ii11ii1ii / IIII - II111iiii
 if 100 - 100: OoOO
 if 46 - 46: OoOO0ooOOoo0O / iIii1I11I1II1 % i11Ii11I1Ii1i . iIii1I11I1II1 * i11Ii11I1Ii1i
 if 38 - 38: o00O0oo - i11Ii11I1Ii1i / O0 . iii11
def i1iiIiI1Ii1i ( ) :
 if 22 - 22: OoIii111II / i11iIiiIii
 OOOoOoO ( )
 OoO ( )
 if 62 - 62: OoOO / o00O0oo
def ii1O000OOO0OOo ( ) :
 if 32 - 32: o0oO0 * O0
 i1iiIiI1Ii1i ( )
 if 100 - 100: Ooo0OO0oOO % iIii1I11I1II1 * II111iiii - i11Ii11I1Ii1i
def oo00O00oO000o ( ) :
 if xbmc . getCondVisibility ( 'System.HasAddon(script.favourites)' ) :
  try :
   xbmc . executebuiltin ( "RunScript(script.favourites)" )
  except :
   pass
def OOo00OoO ( ) :
 IiII1IiiIiI1 . openSettings ( )
 if 10 - 10: o0000oOoOoO0o / i11iIiiIii
 if 92 - 92: O0oO . iii11
def oOO00O0Ooooo00 ( ) :
 resoveurl . display_settings ( )
 if 97 - 97: Ooo0OO0oOO / iii11 % i1IIi % o00O0oo
def ii111I11iI ( ) :
 II1IIIIiII1i ( '[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % I1III , 'resolve' , 120 , oO0 , Ooo )
 if 93 - 93: o00O0oo / iIii1I11I1II1 * i1IIi % OoooooooOO * O0 * O0oO
def Ooooooo ( ) :
 if 39 - 39: OoIii111II * ii11ii1ii + iIii1I11I1II1 - OoIii111II + IIII
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 69 - 69: O0
def i1i111iI ( ) :
 II1IIIIiII1i ( '[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % I1III , 'resolve' , 140 , oO0 , Ooo )
 if 85 - 85: Ooo0OO0oOO / O0
def oOOOOoo ( ) :
 if 18 - 18: o0000oOoOoO0o % O0 * o00O0oo
 try :
  if 62 - 62: iii11 . OoIii111II . OoooooooOO
  OO0O0OoOO0 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  iiiI1I11i1 = IiII1IiiIiI1 . getSetting ( 'mail' )
  IIi1i11111 = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 11 - 11: IIII / O0oO
  ii1I1IiiI1ii1i = I1i1i1iii ( OOOiiiiI )
  I1111i = re . compile ( o00O0 ) . findall ( ii1I1IiiI1ii1i )
  for O0ooO0OoO00o , II1iiiiII , O0OoOO0oo0 in I1111i :
   if re . search ( IIi1i11111 , O0OoOO0oo0 ) :
    if 73 - 73: i1IIi / i11iIiiIii
    if OO0O0OoOO0 == O0ooO0OoO00o and iiiI1I11i1 == II1iiiiII and IIi1i11111 == O0OoOO0oo0 :
     if 58 - 58: ii11ii1ii . II111iiii + oO0o0ooO0 - i11iIiiIii / II111iiii / O0
     II1IIIIiII1i ( '[COLOR %s]Buscador[/COLOR]' % I1III , 'search' , 146 , oOOoo00O0O , Ooo )
     II1IIIIiII1i ( '[COLOR %s]Estrenos[/COLOR]' % I1III , ii11IIII11I , 3 , Oo0o0000o0o0 , Ooo )
     if 85 - 85: OoOO0ooOOoo0O + IIII
     if 10 - 10: OoIii111II / OoOO + OoOO0ooOOoo0O / i1IIi
     if 27 - 27: o0oO0
     II1IIIIiII1i ( '[COLOR %s]Animacion[/COLOR]' % I1III , ii11IIII11I , 6 , oo0o0O00 , Ooo )
     if 67 - 67: OOooOOo
     if 55 - 55: o00O0oo - i11Ii11I1Ii1i * o0000oOoOoO0o + OoOO0ooOOoo0O * OoOO0ooOOoo0O * O0
     if 91 - 91: iii11 - IIII % iIii1I11I1II1 - OoooooooOO % Ooo0OO0oOO
     if 98 - 98: OoOO . OoOO * oO0o0ooO0 * II111iiii * iii11
     II1IIIIiII1i ( '[COLOR %s]Grandes Peliculas[/COLOR]' % I1III , ii11IIII11I , 30 , i1iiIII111ii , Ooo )
     if 92 - 92: ii11ii1ii
     if 40 - 40: OoOO0ooOOoo0O / OoIii111II
     if 79 - 79: OoOO - iIii1I11I1II1 + o0oO0 - iii11
     II1IIIIiII1i ( '[COLOR %s]Familiar[/COLOR]' % I1III , ii11IIII11I , 13 , OOooO0OOoo , Ooo )
     if 93 - 93: II111iiii . OOooOOo - ii11ii1ii + OoOO0ooOOoo0O
     if 61 - 61: II111iiii
     if 15 - 15: i11iIiiIii % OOooOOo * O0oO / iii11
     if 90 - 90: i11Ii11I1Ii1i
     if 31 - 31: IIII + O0
     if 87 - 87: Ooo0OO0oOO
     if 45 - 45: OoOO / OoooooooOO - i11Ii11I1Ii1i / o0oO0 % OoIii111II
     if 83 - 83: OOooOOo . iIii1I11I1II1 - OoIii111II * i11iIiiIii
     if 20 - 20: i1IIi * iii11 + II111iiii % o0000oOoOoO0o % oO0o0ooO0
     if 13 - 13: ii11ii1ii
     II1IIIIiII1i ( '[COLOR %s]Super heroes[/COLOR]' % I1III , ii11IIII11I , 24 , O0OoO000O0OO , Ooo )
     II1IIIIiII1i ( '[COLOR %s]4k[/COLOR] En pruebas' % I1III , ii11IIII11I , 141 , I11i1 , Ooo )
     if 60 - 60: o00O0oo * OOooOOo
     if 17 - 17: IIII % ii11ii1ii / o00O0oo . OoIii111II * IIII - II111iiii
     if 41 - 41: o0oO0
 except :
  pass
  if 77 - 77: iii11
  if 65 - 65: II111iiii . OOooOOo % oO0o0ooO0 * OoOO
def iI11I ( ) :
 if 11 - 11: i11Ii11I1Ii1i - oO0o0ooO0 + II111iiii - iIii1I11I1II1
 try :
  if 7 - 7: OoIii111II - O0oO / II111iiii * o0oO0 . i11Ii11I1Ii1i * i11Ii11I1Ii1i
  OO0O0OoOO0 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  iiiI1I11i1 = IiII1IiiIiI1 . getSetting ( 'mail' )
  IIi1i11111 = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 61 - 61: O0oO % Ooo0OO0oOO - OoOO / ii11ii1ii
  ii1I1IiiI1ii1i = I1i1i1iii ( OOOiiiiI )
  I1111i = re . compile ( o00O0 ) . findall ( ii1I1IiiI1ii1i )
  for O0ooO0OoO00o , II1iiiiII , O0OoOO0oo0 in I1111i :
   if re . search ( IIi1i11111 , O0OoOO0oo0 ) :
    if 4 - 4: OoooooooOO - i1IIi % o0oO0 - IIII * o0000oOoOoO0o
    if OO0O0OoOO0 == O0ooO0OoO00o and iiiI1I11i1 == II1iiiiII and IIi1i11111 == O0OoOO0oo0 :
     if 85 - 85: OoooooooOO * iIii1I11I1II1 . i11Ii11I1Ii1i / OoooooooOO % OOooOOo % O0
     II1IIIIiII1i ( '[COLOR %s]Buscar Serie[/COLOR]' % I1III , 'search' , 145 , o0 , Ooo )
     if 36 - 36: o0oO0 / II111iiii / OoIii111II / OoIii111II + o00O0oo
     oO0Ooo0ooOO0 ( )
     if 46 - 46: o0oO0 % OoOO0ooOOoo0O
     II1IIIIiII1i ( '[COLOR %s]En emision[/COLOR]' % I1III , ii11IIII11I , 150 , IIiiiiiiIi1I1 , Ooo )
     II1IIIIiII1i ( '[COLOR %s]Mejor valoradas[/COLOR]' % I1III , ii11IIII11I , 151 , I1IIIii , Ooo )
     II1IIIIiII1i ( '[COLOR %s]Series Retro[/COLOR]' % I1III , ii11IIII11I , 152 , oOoOooOo0o0 , Ooo )
     II1IIIIiII1i ( '[COLOR %s]Todas[/COLOR]' % I1III , ii11IIII11I , 142 , I11II1i , Ooo )
     if 64 - 64: i11iIiiIii - II111iiii
     if 77 - 77: OoOO0ooOOoo0O % o0oO0
 except :
  pass
  if 9 - 9: OoOO - ii11ii1ii * OoooooooOO . ii11ii1ii
  if 2 - 2: OoooooooOO % IIII
  if 63 - 63: OOooOOo % iIii1I11I1II1
def oO0Ooo0ooOO0 ( ) :
 if 39 - 39: i11Ii11I1Ii1i / II111iiii / o00O0oo % OOooOOo
 O0Oo00 = 'aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtLw==' . decode ( '\x62\x61\x73\x65\x36\x34' )
 ii1IiIIi1i = 'Y29uZGljaW9uLnR4dA==' . decode ( '\x62\x61\x73\x65\x36\x34' )
 O0o0O0 = O0Oo00 + ii1IiIIi1i
 oOOo0OOOOo0Oo = '[\'"](.*?)[\'"]'
 iI11I = I1i1i1iii ( O0o0O0 )
 I1111i = re . compile ( oOOo0OOOOo0Oo ) . findall ( iI11I )
 for OOo0o in I1111i :
  try :
   if 72 - 72: iIii1I11I1II1
   if OOo0o == 'si' or OOo0o == 'Si' :
    if 11 - 11: II111iiii / o0000oOoOoO0o
    II1IIIIiII1i ( '[COLOR lime](Si)[/COLOR][COLOR %s] Nuevos Episodios[/COLOR]' % I1III , ii11IIII11I , 155 , O000OO0 , Ooo )
    if 21 - 21: i11iIiiIii / i1IIi + OOooOOo * IIII . iii11
   elif OOo0o == 'no' or OOo0o == 'No' :
    if 84 - 84: O0 . O0oO - II111iiii . Ooo0OO0oOO / II111iiii
    II1IIIIiII1i ( '[COLOR red](No)[/COLOR][COLOR %s] Nuevos Episodios[/COLOR]' % I1III , ii11IIII11I , 155 , iiiiiIIii , Ooo )
    if 47 - 47: OoooooooOO
   return
   if 4 - 4: OOooOOo % O0oO
  except :
   pass
   if 10 - 10: OoIii111II . OoooooooOO - OoOO + OoIii111II - O0
def o0oO00 ( ) :
 if 65 - 65: IIII . iii11 . OoOO . i11Ii11I1Ii1i - IIII
 if 19 - 19: i11iIiiIii + i11Ii11I1Ii1i % Ooo0OO0oOO
 try :
  if 14 - 14: OoOO . II111iiii . O0oO / o0oO0 % o00O0oo - Ooo0OO0oOO
  o0oOoO0O = I1i1i1iii ( dbserie )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( o0oOoO0O )
  for iIIii in I1111i :
   if 84 - 84: O0 * OoooooooOO - OoIii111II * OoIii111II
   try :
    if 8 - 8: Ooo0OO0oOO / i1IIi . oO0o0ooO0
    i1I1IiI = iIIii
    Iii1I1111ii = xbmc . Keyboard ( '' , 'Buscar' )
    Iii1I1111ii . doModal ( )
    if ( Iii1I1111ii . isConfirmed ( ) ) :
     ooOoO00 = xbmcgui . DialogProgress ( )
     ooOoO00 . create ( 'Realstream:' , 'Buscando ...' )
     Ii1IIiI1i = range ( 0 , 69 )
     for o0O00Oo0 in Ii1IIiI1i :
      o0O00Oo0 = o0O00Oo0 + 1
     I11I = urllib . quote_plus ( Iii1I1111ii . getText ( ) ) . replace ( '+' , ' ' )
     I11iIi1i1II11 = I1i1i1iii ( i1I1IiI )
     I1111i = re . compile ( i1Ii11i1i ) . findall ( I11iIi1i1II11 )
     for oOooOO , i1I1i111Ii , Ooo , ooo , Ooo0oOooo0 in I1111i :
      ooOoO00 . update ( o0O00Oo0 , '[COLOR orange]Realstream: Buscando ...[/COLOR]' , '[COLOR gold] %s [/COLOR]' % i1I1i111Ii )
      xbmc . sleep ( 5 )
      if ooOoO00 . iscanceled ( ) : break ;
      if re . search ( I11I , IiI1iIiIIIii ( i1I1i111Ii . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       if 31 - 31: IIII / ii11ii1ii * i1IIi . OoOO0ooOOoo0O
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Generando listado ...  [COLOR orange] Por favor espere ![/COLOR] , 4000)" )
       OO0o0oO ( i1I1i111Ii , ooo , 143 , oOooOO , Ooo , Ooo0oOooo0 )
       ooOoO00 . update ( 100 , '[COLOR orange]Realstream: [/COLOR]' , '[COLOR gold] Busqueda finalizada ...[/COLOR]' )
       xbmc . sleep ( 2000 )
       ooOoO00 . close ( )
     II1IIIIiII1i ( '[COLOR %s]Buscar Serie[/COLOR]' % I1III , 'search' , 145 , o0 , Ooo )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Sin Resultados para: [COLOR orange]" + I11I + "[/COLOR] , 2000)" )
     if 83 - 83: o0000oOoOoO0o / i11iIiiIii % iIii1I11I1II1 . O0oO % oO0o0ooO0 . OoooooooOO
     if 94 - 94: o0oO0 + iIii1I11I1II1 % OoOO
   except : II1IIIIiII1i ( '[COLOR %s]Buscar Serie[/COLOR]' % I1III , 'search' , 145 , o0 , Ooo )
   if 93 - 93: o0oO0 - IIII + iIii1I11I1II1 * o0000oOoOoO0o + iii11 . i11Ii11I1Ii1i
 except :
  pass
  if 49 - 49: OoooooooOO * O0oO - ii11ii1ii . oO0o0ooO0
def O000o0 ( ) :
 if 98 - 98: OoOO . O0oO % II111iiii
 try :
  if 71 - 71: iii11 % i1IIi - II111iiii - IIII + IIII * Ooo0OO0oOO
  o0oOoO0O = I1i1i1iii ( dbnserie )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( o0oOoO0O )
  for iIIii in I1111i :
   if 51 - 51: iIii1I11I1II1 / OoOO0ooOOoo0O + IIII - O0oO + i11Ii11I1Ii1i
   try :
    if 29 - 29: o0000oOoOoO0o % iIii1I11I1II1 . OoooooooOO % OoooooooOO % II111iiii / i11Ii11I1Ii1i
    i1I1IiI = iIIii
    if 70 - 70: i11iIiiIii % i11Ii11I1Ii1i
   except :
    pass
    if 11 - 11: OoIii111II % o00O0oo % o0oO0 / II111iiii % iii11 - ii11ii1ii
  I11iIi1i1II11 = I1i1i1iii ( i1I1IiI )
  I1111i = re . compile ( i1Ii11i1i ) . findall ( I11iIi1i1II11 )
  for oOooOO , i1I1i111Ii , Ooo , ooo , Ooo0oOooo0 in I1111i :
   try :
    if 96 - 96: o00O0oo / II111iiii . o0oO0 - i11Ii11I1Ii1i * O0oO * oO0o0ooO0
    OO0o0oO ( i1I1i111Ii , ooo , 143 , oOooOO , Ooo , Ooo0oOooo0 )
    if 76 - 76: o0oO0 - II111iiii * IIII / OoooooooOO
   except :
    pass
 except :
  pass
  if 18 - 18: OoOO + iIii1I11I1II1 - II111iiii - OOooOOo
def oooOOOO0oooo ( ) :
 if 51 - 51: O0 - i1IIi / OOooOOo
 try :
  if 37 - 37: o0000oOoOoO0o % Ooo0OO0oOO
  o0oOoO0O = I1i1i1iii ( dbrserie )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( o0oOoO0O )
  for iIIii in I1111i :
   if 83 - 83: IIII . iii11 + oO0o0ooO0 - IIII * iii11 / iii11
   try :
    if 39 - 39: iii11 / ii11ii1ii % OoOO % i11iIiiIii
    i1I1IiI = iIIii
    if 90 - 90: iii11 - OoooooooOO
   except :
    pass
    if 96 - 96: O0 . o0oO0 % OoOO * iIii1I11I1II1
  I11iIi1i1II11 = I1i1i1iii ( i1I1IiI )
  I1111i = re . compile ( i1Ii11i1i ) . findall ( I11iIi1i1II11 )
  for oOooOO , i1I1i111Ii , Ooo , ooo , Ooo0oOooo0 in I1111i :
   try :
    if 54 - 54: o0oO0 * iii11 - OoooooooOO % OOooOOo + O0
    OO0o0oO ( i1I1i111Ii , ooo , 143 , oOooOO , Ooo , Ooo0oOooo0 )
    if 6 - 6: o00O0oo - II111iiii / oO0o0ooO0 + i11iIiiIii + IIII
   except :
    pass
 except :
  pass
  if 54 - 54: o0oO0 - O0oO - iii11 . iIii1I11I1II1
  if 79 - 79: o0oO0 . OoOO
def IIiI1I1 ( ) :
 if 15 - 15: o0oO0 * ii11ii1ii % o00O0oo * iIii1I11I1II1 - i11iIiiIii
 try :
  if 60 - 60: OOooOOo * iii11 % OoOO + oO0o0ooO0
  o0oOoO0O = I1i1i1iii ( dbeserie )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( o0oOoO0O )
  for iIIii in I1111i :
   if 52 - 52: i1IIi
   try :
    if 84 - 84: o0oO0 / OoIii111II
    i1I1IiI = iIIii
    if 86 - 86: OoOO0ooOOoo0O * II111iiii - O0 . OoOO0ooOOoo0O % iIii1I11I1II1 / IIII
   except :
    pass
    if 11 - 11: OOooOOo * oO0o0ooO0 + o00O0oo / o00O0oo
  I11iIi1i1II11 = I1i1i1iii ( i1I1IiI )
  I1111i = re . compile ( i1Ii11i1i ) . findall ( I11iIi1i1II11 )
  for oOooOO , i1I1i111Ii , Ooo , ooo , Ooo0oOooo0 in I1111i :
   try :
    if 37 - 37: i11iIiiIii + i1IIi
    OO0o0oO ( i1I1i111Ii , ooo , 143 , oOooOO , Ooo , Ooo0oOooo0 )
    if 23 - 23: i11Ii11I1Ii1i + O0oO . OoOO0ooOOoo0O * OOooOOo + o00O0oo
   except :
    pass
 except :
  pass
  if 18 - 18: OoIii111II * o0000oOoOoO0o . OoIii111II / O0
def iiIII1II ( ) :
 if 100 - 100: ii11ii1ii % o0oO0 / O0oO
 try :
  if 30 - 30: ii11ii1ii - IIII - i11Ii11I1Ii1i
  o0oOoO0O = I1i1i1iii ( dbtserie )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( o0oOoO0O )
  for iIIii in I1111i :
   if 81 - 81: o0000oOoOoO0o . OoooooooOO + IIII * Ooo0OO0oOO
   try :
    if 74 - 74: i1IIi + O0 + ii11ii1ii
    i1I1IiI = iIIii
    if 5 - 5: ii11ii1ii * OoOO0ooOOoo0O
   except :
    pass
    if 46 - 46: Ooo0OO0oOO
  I11iIi1i1II11 = I1i1i1iii ( i1I1IiI )
  I1111i = re . compile ( i1Ii11i1i ) . findall ( I11iIi1i1II11 )
  for oOooOO , i1I1i111Ii , Ooo , ooo , Ooo0oOooo0 in I1111i :
   try :
    if 33 - 33: i11Ii11I1Ii1i - II111iiii * OoooooooOO - ii11ii1ii - IIII
    OO0o0oO ( i1I1i111Ii , ooo , 143 , oOooOO , Ooo , Ooo0oOooo0 )
    if 84 - 84: iii11 + ii11ii1ii - OoOO0ooOOoo0O * OoOO0ooOOoo0O
   except :
    pass
 except :
  pass
  if 61 - 61: OoooooooOO . oO0o0ooO0 . OoooooooOO / ii11ii1ii
def o00O ( ) :
 if 48 - 48: i11Ii11I1Ii1i . i11iIiiIii
 try :
  if 5 - 5: oO0o0ooO0 . o00O0oo . II111iiii . OoooooooOO
  o0oOoO0O = I1i1i1iii ( dbserie )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( o0oOoO0O )
  for iIIii in I1111i :
   if 96 - 96: i11iIiiIii - IIII % O0 / OoOO
   try :
    if 100 - 100: i11Ii11I1Ii1i / o0oO0 - OoooooooOO % II111iiii - OOooOOo % OoOO0ooOOoo0O
    i1I1IiI = iIIii
    if 60 - 60: iIii1I11I1II1 + i1IIi
   except :
    pass
    if 86 - 86: iIii1I11I1II1 + OoOO0ooOOoo0O . i11iIiiIii - o0oO0
  I11iIi1i1II11 = I1i1i1iii ( i1I1IiI )
  I1111i = re . compile ( i1Ii11i1i ) . findall ( I11iIi1i1II11 )
  for oOooOO , i1I1i111Ii , Ooo , ooo , Ooo0oOooo0 in I1111i :
   try :
    if 51 - 51: OoOO0ooOOoo0O
    OO0o0oO ( i1I1i111Ii , ooo , 143 , oOooOO , Ooo , Ooo0oOooo0 )
    if 14 - 14: OoIii111II % oO0o0ooO0 % ii11ii1ii - i11iIiiIii
   except :
    pass
 except :
  pass
  if 53 - 53: o0oO0 % ii11ii1ii
def O0ooOo0o0Oo ( name , url ) :
 if 71 - 71: iIii1I11I1II1 - IIII . OOooOOo % OoooooooOO + IIII
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 26 - 26: ii11ii1ii + IIII / OoOO % OoOO0ooOOoo0O % o00O0oo + II111iiii
 i11I1I1iiI = I1i1i1iii ( url )
 I1111i = re . compile ( ii ) . findall ( i11I1I1iiI )
 for oOooOO , name , Ooo , url in I1111i :
  try :
   if 34 - 34: O0oO % Ooo0OO0oOO . O0 . iIii1I11I1II1
   if 93 - 93: i1IIi . i11iIiiIii . ii11ii1ii
   ooo00OOOooO = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % ooo00OOOooO + name + '[/COLOR]'
   O0O00OOo ( name , url , 144 , oOooOO , Ooo )
   if 66 - 66: i11iIiiIii / o0000oOoOoO0o - OoooooooOO / i1IIi . i11iIiiIii
   if 16 - 16: ii11ii1ii % o00O0oo + O0oO - O0 . i11Ii11I1Ii1i / iii11
  except :
   pass
   if 35 - 35: oO0o0ooO0 / iii11 / II111iiii - iIii1I11I1II1 + II111iiii . iii11
   if 81 - 81: i11Ii11I1Ii1i * IIII - o00O0oo * o0oO0 % OoOO0ooOOoo0O * OoOO0ooOOoo0O
   if 59 - 59: iIii1I11I1II1
def O0O00OOo ( name , url , mode , iconimage , fanart ) :
 if 7 - 7: IIII * OOooOOo / o0000oOoOoO0o * i11iIiiIii
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 84 - 84: IIII . i11Ii11I1Ii1i
 II1i111 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage="
 i1iiiIii11 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 i1iiiIii11 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 i1iiiIii11 . setProperty ( 'fanart_image' , fanart )
 i1iiiIii11 . setProperty ( 'IsPlayable' , 'true' )
 OOoOOO000O0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1i111 , listitem = i1iiiIii11 )
 return OOoOOO000O0
 if 92 - 92: o00O0oo / O0
 if 80 - 80: o0000oOoOoO0o - IIII + OoooooooOO
def O0ooOoO ( name , url ) :
 if 26 - 26: OoOO0ooOOoo0O / ii11ii1ii - i1IIi + O0oO
 if 38 - 38: OoooooooOO / o00O0oo . O0 / i1IIi / ii11ii1ii + iIii1I11I1II1
 Oo0ooOo0o = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 O0O0ooOOO = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 oOOo0O00o = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( '\x62\x61\x73\x65\x36\x34' )
 ooO00O00oOO = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 O00oO000O0O = I1i1i1iii ( oOOo0O00o )
 I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
 for I1 in I1111i :
  if 48 - 48: OOooOOo + o00O0oo + II111iiii * i11iIiiIii
  try :
   if 13 - 13: OoooooooOO * oO0o0ooO0 - o0oO0 / IIII + O0oO + OoIii111II
   if 39 - 39: iIii1I11I1II1 - OoooooooOO
   Oo0ooOo0o = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 81 - 81: o00O0oo - O0 * OoooooooOO
   if 23 - 23: II111iiii / oO0o0ooO0
   if Oo0ooOo0o == I1 :
    if 28 - 28: ii11ii1ii * Ooo0OO0oOO - OoOO
    if 'https://mybox.com' in url :
     if 19 - 19: O0oO
     url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
     if 67 - 67: O0 % iIii1I11I1II1 / OoIii111II . i11iIiiIii - o0oO0 + O0
    if 'uptostream.com' in url :
     if 27 - 27: IIII
     try :
      if 89 - 89: II111iiii / oO0o0ooO0
      O00oO000O0O = I1i1i1iii ( url )
      I1111i = re . compile ( Iii1IIII11I ) . findall ( O00oO000O0O )
      for url , IIo0OoO00 , IIIIIiII1 in I1111i :
       if 45 - 45: OOooOOo / i11Ii11I1Ii1i . i11Ii11I1Ii1i
       IIo0OoO00 = IIo0OoO00 . replace ( '","res":"2160",' , ' ' ) . replace ( '","res":"1080",' , ' ' ) . replace ( '","res":"720",' , ' ' ) . replace ( '","res":"480",' , ' ' ) . replace ( '","res":"360",' , ' ' )
       url = url . replace ( '\/' , '/' )
       url = url . replace ( ',"type":"video/mp4",' , ' ' )
       IIIIIiII1 = IIIIIiII1 . replace ( 'spa' , 'Castellano:' ) . replace ( 'eng' , 'Ingles:' ) . replace ( 'spa1' , 'Latino:' ) . replace ( 'eng2' , 'Americano:' )
       name = '[COLOR white]' + IIIIIiII1 + '[/COLOR] - [COLOR gold]' + IIo0OoO00 + '[/COLOR]'
       if 35 - 35: iii11 . OoOO0ooOOoo0O * i11iIiiIii
       iiII = [ ]
       iiII . append ( '[COLOR orange]Real Stream: [/COLOR][COLOR gold]1. Mostrar mas info. [Reiniciar][/COLOR]' )
       iiII . append ( '[COLOR gold]2. Mostar otras calidades disponibles [/COLOR]' )
       iiII . append ( '[COLOR gold]3. Ver en: %s [/COLOR]' % name )
       if 57 - 57: O0oO . ii11ii1ii + II111iiii
       if 43 - 43: iii11 % i11Ii11I1Ii1i
       o0O0ooOOoO = 'Seleccione una calidad e idioma:'
       iI = xbmcgui . Dialog ( )
       i11ii = iI . select ( o0O0ooOOoO , iiII )
       if 50 - 50: o0oO0 / OoOO0ooOOoo0O * o0oO0
       if 34 - 34: O0 * O0 % OoooooooOO + i11Ii11I1Ii1i * iIii1I11I1II1 % o0oO0
       if i11ii == 0 :
        if 25 - 25: O0oO + OoOO0ooOOoo0O . o0000oOoOoO0o % OoOO0ooOOoo0O * IIII
        OOoOOO000O0 = iI . ok ( "[COLOR darkpink]REALSTREAM:[/COLOR] " , "[COLOR gold]  Reiniciadas las opciones.  [/COLOR]" , "" )
        del iI
        return
        if 32 - 32: i11iIiiIii - iii11
       elif i11ii == 1 :
        if 53 - 53: OoooooooOO - OoIii111II
        pass
        if 87 - 87: oO0o0ooO0 . OOooOOo
        del iI
        if 17 - 17: o0oO0 . i11iIiiIii
        if 5 - 5: o00O0oo + O0 + O0 . iii11 - Ooo0OO0oOO
        if 63 - 63: oO0o0ooO0
        if 71 - 71: i1IIi . o0oO0 * i11Ii11I1Ii1i % OoooooooOO + IIII
       elif i11ii == 2 :
        if 36 - 36: OoIii111II
        i1iiI ( name , url )
        if 74 - 74: iii11 % o00O0oo
        return
        if 7 - 7: II111iiii
     except :
      pass
      if 27 - 27: oO0o0ooO0 . OoooooooOO + i11iIiiIii
      if 86 - 86: O0oO / o0000oOoOoO0o - o0000oOoOoO0o + o00O0oo + oO0o0ooO0
    if 'https://team.com' in url :
     if 33 - 33: o0000oOoOoO0o . i11Ii11I1Ii1i . OoIii111II . i1IIi
     url = url . replace ( 'https://team.com' , 'https://verystream.com' )
     if 49 - 49: o00O0oo
     if 84 - 84: O0oO - ii11ii1ii / O0 - iii11
     if 21 - 21: O0 * O0 % o00O0oo
    if 'https://vidcloud.co/' in url :
     if 94 - 94: O0oO + II111iiii % i11iIiiIii
     url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
     if 8 - 8: Ooo0OO0oOO * O0
    if 'https://gounlimited.to' in url :
     if 73 - 73: o0000oOoOoO0o / oO0o0ooO0 / O0oO / OoOO
     url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
     if 11 - 11: OoOO0ooOOoo0O + OoIii111II - OoooooooOO / OoOO
    if 'https://drive.com' in url :
     if 34 - 34: Ooo0OO0oOO
     url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
     if 45 - 45: Ooo0OO0oOO / ii11ii1ii / o0oO0
     if 44 - 44: o00O0oo - o0oO0 / II111iiii * OoOO * ii11ii1ii
     if 73 - 73: o0000oOoOoO0o - OOooOOo * i1IIi / i11iIiiIii * IIII % II111iiii
     if 56 - 56: OoooooooOO * ii11ii1ii . ii11ii1ii . o00O0oo
    import resolveurl
    if 24 - 24: ii11ii1ii . O0oO * o0oO0 % i11Ii11I1Ii1i / IIII
    Oo0Ooo0O0 = resolveurl . HostedMediaFile ( url )
    if 42 - 42: i1IIi * oO0o0ooO0 - o0oO0 . OOooOOo + o0000oOoOoO0o . iIii1I11I1II1
    if not Oo0Ooo0O0 :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
     return False
     if 51 - 51: O0oO . ii11ii1ii
    try :
     ooOoO00 = xbmcgui . DialogProgress ( )
     ooOoO00 . create ( 'Realstream:' , 'Iniciando ...' )
     ooOoO00 . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
     xbmc . sleep ( 1000 )
     IiiIiiIi = Oo0Ooo0O0 . resolve ( )
     if not IiiIiiIi or not isinstance ( IiiIiiIi , basestring ) :
      try : i1iiIIIi = IiiIiiIi . msg
      except : i1iiIIIi = url
      raise Exception ( i1iiIIIi )
      if 62 - 62: O0 / OOooOOo % O0 * OoOO % OOooOOo
    except Exception as Ii1II1I11i1 :
     try : i1iiIIIi = str ( Ii1II1I11i1 )
     except : i1iiIIIi = url
     ooOoO00 . update ( 45 , 'RESOLVEURL:' , 'Reiniciando ... ' )
     xbmc . sleep ( 1000 )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Episodio no disponible.  ,3000)" )
     ooOoO00 . close ( )
     if 33 - 33: OOooOOo . oO0o0ooO0 * OoOO * iIii1I11I1II1
    ooOoO00 . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    ooOoO00 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
    xbmc . sleep ( 500 )
    ooOoO00 . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
    xbmc . sleep ( 500 )
    ooOoO00 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de este capitulo!' )
    ooOoO00 . close ( )
    Ii1i1 = IiII1IiiIiI1 . getSetting ( 'notificar' )
    II11 = xbmcgui . ListItem ( path = IiiIiiIi )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II11 )
    if 12 - 12: iii11
    if 93 - 93: i11iIiiIii % iIii1I11I1II1 % i11iIiiIii + o0000oOoOoO0o / o0000oOoOoO0o / II111iiii
   else :
    if 49 - 49: IIII . o00O0oo . i11iIiiIii - II111iiii / o0oO0
    Ii1i1 = IiII1IiiIiI1 . getSetting ( 'notificar' )
    if Ii1i1 == 'true' :
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Por favor compruebe los ajustes de realstream.[/COLOR]" , "[COLOR white] Desde la seccion Tutoriales puede sacarle mayor partido a su Realstream, tambien puede configurarlo a su gusto. [/COLOR]" , "[COLOR gold]El addon no esta activado o bien configurado.[/COLOR]" )
     if 62 - 62: IIII
     I1III = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
     II1IIIIiII1i ( '[COLOR %s]Video tutoriales[/COLOR]' % I1III , ii11IIII11I , 125 , ooOooo000oOO , Ooo )
  except :
   pass
   if 1 - 1: OoIii111II / OoIii111II - i11iIiiIii
   if 87 - 87: ii11ii1ii / O0 * OoIii111II / o0000oOoOoO0o
   if 19 - 19: iii11 + i1IIi . OOooOOo - ii11ii1ii
   if 16 - 16: oO0o0ooO0 + Ooo0OO0oOO / o0000oOoOoO0o
def O00oOoo0OoO0 ( ) :
 if 62 - 62: i1IIi / Ooo0OO0oOO . OOooOOo * o0000oOoOoO0o
 if 21 - 21: o0000oOoOoO0o
 try :
  if 81 - 81: O0oO / iIii1I11I1II1 - Ooo0OO0oOO * iii11 . OOooOOo * o00O0oo
  o0oOoO0O = I1i1i1iii ( dbpelicula )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( o0oOoO0O )
  for iIIii in I1111i :
   if 95 - 95: OOooOOo
   try :
    if 88 - 88: OoIii111II % OoOO + iii11 + iii11 * II111iiii
    i1I1IiI = iIIii
    Iii1I1111ii = xbmc . Keyboard ( '' , 'Buscar' )
    Iii1I1111ii . doModal ( )
    if ( Iii1I1111ii . isConfirmed ( ) ) :
     ooOoO00 = xbmcgui . DialogProgress ( )
     ooOoO00 . create ( 'Realstream:' , 'Buscando ...' )
     Ii1IIiI1i = range ( 0 , 69 )
     for o0O00Oo0 in Ii1IIiI1i :
      o0O00Oo0 = o0O00Oo0 + 1
     I11I = urllib . quote_plus ( Iii1I1111ii . getText ( ) ) . replace ( '+' , ' ' )
     I11iIi1i1II11 = I1i1i1iii ( i1I1IiI )
     I1111i = re . compile ( oOo00O0oo00o0 ) . findall ( I11iIi1i1II11 )
     for oOooOO , i1I1i111Ii , Ooo , ooo , Ooo0oOooo0 in I1111i :
      ooOoO00 . update ( o0O00Oo0 , '[COLOR orange]Realstream: Buscando ...[/COLOR]' , '[COLOR gold] %s [/COLOR]' % i1I1i111Ii )
      xbmc . sleep ( 5 )
      if ooOoO00 . iscanceled ( ) : break ;
      if re . search ( I11I , IiI1iIiIIIii ( i1I1i111Ii . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       if 78 - 78: OoooooooOO
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Generando listado ...  [COLOR orange] Por favor espere ![/COLOR] , 4000)" )
       OO0o0oO ( i1I1i111Ii , ooo , 147 , oOooOO , Ooo , Ooo0oOooo0 )
       ooOoO00 . update ( 100 , '[COLOR orange]Realstream: [/COLOR]' , '[COLOR gold] Busqueda finalizada ...[/COLOR]' )
       xbmc . sleep ( 2000 )
       ooOoO00 . close ( )
     II1IIIIiII1i ( '[COLOR %s]Buscar Pelicula[/COLOR]' % I1III , 'search' , 146 , o0 , Ooo )
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Sin Resultados para: [COLOR orange]" + I11I + "[/COLOR] , 2000)" )
     if 77 - 77: o00O0oo / i1IIi / ii11ii1ii % IIII
     if 48 - 48: O0oO - OoIii111II + iIii1I11I1II1 + OoooooooOO
   except : II1IIIIiII1i ( '[COLOR %s]Buscar Pelicula[/COLOR]' % I1III , 'search' , 146 , o0 , Ooo )
   if 4 - 4: II111iiii . O0oO + o0oO0 * iii11 . Ooo0OO0oOO
 except :
  pass
  if 87 - 87: OoOO0ooOOoo0O / OoOO / i11iIiiIii
def oO0OO ( ) :
 if 88 - 88: OoOO0ooOOoo0O - i11iIiiIii % o0000oOoOoO0o * O0oO + o00O0oo
 try :
  if 52 - 52: II111iiii . OOooOOo + OoOO0ooOOoo0O % OoOO
  o0oOoO0O = I1i1i1iii ( dbpelicula )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( o0oOoO0O )
  for iIIii in I1111i :
   if 62 - 62: o0000oOoOoO0o
   try :
    if 15 - 15: O0oO + o0oO0 . IIII * OoOO . OoOO0ooOOoo0O
    i1I1IiI = iIIii
    if 18 - 18: i1IIi % II111iiii + iii11 % o0oO0
   except :
    pass
    if 72 - 72: iIii1I11I1II1
  I11iIi1i1II11 = I1i1i1iii ( i1I1IiI )
  I1111i = re . compile ( oOo00O0oo00o0 ) . findall ( I11iIi1i1II11 )
  for oOooOO , i1I1i111Ii , Ooo , ooo , Ooo0oOooo0 in I1111i :
   try :
    if 45 - 45: ii11ii1ii - o0000oOoOoO0o % iii11
    OO0o0oO ( i1I1i111Ii , ooo , 147 , oOooOO , Ooo , Ooo0oOooo0 )
    if 38 - 38: iii11 % IIII - OoooooooOO
   except :
    pass
 except :
  pass
  if 87 - 87: OoOO % OOooOOo
  if 77 - 77: iIii1I11I1II1 - i1IIi . oO0o0ooO0
  if 26 - 26: o0000oOoOoO0o * OoIii111II . i1IIi
def ooOoOO ( ) :
 if 56 - 56: iIii1I11I1II1 . i11iIiiIii - IIII * II111iiii * iii11
 try :
  if 5 - 5: IIII / IIII - o00O0oo
  o0oOoO0O = I1i1i1iii ( dbnovedades )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( o0oOoO0O )
  for iIIii in I1111i :
   if 79 - 79: o00O0oo + iii11
   try :
    if 10 - 10: ii11ii1ii + O0
    i1I1IiI = iIIii
    if 43 - 43: iIii1I11I1II1 / II111iiii % o0000oOoOoO0o - IIII
   except :
    pass
    if 62 - 62: O0oO
  I11iIi1i1II11 = I1i1i1iii ( i1I1IiI )
  I1111i = re . compile ( oOo00O0oo00o0 ) . findall ( I11iIi1i1II11 )
  for oOooOO , i1I1i111Ii , Ooo , ooo , Ooo0oOooo0 in I1111i :
   try :
    if 63 - 63: IIII + Ooo0OO0oOO * oO0o0ooO0 / o0000oOoOoO0o / ii11ii1ii * iIii1I11I1II1
    OO0o0oO ( i1I1i111Ii , ooo , 147 , oOooOO , Ooo , Ooo0oOooo0 )
    if 57 - 57: OoOO0ooOOoo0O - oO0o0ooO0 / Ooo0OO0oOO % i11iIiiIii
   except :
    pass
 except :
  pass
  if 3 - 3: i11Ii11I1Ii1i . Ooo0OO0oOO % OOooOOo + o00O0oo
def oo0o ( ) :
 if 51 - 51: IIII . OOooOOo
 try :
  if 73 - 73: OoooooooOO . OOooOOo / iii11 % o0oO0
  o0OO0O00o = I1i1i1iii ( dbfamiliar )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( o0OO0O00o )
  for iIIii in I1111i :
   if 73 - 73: i1IIi - IIII
   try :
    if 80 - 80: Ooo0OO0oOO + i11iIiiIii / oO0o0ooO0 * o00O0oo * o00O0oo + OoIii111II
    i1I1IiI = iIIii
    if 76 - 76: i11iIiiIii / OoOO0ooOOoo0O + OoOO0ooOOoo0O / i1IIi * OOooOOo
   except :
    pass
    if 12 - 12: iii11 % i11iIiiIii + o0000oOoOoO0o + iii11 / O0oO
  I11iIi1i1II11 = I1i1i1iii ( i1I1IiI )
  I1111i = re . compile ( oOo00O0oo00o0 ) . findall ( I11iIi1i1II11 )
  for oOooOO , i1I1i111Ii , Ooo , ooo , Ooo0oOooo0 in I1111i :
   try :
    if 53 - 53: OoIii111II . iii11 % iIii1I11I1II1 % OoOO0ooOOoo0O % O0oO
    OO0o0oO ( i1I1i111Ii , ooo , 147 , oOooOO , Ooo , Ooo0oOooo0 )
    if 53 - 53: iii11
   except :
    pass
 except :
  pass
  if 69 - 69: OoOO0ooOOoo0O . o0000oOoOoO0o . OOooOOo - o00O0oo
def IiiiI ( ) :
 if 12 - 12: II111iiii
 try :
  if 2 - 2: i1IIi - OOooOOo + O0oO . II111iiii
  o0oOoO0O = I1i1i1iii ( dbestrenos )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( o0oOoO0O )
  for iIIii in I1111i :
   if 25 - 25: oO0o0ooO0
   try :
    if 34 - 34: OoOO0ooOOoo0O . iIii1I11I1II1 % O0
    i1I1IiI = iIIii
    if 43 - 43: o00O0oo - i11Ii11I1Ii1i
   except :
    pass
    if 70 - 70: i11Ii11I1Ii1i / IIII % Ooo0OO0oOO - o0oO0
  I11iIi1i1II11 = I1i1i1iii ( i1I1IiI )
  I1111i = re . compile ( oOo00O0oo00o0 ) . findall ( I11iIi1i1II11 )
  for oOooOO , i1I1i111Ii , Ooo , ooo , Ooo0oOooo0 in I1111i :
   try :
    if 47 - 47: i11Ii11I1Ii1i
    OO0o0oO ( i1I1i111Ii , ooo , 147 , oOooOO , Ooo , Ooo0oOooo0 )
    if 92 - 92: IIII + OoOO0ooOOoo0O % i1IIi
   except :
    pass
 except :
  pass
  if 23 - 23: iii11 - IIII + o0oO0 - OoOO0ooOOoo0O * OoOO0ooOOoo0O . ii11ii1ii
def iIii11iI1II ( ) :
 if 42 - 42: Ooo0OO0oOO - OOooOOo + o00O0oo % o0oO0
 try :
  if 44 - 44: i1IIi - O0 - o00O0oo * o00O0oo + OoOO0ooOOoo0O
  O0oo = I1i1i1iii ( dbsuperheroes )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O0oo )
  for iIIii in I1111i :
   if 82 - 82: OoOO0ooOOoo0O + O0 - OoIii111II % oO0o0ooO0 * i11iIiiIii
   try :
    if 15 - 15: o0000oOoOoO0o
    i1I1IiI = iIIii
    if 39 - 39: IIII / o00O0oo / OOooOOo * iii11
   except :
    pass
    if 44 - 44: O0 + Ooo0OO0oOO . iIii1I11I1II1 + ii11ii1ii / O0 - O0oO
  I11iIi1i1II11 = I1i1i1iii ( i1I1IiI )
  I1111i = re . compile ( oOo00O0oo00o0 ) . findall ( I11iIi1i1II11 )
  for oOooOO , i1I1i111Ii , Ooo , ooo , Ooo0oOooo0 in I1111i :
   try :
    if 83 - 83: OoIii111II * O0oO / ii11ii1ii
    OO0o0oO ( i1I1i111Ii , ooo , 147 , oOooOO , Ooo , Ooo0oOooo0 )
    if 32 - 32: o0000oOoOoO0o + OoOO0ooOOoo0O - OoooooooOO
   except :
    pass
 except :
  pass
  if 39 - 39: OoooooooOO * IIII * O0 . O0oO . OoOO + Ooo0OO0oOO
def II1IIi ( ) :
 if 51 - 51: ii11ii1ii + oO0o0ooO0 / i11Ii11I1Ii1i - i1IIi
 try :
  if 51 - 51: ii11ii1ii - o00O0oo * O0oO
  o0oOoO0O = I1i1i1iii ( dbgpelis )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( o0oOoO0O )
  for iIIii in I1111i :
   if 12 - 12: iIii1I11I1II1 % Ooo0OO0oOO % Ooo0OO0oOO
   try :
    if 78 - 78: OoIii111II . OoOO0ooOOoo0O . O0oO
    i1I1IiI = iIIii
    if 97 - 97: oO0o0ooO0
   except :
    pass
    if 80 - 80: OOooOOo . o0oO0
  I11iIi1i1II11 = I1i1i1iii ( i1I1IiI )
  I1111i = re . compile ( oOo00O0oo00o0 ) . findall ( I11iIi1i1II11 )
  for oOooOO , i1I1i111Ii , Ooo , ooo , Ooo0oOooo0 in I1111i :
   try :
    if 47 - 47: O0oO + Ooo0OO0oOO + II111iiii % i11iIiiIii
    OO0o0oO ( i1I1i111Ii , ooo , 147 , oOooOO , Ooo , Ooo0oOooo0 )
    if 93 - 93: o00O0oo % OoOO0ooOOoo0O . O0 / i11Ii11I1Ii1i * oO0o0ooO0
   except :
    pass
 except :
  pass
  if 29 - 29: o0000oOoOoO0o
def oo0 ( ) :
 if 2 - 2: OoooooooOO
 try :
  if 60 - 60: OoOO
  o0oOoO0O = I1i1i1iii ( P4k )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( o0oOoO0O )
  for iIIii in I1111i :
   if 81 - 81: OoOO0ooOOoo0O % o0oO0
   try :
    if 87 - 87: iIii1I11I1II1 . OoooooooOO * OoOO0ooOOoo0O
    i1I1IiI = iIIii
    if 100 - 100: OoOO / i1IIi - OOooOOo % o0oO0 - iIii1I11I1II1
   except :
    pass
    if 17 - 17: O0oO / o0000oOoOoO0o % ii11ii1ii
  I11iIi1i1II11 = I1i1i1iii ( i1I1IiI )
  I1111i = re . compile ( oOo00O0oo00o0 ) . findall ( I11iIi1i1II11 )
  for oOooOO , i1I1i111Ii , Ooo , ooo , Ooo0oOooo0 in I1111i :
   try :
    if 71 - 71: OoIii111II . iii11 . OoOO
    OO0o0oO ( i1I1i111Ii , ooo , 147 , oOooOO , Ooo , Ooo0oOooo0 )
    if 68 - 68: i11iIiiIii % oO0o0ooO0 * OoOO * OoIii111II * II111iiii + O0
   except :
    pass
 except :
  pass
  if 66 - 66: O0oO % o00O0oo % OoooooooOO
def II11iIi ( ) :
 if 29 - 29: O0 . iii11
 try :
  if 66 - 66: oO0o0ooO0 * iIii1I11I1II1 % iIii1I11I1II1 * OoIii111II - Ooo0OO0oOO - OoIii111II
  o0O0oO0 = I1i1i1iii ( db23 )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( o0O0oO0 )
  for iIIii in I1111i :
   if 77 - 77: O0 . o0oO0
   try :
    if 39 - 39: Ooo0OO0oOO . II111iiii
    i1I1IiI = iIIii
    if 45 - 45: oO0o0ooO0 * OoOO0ooOOoo0O / iIii1I11I1II1
   except :
    pass
    if 77 - 77: iii11 - O0oO
  I11iIi1i1II11 = I1i1i1iii ( i1I1IiI )
  I1111i = re . compile ( oOo00O0oo00o0 ) . findall ( I11iIi1i1II11 )
  for oOooOO , i1I1i111Ii , Ooo , ooo , Ooo0oOooo0 in I1111i :
   try :
    if 11 - 11: o00O0oo
    OO0o0oO ( i1I1i111Ii , ooo , 147 , oOooOO , Ooo , Ooo0oOooo0 )
    if 26 - 26: iIii1I11I1II1 * iii11 - IIII
   except :
    pass
 except :
  pass
  if 27 - 27: o00O0oo * iii11 - OoOO + o0oO0 * o0oO0
def o0OO0O0OO0oO0 ( ) :
 if 9 - 9: oO0o0ooO0 % i11iIiiIii / ii11ii1ii
 try :
  if 20 - 20: oO0o0ooO0 * O0 + O0oO - OoooooooOO . O0oO
  O00oO000O0O = I1i1i1iii ( db4 )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for iIIii in I1111i :
   if 60 - 60: o0000oOoOoO0o . o0000oOoOoO0o / i11Ii11I1Ii1i
   try :
    if 45 - 45: O0 . i11iIiiIii % i11Ii11I1Ii1i . OoOO0ooOOoo0O % OoIii111II % iIii1I11I1II1
    i1I1IiI = iIIii
    if 58 - 58: iIii1I11I1II1 . OoOO0ooOOoo0O - i11iIiiIii * iIii1I11I1II1 % i11iIiiIii / OOooOOo
   except :
    pass
    if 80 - 80: o00O0oo / iIii1I11I1II1 % OoOO0ooOOoo0O
    if 80 - 80: OoOO % i11Ii11I1Ii1i
    if 99 - 99: Ooo0OO0oOO / iIii1I11I1II1 - o0oO0 * o00O0oo % OOooOOo
  I11iIi1i1II11 = I1i1i1iii ( i1I1IiI )
  I1111i = re . compile ( oOo00O0oo00o0 ) . findall ( I11iIi1i1II11 )
  for oOooOO , i1I1i111Ii , Ooo , ooo , Ooo0oOooo0 in I1111i :
   try :
    if 13 - 13: OoOO
    OO0o0oO ( i1I1i111Ii , ooo , 147 , oOooOO , Ooo , Ooo0oOooo0 )
    if 70 - 70: iii11 + O0 . oO0o0ooO0 * o0oO0
   except :
    pass
 except :
  pass
  if 2 - 2: OoooooooOO . IIII . OoIii111II
def I1iIII1IiiI ( name , url ) :
 if 96 - 96: OOooOOo % i1IIi . o0000oOoOoO0o . O0
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 37 - 37: i1IIi - IIII % OoooooooOO / IIII % Ooo0OO0oOO
 i11I1I1iiI = I1i1i1iii ( url )
 I1111i = re . compile ( OOooooO0Oo ) . findall ( i11I1I1iiI )
 for oOooOO , name , Ooo , url , id in I1111i :
  try :
   if 48 - 48: i11iIiiIii % oO0o0ooO0
   ooo00OOOooO = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % ooo00OOOooO + name + '[/COLOR]'
   i11i11 ( name , url , 130 , oOooOO , Ooo , id )
   if 18 - 18: iIii1I11I1II1 + O0oO * OOooOOo - IIII / OOooOOo
   if 78 - 78: O0oO . OoIii111II
  except :
   pass
   if 38 - 38: OoOO0ooOOoo0O + OoIii111II
def i11i11 ( name , url , mode , iconimage , fanart , id ) :
 if 15 - 15: ii11ii1ii + O0oO . Ooo0OO0oOO - iIii1I11I1II1 / O0 % iIii1I11I1II1
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 86 - 86: OOooOOo / oO0o0ooO0 * o0oO0
 II1i111 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + "&id=" + str ( id )
 i1iiiIii11 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 i1iiiIii11 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 i1iiiIii11 . setProperty ( 'fanart_image' , fanart )
 i1iiiIii11 . setProperty ( 'IsPlayable' , 'true' )
 O00o = [ ]
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  O00o . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 86 - 86: o00O0oo * II111iiii * O0oO
  i1iiiIii11 . addContextMenuItems ( O00o , replaceItems = True )
 OOoOOO000O0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1i111 , listitem = i1iiiIii11 )
 return OOoOOO000O0
 if 74 - 74: o00O0oo / OoIii111II
def oo0oO0oO ( ) :
 if 48 - 48: OoOO0ooOOoo0O % o00O0oo / O0oO . iIii1I11I1II1 * II111iiii
 if 65 - 65: OoOO0ooOOoo0O
 I1iI11I1III1 = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 I1iI11I1III1 . doModal ( )
 if not I1iI11I1III1 . isConfirmed ( ) :
  return None ;
 i1I1i111Ii = I1iI11I1III1 . getText ( ) . strip ( )
 if 8 - 8: i11iIiiIii / II111iiii + o0000oOoOoO0o * o0oO0 % OoIii111II . O0oO
 if 6 - 6: OoIii111II % ii11ii1ii . ii11ii1ii - o00O0oo / O0oO . i1IIi
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 99 - 99: OoOO0ooOOoo0O . iii11
  O0oOIiIII = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + i1I1i111Ii + '&language=es-ES' ) )
  if 13 - 13: o0000oOoOoO0o % oO0o0ooO0 / iii11 % iii11 % O0
  if 90 - 90: OoIii111II . Ooo0OO0oOO / iIii1I11I1II1
  return 'android'
  if 28 - 28: OoIii111II + oO0o0ooO0 - Ooo0OO0oOO / iIii1I11I1II1 - OOooOOo
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 45 - 45: O0 / i1IIi * oO0o0ooO0 * OoOO
  O0oOIiIII = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + i1I1i111Ii + '&language=es-ES' )
  if 35 - 35: o00O0oo / i11Ii11I1Ii1i % OOooOOo + iIii1I11I1II1
  if 79 - 79: OoOO0ooOOoo0O / Ooo0OO0oOO
  return 'windows'
  if 77 - 77: ii11ii1ii
  if 46 - 46: iii11
def o00OoooooooOo ( ) :
 if 32 - 32: o0000oOoOoO0o + OOooOOo . iii11
 try :
  if 41 - 41: OoOO0ooOOoo0O . i11iIiiIii / O0oO
  O00oO000O0O = I1i1i1iii ( todas )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for iIIii in I1111i :
   if 98 - 98: OoOO0ooOOoo0O % II111iiii
   try :
    if 95 - 95: iIii1I11I1II1 - iii11 - IIII + iii11 % o00O0oo . OOooOOo
    all = iIIii
    if 41 - 41: O0 + oO0o0ooO0 . i1IIi - II111iiii * o0000oOoOoO0o . OoOO
   except :
    pass
    if 68 - 68: o0000oOoOoO0o
  i11I1I1iiI = I1i1i1iii ( all )
  I1111i = re . compile ( I1I1I ) . findall ( i11I1I1iiI )
  for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
   try :
    if 20 - 20: iii11 - iii11
    o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
    if 37 - 37: OoIii111II
   except :
    pass
 except :
  pass
  if 37 - 37: ii11ii1ii / OoIii111II * O0
def o0o00O0oOooO0 ( ) :
 if 99 - 99: Ooo0OO0oOO
 try :
  if 76 - 76: OoOO
  OO0O0OoOO0 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  iiiI1I11i1 = IiII1IiiIiI1 . getSetting ( 'mail' )
  IIi1i11111 = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 92 - 92: O0oO - iIii1I11I1II1 % OoooooooOO
  ii1I1IiiI1ii1i = I1i1i1iii ( OOOiiiiI )
  I1111i = re . compile ( o00O0 ) . findall ( ii1I1IiiI1ii1i )
  for II1iiiiII , O0ooO0OoO00o , O0OoOO0oo0 in I1111i :
   if re . search ( IIi1i11111 , O0OoOO0oo0 ) :
    if 39 - 39: i11Ii11I1Ii1i . OOooOOo * OoOO0ooOOoo0O - i11iIiiIii
    if OO0O0OoOO0 == O0ooO0OoO00o and iiiI1I11i1 == II1iiiiII and IIi1i11111 == O0OoOO0oo0 :
     if 1 - 1: i11Ii11I1Ii1i * OoOO0ooOOoo0O
     I11 = I1i1i1iii ( db )
     I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( I11 )
     for iIIii in I1111i :
      if 66 - 66: OoOO0ooOOoo0O + i1IIi % II111iiii . O0 * o00O0oo % o00O0oo
      try :
       if 87 - 87: IIII + o0000oOoOoO0o . i11Ii11I1Ii1i - OoooooooOO
       i1I1IiI = iIIii
       if 6 - 6: iIii1I11I1II1 * OoooooooOO
      except :
       pass
       if 28 - 28: ii11ii1ii * o0000oOoOoO0o / iii11
     I11iIi1i1II11 = I1i1i1iii ( i1I1IiI )
     I1111i = re . compile ( I1I1I ) . findall ( I11iIi1i1II11 )
     for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
      try :
       if 52 - 52: O0 / o0000oOoOoO0o % i11Ii11I1Ii1i * OOooOOo % IIII
       o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
       if 69 - 69: o00O0oo
      except :
       pass
       if 83 - 83: o0000oOoOoO0o
    else :
     if 38 - 38: iii11 + OoooooooOO . i1IIi
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Esta seccion ha sido cerrada![COLOR orange] Lo sentimos ...[/COLOR] ,5000)" )
     if 19 - 19: i11Ii11I1Ii1i - o0000oOoOoO0o - o0oO0 - OoOO0ooOOoo0O . i11Ii11I1Ii1i . iii11
     return False
     if 48 - 48: i11Ii11I1Ii1i + OoIii111II
 except :
  pass
  if 60 - 60: O0oO + i11Ii11I1Ii1i . OoIii111II / i1IIi . iIii1I11I1II1
def i1i11ii1Ii ( ) :
 if 12 - 12: IIII . o0oO0
 try :
  if 79 - 79: iii11 / ii11ii1ii / i11Ii11I1Ii1i . iii11 * OoooooooOO + o0000oOoOoO0o
  OO0O0OoOO0 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  iiiI1I11i1 = IiII1IiiIiI1 . getSetting ( 'mail' )
  IIi1i11111 = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 73 - 73: O0 - o00O0oo
  ii1I1IiiI1ii1i = I1i1i1iii ( OOOiiiiI )
  I1111i = re . compile ( o00O0 ) . findall ( ii1I1IiiI1ii1i )
  for O0ooO0OoO00o , II1iiiiII , O0OoOO0oo0 in I1111i :
   if re . search ( IIi1i11111 , O0OoOO0oo0 ) :
    if 2 - 2: II111iiii / iii11
    if OO0O0OoOO0 == O0ooO0OoO00o and iiiI1I11i1 == II1iiiiII and IIi1i11111 == O0OoOO0oo0 :
     if 54 - 54: i1IIi . O0oO - o00O0oo + Ooo0OO0oOO + ii11ii1ii / ii11ii1ii
     Oo0o0000o0o0 = I1i1i1iii ( db1 )
     I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( Oo0o0000o0o0 )
     for iIIii in I1111i :
      if 22 - 22: Ooo0OO0oOO . iIii1I11I1II1
      try :
       i1IiiiiIi1I = iIIii
      except :
       pass
       if 56 - 56: OoooooooOO * O0
     O00oO000O0O = I1i1i1iii ( i1IiiiiIi1I )
     I1111i = re . compile ( I1I1I ) . findall ( O00oO000O0O )
     for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
      try :
       if 85 - 85: OoooooooOO % OoOO0ooOOoo0O * iIii1I11I1II1
       o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
       if 44 - 44: iIii1I11I1II1 . o00O0oo + iii11 . Ooo0OO0oOO
      except :
       pass
       if 7 - 7: o00O0oo + iIii1I11I1II1 * O0oO * O0oO / II111iiii - o0oO0
    else :
     if 65 - 65: oO0o0ooO0 + OoOO0ooOOoo0O + II111iiii
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Esta seccion ha sido cerrada![COLOR orange] Lo sentimos ...[/COLOR] ,5000)" )
     if 77 - 77: II111iiii
     return False
 except :
  pass
  if 50 - 50: O0 . O0 . Ooo0OO0oOO % ii11ii1ii
  if 68 - 68: oO0o0ooO0
  if 10 - 10: o0oO0
def OOOo ( ) :
 if 35 - 35: Ooo0OO0oOO - OoOO . ii11ii1ii * ii11ii1ii / i11iIiiIii + o00O0oo
 try :
  if 87 - 87: OoOO0ooOOoo0O % iIii1I11I1II1
  OO0O0OoOO0 = IiII1IiiIiI1 . getSetting ( 'usuario' )
  iiiI1I11i1 = IiII1IiiIiI1 . getSetting ( 'mail' )
  IIi1i11111 = IiII1IiiIiI1 . getSetting ( 'claves' )
  if 72 - 72: IIII . IIII - o00O0oo
  ii1I1IiiI1ii1i = I1i1i1iii ( OOOiiiiI )
  I1111i = re . compile ( o00O0 ) . findall ( ii1I1IiiI1ii1i )
  for II1iiiiII , O0ooO0OoO00o , O0OoOO0oo0 in I1111i :
   if re . search ( IIi1i11111 , O0OoOO0oo0 ) :
    if 48 - 48: ii11ii1ii - Ooo0OO0oOO + ii11ii1ii - OOooOOo * i11iIiiIii . i11Ii11I1Ii1i
    if OO0O0OoOO0 == O0ooO0OoO00o and iiiI1I11i1 == II1iiiiII and IIi1i11111 == O0OoOO0oo0 :
     if 35 - 35: OoIii111II . O0 + ii11ii1ii + IIII + i1IIi
     O00oO000O0O = I1i1i1iii ( db2 )
     I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
     for iIIii in I1111i :
      if 65 - 65: O0 * OOooOOo / OOooOOo . OoOO0ooOOoo0O
      try :
       if 87 - 87: II111iiii * o00O0oo % ii11ii1ii * ii11ii1ii
       O0OOOOOO0 = iIIii
       if 79 - 79: II111iiii - Ooo0OO0oOO . i1IIi + O0 % O0 * OOooOOo
      except :
       pass
       if 7 - 7: i1IIi + IIII % i11Ii11I1Ii1i / o0000oOoOoO0o + i1IIi
       if 41 - 41: o0oO0 + i11iIiiIii / OoIii111II % o00O0oo
     O00oO000O0O = I1i1i1iii ( O0OOOOOO0 )
     I1111i = re . compile ( I1I1I ) . findall ( O00oO000O0O )
     for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
      try :
       o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
       if 22 - 22: OoOO0ooOOoo0O % o0000oOoOoO0o * o0oO0 - o00O0oo + o0000oOoOoO0o - ii11ii1ii
      except :
       pass
    else :
     if 15 - 15: IIII
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Esta seccion ha sido cerrada![COLOR orange] Lo sentimos ...[/COLOR] ,5000)" )
     if 31 - 31: i11Ii11I1Ii1i / i1IIi . OoOO
     return False
     if 83 - 83: oO0o0ooO0 / iIii1I11I1II1 + i1IIi / i11Ii11I1Ii1i
 except :
  pass
  if 47 - 47: oO0o0ooO0 + OoooooooOO . II111iiii . i11Ii11I1Ii1i
def o0Oo0oO00OOO ( ) :
 if 10 - 10: iIii1I11I1II1 % O0oO . o0000oOoOoO0o * iii11 % II111iiii * OoIii111II
 try :
  if 24 - 24: i11Ii11I1Ii1i
  I1iIii = I1i1i1iii ( db26 )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( I1iIii )
  for iIIii in I1111i :
   if 97 - 97: o00O0oo / ii11ii1ii + iii11
   try :
    if 32 - 32: Ooo0OO0oOO % iii11 * ii11ii1ii
    O0O000oOo0O = iIIii
    if 82 - 82: OoIii111II
   except :
    pass
    if 86 - 86: ii11ii1ii * II111iiii * O0
    if 83 - 83: OoIii111II / iii11
  O00oO000O0O = I1i1i1iii ( O0O000oOo0O )
  I1111i = re . compile ( I1I1I ) . findall ( O00oO000O0O )
  for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
   try :
    if 64 - 64: OoOO % OoIii111II . iii11 % OoOO + O0oO * OoIii111II
    o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
    if 83 - 83: o0000oOoOoO0o % oO0o0ooO0 + O0oO % i11iIiiIii + O0
   except :
    pass
 except :
  pass
  if 65 - 65: iIii1I11I1II1 % oO0o0ooO0 + O0 / OoooooooOO
def O0000oO0o00 ( ) :
 if 80 - 80: OoooooooOO + OoIii111II
 try :
  if 95 - 95: iii11 / oO0o0ooO0 * iii11 - OoooooooOO * OoooooooOO % OoOO
  O00oO000O0O = I1i1i1iii ( db3 )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for iIIii in I1111i :
   if 43 - 43: ii11ii1ii . iii11
   try :
    if 12 - 12: iii11 + IIII + O0oO . OoIii111II / o0oO0
    i1I = iIIii
    if 100 - 100: OoOO % OoOO
   except :
    pass
    if 15 - 15: oO0o0ooO0 / iii11
    if 37 - 37: i11iIiiIii + OOooOOo . IIII % O0oO % O0oO
  O00oO000O0O = I1i1i1iii ( i1I )
  I1111i = re . compile ( I1I1I ) . findall ( O00oO000O0O )
  for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
    if 26 - 26: O0
   except :
    pass
 except :
  pass
  if 34 - 34: Ooo0OO0oOO * iii11
def OooOoOO0OO ( ) :
 if 27 - 27: OoIii111II * OOooOOo . iIii1I11I1II1 - iIii1I11I1II1
 try :
  if 5 - 5: OoIii111II
  O00oO000O0O = I1i1i1iii ( db4 )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for iIIii in I1111i :
   if 84 - 84: II111iiii * oO0o0ooO0 * II111iiii % OoIii111II / OOooOOo
   try :
    if 100 - 100: OoIii111II . o0oO0 - iIii1I11I1II1 . i11iIiiIii / II111iiii
    o0oO0OO00oo0o = iIIii
    if 17 - 17: OoIii111II / o00O0oo - o0000oOoOoO0o * o00O0oo
   except :
    pass
    if 42 - 42: o0oO0
  O00oO000O0O = I1i1i1iii ( o0oO0OO00oo0o )
  I1111i = re . compile ( I1I1I ) . findall ( O00oO000O0O )
  for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
    if 68 - 68: IIII . ii11ii1ii % Ooo0OO0oOO - OoooooooOO * i11Ii11I1Ii1i . IIII
   except :
    pass
 except :
  pass
  if 46 - 46: i11iIiiIii - IIII * OOooOOo * O0oO % o00O0oo * i1IIi
def Iii1I ( ) :
 if 40 - 40: OoIii111II * O0
 try :
  if 86 - 86: o0oO0
  O00oO000O0O = I1i1i1iii ( db5 )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for iIIii in I1111i :
   if 29 - 29: iIii1I11I1II1 - OoOO + OOooOOo % iIii1I11I1II1 % IIII
   try :
    if 84 - 84: OoIii111II + o00O0oo + o0oO0 + i11Ii11I1Ii1i
    ooOOo0o = iIIii
    if 50 - 50: II111iiii - iii11 + iIii1I11I1II1 + iIii1I11I1II1
   except :
    pass
    if 91 - 91: II111iiii - O0 . iIii1I11I1II1 . O0 + o00O0oo - II111iiii
    if 26 - 26: o0000oOoOoO0o
  O00oO000O0O = I1i1i1iii ( ooOOo0o )
  I1111i = re . compile ( I1I1I ) . findall ( O00oO000O0O )
  for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
    if 12 - 12: OoooooooOO / O0 + II111iiii * o00O0oo
   except :
    pass
 except :
  pass
  if 46 - 46: II111iiii - OoIii111II * OoooooooOO / oO0o0ooO0 % OoIii111II
def Ii ( ) :
 if 18 - 18: OoIii111II % oO0o0ooO0 * OoOO0ooOOoo0O
 try :
  if 62 - 62: IIII + ii11ii1ii % iIii1I11I1II1 / iIii1I11I1II1 . Ooo0OO0oOO . OoIii111II
  O00oO000O0O = I1i1i1iii ( db6 )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for iIIii in I1111i :
   if 21 - 21: OoOO - o0oO0 - OOooOOo / OoOO0ooOOoo0O
   try :
    if 48 - 48: OoooooooOO
    II1IiI1iiI111 = iIIii
    if 74 - 74: II111iiii - OoOO0ooOOoo0O + oO0o0ooO0 - IIII
   except :
    pass
    if 82 - 82: o0000oOoOoO0o % OOooOOo + O0
    if 90 - 90: OoOO0ooOOoo0O + OOooOOo * IIII
  O00oO000O0O = I1i1i1iii ( II1IiI1iiI111 )
  I1111i = re . compile ( I1I1I ) . findall ( O00oO000O0O )
  for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
    if 3 - 3: OOooOOo / i1IIi
   except :
    pass
 except :
  pass
  if 22 - 22: oO0o0ooO0 + IIII * II111iiii . Ooo0OO0oOO % IIII % O0oO
def OOo00ooOoO0o ( ) :
 if 21 - 21: i11iIiiIii
 try :
  if 89 - 89: i11Ii11I1Ii1i . i11iIiiIii * O0
  O00oO000O0O = I1i1i1iii ( db7 )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for iIIii in I1111i :
   if 44 - 44: i1IIi . OOooOOo / i11iIiiIii + OoIii111II
   try :
    if 27 - 27: IIII
    O0OO0ooO00 = iIIii
    if 83 - 83: iIii1I11I1II1
   except :
    pass
    if 63 - 63: OoooooooOO * OoOO / O0oO - oO0o0ooO0 . iIii1I11I1II1 + i11Ii11I1Ii1i
    if 44 - 44: i1IIi % OOooOOo % o0000oOoOoO0o
  O00oO000O0O = I1i1i1iii ( O0OO0ooO00 )
  I1111i = re . compile ( I1I1I ) . findall ( O00oO000O0O )
  for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
    if 9 - 9: ii11ii1ii % OoooooooOO - o0oO0
   except :
    pass
 except :
  pass
  if 43 - 43: OoOO % OoOO
def IIiii11ii1i ( ) :
 if 7 - 7: oO0o0ooO0 - O0 * O0oO - o0000oOoOoO0o - II111iiii
 try :
  if 41 - 41: OOooOOo - iii11 % II111iiii . iii11 - O0oO
  O00oO000O0O = I1i1i1iii ( db27 )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for iIIii in I1111i :
   if 45 - 45: o0oO0 - IIII
   try :
    if 70 - 70: OoOO % OOooOOo / OOooOOo . O0oO % Ooo0OO0oOO . II111iiii
    I1ii1Ii1 = iIIii
    if 73 - 73: O0 . oO0o0ooO0 + i11iIiiIii + iIii1I11I1II1 - O0oO / OoOO0ooOOoo0O
   except :
    pass
    if 99 - 99: o00O0oo * oO0o0ooO0 * o00O0oo - II111iiii + o0oO0
    if 72 - 72: o0000oOoOoO0o % OOooOOo / i11Ii11I1Ii1i - O0 + O0oO
  O00oO000O0O = I1i1i1iii ( I1ii1Ii1 )
  I1111i = re . compile ( I1I1I ) . findall ( O00oO000O0O )
  for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
    if 83 - 83: O0
   except :
    pass
 except :
  pass
  if 89 - 89: ii11ii1ii + o00O0oo - o0000oOoOoO0o
  if 40 - 40: OoOO + OoOO
def o0oo0o00ooO00 ( ) :
 if 37 - 37: OoOO - o00O0oo . OoooooooOO . Ooo0OO0oOO + OoOO0ooOOoo0O / o0oO0
 try :
  if 15 - 15: OoIii111II . i1IIi * OoOO0ooOOoo0O % iIii1I11I1II1
  O00oO000O0O = I1i1i1iii ( db8 )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for iIIii in I1111i :
   if 35 - 35: o00O0oo + iii11 - OoOO0ooOOoo0O % oO0o0ooO0 % o0000oOoOoO0o % OoOO0ooOOoo0O
   try :
    if 45 - 45: OOooOOo * IIII % OoOO
    i111I11I = iIIii
    if 80 - 80: iIii1I11I1II1 - OoooooooOO - o00O0oo - o00O0oo . OoooooooOO
   except :
    pass
    if 48 - 48: iii11 . i11iIiiIii / i1IIi % OoIii111II % i11Ii11I1Ii1i + oO0o0ooO0
    if 41 - 41: OoIii111II
  O00oO000O0O = I1i1i1iii ( i111I11I )
  I1111i = re . compile ( I1I1I ) . findall ( O00oO000O0O )
  for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
    if 3 - 3: OoIii111II + II111iiii / iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 10 - 10: II111iiii . O0
  if 31 - 31: oO0o0ooO0 / i11iIiiIii / O0
def iiI1ii ( ) :
 if 76 - 76: o0oO0 + iIii1I11I1II1 + OoOO0ooOOoo0O . OoOO
 try :
  if 49 - 49: OoIii111II / Ooo0OO0oOO / IIII
  O00oO000O0O = I1i1i1iii ( db9 )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for iIIii in I1111i :
   if 25 - 25: OOooOOo % O0 + i1IIi - Ooo0OO0oOO
   try :
    if 38 - 38: o0000oOoOoO0o % iii11 + i11iIiiIii + i11Ii11I1Ii1i + Ooo0OO0oOO / i11iIiiIii
    o0OOOOOo0 = iIIii
    if 57 - 57: iIii1I11I1II1 + iIii1I11I1II1
   except :
    pass
    if 56 - 56: oO0o0ooO0 + Ooo0OO0oOO
    if 32 - 32: II111iiii + OoOO0ooOOoo0O % Ooo0OO0oOO / OoOO0ooOOoo0O + o00O0oo
  O00oO000O0O = I1i1i1iii ( o0OOOOOo0 )
  I1111i = re . compile ( I1I1I ) . findall ( O00oO000O0O )
  for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
    if 2 - 2: i11iIiiIii - iii11 + OoOO % O0oO * o0oO0
   except :
    pass
    if 54 - 54: O0 - i11Ii11I1Ii1i . IIII % i11Ii11I1Ii1i + i11Ii11I1Ii1i
 except :
  pass
  if 36 - 36: IIII % i11iIiiIii
  if 47 - 47: i1IIi + II111iiii . ii11ii1ii * oO0o0ooO0 . O0oO / i1IIi
def i11iioOOOOO0Ooooo ( ) :
 if 57 - 57: o0oO0 - OoooooooOO
 try :
  if 68 - 68: o0000oOoOoO0o % o00O0oo / iii11 + iii11 - iii11 . OoOO
  O00oO000O0O = I1i1i1iii ( db10 )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for iIIii in I1111i :
   if 100 - 100: OoOO0ooOOoo0O % ii11ii1ii
   try :
    if 76 - 76: II111iiii / OoOO + OoooooooOO . o00O0oo . O0oO . Ooo0OO0oOO
    iiiI = iIIii
    if 10 - 10: o00O0oo % OOooOOo - II111iiii
   except :
    pass
    if 11 - 11: O0 + OOooOOo
    if 80 - 80: oO0o0ooO0 % oO0o0ooO0 % O0 - i11iIiiIii . i11Ii11I1Ii1i / O0
  O00oO000O0O = I1i1i1iii ( iiiI )
  I1111i = re . compile ( I1I1I ) . findall ( O00oO000O0O )
  for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
    if 13 - 13: OOooOOo + O0 - o00O0oo % ii11ii1ii / o0oO0 . i1IIi
   except :
    pass
    if 60 - 60: ii11ii1ii . OoIii111II % OOooOOo - iii11
 except :
  pass
  if 79 - 79: OoooooooOO / o00O0oo . O0
def oOoO0Oo0 ( ) :
 if 7 - 7: Ooo0OO0oOO + o0oO0
 try :
  if 32 - 32: iIii1I11I1II1 % OOooOOo / i11iIiiIii + IIII - o0000oOoOoO0o . i11Ii11I1Ii1i
  O00oO000O0O = I1i1i1iii ( db11 )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for iIIii in I1111i :
   if 86 - 86: i1IIi / o0oO0 * OOooOOo
   try :
    if 67 - 67: o00O0oo * o00O0oo / oO0o0ooO0 * OoooooooOO + OoOO0ooOOoo0O
    oooo = iIIii
    if 63 - 63: Ooo0OO0oOO % OOooOOo
   except :
    pass
    if 75 - 75: Ooo0OO0oOO / ii11ii1ii
  O00oO000O0O = I1i1i1iii ( oooo )
  I1111i = re . compile ( I1I1I ) . findall ( O00oO000O0O )
  for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
    if 8 - 8: iIii1I11I1II1
   except :
    pass
 except :
  pass
  if 30 - 30: o0oO0 - i11iIiiIii
  if 3 - 3: OoIii111II / O0oO
def Ii11 ( ) :
 if 3 - 3: o0oO0 + iii11 . i1IIi / IIII % iii11
 try :
  if 98 - 98: OoIii111II * iIii1I11I1II1 . o0oO0 * ii11ii1ii / o00O0oo + Ooo0OO0oOO
  O00oO000O0O = I1i1i1iii ( db12 )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for iIIii in I1111i :
   if 25 - 25: oO0o0ooO0
   try :
    if 19 - 19: OOooOOo % o0oO0 . OoIii111II * Ooo0OO0oOO
    oOo0OOOOoO = iIIii
    if 70 - 70: II111iiii + iii11 + i11iIiiIii - i1IIi / OoIii111II
   except :
    pass
    if 40 - 40: o00O0oo * iii11
    if 38 - 38: O0 . ii11ii1ii + OoOO0ooOOoo0O - oO0o0ooO0
  O00oO000O0O = I1i1i1iii ( oOo0OOOOoO )
  I1111i = re . compile ( I1I1I ) . findall ( O00oO000O0O )
  for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
    if 43 - 43: i11Ii11I1Ii1i + ii11ii1ii / OoooooooOO
   except :
    pass
 except :
  pass
  if 24 - 24: O0 + o0000oOoOoO0o * o0oO0 - iii11
  if 10 - 10: i11iIiiIii
def ii11i ( ) :
 if 71 - 71: o0oO0 * iii11 % II111iiii . o0oO0 % OoOO + o00O0oo
 try :
  if 66 - 66: o0oO0 - ii11ii1ii . i1IIi
  O00oO000O0O = I1i1i1iii ( db13 )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for iIIii in I1111i :
   if 75 - 75: o0oO0 - O0oO % OoOO0ooOOoo0O
   try :
    if 80 - 80: o0oO0 / IIII
    iIIi1i11 = iIIii
    if 34 - 34: OoOO % o0000oOoOoO0o % OOooOOo
   except :
    pass
  O00oO000O0O = I1i1i1iii ( iIIi1i11 )
  I1111i = re . compile ( I1I1I ) . findall ( O00oO000O0O )
  for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
    if 3 - 3: OoooooooOO * OOooOOo * oO0o0ooO0 - OoIii111II - Ooo0OO0oOO
   except :
    pass
 except :
  pass
  if 21 - 21: OoooooooOO - o00O0oo . OoOO0ooOOoo0O
def oOo ( ) :
 if 69 - 69: O0 / II111iiii * i1IIi
 try :
  if 66 - 66: O0
  O00oO000O0O = I1i1i1iii ( db14 )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for iIIii in I1111i :
   if 52 - 52: OoOO * OoooooooOO
   try :
    if 12 - 12: O0 + OoIii111II * i1IIi . OoOO
    o0OO0oooo = iIIii
    if 40 - 40: iii11 - OoOO0ooOOoo0O * O0oO - OoIii111II / OoOO0ooOOoo0O
   except :
    pass
    if 71 - 71: oO0o0ooO0 / OoooooooOO % OoIii111II / OoOO0ooOOoo0O % iii11
    if 19 - 19: iii11 + OoIii111II / oO0o0ooO0 / II111iiii
  O00oO000O0O = I1i1i1iii ( o0OO0oooo )
  I1111i = re . compile ( I1I1I ) . findall ( O00oO000O0O )
  for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
    if 92 - 92: i1IIi % Ooo0OO0oOO + Ooo0OO0oOO - iIii1I11I1II1 . o0oO0
   except :
    pass
 except :
  pass
  if 33 - 33: o0000oOoOoO0o / O0 + IIII
  if 75 - 75: OoIii111II % i11iIiiIii + iIii1I11I1II1
def oOoOo0o00o ( ) :
 if 2 - 2: II111iiii
 try :
  if 54 - 54: o0oO0 . OoooooooOO % ii11ii1ii
  O00oO000O0O = I1i1i1iii ( db15 )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for iIIii in I1111i :
   if 22 - 22: IIII
   try :
    if 22 - 22: i11Ii11I1Ii1i * O0oO - ii11ii1ii * O0 / i11iIiiIii
    OOooO0Oo0o000 = iIIii
    if 17 - 17: iIii1I11I1II1 + OOooOOo
   except :
    pass
    if 57 - 57: o0000oOoOoO0o / iii11
    if 13 - 13: OoooooooOO + OoOO
  O00oO000O0O = I1i1i1iii ( OOooO0Oo0o000 )
  I1111i = re . compile ( I1I1I ) . findall ( O00oO000O0O )
  for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
    if 32 - 32: O0 + oO0o0ooO0 % ii11ii1ii
   except :
    pass
 except :
  pass
  if 7 - 7: o00O0oo / Ooo0OO0oOO
def I1i1I11111iI1 ( ) :
 if 32 - 32: OOooOOo + o00O0oo - oO0o0ooO0 + o00O0oo / i1IIi * oO0o0ooO0
 try :
  if 90 - 90: o0oO0 % oO0o0ooO0
  O00oO000O0O = I1i1i1iii ( db16 )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for iIIii in I1111i :
   if 6 - 6: OoooooooOO / i11iIiiIii / iii11
   try :
    if 60 - 60: OOooOOo % oO0o0ooO0 / o0000oOoOoO0o % oO0o0ooO0 * i11iIiiIii / i11Ii11I1Ii1i
    i1Ii11II = iIIii
    if 33 - 33: OoIii111II . OoooooooOO . oO0o0ooO0
   except :
    pass
    if 15 - 15: o00O0oo . i11Ii11I1Ii1i
    if 94 - 94: O0oO . OOooOOo
  O00oO000O0O = I1i1i1iii ( i1Ii11II )
  I1111i = re . compile ( I1I1I ) . findall ( O00oO000O0O )
  for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
    if 73 - 73: i1IIi / II111iiii
   except :
    pass
 except :
  pass
  if 45 - 45: o0oO0 / Ooo0OO0oOO . OoooooooOO + OoOO
  if 51 - 51: i11Ii11I1Ii1i % i11iIiiIii % OoIii111II + iii11 % o00O0oo
def IIIIIiiiiI1I ( ) :
 if 93 - 93: ii11ii1ii * oO0o0ooO0 + OoOO - iii11 . o00O0oo + OoooooooOO
 try :
  if 44 - 44: O0oO * o0000oOoOoO0o
  O00oO000O0O = I1i1i1iii ( db17 )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for iIIii in I1111i :
   if 49 - 49: IIII % O0oO * i11iIiiIii / oO0o0ooO0 % IIII
   try :
    if 70 - 70: OoOO0ooOOoo0O / II111iiii % Ooo0OO0oOO - i11Ii11I1Ii1i
    I1II1IiI1 = iIIii
    if 26 - 26: IIII * ii11ii1ii
   except :
    pass
    if 31 - 31: O0oO * oO0o0ooO0 . o0oO0
    if 35 - 35: O0oO
  O00oO000O0O = I1i1i1iii ( I1II1IiI1 )
  I1111i = re . compile ( I1I1I ) . findall ( O00oO000O0O )
  for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
    if 94 - 94: Ooo0OO0oOO / i11iIiiIii % O0
   except :
    pass
 except :
  pass
  if 70 - 70: O0oO - ii11ii1ii / OoooooooOO % OoooooooOO
  if 95 - 95: OoooooooOO % OoooooooOO . o0oO0
def III1ii ( ) :
 if 38 - 38: o00O0oo + OoOO0ooOOoo0O
 try :
  if 68 - 68: O0
  O00oO000O0O = I1i1i1iii ( db18 )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for iIIii in I1111i :
   if 76 - 76: o00O0oo
   try :
    if 99 - 99: o0000oOoOoO0o
    I11IIII1111II = iIIii
    if 6 - 6: iIii1I11I1II1 / IIII + O0oO
   except :
    pass
    if 89 - 89: oO0o0ooO0
    if 87 - 87: i11Ii11I1Ii1i % ii11ii1ii
  O00oO000O0O = I1i1i1iii ( I11IIII1111II )
  I1111i = re . compile ( I1I1I ) . findall ( O00oO000O0O )
  for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
    if 62 - 62: OoOO + Ooo0OO0oOO / i11Ii11I1Ii1i * i11iIiiIii
   except :
    pass
 except :
  pass
  if 37 - 37: i11Ii11I1Ii1i
  if 33 - 33: OoOO - O0 - OoOO
def O000oooOO0Oo0 ( ) :
 if 31 - 31: OoIii111II - OoOO / IIII . i1IIi / o0oO0
 try :
  if 66 - 66: OoOO
  O00oO000O0O = I1i1i1iii ( db19 )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for iIIii in I1111i :
   if 72 - 72: iii11
   try :
    if 91 - 91: II111iiii / OoIii111II + iIii1I11I1II1 . O0oO - O0
    O0OOO00OOO00o = iIIii
    if 12 - 12: O0
   except :
    pass
    if 75 - 75: iIii1I11I1II1 % OoIii111II + o00O0oo * O0 . i11Ii11I1Ii1i - Ooo0OO0oOO
    if 32 - 32: o0oO0 % oO0o0ooO0 - i1IIi
  O00oO000O0O = I1i1i1iii ( O0OOO00OOO00o )
  I1111i = re . compile ( I1I1I ) . findall ( O00oO000O0O )
  for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
    if 40 - 40: iIii1I11I1II1 + i11Ii11I1Ii1i * OoOO0ooOOoo0O + oO0o0ooO0
   except :
    pass
 except :
  pass
  if 15 - 15: O0oO % OOooOOo - iIii1I11I1II1 * Ooo0OO0oOO
  if 71 - 71: OoOO0ooOOoo0O % ii11ii1ii % Ooo0OO0oOO
def I111 ( ) :
 if 6 - 6: OoOO0ooOOoo0O / Ooo0OO0oOO + i11Ii11I1Ii1i - o0000oOoOoO0o * IIII + Ooo0OO0oOO
 try :
  if 76 - 76: II111iiii - OoooooooOO % OoIii111II
  O00oO000O0O = I1i1i1iii ( db20 )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for iIIii in I1111i :
   if 40 - 40: o0oO0
   try :
    if 59 - 59: O0oO * OoooooooOO + IIII . iIii1I11I1II1 / i1IIi
    O0Oo0O00o0oo0OO = iIIii
    if 97 - 97: i11iIiiIii + OoOO0ooOOoo0O / Ooo0OO0oOO % IIII
   except :
    pass
    if 38 - 38: IIII % OoIii111II % II111iiii - ii11ii1ii - iIii1I11I1II1
  O00oO000O0O = I1i1i1iii ( O0Oo0O00o0oo0OO )
  I1111i = re . compile ( I1I1I ) . findall ( O00oO000O0O )
  for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
    if 9 - 9: o0000oOoOoO0o % o00O0oo . o00O0oo
   except :
    pass
 except :
  pass
  if 28 - 28: OoooooooOO % oO0o0ooO0 + o00O0oo + O0 . iii11
  if 80 - 80: i11iIiiIii % o00O0oo
def OOO00o0 ( ) :
 if 97 - 97: o00O0oo / o00O0oo / iIii1I11I1II1 % i1IIi . o00O0oo . OoIii111II
 try :
  if 4 - 4: ii11ii1ii - OoOO - i11iIiiIii * iii11 / o0oO0 - IIII
  O00oO000O0O = I1i1i1iii ( db21 )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for iIIii in I1111i :
   if 45 - 45: o0000oOoOoO0o % ii11ii1ii * i1IIi - O0
   try :
    if 82 - 82: II111iiii / i11Ii11I1Ii1i
    OOoOi1IiiI = iIIii
    if 70 - 70: O0oO . IIII * ii11ii1ii / IIII
   except :
    pass
    if 83 - 83: OoooooooOO + OoOO * oO0o0ooO0 . O0
    if 13 - 13: o0000oOoOoO0o
  O00oO000O0O = I1i1i1iii ( OOoOi1IiiI )
  I1111i = re . compile ( I1I1I ) . findall ( O00oO000O0O )
  for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
    if 7 - 7: OOooOOo + OoIii111II / i11iIiiIii / ii11ii1ii
   except :
    pass
 except :
  pass
  if 97 - 97: iii11 . O0oO / OOooOOo
def o00OO0o0 ( ) :
 if 39 - 39: Ooo0OO0oOO % o00O0oo - i11Ii11I1Ii1i
 try :
  if 48 - 48: i11iIiiIii
  O00oO000O0O = I1i1i1iii ( db22 )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for iIIii in I1111i :
   if 52 - 52: iIii1I11I1II1
   try :
    if 38 - 38: O0oO . O0oO * oO0o0ooO0 / OoooooooOO % Ooo0OO0oOO
    OO000 = iIIii
    if 31 - 31: OoOO * O0 / O0oO . OoooooooOO * O0oO . o00O0oo
   except :
    pass
  O00oO000O0O = I1i1i1iii ( OO000 )
  I1111i = re . compile ( I1I1I ) . findall ( O00oO000O0O )
  for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
    if 50 - 50: OoOO * O0oO - o0000oOoOoO0o + OoIii111II * OoOO % oO0o0ooO0
   except :
    pass
 except :
  pass
  if 92 - 92: O0oO % i1IIi % Ooo0OO0oOO % OoIii111II % o0000oOoOoO0o
def O00Ooo0O0OOOo ( ) :
 if 92 - 92: o0oO0 - iIii1I11I1II1
 try :
  if 30 - 30: O0oO / o00O0oo
  O00oO000O0O = I1i1i1iii ( db23 )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for iIIii in I1111i :
   if 22 - 22: oO0o0ooO0 * i11Ii11I1Ii1i
   try :
    if 4 - 4: OoOO0ooOOoo0O - oO0o0ooO0 + OOooOOo
    iiIiIiIiiIiI = iIIii
    if 23 - 23: OoOO / i11Ii11I1Ii1i / iIii1I11I1II1
   except :
    pass
  O00oO000O0O = I1i1i1iii ( iiIiIiIiiIiI )
  I1111i = re . compile ( I1I1I ) . findall ( O00oO000O0O )
  for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
    if 44 - 44: ii11ii1ii . ii11ii1ii + OoooooooOO * i11iIiiIii / O0oO + iii11
   except :
    pass
 except :
  pass
  if 17 - 17: IIII + II111iiii
def I1i11I11Iii ( ) :
 if 3 - 3: o0000oOoOoO0o
 try :
  if 77 - 77: OOooOOo % Ooo0OO0oOO
  O00oO000O0O = I1i1i1iii ( db25 )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for iIIii in I1111i :
   if 74 - 74: OoOO0ooOOoo0O / i1IIi % OoooooooOO
   try :
    if 52 - 52: OoIii111II % Ooo0OO0oOO
    I111oOOooo00OOooO = iIIii
    if 31 - 31: OOooOOo / o0000oOoOoO0o + OOooOOo - II111iiii
   except :
    pass
  O00oO000O0O = I1i1i1iii ( I111oOOooo00OOooO )
  I1111i = re . compile ( I1I1I ) . findall ( O00oO000O0O )
  for iiI , i1I1i111Ii , ooo , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo in I1111i :
   try :
    o0OOOoO0 ( i1I1i111Ii , ooo , iiI , id , i1i1iI1iiiI , Ooo0oOooo0 , Ooo )
    if 29 - 29: OOooOOo + i11iIiiIii . O0
   except :
    pass
 except :
  pass
  if 75 - 75: iii11 + iIii1I11I1II1
def IiiiI1 ( ) :
 if 34 - 34: o0oO0 + ii11ii1ii - i1IIi - OoIii111II + iIii1I11I1II1
 try :
  if 75 - 75: o00O0oo
  O00oO000O0O = I1i1i1iii ( db24 )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for iIIii in I1111i :
   if 92 - 92: O0oO / O0 * OOooOOo - O0oO
   try :
    if 99 - 99: i11iIiiIii % OoooooooOO
    o0000O00oO0O = iIIii
    if 3 - 3: iIii1I11I1II1 % o00O0oo . IIII % O0oO
   except :
    pass
  O00oO000O0O = I1i1i1iii ( o0000O00oO0O )
  I1111i = re . compile ( iIiIIi1 ) . findall ( O00oO000O0O )
  for iiI , i1I1i111Ii , ooo in I1111i :
   try :
    I1i1I1Iiiii1 ( iiI , i1I1i111Ii , ooo )
    if 88 - 88: O0oO + OOooOOo - O0oO / OoooooooOO - i11iIiiIii
   except :
    pass
    if 24 - 24: iIii1I11I1II1
 except :
  pass
  if 89 - 89: o0oO0 / i1IIi - o0000oOoOoO0o % OOooOOo . ii11ii1ii - O0
  if 71 - 71: OoOO % OOooOOo - i11Ii11I1Ii1i . i11Ii11I1Ii1i
  if 22 - 22: Ooo0OO0oOO / Ooo0OO0oOO - o0oO0 % O0oO . IIII + OoIii111II
def I1i1I1Iiiii1 ( thumb , name , url ) :
 if 64 - 64: i1IIi % o00O0oo / o0oO0 % OoooooooOO
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 if 24 - 24: iii11 + OoooooooOO . OoIii111II / OoOO0ooOOoo0O / O0oO
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OOO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   II1IIIIiII1i ( name , url , '' , o0oOoO00o , Ooo )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 65 - 65: OoooooooOO
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OOO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 18 - 18: O0 - i1IIi . iii11
   o00OOo00 ( name , url , 4 , oOooOO , Ooo )
   if 65 - 65: i1IIi
  else :
   if 9 - 9: oO0o0ooO0
   o00OOo00 ( name , url , 4 , oOooOO , Ooo )
   if 2 - 2: iIii1I11I1II1 * OOooOOo % i1IIi % o00O0oo + OoooooooOO + OOooOOo
def iIi1iiI1i1 ( name , url , thumb , id , trailer ) :
 if 3 - 3: IIII . OoIii111II / ii11ii1ii
 name = name . encode ( 'utf-8' )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 89 - 89: OoooooooOO . iIii1I11I1II1 . ii11ii1ii * iIii1I11I1II1 - iii11
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OOO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   II1IIIIiII1i ( name , url , '' , o0oOoO00o , Ooo )
 else :
  ooo00OOOooO = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
  if 92 - 92: OoooooooOO - o00O0oo - OoooooooOO % OOooOOo % OOooOOo % iIii1I11I1II1
  name = '[COLOR %s]' % ooo00OOOooO + name + '[/COLOR]'
  if 92 - 92: i11Ii11I1Ii1i * O0 % iii11 . iIii1I11I1II1
  if 'tvg-logo' in thumb :
   thumb = re . compile ( OOO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   oOoO0o00OO0 = IiII1IiiIiI1 . getSetting ( 'selecton' )
   if oOoO0o00OO0 == 'true' :
    if 66 - 66: O0oO + o0oO0
    i1ii1iIi ( name , url , 1 , thumb , thumb , id , trailer )
    if 43 - 43: o0oO0 + i11Ii11I1Ii1i + i1IIi - OoOO0ooOOoo0O + o0000oOoOoO0o
   else :
    if 54 - 54: o00O0oo + o00O0oo + O0oO % i1IIi % i11iIiiIii
    i1ii1iIi ( name , url , 130 , thumb , thumb , id , trailer )
    if 100 - 100: o00O0oo
  else :
   if 96 - 96: OOooOOo . OoIii111II * II111iiii % OoIii111II . iii11 * i1IIi
   if oOoO0o00OO0 == 'true' :
    if 83 - 83: iIii1I11I1II1
    i1ii1iIi ( name , url , 1 , thumb , thumb , id , trailer )
    if 97 - 97: i11iIiiIii + ii11ii1ii * IIII % i11Ii11I1Ii1i . OoIii111II
   else :
    if 4 - 4: O0 . i11Ii11I1Ii1i - iIii1I11I1II1
    i1ii1iIi ( name , url , 130 , thumb , thumb , id , trailer )
    if 19 - 19: IIII % OoOO / o0oO0 + II111iiii % OoooooooOO
def o0OOOoO0 ( name , url , thumb , id , trailer , description , fanart ) :
 if 89 - 89: o0oO0
 if 51 - 51: i11Ii11I1Ii1i
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . strip ( )
 ooo00OOOooO = IiII1IiiIiI1 . getSetting ( 'Fontcolor' )
 fanart = fanart . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 name = '[COLOR %s]' % ooo00OOOooO + name + '[/COLOR]'
 if 68 - 68: i11Ii11I1Ii1i - o0000oOoOoO0o * OoOO % Ooo0OO0oOO . Ooo0OO0oOO - iIii1I11I1II1
 if 22 - 22: OoooooooOO / o00O0oo % i11Ii11I1Ii1i * OoOO0ooOOoo0O
 if 'tvg-logo' in thumb :
  thumb = re . compile ( OOO ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  if oOoO0o00OO0 == 'true' :
   Ii1IiiiI1ii ( name , url , 1 , thumb , fanart , id , trailer , description )
  else :
   if 55 - 55: o00O0oo
   Ii1IiiiI1ii ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 76 - 76: oO0o0ooO0 - i11iIiiIii
 else :
  if 27 - 27: o00O0oo - i11iIiiIii % iii11 / ii11ii1ii . ii11ii1ii / OoooooooOO
  if oOoO0o00OO0 == 'true' :
   if 76 - 76: O0oO * OoOO . iIii1I11I1II1 % OoooooooOO % o00O0oo
   Ii1IiiiI1ii ( name , url , 1 , thumb , fanart , id , trailer , description )
   if 39 - 39: II111iiii * OoOO0ooOOoo0O . O0 * O0oO
  else :
   if 89 - 89: o0oO0 - Ooo0OO0oOO . O0oO - iii11 - OOooOOo
   Ii1IiiiI1ii ( name , url , 130 , thumb , fanart , id , trailer , description )
   if 79 - 79: OoIii111II + OoIii111II + o0oO0
   if 39 - 39: O0 - OoooooooOO
def oo0O00ooo0o ( name , trailer ) :
 if 29 - 29: OoooooooOO . II111iiii % OoOO0ooOOoo0O
 if Ii1i1 == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Realstream, Reproduciendo Trailer de: [COLOR green]" + name + "[/COLOR] ,5000)" )
  if 26 - 26: iIii1I11I1II1 - o00O0oo . OoIii111II . OoIii111II + iIii1I11I1II1 * ii11ii1ii
  ooo = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  O0Oo00Oo0o0ooOoO = ooo
  iI1Ii11 = xbmcgui . ListItem ( name , trailer , path = O0Oo00Oo0o0ooOoO )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iI1Ii11 )
 else :
  ooo = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  O0Oo00Oo0o0ooOoO = ooo
  iI1Ii11 = xbmcgui . ListItem ( name , trailer , path = O0Oo00Oo0o0ooOoO )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iI1Ii11 )
  if 93 - 93: OOooOOo / Ooo0OO0oOO / O0oO + II111iiii + i11iIiiIii
  if 16 - 16: OOooOOo - oO0o0ooO0 . ii11ii1ii
def i1iiI ( name , url ) :
 if 94 - 94: OoOO0ooOOoo0O + OoIii111II . Ooo0OO0oOO
 if Ii1i1 == 'true' :
  if 69 - 69: O0 - O0
  try :
   if 41 - 41: OoIii111II % o0000oOoOoO0o
   ooOoO00 = xbmcgui . DialogProgress ( )
   ooOoO00 . create ( 'Realstream:' , 'Iniciando ...' )
   ooOoO00 . update ( 30 , 'Realstream:' , 'Conectando al servidor ...' )
   xbmc . sleep ( 1000 )
   ooOoO00 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   ooOoO00 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   ooOoO00 . close ( )
   if 67 - 67: O0 % iii11
   O0Oo00Oo0o0ooOoO = url
   iI1Ii11 = xbmcgui . ListItem ( name , path = O0Oo00Oo0o0ooOoO )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iI1Ii11 )
   if 35 - 35: OOooOOo . OoOO0ooOOoo0O + OoooooooOO % ii11ii1ii % IIII
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. ,3000)" )
  if 39 - 39: o0oO0
 else :
  if 60 - 60: IIII
  try :
   if 62 - 62: iii11 * O0oO
   ooOoO00 = xbmcgui . DialogProgress ( )
   ooOoO00 . create ( 'Realstream:' , 'Iniciando ...' )
   ooOoO00 . update ( 30 , 'Realstream:' , 'Conectando al servidor ...' )
   xbmc . sleep ( 1000 )
   ooOoO00 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   ooOoO00 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   ooOoO00 . close ( )
   if 74 - 74: OoOO0ooOOoo0O . iIii1I11I1II1
   O0Oo00Oo0o0ooOoO = url
   iI1Ii11 = xbmcgui . ListItem ( name , path = O0Oo00Oo0o0ooOoO )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iI1Ii11 )
   if 87 - 87: Ooo0OO0oOO
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. ,3000)" )
  if 41 - 41: OoOO0ooOOoo0O . iIii1I11I1II1 % Ooo0OO0oOO + O0
 return
 if 22 - 22: o0000oOoOoO0o + ii11ii1ii . Ooo0OO0oOO + o00O0oo * i11Ii11I1Ii1i . i11iIiiIii
 if 90 - 90: IIII * OoOO0ooOOoo0O - ii11ii1ii + o0000oOoOoO0o
def OoOII11IiI1 ( trailer ) :
 if 86 - 86: iIii1I11I1II1 % oO0o0ooO0 - OoOO0ooOOoo0O + iii11 % OoOO . o00O0oo
 if 'https://www.youtube.com' in trailer :
  if 4 - 4: i1IIi + OoOO0ooOOoo0O
  try :
   if 39 - 39: iIii1I11I1II1 + Ooo0OO0oOO
   import resolveurl
   if 92 - 92: O0oO % i11iIiiIii % ii11ii1ii
   Oo0Ooo0O0 = resolveurl . HostedMediaFile ( ooo )
   ooOoO00 = xbmcgui . DialogProgress ( )
   ooOoO00 . create ( 'Realstream:' , 'Conectando al servidor ... ' )
   ooOoO00 . update ( 20 , 'Por favor, espere ...' )
   xbmc . sleep ( 500 )
   if 23 - 23: II111iiii * i11Ii11I1Ii1i
   if not Oo0Ooo0O0 :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    return False
    if 80 - 80: iii11 / i11iIiiIii + OoooooooOO
   try :
    if 38 - 38: o00O0oo % Ooo0OO0oOO + i1IIi * OoooooooOO * oO0o0ooO0
    ooOoO00 . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    IiiIiiIi = Oo0Ooo0O0 . resolve ( )
    if not IiiIiiIi or not isinstance ( IiiIiiIi , basestring ) :
     try : i1iiIIIi = IiiIiiIi . msg
     except : i1iiIIIi = IiiIiiIi
     raise Exception ( i1iiIIIi )
   except Exception as Ii1II1I11i1 :
    try : i1iiIIIi = str ( Ii1II1I11i1 )
    except : i1iiIIIi = IiiIiiIi
    ooOoO00 . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
    ooOoO00 . close ( )
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    if 83 - 83: iIii1I11I1II1 - Ooo0OO0oOO - iii11 / OoOO - O0
   ooOoO00 . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
   xbmc . sleep ( 500 )
   ooOoO00 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   ooOoO00 . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
   xbmc . sleep ( 500 )
   ooOoO00 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   ooOoO00 . close ( )
   if 81 - 81: o0oO0 - oO0o0ooO0 * o00O0oo / iii11
   II11 = xbmcgui . ListItem ( path = IiiIiiIi )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II11 )
   if 21 - 21: OoOO
  except :
   pass
   if 63 - 63: O0oO . O0 * O0oO + iIii1I11I1II1
  else :
   if 46 - 46: i1IIi + II111iiii * i1IIi - o0oO0
   ooo = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
   O0Oo00Oo0o0ooOoO = ooo
   iI1Ii11 = xbmcgui . ListItem ( trailer , path = O0Oo00Oo0o0ooOoO )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iI1Ii11 )
   return
   if 79 - 79: II111iiii - oO0o0ooO0 * o00O0oo - OoOO0ooOOoo0O . o00O0oo
def iiII1IIii1i1 ( name , url ) :
 if 38 - 38: i11Ii11I1Ii1i * OoooooooOO
 if '[Youtube]' in name :
  if 2 - 2: oO0o0ooO0 - i11iIiiIii
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  O0Oo00Oo0o0ooOoO = url
  iI1Ii11 = xbmcgui . ListItem ( i1i1iI1iiiI , path = O0Oo00Oo0o0ooOoO )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iI1Ii11 )
  if 98 - 98: oO0o0ooO0 + OoooooooOO - iii11 % i11iIiiIii / o0000oOoOoO0o . OoooooooOO
  if 87 - 87: i1IIi
 else :
  if 33 - 33: iii11 % II111iiii
  import resolveurl
  if 49 - 49: o00O0oo + O0oO / o0000oOoOoO0o + OoooooooOO + IIII / OoIii111II
  Oo0Ooo0O0 = resolveurl . HostedMediaFile ( url )
  if 29 - 29: o0oO0 - o0oO0 / Ooo0OO0oOO
  if not Oo0Ooo0O0 :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 49 - 49: O0oO + oO0o0ooO0 % OoOO - ii11ii1ii - O0 - OoooooooOO
   if 4 - 4: II111iiii - oO0o0ooO0 % ii11ii1ii * i11iIiiIii
  try :
   IiiIiiIi = Oo0Ooo0O0 . resolve ( )
   if not IiiIiiIi or not isinstance ( IiiIiiIi , basestring ) :
    try : i1iiIIIi = IiiIiiIi . msg
    except : i1iiIIIi = url
    raise Exception ( i1iiIIIi )
  except Exception as Ii1II1I11i1 :
   try : i1iiIIIi = str ( Ii1II1I11i1 )
   except : i1iiIIIi = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 18 - 18: ii11ii1ii % O0
  Ii1i1 = IiII1IiiIiI1 . getSetting ( 'notificar' )
  if Ii1i1 == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  II11 = xbmcgui . ListItem ( path = IiiIiiIi )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II11 )
  if 66 - 66: iIii1I11I1II1 % i11iIiiIii / OOooOOo
  if 47 - 47: o00O0oo * oO0o0ooO0 + iIii1I11I1II1 - oO0o0ooO0 / OoIii111II
 return
 if 86 - 86: OoIii111II
 if 43 - 43: OOooOOo / i11Ii11I1Ii1i / Ooo0OO0oOO + iIii1I11I1II1 + OoooooooOO
def iiI111i1 ( name , url ) :
 if 41 - 41: i11iIiiIii * O0 - i11Ii11I1Ii1i . II111iiii % OoOO % o00O0oo
 if 'mybox.com' in url :
  if 32 - 32: IIII + i11Ii11I1Ii1i + iIii1I11I1II1 * ii11ii1ii
  url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
  if 62 - 62: i11iIiiIii
  try :
   if 2 - 2: OOooOOo
   O00oO000O0O = I1i1i1iii ( url )
   I1111i = re . compile ( Iii1IIII11I ) . findall ( O00oO000O0O )
   for url , IIo0OoO00 , IIIIIiII1 in I1111i :
    if 69 - 69: OoooooooOO / ii11ii1ii * iii11
    IIo0OoO00 = IIo0OoO00 . replace ( '","res":"2160",' , ' 2160 ' ) . replace ( '","res":"1080",' , ' 1080' ) . replace ( '","res":"720",' , ' 720' ) . replace ( '","res":"480",' , ' 480' ) . replace ( '","res":"360",' , ' 360' )
    url = url . replace ( '\/' , '/' )
    url = url . replace ( ',"type":"video/mp4",' , ' ' )
    IIIIIiII1 = IIIIIiII1 . replace ( 'spa' , 'Castellano:' ) . replace ( 'eng' , 'Ingles:' ) . replace ( 'spa1' , 'Latino:' ) . replace ( 'eng2' , 'Americano:' )
    name = '[COLOR white]' + IIIIIiII1 + '[/COLOR] - [COLOR gold]' + IIo0OoO00 + '[/COLOR]'
    if 99 - 99: II111iiii * iIii1I11I1II1 % O0 * oO0o0ooO0 / II111iiii % OoooooooOO
    iiII = [ ]
    iiII . append ( '[COLOR orange]Real Stream: [/COLOR][COLOR gold]1. Mostrar mas info. [Reiniciar][/COLOR]' )
    iiII . append ( '[COLOR gold]2. Mostar otras calidades disponibles [/COLOR]' )
    iiII . append ( '[COLOR gold]3. Ver en: %s [/COLOR]' % name )
    if 14 - 14: OoIii111II . OoIii111II % Ooo0OO0oOO
    if 42 - 42: o0000oOoOoO0o . IIII - Ooo0OO0oOO
    o0O0ooOOoO = 'Seleccione una calidad e idioma:'
    iI = xbmcgui . Dialog ( )
    i11ii = iI . select ( o0O0ooOOoO , iiII )
    if 33 - 33: II111iiii / O0 / OoIii111II - O0oO - i1IIi
    if 8 - 8: i11iIiiIii . i11Ii11I1Ii1i / iIii1I11I1II1 / o00O0oo / OoIii111II - o0oO0
    if 32 - 32: o0000oOoOoO0o . i1IIi * ii11ii1ii
    if i11ii == 0 :
     if 98 - 98: o0oO0 - II111iiii / OOooOOo . oO0o0ooO0 * OoIii111II . O0oO
     OOoOOO000O0 = iI . ok ( "[COLOR darkpink]REALSTREAM:[/COLOR] " , "[COLOR gold]  Reiniciadas las opciones.  [/COLOR]" , "" )
     del iI
     return
     if 25 - 25: i11iIiiIii / OoOO0ooOOoo0O - iii11 / OoOO . o0000oOoOoO0o . o0000oOoOoO0o
    elif i11ii == 1 :
     if 6 - 6: oO0o0ooO0 . O0oO
     pass
     if 43 - 43: o00O0oo + o0000oOoOoO0o
     del iI
     if 50 - 50: oO0o0ooO0 % i1IIi * O0
     if 4 - 4: iIii1I11I1II1 . i1IIi
    elif i11ii == 2 :
     if 63 - 63: iIii1I11I1II1 + OoIii111II % i1IIi / OOooOOo % II111iiii
     i1iiI ( name , url )
     if 60 - 60: o0000oOoOoO0o . OoOO0ooOOoo0O % iii11 / OOooOOo / O0
     return
     if 19 - 19: i11iIiiIii . OOooOOo + II111iiii / IIII . o00O0oo * Ooo0OO0oOO
  except :
   pass
   if 59 - 59: iIii1I11I1II1 / o00O0oo % Ooo0OO0oOO
 elif 'uptostream.com' in url :
  if 84 - 84: iIii1I11I1II1 / OOooOOo . OoOO0ooOOoo0O % O0oO
  try :
   if 99 - 99: ii11ii1ii + i11iIiiIii
   O00oO000O0O = I1i1i1iii ( url )
   I1111i = re . compile ( Iii1IIII11I ) . findall ( O00oO000O0O )
   for url , IIo0OoO00 , IIIIIiII1 in I1111i :
    if 36 - 36: o0oO0 * iii11 * iIii1I11I1II1 - O0oO % i11iIiiIii
    IIo0OoO00 = IIo0OoO00 . replace ( '","res":"2160",' , ' ' ) . replace ( '","res":"1080",' , ' ' ) . replace ( '","res":"720",' , ' ' ) . replace ( '","res":"480",' , ' ' ) . replace ( '","res":"360",' , ' ' )
    url = url . replace ( '\/' , '/' )
    url = url . replace ( ',"type":"video/mp4",' , ' ' )
    IIIIIiII1 = IIIIIiII1 . replace ( 'spa' , 'Castellano:' ) . replace ( 'eng' , 'Ingles:' ) . replace ( 'spa1' , 'Latino:' ) . replace ( 'eng2' , 'Americano:' )
    name = '[COLOR white]' + IIIIIiII1 + '[/COLOR] - [COLOR gold]' + IIo0OoO00 + '[/COLOR]'
    if 98 - 98: iIii1I11I1II1 - i1IIi + Ooo0OO0oOO % O0oO + Ooo0OO0oOO / oO0o0ooO0
    iiII = [ ]
    iiII . append ( '[COLOR orange]Real Stream: [/COLOR][COLOR gold]1. Mostrar mas info. [Reiniciar][/COLOR]' )
    iiII . append ( '[COLOR gold]2. Mostar otras calidades disponibles [/COLOR]' )
    iiII . append ( '[COLOR gold]3. Ver en: %s [/COLOR]' % name )
    if 97 - 97: OoIii111II % Ooo0OO0oOO + II111iiii - OoIii111II % OoOO + Ooo0OO0oOO
    if 31 - 31: o0000oOoOoO0o
    o0O0ooOOoO = 'Seleccione una calidad e idioma:'
    iI = xbmcgui . Dialog ( )
    i11ii = iI . select ( o0O0ooOOoO , iiII )
    if 35 - 35: OoOO0ooOOoo0O + o0oO0 * Ooo0OO0oOO / OoOO0ooOOoo0O
    if 69 - 69: Ooo0OO0oOO . IIII - OOooOOo
    if i11ii == 0 :
     if 29 - 29: i11iIiiIii . o00O0oo / OOooOOo . IIII + i11iIiiIii
     OOoOOO000O0 = iI . ok ( "[COLOR darkpink]REALSTREAM:[/COLOR] " , "[COLOR gold]  Reiniciadas las opciones.  [/COLOR]" , "" )
     del iI
     return
     if 26 - 26: OoIii111II / o0oO0 - OoooooooOO
    elif i11ii == 1 :
     if 9 - 9: OoooooooOO * o00O0oo
     pass
     if 9 - 9: ii11ii1ii + i11Ii11I1Ii1i
     del iI
     if 64 - 64: O0 * OOooOOo / OOooOOo
     if 57 - 57: o00O0oo / OoooooooOO % o00O0oo . O0 / o00O0oo
     if 63 - 63: OoIii111II + iIii1I11I1II1 + OOooOOo + iii11
     if 72 - 72: OoOO + i11iIiiIii + o00O0oo
    elif i11ii == 2 :
     if 96 - 96: oO0o0ooO0 % i1IIi / o0000oOoOoO0o
     i1iiI ( name , url )
     if 13 - 13: II111iiii - ii11ii1ii % i11iIiiIii + i11Ii11I1Ii1i
     return
     if 88 - 88: O0 . oO0o0ooO0 % OOooOOo
  except :
   pass
 else :
  if 10 - 10: OOooOOo + O0
  Oo0ooOo0o = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
  O0O0ooOOO = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  oOOo0O00o = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( '\x62\x61\x73\x65\x36\x34' )
  ooO00O00oOO = IiII1IiiIiI1 . getSetting ( 'key_ext' )
  O00oO000O0O = I1i1i1iii ( oOOo0O00o )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
  for I1 in I1111i :
   if 75 - 75: O0 % iIii1I11I1II1 / OoOO0ooOOoo0O % IIII / OoIii111II
   try :
    if 31 - 31: i11iIiiIii * OoOO0ooOOoo0O
    if 69 - 69: i11iIiiIii
    Oo0ooOo0o = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
    if 61 - 61: O0
    if 21 - 21: OoOO % iIii1I11I1II1 . OoOO
    if Oo0ooOo0o == I1 :
     if 99 - 99: o0000oOoOoO0o * IIII % oO0o0ooO0 * oO0o0ooO0 + OoooooooOO
     if 82 - 82: O0oO / OoOO0ooOOoo0O - IIII / Ooo0OO0oOO
     if 'https://team.com' in url :
      if 50 - 50: IIII + OoOO . i11iIiiIii + o00O0oo + i11iIiiIii
      url = url . replace ( 'https://team.com' , 'https://verystream.com' )
      if 31 - 31: oO0o0ooO0 * iii11 . OoOO0ooOOoo0O * O0oO
     if 'https://mybox.com' in url :
      if 28 - 28: OoIii111II + OOooOOo - ii11ii1ii % IIII . O0oO + OOooOOo
      url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
      if 72 - 72: o0oO0 / ii11ii1ii / oO0o0ooO0 * OoOO0ooOOoo0O + IIII
      if 58 - 58: o0000oOoOoO0o % OOooOOo . OOooOOo * OoOO - OoIii111II . OoooooooOO
     if 'https://vidcloud.co/' in url :
      if 10 - 10: iii11
      url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
      if 48 - 48: i11Ii11I1Ii1i * i1IIi % OoooooooOO * o0oO0 * OoOO
     if 'https://gounlimited.to' in url :
      if 7 - 7: i11Ii11I1Ii1i . o0oO0 . i11Ii11I1Ii1i - iii11
      url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
      if 33 - 33: Ooo0OO0oOO + OoooooooOO - OoOO / i1IIi / OoooooooOO
     if 'https://drive.com' in url :
      if 82 - 82: o00O0oo / IIII - i11Ii11I1Ii1i / ii11ii1ii * OoOO
      url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
      if 55 - 55: OoooooooOO
      if 73 - 73: OoOO0ooOOoo0O - o00O0oo % ii11ii1ii + o00O0oo - O0 . OoOO
     import resolveurl
     if 38 - 38: O0
     Oo0Ooo0O0 = resolveurl . HostedMediaFile ( url )
     if 79 - 79: i1IIi . oO0o0ooO0
     if 34 - 34: iii11 * II111iiii
     if 71 - 71: OoIii111II
     if 97 - 97: o00O0oo
     if not Oo0Ooo0O0 :
      xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
      return False
      if 86 - 86: ii11ii1ii - IIII . OoOO0ooOOoo0O . II111iiii * OOooOOo . II111iiii
     try :
      if 34 - 34: o0000oOoOoO0o . iii11 % OoIii111II - O0 / iii11
      ooOoO00 = xbmcgui . DialogProgress ( )
      ooOoO00 . create ( 'Realstream:' , 'Iniciando ...' )
      ooOoO00 . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
      xbmc . sleep ( 1000 )
      if 91 - 91: i11iIiiIii % iii11 * oO0o0ooO0 - o00O0oo . iii11
      IiiIiiIi = Oo0Ooo0O0 . resolve ( )
      if not IiiIiiIi or not isinstance ( IiiIiiIi , basestring ) :
       if 28 - 28: i11iIiiIii
       try : i1iiIIIi = IiiIiiIi . msg
       except : i1iiIIIi = url
       raise Exception ( i1iiIIIi )
       if 51 - 51: OOooOOo + Ooo0OO0oOO * O0 . o0oO0
     except Exception as Ii1II1I11i1 :
      try : i1iiIIIi = str ( Ii1II1I11i1 )
      except : i1iiIIIi = url
      if 82 - 82: IIII * o00O0oo % o0oO0 . IIII
      if 43 - 43: OoOO . Ooo0OO0oOO * ii11ii1ii
      if 20 - 20: i1IIi . i1IIi - O0oO
      for O0o00ooo in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       iiiIIiiiI = 1
       ooOoO00 . update ( 45 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % O0o00ooo )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5  Puede cancelar cuando desee o esperar...,  1000)" % iiiIIiiiI )
       ooOoO00 . close ( )
       if 50 - 50: iii11 + O0oO / o0oO0 * IIII / o0000oOoOoO0o
      for O0o00ooo in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       iiiIIiiiI = 2
       ooOoO00 . update ( 48 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % O0o00ooo )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % iiiIIiiiI )
       ooOoO00 . close ( )
      for O0o00ooo in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       iiiIIiiiI = 3
       ooOoO00 . update ( 50 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % O0o00ooo )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % iiiIIiiiI )
       ooOoO00 . close ( )
      for O0o00ooo in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       iiiIIiiiI = 4
       ooOoO00 . update ( 53 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % O0o00ooo )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % iiiIIiiiI )
       ooOoO00 . close ( )
      for O0o00ooo in [ 0 , 1 , 2 , 3 , 4 , 5 ] :
       iiiIIiiiI = 5
       ooOoO00 . update ( 55 , 'RESOLVEURL: [COLOR orange]Reiniciando en:[/COLOR][COLOR yellow] %s Seg. [/COLOR] [COLOR blue]Puede cancelar en cualquier momento o esperar ...[/COLOR]' % O0o00ooo )
       xbmc . sleep ( 1000 )
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Intento %s de 5 Puede cancelar cuando desee o esperar...,  1000)" % iiiIIiiiI )
       ooOoO00 . close ( )
       if 27 - 27: O0 - O0oO * II111iiii - iIii1I11I1II1 / Ooo0OO0oOO
      if ooOoO00 . iscanceled ( ) :
       xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Cancelando !! , 2000)" )
       ooOoO00 . close ( )
       break
       if 24 - 24: ii11ii1ii / iIii1I11I1II1 % IIII * OoOO0ooOOoo0O - iIii1I11I1II1
       if 50 - 50: II111iiii
       if 39 - 39: II111iiii . OoOO0ooOOoo0O - ii11ii1ii * i1IIi . OoooooooOO
     ooOoO00 . update ( 60 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
     xbmc . sleep ( 500 )
     ooOoO00 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
     xbmc . sleep ( 1000 )
     ooOoO00 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
     ooOoO00 . close ( )
     Ii1i1 = IiII1IiiIiI1 . getSetting ( 'notificar' )
     II11 = xbmcgui . ListItem ( path = IiiIiiIi )
     xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II11 )
     if 44 - 44: OOooOOo
     if 55 - 55: oO0o0ooO0 . iii11 * iii11
    else :
     if 82 - 82: OOooOOo % OoOO % O0oO + O0oO
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold] El addon no ha podido conectar al servidor.[/COLOR]" )
     return False
     if 6 - 6: ii11ii1ii
   except :
    pass
    if 73 - 73: iii11 * o00O0oo + o0000oOoOoO0o - ii11ii1ii . O0oO
 return
 if 93 - 93: i11iIiiIii
def OoOiII11IiIi ( ) :
 if 27 - 27: OoOO + OoOO0ooOOoo0O
 ooo0oOooo0o0 = [ ]
 IIi = sys . argv [ 2 ]
 if len ( IIi ) >= 2 :
  i1Ii1i1ii1 = sys . argv [ 2 ]
  oOOoOOooO0 = i1Ii1i1ii1 . replace ( '?' , '' )
  if ( i1Ii1i1ii1 [ len ( i1Ii1i1ii1 ) - 1 ] == '/' ) :
   i1Ii1i1ii1 = i1Ii1i1ii1 [ 0 : len ( i1Ii1i1ii1 ) - 2 ]
  Iii1IIII1Iii = oOOoOOooO0 . split ( '&' )
  ooo0oOooo0o0 = { }
  for O0o00ooo in range ( len ( Iii1IIII1Iii ) ) :
   OOOOOOo0o0O0o = { }
   OOOOOOo0o0O0o = Iii1IIII1Iii [ O0o00ooo ] . split ( '=' )
   if ( len ( OOOOOOo0o0O0o ) ) == 2 :
    ooo0oOooo0o0 [ OOOOOOo0o0O0o [ 0 ] ] = OOOOOOo0o0O0o [ 1 ]
 return ooo0oOooo0o0
 if 8 - 8: o0000oOoOoO0o / o0000oOoOoO0o - O0oO + o0000oOoOoO0o * OoOO0ooOOoo0O . o0000oOoOoO0o
 if 45 - 45: II111iiii * i1IIi
def II1ii1 ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  pass
  if 89 - 89: o0000oOoOoO0o + IIII * oO0o0ooO0
def i1iI1IIi ( ) :
 iI = xbmcgui . Dialog ( )
 list = (
 iiI1I ,
 O0oooO00ooO0
 )
 if 99 - 99: OoIii111II
 OOO0o0 = iI . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=%s]Accede a themoviedb.com[/COLOR]' % I1III ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 90 - 90: Ooo0OO0oOO - O0oO . OoOO + OoOO
 if OOO0o0 :
  if 45 - 45: OoOO0ooOOoo0O / OoooooooOO . iii11 % O0 * o00O0oo * ii11ii1ii
  if OOO0o0 < 0 :
   return
  oOO0ooO = list [ OOO0o0 - 2 ]
  return oOO0ooO ( )
 else :
  oOO0ooO = list [ OOO0o0 ]
  return oOO0ooO ( )
 return
 if 57 - 57: i11Ii11I1Ii1i - OOooOOo + OoooooooOO / i11Ii11I1Ii1i . Ooo0OO0oOO % i1IIi
def OooooO0o0 ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 99 - 99: IIII * i1IIi . o0oO0 * iii11 . Ooo0OO0oOO
O0iI1I1ii11IIi1 = OooooO0o0 ( )
if 100 - 100: ii11ii1ii . o0oO0 . OOooOOo % II111iiii - oO0o0ooO0
def iiI1I ( ) :
 if O0iI1I1ii11IIi1 == 'android' :
  O0oOIiIII = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  O0oOIiIII = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 52 - 52: OOooOOo % OoOO * o0oO0 * i11Ii11I1Ii1i / IIII
  if 88 - 88: oO0o0ooO0
def O0oooO00ooO0 ( ) :
 if 1 - 1: ii11ii1ii
 main ( )
 if 95 - 95: OoooooooOO / O0oO % OoooooooOO / Ooo0OO0oOO * OoIii111II
 if 75 - 75: O0
 if 56 - 56: OoOO / II111iiii
def IIIiiiiI1 ( ) :
 iI = xbmcgui . Dialog ( )
 iii11i1 = (
 IIiI1I1IIiiI1 ,
 oooOOO0o0O0
 )
 if 31 - 31: OoooooooOO - oO0o0ooO0 / iii11
 OOO0o0 = iI . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 62 - 62: i11iIiiIii - O0oO
 if OOO0o0 :
  if 81 - 81: O0oO
  if OOO0o0 < 0 :
   return
  oOO0ooO = iii11i1 [ OOO0o0 - 2 ]
  return oOO0ooO ( )
 else :
  oOO0ooO = iii11i1 [ OOO0o0 ]
  return oOO0ooO ( )
 return
 if 92 - 92: IIII - ii11ii1ii - OoooooooOO / OoIii111II - i1IIi
def OooooO0o0 ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 81 - 81: i1IIi / iii11 % i11iIiiIii . iIii1I11I1II1 * OoOO0ooOOoo0O + OoooooooOO
O0iI1I1ii11IIi1 = OooooO0o0 ( )
if 31 - 31: i1IIi % II111iiii
def IIiI1I1IIiiI1 ( ) :
 if O0iI1I1ii11IIi1 == 'android' :
  O0oOIiIII = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  O0oOIiIII = webbrowser . open ( 'https://olpair.com/' )
  if 13 - 13: iIii1I11I1II1 - II111iiii % O0 . o0oO0 % OoOO
  if 2 - 2: OoooooooOO - o0oO0 % oO0o0ooO0 / OOooOOo / o0000oOoOoO0o
def oooOOO0o0O0 ( ) :
 if 3 - 3: II111iiii / IIII
 main ( )
 if 48 - 48: Ooo0OO0oOO . o00O0oo
 if 49 - 49: i1IIi - OoOO0ooOOoo0O . ii11ii1ii + iIii1I11I1II1 - Ooo0OO0oOO / ii11ii1ii
def iIi11ii1 ( name , url , id , trailer ) :
 iI = xbmcgui . Dialog ( )
 iii11i1 = (
 iII ,
 O0ooiIIi1 ,
 OoOo0O00 ,
 i1iI1IIi ,
 iI1i1iI1iI
 )
 if 18 - 18: O0oO + ii11ii1ii - OoOO / iii11 / IIII
 OOO0o0 = iI . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % I1III ,

 '[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % I1III ,

 '[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % I1III ,

 '[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % I1III ,

 '[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % I1III ] )
 if 53 - 53: IIII + o0000oOoOoO0o . oO0o0ooO0 / O0oO
 if OOO0o0 :
  if 52 - 52: iii11 + iii11
  if OOO0o0 < 0 :
   return
  oOO0ooO = iii11i1 [ OOO0o0 - 5 ]
  return oOO0ooO ( )
 else :
  oOO0ooO = iii11i1 [ OOO0o0 ]
  return oOO0ooO ( )
 return
 if 73 - 73: o0000oOoOoO0o . i11iIiiIii % OoooooooOO + Ooo0OO0oOO . OoooooooOO / IIII
 if 54 - 54: OoOO0ooOOoo0O . OoooooooOO
 if 36 - 36: oO0o0ooO0 / II111iiii * OoIii111II % o00O0oo
def iII ( ) :
 if 31 - 31: II111iiii + IIII - OoooooooOO . O0oO
 iiI111i1 ( i1I1i111Ii , ooo )
 if 28 - 28: o0oO0 . o00O0oo
def O0ooiIIi1 ( ) :
 if 77 - 77: o00O0oo % II111iiii
 oo0O00ooo0o ( i1I1i111Ii , i1i1iI1iiiI )
 if 81 - 81: OoOO0ooOOoo0O % o0oO0 / O0 * iIii1I11I1II1 % OoIii111II . OOooOOo
def OoOo0O00 ( ) :
 if 90 - 90: o0000oOoOoO0o
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  IIiII = id
  if 39 - 39: o0000oOoOoO0o / OoIii111II - i11Ii11I1Ii1i
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % IIiII )
  if 96 - 96: O0oO * o00O0oo * o0oO0 + o00O0oo % OOooOOo + i11iIiiIii
 if Ii1i1 == 'true' :
  if 37 - 37: O0oO % o00O0oo / Ooo0OO0oOO
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + i1I1i111Ii + "[/COLOR] ,5000)" )
  if 94 - 94: O0oO / OoOO . o0000oOoOoO0o
def iIi ( ) :
 if 93 - 93: II111iiii . i11iIiiIii + II111iiii % oO0o0ooO0
 i1iI1IIi ( )
 if 98 - 98: iii11 * oO0o0ooO0 * OoOO0ooOOoo0O + o0oO0 * i11Ii11I1Ii1i
def iI1i1iI1iI ( ) :
 if 4 - 4: OoIii111II
 i1iiIiI1Ii1i ( )
def II1IIIIiII1i ( name , url , mode , iconimage , fanart ) :
 if 16 - 16: iIii1I11I1II1 * i11Ii11I1Ii1i + oO0o0ooO0 . O0 . o0000oOoOoO0o
 II1i111 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 OOoOOO000O0 = True
 i1iiiIii11 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1iiiIii11 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 i1iiiIii11 . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  II1i111 = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  OOoOOO000O0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1i111 , listitem = i1iiiIii11 , isFolder = True )
  return OOoOOO000O0
 OOoOOO000O0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1i111 , listitem = i1iiiIii11 , isFolder = True )
 return OOoOOO000O0
 if 99 - 99: i11iIiiIii - i11Ii11I1Ii1i
def OO0o0oO ( name , url , mode , iconimage , fanart , description ) :
 if 85 - 85: iii11 % o00O0oo
 II1i111 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 OOoOOO000O0 = True
 i1iiiIii11 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1iiiIii11 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 i1iiiIii11 . setProperty ( 'fanart_image' , fanart )
 OOoOOO000O0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1i111 , listitem = i1iiiIii11 , isFolder = True )
 return OOoOOO000O0
 if 95 - 95: OoOO * IIII * i11Ii11I1Ii1i . o0000oOoOoO0o
def oooOo00 ( name , url , mode , iconimage ) :
 if 1 - 1: OOooOOo + o00O0oo
 II1i111 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 OOoOOO000O0 = True
 i1iiiIii11 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1iiiIii11 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 i1iiiIii11 . setProperty ( 'fanart_image' , Ooo )
 OOoOOO000O0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1i111 , listitem = i1iiiIii11 , isFolder = True )
 return OOoOOO000O0
 if 70 - 70: iIii1I11I1II1 + O0oO . o00O0oo / Ooo0OO0oOO
 if 77 - 77: ii11ii1ii / O0oO . i11Ii11I1Ii1i / iii11 - OoooooooOO
def i1ii1iIi ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 76 - 76: O0
 IiIIIi1iIi = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( '\x62\x61\x73\x65\x36\x34' )
 if 71 - 71: OOooOOo . i1IIi
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 O00o = [ ]
 if 19 - 19: II111iiii / II111iiii % o00O0oo + oO0o0ooO0 + oO0o0ooO0 + i11Ii11I1Ii1i
 O00o . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 II1i111 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 i1iiiIii11 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 i1iiiIii11 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 i1iiiIii11 . setProperty ( 'fanart_image' , fanart )
 i1iiiIii11 . setProperty ( 'IsPlayable' , 'true' )
 if 4 - 4: o0000oOoOoO0o + O0oO / i11Ii11I1Ii1i + i1IIi % o0000oOoOoO0o % i11Ii11I1Ii1i
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  O00o . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 80 - 80: o0oO0
  i1iiiIii11 . addContextMenuItems ( O00o , replaceItems = True )
 OOoOOO000O0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1i111 , listitem = i1iiiIii11 )
 return OOoOOO000O0
 if 26 - 26: iIii1I11I1II1 . OoooooooOO - iIii1I11I1II1
 if 59 - 59: o00O0oo + O0oO . oO0o0ooO0
def Ii1IiiiI1ii ( name , url , mode , iconimage , fanart , id , trailer , description ) :
 if 87 - 87: OoOO
 IiIIIi1iIi = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( '\x62\x61\x73\x65\x36\x34' )
 if 34 - 34: iii11 . OoOO0ooOOoo0O / i11iIiiIii / i11Ii11I1Ii1i
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 O00o = [ ]
 if 46 - 46: ii11ii1ii + II111iiii * OOooOOo + IIII
 O00o . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 II1i111 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 i1iiiIii11 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 i1iiiIii11 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 i1iiiIii11 . setProperty ( 'fanart_image' , fanart )
 i1iiiIii11 . setProperty ( 'IsPlayable' , 'true' )
 if 31 - 31: o0oO0 * o0000oOoOoO0o * o0oO0 + OoOO * o0000oOoOoO0o . iii11
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  O00o . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 89 - 89: OoooooooOO * o0oO0 * OOooOOo . Ooo0OO0oOO * o0oO0 / i11Ii11I1Ii1i
  i1iiiIii11 . addContextMenuItems ( O00o , replaceItems = True )
 OOoOOO000O0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1i111 , listitem = i1iiiIii11 )
 return OOoOOO000O0
 if 46 - 46: i11iIiiIii
def o00OOo00 ( name , url , mode , iconimage , fanart ) :
 if 15 - 15: O0 / i1IIi / i1IIi . i11Ii11I1Ii1i % OoOO0ooOOoo0O + OOooOOo
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 48 - 48: iii11 % i11Ii11I1Ii1i % o0oO0 % iIii1I11I1II1 . o0oO0
 II1i111 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 i1iiiIii11 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 i1iiiIii11 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 i1iiiIii11 . setProperty ( 'fanart_image' , fanart )
 i1iiiIii11 . setProperty ( 'IsPlayable' , 'true' )
 OOoOOO000O0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1i111 , listitem = i1iiiIii11 )
 return OOoOOO000O0
 if 14 - 14: i11Ii11I1Ii1i * OoOO % O0 + O0oO + o00O0oo
def III1I11Iiii ( name , url , mode , iconimage ) :
 if 44 - 44: OoOO - ii11ii1ii / i11Ii11I1Ii1i
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 4 - 4: OoooooooOO + i11Ii11I1Ii1i % O0 + iIii1I11I1II1 % i11Ii11I1Ii1i * i11iIiiIii
 II1i111 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 i1iiiIii11 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 i1iiiIii11 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 i1iiiIii11 . setProperty ( 'fanart_image' , Ooo )
 i1iiiIii11 . setProperty ( 'IsPlayable' , 'true' )
 OOoOOO000O0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1i111 , listitem = i1iiiIii11 )
 return OOoOOO000O0
 if 32 - 32: OoOO0ooOOoo0O + Ooo0OO0oOO + o0oO0 + OOooOOo
def I1IIIIII1 ( name , url , mode , iconimage ) :
 II1i111 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 OOoOOO000O0 = True
 i1iiiIii11 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 OOoOOO000O0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1i111 , listitem = i1iiiIii11 , isFolder = True )
 return OOoOOO000O0
 if 99 - 99: IIII + OOooOOo . o00O0oo * OoooooooOO
def OoooOO0 ( ) :
 if 69 - 69: II111iiii + i11Ii11I1Ii1i
 if 55 - 55: i11iIiiIii + OOooOOo
 if 64 - 64: i11iIiiIii + i1IIi % O0 . O0oO
 Iii1I1111ii = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 Iii1I1111ii . doModal ( )
 if ( Iii1I1111ii . isConfirmed ( ) ) :
  if 64 - 64: Ooo0OO0oOO / i1IIi % i11Ii11I1Ii1i
  I11I = urllib . quote_plus ( Iii1I1111ii . getText ( ) ) . replace ( '+' , ' ' )
  if 84 - 84: OoOO0ooOOoo0O - ii11ii1ii . Ooo0OO0oOO . OoIii111II - ii11ii1ii
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 99 - 99: iii11
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % I11I )
    if 75 - 75: Ooo0OO0oOO . IIII / OoIii111II
    if Ii1i1 == 'true' :
     if 84 - 84: OoooooooOO . OOooOOo / o0000oOoOoO0o
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + i1I1i111Ii + "[/COLOR] ,10000)" )
     if 86 - 86: ii11ii1ii % OoOO0ooOOoo0O
   except :
    if 77 - 77: o0oO0 % IIII / oO0o0ooO0
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 91 - 91: OoOO / OoOO . II111iiii . Ooo0OO0oOO - OOooOOo
    if 23 - 23: OOooOOo
i1Ii1i1ii1 = OoOiII11IiIi ( )
ooo = None
i1I1i111Ii = None
i1IIiI1iII = None
oOooOO = None
id = None
i1i1iI1iiiI = None
if 45 - 45: i1IIi % IIII % II111iiii
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 4 - 4: oO0o0ooO0 * OOooOOo - Ooo0OO0oOO / II111iiii + IIII / i11iIiiIii
try :
 ooo = urllib . unquote_plus ( i1Ii1i1ii1 [ "url" ] )
except :
 pass
try :
 i1I1i111Ii = urllib . unquote_plus ( i1Ii1i1ii1 [ "name" ] )
except :
 pass
try :
 i1IIiI1iII = int ( i1Ii1i1ii1 [ "mode" ] )
except :
 pass
try :
 oOooOO = urllib . unquote_plus ( i1Ii1i1ii1 [ "iconimage" ] )
except :
 pass
try :
 id = int ( i1Ii1i1ii1 [ "id" ] )
except :
 pass
try :
 i1i1iI1iiiI = urllib . unquote_plus ( i1Ii1i1ii1 [ "trailer" ] )
except :
 pass
 if 63 - 63: OoOO + Ooo0OO0oOO
 if 3 - 3: OoOO0ooOOoo0O - iii11 / oO0o0ooO0 . O0 * Ooo0OO0oOO / o00O0oo
print "Mode: " + str ( i1IIiI1iII )
print "URL: " + str ( ooo )
print "Name: " + str ( i1I1i111Ii )
print "iconimage: " + str ( oOooOO )
print "id: " + str ( id )
print "trailer: " + str ( i1i1iI1iiiI )
if 18 - 18: o0oO0
if 74 - 74: o0oO0 + o00O0oo + OOooOOo
def OOOoo0OO ( ) :
 if 37 - 37: OoIii111II
 try :
  if 97 - 97: o0000oOoOoO0o / OoIii111II + OoOO0ooOOoo0O + OoOO % iii11
  iIIi1II1 = I1i1i1iii ( OOOoo0OO )
  I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( iIIi1II1 )
  for OOo0o in I1111i :
   if 42 - 42: iIii1I11I1II1 - Ooo0OO0oOO - O0oO - iii11
   if OOo0o == 'si' :
    if 33 - 33: OoOO0ooOOoo0O - O0
    import resoveurl
    from resoveurl import common
    import random
    from random import choice
    III11iI1i11i = xbmc . Player ( )
    OOOO0OOoO0O0 = [ 'gtG1Y3_34ug' , '3d_ACcf0rDc' , 'AKpPeLAMY9I' , 'sVBa5hNZFHM' , '5ZCVhFmbAY0' ]
    IIiI = random . choice ( OOOO0OOoO0O0 )
    ooo = 'https://www.youtube.com/watch?v=%s' % IIiI
    ooo = resoveurl . HostedMediaFile ( ooo ) . resolve ( )
    III11iI1i11i . play ( ooo )
    if 99 - 99: o0000oOoOoO0o * oO0o0ooO0 . iii11 / OoOO0ooOOoo0O . Ooo0OO0oOO
    i111iIi1i1 == 'false'
    if 65 - 65: OoOO0ooOOoo0O . II111iiii % i11Ii11I1Ii1i + o0oO0
   else :
    if 37 - 37: oO0o0ooO0 - iIii1I11I1II1 + II111iiii . o0oO0 % iIii1I11I1II1
    i111iIi1i1 == 'false'
    if 17 - 17: iii11 + i1IIi % O0
    return False
    if 65 - 65: OoIii111II
 except :
  pass
  if 50 - 50: II111iiii / OoOO
  if 79 - 79: o00O0oo - iIii1I11I1II1 % i1IIi / ii11ii1ii + II111iiii
  if 95 - 95: oO0o0ooO0
if i1IIiI1iII == None or ooo == None or len ( ooo ) < 1 :
 if 48 - 48: O0oO / iIii1I11I1II1 % II111iiii
 Oo0ooOo0o = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
 O0O0ooOOO = '0110nhu' . replace ( '0110nhu' , 'nhu' )
 oOOo0O00o = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( '\x62\x61\x73\x65\x36\x34' )
 ooO00O00oOO = IiII1IiiIiI1 . getSetting ( 'key_ext' )
 O00oO000O0O = I1i1i1iii ( oOOo0O00o )
 I1111i = re . compile ( oOO0O00Oo0O0o ) . findall ( O00oO000O0O )
 for I1 in I1111i :
  if 39 - 39: i1IIi . o00O0oo / O0oO / O0oO
  try :
   if 100 - 100: OoooooooOO - OoooooooOO + OoIii111II
   if 32 - 32: OoOO0ooOOoo0O * o0000oOoOoO0o / OoooooooOO
   Oo0ooOo0o = IiII1IiiIiI1 . getSetting ( 'licencia_addon' )
   if 90 - 90: iii11
   if 35 - 35: II111iiii / o0oO0
   if Oo0ooOo0o == I1 :
    if 79 - 79: OoOO0ooOOoo0O + iii11 * i11Ii11I1Ii1i * o0oO0
    if 53 - 53: IIII / ii11ii1ii
    Iii1iI ( )
    i1iiIiI1Ii1i ( )
    if 10 - 10: o00O0oo . o0000oOoOoO0o
    i111iIi1i1 = IiII1IiiIiI1 . getSetting ( 'videos_event' )
    if i111iIi1i1 == 'true' :
     xbmc . sleep ( 3000 )
     OOOoo0OO ( )
     if 75 - 75: O0 * i1IIi - O0oO / IIII % IIII / OoOO0ooOOoo0O
   else :
    if 5 - 5: O0 - i11Ii11I1Ii1i / iii11 . o0000oOoOoO0o
    I1III = IiII1IiiIiI1 . getSetting ( 'MenuColor' )
    if 7 - 7: o00O0oo - OoOO0ooOOoo0O
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Por favor compruebe los ajustes de realstream.[/COLOR]" , "[COLOR white] Desde la seccion Tutoriales puede sacarle mayor partido a su Realstream, tambien puede configurarlo a su gusto. [/COLOR]" , "[COLOR gold]El addon no esta activado o bien configurado.[/COLOR]" )
    if 54 - 54: oO0o0ooO0 / iIii1I11I1II1 / OoooooooOO . i1IIi - OoOO0ooOOoo0O
  except :
   pass
   if 57 - 57: iIii1I11I1II1 * o0oO0 * i11Ii11I1Ii1i / oO0o0ooO0
elif i1IIiI1iII == 1 :
 iIi11ii1 ( i1I1i111Ii , ooo , id , i1i1iI1iiiI )
elif i1IIiI1iII == 2 :
 ooOoOO ( )
elif i1IIiI1iII == 3 :
 IiiiI ( )
elif i1IIiI1iII == 4 :
 iiII1IIii1i1 ( i1I1i111Ii , ooo )
elif i1IIiI1iII == 5 :
 O0000oO0o00 ( )
elif i1IIiI1iII == 6 :
 o0OO0O0OO0oO0 ( )
elif i1IIiI1iII == 7 :
 Iii1I ( )
elif i1IIiI1iII == 8 :
 Ii ( )
elif i1IIiI1iII == 9 :
 OOo00ooOoO0o ( )
elif i1IIiI1iII == 10 :
 o0oo0o00ooO00 ( )
elif i1IIiI1iII == 11 :
 iiI1ii ( )
elif i1IIiI1iII == 12 :
 i11iioOOOOO0Ooooo ( )
elif i1IIiI1iII == 13 :
 oo0o ( )
elif i1IIiI1iII == 14 :
 Ii11 ( )
elif i1IIiI1iII == 15 :
 ii11i ( )
elif i1IIiI1iII == 16 :
 oOo ( )
elif i1IIiI1iII == 17 :
 oOoOo0o00o ( )
elif i1IIiI1iII == 18 :
 I1i1I11111iI1 ( )
elif i1IIiI1iII == 19 :
 IIIIIiiiiI1I ( )
elif i1IIiI1iII == 20 :
 III1ii ( )
elif i1IIiI1iII == 21 :
 O000oooOO0Oo0 ( )
elif i1IIiI1iII == 22 :
 I111 ( )
elif i1IIiI1iII == 23 :
 OOO00o0 ( )
elif i1IIiI1iII == 24 :
 iIii11iI1II ( )
elif i1IIiI1iII == 25 :
 II11iIi ( )
elif i1IIiI1iII == 26 :
 oO0OO ( )
elif i1IIiI1iII == 28 :
 O0ooOoO ( i1I1i111Ii , ooo )
elif i1IIiI1iII == 29 :
 o0Oo0oO00OOO ( )
elif i1IIiI1iII == 30 :
 II1IIi ( )
elif i1IIiI1iII == 31 :
 prueba ( )
elif i1IIiI1iII == 98 :
 busqueda_global ( )
elif i1IIiI1iII == 97 :
 IIIiiiiI1 ( )
elif i1IIiI1iII == 99 :
 oo0oO0oO ( )
elif i1IIiI1iII == 100 :
 menu_player ( i1I1i111Ii , ooo )
elif i1IIiI1iII == 111 :
 OoiIIiIi1 ( )
elif i1IIiI1iII == 115 :
 oo0O00ooo0o ( ooo )
elif i1IIiI1iII == 116 :
 oOOOOoo ( )
elif i1IIiI1iII == 117 :
 iI11I ( )
elif i1IIiI1iII == 119 :
 OOo00OoO ( )
elif i1IIiI1iII == 120 :
 oOO00O0Ooooo00 ( )
elif i1IIiI1iII == 121 :
 oo00O00oO000o ( )
elif i1IIiI1iII == 125 :
 IiiiI1 ( )
elif i1IIiI1iII == 112 :
 list_proxy ( )
elif i1IIiI1iII == 127 :
 OoooOO0 ( )
elif i1IIiI1iII == 128 :
 TESTLINKS ( )
elif i1IIiI1iII == 130 :
 iiI111i1 ( i1I1i111Ii , ooo )
elif i1IIiI1iII == 140 :
 Ooooooo ( )
elif i1IIiI1iII == 141 :
 oo0 ( )
elif i1IIiI1iII == 142 :
 o00O ( )
elif i1IIiI1iII == 143 :
 O0ooOo0o0Oo ( i1I1i111Ii , ooo )
elif i1IIiI1iII == 144 :
 O0ooOoO ( i1I1i111Ii , ooo )
elif i1IIiI1iII == 145 :
 o0oO00 ( )
elif i1IIiI1iII == 146 :
 O00oOoo0OoO0 ( )
elif i1IIiI1iII == 147 :
 I1iIII1IiiI ( i1I1i111Ii , ooo )
elif i1IIiI1iII == 150 :
 IIiI1I1 ( )
elif i1IIiI1iII == 151 :
 iiIII1II ( )
elif i1IIiI1iII == 152 :
 oooOOOO0oooo ( )
elif i1IIiI1iII == 155 :
 O000o0 ( )
 if 46 - 46: o0oO0
xbmcplugin . endOfDirectory ( o0OoOoOO00 ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
