# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 0.9.6
#
############################################
# Dependencias 
# Script ExtendedInfo
# Script Urlresolver de TVAddons
# Script ResolveURL Por Jsergio.
#
############################################
#
# Corregido imcompatibilidad con Servidor Team
# Agregados nuevos iconos, ahora se puede el aspecto desde ajustes del addon.
#
############################################
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import cookielib , webbrowser
import traceback , datetime , HTMLParser , httplib
import urlresolver
import cookielib , base64
import requests
import plugintools
import config
oo000 = xbmcaddon . Addon ( 'plugin.video.Real.stream' )
ii = oo000 . getAddonInfo ( 'version' )
oOOo = int ( sys . argv [ 1 ] )
O0 = 'gruponetai/'
o0O = xbmcaddon . Addon ( id = 'plugin.video.Real.stream' )
iI11I1II1I1I = o0O . getAddonInfo ( 'profile' )
oooo = o0O . getAddonInfo ( 'path' )
iIIii1IIi = oo000 . getSetting ( 'iconos' )
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if iIIii1IIi == 'true' :
 if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
 O0oOO0o0 = xbmc . translatePath ( os . path . join ( oooo , 'fanart.png' ) )
 i1ii1iIII = xbmc . translatePath ( os . path . join ( oooo , 'icon.png' ) )
 Oo0oO0oo0oO00 = xbmc . translatePath ( os . path . join ( oooo , 'extended_info.png' ) )
 i111I = xbmc . translatePath ( os . path . join ( oooo , 'buscar.png' ) )
 II1Ii1iI1i = xbmc . translatePath ( os . path . join ( oooo , 'pair.png' ) )
 iiI1iIiI = xbmc . translatePath ( os . path . join ( oooo , 'theMovieDB.png' ) )
 OOo = xbmc . translatePath ( os . path . join ( oooo , 'novedades.png' ) )
 Ii1IIii11 = xbmc . translatePath ( os . path . join ( oooo , 'estrenos.png' ) )
 Oooo0000 = xbmc . translatePath ( os . path . join ( oooo , 'recomendadas.png' ) )
 i11 = xbmc . translatePath ( os . path . join ( oooo , 'accion.png' ) )
 I11 = xbmc . translatePath ( os . path . join ( oooo , 'animacion.png' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( oooo , 'aventuras.png' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( oooo , 'belico.png' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( oooo , 'ciencia-ficcion.png' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( oooo , 'clasicos.png' ) )
 oO = xbmc . translatePath ( os . path . join ( oooo , 'comedia.png' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( oooo , 'crimen.png' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( oooo , 'drama.png' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( oooo , 'familiar.png' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( oooo , 'fantasia.png' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( oooo , 'historia.png' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( oooo , 'marvel.png' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( oooo , 'misterio.png' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( oooo , 'musical.png' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( oooo , 'romance.png' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( oooo , 'spain.png' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( oooo , 'suspense.png' ) )
 II = xbmc . translatePath ( os . path . join ( oooo , 'terror.png' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( oooo , 'thriller.png' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( oooo , 'western.png' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( oooo , 'sagas_cine.png' ) )
 OO0o = xbmc . translatePath ( os . path . join ( oooo , '4k.png' ) )
 Ooo = xbmc . translatePath ( os . path . join ( oooo , 'torrent.png' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( oooo , 'buscar-serie.jpg' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( oooo , 'series-todas.jpg' ) )
 O0O = xbmc . translatePath ( os . path . join ( oooo , 'favorites.png' ) )
 O00o0OO = xbmc . translatePath ( os . path . join ( oooo , 'artesmarciales.png' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( oooo , 'emision.png' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( oooo , 'mejores.png' ) )
 if 71 - 71: oO00OO0oo0 . III1i1i
else :
 if 26 - 26: i1iiI11I
 if 29 - 29: iiIi
 O00o0OO = xbmc . translatePath ( os . path . join ( oooo , 'artesmarciales.png' ) )
 iIIii1IIi = oo000 . getSetting ( 'iconos' )
 O0oOO0o0 = xbmc . translatePath ( os . path . join ( oooo , 'fanart.jpg' ) )
 i1ii1iIII = xbmc . translatePath ( os . path . join ( oooo , 'icon.png' ) )
 Oo0oO0oo0oO00 = xbmc . translatePath ( os . path . join ( oooo , 'extended_info.png' ) )
 i111I = xbmc . translatePath ( os . path . join ( oooo , 'buscar.png' ) )
 II1Ii1iI1i = xbmc . translatePath ( os . path . join ( oooo , 'pair.png' ) )
 iiI1iIiI = xbmc . translatePath ( os . path . join ( oooo , 'theMovieDB.jpg' ) )
 OOo = xbmc . translatePath ( os . path . join ( oooo , 'novedades.jpg' ) )
 Ii1IIii11 = xbmc . translatePath ( os . path . join ( oooo , 'encines.jpg' ) )
 Oooo0000 = xbmc . translatePath ( os . path . join ( oooo , 'recomendadas.jpg' ) )
 i11 = xbmc . translatePath ( os . path . join ( oooo , 'accion.jpg' ) )
 I11 = xbmc . translatePath ( os . path . join ( oooo , 'animacion.jpg' ) )
 Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( oooo , 'aventuras.jpg' ) )
 oOo0oooo00o = xbmc . translatePath ( os . path . join ( oooo , 'belico.jpg' ) )
 oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( oooo , 'ciencia-ficcion.jpg' ) )
 oo0o0O00 = xbmc . translatePath ( os . path . join ( oooo , 'clasicos.png' ) )
 oO = xbmc . translatePath ( os . path . join ( oooo , 'comedia.jpg' ) )
 i1iiIIiiI111 = xbmc . translatePath ( os . path . join ( oooo , 'crimen.jpg' ) )
 oooOOOOO = xbmc . translatePath ( os . path . join ( oooo , 'drama.jpg' ) )
 i1iiIII111ii = xbmc . translatePath ( os . path . join ( oooo , 'familiar.jpg' ) )
 i1iIIi1 = xbmc . translatePath ( os . path . join ( oooo , 'fantasia.jpg' ) )
 ii11iIi1I = xbmc . translatePath ( os . path . join ( oooo , 'historia.jpg' ) )
 iI111I11I1I1 = xbmc . translatePath ( os . path . join ( oooo , 'superheroes.jpg' ) )
 OOooO0OOoo = xbmc . translatePath ( os . path . join ( oooo , 'misterio.jpg' ) )
 iIii1 = xbmc . translatePath ( os . path . join ( oooo , 'musical.jpg' ) )
 oOOoO0 = xbmc . translatePath ( os . path . join ( oooo , 'romance.jpg' ) )
 O0OoO000O0OO = xbmc . translatePath ( os . path . join ( oooo , 'spain.jpg' ) )
 iiI1IiI = xbmc . translatePath ( os . path . join ( oooo , 'suspense.jpg' ) )
 II = xbmc . translatePath ( os . path . join ( oooo , 'terror.jpg' ) )
 ooOoOoo0O = xbmc . translatePath ( os . path . join ( oooo , 'thriller.jpg' ) )
 OooO0 = xbmc . translatePath ( os . path . join ( oooo , 'western.jpg' ) )
 II11iiii1Ii = xbmc . translatePath ( os . path . join ( oooo , 'sagas_cine.jpg' ) )
 OO0o = xbmc . translatePath ( os . path . join ( oooo , '4k.jpg' ) )
 Ooo = xbmc . translatePath ( os . path . join ( oooo , 'torrent.jpg' ) )
 O0o0Oo = xbmc . translatePath ( os . path . join ( oooo , 'buscar-serie.jpg' ) )
 Oo00OOOOO = xbmc . translatePath ( os . path . join ( oooo , 'series-todas.jpg' ) )
 I11i1 = xbmc . translatePath ( os . path . join ( oooo , 'emision.png' ) )
 iIi1ii1I1 = xbmc . translatePath ( os . path . join ( oooo , 'mejores.jpg' ) )
 O0O = xbmc . translatePath ( os . path . join ( oooo , 'favoritos.png' ) )
 if 98 - 98: Oo0Ooo % I11i * iII111i * I11i
 if 45 - 45: i1iiI11I . I11i
 if 83 - 83: IiII . Oo0Ooo . iII111i
I1I = xbmc . translatePath ( os . path . join ( oooo , 'peliculas.png' ) )
oOO00oOO = xbmc . translatePath ( os . path . join ( oooo , 'series.png' ) )
OoOo = xbmc . translatePath ( os . path . join ( oooo , 'ajustes.png' ) )
iI = xbmc . translatePath ( os . path . join ( oooo , 'videoteca.png' ) )
o00O = xbmc . translatePath ( os . path . join ( oooo , 'favorites.png' ) )
OOO0OOO00oo = xbmc . translatePath ( os . path . join ( oooo , 'resolver.png' ) )
Iii111II = xbmc . translatePath ( os . path . join ( oooo , 'test.png' ) )
iiii11I = xbmc . translatePath ( os . path . join ( oooo , 'video-tutoriales.png' ) )
Ooo0OO0oOO = xbmc . translatePath ( os . path . join ( oooo , 'proxy.png' ) )
if 50 - 50: I1ii11iIi11i
Ii1i11IIii1I = oo000 . getSetting ( 'mostrar_cat' )
OOOoO0O0o = oo000 . getSetting ( 'videos' )
O0o0Ooo = oo000 . getSetting ( 'activar' )
O00 = oo000 . getSetting ( 'favcopy' )
iI1Ii11iII1 = oo000 . getSetting ( 'anticopia' )
Oo0O0O0ooO0O = oo000 . getSetting ( 'licencia_addon' )
IIIIii = oo000 . getSetting ( 'notificar' )
O0o0 = oo000 . getSetting ( 'mostrar_bus' )
OO00Oo = oo000 . getSetting ( 'restante' )
O0OOO0OOoO0O = oo000 . getSetting ( 'selecton' )
O00Oo000ooO0 = oo000 . getSetting ( 'aviso' )
OoO0O00IIiII = oo000 . getSetting ( 'RealStream_Settings' )
o0 = oo000 . getSetting ( 'Resolver_Settings' )
OO00Oo = oo000 . getSetting ( 'restante' )
ooOooo000oOO = oo000 . getSetting ( 'fav' )
Oo0oOOo = oo000 . getSetting ( 'Fontcolor' )
Oo0OoO00oOO0o = oo000 . getSetting ( 'MenuColor' )
OOO00O = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v' . decode ( 'base64' )
OOoOO0oo0ooO = 'bienvenida'
O0o0O00Oo0o0 = 'bienvenida'
copyright = oo000 . getSetting ( 'copyright' )
O00O0oOO00O00 = 'cGx1Z2luLnZpZGVvLg==' . decode ( 'base64' ) + copyright
i1 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
Oo00 = oo000 . getSetting ( 'Forceupdate' )
if Oo00 == 'true' :
 xbmc . executebuiltin ( 'UpdateAddonRepos()' )
 xbmc . executebuiltin ( 'UpdateLocalAddons()' )
i1i = 'LnR4dA==' . decode ( 'base64' )
if 50 - 50: III1i1i
i11I1iIiII = 'aHR0cDovL2JpdC5seS8yU1FOSnlP' . decode ( 'base64' )
oO00o0 = OOO00O + OOoOO0oo0ooO + i1i
OOoo0O = 'http://www.youtube.com'
Oo0ooOo0o = 'aHR0cDovL3kzei5zag==' . decode ( 'base64' )
Ii1i1 = '.xsl.pt'
iiIii = 'L21hc3Rlci8=' . decode ( 'base64' )
ooo0O = Oo0ooOo0o + Ii1i1
oOoO0o00OO0 = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*texto3=[\'"](.*?)[\'"]\s*'
i1I1ii = 'tvg-logo=[\'"](.*?)[\'"]'
if 61 - 61: o0oOOo0O0Ooo
O0OOO = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)'
II11iIiIIIiI = '(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)'
o0o = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
o00 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
OooOO000 = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
OOoOoo = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
oO0000OOo00 = '#(.+?),(.+)\s*(.+)'
iiIi1IIiIi = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
if 75 - 75: I1ii11iIi11i + oO0o
OoooO0oO = 'source src=[\'"](.*?)[\'"]\s*title=[\'"](.*?)[\'"]'
i1iIi = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
ooOOoooooo = '[\'"](.*?)[\'"]'
II1I = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
O0i1II1Iiii1I11 = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw==' . decode ( 'base64' )
IIII = O0i1II1Iiii1I11 + O0
iiIiI = '[\'"](.*?)[\'"]'
o00oooO0Oo = 'UmVhbHN0cmVhbQ==' . decode ( 'base64' )
o0O0OOO0Ooo = 'video=[\'"](.*?)[\'"]'
iiIiII1 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
OOO00O0O = 'aHR0cDovL2JpdC5seS8yUjQx' . decode ( 'base64' ) + iiIiII1
iii = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
oOooOOOoOo = '0110R0N' . replace ( '0110R0N' , 'R0N' )
i1Iii1i1I = 'aHR0cDovL2JpdC5seS8yWEIx' . decode ( 'base64' ) + oOooOOOoOo
OOoO00 = '0110pEJ' . replace ( '0110pEJ' , 'pEJ' )
IiI111111IIII = 'aHR0cDovL2JpdC5seS8yd1Nh' . decode ( 'base64' ) + OOoO00
i1Ii = 'ABBAOb5' . replace ( 'ABBAOb5' , 'Ob5' )
ii111iI1iIi1 = 'aHR0cDovL2JpdC5seS8yRVhV' . decode ( 'base64' ) + i1Ii
OOO = '0110jaw' . replace ( '0110jaw' , 'jaw' )
oo0OOo0 = 'aHR0cDovL2JpdC5seS8yd01M' . decode ( 'base64' ) + OOO
I11IiI = '01109DI' . replace ( '01109DI' , '9DI' )
O0ooO0Oo00o = 'aHR0cDovL2JpdC5seS8ySXgz' . decode ( 'base64' ) + I11IiI
ooO0oOOooOo0 = '01103hs' . replace ( '01103hs' , '3hs' )
i1I1ii11i1Iii = 'aHR0cDovL2JpdC5seS8zMW1U' . decode ( 'base64' ) + ooO0oOOooOo0
I1IiiiiI = '01107DW' . replace ( '01107DW' , '7DW' )
o0OIiII = 'aHR0cDovL2JpdC5seS8yV1ln' . decode ( 'base64' ) + I1IiiiiI
ii1iII1II = '0110mLl' . replace ( '0110mLl' , 'mLl' )
Iii1I1I11iiI1 = 'aHR0cDovL2JpdC5seS8yS0cw' . decode ( 'base64' ) + ii1iII1II
I1I1i1I = '01102Hj' . replace ( '01102Hj' , '2Hj' )
ii1I = 'aHR0cDovL2JpdC5seS8yWEJo' . decode ( 'base64' ) + I1I1i1I
O0oO0 = '0110fXg' . replace ( '0110fXg' , 'fXg' )
oO0 = 'aHR0cDovL2JpdC5seS8ySTVy' . decode ( 'base64' ) + O0oO0
O0OO0O = '0110NMH' . replace ( '0110NMH' , 'NMH' )
OO = 'aHR0cDovL2JpdC5seS8yd0t6' . decode ( 'base64' ) + O0OO0O
OoOoO = '0110bwQ' . replace ( '0110bwQ' , 'bwQ' )
Ii1I1i = 'aHR0cDovL2JpdC5seS8yd01V' . decode ( 'base64' ) + OoOoO
OOI1iI1ii1II = '0110xzG' . replace ( '0110xzG' , 'xzG' )
O0O0OOOOoo = 'aHR0cDovL2JpdC5seS8yWHhz' . decode ( 'base64' ) + OOI1iI1ii1II
oOooO0 = '0110x64' . replace ( '0110x64' , 'x64' )
Ii1I1Ii = 'aHR0cDovL2JpdC5seS8yRVlF' . decode ( 'base64' ) + oOooO0
OOoO0 = '0110vUE' . replace ( '0110vUE' , 'vUE' )
OO0Oooo0oOO0O = 'aHR0cDovL2JpdC5seS8yWmhW' . decode ( 'base64' ) + OOoO0
o00O0 = '01107ZL' . replace ( '01107ZL' , '7ZL' )
oOO0O00Oo0O0o = 'aHR0cDovL2JpdC5seS8yWm4w' . decode ( 'base64' ) + o00O0
ii1 = '01106cf' . replace ( '01106cf' , '6cf' )
I1iIIiiIIi1i = 'aHR0cDovL2JpdC5seS8yRVlk' . decode ( 'base64' ) + ii1
O0O0ooOOO = '0110Jtp' . replace ( '0110Jtp' , 'Jtp' )
oOOo0O00o = 'aHR0cDovL2JpdC5seS8yV3Nq' . decode ( 'base64' ) + O0O0ooOOO
iIiIi11 = '0110a5b' . replace ( '0110a5b' , 'a5b' )
OOOiiiiI = 'aHR0cDovL2JpdC5seS8yV3dj' . decode ( 'base64' ) + iIiIi11
oooOo0OOOoo0 = '0110Q7u' . replace ( '0110Q7u' , 'Q7u' )
OOoO = 'aHR0cDovL2JpdC5seS8yV3NL' . decode ( 'base64' ) + oooOo0OOOoo0
OO0O000 = '0110rsq' . replace ( '0110rsq' , 'rsq' )
iiIiI1i1 = 'aHR0cDovL2JpdC5seS8ySzhE' . decode ( 'base64' ) + OO0O000
oO0O00oOOoooO = '0110DDR' . replace ( '0110DDR' , 'DDR' )
IiIi11iI = 'aHR0cDovL2JpdC5seS8ySzd5' . decode ( 'base64' ) + oO0O00oOOoooO
Oo0O00O000 = '0110feQ' . replace ( '0110feQ' , 'feQ' )
i11I1IiII1i1i = 'aHR0cDovL2JpdC5seS8yS0cz' . decode ( 'base64' ) + Oo0O00O000
oo = '0110MHY' . replace ( '0110MHY' , 'MHY' )
I1111i = 'aHR0cDovL2JpdC5seS8ySXVo' . decode ( 'base64' ) + oo
iIIii = '0110xdb' . replace ( '0110xdb' , 'xdb' )
o00O0O = 'aHR0cDovL2JpdC5seS8yWEJu' . decode ( 'base64' ) + iIIii
ii1iii1i = 'aHR0cDovL2JpdC5seS8yS0pZZVVp' . decode ( 'base64' )
O00O0oOO00O00 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
Iii1I1111ii = '0110lxu' . replace ( '0110lxu' , 'lxu' )
ooOoO00 = 'aHR0cDovL2JpdC5seS8yV1Bj' . decode ( 'base64' ) + Iii1I1111ii
Ii1IIiI1i = '0110pzp' . replace ( '0110pzp' , 'pzp' )
o0O00Oo0 = 'aHR0cDovL2JpdC5seS8yVHpB' . decode ( 'base64' ) + Ii1IIiI1i
IiII111i1i11 = '01105yt' . replace ( '01105yt' , '5yt' )
i111iIi1i1II1 = 'aHR0cDovL2JpdC5seS8yTVpp' . decode ( 'base64' ) + IiII111i1i11
if 86 - 86: Oo0Ooo / I11i . o0oOOo0O0Ooo
II1i111Ii1i = '1001DTs' . replace ( '1001DTs' , 'DTs' )
iii1 = 'aHR0cDovL2JpdC5seS8ySzhP' . decode ( 'base64' ) + II1i111Ii1i
ooO0oooOO0 = '1001Hky' . replace ( '1001Hky' , 'Hky' )
o0ooo0 = 'aHR0cDovL2JpdC5seS8yTGVL' . decode ( 'base64' ) + ooO0oooOO0
oOOOoo00 = '1001VFU' . replace ( '1001VFU' , 'VFU' )
iiIiIIIiiI = 'aHR0cDovL2JpdC5seS8zMERx' . decode ( 'base64' ) + oOOOoo00
if 12 - 12: I1IiiI - Ii1I
def oOoO00O0 ( ) :
 if 75 - 75: I1ii11iIi11i . iiIi . I1IiiI * i1iiI11I
 if 4 - 4: o00O0oo % IiII * OOooOOo
 try :
  if 100 - 100: i1iiI11I * I1Ii111 + I1Ii111
  OoOO0o = i1II1 ( i1Iii1i1I )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   try :
    if 87 - 87: Ii1I
    IiI111111IIII = IiiiiI1i1Iii
    if 29 - 29: I1ii11iIi11i % I1Ii111 - I1ii11iIi11i / I1Ii111 . OoOoOO00
    i11III1111iIi = xbmc . Keyboard ( '' , 'Busqueda por titulo' )
    i11III1111iIi . doModal ( )
    if ( i11III1111iIi . isConfirmed ( ) ) :
     if 38 - 38: oO00OO0oo0 + ooOoO0o / i1iiI11I % iiIi - iII111i
     iI11 = urllib . quote_plus ( i11III1111iIi . getText ( ) ) . replace ( '+' , ' ' )
     Ii1Io0OO0o0o00o = i1II1 ( IiI111111IIII )
     i11i1 = re . compile ( O0OOO ) . findall ( Ii1Io0OO0o0o00o )
     if 100 - 100: IiII / i1iiI11I / iII111i
     for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
      if re . search ( iI11 , o0OO0o0oOOO0O ( OOOooo . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
       if 81 - 81: I1IiiI . OoO0O00 . oO00OO0oo0 - oO0o / OOooOOo + iII111i
   except :
    pass
 except :
  pass
def o0O00oOOoo ( ) :
 if 18 - 18: o00O0oo + III1i1i - I1IiiI
 if 53 - 53: OoOoOO00
 Ooo00Oo = i1II1 ( ii1iii1i )
 i11i1 = re . compile ( ooOOoooooo ) . findall ( Ooo00Oo )
 for oO00Oooo0O0o0 in i11i1 :
  try :
   if 14 - 14: Ii1I % I1IiiI * oO00OO0oo0 + o00O0oo + oO0o * o00O0oo
   import xbmc
   import xbmcaddon
   if 3 - 3: I11i * oO0o
   __addon__ = xbmcaddon . Addon ( )
   __addonname__ = __addon__ . getAddonInfo ( 'name' )
   __icon__ = __addon__ . getAddonInfo ( 'icon' )
   if 95 - 95: I1Ii111 % IiII . o00O0oo
   ii = oo000 . getAddonInfo ( 'version' )
   if 72 - 72: OoO0O00
   OooooOoooO = "[COLOR orange]Version instalada Actualmente: [COLOR gold] " + ii + " [/COLOR][/COLOR]" "[COLOR white]Disponible la version:  [COLOR lime]  "  + oO00Oooo0O0o0 +  "  [/COLOR][/COLOR]"
   oOIIiIi = 5000
   if 91 - 91: iII111i * oO0o / I1ii11iIi11i . I1IiiI + OOooOOo + I11i
   xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , OooooOoooO , oOIIiIi , __icon__ ) )
   if 8 - 8: IiII / iII111i
   if 20 - 20: I1ii11iIi11i
  except :
   pass
   if 95 - 95: oO00OO0oo0 - I1ii11iIi11i
   if 34 - 34: iiIi * I1ii11iIi11i . OoOoOO00 * iiIi / iiIi
def IIiI1Ii ( ) :
 if 57 - 57: I1Ii111 - iiIi - ooOoO0o + OOooOOo
 O00Oo000ooO0 = oo000 . getSetting ( 'aviso' )
 if O00Oo000ooO0 == 'true' :
  OoOO0o = i1II1 ( oO00o0 )
  i11i1 = re . compile ( oOoO0o00OO0 ) . findall ( OoOO0o )
  for I1IIIiI11i1 , i11I1I1I , oOOOo00O00O in i11i1 :
   try :
    if 2 - 2: Ii1I - iII111i
    if 58 - 58: o00O0oo + Ii1I - I1ii11iIi11i
    i1i1ii = I1IIIiI11i1
    iII1ii1 = i11I1I1I
    I1i1iiiI1 = oOOOo00O00O
    if 24 - 24: IiII / II111iiii + IiII
    if 20 - 20: ooOoO0o + o00O0oo / I1IiiI % Oo0Ooo
    OooooOoooO = "[B]" + i1i1ii + "[/B]"
    oOo0O = "" + iII1ii1 + ""
    OOO0O00oO = "" + I1i1iiiI1 + ""
    if 9 - 9: Oo0Ooo
    xbmcgui . Dialog ( ) . ok ( "Real Stream" , OooooOoooO , oOo0O , OOO0O00oO )
    if 31 - 31: Ii1I % OOooOOo
   except :
    pass
    if 14 - 14: IiII / IiII % iiIi
    if 56 - 56: I1ii11iIi11i . I1IiiI + oO0o
 Ooo00Oo = i1II1 ( ii1iii1i )
 i11i1 = re . compile ( ooOOoooooo ) . findall ( Ooo00Oo )
 for oO00Oooo0O0o0 in i11i1 :
  try :
   if 1 - 1: oO00OO0oo0
   import xbmc
   import xbmcaddon
   if 97 - 97: I1Ii111 + oO00OO0oo0 + I1IiiI + II111iiii
   __addon__ = xbmcaddon . Addon ( )
   __addonname__ = __addon__ . getAddonInfo ( 'name' )
   __icon__ = __addon__ . getAddonInfo ( 'icon' )
   if 77 - 77: Ii1I / OoO0O00
   ii = oo000 . getAddonInfo ( 'version' )
   IIii11I1i1I = oO00Oooo0O0o0
   if 99 - 99: oO00OO0oo0
   OooooOoooO = "[COLOR orange]Version instalada Actualmente: [COLOR gold] " + ii + " [/COLOR][/COLOR]" "[COLOR white]Ultima version: [COLOR lime] " + oO00Oooo0O0o0 + "  [/COLOR][/COLOR]"
   oOIIiIi = 5000
   if 76 - 76: OOooOOo * I1ii11iIi11i
   xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , OooooOoooO , oOIIiIi , __icon__ ) )
   if 82 - 82: o00O0oo * oO00OO0oo0 / iII111i
   if 36 - 36: OoO0O00 - OoOoOO00 . I1IiiI / o0oOOo0O0Ooo + Ii1I
   if ii < IIii11I1i1I :
    if 33 - 33: o0oOOo0O0Ooo / iiIi * I1IiiI % o00O0oo * i1iiI11I
    xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR orange]Ya esta disponible la nueva version[/COLOR][COLOR lime]" + oO00Oooo0O0o0 + "[/COLOR][COLOR orange]. Puedes instalarla desde el repositorio Realstream, sino se actualiza sola.[/COLOR]" )
  except :
   pass
 if not xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
  if 100 - 100: III1i1i . ooOoO0o / o00O0oo % I11i % o0oOOo0O0Ooo - OOooOOo
  if 46 - 46: I1IiiI * o0oOOo0O0Ooo - oO0o * iiIi
  if 33 - 33: o00O0oo
def o0OO0o0oOOO0O ( s ) :
 if 74 - 74: I1Ii111 + I1IiiI + OoOoOO00 - OoOoOO00 + o0oOOo0O0Ooo
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 83 - 83: iII111i - I1ii11iIi11i + I1Ii111
def iIi1Ii1i1iI ( file ) :
 if 16 - 16: I1Ii111 / oO0o / OoO0O00 * I1ii11iIi11i + OoOoOO00 % I1Ii111
 try :
  ooo0o00 = open ( file , 'r' )
  OoOO0o = ooo0o00 . read ( )
  ooo0o00 . close ( )
  return OoOO0o
 except :
  pass
  if 99 - 99: I1IiiI . ooOoO0o + Oo0Ooo
def i1II1 ( url ) :
 if 32 - 32: o00O0oo . Oo0Ooo % Oo0Ooo * II111iiii - OOooOOo - ooOoO0o
 try :
  o00oo0 = urllib2 . Request ( url )
  o00oo0 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0' )
  oooooOOO000Oo = urllib2 . urlopen ( o00oo0 )
  Ooo00OoOOO = oooooOOO000Oo . read ( )
  oooooOOO000Oo . close ( )
  return Ooo00OoOOO
 except urllib2 . URLError , Oo0OO0000oooo :
  print 'We failed to open "%s".' % url
  if hasattr ( Oo0OO0000oooo , 'code' ) :
   print 'We failed with error code - %s.' % Oo0OO0000oooo . code
  if hasattr ( Oo0OO0000oooo , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , Oo0OO0000oooo . reason
   if 7 - 7: IiII - OOooOOo - I1IiiI % IiII - o0oOOo0O0Ooo
def I1II ( url ) :
 o00oo0 = urllib2 . Request ( url )
 o00oo0 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 o00oo0 . add_header ( 'Referer' , '%s' % url )
 o00oo0 . add_header ( 'Connection' , 'keep-alive' )
 oooooOOO000Oo = urllib2 . urlopen ( o00oo0 )
 Ooo00OoOOO = oooooOOO000Oo . read ( )
 oooooOOO000Oo . close ( )
 return Ooo00OoOOO
 if 64 - 64: I1IiiI % ooOoO0o % I1IiiI * OOooOOo . IiII + I1ii11iIi11i
 if 75 - 75: ooOoO0o . OoO0O00 % Ii1I * ooOoO0o % OoO0O00
def I11i1iIiIIIIIii ( ) :
 if 58 - 58: Ii1I / III1i1i . I11i / OoO0O00 + i1iiI11I
 Oo0OoO00oOO0o = oo000 . getSetting ( 'MenuColor' )
 if 86 - 86: ooOoO0o * I1ii11iIi11i + ooOoO0o + o0oOOo0O0Ooo
 if O0o0Ooo == 'true' :
  if 8 - 8: i1iiI11I - oO00OO0oo0 / iiIi
  oo0oOoo ( '[COLOR %s]Peliculas[/COLOR] ' % Oo0OoO00oOO0o , 'movieDB' , 116 , I1I , O0oOO0o0 )
  oo0oOoo ( '[COLOR %s]Series[/COLOR] ' % Oo0OoO00oOO0o , 'movieDB' , 117 , oOO00oOO , O0oOO0o0 )
  if 57 - 57: I11i - iII111i
  if 50 - 50: i1iiI11I / OoOoOO00 % OOooOOo . I1ii11iIi11i / oO00OO0oo0
 if OoO0O00IIiII == 'true' :
  oo0oOoo ( '[COLOR %s]Ajustes[/COLOR]' % Oo0OoO00oOO0o , 'Settings' , 119 , OoOo , O0oOO0o0 )
  if 88 - 88: I1Ii111 . ooOoO0o * Ii1I . I11i / iiIi . ooOoO0o
  if 10 - 10: Ii1I * oO0o % I1IiiI * Oo0Ooo . I1IiiI % iII111i
  if Ii1i11IIii1I == 'true' :
   Iii1 ( )
   if 71 - 71: o0oOOo0O0Ooo / OoOoOO00 . iII111i % OoO0O00 . I11i
  if o0 == 'true' :
   Iiiiii111i1ii ( )
   i1i1iII1 ( )
   if 25 - 25: Oo0Ooo % oO00OO0oo0 . iiIi
  if iI1Ii11iII1 == 'false' :
   if 14 - 14: IiII + iII111i - oO00OO0oo0 / I1IiiI . i1iiI11I
   OooooOoooO = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
   oOo0O = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Script.ResolveURL para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
   OOO0O00oO = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"
   if 45 - 45: i1iiI11I
   xbmcgui . Dialog ( ) . ok ( "Real Stream" , OooooOoooO , oOo0O , OOO0O00oO )
   if 83 - 83: I11i . OoO0O00
def Oo0ooo ( ) :
 oo0oOoo ( '[COLOR orange]Buscador por id[/COLOR]' , OOoo0O , 127 , iiI1iIiI , O0oOO0o0 )
 if 28 - 28: IiII . o0oOOo0O0Ooo / iII111i + o0oOOo0O0Ooo . OoO0O00 . III1i1i
def O000OOO0OOo ( ) :
 if 32 - 32: o00O0oo * I1IiiI
 Oo0OoO00oOO0o = oo000 . getSetting ( 'MenuColor' )
 oo0oOoo ( '[COLOR %s]The movie DB[/COLOR]' % Oo0OoO00oOO0o , 'movieDB' , 99 , iiI1iIiI , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Buscador por id[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 127 , iiI1iIiI , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Video tutoriales[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 125 , iiii11I , O0oOO0o0 )
 if 100 - 100: iiIi % Oo0Ooo * o0oOOo0O0Ooo - oO00OO0oo0
 if 92 - 92: iiIi
 if 22 - 22: oO0o % oO00OO0oo0 * iII111i / I1Ii111 % II111iiii * ooOoO0o
 if 95 - 95: OoO0O00 - III1i1i * I1ii11iIi11i + I11i
 if 10 - 10: Ii1I / II111iiii
 if 92 - 92: ooOoO0o . i1iiI11I
 oo0oOoo ( '[COLOR %s]Autorizar OPENLOAD[/COLOR]' % Oo0OoO00oOO0o , 'movieDB' , 97 , II1Ii1iI1i , O0oOO0o0 )
 if 85 - 85: iII111i . i1iiI11I
 if 78 - 78: iiIi * i1iiI11I + Oo0Ooo + Oo0Ooo / i1iiI11I . o00O0oo
 if 97 - 97: iiIi / i1iiI11I % OoOoOO00 % iII111i
 I11i1iIiIIIIIii ( )
 if 18 - 18: Oo0Ooo % ooOoO0o
 if 95 - 95: iiIi + II111iiii * i1iiI11I - OoOoOO00 * i1iiI11I - Oo0Ooo
 if 75 - 75: OoO0O00 * III1i1i
 if 9 - 9: III1i1i - o0oOOo0O0Ooo + I1IiiI / Oo0Ooo / II111iiii
 if 39 - 39: III1i1i * oO0o + Oo0Ooo - III1i1i + I1Ii111
 if 69 - 69: I1IiiI
 if 85 - 85: iiIi / I1IiiI
 if 18 - 18: Ii1I % I1IiiI * iII111i
 if 62 - 62: i1iiI11I . III1i1i . OoO0O00
 if 11 - 11: I1Ii111 / ooOoO0o
 if 73 - 73: OoOoOO00 / II111iiii
def OOOIiiiii1iI ( ) :
 IIi = xbmcgui . Dialog ( )
 ooOooo0 = (
 oO0OO0 ,
 o0O0Oo00 ,
 )
 if 51 - 51: I1Ii111 % Oo0Ooo - OoO0O00 % iiIi * Oo0Ooo % OOooOOo
 oO0o00oOOooO0 = IIi . select ( '[B][COLOR=yellow]Listado de Proxys Gratuitos:[/COLOR][/B]' , [
 '[COLOR=orange]                      Accede a la web[/COLOR]' ,

 '[B][COLOR=gold]                      Volver al Menu [/COLOR][/B]' , ] )
 if 79 - 79: OOooOOo - Oo0Ooo + o00O0oo - i1iiI11I
 if oO0o00oOOooO0 :
  if 93 - 93: o0oOOo0O0Ooo . I1ii11iIi11i - oO0o + I11i
  if oO0o00oOOooO0 < 0 :
   return
  ooO0o = ooOooo0 [ oO0o00oOOooO0 - 2 ]
  return ooO0o ( )
 else :
  ooO0o = ooOooo0 [ oO0o00oOOooO0 ]
  return ooO0o ( )
 return
 if 89 - 89: ooOoO0o / i1iiI11I
def oooO0o0o0O0 ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 27 - 27: OoO0O00 - oO00OO0oo0 / ooOoO0o
OOooOo00oo0 = oooO0o0o0O0 ( )
if 84 - 84: i1iiI11I + ooOoO0o
def oO0OO0 ( ) :
 if OOooOo00oo0 == 'android' :
  IIiiIIi1 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://hidemyna.me/es/proxy-list/?country=ES&type=hs#list' ) )
  if 59 - 59: III1i1i . I1Ii111 % o0oOOo0O0Ooo
 else :
  IIiiIIi1 = webbrowser . open ( 'https://hidemyna.me/es/proxy-list/?country=ES&type=hs#list' )
  if 39 - 39: iII111i
  if 97 - 97: I1Ii111 - OOooOOo / o00O0oo . II111iiii % IiII * IiII
def o0O0Oo00 ( ) :
 if 1 - 1: I1ii11iIi11i % iiIi
 O000OOO0OOo ( )
 if 65 - 65: I1ii11iIi11i + I11i / I1Ii111
 if 83 - 83: Ii1I . oO00OO0oo0 - oO0o
def Ooo0O ( ) :
 if xbmc . getCondVisibility ( 'System.HasAddon(script.favourites)' ) :
  try :
   xbmc . executebuiltin ( "RunScript(script.favourites)" )
  except :
   pass
def o0oo0000OO ( ) :
 oo000 . openSettings ( )
 if 69 - 69: iiIi - OOooOOo / II111iiii + iII111i % OoO0O00
 if 73 - 73: o00O0oo - i1iiI11I
def O00oooo00o0O ( ) :
 urlresolver . display_settings ( )
 if 9 - 9: I1ii11iIi11i % I1ii11iIi11i % o0oOOo0O0Ooo
def Iiiiii111i1ii ( ) :
 oo0oOoo ( '[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % Oo0OoO00oOO0o , 'resolve' , 120 , OOO0OOO00oo , O0oOO0o0 )
 if 30 - 30: III1i1i + i1iiI11I - III1i1i . III1i1i - o0oOOo0O0Ooo + I1IiiI
def oOO0 ( ) :
 if 46 - 46: o00O0oo % I11i
 xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 if 64 - 64: II111iiii - o0oOOo0O0Ooo
def i1i1iII1 ( ) :
 oo0oOoo ( '[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % Oo0OoO00oOO0o , 'resolve' , 140 , OOO0OOO00oo , O0oOO0o0 )
 if 77 - 77: I11i % o00O0oo
def Iii1 ( ) :
 if 9 - 9: OOooOOo - oO0o * OoO0O00 . oO0o
 Oo0OoO00oOO0o = oo000 . getSetting ( 'MenuColor' )
 oo0oOoo ( '[COLOR %s]Buscador[/COLOR]' % Oo0OoO00oOO0o , 'search' , 111 , i111I , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Estrenos[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 3 , Ii1IIii11 , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Todas[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 26 , Oooo0000 , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]4K[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 141 , OO0o , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Novedades[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 2 , OOo , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Accion[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 5 , i11 , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Animacion[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 6 , I11 , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Artes Marciales[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 29 , O00o0OO , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Aventuras[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 7 , Oo0o0000o0o0 , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Belico[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 8 , oOo0oooo00o , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Ciencia Ficcion[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 9 , oO0o0o0ooO0oO , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Cine Clasico[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 30 , oo0o0O00 , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Comedia[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 10 , oO , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Crimen[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 11 , i1iiIIiiI111 , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Drama[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 12 , oooOOOOO , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Familiar[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 13 , i1iiIII111ii , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Fantasia[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 14 , i1iIIi1 , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Historia[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 15 , ii11iIi1I , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Misterio[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 16 , OOooO0OOoo , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Musical[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 17 , iIii1 , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Romance[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 18 , oOOoO0 , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Thriller[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 19 , ooOoOoo0O , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Suspense[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 20 , iiI1IiI , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Terror[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 21 , II , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Western[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 22 , OooO0 , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Spain[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 23 , O0OoO000O0OO , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Super heroes[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 24 , iI111I11I1I1 , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Sagas[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 25 , II11iiii1Ii , O0oOO0o0 )
 if 2 - 2: OoO0O00 % I1Ii111
def oOoOOo0oo0 ( ) :
 if 60 - 60: iiIi * i1iiI11I + oO0o
 oo0oOoo ( '[COLOR %s]Buscar Serie[/COLOR]' % Oo0OoO00oOO0o , 'search' , 145 , O0o0Oo , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]En emision[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 150 , I11i1 , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]15 Mejores[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 151 , iIi1ii1I1 , O0oOO0o0 )
 oo0oOoo ( '[COLOR %s]Todas[/COLOR]' % Oo0OoO00oOO0o , OOoo0O , 142 , Oo00OOOOO , O0oOO0o0 )
 if 19 - 19: OOooOOo * ooOoO0o / ooOoO0o . OoO0O00 - I1Ii111 + II111iiii
def oo0OOo0O ( ) :
 if 39 - 39: OoO0O00 + IiII % I1Ii111 / I1Ii111
 if 27 - 27: oO00OO0oo0 . ooOoO0o . Oo0Ooo . Oo0Ooo
 try :
  if 20 - 20: Ii1I / OoOoOO00
  oOIi111 = i1II1 ( iii1 )
  i11i1 = re . compile ( iiIiI ) . findall ( oOIi111 )
  for IiiiiI1i1Iii in i11i1 :
   if 67 - 67: I1IiiI
   try :
    if 52 - 52: o0oOOo0O0Ooo . iiIi / I11i / OoO0O00 . II111iiii
    I1i1i = IiiiiI1i1Iii
    i11III1111iIi = xbmc . Keyboard ( '' , 'Buscar' )
    i11III1111iIi . doModal ( )
    if ( i11III1111iIi . isConfirmed ( ) ) :
     if 86 - 86: oO0o / IiII + I1IiiI * oO00OO0oo0
     iI11 = urllib . quote_plus ( i11III1111iIi . getText ( ) ) . replace ( '+' , ' ' )
     Ooo00Oo = i1II1 ( I1i1i )
     i11i1 = re . compile ( o0o ) . findall ( Ooo00Oo )
     for i1ii1iIII , OOOooo , O0oOO0o0 , OooO0OO in i11i1 :
      if re . search ( iI11 , o0OO0o0oOOO0O ( OOOooo . replace ( ' ' , ' ' ) ) , re . IGNORECASE ) :
       oo0oOoo ( OOOooo , OooO0OO , 143 , i1ii1iIII , O0oOO0o0 )
       if 19 - 19: o0oOOo0O0Ooo * III1i1i + o00O0oo
   except :
    pass
 except :
  pass
  if 65 - 65: I1Ii111 . i1iiI11I . OOooOOo . oO00OO0oo0 - I1Ii111
  if 19 - 19: II111iiii + oO00OO0oo0 % iiIi
def IIii11II11II1 ( ) :
 if 10 - 10: I1ii11iIi11i / oO0o % iII111i * iiIi
 try :
  if 6 - 6: oO00OO0oo0 . III1i1i * I11i . OoOoOO00
  oOIi111 = i1II1 ( iiIiIIIiiI )
  i11i1 = re . compile ( iiIiI ) . findall ( oOIi111 )
  for IiiiiI1i1Iii in i11i1 :
   if 98 - 98: OoOoOO00
   try :
    if 65 - 65: I11i / OOooOOo % III1i1i
    I1i1i = IiiiiI1i1Iii
    if 45 - 45: I11i
   except :
    pass
    if 66 - 66: OOooOOo
  Ooo00Oo = i1II1 ( I1i1i )
  i11i1 = re . compile ( o0o ) . findall ( Ooo00Oo )
  for i1ii1iIII , OOOooo , O0oOO0o0 , OooO0OO in i11i1 :
   try :
    if 56 - 56: I1IiiI
    oo0oOoo ( OOOooo , OooO0OO , 143 , i1ii1iIII , O0oOO0o0 )
    if 61 - 61: Ii1I / I1Ii111 / oO0o * I1IiiI
   except :
    pass
 except :
  pass
  if 23 - 23: IiII - I1Ii111 + ooOoO0o
def II11 ( ) :
 if 30 - 30: II111iiii % Oo0Ooo . ooOoO0o % Oo0Ooo
 try :
  if 62 - 62: oO0o * I11i
  oOIi111 = i1II1 ( o0ooo0 )
  i11i1 = re . compile ( iiIiI ) . findall ( oOIi111 )
  for IiiiiI1i1Iii in i11i1 :
   if 79 - 79: OOooOOo . oO00OO0oo0 * o00O0oo - I1Ii111 + iiIi
   try :
    if 14 - 14: II111iiii - oO00OO0oo0 * I11i
    I1i1i = IiiiiI1i1Iii
    if 51 - 51: iII111i / Oo0Ooo % IiII + Ii1I * iiIi + i1iiI11I
   except :
    pass
    if 77 - 77: iiIi * I11i
  Ooo00Oo = i1II1 ( I1i1i )
  i11i1 = re . compile ( o0o ) . findall ( Ooo00Oo )
  for i1ii1iIII , OOOooo , O0oOO0o0 , OooO0OO in i11i1 :
   try :
    if 14 - 14: ooOoO0o % ooOoO0o / III1i1i
    oo0oOoo ( OOOooo , OooO0OO , 143 , i1ii1iIII , O0oOO0o0 )
    if 72 - 72: OoOoOO00 - o0oOOo0O0Ooo - I1Ii111 + I1Ii111 * Ii1I * I1Ii111
   except :
    pass
 except :
  pass
  if 33 - 33: oO0o
def II11i11Iii ( ) :
 if 68 - 68: OoO0O00 % o0oOOo0O0Ooo
 try :
  if 26 - 26: o0oOOo0O0Ooo % II111iiii % Oo0Ooo % ooOoO0o * ooOoO0o * iII111i
  oOIi111 = i1II1 ( iii1 )
  i11i1 = re . compile ( iiIiI ) . findall ( oOIi111 )
  for IiiiiI1i1Iii in i11i1 :
   if 24 - 24: o0oOOo0O0Ooo % i1iiI11I - iiIi + I1ii11iIi11i * iII111i
   try :
    if 2 - 2: o00O0oo - III1i1i
    I1i1i = IiiiiI1i1Iii
    if 83 - 83: IiII % Ii1I % o00O0oo - o0oOOo0O0Ooo * I1Ii111 / OoO0O00
   except :
    pass
    if 18 - 18: OOooOOo + Oo0Ooo - o0oOOo0O0Ooo - I1ii11iIi11i
  Ooo00Oo = i1II1 ( I1i1i )
  i11i1 = re . compile ( o0o ) . findall ( Ooo00Oo )
  for i1ii1iIII , OOOooo , O0oOO0o0 , OooO0OO in i11i1 :
   try :
    if 71 - 71: OoO0O00
    oo0oOoo ( OOOooo , OooO0OO , 143 , i1ii1iIII , O0oOO0o0 )
    if 33 - 33: i1iiI11I
   except :
    pass
 except :
  pass
  if 62 - 62: iII111i + o00O0oo + OoOoOO00 / OoO0O00
def IIiiii ( name , url ) :
 if 37 - 37: Ii1I % iiIi
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 83 - 83: I1Ii111 . i1iiI11I + IiII - I1Ii111 * i1iiI11I / i1iiI11I
 Ii1Io0OO0o0o00o = i1II1 ( url )
 i11i1 = re . compile ( OooOO000 ) . findall ( Ii1Io0OO0o0o00o )
 for I11I1 , name , O0oOO0o0 , url in i11i1 :
  try :
   if 45 - 45: III1i1i
   if 20 - 20: OoO0O00 * Ii1I * I1IiiI . I1Ii111
   Oo0oOOo = oo000 . getSetting ( 'Fontcolor' )
   name = '[COLOR %s]' % Oo0oOOo + name + '[/COLOR]'
   OoO000O ( name , url , 144 , I11I1 , O0oOO0o0 )
   if 94 - 94: I11i . I1IiiI / o00O0oo . iII111i - OoOoOO00
   if 26 - 26: OOooOOo - I1Ii111 . Ii1I
  except :
   pass
   if 65 - 65: iII111i % I1IiiI % Oo0Ooo * o00O0oo
   if 31 - 31: o00O0oo
   if 44 - 44: I11i - Oo0Ooo - oO0o
def OoO000O ( name , url , mode , iconimage , fanart ) :
 if 80 - 80: Oo0Ooo * i1iiI11I % ooOoO0o % oO0o
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 95 - 95: Oo0Ooo - iII111i . i1iiI11I - I1ii11iIi11i
 OOOOoo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage="
 o000 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 o000 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 o000 . setProperty ( 'fanart_image' , fanart )
 o000 . setProperty ( 'IsPlayable' , 'true' )
 OOooo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOOOoo , listitem = o000 )
 return OOooo0O
 if 34 - 34: I1Ii111
 if 11 - 11: I1ii11iIi11i * IiII + iII111i / iII111i
def iiii1I1 ( name , url ) :
 if 14 - 14: I11i * I1ii11iIi11i + OoO0O00 - oO00OO0oo0 - III1i1i
 if 15 - 15: III1i1i / I1IiiI . Ii1I . II111iiii
 if 'https://team.com' in url :
  if 59 - 59: i1iiI11I - Ii1I - iiIi
  url = url . replace ( 'https://team.com' , 'https://verystream.com' )
  if 48 - 48: OoOoOO00 + ooOoO0o % I11i / oO0o - Ii1I
 if 'https://mybox.com' in url :
  if 67 - 67: IiII % Ii1I . OoO0O00 + I1Ii111 * ooOoO0o * I11i
  url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
  if 36 - 36: I1IiiI + oO0o
  if 5 - 5: oO0o * I11i
 if 'https://vidcloud.co/' in url :
  if 46 - 46: iiIi
  url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
  if 33 - 33: oO00OO0oo0 - o0oOOo0O0Ooo * OoO0O00 - oO0o - I1Ii111
 if 'https://gounlimited.to' in url :
  if 84 - 84: i1iiI11I + oO0o - I11i * I11i
  url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
  if 61 - 61: OoO0O00 . IiII . OoO0O00 / oO0o
 if 'https://drive.com' in url :
  if 72 - 72: OoOoOO00
  url = url . replace ( 'https://drive.com/' , 'https://drive.google.com/' )
  if 82 - 82: I11i + OoO0O00 / II111iiii * iII111i . OoO0O00
  if 63 - 63: iII111i
 import resolveurl
 if 6 - 6: iiIi / iII111i
 oOooO00o0O = urlresolver . HostedMediaFile ( url )
 OOo0 = xbmcgui . DialogProgress ( )
 OOo0 . create ( 'Realstream:' , 'Iniciando ...' )
 OOo0 . update ( 30 , 'RESOLVEURL:' , 'Conectando al servidor ...' )
 xbmc . sleep ( 1000 )
 if 35 - 35: OoOoOO00 - Oo0Ooo + OoOoOO00
 if 86 - 86: Oo0Ooo + I11i . II111iiii - o00O0oo
 if not oOooO00o0O :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
  return False
  if 51 - 51: I11i
 try :
  if 14 - 14: III1i1i % IiII % oO0o - II111iiii
  OOo0 . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
  xbmc . sleep ( 500 )
  o0OO000ooOo = oOooO00o0O . resolve ( )
  if not o0OO000ooOo or not isinstance ( o0OO000ooOo , basestring ) :
   try : oOo00OooO0oO = o0OO000ooOo . msg
   except : oOo00OooO0oO = url
   raise Exception ( oOo00OooO0oO )
 except Exception as Oo0OO0000oooo :
  try : oOo00OooO0oO = str ( Oo0OO0000oooo )
  except : oOo00OooO0oO = url
  OOo0 . update ( 100 , 'RESOLVEURL:' , 'Enlace no encontrado.' )
  OOo0 . close ( )
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,7000)" )
  if 16 - 16: III1i1i / oO0o + I1Ii111 / o00O0oo
 OOo0 . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
 xbmc . sleep ( 500 )
 OOo0 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
 xbmc . sleep ( 500 )
 OOo0 . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
 xbmc . sleep ( 500 )
 OOo0 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de este capitulo!' )
 OOo0 . close ( )
 IIIIii = oo000 . getSetting ( 'notificar' )
 if IIIIii == 'true' :
  if 42 - 42: oO0o + o0oOOo0O0Ooo - I1ii11iIi11i / ooOoO0o % III1i1i
  if '[Realstream]' or '[Mybox]' in name :
   OO00Oo = oo000 . getSetting ( 'restante' )
  elif OO00Oo == 'true' :
   IIi = xbmcgui . Dialog ( )
   OOooo0O = IIi . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
  O0ooOOO = xbmcgui . ListItem ( path = o0OO000ooOo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0ooOOO )
  if 70 - 70: iiIi . I1IiiI . i1iiI11I . I1IiiI + OoOoOO00
 else :
  if 9 - 9: oO0o
  O0ooOOO = xbmcgui . ListItem ( path = o0OO000ooOo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0ooOOO )
  if 99 - 99: ooOoO0o - i1iiI11I - IiII % OOooOOo
  if 21 - 21: o0oOOo0O0Ooo % iII111i . OoOoOO00 - OoO0O00
  if 4 - 4: OoO0O00 . iiIi
def oOO0oo ( ) :
 if 29 - 29: I1ii11iIi11i * o0oOOo0O0Ooo * OoO0O00 - iII111i * o0oOOo0O0Ooo
 if 41 - 41: I1IiiI
 I111I11I111 = xbmc . Keyboard ( '' , 'Titulo de la pelicula' )
 I111I11I111 . doModal ( )
 if not I111I11I111 . isConfirmed ( ) :
  return None ;
 OOOooo = I111I11I111 . getText ( ) . strip ( )
 if 46 - 46: II111iiii - I1IiiI . IiII
 if 100 - 100: I1ii11iIi11i / Ii1I * oO00OO0oo0 . I1IiiI / I1Ii111
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  if 83 - 83: i1iiI11I
  IIiiIIi1 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' + OOOooo + '&language=es-ES' ) )
  if 48 - 48: o0oOOo0O0Ooo * I1Ii111 * i1iiI11I
  if 50 - 50: III1i1i % OoOoOO00
  return 'android'
  if 21 - 21: OoO0O00 - Oo0Ooo
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if 93 - 93: IiII - Ii1I % I11i . I11i - iiIi
  IIiiIIi1 = webbrowser . open ( 'https://www.themoviedb.org/search?query=' + OOOooo + '&language=es-ES' )
  if 90 - 90: iiIi + o0oOOo0O0Ooo * iII111i / o00O0oo . Ii1I + Ii1I
  if 40 - 40: iiIi / I11i % II111iiii % iII111i / I1ii11iIi11i
  return 'windows'
  if 62 - 62: OoOoOO00 - I11i
  if 62 - 62: OoOoOO00 + oO0o % III1i1i
def iIi ( ) :
 if 10 - 10: OOooOOo / oO0o
 try :
  if 15 - 15: oO00OO0oo0 . I11i / oO00OO0oo0 * ooOoO0o - I1ii11iIi11i % iII111i
  OoOO0o = i1II1 ( i1Iii1i1I )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 57 - 57: I1IiiI % I11i % IiII
   try :
    if 45 - 45: iII111i + o0oOOo0O0Ooo * II111iiii
    all = IiiiiI1i1Iii
    if 13 - 13: OoO0O00 * IiII - o00O0oo / I1Ii111 + ooOoO0o + III1i1i
   except :
    pass
    if 39 - 39: Oo0Ooo - OoO0O00
  Ii1Io0OO0o0o00o = i1II1 ( all )
  i11i1 = re . compile ( O0OOO ) . findall ( Ii1Io0OO0o0o00o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    if 81 - 81: iII111i - I1IiiI * OoO0O00
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 23 - 23: o0oOOo0O0Ooo / IiII
   except :
    pass
 except :
  pass
  if 28 - 28: oO0o * iiIi - OOooOOo
def iI11iiii1I ( ) :
 if 3 - 3: I1IiiI % OoO0O00 / I1Ii111
 try :
  if 89 - 89: o0oOOo0O0Ooo / IiII
  OOo = i1II1 ( IiI111111IIII )
  i11i1 = re . compile ( iiIiI ) . findall ( OOo )
  for IiiiiI1i1Iii in i11i1 :
   if 14 - 14: I1Ii111 . I1ii11iIi11i * iiIi + o0oOOo0O0Ooo - iiIi + I1Ii111
   try :
    if 18 - 18: IiII - Ii1I - I1ii11iIi11i - I1ii11iIi11i
    I1i1i = IiiiiI1i1Iii
    if 54 - 54: oO0o + I1ii11iIi11i / oO00OO0oo0 . I1ii11iIi11i * I11i
   except :
    pass
    if 1 - 1: I11i * OOooOOo . OoOoOO00 / oO0o . iII111i + oO0o
  Ooo00Oo = i1II1 ( I1i1i )
  i11i1 = re . compile ( O0OOO ) . findall ( Ooo00Oo )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    if 17 - 17: oO0o + OOooOOo / o00O0oo / oO00OO0oo0 * I1Ii111
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 29 - 29: OOooOOo % OoO0O00 * IiII / o0oOOo0O0Ooo - IiII
   except :
    pass
 except :
  pass
  if 19 - 19: II111iiii
def oo0 ( ) :
 if 73 - 73: I11i . I1ii11iIi11i
 try :
  if 32 - 32: I11i * I1ii11iIi11i % iiIi * o00O0oo . I1IiiI
  Ii1IIii11 = i1II1 ( ii111iI1iIi1 )
  i11i1 = re . compile ( iiIiI ) . findall ( Ii1IIii11 )
  for IiiiiI1i1Iii in i11i1 :
   if 48 - 48: oO00OO0oo0 * oO00OO0oo0
   try :
    I1I1 = IiiiiI1i1Iii
   except :
    pass
    if 4 - 4: Ii1I % I11i * I1Ii111
  OoOO0o = i1II1 ( I1I1 )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 32 - 32: II111iiii - i1iiI11I
   except :
    pass
 except :
  pass
  if 53 - 53: OoO0O00 - III1i1i
def oOo ( ) :
 if 17 - 17: o00O0oo . II111iiii
 try :
  if 5 - 5: iII111i + I1IiiI + I1IiiI . i1iiI11I - iiIi
  OoOO0o = i1II1 ( db2 )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 63 - 63: IiII
   try :
    if 71 - 71: OoOoOO00 . o00O0oo * oO00OO0oo0 % OoO0O00 + I1Ii111
    iIIi1iiI1i11 = IiiiiI1i1Iii
    if 56 - 56: OoO0O00
   except :
    pass
    if 30 - 30: II111iiii + IiII
    if 38 - 38: III1i1i . o00O0oo
  OoOO0o = i1II1 ( iIIi1iiI1i11 )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 24 - 24: Ii1I - Ii1I + iII111i + I1ii11iIi11i - IiII
   except :
    pass
 except :
  pass
  if 12 - 12: oO00OO0oo0 . III1i1i . I11i / I1IiiI
def OO0oOOo0o ( ) :
 if 50 - 50: oO00OO0oo0 . iII111i . OOooOOo * ooOoO0o + o0oOOo0O0Ooo % II111iiii
 try :
  if 8 - 8: iiIi * I1IiiI
  OOoOIiIIII = i1II1 ( o0O00Oo0 )
  i11i1 = re . compile ( iiIiI ) . findall ( OOoOIiIIII )
  for IiiiiI1i1Iii in i11i1 :
   if 89 - 89: OOooOOo / I1ii11iIi11i
   try :
    if 16 - 16: oO0o + iiIi / oO0o / OOooOOo % IiII % iII111i
    Ii1II11II1iii = IiiiiI1i1Iii
    if 86 - 86: oO00OO0oo0
   except :
    pass
    if 69 - 69: iII111i - i1iiI11I
    if 16 - 16: oO0o
  OoOO0o = i1II1 ( Ii1II11II1iii )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 14 - 14: OoOoOO00 - I1IiiI % oO0o
   except :
    pass
 except :
  pass
  if 92 - 92: o00O0oo % oO00OO0oo0 / iII111i % iII111i * I1ii11iIi11i
def Oo ( ) :
 if 78 - 78: OOooOOo % III1i1i * OoOoOO00
 try :
  if 66 - 66: o00O0oo . I1ii11iIi11i + Ii1I . Oo0Ooo
  OoOO0o = i1II1 ( oo0OOo0 )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 51 - 51: ooOoO0o . oO0o
   try :
    if 45 - 45: OoOoOO00 - oO0o / I1IiiI . iII111i
    iI1 = IiiiiI1i1Iii
    if 14 - 14: iII111i
   except :
    pass
    if 49 - 49: IiII / OoOoOO00 % o00O0oo . I1ii11iIi11i
    if 93 - 93: I1Ii111
  OoOO0o = i1II1 ( iI1 )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 43 - 43: iII111i / I1ii11iIi11i . iiIi
   except :
    pass
 except :
  pass
  if 62 - 62: Oo0Ooo + oO00OO0oo0 . oO0o / III1i1i % I1IiiI . i1iiI11I
def Oo0oOooOoOo ( ) :
 if 49 - 49: I1Ii111 . iII111i . II111iiii - o0oOOo0O0Ooo / o00O0oo
 try :
  if 62 - 62: I1Ii111
  OoOO0o = i1II1 ( O0ooO0Oo00o )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 1 - 1: III1i1i / III1i1i - II111iiii
   try :
    if 87 - 87: oO0o / I1IiiI * III1i1i / Ii1I
    I1iiIII = IiiiiI1i1Iii
    if 16 - 16: IiII + iiIi / Ii1I
   except :
    pass
    if 82 - 82: III1i1i * II111iiii % o0oOOo0O0Ooo - OoO0O00
  OoOO0o = i1II1 ( I1iiIII )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 90 - 90: oO0o . IiII * OoOoOO00 - OoOoOO00
   except :
    pass
 except :
  pass
  if 16 - 16: I1ii11iIi11i * OoOoOO00 - Ii1I . III1i1i % ooOoO0o / Ii1I
def Ii11iI1ii1111 ( ) :
 if 42 - 42: i1iiI11I + i1iiI11I * o0oOOo0O0Ooo
 try :
  if 78 - 78: OoO0O00
  OoOO0o = i1II1 ( i1I1ii11i1Iii )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 77 - 77: iII111i / OoOoOO00 / oO0o % I1Ii111
   try :
    if 48 - 48: ooOoO0o - III1i1i + Oo0Ooo + OoO0O00
    Ii = IiiiiI1i1Iii
    if 42 - 42: o00O0oo * i1iiI11I . III1i1i * I1ii11iIi11i + I11i
   except :
    pass
    if 25 - 25: ooOoO0o . I1ii11iIi11i + IiII
    if 75 - 75: III1i1i - Ii1I % oO00OO0oo0 + II111iiii
  OoOO0o = i1II1 ( Ii )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 100 - 100: ooOoO0o + Ii1I - II111iiii - o0oOOo0O0Ooo
   except :
    pass
 except :
  pass
  if 40 - 40: I11i % OOooOOo
def oo0O0o00 ( ) :
 if 70 - 70: OOooOOo
 try :
  if 46 - 46: ooOoO0o - OoOoOO00
  OoOO0o = i1II1 ( o0OIiII )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 46 - 46: i1iiI11I % o00O0oo
   try :
    if 72 - 72: Oo0Ooo
    iI1I1II1 = IiiiiI1i1Iii
    if 92 - 92: OoO0O00 - OoO0O00 * OOooOOo % I1ii11iIi11i
   except :
    pass
    if 77 - 77: Oo0Ooo - OoOoOO00 . IiII
    if 26 - 26: Ii1I * III1i1i . OoOoOO00
  OoOO0o = i1II1 ( iI1I1II1 )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 59 - 59: I1IiiI + OoOoOO00 - Ii1I
   except :
    pass
 except :
  pass
  if 62 - 62: II111iiii % I1Ii111 . III1i1i . I1Ii111
def ooOo0O0O0oOO0 ( ) :
 if 10 - 10: oO0o + I1IiiI
 try :
  if 43 - 43: Oo0Ooo / o0oOOo0O0Ooo % Ii1I - I1Ii111
  OoOO0o = i1II1 ( Iii1I1I11iiI1 )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 62 - 62: ooOoO0o
   try :
    if 63 - 63: I1Ii111 + iiIi * IiII / Ii1I / oO0o * Oo0Ooo
    OOoO00ooO = IiiiiI1i1Iii
    if 12 - 12: iiIi % I1ii11iIi11i + IiII - OoOoOO00 . o00O0oo / I1ii11iIi11i
   except :
    pass
    if 51 - 51: I1Ii111 . I1ii11iIi11i
    if 73 - 73: OoO0O00 . I1ii11iIi11i / i1iiI11I % o00O0oo
  OoOO0o = i1II1 ( OOoO00ooO )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 65 - 65: III1i1i - I1ii11iIi11i - o00O0oo
   except :
    pass
 except :
  pass
  if 42 - 42: o0oOOo0O0Ooo * I1ii11iIi11i % OoOoOO00 - o00O0oo % III1i1i
def Ii1I1 ( ) :
 if 58 - 58: III1i1i - ooOoO0o % I1ii11iIi11i
 try :
  if 4 - 4: OoOoOO00 + iiIi + OoOoOO00
  OoOO0o = i1II1 ( i111iIi1i1II1 )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 31 - 31: o00O0oo
   try :
    if 78 - 78: II111iiii + Ii1I + i1iiI11I / Ii1I % Oo0Ooo % III1i1i
    Oo0O0Oo00O = IiiiiI1i1Iii
    if 9 - 9: Ii1I . I1ii11iIi11i - iII111i
   except :
    pass
    if 32 - 32: OoO0O00 / I1ii11iIi11i / Oo0Ooo + o0oOOo0O0Ooo . IiII . Ii1I
    if 21 - 21: Oo0Ooo / o0oOOo0O0Ooo % OoOoOO00
  OoOO0o = i1II1 ( Oo0O0Oo00O )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 8 - 8: OOooOOo + I11i . Oo0Ooo % I1IiiI
   except :
    pass
 except :
  pass
  if 43 - 43: iII111i - oO00OO0oo0
  if 70 - 70: oO00OO0oo0 / I1Ii111 % iiIi - o00O0oo
def i1II11Iii1I ( ) :
 if 92 - 92: I1Ii111 % III1i1i % I11i
 try :
  if 4 - 4: I11i + o00O0oo / IiII
  OoOO0o = i1II1 ( ii1I )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 13 - 13: oO00OO0oo0
   try :
    if 80 - 80: o00O0oo - Ii1I
    iI1II1I1I = IiiiiI1i1Iii
    if 79 - 79: I1Ii111 / i1iiI11I . I11i - iII111i
   except :
    pass
    if 47 - 47: OoO0O00 % I1IiiI * oO00OO0oo0 . o00O0oo
    if 38 - 38: I1IiiI - III1i1i % i1iiI11I
  OoOO0o = i1II1 ( iI1II1I1I )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 64 - 64: Oo0Ooo
   except :
    pass
 except :
  pass
  if 15 - 15: iII111i + I1Ii111 / iII111i / i1iiI11I
  if 31 - 31: iiIi + I1IiiI + iiIi . Oo0Ooo + oO0o / Ii1I
def II11i1IiIII ( ) :
 if 67 - 67: oO0o / oO00OO0oo0 * OoO0O00
 try :
  if 100 - 100: I1IiiI . ooOoO0o . OOooOOo + I1IiiI * IiII
  OoOO0o = i1II1 ( oO0 )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 42 - 42: IiII % OoO0O00 + Ii1I
   try :
    if 56 - 56: OoO0O00 + iII111i - oO00OO0oo0
    III1I1 = IiiiiI1i1Iii
    if 12 - 12: Oo0Ooo % iiIi % iiIi
   except :
    pass
    if 78 - 78: III1i1i . I11i . ooOoO0o
    if 97 - 97: IiII
  OoOO0o = i1II1 ( III1I1 )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 80 - 80: I1ii11iIi11i . o00O0oo
   except :
    pass
    if 47 - 47: ooOoO0o + iiIi + o0oOOo0O0Ooo % II111iiii
 except :
  pass
  if 93 - 93: iII111i % I11i . I1IiiI / oO00OO0oo0 * IiII
  if 29 - 29: Ii1I
def oo0iIiI ( ) :
 if 81 - 81: I11i % o00O0oo
 try :
  if 87 - 87: Oo0Ooo . OoO0O00 * I11i
  OoOO0o = i1II1 ( OO )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 100 - 100: OOooOOo / OoOoOO00 - I1ii11iIi11i % o00O0oo - Oo0Ooo
   try :
    if 17 - 17: ooOoO0o / Ii1I % oO0o
    o0oo00o0O0O00 = IiiiiI1i1Iii
    if 34 - 34: I1Ii111 . oO0o
   except :
    pass
    if 78 - 78: iII111i % I1ii11iIi11i / OoO0O00 % I1Ii111 - oO00OO0oo0
    if 2 - 2: Oo0Ooo
  OoOO0o = i1II1 ( o0oo00o0O0O00 )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 45 - 45: OoO0O00 / II111iiii
   except :
    pass
    if 10 - 10: oO00OO0oo0 - IiII * Oo0Ooo % Oo0Ooo * III1i1i - iII111i
 except :
  pass
  if 97 - 97: o0oOOo0O0Ooo % i1iiI11I + i1iiI11I - OOooOOo / o00O0oo * I1ii11iIi11i
def iIii1iII1Ii ( ) :
 if 50 - 50: o00O0oo
 try :
  if 22 - 22: ooOoO0o * I1IiiI . o0oOOo0O0Ooo - OOooOOo
  OoOO0o = i1II1 ( Ii1I1i )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 90 - 90: IiII
   try :
    if 94 - 94: ooOoO0o / iII111i * i1iiI11I - I11i
    I1Ii11II1I1 = IiiiiI1i1Iii
    if 41 - 41: I1IiiI * iiIi - I11i . o00O0oo
   except :
    pass
    if 65 - 65: oO0o . OoO0O00
  OoOO0o = i1II1 ( I1Ii11II1I1 )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 70 - 70: oO0o - IiII . Oo0Ooo % ooOoO0o / I11i - I1IiiI
   except :
    pass
 except :
  pass
  if 55 - 55: oO00OO0oo0 - OOooOOo
  if 100 - 100: I1IiiI
def o00IiI1iiII1i1i ( ) :
 if 18 - 18: I1ii11iIi11i
 try :
  if 80 - 80: iII111i / Oo0Ooo % I11i
  OoOO0o = i1II1 ( O0O0OOOOoo )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 80 - 80: OOooOOo % oO00OO0oo0
   try :
    if 99 - 99: iiIi / Oo0Ooo - o00O0oo * iII111i % I1ii11iIi11i
    i1II1i = IiiiiI1i1Iii
    if 10 - 10: o00O0oo - I11i . OoO0O00 . I1Ii111 . OOooOOo * oO00OO0oo0
   except :
    pass
    if 78 - 78: IiII / OOooOOo - IiII * OoO0O00 . I11i
    if 96 - 96: I1ii11iIi11i % OoOoOO00 . Ii1I . I1IiiI
  OoOO0o = i1II1 ( i1II1i )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 37 - 37: OoOoOO00 - I1Ii111 % OoO0O00 / I1Ii111 % iiIi
   except :
    pass
 except :
  pass
  if 48 - 48: II111iiii % IiII
  if 29 - 29: oO00OO0oo0 + II111iiii % ooOoO0o
def oOo00Ooo0o0 ( ) :
 if 33 - 33: ooOoO0o
 try :
  if 87 - 87: I11i / III1i1i + Oo0Ooo
  OoOO0o = i1II1 ( Ii1I1Ii )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 93 - 93: Oo0Ooo + IiII % iiIi
   try :
    if 21 - 21: I1Ii111
    iIiI1I1IIi11 = IiiiiI1i1Iii
    if 9 - 9: iiIi + oO00OO0oo0 - ooOoO0o / OoOoOO00 % iII111i / III1i1i
   except :
    pass
  OoOO0o = i1II1 ( iIiI1I1IIi11 )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 60 - 60: iII111i
   except :
    pass
 except :
  pass
  if 1 - 1: I11i . II111iiii % I11i - oO00OO0oo0 % OoOoOO00 + iII111i
def IiiIiIi111iI1 ( ) :
 if 88 - 88: oO0o % IiII + III1i1i
 try :
  if 8 - 8: II111iiii / o0oOOo0O0Ooo + Ii1I * o00O0oo % III1i1i . ooOoO0o
  OoOO0o = i1II1 ( OO0Oooo0oOO0O )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 6 - 6: III1i1i % oO0o . oO0o - iII111i / ooOoO0o . OoOoOO00
   try :
    if 99 - 99: I11i . i1iiI11I
    O0oO = IiiiiI1i1Iii
    if 27 - 27: I1IiiI / I11i + Oo0Ooo - I1Ii111 % Ii1I
   except :
    pass
    if 30 - 30: i1iiI11I % i1iiI11I % III1i1i . I11i
    if 9 - 9: iiIi / o0oOOo0O0Ooo . I11i % Ii1I * o0oOOo0O0Ooo - iiIi
  OoOO0o = i1II1 ( O0oO )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 55 - 55: I1ii11iIi11i
   except :
    pass
 except :
  pass
  if 45 - 45: I1IiiI / OoOoOO00 * IiII * OOooOOo
  if 35 - 35: iII111i / oO00OO0oo0 % I1ii11iIi11i + Oo0Ooo
def oO00o ( ) :
 if 36 - 36: i1iiI11I . o0oOOo0O0Ooo % iiIi
 try :
  if 84 - 84: OoO0O00 - II111iiii / Oo0Ooo / OoO0O00 / iII111i
  OoOO0o = i1II1 ( oOO0O00Oo0O0o )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 4 - 4: oO0o + Ii1I
   try :
    if 17 - 17: OOooOOo * I11i
    ii11i = IiiiiI1i1Iii
    if 71 - 71: i1iiI11I / iII111i * Oo0Ooo
   except :
    pass
    if 57 - 57: I1Ii111 + i1iiI11I % iII111i . OOooOOo / OOooOOo * I1IiiI
    if 6 - 6: OoOoOO00 - o0oOOo0O0Ooo * Ii1I . OOooOOo
  OoOO0o = i1II1 ( ii11i )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 68 - 68: Ii1I
   except :
    pass
 except :
  pass
  if 20 - 20: i1iiI11I - i1iiI11I
def iIIiI11i1I11 ( ) :
 if 29 - 29: OOooOOo * Oo0Ooo * I1IiiI - I11i / III1i1i
 try :
  if 99 - 99: iiIi
  OoOO0o = i1II1 ( I1iIIiiIIi1i )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 76 - 76: OOooOOo
   try :
    if 92 - 92: ooOoO0o - Oo0Ooo % OoO0O00
    I1 = IiiiiI1i1Iii
    if 84 - 84: I11i - II111iiii
   except :
    pass
    if 1 - 1: oO00OO0oo0 * I11i
    if 66 - 66: I11i + OoOoOO00 % o0oOOo0O0Ooo . I1IiiI * iII111i % iII111i
  OoOO0o = i1II1 ( I1 )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 87 - 87: I1Ii111 + Ii1I . oO00OO0oo0 - OoO0O00
   except :
    pass
 except :
  pass
  if 6 - 6: Oo0Ooo * OoO0O00
  if 28 - 28: oO0o * Ii1I / i1iiI11I
def Oo0O ( ) :
 if 88 - 88: I1ii11iIi11i % I1Ii111 % iII111i . II111iiii % Ii1I
 try :
  if 38 - 38: i1iiI11I + OoO0O00 . OoOoOO00
  OoOO0o = i1II1 ( oOOo0O00o )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 19 - 19: oO00OO0oo0 - Ii1I - o00O0oo - I11i . oO00OO0oo0 . i1iiI11I
   try :
    if 48 - 48: oO00OO0oo0 + III1i1i
    O0o0o0 = IiiiiI1i1Iii
    if 15 - 15: Oo0Ooo . I1IiiI
   except :
    pass
    if 70 - 70: o00O0oo . II111iiii % o00O0oo . I1IiiI - Oo0Ooo
    if 26 - 26: I1Ii111
  OoOO0o = i1II1 ( O0o0o0 )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 76 - 76: OoOoOO00 * OoO0O00 * I1IiiI + i1iiI11I * i1iiI11I
   except :
    pass
 except :
  pass
  if 35 - 35: Ii1I
  if 73 - 73: I1IiiI - iII111i
def ii1IoO0O ( ) :
 if 59 - 59: OoO0O00 * oO0o + OoOoOO00
 try :
  if 23 - 23: iiIi
  OoOO0o = i1II1 ( OOOiiiiI )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 13 - 13: Oo0Ooo
   try :
    if 77 - 77: II111iiii - Oo0Ooo / IiII / iiIi / OOooOOo
    ooo0O0o0OoOO = IiiiiI1i1Iii
    if 9 - 9: OOooOOo
   except :
    pass
    if 60 - 60: i1iiI11I
    if 98 - 98: iiIi
  OoOO0o = i1II1 ( ooo0O0o0OoOO )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 34 - 34: Oo0Ooo * ooOoO0o * ooOoO0o / iII111i
   except :
    pass
 except :
  pass
  if 28 - 28: OOooOOo - IiII + I11i + o00O0oo / Oo0Ooo
  if 26 - 26: Oo0Ooo - I1IiiI . I1IiiI
def O0oOoo ( ) :
 if 76 - 76: OoOoOO00 % I11i - I1ii11iIi11i / Ii1I * iiIi
 try :
  if 4 - 4: oO0o * oO0o / I11i
  OoOO0o = i1II1 ( OOoO )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 4 - 4: I1ii11iIi11i * I11i % ooOoO0o . I11i
   try :
    if 11 - 11: I1Ii111 - I11i - Ii1I * I11i + iiIi
    oooo0O0o0OoOO = IiiiiI1i1Iii
    if 36 - 36: IiII / i1iiI11I - I1ii11iIi11i . I1ii11iIi11i
   except :
    pass
    if 2 - 2: III1i1i + iII111i
    if 91 - 91: iII111i % iiIi
  OoOO0o = i1II1 ( oooo0O0o0OoOO )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 38 - 38: oO00OO0oo0 - I1Ii111 . I1ii11iIi11i
   except :
    pass
 except :
  pass
  if 51 - 51: IiII + OOooOOo + oO00OO0oo0 + oO00OO0oo0 % Ii1I
  if 29 - 29: iiIi
def ii1iIi1Ii1 ( ) :
 if 66 - 66: OOooOOo % Ii1I
 try :
  if 21 - 21: I11i - OoO0O00 % II111iiii
  OoOO0o = i1II1 ( iiIiI1i1 )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 71 - 71: OoOoOO00 - ooOoO0o * i1iiI11I + IiII - OOooOOo % iII111i
   try :
    if 63 - 63: Oo0Ooo + I1Ii111 . OOooOOo / I1ii11iIi11i
    oO0O = IiiiiI1i1Iii
    if 26 - 26: Oo0Ooo + OoOoOO00 / I11i % iII111i
   except :
    pass
    if 44 - 44: OoO0O00 . o0oOOo0O0Ooo . I1Ii111 % OoO0O00
  OoOO0o = i1II1 ( oO0O )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 86 - 86: II111iiii + I1IiiI * III1i1i - OOooOOo * I1Ii111 + I1IiiI
   except :
    pass
 except :
  pass
  if 95 - 95: Oo0Ooo . i1iiI11I % oO00OO0oo0 - i1iiI11I * o0oOOo0O0Ooo
  if 89 - 89: oO00OO0oo0 . I1ii11iIi11i
def ooOoo0OoOO ( ) :
 if 38 - 38: OOooOOo / iiIi % i1iiI11I * ooOoO0o + II111iiii % iiIi
 try :
  if 61 - 61: i1iiI11I - o00O0oo % iII111i / iiIi / oO00OO0oo0 + Oo0Ooo
  OoOO0o = i1II1 ( IiIi11iI )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 87 - 87: i1iiI11I + iiIi + I1IiiI / OoOoOO00 % III1i1i / i1iiI11I
   try :
    if 64 - 64: OOooOOo % III1i1i . i1iiI11I % OOooOOo + ooOoO0o * III1i1i
    OOOO00OooO = IiiiiI1i1Iii
    if 64 - 64: OOooOOo . I1ii11iIi11i - OoO0O00 . iiIi - oO00OO0oo0
   except :
    pass
    if 77 - 77: o00O0oo % I11i / o0oOOo0O0Ooo % oO00OO0oo0 % OoO0O00 % OOooOOo
    if 19 - 19: III1i1i * i1iiI11I / IiII * i1iiI11I - OoO0O00 * ooOoO0o
  OoOO0o = i1II1 ( OOOO00OooO )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 17 - 17: o0oOOo0O0Ooo + oO0o . i1iiI11I
   except :
    pass
 except :
  pass
  if 12 - 12: i1iiI11I + I1Ii111 + ooOoO0o . III1i1i / o00O0oo
def i1I ( ) :
 if 100 - 100: OOooOOo % OOooOOo
 try :
  if 15 - 15: IiII / i1iiI11I
  OoOO0o = i1II1 ( i11I1IiII1i1i )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 37 - 37: II111iiii + I1ii11iIi11i . I1Ii111 % ooOoO0o % ooOoO0o
   try :
    if 26 - 26: I1IiiI
    i111I1iiIiII = IiiiiI1i1Iii
    if 97 - 97: o0oOOo0O0Ooo - i1iiI11I - Oo0Ooo * I1ii11iIi11i
   except :
    pass
  OoOO0o = i1II1 ( i111I1iiIiII )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 54 - 54: Oo0Ooo
   except :
    pass
 except :
  pass
  if 5 - 5: III1i1i
def Oo0O0oo0o00o0 ( ) :
 if 66 - 66: Oo0Ooo . II111iiii / ooOoO0o / iiIi + i1iiI11I
 try :
  if 5 - 5: I11i % oO00OO0oo0 + III1i1i
  OoOO0o = i1II1 ( I1111i )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 13 - 13: III1i1i
   try :
    if 19 - 19: o0oOOo0O0Ooo - III1i1i
    OOOOo000o00OO = IiiiiI1i1Iii
    if 96 - 96: I1IiiI . I1Ii111 % iiIi + II111iiii - I1Ii111 * iiIi
   except :
    pass
  OoOO0o = i1II1 ( OOOOo000o00OO )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 33 - 33: iiIi % OoOoOO00 - IiII . I1IiiI / I1IiiI
   except :
    pass
 except :
  pass
  if 96 - 96: OoO0O00 + III1i1i * I1IiiI
def oo0OoOO0o0o ( ) :
 if 67 - 67: I11i - I11i * OOooOOo - oO00OO0oo0 % IiII
 try :
  if 44 - 44: I1ii11iIi11i . OoOoOO00 + I1Ii111
  OoOO0o = i1II1 ( ooOoO00 )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 16 - 16: Ii1I - OOooOOo / i1iiI11I
   try :
    if 48 - 48: Oo0Ooo
    OoooooOo = IiiiiI1i1Iii
    if 67 - 67: o0oOOo0O0Ooo / Ii1I . I1Ii111 . OoO0O00
   except :
    pass
  OoOO0o = i1II1 ( OoooooOo )
  i11i1 = re . compile ( O0OOO ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO , id , o0OOo0o0O0O in i11i1 :
   try :
    iII1i11 ( OOOooo , OooO0OO , oOoOOo0O , id , o0OOo0o0O0O )
    if 19 - 19: III1i1i . iII111i / I11i
   except :
    pass
 except :
  pass
  if 68 - 68: iiIi / OoO0O00 * ooOoO0o / IiII
def ooooO000 ( ) :
 if 61 - 61: iiIi - I1Ii111 + I1Ii111
 try :
  if 40 - 40: II111iiii . Oo0Ooo
  OoOO0o = i1II1 ( o00O0O )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for IiiiiI1i1Iii in i11i1 :
   if 2 - 2: OoOoOO00 * IiII - IiII + OoO0O00 % I11i / I11i
   try :
    if 3 - 3: OoO0O00
    O0OoO0o = IiiiiI1i1Iii
    if 1 - 1: iiIi % ooOoO0o * iII111i - o0oOOo0O0Ooo
   except :
    pass
  OoOO0o = i1II1 ( O0OoO0o )
  i11i1 = re . compile ( oO0000OOo00 ) . findall ( OoOO0o )
  for oOoOOo0O , OOOooo , OooO0OO in i11i1 :
   try :
    iI11I1IIi ( oOoOOo0O , OOOooo , OooO0OO )
    if 7 - 7: I11i + i1iiI11I + I1Ii111 + o0oOOo0O0Ooo . I1ii11iIi11i / OoOoOO00
   except :
    pass
    if 22 - 22: IiII + I1Ii111 * o0oOOo0O0Ooo . iiIi % I1Ii111 % ooOoO0o
 except :
  pass
  if 80 - 80: IiII * ooOoO0o / Oo0Ooo % IiII / Oo0Ooo
  if 42 - 42: OoOoOO00 / II111iiii . oO0o * oO00OO0oo0 . II111iiii * I1IiiI
  if 44 - 44: OoOoOO00 . I1ii11iIi11i / II111iiii + III1i1i
def iI11I1IIi ( thumb , name , url ) :
 if 27 - 27: I1Ii111
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( i1I1ii ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   oo0oOoo ( name , url , '' , i1ii1iIII , O0oOO0o0 )
 else :
  name = '[COLOR white]%s[/COLOR]' % name
  if 52 - 52: i1iiI11I % I11i + Oo0Ooo * IiII . o00O0oo
  if 'tvg-logo' in thumb :
   thumb = re . compile ( i1I1ii ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   if 95 - 95: Oo0Ooo . III1i1i - OoO0O00 * OOooOOo / Ii1I
   oOo0OO0o0 ( name , url , 4 , I11I1 , O0oOO0o0 )
   if 35 - 35: oO0o . oO0o % OoO0O00 - o00O0oo
  else :
   if 43 - 43: OOooOOo % OOooOOo
   oOo0OO0o0 ( name , url , 4 , I11I1 , O0oOO0o0 )
   if 46 - 46: oO0o % Oo0Ooo . oO00OO0oo0 . I1IiiI * iiIi / OoO0O00
def iII1i11 ( name , url , thumb , id , trailer ) :
 if 7 - 7: IiII - I1IiiI * ooOoO0o - Ii1I - o0oOOo0O0Ooo
 if 41 - 41: I1ii11iIi11i - i1iiI11I % o0oOOo0O0Ooo . i1iiI11I - ooOoO0o
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 trailer = trailer . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if 45 - 45: o00O0oo - I1Ii111
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( i1I1ii ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
  else :
   oo0oOoo ( name , url , '' , i1ii1iIII , O0oOO0o0 )
 else :
  Oo0oOOo = oo000 . getSetting ( 'Fontcolor' )
  if 70 - 70: OOooOOo % I1ii11iIi11i / I1ii11iIi11i . ooOoO0o % iiIi . o0oOOo0O0Ooo
  name = '[COLOR %s]' % Oo0oOOo + name + '[/COLOR]'
  if 10 - 10: o00O0oo - II111iiii . iII111i % OoOoOO00
  if 'tvg-logo' in thumb :
   thumb = re . compile ( i1I1ii ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   O0OOO0OOoO0O = oo000 . getSetting ( 'selecton' )
   if O0OOO0OOoO0O == 'true' :
    if 78 - 78: Oo0Ooo * oO0o . oO0o - I1Ii111 . Oo0Ooo
    I111I1I ( name , url , 1 , thumb , thumb , id , trailer )
    if 54 - 54: o0oOOo0O0Ooo + ooOoO0o % ooOoO0o % Ii1I
   else :
    if 25 - 25: oO00OO0oo0 - oO0o
    I111I1I ( name , url , 130 , thumb , thumb , id , trailer )
    if 10 - 10: I1IiiI % III1i1i . OOooOOo + Ii1I + iII111i
  else :
   if 52 - 52: I11i / OOooOOo + i1iiI11I
   if O0OOO0OOoO0O == 'true' :
    if 49 - 49: Oo0Ooo % ooOoO0o . ooOoO0o . Oo0Ooo * I11i / ooOoO0o
    I111I1I ( name , url , 1 , thumb , thumb , id , trailer )
    if 95 - 95: IiII * Oo0Ooo + iII111i
   else :
    if 5 - 5: oO0o
    I111I1I ( name , url , 130 , thumb , thumb , id , trailer )
    if 100 - 100: o00O0oo + Oo0Ooo
    if 59 - 59: III1i1i
def oOoO0OOO00O ( name , trailer ) :
 if 73 - 73: Ii1I % OOooOOo + III1i1i + I1ii11iIi11i
 if IIIIii == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Realstream, Reproduciendo Trailer de: [COLOR green]" + name + "[/COLOR] ,5000)" )
  if 80 - 80: OoOoOO00 + Ii1I + III1i1i * ooOoO0o
  OooO0OO = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  OO00OoOoOO = OooO0OO
  II1i = xbmcgui . ListItem ( name , trailer , path = OO00OoOoOO )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i )
 else :
  OooO0OO = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
  OO00OoOoOO = OooO0OO
  II1i = xbmcgui . ListItem ( name , trailer , path = OO00OoOoOO )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i )
  if 94 - 94: o00O0oo . OoOoOO00
  if 71 - 71: oO00OO0oo0 + OOooOOo - III1i1i . OOooOOo . III1i1i + I1ii11iIi11i
def iiiiIiIi ( trailer ) :
 if 3 - 3: oO0o
 if 'https://www.youtube.com' in trailer :
  if 33 - 33: oO0o / Oo0Ooo % OoOoOO00
  try :
   if 76 - 76: o00O0oo + Oo0Ooo + I11i . OOooOOo
   import resolveurl
   if 49 - 49: III1i1i / iiIi / I1Ii111
   oOooO00o0O = urlresolver . HostedMediaFile ( OooO0OO )
   OOo0 = xbmcgui . DialogProgress ( )
   OOo0 . create ( 'Realstream:' , 'Conectando al servidor ... ' )
   OOo0 . update ( 20 , 'Por favor, espere ...' )
   xbmc . sleep ( 500 )
   if 25 - 25: I1ii11iIi11i % I1IiiI + OoOoOO00 - iiIi
   if not oOooO00o0O :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    return False
    if 38 - 38: Ii1I % i1iiI11I + II111iiii + oO00OO0oo0 + iiIi / II111iiii
   try :
    if 94 - 94: oO00OO0oo0 - oO0o + IiII
    OOo0 . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
    xbmc . sleep ( 500 )
    o0OO000ooOo = oOooO00o0O . resolve ( )
    if not o0OO000ooOo or not isinstance ( o0OO000ooOo , basestring ) :
     try : oOo00OooO0oO = o0OO000ooOo . msg
     except : oOo00OooO0oO = o0OO000ooOo
     raise Exception ( oOo00OooO0oO )
   except Exception as Oo0OO0000oooo :
    try : oOo00OooO0oO = str ( Oo0OO0000oooo )
    except : oOo00OooO0oO = o0OO000ooOo
    OOo0 . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
    OOo0 . close ( )
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
    if 59 - 59: ooOoO0o . I1ii11iIi11i - Oo0Ooo + Oo0Ooo
   OOo0 . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
   xbmc . sleep ( 500 )
   OOo0 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
   xbmc . sleep ( 500 )
   OOo0 . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
   xbmc . sleep ( 500 )
   OOo0 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
   OOo0 . close ( )
   if 56 - 56: IiII + iiIi
   O0ooOOO = xbmcgui . ListItem ( path = o0OO000ooOo )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0ooOOO )
   if 32 - 32: o0oOOo0O0Ooo + I11i % iiIi / I11i + iII111i
  except :
   pass
   if 2 - 2: II111iiii - i1iiI11I + OOooOOo % ooOoO0o * o00O0oo
  else :
   if 54 - 54: I1IiiI - oO00OO0oo0 . I1Ii111 % oO00OO0oo0 + oO00OO0oo0
   OooO0OO = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
   OO00OoOoOO = OooO0OO
   II1i = xbmcgui . ListItem ( trailer , path = OO00OoOoOO )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i )
   return
   if 36 - 36: I1Ii111 % II111iiii
def Iiii1Ii ( name , url ) :
 if 62 - 62: OoOoOO00 % I11i
 if '[Youtube]' in name :
  if 37 - 37: ooOoO0o * OoOoOO00
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  OO00OoOoOO = url
  II1i = xbmcgui . ListItem ( o0OOo0o0O0O , path = OO00OoOoOO )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II1i )
  if 20 - 20: III1i1i + I11i - I1Ii111 - I1Ii111 - iII111i
  if 7 - 7: I1IiiI
 else :
  if 26 - 26: Ii1I / OoO0O00 % iiIi % I1Ii111
  import urlresolver
  from urlresolver import common
  if 54 - 54: I11i - i1iiI11I
  oOooO00o0O = urlresolver . HostedMediaFile ( url )
  if 65 - 65: i1iiI11I . iiIi + I1Ii111 / oO0o + III1i1i % OoOoOO00
  if not oOooO00o0O :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 28 - 28: II111iiii + I1IiiI / iII111i
   if 3 - 3: OOooOOo * OoOoOO00 . I1ii11iIi11i . I1IiiI - I11i
  try :
   o0OO000ooOo = oOooO00o0O . resolve ( )
   if not o0OO000ooOo or not isinstance ( o0OO000ooOo , basestring ) :
    try : oOo00OooO0oO = o0OO000ooOo . msg
    except : oOo00OooO0oO = url
    raise Exception ( oOo00OooO0oO )
  except Exception as Oo0OO0000oooo :
   try : oOo00OooO0oO = str ( Oo0OO0000oooo )
   except : oOo00OooO0oO = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 81 - 81: I1ii11iIi11i - Oo0Ooo / I1ii11iIi11i / I1IiiI
  IIIIii = oo000 . getSetting ( 'notificar' )
  if IIIIii == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  O0ooOOO = xbmcgui . ListItem ( path = o0OO000ooOo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0ooOOO )
  if 34 - 34: o00O0oo * o00O0oo - iII111i - I1IiiI . II111iiii
  if 32 - 32: Oo0Ooo . OOooOOo * IiII / I1Ii111 . o0oOOo0O0Ooo - oO0o
 return
 if 10 - 10: iII111i / II111iiii - o00O0oo + IiII * I1ii11iIi11i
def OoooOo0 ( name , url ) :
 if 20 - 20: o0oOOo0O0Ooo - ooOoO0o + OoOoOO00 + o00O0oo
 import resolveurl
 if 7 - 7: iiIi + o00O0oo
 oOooO00o0O = urlresolver . HostedMediaFile ( url )
 dp = xbmcgui . DialogProgress ( )
 dp . create ( 'Realstream:' , 'Conectando al servidor ... ' )
 dp . update ( 20 , 'Por favor, espere ...' )
 xbmc . sleep ( 500 )
 if 32 - 32: Oo0Ooo % I1ii11iIi11i / II111iiii + I1Ii111 - Ii1I . oO00OO0oo0
 if not oOooO00o0O :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  return False
  if 86 - 86: OoOoOO00 / o00O0oo * I1ii11iIi11i
 try :
  if 67 - 67: iII111i * iII111i / IiII * OoO0O00 + I11i
  dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
  xbmc . sleep ( 500 )
  o0OO000ooOo = oOooO00o0O . resolve ( )
  if not o0OO000ooOo or not isinstance ( o0OO000ooOo , basestring ) :
   try : oOo00OooO0oO = o0OO000ooOo . msg
   except : oOo00OooO0oO = o0OO000ooOo
   raise Exception ( oOo00OooO0oO )
 except Exception as Oo0OO0000oooo :
  try : oOo00OooO0oO = str ( Oo0OO0000oooo )
  except : oOo00OooO0oO = o0OO000ooOo
  dp . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
  dp . close ( )
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
  if 79 - 79: OoOoOO00
 dp . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
 xbmc . sleep ( 500 )
 dp . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
 xbmc . sleep ( 500 )
 dp . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
 xbmc . sleep ( 500 )
 dp . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
 dp . close ( )
 IIIIii = oo000 . getSetting ( 'notificar' )
 if 1 - 1: IiII / OoOoOO00
 if 74 - 74: ooOoO0o / OoO0O00 / oO0o * II111iiii . o0oOOo0O0Ooo . OoO0O00
 if '[Realstream]' or '[Mybox]' in name :
  restante = oo000 . getSetting ( 'restante' )
 elif restante == 'true' :
  dialog = xbmcgui . Dialog ( )
  ok = dialog . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
 O0ooOOO = xbmcgui . ListItem ( path = o0OO000ooOo )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0ooOOO )
 if 59 - 59: II111iiii . OoO0O00 / ooOoO0o * iII111i + OoO0O00
def OoooOo0 ( name , url ) :
 if 3 - 3: II111iiii * oO0o % Oo0Ooo % I1ii11iIi11i * oO00OO0oo0 / I1Ii111
 if 95 - 95: III1i1i * I1IiiI * i1iiI11I . OoO0O00 % oO0o + iII111i
 if 'https://www.rapidvideo.com/v/' in url :
  if 98 - 98: IiII . OoO0O00
  OoOO0o = i1II1 ( url )
  i11i1 = re . compile ( 'rapidvideo' ) . findall ( OoOO0o )
  for url in i11i1 :
   if 54 - 54: I1IiiI / III1i1i % iiIi * OoOoOO00 * I1IiiI
   if 48 - 48: Ii1I . IiII % I11i - I11i
   try :
    IIIIii = oo000 . getSetting ( 'notificar' )
    if IIIIii == 'true' :
     xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    O0ooOOO = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0ooOOO )
    if 33 - 33: ooOoO0o % o0oOOo0O0Ooo + OOooOOo
   except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 93 - 93: OoOoOO00 . III1i1i / I1ii11iIi11i + III1i1i
   if 58 - 58: iII111i + I1IiiI . oO0o + I11i - OOooOOo - I11i
 else :
  if 41 - 41: oO0o / OoOoOO00 / oO0o - oO00OO0oo0 . Ii1I
  import urlresolver
  from urlresolver import common
  if 65 - 65: I1IiiI * II111iiii . OoO0O00 / I1ii11iIi11i / oO00OO0oo0
  oOooO00o0O = urlresolver . HostedMediaFile ( url )
  if 69 - 69: iiIi % iiIi
  if not oOooO00o0O :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 76 - 76: II111iiii * oO00OO0oo0 / OOooOOo % iII111i + I1Ii111
   if 48 - 48: Oo0Ooo % OoOoOO00 + I11i % Ii1I
  try :
   o0OO000ooOo = oOooO00o0O . resolve ( )
   if not o0OO000ooOo or not isinstance ( o0OO000ooOo , basestring ) :
    try : oOo00OooO0oO = o0OO000ooOo . msg
    except : oOo00OooO0oO = url
    raise Exception ( oOo00OooO0oO )
  except Exception as Oo0OO0000oooo :
   try : oOo00OooO0oO = str ( Oo0OO0000oooo )
   except : oOo00OooO0oO = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 79 - 79: I11i % I1ii11iIi11i % o00O0oo / OoOoOO00 % OOooOOo
  IIIIii = oo000 . getSetting ( 'notificar' )
  if IIIIii == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  O0ooOOO = xbmcgui . ListItem ( path = o0OO000ooOo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0ooOOO )
  if 56 - 56: Oo0Ooo - II111iiii * oO00OO0oo0
 return
 if 84 - 84: I1Ii111 + o00O0oo + Ii1I
 if 33 - 33: o00O0oo
 if 93 - 93: iiIi
def II11iIIii ( name , url ) :
 if 57 - 57: I1IiiI * iII111i . II111iiii
 o0OO000ooOo = url
 IIIIii = oo000 . getSetting ( 'notificar' )
 if IIIIii == 'true' :
  xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
  O0ooOOO = xbmcgui . ListItem ( path = o0OO000ooOo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0ooOOO )
 else :
  O0ooOOO = xbmcgui . ListItem ( path = o0OO000ooOo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0ooOOO )
 return
 if 69 - 69: I1IiiI / o0oOOo0O0Ooo * OoOoOO00
def oOIiiIIi ( name , url ) :
 if 96 - 96: OoOoOO00 . ooOoO0o + IiII + iII111i * I1Ii111 - o0oOOo0O0Ooo
 if 1 - 1: I1IiiI
 if '[Youtube]' in name :
  if 40 - 40: i1iiI11I - I11i * ooOoO0o - III1i1i / I11i
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 71 - 71: IiII / OoO0O00 % III1i1i / I11i % i1iiI11I
  try :
   IIIIii = oo000 . getSetting ( 'notificar' )
   if IIIIii == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    O0ooOOO = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0ooOOO )
    if 19 - 19: i1iiI11I + III1i1i / IiII / o0oOOo0O0Ooo
    if 92 - 92: OoOoOO00 % iiIi + iiIi - Oo0Ooo . o00O0oo
    if 33 - 33: Ii1I / I1IiiI + I1Ii111
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 75 - 75: III1i1i % II111iiii + Oo0Ooo
  if 92 - 92: I11i % I1IiiI
 else :
  if 55 - 55: Oo0Ooo * oO00OO0oo0
  import xbmcgui
  import urlresolver
  from urlresolver import common
  if 85 - 85: Oo0Ooo . o0oOOo0O0Ooo
  oOooO00o0O = urlresolver . HostedMediaFile ( url )
  if 54 - 54: o00O0oo . OoO0O00 % oO0o
  if not oOooO00o0O :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 22 - 22: I1Ii111
  import resolveurl as urlresolver
  if 22 - 22: oO00OO0oo0 * ooOoO0o - oO0o * I1IiiI / II111iiii
  oOooO00o0O = urlresolver . HostedMediaFile ( url )
  if 78 - 78: oO0o * I1IiiI / iiIi + OoO0O00 + I1Ii111
  if 23 - 23: oO00OO0oo0 % OoO0O00 / Oo0Ooo + iII111i / OoOoOO00 / Ii1I
  if not oOooO00o0O :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 94 - 94: OoOoOO00
  try :
   o0OO000ooOo = oOooO00o0O . resolve ( )
   if not o0OO000ooOo or not isinstance ( o0OO000ooOo , basestring ) :
    try : oOo00OooO0oO = o0OO000ooOo . msg
    except : oOo00OooO0oO = url
    raise Exception ( oOo00OooO0oO )
  except Exception as Oo0OO0000oooo :
   try : oOo00OooO0oO = str ( Oo0OO0000oooo )
   except : oOo00OooO0oO = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   return False
   if 36 - 36: I1ii11iIi11i + oO0o
   if 46 - 46: oO00OO0oo0
   if 65 - 65: OoOoOO00 . iII111i / iiIi
  IIIIii = oo000 . getSetting ( 'notificar' )
  if IIIIii == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 11 - 11: III1i1i * iiIi / iiIi - I1Ii111
   if '[Realstream]' in name :
    if 68 - 68: I1ii11iIi11i % III1i1i - III1i1i / I1ii11iIi11i + iII111i - oO0o
    OO00Oo = oo000 . getSetting ( 'restante' )
    if OO00Oo == 'true' :
     IIi = xbmcgui . Dialog ( )
     OOooo0O = IIi . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 65 - 65: iiIi - OoOoOO00
   O0ooOOO = xbmcgui . ListItem ( path = o0OO000ooOo )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0ooOOO )
   if 62 - 62: ooOoO0o / IiII % oO0o . OoO0O00 / II111iiii / i1iiI11I
   if 60 - 60: I1ii11iIi11i % IiII / Ii1I % IiII * II111iiii / oO00OO0oo0
   if 34 - 34: i1iiI11I - I1Ii111
 return
 if 25 - 25: IiII % I1ii11iIi11i + II111iiii + I1IiiI * OoO0O00
 if 64 - 64: OoOoOO00
 if 10 - 10: i1iiI11I % I1IiiI / I1ii11iIi11i % ooOoO0o
def iiII ( name , url ) :
 if 28 - 28: iiIi . OoO0O00 + Ii1I + o00O0oo % oO00OO0oo0
 if 80 - 80: oO0o
 if '[Youtube]' in name :
  if 86 - 86: iII111i * ooOoO0o . I11i / oO0o + IiII
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 8 - 8: I11i
  try :
   IIIIii = oo000 . getSetting ( 'notificar' )
   if IIIIii == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    O0ooOOO = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0ooOOO )
    if 16 - 16: Ii1I . ooOoO0o
    if 50 - 50: iiIi * I11i + iII111i - II111iiii + oO0o * iII111i
    if 20 - 20: i1iiI11I / Ii1I % I11i
  except : xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
  if 69 - 69: i1iiI11I - OoOoOO00 % oO00OO0oo0 . I1Ii111 - I1Ii111
 else :
  if 65 - 65: I1Ii111 + o0oOOo0O0Ooo
  import resolveurl
  if 61 - 61: II111iiii * IiII % oO0o * i1iiI11I - OoO0O00 - OOooOOo
  oOooO00o0O = urlresolver . HostedMediaFile ( url )
  if 83 - 83: iiIi / I1Ii111
  if 39 - 39: III1i1i + ooOoO0o
  if not oOooO00o0O :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 9 - 9: I1ii11iIi11i % ooOoO0o . oO0o * I1ii11iIi11i
  try :
   o0OO000ooOo = oOooO00o0O . resolve ( )
   if not o0OO000ooOo or not isinstance ( o0OO000ooOo , basestring ) :
    try : oOo00OooO0oO = o0OO000ooOo . msg
    except : oOo00OooO0oO = url
    raise Exception ( oOo00OooO0oO )
  except Exception as Oo0OO0000oooo :
   try : oOo00OooO0oO = str ( Oo0OO0000oooo )
   except : oOo00OooO0oO = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 99 - 99: I1IiiI . Ii1I % ooOoO0o - oO0o / ooOoO0o
   if 20 - 20: I11i * oO00OO0oo0
   if 19 - 19: OoO0O00
  IIIIii = oo000 . getSetting ( 'notificar' )
  if IIIIii == 'true' :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
   if 76 - 76: OOooOOo * IiII
   if '[Realstream]' in name :
    if 63 - 63: o0oOOo0O0Ooo . o0oOOo0O0Ooo + iII111i + I1Ii111 + I1IiiI . o00O0oo
    OO00Oo = oo000 . getSetting ( 'restante' )
    if OO00Oo == 'true' :
     IIi = xbmcgui . Dialog ( )
     OOooo0O = IIi . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 1 - 1: I1IiiI * II111iiii - iiIi - o00O0oo
   O0ooOOO = xbmcgui . ListItem ( path = o0OO000ooOo )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0ooOOO )
   if 94 - 94: OOooOOo + III1i1i + iiIi
   if 82 - 82: oO0o - oO0o . Oo0Ooo / I1Ii111 + III1i1i % Oo0Ooo
   if 61 - 61: I1Ii111 / oO0o % I1Ii111 - OOooOOo + iiIi / iiIi
 return
 if 82 - 82: oO0o
 if 5 - 5: OOooOOo / OOooOOo - I1IiiI - i1iiI11I + i1iiI11I
 if 99 - 99: ooOoO0o * OoO0O00 / Ii1I . III1i1i - Oo0Ooo - o00O0oo
def I1iIiIii ( name , url ) :
 if 76 - 76: OOooOOo . OoO0O00 % i1iiI11I * o00O0oo
 if 23 - 23: III1i1i + Oo0Ooo
 if '[Youtube]' in name :
  if 14 - 14: I1IiiI % III1i1i % o00O0oo * IiII
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 65 - 65: ooOoO0o % IiII + iII111i
  try :
   IIIIii = oo000 . getSetting ( 'notificar' )
   if IIIIii == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    O0ooOOO = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0ooOOO )
    if 86 - 86: Oo0Ooo / I1IiiI . i1iiI11I % Oo0Ooo % oO0o
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 86 - 86: II111iiii - Ii1I . iiIi * oO0o / o00O0oo % Ii1I
 else :
  if 61 - 61: Ii1I + I11i
  if 'https://team.com' in url :
   if 15 - 15: I11i * IiII + I1Ii111 . ooOoO0o % I1ii11iIi11i - iiIi
   url = url . replace ( 'https://team.com' , 'https://verystream.com' )
   if 13 - 13: I11i % I11i % oO0o % I1ii11iIi11i * OoOoOO00 % ooOoO0o
  if 'https://mybox.com' in url :
   if 82 - 82: III1i1i . I11i / iiIi + oO00OO0oo0 - iiIi
   url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
   if 55 - 55: iiIi % oO0o % Ii1I
  if 'https://drive.com' in url :
   if 29 - 29: III1i1i / Oo0Ooo + iII111i % oO00OO0oo0 % ooOoO0o
   url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
   if 46 - 46: Oo0Ooo
  if 'https://vid.co' in url :
   if 70 - 70: OoOoOO00 . ooOoO0o
   url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
   if 74 - 74: ooOoO0o
  if 'https://limited.to' in url :
   if 58 - 58: Oo0Ooo * OOooOOo * i1iiI11I * iiIi . OoO0O00
   url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
   if 6 - 6: iII111i - IiII * II111iiii + I11i / iiIi % I1Ii111
  import resolveurl
  if 38 - 38: I1Ii111 % III1i1i % o0oOOo0O0Ooo - oO0o - Oo0Ooo
  oOooO00o0O = urlresolver . HostedMediaFile ( url )
  if 9 - 9: Ii1I % iII111i . iII111i
  if 28 - 28: OoO0O00 % IiII + iII111i + I1IiiI . i1iiI11I
  if not oOooO00o0O :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace no encontrado para: [COLOR orange]" + name + "[/COLOR] ,5000)" )
   return False
   if 80 - 80: II111iiii % iII111i
  try :
   o0OO000ooOo = oOooO00o0O . resolve ( )
   if not o0OO000ooOo or not isinstance ( o0OO000ooOo , basestring ) :
    try : oOo00OooO0oO = o0OO000ooOo . msg
    except : oOo00OooO0oO = url
    raise Exception ( oOo00OooO0oO )
  except Exception as Oo0OO0000oooo :
   try : oOo00OooO0oO = str ( Oo0OO0000oooo )
   except : oOo00OooO0oO = url
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace borrado, o no encontrado. Prueba a reiniciar el router o poner una VPN.[/COLOR]  ,5000)" )
   return False
   if 54 - 54: Ii1I + ooOoO0o - Oo0Ooo % iiIi % III1i1i
   if 19 - 19: iII111i / Oo0Ooo % OoOoOO00 . OoO0O00
   if 57 - 57: iiIi . oO0o - OOooOOo - II111iiii * i1iiI11I / Ii1I
   IIIIii = oo000 . getSetting ( 'notificar' )
   if IIIIii == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,5000)" )
    if 79 - 79: iII111i + Ii1I % oO0o * Ii1I
    if '[Realstream]' or '[Mybox]' in name :
     OO00Oo = oo000 . getSetting ( 'restante' )
    elif OO00Oo == 'true' :
     IIi = xbmcgui . Dialog ( )
     OOooo0O = IIi . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
     if 21 - 21: oO00OO0oo0
  O0ooOOO = xbmcgui . ListItem ( path = o0OO000ooOo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0ooOOO )
  if 24 - 24: oO00OO0oo0 / iiIi
 return
 if 61 - 61: Oo0Ooo + IiII
def i1IiiI ( name , url ) :
 if 70 - 70: ooOoO0o . I1Ii111 * oO0o / I1Ii111
 if 83 - 83: OoO0O00 + OOooOOo * IiII . I1IiiI
 if '[Youtube]' in name :
  if 13 - 13: Ii1I
  url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
  if 7 - 7: I1ii11iIi11i + III1i1i / II111iiii / oO0o
  try :
   IIIIii = oo000 . getSetting ( 'notificar' )
   if IIIIii == 'true' :
    xbmc . executebuiltin ( "XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" + name + "[/COLOR] ,7500)" )
    O0ooOOO = xbmcgui . ListItem ( path = url )
    xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0ooOOO )
    if 97 - 97: i1iiI11I . ooOoO0o / I1ii11iIi11i
  except :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" + name + "[/COLOR] ,7500)" )
   pass
   if 83 - 83: ooOoO0o - iII111i * IiII
 else :
  if 90 - 90: oO0o * I1ii11iIi11i
  if 'https://team.com' in url :
   if 75 - 75: iII111i - I11i * II111iiii . OoO0O00 - oO0o . ooOoO0o
   url = url . replace ( 'https://team.com' , 'https://verystream.com' )
   if 6 - 6: ooOoO0o * IiII / OoO0O00 % o00O0oo * Ii1I
  if 'https://mybox.com' in url :
   if 28 - 28: III1i1i * I1ii11iIi11i % III1i1i
   url = url . replace ( 'https://mybox.com' , 'https://uptostream.com' )
   if 95 - 95: I1IiiI / ooOoO0o . i1iiI11I
  if 'https://drive.com' in url :
   if 17 - 17: ooOoO0o
   url = url . replace ( 'https://drive.com' , 'https://drive.google.com' )
   if 56 - 56: iiIi * Ii1I + ooOoO0o
  if 'https://vid.co' in url :
   if 48 - 48: III1i1i * OOooOOo % i1iiI11I - ooOoO0o
   url = url . replace ( 'https://vid.co' , 'https://vidcloud.co' )
   if 72 - 72: OoOoOO00 % iiIi % III1i1i % IiII - IiII
  if 'https://limited.to' in url :
   if 97 - 97: Ii1I * I1IiiI / Ii1I * OOooOOo * oO0o
   url = url . replace ( 'https://limited.to' , 'https://gounlimited.to' )
   if 38 - 38: i1iiI11I
  import resolveurl
  if 25 - 25: Oo0Ooo % o0oOOo0O0Ooo / ooOoO0o / iII111i
  oOooO00o0O = urlresolver . HostedMediaFile ( url )
  OOo0 = xbmcgui . DialogProgress ( )
  OOo0 . create ( 'Realstream:' , 'Conectando al servidor ... ' )
  OOo0 . update ( 20 , 'Por favor, espere ...' )
  xbmc . sleep ( 500 )
  if 22 - 22: IiII * oO00OO0oo0
  if not oOooO00o0O :
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
   return False
   if 4 - 4: I11i - IiII + I1ii11iIi11i
  try :
   if 36 - 36: III1i1i
   OOo0 . update ( 50 , 'RESOLVEURL:' , 'Comprobando que existe el enlace.' )
   xbmc . sleep ( 500 )
   o0OO000ooOo = oOooO00o0O . resolve ( )
   if not o0OO000ooOo or not isinstance ( o0OO000ooOo , basestring ) :
    try : oOo00OooO0oO = o0OO000ooOo . msg
    except : oOo00OooO0oO = o0OO000ooOo
    raise Exception ( oOo00OooO0oO )
  except Exception as Oo0OO0000oooo :
   try : oOo00OooO0oO = str ( Oo0OO0000oooo )
   except : oOo00OooO0oO = o0OO000ooOo
   OOo0 . update ( 100 , 'RESOLVEURL:' , 'Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.' )
   OOo0 . close ( )
   xbmc . executebuiltin ( "XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)" )
   if 19 - 19: I11i . Ii1I . OoO0O00
  OOo0 . update ( 50 , 'RESOLVEURL:' , 'Comprobando si existe el enlace.' )
  xbmc . sleep ( 500 )
  OOo0 . update ( 75 , 'RESOLVEURL:' , 'Resolviendo enlace ...' )
  xbmc . sleep ( 500 )
  OOo0 . update ( 95 , 'RESOLVEURL:' , 'Encontrado ...' )
  xbmc . sleep ( 500 )
  OOo0 . update ( 100 , 'RESOLVEURL:' , 'Disfrute de la pelicula!' )
  OOo0 . close ( )
  IIIIii = oo000 . getSetting ( 'notificar' )
  if 13 - 13: I1Ii111 . oO0o / o0oOOo0O0Ooo
  if 43 - 43: Oo0Ooo % OOooOOo
  if '[Realstream]' or '[Mybox]' in name :
   OO00Oo = oo000 . getSetting ( 'restante' )
  elif OO00Oo == 'true' :
   IIi = xbmcgui . Dialog ( )
   OOooo0O = IIi . ok ( "[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]" )
  O0ooOOO = xbmcgui . ListItem ( path = o0OO000ooOo )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , O0ooOOO )
  if 84 - 84: oO0o
 return
 if 44 - 44: OoO0O00 * II111iiii / oO0o
def OoO ( ) :
 if 67 - 67: iII111i + o00O0oo
 if 72 - 72: III1i1i % Ii1I
 OooooO = [ ]
 oO00OoO0oo = sys . argv [ 2 ]
 if len ( oO00OoO0oo ) >= 2 :
  o00o0o000Oo = sys . argv [ 2 ]
  Oooo00OOo = o00o0o000Oo . replace ( '?' , '' )
  if ( o00o0o000Oo [ len ( o00o0o000Oo ) - 1 ] == '/' ) :
   o00o0o000Oo = o00o0o000Oo [ 0 : len ( o00o0o000Oo ) - 2 ]
  iIiII = Oooo00OOo . split ( '&' )
  OooooO = { }
  for OooOO in range ( len ( iIiII ) ) :
   iio0oo0Oo = { }
   iio0oo0Oo = iIiII [ OooOO ] . split ( '=' )
   if ( len ( iio0oo0Oo ) ) == 2 :
    OooooO [ iio0oo0Oo [ 0 ] ] = iio0oo0Oo [ 1 ]
 return OooooO
 if 10 - 10: iII111i
 if 87 - 87: oO0o % o00O0oo
def ooO0o0oO0 ( ) :
 try :
  import resolveurl
  xbmcaddon . Addon ( 'script.module.resolveurl' ) . openSettings ( )
 except :
  import urlresolver
  xbmcaddon . Addon ( 'script.module.urlresolver' ) . openSettings ( )
  if 66 - 66: i1iiI11I % I1IiiI
def o0o0ooOo00 ( ) :
 IIi = xbmcgui . Dialog ( )
 list = (
 OO00oO0OoO0o ,
 I11I111i1I1
 )
 if 41 - 41: OoO0O00 / OoOoOO00
 oO0o00oOOooO0 = IIi . select ( '[B][COLOR=orange]The Movie db[/COLOR][/B]' , [
 '[COLOR=%s]Accede a themoviedb.com[/COLOR]' % Oo0OoO00oOO0o ,

 '[B][COLOR=white]                           Volver al Menu [/COLOR][/B]' , ] )
 if 70 - 70: I11i % Ii1I % OoOoOO00 / iII111i % II111iiii / OoOoOO00
 if oO0o00oOOooO0 :
  if 4 - 4: III1i1i
  if oO0o00oOOooO0 < 0 :
   return
  ooO0o = list [ oO0o00oOOooO0 - 2 ]
  return ooO0o ( )
 else :
  ooO0o = list [ oO0o00oOOooO0 ]
  return ooO0o ( )
 return
 if 93 - 93: IiII % OoOoOO00
def oooO0o0o0O0 ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 83 - 83: I1ii11iIi11i . oO0o - ooOoO0o . Ii1I
OOooOo00oo0 = oooO0o0o0O0 ( )
if 73 - 73: I1ii11iIi11i - oO00OO0oo0 . oO00OO0oo0
def OO00oO0OoO0o ( ) :
 if OOooOo00oo0 == 'android' :
  IIiiIIi1 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
 else :
  IIiiIIi1 = webbrowser . open ( 'https://www.themoviedb.org/movie/' )
  if 22 - 22: iiIi / iiIi - o00O0oo % ooOoO0o . I1Ii111 + III1i1i
  if 64 - 64: OoOoOO00 % iII111i / o00O0oo % OoO0O00
def I11I111i1I1 ( ) :
 if 24 - 24: i1iiI11I + OoO0O00 . III1i1i / I11i / ooOoO0o
 main ( )
 if 65 - 65: OoO0O00
 if 18 - 18: I1IiiI - OoOoOO00 . i1iiI11I
 if 98 - 98: Ii1I
def OOo00Oooo ( ) :
 IIi = xbmcgui . Dialog ( )
 ooOooo0 = (
 I1oO0oOOOooo ,
 Ii1iiI1i1
 )
 if 3 - 3: I1Ii111 . III1i1i / oO0o
 oO0o00oOOooO0 = IIi . select ( '[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]' , [
 '[COLOR=orange]                       Pair OpenLoad [/COLOR]' ,

 '[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]' , ] )
 if 89 - 89: OoO0O00 . Oo0Ooo . oO0o * Oo0Ooo - i1iiI11I
 if oO0o00oOOooO0 :
  if 92 - 92: OoO0O00 - iII111i - OoO0O00 % I1ii11iIi11i % I1ii11iIi11i % Oo0Ooo
  if oO0o00oOOooO0 < 0 :
   return
  ooO0o = ooOooo0 [ oO0o00oOOooO0 - 2 ]
  return ooO0o ( )
 else :
  ooO0o = ooOooo0 [ oO0o00oOOooO0 ]
  return ooO0o ( )
 return
 if 92 - 92: oO00OO0oo0 * I1IiiI % i1iiI11I . Oo0Ooo
def oooO0o0o0O0 ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 66 - 66: ooOoO0o + o00O0oo
OOooOo00oo0 = oooO0o0o0O0 ( )
if 48 - 48: iII111i
def I1oO0oOOOooo ( ) :
 if OOooOo00oo0 == 'android' :
  IIiiIIi1 = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  IIiiIIi1 = webbrowser . open ( 'https://olpair.com/' )
  if 96 - 96: iiIi . OoO0O00
  if 39 - 39: I1Ii111 + OOooOOo
def Ii1iiI1i1 ( ) :
 if 80 - 80: I1Ii111 % OOooOOo / I11i
 main ( )
 if 54 - 54: oO0o % OOooOOo - I1Ii111 - ooOoO0o
 if 71 - 71: iiIi . II111iiii
def OoO000oo000o0 ( name , url , id , trailer ) :
 IIi = xbmcgui . Dialog ( )
 ooOooo0 = (
 i1Ii1I1Ii11iI ,
 i1ii111i ,
 i1ii1i1Ii11 ,
 o0o0ooOo00 ,
 O0O0Oo0O0oo
 )
 if 62 - 62: ooOoO0o / iII111i
 oO0o00oOOooO0 = IIi . select ( '[COLOR=orange]REAL STREAM MENU:[/COLOR]' , [

 '[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % Oo0OoO00oOO0o ,

 '[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % Oo0OoO00oOO0o ,

 '[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % Oo0OoO00oOO0o ,

 '[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % Oo0OoO00oOO0o ,

 '[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % Oo0OoO00oOO0o ] )
 if 85 - 85: I1ii11iIi11i + oO00OO0oo0 - oO00OO0oo0 . OoO0O00 - Oo0Ooo
 if oO0o00oOOooO0 :
  if 8 - 8: II111iiii * Ii1I / iII111i . o00O0oo
  if oO0o00oOOooO0 < 0 :
   return
  ooO0o = ooOooo0 [ oO0o00oOOooO0 - 5 ]
  return ooO0o ( )
 else :
  ooO0o = ooOooo0 [ oO0o00oOOooO0 ]
  return ooO0o ( )
 return
 if 31 - 31: II111iiii - iiIi / iII111i - o00O0oo
 if 5 - 5: II111iiii * oO0o
 if 29 - 29: o00O0oo / iiIi % ooOoO0o
def i1Ii1I1Ii11iI ( ) :
 if 10 - 10: Oo0Ooo % OoO0O00 % iII111i
 i1IiiI ( OOOooo , OooO0OO )
 if 39 - 39: o0oOOo0O0Ooo * I11i . I1IiiI * ooOoO0o
def i1ii111i ( ) :
 if 89 - 89: o00O0oo - iiIi . ooOoO0o - i1iiI11I - I1ii11iIi11i
 oOoO0OOO00O ( OOOooo , o0OOo0o0O0O )
 if 79 - 79: III1i1i + III1i1i + o00O0oo
def i1ii1i1Ii11 ( ) :
 if 39 - 39: I1IiiI - OoO0O00
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  oo0O00ooo0o = id
  if 29 - 29: OoO0O00 . o0oOOo0O0Ooo % I11i
  xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % oo0O00ooo0o )
  if 26 - 26: Oo0Ooo - iII111i . III1i1i . III1i1i + Oo0Ooo * oO0o
 if IIIIii == 'true' :
  if 85 - 85: I1Ii111 + o0oOOo0O0Ooo - I1Ii111 * IiII - OoOoOO00 % oO00OO0oo0
  xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + OOOooo + "[/COLOR] ,5000)" )
  if 1 - 1: OoO0O00 / I1IiiI + I11i + I11i . i1iiI11I - I11i
def I11iii1I1Iiii ( ) :
 if 47 - 47: II111iiii / oO0o - oO0o * OOooOOo
 o0o0ooOo00 ( )
 if 48 - 48: III1i1i
def O0O0Oo0O0oo ( ) :
 if 96 - 96: IiII / I1IiiI . o0oOOo0O0Ooo + III1i1i % Ii1I
 O000OOO0OOo ( )
def oo0oOoo ( name , url , mode , iconimage , fanart ) :
 if 67 - 67: I1IiiI % i1iiI11I
 OOOOoo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 OOooo0O = True
 o000 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 o000 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 o000 . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  OOOOoo = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  OOooo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOOOoo , listitem = o000 , isFolder = True )
  return OOooo0O
 OOooo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOOOoo , listitem = o000 , isFolder = True )
 return OOooo0O
 if 35 - 35: I1ii11iIi11i . I11i + OoO0O00 % oO0o % I1Ii111
def I111I1I ( name , url , mode , iconimage , fanart , id , trailer ) :
 if 39 - 39: o00O0oo
 i1 = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt' . decode ( 'base64' )
 if 60 - 60: I1Ii111
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 o000ooOo0o0OO = [ ]
 if 1 - 1: Oo0Ooo % iiIi + I1IiiI
 o000ooOo0o0OO . append ( ( "Reproducir Trailer" , "XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % ( trailer ) ) )
 OOOOoo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id ) + "&trailer=" + urllib . quote_plus ( trailer )
 o000 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 o000 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 o000 . setProperty ( 'fanart_image' , fanart )
 o000 . setProperty ( 'IsPlayable' , 'true' )
 if 22 - 22: Ii1I + oO0o . iiIi + iII111i * oO00OO0oo0 . II111iiii
 if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
  o000ooOo0o0OO . append ( ( "[B][COLOR yellow]ExtendedInfo[/COLOR][/B]" , "XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % ( name , id ) ) )
  if 90 - 90: I1Ii111 * I11i - oO0o + Ii1I
  o000 . addContextMenuItems ( o000ooOo0o0OO , replaceItems = True )
 OOooo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOOOoo , listitem = o000 )
 return OOooo0O
 if 53 - 53: OoO0O00 . OoO0O00 + Ii1I - oO00OO0oo0 + I1Ii111
def oOo0OO0o0 ( name , url , mode , iconimage , fanart ) :
 if 44 - 44: i1iiI11I - III1i1i
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 100 - 100: IiII . OOooOOo - o00O0oo + I1IiiI * OOooOOo
 OOOOoo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&id=" + str ( id )
 o000 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 o000 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 o000 . setProperty ( 'fanart_image' , fanart )
 o000 . setProperty ( 'IsPlayable' , 'true' )
 OOooo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOOOoo , listitem = o000 )
 return OOooo0O
 if 59 - 59: o0oOOo0O0Ooo
def iIiIi11I1iIii1i11 ( name , url , mode ) :
 if 42 - 42: OOooOOo * II111iiii
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 if 16 - 16: oO00OO0oo0 % I1ii11iIi11i - iiIi
 OOOOoo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 o000 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = I11I1 )
 o000 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 o000 . setProperty ( 'fanart_image' , O0oOO0o0 )
 o000 . setProperty ( 'IsPlayable' , 'true' )
 OOooo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOOOoo , listitem = o000 )
 return OOooo0O
 if 100 - 100: OoO0O00 * IiII
def OoO0o0OO ( name , url , mode , iconimage ) :
 OOOOoo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 OOooo0O = True
 o000 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 OOooo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOOOoo , listitem = o000 , isFolder = True )
 return OOooo0O
 if 10 - 10: IiII - oO00OO0oo0 % o0oOOo0O0Ooo - i1iiI11I - OoOoOO00
def iIi11iI1i ( ) :
 if 46 - 46: OoOoOO00 + o0oOOo0O0Ooo * OoOoOO00 - o00O0oo
 if 79 - 79: o0oOOo0O0Ooo - IiII * iII111i - I11i . iII111i
 if 11 - 11: I1IiiI * I11i
 i11III1111iIi = xbmc . Keyboard ( '' , 'Escriba id de la pelicula: Themoviedb.org' )
 i11III1111iIi . doModal ( )
 if ( i11III1111iIi . isConfirmed ( ) ) :
  if 37 - 37: I11i + I1IiiI . I1IiiI * oO0o % i1iiI11I / oO00OO0oo0
  iI11 = urllib . quote_plus ( i11III1111iIi . getText ( ) ) . replace ( '+' , ' ' )
  if 18 - 18: OoO0O00
  if xbmc . getCondVisibility ( 'System.HasAddon(script.extendedinfo)' ) :
   try :
    if 57 - 57: iiIi . I11i * Ii1I - OoO0O00
    xbmc . executebuiltin ( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % iI11 )
    if 75 - 75: II111iiii / Ii1I . III1i1i . OoOoOO00 . OoOoOO00 / ooOoO0o
    if IIIIii == 'true' :
     if 94 - 94: iiIi + I1ii11iIi11i
     xbmc . executebuiltin ( "XBMC.Notification(Extended Info,Abriendo: [COLOR green]" + OOOooo + "[/COLOR] ,10000)" )
     if 56 - 56: I11i % Ii1I
   except :
    if 40 - 40: I1Ii111 / III1i1i
    xbmcgui . Dialog ( ) . ok ( "El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]" , "[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]" )
    if 29 - 29: o00O0oo - o00O0oo / iiIi
    if 49 - 49: ooOoO0o + IiII % OOooOOo - oO0o - I1IiiI - OoO0O00
    if 4 - 4: o0oOOo0O0Ooo - IiII % oO0o * II111iiii
o00o0o000Oo = OoO ( )
OooO0OO = None
OOOooo = None
iIiII1iiiiI = None
I11I1 = None
id = None
o0OOo0o0O0O = None
if 80 - 80: oO0o - Ii1I - o0oOOo0O0Ooo . III1i1i - I1IiiI * III1i1i
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 43 - 43: I1ii11iIi11i / oO00OO0oo0 / iiIi + Oo0Ooo + OoO0O00
try :
 OooO0OO = urllib . unquote_plus ( o00o0o000Oo [ "url" ] )
except :
 pass
try :
 OOOooo = urllib . unquote_plus ( o00o0o000Oo [ "name" ] )
except :
 pass
try :
 iIiII1iiiiI = int ( o00o0o000Oo [ "mode" ] )
except :
 pass
try :
 I11I1 = urllib . unquote_plus ( o00o0o000Oo [ "iconimage" ] )
except :
 pass
try :
 id = int ( o00o0o000Oo [ "id" ] )
except :
 pass
try :
 o0OOo0o0O0O = urllib . unquote_plus ( o00o0o000Oo [ "trailer" ] )
except :
 pass
 if 33 - 33: o0oOOo0O0Ooo - III1i1i - iiIi
 if 92 - 92: OOooOOo * III1i1i
print "Mode: " + str ( iIiII1iiiiI )
print "URL: " + str ( OooO0OO )
print "Name: " + str ( OOOooo )
print "iconimage: " + str ( I11I1 )
print "id: " + str ( id )
print "trailer: " + str ( o0OOo0o0O0O )
if 92 - 92: IiII
if iIiII1iiiiI == None or OooO0OO == None or len ( OooO0OO ) < 1 :
 if O00O0oOO00O00 == i1 :
  if 7 - 7: oO00OO0oo0
  if 73 - 73: OOooOOo % iII111i
  IIiI1Ii ( )
  if 32 - 32: I1Ii111 + oO00OO0oo0 + Oo0Ooo * oO0o
  if 62 - 62: II111iiii
  Oo0O0O0ooO0O = oo000 . getSetting ( 'licencia_addon' )
  iiIiII1 = '0110nhu' . replace ( '0110nhu' , 'nhu' )
  if 2 - 2: I1ii11iIi11i
  OOO00O0O = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Q1ZEtzY0ww' . decode ( 'base64' )
  oo0O = oo000 . getSetting ( 'key_ext' )
  OoOO0o = i1II1 ( OOO00O0O )
  i11i1 = re . compile ( iiIiI ) . findall ( OoOO0o )
  for O0o0o0ooO0ooo in i11i1 :
   try :
    if 47 - 47: III1i1i
    if 76 - 76: OOooOOo * Oo0Ooo + iII111i - iiIi - ooOoO0o / OoOoOO00
    Oo0O0O0ooO0O = oo000 . getSetting ( 'licencia_addon' )
    if 27 - 27: iII111i . III1i1i
    if 66 - 66: I1IiiI / I1IiiI * OoOoOO00 . OoO0O00 % Oo0Ooo
    if Oo0O0O0ooO0O == O0o0o0ooO0ooo :
     if 21 - 21: III1i1i - I1ii11iIi11i % OoO0O00 + Ii1I
     if 92 - 92: iiIi + III1i1i
     if 52 - 52: o0oOOo0O0Ooo / I1ii11iIi11i . IiII * III1i1i . ooOoO0o
     O000OOO0OOo ( )
     if 25 - 25: II111iiii / I11i - i1iiI11I / OOooOOo . Ii1I . Ii1I
    else :
     if 6 - 6: IiII . ooOoO0o
     xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red]Llave incorrecta o no esta vigente![/COLOR] [COLOR gold]>El addon esta desactivado.[/COLOR]" )
     if 43 - 43: iII111i + Ii1I
     if 50 - 50: IiII % OoOoOO00 * I1IiiI
   except :
    pass
    if 4 - 4: Oo0Ooo . OoOoOO00
 else :
  xbmcgui . Dialog ( ) . ok ( "Realstream:" , "[COLOR red][B]Error, de inicio. ¿Tienes Instalado Realstream?[/B][/COLOR]" )
  if 63 - 63: Oo0Ooo + III1i1i % OoOoOO00 / I1ii11iIi11i % o0oOOo0O0Ooo
  if 60 - 60: Ii1I . I11i % i1iiI11I / I1ii11iIi11i / I1IiiI
  if 19 - 19: II111iiii . I1ii11iIi11i + o0oOOo0O0Ooo / I1Ii111 . iII111i * iiIi
elif iIiII1iiiiI == 1 :
 OoO000oo000o0 ( OOOooo , OooO0OO , id , o0OOo0o0O0O )
elif iIiII1iiiiI == 2 :
 iI11iiii1I ( )
elif iIiII1iiiiI == 3 :
 oo0 ( )
elif iIiII1iiiiI == 4 :
 Iiii1Ii ( OOOooo , OooO0OO )
elif iIiII1iiiiI == 5 :
 Oo ( )
elif iIiII1iiiiI == 6 :
 Oo0oOooOoOo ( )
elif iIiII1iiiiI == 7 :
 Ii11iI1ii1111 ( )
elif iIiII1iiiiI == 8 :
 oo0O0o00 ( )
elif iIiII1iiiiI == 9 :
 ooOo0O0O0oOO0 ( )
elif iIiII1iiiiI == 10 :
 i1II11Iii1I ( )
elif iIiII1iiiiI == 11 :
 II11i1IiIII ( )
elif iIiII1iiiiI == 12 :
 oo0iIiI ( )
elif iIiII1iiiiI == 13 :
 iIii1iII1Ii ( )
elif iIiII1iiiiI == 14 :
 o00IiI1iiII1i1i ( )
elif iIiII1iiiiI == 15 :
 oOo00Ooo0o0 ( )
elif iIiII1iiiiI == 16 :
 IiiIiIi111iI1 ( )
elif iIiII1iiiiI == 17 :
 oO00o ( )
elif iIiII1iiiiI == 18 :
 iIIiI11i1I11 ( )
elif iIiII1iiiiI == 19 :
 Oo0O ( )
elif iIiII1iiiiI == 20 :
 ii1IoO0O ( )
elif iIiII1iiiiI == 21 :
 O0oOoo ( )
elif iIiII1iiiiI == 22 :
 ii1iIi1Ii1 ( )
elif iIiII1iiiiI == 23 :
 ooOoo0OoOO ( )
elif iIiII1iiiiI == 24 :
 i1I ( )
elif iIiII1iiiiI == 25 :
 Oo0O0oo0o00o0 ( )
elif iIiII1iiiiI == 26 :
 iIi ( )
elif iIiII1iiiiI == 28 :
 iiii1I1 ( OOOooo , OooO0OO )
elif iIiII1iiiiI == 29 :
 OO0oOOo0o ( )
elif iIiII1iiiiI == 30 :
 Ii1I1 ( )
elif iIiII1iiiiI == 98 :
 busqueda_global ( )
elif iIiII1iiiiI == 97 :
 OOo00Oooo ( )
elif iIiII1iiiiI == 99 :
 oOO0oo ( )
elif iIiII1iiiiI == 100 :
 menu_player ( OOOooo , OooO0OO )
elif iIiII1iiiiI == 111 :
 oOoO00O0 ( )
elif iIiII1iiiiI == 115 :
 oOoO0OOO00O ( OooO0OO )
elif iIiII1iiiiI == 116 :
 Iii1 ( )
elif iIiII1iiiiI == 117 :
 oOoOOo0oo0 ( )
elif iIiII1iiiiI == 119 :
 o0oo0000OO ( )
elif iIiII1iiiiI == 120 :
 O00oooo00o0O ( )
elif iIiII1iiiiI == 121 :
 Ooo0O ( )
elif iIiII1iiiiI == 125 :
 ooooO000 ( )
elif iIiII1iiiiI == 112 :
 OOOIiiiii1iI ( )
elif iIiII1iiiiI == 127 :
 iIi11iI1i ( )
elif iIiII1iiiiI == 128 :
 TESTLINKS ( )
elif iIiII1iiiiI == 130 :
 i1IiiI ( OOOooo , OooO0OO )
elif iIiII1iiiiI == 140 :
 oOO0 ( )
elif iIiII1iiiiI == 141 :
 oo0OoOO0o0o ( )
elif iIiII1iiiiI == 142 :
 II11i11Iii ( )
elif iIiII1iiiiI == 143 :
 IIiiii ( OOOooo , OooO0OO )
elif iIiII1iiiiI == 144 :
 iiii1I1 ( OOOooo , OooO0OO )
elif iIiII1iiiiI == 145 :
 oo0OOo0O ( )
elif iIiII1iiiiI == 150 :
 IIii11II11II1 ( )
elif iIiII1iiiiI == 151 :
 II11 ( )
xbmcplugin . endOfDirectory ( oOOo ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
