script.module.pyrrent2http
==========================

This add-on is engine for [plugin.video.torrenter](https://github.com/DiMartinoXBMC/plugin.video.torrenter) 

This add-on can be used to stream media files from torrents without need to download entire files.

Данный движок для модуля Torrenter v2 медиа-центра KODI (XBMC) появился из-за отсутствия рабочего решения для Raspberry Pi.
Сейчас pyrrent2http работает на множестве платформ.
