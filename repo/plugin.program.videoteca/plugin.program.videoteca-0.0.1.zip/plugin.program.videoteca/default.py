import urlresolver
if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * Ii1I
if 46 - 46: ooOoO0o * I11i - OoooooooOO
if 30 - 30: o0oOOo0O0Ooo - O0 % o0oOOo0O0Ooo - OoooooooOO * O0 * OoooooooOO
if 60 - 60: iIii1I11I1II1 / i1IIi * oO0o - I1ii11iIi11i + o0oOOo0O0Ooo
if 94 - 94: i1IIi % Oo0Ooo
if 68 - 68: Ii1I / O0
if 46 - 46: O0 * II111iiii / IiII * Oo0Ooo * iII111i . I11i
if 62 - 62: i11iIiiIii - II111iiii % I1Ii111 - iIii1I11I1II1 . I1ii11iIi11i . II111iiii
if 61 - 61: oO0o / OoOoOO00 / iII111i * OoO0O00 . II111iiii
if 1 - 1: II111iiii - I1ii11iIi11i % i11iIiiIii + IiII . I1Ii111
if 55 - 55: iIii1I11I1II1 - I1IiiI . Ii1I * IiII * i1IIi / iIii1I11I1II1
if 79 - 79: oO0o + I1Ii111 . ooOoO0o * IiII % I11i . I1IiiI
import xbmcgui
import xbmcplugin
import sys
import os
import shutil
from url_dispatcher import URL_Dispatcher
import log_utils
import kodi
if 94 - 94: iII111i * Ii1I / IiII . i1IIi * iII111i
iiiii11iII1 = log_utils . Logger . get_logger ( )
if 54 - 54: ooOoO0o . ooOoO0o / iIii1I11I1II1 / I11i + oO0o / o0oOOo0O0Ooo
def I1i1I ( ** enums ) :
 return type ( 'Enum' , ( ) , enums )
 if 72 - 72: Oo0Ooo % OOooOOo . I1IiiI / I11i * I1IiiI
iiiI11 = kodi . translate_path ( kodi . get_profile ( ) )
OOooO = os . path . join ( iiiI11 , 'links' )
OOoO00o = 'links.txt'
if not os . path . exists ( iiiI11 ) :
 os . mkdir ( iiiI11 )
if not os . path . exists ( OOooO ) :
 os . mkdir ( OOooO )
 if 9 - 9: I1IiiI - Ii1I % i1IIi % OoooooooOO
i1iIIi1 = I1i1I (
 MAIN = 'main' , ADD_LINK = 'add_link' , PLAY_LINK = 'play_link' , DELETE_LINK = 'delete_link' , SETTINGS = 'settings' , EDIT_LINK = 'edit_link' , OPEN_DIR = 'open_dir' ,
 CREATE_DIR = 'create_dir' , DELETE_DIR = 'delete_dir' , RENAME_DIR = 'rename_dir'
 )
if 50 - 50: i11iIiiIii - Ii1I
oo0Ooo0 = URL_Dispatcher ( )
if 46 - 46: ooOoO0o % ooOoO0o - oO0o * o0oOOo0O0Ooo % iII111i
@ oo0Ooo0 . register ( i1iIIi1 . MAIN )
def OOooO0OOoo ( ) :
 iIii1 ( OOooO )
 if 71 - 71: OoO0O00
@ oo0Ooo0 . register ( i1iIIi1 . OPEN_DIR , [ 'path' ] )
def iIii1 ( path ) :
 kodi . create_item ( { 'mode' : i1iIIi1 . CREATE_DIR , 'path' : path } , 'Crear Categoria ' , is_folder = False , is_playable = False )
 kodi . create_item ( { 'mode' : i1iIIi1 . ADD_LINK , 'path' : path } , 'Agregar Enlace al video' , is_folder = False , is_playable = False )
 kodi . create_item ( { 'mode' : i1iIIi1 . SETTINGS } , 'Ajustar URLResolver' , is_folder = False , is_playable = False )
 path , oO0O , OOoO000O0OO = iiI1IiI ( path )
 for II in sorted ( oO0O ) :
  ooOoOoo0O ( path , II )
  if 76 - 76: O0 / o0oOOo0O0Ooo . I1IiiI * Ii1I - OOooOOo
 if OOoO00o in OOoO000O0OO :
  Oooo = os . path . join ( path , OOoO00o )
  with open ( Oooo ) as O00o :
   for O00 , i11I1 in enumerate ( O00o ) :
    Ii11Ii11I = i11I1 . split ( '|' )
    iI11i1I1 = Ii11Ii11I [ 0 ] . strip ( )
    if not iI11i1I1 : continue
    try : o0o0OOO0o0 = Ii11Ii11I [ 1 ]
    except : o0o0OOO0o0 = Ii11Ii11I [ 0 ]
    ooOOOo0oo0O0 ( O00 , iI11i1I1 , o0o0OOO0o0 , path )
    if 71 - 71: I1Ii111 . O0
 kodi . set_content ( 'files' )
 kodi . end_of_directory ( cache_to_disc = False )
 if 73 - 73: OOooOOo % OoOoOO00 - Ii1I
@ oo0Ooo0 . register ( i1iIIi1 . CREATE_DIR , [ 'path' ] , [ 'dir_name' ] )
def iiIIII1i1i ( path , dir_name = None ) :
 if dir_name is None :
  dir_name = kodi . get_keyboard ( 'Enter Directory Name' )
  if dir_name is None :
   return
   if 26 - 26: OoooooooOO
 try :
  os . mkdir ( os . path . join ( path , dir_name ) )
 except OSError as IiiI11Iiiii :
  kodi . notify ( msg = IiiI11Iiiii . strerror )
 kodi . refresh_container ( )
 if 18 - 18: o0oOOo0O0Ooo
@ oo0Ooo0 . register ( i1iIIi1 . DELETE_DIR , [ 'path' , 'dir_name' ] )
def I1i1I1II ( path , dir_name ) :
 path = os . path . join ( path , dir_name )
 try :
  os . rmdir ( path )
 except OSError :
  i1 = xbmcgui . Dialog ( ) . yesno ( 'La categoria ya existe' , 'Desea borrarla?' , nolabel = 'No' , yeslabel = 'Yes' )
  if i1 :
   shutil . rmtree ( path )
   kodi . refresh_container ( )
   if 48 - 48: O0 + O0 - I1ii11iIi11i . ooOoO0o / iIii1I11I1II1
@ oo0Ooo0 . register ( i1iIIi1 . RENAME_DIR , [ 'path' , 'dir_name' ] , [ 'new_name' ] )
def OoOOO00oOO0 ( path , dir_name , new_name = None ) :
 if new_name is None :
  new_name = kodi . get_keyboard ( 'Introduzca un nombre para la categoria' , dir_name )
  if new_name is None :
   return
   if 95 - 95: OOooOOo / OoooooooOO
 iI = os . path . join ( path , dir_name )
 o00O = os . path . join ( path , new_name )
 try :
  os . rename ( iI , o00O )
 except OSError as IiiI11Iiiii :
  kodi . notify ( msg = IiiI11Iiiii . strerror )
 kodi . refresh_container ( )
 if 69 - 69: oO0o % I1Ii111 - o0oOOo0O0Ooo + I1Ii111 - O0 % OoooooooOO
@ oo0Ooo0 . register ( i1iIIi1 . ADD_LINK , kwargs = [ 'link' , 'name' , 'refresh' , 'path' ] )
def Iii111II ( link = None , name = None , refresh = True , path = None ) :
 if path is None : path = OOooO
 if link is None :
  iiii11I = Ooo0OO0oOO ( )
 else :
  if name is None :
   iiii11I = ( link , )
  else :
   iiii11I = ( link , name )
   if 50 - 50: I1IiiI
 if iiii11I :
  if not os . path . exists ( os . path . dirname ( path ) ) :
   os . mkdir ( os . path . dirname ( path ) )
   if 34 - 34: I1IiiI * II111iiii % iII111i * OoOoOO00 - I1IiiI
  path = os . path . join ( path , OOoO00o )
  with open ( path , 'a' ) as O00o :
   i11I1 = '|' . join ( iiii11I )
   if not i11I1 . endswith ( '\n' ) :
    i11I1 += '\n'
   O00o . write ( i11I1 )
   if 33 - 33: o0oOOo0O0Ooo + OOooOOo * OoO0O00 - Oo0Ooo / oO0o % Ii1I
  if refresh :
   kodi . refresh_container ( )
   if 21 - 21: OoO0O00 * iIii1I11I1II1 % oO0o * i1IIi
@ oo0Ooo0 . register ( i1iIIi1 . SETTINGS )
def Ii11Ii1I ( ) :
 urlresolver . display_settings ( )
 if 72 - 72: iII111i / i1IIi * Oo0Ooo - I1Ii111
@ oo0Ooo0 . register ( i1iIIi1 . DELETE_LINK , [ 'index' , 'path' ] )
def Oo0O0O0ooO0O ( index , path ) :
 path = os . path . join ( path , OOoO00o )
 IIIIii = [ ]
 with open ( path ) as O00o :
  for O00 , i11I1 in enumerate ( O00o ) :
   if O00 == int ( index ) :
    continue
   IIIIii . append ( i11I1 )
   if 70 - 70: Ii1I / I11i . iII111i % Oo0Ooo
 OOoOO00OOO0OO ( path , IIIIii )
 kodi . refresh_container ( )
 if 16 - 16: I1IiiI * oO0o % IiII
@ oo0Ooo0 . register ( i1iIIi1 . EDIT_LINK , [ 'index' , 'path' ] )
def Oo000o ( index , path ) :
 path = os . path . join ( path , OOoO00o )
 IIIIii = [ ]
 with open ( path ) as O00o :
  for O00 , i11I1 in enumerate ( O00o ) :
   if O00 == int ( index ) :
    Ii11Ii11I = i11I1 . split ( '|' )
    iiii11I = Ooo0OO0oOO ( * Ii11Ii11I )
    if iiii11I :
     i11I1 = '|' . join ( iiii11I )
     if 7 - 7: ooOoO0o * OoO0O00 % oO0o . IiII
   IIIIii . append ( i11I1 )
   if 45 - 45: i11iIiiIii * II111iiii % iIii1I11I1II1 + I1ii11iIi11i - Ii1I
 OOoOO00OOO0OO ( path , IIIIii )
 kodi . refresh_container ( )
 if 17 - 17: IiII
@ oo0Ooo0 . register ( i1iIIi1 . PLAY_LINK , [ 'link' ] )
def ooOooo000oOO ( link ) :
 iiiii11iII1 . log ( 'Playing Link: |%s|' % ( link ) , log_utils . LOGDEBUG )
 Oo0oOOo = urlresolver . HostedMediaFile ( url = link )
 if not Oo0oOOo :
  iiiii11iII1 . log ( 'Indirect hoster_url not supported by urlresolver: %s' % ( link ) )
  kodi . notify ( 'Enlace no soportado: %s' % ( link ) , duration = 7500 )
  return False
 iiiii11iII1 . log ( 'Enlace soportado: |%s|' % ( link ) , log_utils . LOGDEBUG )
 if 58 - 58: II111iiii * OOooOOo * I1ii11iIi11i / OOooOOo
 try :
  oO0o0OOOO = Oo0oOOo . resolve ( )
  if not oO0o0OOOO or not isinstance ( oO0o0OOOO , basestring ) :
   try : O0O0OoOO0 = oO0o0OOOO . msg
   except : O0O0OoOO0 = link
   raise Exception ( O0O0OoOO0 )
 except Exception as IiiI11Iiiii :
  try : O0O0OoOO0 = str ( IiiI11Iiiii )
  except : O0O0OoOO0 = link
  kodi . notify ( 'Fallo al resolver: %s' % ( O0O0OoOO0 ) , duration = 7500 )
  return False
  if 10 - 10: OoooooooOO % iIii1I11I1II1
 iiiii11iII1 . log ( 'Enlace resuelto: |%s|%s|' % ( link , oO0o0OOOO ) , log_utils . LOGDEBUG )
 if 54 - 54: I1Ii111 - II111iiii % OoOoOO00 % I11i % iIii1I11I1II1 + ooOoO0o
 I1111I1iII11 = xbmcgui . ListItem ( path = oO0o0OOOO )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I1111I1iII11 )
 if 59 - 59: iIii1I11I1II1 * i11iIiiIii / I1ii11iIi11i * i1IIi * O0
def OOoOO00OOO0OO ( path , links ) :
 with open ( path , 'w' ) as O00o :
  for i11I1 in links :
   if not i11I1 . endswith ( '\n' ) :
    i11I1 += '\n'
    if 83 - 83: OoO0O00 / I1Ii111 . OoOoOO00 / IiII . OoOoOO00 . OOooOOo
   O00o . write ( i11I1 )
   if 75 - 75: I11i + OoO0O00 . OoOoOO00 . ooOoO0o + Oo0Ooo . OoO0O00
def Ooo0OO0oOO ( old_link = '' , old_name = '' ) :
 if old_link . endswith ( '\n' ) : old_link = old_link [ : - 1 ]
 if old_name . endswith ( '\n' ) : old_name = old_name [ : - 1 ]
 O0O = kodi . get_keyboard ( 'Edit Link' , old_link )
 if O0O is None :
  return
  if 98 - 98: OoooooooOO + iII111i . OoOoOO00
 Oo0ooOo0o = kodi . get_keyboard ( 'Introduzca un nombre' , old_name )
 if Oo0ooOo0o is None :
  return
  if 22 - 22: iIii1I11I1II1 / i11iIiiIii * iIii1I11I1II1 * II111iiii . OOooOOo / i11iIiiIii
 if Oo0ooOo0o :
  return ( O0O , Oo0ooOo0o )
 else :
  return ( O0O , )
  if 2 - 2: I1IiiI / O0 / o0oOOo0O0Ooo % OoOoOO00 % Ii1I
def ooOoOoo0O ( path , dir_name ) :
 o0o00OO0 = [ ]
 i1I1ii = { 'mode' : i1iIIi1 . DELETE_DIR , 'path' : path , 'dir_name' : dir_name }
 o0o00OO0 . append ( ( 'Borrar categoria' , 'RunPlugin(%s)' % ( kodi . get_plugin_url ( i1I1ii ) ) ) , )
 i1I1ii = { 'mode' : i1iIIi1 . RENAME_DIR , 'path' : path , 'dir_name' : dir_name }
 o0o00OO0 . append ( ( 'Renombrar categoria' , 'RunPlugin(%s)' % ( kodi . get_plugin_url ( i1I1ii ) ) ) , )
 path = os . path . join ( path , dir_name )
 kodi . create_item ( { 'mode' : i1iIIi1 . OPEN_DIR , 'path' : path } , dir_name , is_folder = True , menu_items = o0o00OO0 )
 if 61 - 61: II111iiii
def ooOOOo0oo0O0 ( index , link , label , path ) :
 o0o00OO0 = [ ]
 i1I1ii = { 'mode' : i1iIIi1 . DELETE_LINK , 'index' : index , 'path' : path }
 o0o00OO0 . append ( ( 'Delete Link' , 'RunPlugin(%s)' % ( kodi . get_plugin_url ( i1I1ii ) ) ) , )
 i1I1ii = { 'mode' : i1iIIi1 . EDIT_LINK , 'index' : index , 'path' : path }
 o0o00OO0 . append ( ( 'Edit Link' , 'RunPlugin(%s)' % ( kodi . get_plugin_url ( i1I1ii ) ) ) , )
 kodi . create_item ( { 'mode' : i1iIIi1 . PLAY_LINK , 'link' : link } , label , is_folder = False , is_playable = True , menu_items = o0o00OO0 )
 if 64 - 64: ooOoO0o / OoOoOO00 - O0 - I11i
def iiI1IiI ( path ) :
 try : return next ( os . walk ( path ) )
 except : return ( path , [ ] , [ ] )
 if 86 - 86: I11i % OoOoOO00 / I1IiiI / OoOoOO00
def iIIi1i1 ( argv = None ) :
 if sys . argv : argv = sys . argv
 i1I1ii = kodi . parse_query ( sys . argv [ 2 ] )
 iiiii11iII1 . log ( 'Version: |%s| Queries: |%s|' % ( kodi . get_version ( ) , i1I1ii ) )
 iiiii11iII1 . log ( 'Args: |%s|' % ( argv ) )
 if 10 - 10: I11i
 # don't process params that don't match our url exactly. (e.g. plugin://plugin.video.1channel/extrafanart)
 OOooOO000 = 'plugin://%s/' % ( kodi . get_id ( ) )
 if argv [ 0 ] != OOooOO000 :
  return
  if 97 - 97: I1ii11iIi11i + OOooOOo / iIii1I11I1II1 / iII111i
 I1111IIi = i1I1ii . get ( 'mode' , None )
 oo0Ooo0 . dispatch ( I1111IIi , i1I1ii )
 if 93 - 93: OoooooooOO / I1IiiI % i11iIiiIii + I1ii11iIi11i * OoO0O00
if __name__ == '__main__' :
 sys . exit ( iIIi1i1 ( ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
