# -*- coding: utf-8 -*-
# By NETAI TEAM - 2020 #
# Tenpvnf n Urvfraoret cbe fh bevragnpvba l nlhqn ra yn rapevcgnpvba. # 
if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * Ii1I
if 46 - 46: ooOoO0o * I11i - OoooooooOO
if 30 - 30: o0oOOo0O0Ooo - O0 % o0oOOo0O0Ooo - OoooooooOO * O0 * OoooooooOO
if 60 - 60: iIii1I11I1II1 / i1IIi * oO0o - I1ii11iIi11i + o0oOOo0O0Ooo
import urllib , urllib2 , sys , re , os , unicodedata
import xbmc , xbmcgui , xbmcplugin , xbmcaddon
import codecs
ooO0oo0oO0 = int ( sys . argv [ 1 ] )
if 100 - 100: i1IIi
I1Ii11I1Ii1i = xbmcaddon . Addon ( id = 'plugin.video.Realstream.tv' )
Ooo = I1Ii11I1Ii1i . getAddonInfo ( 'profile' )
o0oOoO00o = I1Ii11I1Ii1i . getAddonInfo ( 'path' )
i1 = xbmc . translatePath ( os . path . join ( o0oOoO00o , 'fanart.jpg' ) )
oOOoo00O0O = xbmc . translatePath ( os . path . join ( o0oOoO00o , 'icon.png' ) )
if 15 - 15: I1IiiI
exec codecs . decode ( "6C6976655F736F75726365203D2020636F646563732E6465636F64652827756767633A2F2F6F76672E796C2F3249697A506A59272C20275C7837325C7836665C7837345C7833315C78333327292E6465636F646528277574662D3827290D0A6C6976655F736F7572636532203D20636F646563732E6465636F64652827756767633A2F2F6F76672E796C2F324771796A614B272C20275C7837325C7836665C7837345C7833315C78333327292E6465636F646528277574662D38272920200D0A6C6976655F736F7572636533203D20636F646563732E6465636F64652827756767633A2F2F6F76672E796C2F32563371725647272C20275C7837325C7836665C7837345C7833315C78333327292E6465636F646528277574662D38272920200D0A6C6976655F736F7572636534203D20636F646563732E6465636F6465282775676763663A2F2F636E6667726F76612E70627A2F656E6A2F644B515A59367849272C20275C7837325C7836665C7837345C7833315C78333327292E6465636F646528277574662D38272920200D0A677569615F746474203D20636F646563732E6465636F6465282775676763663A2F2F6A6A6A2E63656274656E7A6E707662612D6771672E70627A2F6E7562656E2E637563272C20275C7837325C7836665C7837345C7833315C78333327292E6465636F646528277574662D3827290D0A7265676578203D20276E616D653D282E2B3F2975726C3D282E2B296C6F676F3D282E2B3F29270D0A6D33755F7468756D625F7265676578203D20277476672D6C6F676F3D5B5C27225D282E2A3F295B5C27225D270D0A6D33755F7265676578203D202723282E2B3F292C282E2B295C732A282E2B295C732A270D0A6D33755F67756961203D20273C74642077696474683D22323530222076616C69676E3D22746F70223E282E2B3F293C2F74643E5C732A7C636C6173733D22696E64223E282E2B293C2F7370616E3E270D0A6D33755F6576656E746F73203D20277469746C652D73656374696F6E2D776964676574223E3C7374726F6E673E282E2B3F293C2F7370616E3E7C636C6173733D226461696C79646179223E282E2B3F293C2F7370616E3E7C226461696C79686F7572223E282E2B3F293C2F7374726F6E673E7C636C6173733D226461696C79636F6D7065746974696F6E223E282E2B3F293C2F7370616E3E7C3C6120687265663D2222207469746C653D2253656D6966696E616C223E282E2B3F293C2F613E7C3C6920636C6173733D2269636F6E2D70616E74616C6C61223E3C2F693E282E2B3F293C2F7370616E3E270D0A755F74756265203D2027687474703A2F2F7777772E796F75747562652E636F6D270D0A6469726563746F73203D20636F646563732E6465636F64652827756767633A2F2F76632D67626279662E7A792F272C275C7837325C7836665C7837345C7833315C78333327292E6465636F646528277574662D382729" , "\x68\x65\x78" ) . decode ( 'utf-8' )
if 90 - 90: IiII * i1IIi / Ii1I . OoO0O00 * oO0o
if 16 - 16: ooOoO0o * IiII % I11i . I1Ii111 / IiII % iII111i
I11 = xbmc . translatePath ( os . path . join ( o0oOoO00o , 'buscar.jpg' ) )
Ii1iiii = xbmc . translatePath ( os . path . join ( o0oOoO00o , 'tvguia.jpg' ) )
OOO0O = xbmc . translatePath ( os . path . join ( o0oOoO00o , 'tdt.jpg' ) )
oo0ooO0oOOOOo = xbmc . translatePath ( os . path . join ( o0oOoO00o , 'pelisyseries.jpg' ) )
oO000OoOoo00o = xbmc . translatePath ( os . path . join ( o0oOoO00o , 'deportes.jpg' ) )
iiiI11 = xbmc . translatePath ( os . path . join ( o0oOoO00o , 'documentales.jpg' ) )
if 91 - 91: o0oOOo0O0Ooo / II111iiii . I1ii11iIi11i + OOooOOo
def iI11 ( s ) :
 if 17 - 17: o0oOOo0O0Ooo
 return '' . join ( ( c for c in unicodedata . normalize ( 'NFD' , s . decode ( 'utf-8' ) ) if unicodedata . category ( c ) != 'Mn' ) )
 if 64 - 64: Ii1I % i1IIi % OoooooooOO
def i1iIIi1 ( file ) :
 if 50 - 50: i11iIiiIii - Ii1I
 try :
  oo0Ooo0 = open ( file , 'r' )
  I1I11I1I1I = oo0Ooo0 . read ( )
  oo0Ooo0 . close ( )
  return I1I11I1I1I
 except :
  pass
def OooO0OO ( url ) :
 iiiIi = urllib2 . Request ( url )
 iiiIi . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36' )
 iiiIi . add_header ( 'Referer' , '%s' % url )
 iiiIi . add_header ( 'Connection' , 'keep-alive' )
 IiIIIiI1I1 = urllib2 . urlopen ( iiiIi )
 OoO000 = IiIIIiI1I1 . read ( )
 IiIIIiI1I1 . close ( )
 return OoO000
 if 42 - 42: oO0o - i1IIi / i11iIiiIii + OOooOOo + OoO0O00
def iIi ( url ) :
 if 40 - 40: oO0o . OoOoOO00 . Oo0Ooo . i1IIi
 try :
  iiiIi = urllib2 . Request ( url )
  iiiIi . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0' )
  IiIIIiI1I1 = urllib2 . urlopen ( iiiIi )
  OoO000 = IiIIIiI1I1 . read ( )
  IiIIIiI1I1 . close ( )
  return OoO000
 except urllib2 . URLError , I11iii :
  print 'We failed to open "%s".' % url
  if hasattr ( I11iii , 'code' ) :
   print 'We failed with error code - %s.' % I11iii . code
  if hasattr ( I11iii , 'reason' ) :
   print 'We failed to reach a server.'
   print 'Reason: ' , I11iii . reason
   if 54 - 54: OOooOOo + OOooOOo % I1Ii111 % i11iIiiIii / iIii1I11I1II1 . OOooOOo
def o0oO0o00oo ( ) :
 if 32 - 32: Oo0Ooo * O0 % oO0o % Ii1I . IiII
 if 61 - 61: ooOoO0o
 oOOO00o ( '[B][COLOR white]Real Stream TV:[/COLOR][/B]' , oOOoo00O0O , i1 )
 O0O00o0OOO0 ( '[COLOR orange]TDT[/COLOR]' , u_tube , 2 , OOO0O , i1 )
 O0O00o0OOO0 ( '[COLOR orange]Cine y Series[/COLOR]' , u_tube , 5 , oo0ooO0oOOOOo , i1 )
 O0O00o0OOO0 ( '[COLOR orange]Deportes[/COLOR]' , u_tube , 6 , oO000OoOoo00o , i1 )
 O0O00o0OOO0 ( '[COLOR orange]Documental[/COLOR]' , u_tube , 7 , iiiI11 , i1 )
 if 27 - 27: O0 % i1IIi * oO0o + i11iIiiIii + OoooooooOO * i1IIi
 oOOO00o ( '[COLOR white]GUIAS EVENTOS:[/COLOR]' , oOOoo00O0O , i1 )
 if 80 - 80: I11i * i11iIiiIii / I1Ii111
 O0O00o0OOO0 ( '[COLOR orange]GUIA TDT[/COLOR]' , u_tube , 9 , Ii1iiii , i1 )
 if 9 - 9: Ii1I + oO0o % Ii1I + i1IIi . OOooOOo
 if 31 - 31: o0oOOo0O0Ooo + I11i + I11i / II111iiii
def iiI1 ( ) :
 OoO000 = OooO0OO ( guia_tdt )
 i11Iiii = re . compile ( '<td width="250" valign="top">(.+?)</td>\s*|class="ind">(.+)</span>' ) . findall ( OoO000 )
 for iI , I1i1I1II in i11Iiii :
  i1IiIiiI ( '[COLOR gold]%s[/COLOR] [COLOR white]%s[/COLOR]' % ( iI , I1i1I1II ) , I1I , 9 , '' )
  if 80 - 80: OoOoOO00 - OoO0O00
  if 87 - 87: oO0o / I11i - i1IIi * OOooOOo / OoooooooOO . O0
def iii11I111 ( ) :
 if 63 - 63: OoO0O00 * oO0o - iII111i * O0
 I1I11I1I1I = iIi ( live_source )
 i11Iiii = re . compile ( m3u_regex ) . findall ( I1I11I1I1I )
 for iIii111IIi , iI , I1I in i11Iiii :
  try :
   iii11 ( iI , I1I , iIii111IIi )
  except :
   pass
   if 58 - 58: OOooOOo * i11iIiiIii / OoOoOO00 % I1Ii111 - I1ii11iIi11i / oO0o
def ii11i1 ( ) :
 if 29 - 29: I1ii11iIi11i % I1IiiI + ooOoO0o / o0oOOo0O0Ooo + OOooOOo * o0oOOo0O0Ooo
 I1I11I1I1I = iIi ( live_source2 )
 i11Iiii = re . compile ( m3u_regex ) . findall ( I1I11I1I1I )
 for iIii111IIi , iI , I1I in i11Iiii :
  try :
   iii11 ( iI , I1I , iIii111IIi )
  except :
   pass
   if 42 - 42: Ii1I + oO0o
def o0O0o0Oo ( ) :
 if 16 - 16: O0 - I1Ii111 * iIii1I11I1II1 + iII111i
 I1I11I1I1I = iIi ( live_source3 )
 i11Iiii = re . compile ( m3u_regex ) . findall ( I1I11I1I1I )
 for iIii111IIi , iI , I1I in i11Iiii :
  try :
   iii11 ( iI , I1I , iIii111IIi )
  except :
   pass
   if 50 - 50: II111iiii - ooOoO0o * I1ii11iIi11i / I1Ii111 + o0oOOo0O0Ooo
def O0O0O ( ) :
 if 83 - 83: I1ii11iIi11i / ooOoO0o
 I1I11I1I1I = iIi ( live_source4 )
 i11Iiii = re . compile ( m3u_regex ) . findall ( I1I11I1I1I )
 for iIii111IIi , iI , I1I in i11Iiii :
  try :
   iii11 ( iI , I1I , iIii111IIi )
  except :
   pass
   if 49 - 49: o0oOOo0O0Ooo
def IIii1Ii1 ( ) :
 if 5 - 5: iII111i % OOooOOo + ooOoO0o % i11iIiiIii + o0oOOo0O0Ooo
 I1I11I1I1I = iIi ( live_source5 )
 i11Iiii = re . compile ( m3u_regex ) . findall ( I1I11I1I1I )
 for iIii111IIi , iI , I1I in i11Iiii :
  try :
   iii11 ( iI , I1I , iIii111IIi )
  except :
   pass
   if 60 - 60: OoO0O00 * OoOoOO00 - OoO0O00 % OoooooooOO - ooOoO0o + I1IiiI
   if 70 - 70: IiII * Oo0Ooo * I11i / Ii1I
def oO ( ) :
 if 93 - 93: OoO0O00 % oO0o . OoO0O00 * I1Ii111 % Ii1I . II111iiii
 I1I11I1I1I = iIi ( movie_source )
 i11Iiii = re . compile ( regex ) . findall ( I1I11I1I1I )
 for iI , I1I , iIii111IIi in i11Iiii :
  try :
   iI1ii1Ii ( iI , I1I , iIii111IIi )
  except :
   pass
   if 92 - 92: OoOoOO00
def i1OOO ( ) :
 if 59 - 59: II111iiii + OoooooooOO * OoOoOO00 + i1IIi
 I1I11I1I1I = iIi ( docs_source )
 i11Iiii = re . compile ( regex ) . findall ( I1I11I1I1I )
 for iI , I1I , iIii111IIi in i11Iiii :
  try :
   iI1ii1Ii ( iI , I1I , iIii111IIi )
  except :
   pass
   if 58 - 58: II111iiii * OOooOOo * I1ii11iIi11i / OOooOOo
def iI1ii1Ii ( name , url , thumb ) :
 if 75 - 75: oO0o
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( m3u_thumb_regex ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   O0O00o0OOO0 ( name , url , '' , thumb , thumb )
  else :
   O0O00o0OOO0 ( name , url , '' , oOOoo00O0O , i1 )
 else :
  if 'youtube.com/watch?v=' in url :
   url = 'plugin://plugin.video.youtube/play/?video_id=%s' % ( url . split ( '=' ) [ - 1 ] )
  elif 'dailymotion.com/video/' in url :
   url = url . split ( '/' ) [ - 1 ] . split ( '_' ) [ 0 ]
   url = 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=%s' % url
  else :
   url = url
  if 'tvg-logo' in thumb :
   thumb = re . compile ( m3u_thumb_regex ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   I1III ( name , url , 1 , thumb , thumb )
  else :
   I1III ( name , url , 1 , oOOoo00O0O , i1 )
   if 63 - 63: OOooOOo % oO0o * oO0o * OoO0O00 / I1ii11iIi11i
def iii11 ( name , url , thumb ) :
 if 74 - 74: II111iiii
 name = re . sub ( '\s+' , ' ' , name ) . strip ( )
 url = url . replace ( '"' , ' ' ) . replace ( '&amp;' , '&' ) . strip ( )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  if 'tvg-logo' in thumb :
   thumb = re . compile ( m3u_thumb_regex ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   O0O00o0OOO0 ( name , url , '' , thumb , thumb )
  else :
   O0O00o0OOO0 ( name , url , '' , oOOoo00O0O , i1 )
 else :
  if 'youtube.com/watch?v=' in url :
   url = 'plugin://plugin.video.youtube/play/?video_id=%s' % ( url . split ( '=' ) [ - 1 ] )
  elif 'dailymotion.com/video/' in url :
   url = url . split ( '/' ) [ - 1 ] . split ( '_' ) [ 0 ]
   url = 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=%s' % url
  else :
   url = url
  if 'tvg-logo' in thumb :
   thumb = re . compile ( m3u_thumb_regex ) . findall ( str ( thumb ) ) [ 0 ] . replace ( ' ' , '%20' )
   I1III ( name , url , 1 , thumb , thumb )
  else :
   I1III ( name , url , 1 , oOOoo00O0O , i1 )
   if 75 - 75: o0oOOo0O0Ooo . ooOoO0o
def Oo0O00Oo0o0 ( name , url ) :
 if 87 - 87: ooOoO0o * Oo0Ooo % i11iIiiIii % OoOoOO00 - OOooOOo
 if '.m3u8' or '.ts' in url :
  name = re . sub ( '\s+' , ' ' , name ) . strip ( )
  url = url . replace ( "http://" , "plugin://plugin.video.f4mTester/?url=http://" ) . replace ( ".m3u8" , ".ts" )
  url = url + "&amp;streamtype=TSDOWNLOADER&name=%s" % name
  O0ooo0O0oo0 = url
  oo0oOo = xbmcgui . ListItem ( name , path = O0ooo0O0oo0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0oOo )
  return
 else :
  O0ooo0O0oo0 = url
  name = re . sub ( '\s+' , ' ' , name ) . strip ( )
  oo0oOo = xbmcgui . ListItem ( name , path = O0ooo0O0oo0 )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , oo0oOo )
  return
  if 89 - 89: OoOoOO00
def OO0oOoOO0oOO0 ( ) :
 oO0OOoo0OO = [ ]
 O0ii1ii1ii = sys . argv [ 2 ]
 if len ( O0ii1ii1ii ) >= 2 :
  oooooOoo0ooo = sys . argv [ 2 ]
  I1I1IiI1 = oooooOoo0ooo . replace ( '?' , '' )
  if ( oooooOoo0ooo [ len ( oooooOoo0ooo ) - 1 ] == '/' ) :
   oooooOoo0ooo = oooooOoo0ooo [ 0 : len ( oooooOoo0ooo ) - 2 ]
  III1iII1I1ii = I1I1IiI1 . split ( '&' )
  oO0OOoo0OO = { }
  for oOOo0 in range ( len ( III1iII1I1ii ) ) :
   oo00O00oO = { }
   oo00O00oO = III1iII1I1ii [ oOOo0 ] . split ( '=' )
   if ( len ( oo00O00oO ) ) == 2 :
    oO0OOoo0OO [ oo00O00oO [ 0 ] ] = oo00O00oO [ 1 ]
 return oO0OOoo0OO
 if 23 - 23: OoO0O00 + OoO0O00 . OOooOOo
def O0O00o0OOO0 ( name , url , mode , iconimage , fanart ) :
 if 38 - 38: I1Ii111
 Ii1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 OOooOO000 = True
 OOoOoo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 OOoOoo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 OOoOoo . setProperty ( 'fanart_image' , fanart )
 if ( 'youtube.com/user/' in url ) or ( 'youtube.com/channel/' in url ) or ( 'youtube/user/' in url ) or ( 'youtube/channel/' in url ) :
  Ii1 = 'plugin://plugin.video.youtube/%s/%s/' % ( url . split ( '/' ) [ - 2 ] , url . split ( '/' ) [ - 1 ] )
  OOooOO000 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Ii1 , listitem = OOoOoo , isFolder = True )
  return OOooOO000
 OOooOO000 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Ii1 , listitem = OOoOoo , isFolder = True )
 return OOooOO000
 if 85 - 85: I1ii11iIi11i % iII111i % ooOoO0o
def i1IiIiiI ( name , url , mode , iconimage ) :
 Ii1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 OOooOO000 = True
 OOoOoo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 OOoOoo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 OOooOO000 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Ii1 , listitem = OOoOoo , isFolder = True )
 return OOooOO000
 if 82 - 82: i11iIiiIii - iII111i * OoooooooOO / I11i
def I1III ( name , url , mode , iconimage , fanart ) :
 if 31 - 31: IiII . OoO0O00 - iIii1I11I1II1
 Ii1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 OOoOoo = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 OOoOoo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 OOoOoo . setProperty ( 'fanart_image' , fanart )
 OOoOoo . setProperty ( 'IsPlayable' , 'true' )
 OOooOO000 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Ii1 , listitem = OOoOoo )
 if 64 - 64: I11i
def oOOO00o ( name , iconimage , fanart ) :
 if 22 - 22: Oo0Ooo + Ii1I % I1ii11iIi11i
 Ii1 = sys . argv [ 0 ] + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 OOoOoo = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 OOoOoo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 OOoOoo . setProperty ( 'fanart_image' , fanart )
 OOoOoo . setProperty ( 'IsPlayable' , 'false' )
 OOooOO000 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Ii1 , listitem = OOoOoo )
 if 9 - 9: OoooooooOO
def OOOOo ( iconimage , fanart ) :
 if 76 - 76: OoO0O00
 Ii1 = sys . argv [ 0 ] + "&iconimage=" + urllib . quote_plus ( iconimage )
 OOoOoo = xbmcgui . ListItem ( iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 OOoOoo . setProperty ( 'fanart_image' , fanart )
 OOoOoo . setProperty ( 'IsPlayable' , 'false' )
 OOooOO000 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Ii1 , listitem = OOoOoo )
 if 29 - 29: OOooOOo + Oo0Ooo . i11iIiiIii - i1IIi / iIii1I11I1II1
oooooOoo0ooo = OO0oOoOO0oOO0 ( )
I1I = None
iI = None
i1iI11i1ii11 = None
OOooo0O00o = None
if 85 - 85: o0oOOo0O0Ooo - Oo0Ooo
try :
 I1I = urllib . unquote_plus ( oooooOoo0ooo [ "url" ] )
except :
 pass
try :
 iI = urllib . unquote_plus ( oooooOoo0ooo [ "name" ] )
except :
 pass
try :
 i1iI11i1ii11 = int ( oooooOoo0ooo [ "mode" ] )
except :
 pass
try :
 OOooo0O00o = urllib . unquote_plus ( oooooOoo0ooo [ "iconimage" ] )
except :
 pass
 if 32 - 32: OoooooooOO / iIii1I11I1II1 - o0oOOo0O0Ooo
print "Mode: " + str ( i1iI11i1ii11 )
print "URL: " + str ( I1I )
print "Name: " + str ( iI )
print "iconimage: " + str ( OOooo0O00o )
if 91 - 91: iII111i % i1IIi % iIii1I11I1II1
if 20 - 20: OOooOOo % Ii1I / Ii1I + Ii1I
if 45 - 45: oO0o - IiII - OoooooooOO - OoO0O00 . II111iiii / O0
if i1iI11i1ii11 == None or I1I == None or len ( I1I ) < 1 :
 o0oO0o00oo ( )
 if 51 - 51: O0 + iII111i
elif i1iI11i1ii11 == 1 :
 Oo0O00Oo0o0 ( iI , I1I )
 if 8 - 8: oO0o * OoOoOO00 - Ii1I - OoO0O00 * OOooOOo % I1IiiI
elif i1iI11i1ii11 == 2 :
 iii11I111 ( )
 if 48 - 48: O0
elif i1iI11i1ii11 == 3 :
 oO ( )
 if 11 - 11: I11i + OoooooooOO - OoO0O00 / o0oOOo0O0Ooo + Oo0Ooo . II111iiii
elif i1iI11i1ii11 == 4 :
 i1OOO ( )
 if 41 - 41: Ii1I - O0 - O0
elif i1iI11i1ii11 == 98 :
 searchtv ( )
 if 68 - 68: OOooOOo % I1Ii111
elif i1iI11i1ii11 == 99 :
 search ( )
 if 88 - 88: iIii1I11I1II1 - ooOoO0o + OOooOOo
elif i1iI11i1ii11 == 5 :
 ii11i1 ( )
 if 40 - 40: I1IiiI * Ii1I + OOooOOo % iII111i
elif i1iI11i1ii11 == 6 :
 o0O0o0Oo ( )
 if 74 - 74: oO0o - Oo0Ooo + OoooooooOO + I1Ii111 / OoOoOO00
elif i1iI11i1ii11 == 7 :
 O0O0O ( )
 if 23 - 23: O0
elif i1iI11i1ii11 == 8 :
 IIii1Ii1 ( )
 if 85 - 85: Ii1I
elif i1iI11i1ii11 == 9 :
 iiI1 ( )
 if 84 - 84: I1IiiI . iIii1I11I1II1 % OoooooooOO + Ii1I % OoooooooOO % OoO0O00
elif i1iI11i1ii11 == 10 :
 guia_eventos ( )
 if 42 - 42: OoO0O00 / I11i / o0oOOo0O0Ooo + iII111i / OoOoOO00
 if 84 - 84: ooOoO0o * II111iiii + Oo0Ooo
xbmcplugin . endOfDirectory ( ooO0oo0oO0 ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
